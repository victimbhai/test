# Agent Chunk 15: Remediation, Legacy Matrix & Corpus Gaps

**Agent Task:** Apply the correct remediation for each output context. Use the regression test template for every fix. Check the legacy matrix to avoid wasting time on obsolete techniques. Review the corpus gap analysis to understand evidence limitations before trusting any finding.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 26. Remediation and Regression Tests

### 26.1 Primary Remediation: Context-Specific Output Encoding

| Output Context | Encoding Function (by language) | Verify With |
|---|---|---|
| HTML body | PHP: `htmlspecialchars()`, Python/Jinja2: auto-escape, Java: OWASP Java Encoder, Node: framework auto-escape | Submit `<test>` → check for `&lt;test&gt;` |
| HTML attribute | Same as HTML body + always quote attribute values | Submit `"test` → check for `&quot;test` |
| JavaScript string | PHP: `json_encode()`, Python: `json.dumps()`, Java: OWASP `forJavaScript()` | Submit `'test` → check for `\'test` or `'test` |
| URL parameter | PHP: `urlencode()`, Python: `urllib.parse.quote()`, JS: `encodeURIComponent()` | Submit `<test>` → check for `%3Ctest%3E` |
| Inline JSON in HTML | JSON encode + replace `<` with `<` | Submit `</script>` → check for `</script>` |

### 26.2 Secondary Remediation: Safe Rendering Primitives

- Replace `innerHTML` assignments with `textContent` where possible
- Use `document.createElement()` + `setAttribute()` instead of HTML string construction
- Use `addEventListener()` instead of inline event handlers
- Serve JSON responses with `Content-Type: application/json` and `X-Content-Type-Options: nosniff`

### 26.3 Tertiary Remediation: Defense in Depth

- Deploy Content Security Policy with nonce-based script restrictions
- Set `HttpOnly` and `Secure` flags on session cookies
- Set `SameSite=Lax` (or `Strict` where appropriate) on cookies
- Deploy Trusted Types on Chromium-based browsers
- Add `X-Content-Type-Options: nosniff` to all responses

### 26.4 Regression Test Template

For every remediated reflected XSS finding, create a regression test:

```
TEST: Reflected XSS regression — [VECTOR_ID]
ENDPOINT: [URL pattern]
INPUT: [UNIQUE_REFLECTION_MARKER] with context-significant characters
        (e.g., <, >, ", ', `, /, \, &, ;, (, ))
METHOD: [GET/POST]
EXPECTED: All significant characters are properly encoded for the output context
VERIFY:
  1. Response contains encoded form (e.g., &lt; not <)
  2. Browser renders value as text, not as markup or script
  3. No DOM changes or console output from the marker
  4. CSP headers present and correctly configured
NEGATIVE CONTROL: Same test with safe input → renders normally
FREQUENCY: Run on every deployment
```

---

## 27. Current-Versus-Legacy Matrix

| Feature/Behavior | Legacy (pre-2020) | Current (2024–2026) | Action |
|---|---|---|---|
| IE conditional comments | `<!--[if IE]>` executed | **REMOVED** — IE discontinued | Flag any corpus reference |
| Backtick attribute values | IE treated `` attr=`value` `` | **Not supported** in modern browsers | Flag any corpus reference |
| CSS expressions | `expression()` evaluated as JS in IE | **REMOVED** | Flag any corpus reference |
| XSS Auditor (Chrome) | Active through Chrome 77 | **REMOVED** — Chrome 78 (July 2019) | Flag any corpus reference |
| X-XSS-Protection header | Controlled browser XSS filter | **OBSOLETE** — no effect | Flag any corpus reference |
| VBScript in IE | `vbscript:` protocol executed | **REMOVED** | Flag any corpus reference |
| Flash/Java plugins | `<object>`, `<embed>` with plugins | **REMOVED** — plugins deprecated | Flag any corpus reference |
| MIME sniffing (aggressive) | Browsers sniffed text/html from application/json | **Reduced** — `nosniff` widely respected | Check X-Content-Type-Options |
| `document.domain` setter | Allowed cross-subdomain access | **Deprecated** — Chrome 115+ ignores | Flag any corpus reference |
| DOMPurify 2.x bypasses | Various namespace confusion | **Fixed** in 2.x, new issues in 3.x | Label with version |
| `popover` attribute | Not available | Chrome 114+, Firefox 125+, Safari 17+ | New attack surface |
| Trusted Types | Not available | Chrome 83+ only | Check browser support |
| `<selectedcontent>` | Not available | Chrome 130+ (DOMPurify CVE-2026-47423) | New attack surface |

**Corpus legacy content requiring flagging**:
- Any reference to XSS Auditor or `X-XSS-Protection` as a defense
- Any reference to IE-specific behaviors (conditional comments, VBScript, expression())
- Any reference to browser plugins (Flash, Java applets)
- Any DOMPurify bypass without version specification

---

## 28. Corpus Gap Analysis

### 28.1 HIGH Severity Gaps

| Research Topic | Gap Description |
|---|---|
| Framework XSS (KB-44) | Zero citations; covers React/Next/Vue/Nuxt/Angular/Svelte/Astro but **UNVERIFIED** |
| HTMX security | **Entire topic missing** from corpus |
| Alpine.js security | **Entire topic missing** from corpus |
| SolidJS security | **Entire topic missing** from corpus |
| Qwik security | **Entire topic missing** from corpus |
| Browser version matrix | No maintained matrix of browser feature support |
| Negative controls | No systematic negative tests in corpus |
| Regression test fixtures | No test fixtures provided |
| Current-vs-legacy separation | Legacy presented as current throughout |
| Tool validation | Tools never validated against real browsers |

### 28.2 MEDIUM Severity Gaps

| Research Topic | Gap Description |
|---|---|
| Server filter bypass (KB-15) | Missing version specificity |
| Sanitizer bypass (KB-16) | Missing CVE-2026-* entries |
| WAF bypass (KB-17) | Missing WAFFLED research findings |
| Trusted Types deployment | No deployment statistics |
| CSP deployment data | No current deployment stats |
| Cache poisoning escalation | No detailed case studies |
| Remediation verification | No structured approach |
| Streaming SSR | Entire topic missing |
| Post-sanitization mutation | Missing modern examples |

### 28.3 Tool Gaps

| Tool | Critical Gap |
|---|---|
| xss-detector.py | Response-based only — no browser execution verification (false positives) |
| xss-exploiter.py | No safety controls enforced in code |
| reflected-xss-probe.yaml | Static canary, no context analysis, rates as "high" without browser proof |
| reflected-xss-html-injection.yaml | Rates as "critical" without browser execution |
| All tools | No POST method testing, no dependency locks, no negative controls |

---

*Next chunk: chunk-16-research-hypotheses.md*
