# XSS Security Testing Agent Project

## Project Overview
This project builds a comprehensive Cross-Site Scripting (XSS) vulnerability testing agent through systematic deep research. This agent will detect and exploit all variants of XSS — reflected, stored, DOM-based, mutation-based, and exotic — across every injection context, with advanced CSP bypass, WAF evasion, sanitizer bypass, and real-world exploitation capabilities.

## Why XSS Agent is Critical
- **Most Common Web Vulnerability** — Consistently #1 in bug bounty findings
- **Session Hijacking** — Steal cookies, tokens, and session data
- **Account Takeover** — Change passwords, emails, and permissions
- **Data Exfiltration** — Keylogging, form interception, clipboard theft
- **Network Pivoting** — Access internal services via victim's browser
- **RCE Potential** — Electron/WebView/desktop app XSS → system access
- **Worm Propagation** — Self-replicating XSS for mass compromise

## Directory Structure
```
xss-agent/
├── XSS_CLAUDE.md                   # This file
├── XSS_RESEARCH_PROMPT.md          # 13-phase research directive
├── knowledge-base/                  # 42 research files
│   ├── 01-xss-fundamentals.md
│   ├── 02-browser-parsing-execution.md
│   ├── 03-reflected-xss-html-context.md
│   ├── 04-reflected-xss-javascript-context.md
│   ├── 05-reflected-xss-special-contexts.md
│   ├── 06-stored-xss-vectors.md
│   ├── 07-stored-xss-exotic.md
│   ├── 08-blind-xss.md
│   ├── 09-dom-xss-sources-sinks.md
│   ├── 10-dom-xss-modern.md
│   ├── 11-dom-xss-frameworks.md
│   ├── 12-csp-bypass-fundamentals.md
│   ├── 13-csp-bypass-techniques.md
│   ├── 14-csp-bypass-real-world.md
│   ├── 15-filter-bypass-server.md
│   ├── 16-sanitizer-bypass-client.md
│   ├── 17-waf-bypass-xss.md
│   ├── 18-advanced-bypass-techniques.md
│   ├── 19-exploitation-session-hijack.md
│   ├── 20-exploitation-account-takeover.md
│   ├── 21-exploitation-rce-advanced.md
│   ├── 22-exploitation-payloads.md
│   ├── 23-svg-mathml-xml-xss.md
│   ├── 24-json-api-header-xss.md
│   ├── 25-file-upload-xss.md
│   ├── 26-pdf-email-markdown-xss.md
│   ├── 27-browser-api-exploitation.md
│   ├── 28-prototype-pollution-xss.md
│   ├── 29-postmessage-emerging.md
│   ├── 30-bug-bounty-xss.md
│   ├── 31-xss-cve-analysis.md
│   ├── 32-xss-impact.md
│   ├── 33-xss-prevention.md
│   ├── 34-xss-tools.md
│   ├── 35-xss-detection-methodology.md
│   ├── 36-burp-integration.md
│   ├── 37-xss-polyglots.md
│   ├── 38-methodology-compilation.md
│   ├── 39-agent-methodology.md
│   ├── 40-agent-decision-logic.md
│   ├── 41-agent-integration.md
│   └── 42-agent-prompt-compilation.md
├── payloads/
│   ├── detection/                   # Probe and detection payloads
│   ├── html-context/                # HTML context breakout payloads
│   ├── javascript-context/          # JS context breakout payloads
│   ├── dom-xss/                     # DOM XSS source-sink payloads
│   ├── stored-xss/                  # Persistent injection payloads
│   ├── csp-bypass/                  # CSP bypass payloads
│   ├── waf-bypass/                  # WAF evasion payloads
│   ├── sanitizer-bypass/            # Sanitizer bypass payloads
│   ├── svg-mathml/                  # SVG and MathML payloads
│   ├── framework-specific/          # React, Angular, Vue, jQuery payloads
│   ├── exploitation/                # Impact demonstration payloads
│   ├── polyglots/                   # Multi-context polyglot payloads
│   └── exotic/                      # PDF, email, markdown, upload payloads
├── tools/
│   ├── xss-detector.py              # Automated XSS detection scanner
│   ├── xss-exploiter.py             # XSS exploitation framework
│   ├── dom-xss-scanner.py           # DOM XSS source-sink analyzer
│   ├── csp-analyzer.py              # CSP policy analysis and bypass
│   ├── blind-xss-server.py          # Blind XSS callback collector
│   └── nuclei-templates/            # Nuclei XSS detection templates
├── agent/
│   ├── XSS_AGENT_PROMPT.md          # Production agent system prompt
│   ├── methodology.md               # Complete testing methodology
│   └── xss-agent-logic.md           # Decision logic for the agent
└── reports/                         # Generated vulnerability reports
```

## Agent Dependencies
- **auth-agent** — Provides authenticated sessions, token handling
- **recon-agent** — Provides target URLs, parameters, technology stack
- **waf-bypass-agent** — Provides WAF evasion for payload delivery

## Research Phases
| Phase | Topic | KB Files |
|-------|-------|----------|
| 1 | XSS Fundamentals & Taxonomy | 01-02 |
| 2 | Reflected XSS (All Contexts) | 03-05 |
| 3 | Stored XSS (Vectors, Exotic, Blind) | 06-08 |
| 4 | DOM-based XSS | 09-11 |
| 5 | CSP Bypass | 12-14 |
| 6 | Filter/WAF/Sanitizer Bypass | 15-18 |
| 7 | Exploitation & Impact | 19-22 |
| 8 | Context-Specific & Exotic | 23-26 |
| 9 | Modern & Emerging | 27-29 |
| 10 | Real-World Intelligence | 30-33 |
| 11 | Tools & Automation | 34-36 |
| 12 | Payloads & Methodology | 37-38 |
| 13 | Agent Creation | 39-42 |

## Commands
```bash
# Execute full XSS research
"Execute XSS_RESEARCH_PROMPT.md - launch parallel agents for all phases"

# Research specific phase
"Begin PHASE 5: Research CSP bypass techniques"

# The AI agent executes these tools during testing:
python xss-agent/tools/xss-detector.py -u "https://target.com/search?q=test" --context auto
python xss-agent/tools/xss-exploiter.py -u "https://target.com/search?q=test" --payload session-hijack
python xss-agent/tools/dom-xss-scanner.py -u "https://target.com/app" --crawl
python xss-agent/tools/csp-analyzer.py -u "https://target.com" --bypass
python xss-agent/tools/blind-xss-server.py --port 8443 --callback https://your-server.com
```
