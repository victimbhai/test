# 59 - REST API Response Rendering XSS

## Overview

REST API endpoints are vulnerable to XSS when they:
- Reflect user input in responses without encoding
- Serve responses with incorrect Content-Type headers (text/html instead of application/json)
- Omit X-Content-Type-Options: nosniff, allowing browser MIME sniffing
- Use JSONP callbacks without identifier validation
- Allow client-side code to insert JSON values into the DOM unsafely

## Content-Type Confusion Attacks

### Incorrect Content-Type on API Responses

When an API returns data with `text/html` Content-Type instead of `application/json`, browsers render the response as HTML, executing any embedded scripts.

```http
HTTP/1.1 200 OK
Content-Type: text/html

{"error": "<script>alert(document.cookie)</script>"}
```

**CVE-2025-11925 (BLU-IC2/IC4):** Devices used `text/html` Content-Type instead of `application/json` in API replies, allowing injection of HTML/JavaScript into responses. Affects versions through 1.19.5.

**CVE-2025-32960 (Jmix REST API):** The `/files` endpoint served uploaded `.html` files back with `text/html` Content-Type, enabling stored XSS. Fixed in version 7.2.7.

### Server Content-Type Confusion Pattern

```python
# VULNERABLE: API returning HTML Content-Type for JSON data
@app.route('/api/search')
def search():
    query = request.args.get('q', '')
    results = db.search(query)
    # Missing explicit Content-Type -- may default to text/html
    return json.dumps({"query": query, "results": results})

# SAFE: Explicit JSON Content-Type with nosniff
@app.route('/api/search')
def search():
    query = request.args.get('q', '')
    results = db.search(query)
    response = make_response(json.dumps({"query": query, "results": results}))
    response.headers['Content-Type'] = 'application/json'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response
```

### X-Content-Type-Options and Browser Sniffing

Chrome's Opaque Response Blocking (ORB) blocks cross-origin no-cors reads of responses that look like HTML/JSON/XML, but ORB does nothing for same-origin loads. The `nosniff` header remains essential for same-origin API endpoints.

Google Research paper "Content Sniffing with Comma Chameleon" describes how MIME type sniffing leads to polyglot files valid as multiple types simultaneously.

### Parse Server Content-Type Bypass

**CVE-2026-32728:** Stored XSS filter bypass via Content-Type MIME parameter and missing XML extension blocklist entries. Attacker uploads content that bypasses MIME checks and is served as HTML/XML.

**CVE-2026-61448:** Stored XSS from malformed Content-Type bypassing MIME checks. Fixed in 9.10.0-alpha.2 and 8.6.84.

```http
# Attack: Upload with manipulated Content-Type parameter
POST /api/files HTTP/1.1
Content-Type: multipart/form-data; boundary=----
Content-Disposition: form-data; name="file"; filename="data.xml"
Content-Type: text/html; charset=utf-8

<script>alert(document.cookie)</script>
```

## JSON-to-HTML Sniffing

### Client-Side DOM Injection from API Responses

JSON responses are not inherently safe from XSS. When client-side code uses JSON values to update the DOM, XSS results regardless of server-side Content-Type headers.

```javascript
// VULNERABLE: API response inserted into DOM via innerHTML
fetch('/api/user/profile')
  .then(r => r.json())
  .then(data => {
    document.getElementById('bio').innerHTML = data.bio;
    // If data.bio = "<img src=x onerror=alert(document.cookie)>"
    // XSS executes
  });

// SAFE: Use textContent for non-HTML data
fetch('/api/user/profile')
  .then(r => r.json())
  .then(data => {
    document.getElementById('bio').textContent = data.bio;
  });
```

### Firefox Multipart Content-Disposition Bypass

**CVE-2024-10461 (Firefox/Thunderbird):** In multipart/x-mixed-replace responses, `Content-Disposition: attachment` was not respected and did not force a download, allowing XSS. Affects Firefox < 132, Firefox ESR < 128.4, Thunderbird < 128.4 and < 132.

## JSONP Callback Injection

JSONP callback injection occurs when the server echoes the `callback` or `jsonp` parameter into a `application/javascript` response without validating it as a legal JavaScript identifier.

### Recent JSONP CVEs

**CVE-2025-15144 (XunRuiCMS):** Reflected XSS in JSONP error handlers via `dr_show_error` and `dr_exit_msg` functions. Endpoints echo the callback request parameter directly into the HTTP response. Exploit is public.

**GHSA-6mp4-q625-mxjp (YOURLS):** The `callback` and `jsonp` parameters are concatenated into output unsanitized. With public API mode enabled, any unauthenticated attacker can exploit it. Even in private mode, the payload is injected into the 403 response body.

**CVE-2026-42548 (Flight PHP):** The `?jsonp=` value is not validated as a legal JavaScript identifier. Fixed in 3.18.1. CVSS 4.0 score: 8.6.

**CVE-2026-49294 (Valhalla routing engine):** Affects 3.6.3 and earlier, unfixed at publication. Injected script runs in the serving origin, enabling session token theft. CVSS 6.1.

**CVE-2024-29882 (SRS video server):** JSONP callback injection. Fixed in versions 5.0.210 and 6.0.121.

### JSONP Injection Patterns

```javascript
// VULNERABLE: No callback validation
app.get('/api/data', (req, res) => {
  const callback = req.query.callback;
  const data = JSON.stringify({users: getUsers()});
  res.type('application/javascript');
  res.send(`${callback}(${data})`);
  // Payload: ?callback=alert(document.cookie)//
  // Result: alert(document.cookie)//({users: [...]})
});

// SAFE: Validate callback as JavaScript identifier
app.get('/api/data', (req, res) => {
  const callback = req.query.callback;
  if (!/^[$_a-zA-Z][$_a-zA-Z0-9]*$/.test(callback)) {
    return res.status(400).json({error: 'Invalid callback'});
  }
  const data = JSON.stringify({users: getUsers()});
  res.type('application/javascript');
  res.send(`${callback}(${data})`);
});
```

### CORS Misconfiguration Amplifying JSONP

A CORS misconfiguration where an API trusts wildcard subdomains (e.g., `*.target.com`) allows XSS on any subdomain to make credentialed requests to the API. SameSite cookies are sent because subdomains are same-site.

**CVE-2024-8024 (QAnything):** CORS misconfiguration in netease-youdao/qanything 1.4.1 allows an attacker to bypass Same-Origin Policy. CVSS 7.5.

## API Response Reflection Vectors

### FastAPI/Cadwyn Version Parameter XSS

**CVE-2025-53528 (Cadwyn):** FastAPI framework reflected the `version` parameter of the `/docs` endpoint without sanitization in versions before 5.4.3, enabling one-click XSS against any application built on Cadwyn.

### NesterSoft WorkTime API

**CVE-2025-15562:** API endpoint `/report/internet/urls` reflects received data into the HTML response without encoding or filtering. Vendor unresponsive as of February 2026.

## SVG/XML Content-Type Confusion

SVG/XML uploaded content is the most common Content-Type confusion vector. SVG files can contain inline JavaScript (`<script>` tags or event handlers) and are often served with permissive MIME types.

**CVE-2026-56670 (ComfyUI):** The `/view` endpoint stored and served uploaded SVG/XML content inline due to missing handling for `image/svg+xml` and related XML content types, enabling stored XSS. Fixed in 0.28.0.

## Testing Methodology

1. **Check Content-Type headers** on all API responses, including error responses
2. **Test for X-Content-Type-Options: nosniff** absence on every response
3. **Identify JSONP endpoints** and test callback parameter validation
4. **Upload HTML/SVG files** through file upload endpoints and check how they are served
5. **Test client-side rendering** of API responses -- search for innerHTML, dangerouslySetInnerHTML, v-html
6. **Check error responses** for reflected user input with incorrect Content-Type
7. **Test CORS configuration** for overly permissive origins

## Bug Bounty Tips

1. JSONP endpoints continue to be shipped in 2025-2026 despite CORS being widely available
2. Content-Type confusion via SVG/XML uploads is the most common vector in 2024-2026
3. Client-side DOM XSS from API responses is a growing vector that Content-Type headers alone cannot prevent
4. Parse Server has had multiple Content-Type bypass CVEs in 2026 -- check for allowlist vs blocklist approaches
5. Always test API error responses for reflected input with `text/html` Content-Type
6. CORS misconfigurations on APIs can amplify JSONP and other XSS issues by allowing cross-origin credential leakage
7. The `nosniff` header is the primary server-side defense -- its absence is always worth reporting
