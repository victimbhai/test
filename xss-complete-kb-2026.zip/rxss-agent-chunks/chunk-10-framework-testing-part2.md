# Agent Chunk 10: Framework-Specific Testing Part 2 (HTMX, Alpine, Solid, Qwik, Comparison)

**Agent Task:** Identify reflected XSS risks in HTMX, Alpine.js, SolidJS, and Qwik. Unlike the frameworks in Part 1, HTMX and Alpine.js provide NO auto-escaping — all security is the server's responsibility. Use the comparison matrix to quickly assess any target's framework risk profile.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 19. Framework-Specific Research (Part 2)

### 19.6 HTMX

**Default safety**: HTMX itself performs NO output encoding — it relies entirely on server-side template engines for escaping. HTMX swaps server-rendered HTML fragments directly into the DOM.

**XSS-relevant features**:
- `hx-on` — evaluates arbitrary JavaScript. Can be disabled but is enabled by default.
- HTMX swaps use `innerHTML`-equivalent operations by default
- All dynamic content in HTMX responses MUST be escaped by the server
- HTMX does not play well with strict CSP policies (no `unsafe-inline` or `unsafe-eval`)
- `htmx.config.allowEval` controls whether `hx-on`, `hx-vals`, and `hx-headers` with `javascript:` prefix are allowed

**Security model**: "HTMX is not a security tool. It is a tool for building web applications." (htmx.org) The security responsibility is entirely on the server-side template engine.

**Source**: htmx.org security essay, HackerNews discussions, Deepwiki htmx security analysis.

### 19.7 Alpine.js

**Default safety**: Alpine.js evaluates JavaScript expressions directly from HTML attributes (`x-data`, `x-bind`, `x-on`, `x-html`).

**XSS-relevant features**:
- `x-html` — renders raw HTML, equivalent to `innerHTML`
- `x-bind` with user-controlled values — can inject event handlers
- `x-on` — evaluates JavaScript from HTML attributes
- Alpine.js attributes are evaluated as JavaScript, similar to `eval()`

**Security concern**: Like HTMX, Alpine.js places security responsibility on the server. Any user input reflected into Alpine.js attributes without encoding is potentially executable.

**Evidence quality**: INFERENCE — the local corpus has minimal Alpine.js coverage. This analysis is based on Alpine.js documentation and general DOM XSS principles.

### 19.8 SolidJS

**Default safety**: SolidJS uses JSX with automatic HTML escaping for expressions, similar to React.

**Dangerous escape hatches**:
- `innerHTML` prop — renders raw HTML
- Dynamic `<script>` creation via JSX
- Server-side rendering with `renderToString`/`renderToStream` — serialized state may contain reflected values

**Evidence quality**: INFERENCE — the local corpus has no SolidJS-specific content. Analysis based on SolidJS documentation and JSX framework security patterns.

### 19.9 Qwik

**Default safety**: Qwik uses JSX with automatic HTML escaping. Its resumability model serializes component state into HTML attributes.

**Dangerous escape hatches**:
- `dangerouslySetInnerHTML` — same as React's escape hatch
- Serialized state in HTML — Qwik serializes component state into `q:` attributes and inline `<script>` tags for resumability. If user input enters this serialized state without proper encoding, injection may be possible.

**Evidence quality**: INFERENCE — the local corpus has no Qwik-specific content. Analysis based on Qwik documentation and general framework security patterns.

### 19.10 Framework Comparison Matrix

| Framework | Auto-Escape | Raw HTML Primitive | SSR Hydration Risk | CSP Compatibility | Trusted Types | Evidence Quality |
|---|---|---|---|---|---|---|
| React/Next.js | Yes (JSX) | `dangerouslySetInnerHTML` | `__NEXT_DATA__` (JSON, generally safe) | Good (with nonce) | Partial | PRIMARY-EXTERNAL |
| Vue/Nuxt | Yes (`{{ }}`) | `v-html` | `__NUXT__` (Nuxt 2: executable JS) | Good (with nonce) | Partial | PRIMARY-EXTERNAL |
| Angular | Yes + DomSanitizer | `bypassSecurityTrust*` | Angular Universal | Good (with nonce) | Partial | PRIMARY-EXTERNAL |
| Svelte/SvelteKit | Yes (`{ }`) | `{@html}` | Serialized in script tags | Good | Limited | SECONDARY-EXTERNAL |
| Astro | Yes (`.astro`) | `set:html` | Server islands (CVE-2025-64764) | Good | Limited | PRIMARY-EXTERNAL |
| HTMX | **NO** (server responsibility) | All output is raw HTML | N/A (no client hydration) | **Poor** (needs eval) | **None** | SECONDARY-EXTERNAL |
| Alpine.js | **NO** (server responsibility) | `x-html` | N/A | **Poor** (needs eval) | **None** | INFERENCE |
| SolidJS | Yes (JSX) | `innerHTML` prop | Serialized state | Good | Limited | INFERENCE |
| Qwik | Yes (JSX) | `dangerouslySetInnerHTML` | Resumable state serialization | Good | Limited | INFERENCE |

### Agent Quick Reference: Framework Detection

When analyzing a target, look for these indicators to identify the framework:

| Indicator | Framework |
|---|---|
| `__NEXT_DATA__` in page source | Next.js |
| `__NUXT__` or `__NUXT_DATA__` in page source | Nuxt |
| `ng-version` attribute on root element | Angular |
| `data-svelte-h` attributes | SvelteKit |
| `data-astro-*` attributes | Astro |
| `hx-*` attributes on elements | HTMX |
| `x-data`, `x-bind` attributes | Alpine.js |
| `_$HY` or `data-hk` attributes | SolidJS |
| `q:container` attribute on root element | Qwik |
| `data-reactroot` or `__reactFiber$` properties | React |

---

*Next chunk: chunk-11-sanitization-csp-defenses.md*
