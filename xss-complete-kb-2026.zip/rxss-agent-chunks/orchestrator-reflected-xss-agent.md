# Reflected XSS Master Orchestrator Agent

**Purpose:** Coordinate all 20 chunk agents for continuous reflected XSS vulnerability discovery and testing on authorized targets in an isolated local laboratory environment.

## SAFETY CONSTRAINTS — MANDATORY FOR ALL OPERATIONS

```
STOP — READ BEFORE ANY ACTION:
- Do NOT test public applications
- Do NOT send requests to third-party targets
- Do NOT execute repository tools, scripts, or Nuclei templates
- Do NOT reproduce credential-stealing, session-stealing, phishing, keylogging, or persistence code
- Do NOT compile a weaponized payload or WAF-bypass library
- Use ONLY abstract placeholders:
    [UNIQUE_REFLECTION_MARKER]
    [HARMLESS_EXECUTION_MARKER]
    [CONTEXT_SPECIFIC_TEST_VALUE]
    [NEGATIVE_CONTROL]
    [ENCODED_VARIANT]
    [CONTROLLED_PARAMETER]
- Any browser-execution example MUST be limited to an isolated local laboratory
  and a harmless visible or console marker
```

---

## Chunk Agent Index

| Chunk | File | Agent Task | Sections Covered |
|---|---|---|---|
| 01 | `chunk-01-scope-definitions-classification.md` | Learn what reflected XSS is and is not; classify findings correctly | §1–2 |
| 02 | `chunk-02-source-inventory-evidence-quality.md` | Assess source quality and evidence grades before trusting any claim | §3–5 |
| 03 | `chunk-03-request-pipeline-input-sources.md` | Map the full request-to-browser pipeline; identify all input sources | §6–7 |
| 04 | `chunk-04-browser-parsing-decoding.md` | Understand browser parsing contexts and the triple-layer decoding model | §8–9 |
| 05 | `chunk-05-html-attribute-context-testing.md` | Test HTML-context and attribute-context reflected XSS vectors | §10–11 |
| 06 | `chunk-06-javascript-url-json-context.md` | Test JavaScript-context, URL-context, and JSON/hydration reflected XSS | §12–14 |
| 07 | `chunk-07-special-contexts-headers-errors.md` | Test special parser contexts, header reflection, and error page XSS | §15–16 |
| 08 | `chunk-08-oauth-apidocs-testing.md` | Test OAuth callback XSS and API documentation (Swagger UI) XSS | §17–18 |
| 09 | `chunk-09-framework-testing-part1.md` | Test React/Next.js, Vue/Nuxt, Angular, Svelte, Astro escape hatches | §19.1–19.5 |
| 10 | `chunk-10-framework-testing-part2.md` | Test HTMX, Alpine.js, SolidJS, Qwik; use framework detection matrix | §19.6–19.10 |
| 11 | `chunk-11-sanitization-csp-defenses.md` | Evaluate sanitization, CSP, Trusted Types, and browser defenses | §20–21 |
| 12 | `chunk-12-lab-methodology.md` | Follow the 11-step safe lab methodology for every test | §22 |
| 13 | `chunk-13-attack-vector-cards.md` | Use the 8 structured attack-vector cards as test templates | §23 |
| 14 | `chunk-14-false-positive-evidence-severity.md` | Eliminate false positives; classify and rate confirmed findings | §24–25 |
| 15 | `chunk-15-remediation-legacy-gaps.md` | Apply correct remediation; check legacy matrix; understand evidence gaps | §26–28 |
| 16 | `chunk-16-research-hypotheses.md` | Prioritize investigation using the 7 research hypotheses | §29 |
| 17 | `chunk-17-references-bibliography.md` | Trace claims to sources; verify evidence quality | §30–34 |
| 18 | `chunk-18-root-cause-browser-analysis.md` | Classify root causes (RC-1 to RC-8); check browser parser differentials | §35–36 |
| 19 | `chunk-19-source-sink-transformation.md` | Map source-to-sink data flows; use reflection-context matrix | §37–38 |
| 20 | `chunk-20-dompurify-cve-confidence-resume.md` | Check DOMPurify versions, CVE timeline, confidence levels, and resume points | §39–42 |

---

## Orchestration Workflow

### Phase 1: Reconnaissance (Read chunks 01–04)

**Goal:** Understand the target's technology stack and input surfaces.

1. **Read chunk-01** → Internalize reflected XSS definition and classification rules
2. **Read chunk-02** → Understand evidence quality tiers to grade every finding
3. **Read chunk-03** → Map all input sources on the target (query params, POST fields, headers, cookies, path segments, JSON bodies)
4. **Read chunk-04** → Identify which browser parsing contexts are present on the target

**Output:** Target input-source inventory and browser-context map

### Phase 2: Framework & Defense Identification (Read chunks 09–11)

**Goal:** Identify the target's framework, sanitization, and CSP posture.

5. **Read chunk-09** → Check if target uses React, Vue, Angular, Svelte, or Astro
6. **Read chunk-10** → Check if target uses HTMX, Alpine.js, SolidJS, or Qwik; use detection matrix
7. **Read chunk-11** → Evaluate target's sanitization approach, CSP headers, and Trusted Types deployment

**Output:** Framework identification, escape-hatch inventory, defense posture assessment

### Phase 3: Context-Specific Testing (Read chunks 05–08)

**Goal:** Test each reflection point against its specific context.

8. **Read chunk-05** → Test HTML-context and attribute-context reflections
9. **Read chunk-06** → Test JavaScript-context, URL-context, and JSON/hydration reflections
10. **Read chunk-07** → Test special parser contexts (comments, RCDATA, SVG/MathML) and header/error page reflections
11. **Read chunk-08** → Test OAuth callback endpoints and API documentation endpoints

**Output:** Per-context reflection analysis results

### Phase 4: Structured Testing (Read chunks 12–13)

**Goal:** Execute formal lab methodology using attack-vector cards.

12. **Read chunk-12** → Follow the 11-step lab methodology for each candidate reflection
13. **Read chunk-13** → Match each reflection against the 8 attack-vector cards (RXSS-01 through RXSS-08)

**Output:** Structured test results per vector card

### Phase 5: Validation & Classification (Read chunks 14, 18)

**Goal:** Eliminate false positives, classify root causes, and rate severity.

14. **Read chunk-14** → Run every candidate through the false-positive decision tree
15. **Read chunk-18** → Classify each confirmed finding by root cause (RC-1 through RC-8)

**Output:** Validated findings with root-cause classification and severity rating

### Phase 6: Source-to-Sink Verification (Read chunk 19)

**Goal:** Trace the complete data flow for each confirmed finding.

16. **Read chunk-19** → Map the full source-to-sink path using framework-specific patterns; verify against the reflection-context matrix

**Output:** Complete data-flow documentation for each finding

### Phase 7: Remediation & Reporting (Read chunks 15, 16, 17, 20)

**Goal:** Provide actionable remediation and prioritize further research.

17. **Read chunk-15** → Select context-specific remediation; generate regression test; check legacy matrix
18. **Read chunk-16** → Compare findings against research hypotheses; identify areas for deeper investigation
19. **Read chunk-17** → Cross-reference findings against bibliography and source references
20. **Read chunk-20** → Verify DOMPurify version-specific issues; check confidence levels; record resume checkpoint

**Output:** Final report with remediation, regression tests, and research continuation plan

---

## Continuous Testing Loop

After completing all 7 phases, restart from Phase 1 with:

1. **New input sources** discovered during testing
2. **Updated framework versions** (check for new CVEs in chunk-20)
3. **Newly discovered endpoints** not covered in the initial reconnaissance
4. **Error paths** and **edge cases** identified during testing
5. **POST method variants** of GET-tested endpoints

```
CONTINUOUS LOOP:
┌─────────────────────────────────────────────┐
│  Phase 1: Reconnaissance (chunks 01-04)     │
│  Phase 2: Framework ID (chunks 09-11)       │
│  Phase 3: Context Testing (chunks 05-08)    │
│  Phase 4: Structured Testing (chunks 12-13) │
│  Phase 5: Validation (chunks 14, 18)        │
│  Phase 6: Source-to-Sink (chunk 19)         │
│  Phase 7: Remediation (chunks 15-17, 20)    │
│                                             │
│  ──► Discover new surfaces ──► Loop back ◄──│
└─────────────────────────────────────────────┘
```

---

## Finding Report Template

For each confirmed reflected XSS finding, produce a report with:

```
FINDING REPORT
==============
Finding ID: [RXSS-YYYY-MM-DD-NNN]
Date: [Date of discovery]
Classification: [CONFIRMED LAB / LIKELY / POTENTIAL]

TARGET
------
Endpoint: [URL pattern]
HTTP Method: [GET/POST]
Framework: [Identified framework and version]
Input Source: [Query param / POST field / Header / etc.]

REFLECTION ANALYSIS
-------------------
Reflection Location: [Where in response the value appears]
Browser Context: [HTML data / Attribute / JS string / URL / JSON]
Transformations: [Encoding/decoding chain from request to response]
Root Cause: [RC-1 through RC-8 classification]

EVIDENCE
--------
Controlled Request: [The exact HTTP request]
Unique Marker: [UNIQUE_REFLECTION_MARKER value used]
Raw Response: [Response excerpt showing reflection]
Browser Execution: [Console/DOM evidence from isolated lab]
Negative Control: [Same request with proper encoding → no execution]
Browser/Version: [Exact browser name and version tested]
CSP State: [CSP policy present/absent, bypass possible?]

FALSE-POSITIVE CHECKS
---------------------
□ HTML-entity encoding check: [PASS/FAIL]
□ Content-Type check: [PASS/FAIL]
□ Text-only rendering check: [PASS/FAIL]
□ CSP blocking check: [PASS/FAIL]
□ Self-XSS check: [PASS/FAIL]
□ Legacy browser check: [PASS/FAIL]

SEVERITY
--------
CVSS 3.1 Score: [Calculated score]
Vector: [CVSS vector string]
Severity Factors: [What increases/decreases severity]
Evidence Grade: [PRIMARY-LOCAL / PRIMARY-EXTERNAL / etc.]
Confidence: [HIGH / MEDIUM / LOW]

REMEDIATION
-----------
Primary Fix: [Context-specific encoding function]
Defense in Depth: [CSP / Trusted Types / Cookie flags]
Regression Test: [Test case using regression template from chunk-15]

REFERENCES
----------
Attack Vector Card: [RXSS-01 through RXSS-08]
Root Cause: [RC-1 through RC-8]
Related CVEs: [If applicable]
Chunk Sources: [Which chunks were used]
```

---

## Quick-Reference: Which Chunk to Read

| When you need to... | Read chunk... |
|---|---|
| Understand what counts as reflected XSS | 01 |
| Grade evidence quality | 02 |
| Find all input sources | 03 |
| Understand browser parsing | 04 |
| Test HTML or attribute context | 05 |
| Test JS, URL, or JSON context | 06 |
| Test special contexts or error pages | 07 |
| Test OAuth or Swagger UI | 08 |
| Identify React/Vue/Angular/Svelte/Astro | 09 |
| Identify HTMX/Alpine/Solid/Qwik | 10 |
| Evaluate sanitization and CSP | 11 |
| Follow lab methodology | 12 |
| Use attack-vector card templates | 13 |
| Filter false positives | 14 |
| Apply remediation | 15 |
| Prioritize research areas | 16 |
| Trace a claim to its source | 17 |
| Classify root cause | 18 |
| Map source-to-sink data flow | 19 |
| Check DOMPurify / CVEs / confidence | 20 |

---

*This orchestrator coordinates research-only testing in isolated local laboratories. No live applications are tested. No weaponized payloads are produced. All findings use abstract placeholders.*
