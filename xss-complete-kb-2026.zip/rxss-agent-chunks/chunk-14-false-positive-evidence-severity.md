# Agent Chunk 14: False-Positive Filtering & Evidence/Severity Standards

**Agent Task:** Use the false-positive decision tree to eliminate non-exploitable reflections before reporting. Apply the evidence standard to classify findings. Use the severity assessment to rate confirmed cases accurately without inflation.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 24. False-Positive Decision Tree

```
REFLECTED VALUE FOUND IN RESPONSE
│
├── Is the value HTML-entity-encoded? (&lt; for <, &gt; for >, etc.)
│   └── YES → Check: Is encoding complete for the specific context?
│       ├── YES → FALSE POSITIVE: Safely encoded reflection
│       └── NO → Continue analysis (partial encoding may be bypassable)
│
├── Does the value appear ONLY as text content (textContent/innerText equivalent)?
│   └── YES → FALSE POSITIVE: Text-only rendering
│
├── Does the response Content-Type indicate non-HTML? (application/json, text/plain)
│   ├── YES → Is X-Content-Type-Options: nosniff present?
│   │   ├── YES → FALSE POSITIVE: Browser will not render as HTML
│   │   └── NO → POTENTIAL: MIME sniffing may render as HTML (legacy browsers)
│   └── NO → Continue analysis
│
├── Is the response served with Content-Disposition: attachment?
│   └── YES → FALSE POSITIVE: Browser downloads rather than renders
│
├── Does execution require DOM manipulation (DevTools, console, browser extension)?
│   └── YES → FALSE POSITIVE: Not a realistic attack scenario
│
├── Is the value inside an inert context? (<template>, HTML comment, PLAINTEXT)
│   └── YES → Is there a path to escape the inert context?
│       ├── YES → Continue analysis (potential escape)
│       └── NO → FALSE POSITIVE: Inert context
│
├── Does CSP block inline script execution?
│   ├── YES → Is there a CSP bypass path?
│   │   ├── YES → Continue analysis (CSP bypass + reflection = XSS)
│   │   └── NO → DOWNGRADE: Injection flaw exists but execution blocked
│   │       └── Note: Still warrants remediation (defense-in-depth)
│   └── NO → Continue analysis
│
├── Is the issue actually STORED, PURE DOM, or SELF-XSS?
│   ├── STORED → OUT OF SCOPE: Value persists beyond the immediate response
│   ├── PURE DOM → OUT OF SCOPE: No server reflection involved
│   ├── SELF-XSS → FALSE POSITIVE: No realistic delivery path
│   └── REFLECTED → Continue analysis
│
├── Does the issue require an obsolete browser? (IE, old Safari, pre-Chrome 78)
│   └── YES → LEGACY ONLY: Not applicable to current browsers
│
├── Is reflection detected by an automated scanner without browser execution proof?
│   └── YES → POTENTIAL only until browser execution is confirmed
│       └── Scanner reflection ≠ XSS
│
├── Does a WAF block page reflect the value on a different origin?
│   └── YES → FALSE POSITIVE: Execution occurs on WAF's origin, not application's
│
└── ALL CHECKS PASSED → CONFIRMED or LIKELY reflected XSS
    └── Classification depends on whether browser execution was demonstrated
```

### Discriminating Lab Tests for Common False Positives

| False Positive Class | Discriminating Test |
|---|---|
| HTML-encoded reflection | Submit `[MARKER]<img>` → check response for `&lt;img&gt;` (encoded) vs `<img>` (raw) |
| Text-only rendering | Inspect DOM → check if reflected value is in a Text node vs Element |
| JSON response | Check `Content-Type` header; verify no HTML rendering of JSON |
| CSP-blocked execution | Check CSP header; remove CSP in local lab → does execution occur? |
| Self-XSS | Can the test URL be sent to another user who sees execution? |
| Scanner false positive | Open the URL in a real browser → does execution actually occur? |
| Inert context | Attempt to escape the context (inject `-->`, `</template>`, `</textarea>`) |

---

## 25. Evidence and Severity Standard

### 25.1 Confirmed Reflected XSS Laboratory Case Requirements

A confirmed case requires ALL of the following:

| Evidence Element | Description |
|---|---|
| Controlled request | The exact HTTP request with the injected value |
| Unique marker | A unique, inert identifier proving the reflected value is the one tested |
| Raw response | The complete HTTP response (headers + body) showing the reflection |
| Exact reflection location | Byte offset and surrounding context in the response body |
| Browser parsing context | The HTML5 tokenizer state and DOM position at the reflection point |
| Transformation chain | Every encoding, decoding, and transformation between request and response |
| Harmless execution proof | Console output, DOM change, or visible marker in isolated local browser |
| Browser/version | Exact browser name, version, and engine |
| CSP and sandbox state | The CSP policy (if any) and iframe sandbox attributes |
| Realistic delivery model | How a victim would be induced to trigger the vulnerable request |
| Negative control | Same request with proper encoding → no execution |
| Post-fix result | Same request after remediation → no execution |

### 25.2 Research Conclusion Classifications

| Classification | Definition | Action |
|---|---|---|
| **CONFIRMED LAB** | Reproducible harmless execution in an isolated browser | Report with full evidence |
| **LIKELY** | Strong source-to-sink evidence but no browser execution fixture | Document with TRACE GAP markers |
| **POTENTIAL** | Reflection or dangerous code pattern observed | Investigate further before reporting |
| **FALSE POSITIVE** | Safely rendered, unreachable, or non-executing | Document reason for rejection |
| **LEGACY ONLY** | Requires obsolete browser or framework behavior | Label clearly; do not present as current |
| **UNKNOWN** | Insufficient evidence to classify | Identify minimum evidence needed to resolve |

### 25.3 Severity Assessment

**CVSS 3.1 baseline for reflected XSS**: 6.1 (Medium) — `AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N`

| Factor | Increases Severity | Decreases Severity |
|---|---|---|
| Authentication context | Execution on authenticated page | Execution on public page only |
| CSP | No CSP or weak CSP | Strict CSP blocks execution |
| Cookie flags | No `HttpOnly` on session cookie | `HttpOnly` prevents cookie theft |
| Same-site context | `SameSite=None` cookies sent | `SameSite=Lax` limits cross-site delivery |
| Delivery | No interaction (auto-fire via onload) | Requires specific user action |
| Chaining | + Cache poisoning = stored XSS | Standalone reflected only |
| Framework | Error page outside framework protections | Within framework auto-escaping |

**Do NOT inflate severity based on hypothetical worst-case outcomes.** Separate demonstrated impact from theoretical maximum.

---

*Next chunk: chunk-15-remediation-legacy-gaps.md*
