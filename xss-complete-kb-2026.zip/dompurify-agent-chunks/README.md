# DOMPurify XSS Agent Chunks — Splitter Script

This directory will contain 21 agent-ready chunks split from the main research document.

Run the splitter script below to create all chunks:

```bash
python3 splitter.py
```

This creates files 01-21, each named by agent task purpose.
