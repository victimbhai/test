# Agent Chunk 06: JavaScript, URL & JSON Context Testing

**Agent Task:** Test for reflected XSS in JavaScript string contexts, URL-bearing attributes, and inline JSON/hydration data. Understand script block termination, template literal injection, JSONP callbacks, and SSR hydration risks.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 12. JavaScript-Context Reflected XSS

### 12.1 String Literal Breakout

When a reflected value appears inside a JavaScript string:
```html
<script>var search = '[REFLECTED]';</script>
```

**Attack principle**: Close the string delimiter and inject executable code.

**Abstract test model**:
```
Request: ?q=[UNIQUE_REFLECTION_MARKER]
Response: <script>var q = '[UNIQUE_REFLECTION_MARKER]';</script>

Test: ?q=[CONTEXT_SPECIFIC_TEST_VALUE]
where the value terminates the string and introduces a new statement

Lab assertion: Console marker appears in browser console
Negative control: Same with ' escaped to \' -> string contains literal \'
```

**Backslash-escaping bypass**: If the application escapes `'` to `\'` but does not escape `\`:
```
Input: \' ; [HARMLESS_EXECUTION_MARKER] ; //
After escaping: \\' ; [HARMLESS_EXECUTION_MARKER] ; //
Result: The \\ becomes a literal backslash, the ' terminates the string
```

### 12.2 Template Literal Injection

When a reflected value appears inside a JavaScript template literal:
```html
<script>var msg = `Hello ${user}, your search for [REFLECTED] returned 0 results`;</script>
```

**Attack principle**: Inject `${...}` to execute arbitrary expressions within the template literal. No string termination is needed.

### 12.3 Script Block Termination

Regardless of JavaScript string context, the HTML parser treats `</script>` as the end of the script block. The HTML parser operates before the JavaScript engine:

If `[REFLECTED]` contains `</script>`, the browser terminates the script block at that point. Everything after `</script>` is parsed as HTML, allowing tag injection.

**This means JavaScript string escaping alone is insufficient.** The sequence `</script>` must also be prevented, typically by encoding `<` as `\x3C` or `<` within JavaScript strings, or by splitting: `<\/script>`.

### 12.4 JSONP Callback Injection

JSONP endpoints reflect a callback parameter name in the response:
```
Request: /api/data?callback=[REFLECTED]
Response: [REFLECTED]({"data":"value"})
```

If the callback parameter is not strictly validated (alphanumeric + dots only), an attacker can inject executable JavaScript.

**Note**: JSONP is a legacy pattern largely superseded by CORS. However, it persists in older APIs and some CDN configurations.

### 12.5 Inline JSON and Hydration Data

Many applications embed JSON data in `<script>` tags for client-side initialization:
```html
<script>window.__CONFIG__ = {"query":"[REFLECTED]","page":1};</script>
```

**Risk**: If the reflected value contains `</script>`, it terminates the script block. If it contains unescaped `"`, it breaks the JSON structure. The value must be JSON-encoded AND the `</script>` sequence must be prevented.

**Framework-specific hydration data** (see Section 14 for detail):
- Next.js: `<script id="__NEXT_DATA__" type="application/json">`
- Nuxt: `<script>window.__NUXT__={...}</script>`
- SvelteKit: Inline `<script>` with serialized data

---

## 13. URL-Context Reflected XSS

### 13.1 Protocol-Based Injection

When a reflected value controls the URL in a link, image source, or form action:
```html
<a href="[REFLECTED]">Link</a>
```

The primary risk is the `javascript:` pseudo-protocol. Modern browser behavior:

| Browser | `javascript:` in href | `javascript:` in src (img) | `javascript:` in iframe src |
|---|---|---|---|
| Chrome | Executes on click | Blocked | Executes |
| Firefox | Executes on click | Blocked | Executes |
| Safari | Executes on click | Blocked | Executes |

**Defense**: Validate that URLs start with `https://` or `http://` (or another allowed scheme). Blocklisting `javascript:` is fragile due to encoding bypasses (tab/newline insertion, entity encoding).

### 13.2 URL Parameter Injection

When a reflected value appears as a parameter within a URL:
```html
<a href="/page?redirect=[REFLECTED]">Continue</a>
```

If the value is not URL-encoded, an attacker may inject characters that break out of the parameter context:
- `"` to close the attribute
- `>` to close the tag
- Additional attributes or tags

### 13.3 Base URL Manipulation

If a reflected value controls the `<base href="[REFLECTED]">` element, all relative URLs on the page resolve against the attacker-controlled base. This can redirect script loads, form submissions, and link navigations to attacker-controlled domains.

---

## 14. JSON and Hydration Reflected XSS

### 14.1 JSON Response Rendered as HTML

When a JSON API response is served with `Content-Type: application/json`, browsers do not render it as HTML, so XSS is not possible through the JSON itself. However, reflected XSS can occur when:

1. **Missing or incorrect Content-Type**: The response is served as `text/html` despite containing JSON
2. **MIME sniffing**: Without `X-Content-Type-Options: nosniff`, older browsers may sniff the content as HTML
3. **JSON embedded in HTML**: JSON values are interpolated into an HTML template or `<script>` tag
4. **Client-side rendering**: JavaScript fetches JSON and inserts values into the DOM via `innerHTML`

### 14.2 GraphQL Error Reflection

GraphQL endpoints may reflect user input in error messages:
```json
{"errors":[{"message":"Unknown field '[REFLECTED]' on type 'Query'"}]}
```

If the GraphQL error response is rendered in an HTML context (e.g., a custom error page), the reflected value may be exploitable. Risk increases when:
- Error pages use different templates from normal pages
- Error templates lack auto-escaping
- GraphQL introspection errors reflect query fragments

### 14.3 SSR Hydration Data

#### Next.js (`__NEXT_DATA__`)

Next.js embeds page data in a JSON `<script>` tag:
```html
<script id="__NEXT_DATA__" type="application/json">
  {"props":{"pageProps":{"query":"[REFLECTED]"}}}
</script>
```

**Security analysis**:
- `type="application/json"` means the browser does NOT execute this as JavaScript -- it is treated as data
- Next.js JSON-serializes the data, encoding `<`, `>`, and `&` as Unicode escapes
- Primary risk: if `__NEXT_DATA__` is read by client-side JavaScript and values are inserted via `innerHTML` without sanitization, a hybrid reflected/DOM XSS can occur

#### Nuxt (`__NUXT__`)

Nuxt 2 embeds hydration data as executable JavaScript:
```html
<script>window.__NUXT__={data:[{query:"[REFLECTED]"}]}</script>
```

Unlike Next.js, this IS executed as JavaScript. If the reflected value is not properly JavaScript-encoded, breakout is possible. Nuxt 3 uses a safer serialization mechanism.

**CVE-2026-46342**: Nuxt Nitro Server XSS vulnerability (published 2026-05-20).

---

*Next chunk: chunk-07-special-contexts-headers-errors.md*
