# Agent Chunk 16: Prioritized Research Hypotheses

**Agent Task:** Use these 7 research hypotheses to guide investigation priorities. Each hypothesis identifies a specific area where reflected XSS vulnerabilities are expected based on evidence patterns. Pursue CRITICAL and HIGH priorities first. Design lab experiments following the approaches described.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 29. Prioritized Reflected-XSS Research Hypotheses

### Hypothesis 1: SSR Hydration Data Injection (Priority: CRITICAL)

**Claim**: Modern SSR frameworks (Next.js, Nuxt, SvelteKit, Astro, Remix) serialize server-side data into inline `<script>` tags, creating reflected XSS surfaces when user input enters the serialized state.

**Evidence**: KB-44 claims this but provides no citations. CVE-2025-64764 (Astro server islands) and CVE-2026-46342 (Nuxt Nitro) confirm the pattern. Next.js's `type="application/json"` and Unicode escaping mitigate direct execution but may not prevent all attack scenarios.

**Research needed**: Version-specific testing of serialization safety in Next.js 14/15, Nuxt 3, SvelteKit 2, Remix 2, and Astro 5. Focus on `</script>` prevention and JSON encoding completeness.

**Lab approach**: Create local instances of each framework, reflect user input through data loading functions, verify serialization encoding in the HTML output.

### Hypothesis 2: Post-Sanitization DOM Mutation in Modern Browsers (Priority: HIGH)

**Claim**: DOMPurify's sanitized output can mutate when reparsed by the browser, particularly in namespace-crossing scenarios (HTML ↔ SVG ↔ MathML).

**Evidence**: DOMPurify bypass history documents multiple mXSS CVEs through 2026. The CVE-2026-47423 `<selectedcontent>` bypass demonstrates that new browser features can invalidate sanitizer assumptions.

**Research needed**: Test DOMPurify 3.4.9 (latest) against Chrome 130+, Firefox, and Safari with namespace-crossing inputs. Focus on new HTML features that may cause post-sanitization mutation.

**Lab approach**: Create a local page that sanitizes input with DOMPurify and inserts via innerHTML, then inspect the resulting DOM for structural differences from the sanitizer's output.

### Hypothesis 3: HTMX and Alpine.js Fragment Injection (Priority: HIGH)

**Claim**: Applications using HTMX or Alpine.js are vulnerable to reflected XSS through server-rendered HTML fragments that are swapped into the DOM without client-side sanitization.

**Evidence**: HTMX documentation confirms that "all dynamic content must be escaped" by the server. The `hx-on` attribute evaluates arbitrary JavaScript. Alpine.js's `x-html` is equivalent to innerHTML.

**Research needed**: Document the complete XSS surface of HTMX swap operations, `hx-on`, and Alpine.js's `x-html`, `x-bind`, and expression evaluation. Determine CSP compatibility.

**Lab approach**: Create a local HTMX/Alpine.js application, reflect user input through various swap operations and attribute bindings, test with and without CSP.

### Hypothesis 4: WAF Structure-Level Bypass (Priority: MEDIUM)

**Claim**: WAFs can be bypassed not by obfuscating the payload, but by mutating the HTTP request structure (multipart boundaries, Content-Type variations, parameter duplication).

**Evidence**: The WAFFLED paper (2025) demonstrated 1,207 unique bypasses across 4 of 5 tested WAFs using structure-level mutations. Only AWS WAF resisted all tested mutations.

**Research needed**: Determine whether WAFFLED's findings affect reflected XSS specifically, and whether WAF vendors have patched the documented bypasses.

**Lab approach**: Conceptual analysis only — review WAFFLED's published bypass categories and assess their applicability to reflected XSS delivery.

### Hypothesis 5: OAuth/MCP Callback Reflected XSS in Modern Protocols (Priority: MEDIUM)

**Claim**: The pattern of reflected XSS in OAuth callbacks is repeating in newer protocols like MCP (Model Context Protocol) that use similar callback/redirect flows.

**Evidence**: CVE-2025-62800 (FastMCP) and CVE-2026-77272 (MCP Atlassian) demonstrate the same vulnerability pattern in MCP OAuth flows. This suggests a systematic problem in callback handler implementations.

**Research needed**: Analyze the MCP specification's callback handling requirements and compare with OAuth 2.0. Identify common implementation patterns that lead to reflected XSS.

### Hypothesis 6: Framework Error Template Differential Escaping (Priority: MEDIUM)

**Claim**: Framework error templates frequently apply different (or no) escaping compared to the main application templates, creating reflected XSS in error paths.

**Evidence**: KB-35 documents this as a common pattern. The Astro server islands CVE involved a code path that used `markHTMLString` (no escaping). Error pages are often rendered by middleware rather than the application.

**Research needed**: Survey error page rendering in the top 10 web frameworks to identify which apply auto-escaping to error templates by default.

### Hypothesis 7: Prototype Pollution Weakening Sanitizer Configuration (Priority: LOW–MEDIUM)

**Claim**: Prototype pollution vulnerabilities can weaken DOMPurify's configuration, allowing XSS bypasses that would not work against the intended configuration.

**Evidence**: CVE-2026-41238 (DOMPurify 3.0.1–3.3.3) demonstrated that a `|| {}` fallback inherited from `Object.prototype` allowed polluted `tagNameCheck`/`attributeNameCheck` to admit custom elements with event handlers. CVE-2024-45801 combined special nesting with prototype pollution to bypass the depth check.

**Research needed**: Analyze whether current DOMPurify versions (3.4.9) are resistant to all known prototype pollution vectors.

---

*Next chunk: chunk-17-references-bibliography.md*
