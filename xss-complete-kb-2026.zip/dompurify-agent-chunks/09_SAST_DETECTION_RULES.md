# AGENT TASK: Automated SAST Detection - Semgrep, ESLint, CodeQL Rules
# PURPOSE: Deploy static analysis rules for automated DOMPurify vulnerability detection
# PRIORITY: Run for large codebases to automate detection
# INPUTS: Source code repository, Semgrep/ESLint/CodeQL installed
# OUTPUT: SAST scan results, custom rules deployed, findings
# CHAPTERS: 17 (SAST and Code Review)
---

# Chapter 17: DOMPurify-Specific SAST and Code Review

## 17.1 Semgrep Rules for DOMPurify Misuse Detection

### Rule 1: Missing Sanitization on innerHTML/outerHTML/insertAdjacentHTML

```yaml
rules:
  - id: dompurify-missing-sanitization-innerhtml
    patterns:
      - pattern-either:
          - pattern: $EL.innerHTML = $VALUE;
          - pattern: $EL.outerHTML = $VALUE;
          - pattern: $EL.insertAdjacentHTML($POS, $VALUE);
      - pattern-not: $EL.innerHTML = DOMPurify.sanitize(...);
      - pattern-not: $EL.outerHTML = DOMPurify.sanitize(...);
      - pattern-not: $EL.insertAdjacentHTML($POS, DOMPurify.sanitize(...));
      - pattern-not: $EL.innerHTML = "";
      - pattern-not: $EL.innerHTML = '';
      - pattern-not: $EL.outerHTML = "";
      - pattern-not: $EL.outerHTML = '';
    message: >
      Assignment to innerHTML/outerHTML/insertAdjacentHTML without DOMPurify.sanitize().
      If $VALUE contains user-controlled input, this is a potential XSS vulnerability.
      Wrap the value in DOMPurify.sanitize() before assignment.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: MEDIUM
      impact: HIGH
      subcategory: [vuln]
      technology: [browser]
```

### Rule 2: Post-Sanitization String Modification

```yaml
rules:
  - id: dompurify-post-sanitization-modification
    patterns:
      - pattern: |
          $CLEAN = DOMPurify.sanitize(...);
          ...
          $RESULT = $CLEAN.replace(...);
      - pattern: |
          $CLEAN = DOMPurify.sanitize(...);
          ...
          $RESULT = $CLEAN.replaceAll(...);
      - pattern: |
          $CLEAN = DOMPurify.sanitize(...);
          ...
          $RESULT = decodeURIComponent($CLEAN);
      - pattern: |
          $CLEAN = DOMPurify.sanitize(...);
          ...
          $RESULT = $CLEAN + $OTHER;
    message: >
      String modification after DOMPurify.sanitize() can reintroduce XSS vectors.
      DOMPurify's output is safe only as-is. Do not decode, replace, or concatenate
      the sanitized output. Perform all transformations on the input before sanitization.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: HIGH
```

### Rule 3: Dangerous Configuration Options

```yaml
rules:
  - id: dompurify-allow-unknown-protocols
    pattern: |
      DOMPurify.sanitize($INPUT, { ..., ALLOW_UNKNOWN_PROTOCOLS: true, ... })
    message: >
      ALLOW_UNKNOWN_PROTOCOLS: true permits javascript: URIs in href/src/action
      attributes, creating a direct XSS vector. Remove this option or explicitly
      validate URI protocols after sanitization.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: CRITICAL

  - id: dompurify-permissive-custom-element-handling
    patterns:
      - pattern: |
          DOMPurify.sanitize($INPUT, {
            ...,
            CUSTOM_ELEMENT_HANDLING: { ..., tagNameCheck: /.*/, ... },
            ...
          })
      - pattern: |
          DOMPurify.sanitize($INPUT, {
            ...,
            CUSTOM_ELEMENT_HANDLING: { ..., tagNameCheck: () => true, ... },
            ...
          })
    message: >
      Permissive CUSTOM_ELEMENT_HANDLING.tagNameCheck (matches all or always returns true)
      allows any custom element through sanitization. This can be used to inject elements
      that trigger script gadgets in frameworks. Use a specific regex or function.
    languages: [javascript, typescript]
    severity: WARNING
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: HIGH

  - id: dompurify-safe-for-xml-false
    pattern: |
      DOMPurify.sanitize($INPUT, { ..., SAFE_FOR_XML: false, ... })
    message: >
      SAFE_FOR_XML: false disables XML-specific sanitization. If the output is used
      in an XML context (XHTML, SVG documents, SOAP), this can create injection vectors.
      Only set to false when the output will exclusively be used in HTML5 documents.
    languages: [javascript, typescript]
    severity: WARNING
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: MEDIUM
      impact: MEDIUM
```

### Rule 4: Error Fallback Returning Raw Input

```yaml
rules:
  - id: dompurify-error-fallback-raw-input
    patterns:
      - pattern: |
          try {
            $RESULT = DOMPurify.sanitize($INPUT, ...);
          } catch($ERR) {
            $RESULT = $INPUT;
          }
      - pattern: |
          try {
            return DOMPurify.sanitize($INPUT, ...);
          } catch($ERR) {
            return $INPUT;
          }
    message: >
      Error fallback returns raw unsanitized input. If DOMPurify throws an exception
      (e.g., due to malformed input or prototype pollution), the catch block passes
      through the original unsanitized content, creating an XSS bypass. Return an
      empty string or a safe default instead.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: CRITICAL
```

### Rule 5: Caching Sanitized Output

```yaml
rules:
  - id: dompurify-cached-sanitized-output
    patterns:
      - pattern: |
          $CACHE.set($KEY, DOMPurify.sanitize($INPUT, ...));
      - pattern: |
          $CACHE[$KEY] = DOMPurify.sanitize($INPUT, ...);
      - pattern: |
          $MAP.set($KEY, DOMPurify.sanitize(...));
    message: >
      Caching DOMPurify output can serve stale sanitized content after DOMPurify
      is upgraded to fix a vulnerability. The cached output was sanitized by the
      old (vulnerable) version and will be served without re-sanitization.
      Always sanitize at the point of use, never cache sanitized output.
    languages: [javascript, typescript]
    severity: WARNING
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: MEDIUM
      impact: HIGH
```

### Rule 6: Type-Checking Wrapper Bypass

```yaml
rules:
  - id: dompurify-type-check-bypass
    patterns:
      - pattern: |
          if (typeof $INPUT !== 'string') {
            return $INPUT;
          }
          ... DOMPurify.sanitize($INPUT, ...) ...
      - pattern: |
          if (typeof $INPUT !== 'string') return $INPUT;
          ... DOMPurify.sanitize(...) ...
    message: >
      Type-checking bypass: non-string input is returned unsanitized. Attackers can
      pass objects with toString() methods that return malicious HTML, or pass
      TrustedHTML objects that bypass the type check. Always convert to string and
      sanitize regardless of input type.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: HIGH
```

### Rule 7: Config Spread Operator Override

```yaml
rules:
  - id: dompurify-config-spread-override
    patterns:
      - pattern: |
          DOMPurify.sanitize($INPUT, { ...$BASE_CONFIG, ...$OVERRIDE })
      - pattern: |
          const $CONFIG = { ...$BASE_CONFIG, ...$USER_CONFIG };
          ... DOMPurify.sanitize($INPUT, $CONFIG) ...
    message: >
      Spread operator on DOMPurify config allows the second object to override
      security-critical options from the first. If $OVERRIDE or $USER_CONFIG
      contains attacker-controlled values, they can weaken the sanitization
      policy (e.g., adding ALLOW_UNKNOWN_PROTOCOLS: true). Use Object.freeze()
      on the base config and validate overrides explicitly.
    languages: [javascript, typescript]
    severity: WARNING
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: MEDIUM
      impact: HIGH
```

### Rule 8: Template Substitution After Sanitization

```yaml
rules:
  - id: dompurify-template-substitution
    patterns:
      - pattern: |
          $CLEAN = DOMPurify.sanitize(...);
          ...
          $HTML = `...${$CLEAN}...${$UNSANITIZED}...`;
      - pattern: |
          $EL.innerHTML = `...${DOMPurify.sanitize($A)}...${$B}...`;
    message: >
      Template literal combines DOMPurify output with unsanitized variables.
      The unsanitized variable can inject HTML that interacts with the sanitized
      content, or can complete partially-escaped constructs from the sanitized
      output. Sanitize the entire final string, not individual components.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: HIGH
      impact: HIGH
```

### Rule 9: React dangerouslySetInnerHTML Without Sanitize

```yaml
rules:
  - id: dompurify-react-dangerous-html
    patterns:
      - pattern: |
          <$COMPONENT dangerouslySetInnerHTML={{__html: $VALUE}} />
      - pattern: |
          dangerouslySetInnerHTML: { __html: $VALUE }
    pattern-not-inside: |
      DOMPurify.sanitize(...)
    message: >
      React dangerouslySetInnerHTML used without DOMPurify.sanitize() in the
      same expression or enclosing scope. If $VALUE contains user-controlled
      HTML, this is a direct XSS vulnerability. Wrap the value in
      DOMPurify.sanitize() or use a sanitization utility function.
    languages: [javascript, typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      confidence: MEDIUM
      impact: HIGH
      technology: [react]
```

### Rule 10: Vue v-html Without Sanitize

```yaml
rules:
  - id: dompurify-vue-v-html
    pattern: |
      v-html="$VALUE"
    pattern-not-inside: |
      DOMPurify.sanitize(...)
    message: >
      Vue v-html directive used without DOMPurify.sanitize() on the bound value.
      v-html inserts raw HTML into the DOM without sanitization. Ensure the value
      is sanitized before binding.
    languages: [html]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      technology: [vue]
```

### Rule 11: Angular bypassSecurityTrustHtml

```yaml
rules:
  - id: dompurify-angular-bypass-trust
    patterns:
      - pattern: |
          $SANITIZER.bypassSecurityTrustHtml($VALUE)
      - pattern: |
          this.sanitizer.bypassSecurityTrustHtml($VALUE)
    message: >
      Angular bypassSecurityTrustHtml() disables Angular's built-in HTML
      sanitization. If $VALUE is not pre-sanitized with DOMPurify, this creates
      a direct XSS vector. Replace with DOMPurify.sanitize() or use Angular's
      DomSanitizer without bypassing trust.
    languages: [typescript]
    severity: ERROR
    metadata:
      cwe: ["CWE-79"]
      category: security
      technology: [angular]
```

### Rule 12: jQuery .html() With User Input

```yaml
rules:
  - id: dompurify-jquery-html
    patterns:
      - pattern: |
          $($SELECTOR).html($VALUE)
      - pattern: |
          jQuery($SELECTOR).html($VALUE)
    pattern-not-inside: |
      DOMPurify.sanitize(...)
    message: >
      jQuery .html() with potentially user-controlled input without DOMPurify
      sanitization. jQuery's .html() method sets innerHTML, which parses the
      input as HTML. Wrap $VALUE in DOMPurify.sanitize() before passing to .html().
    languages: [javascript, typescript]
    severity: WARNING
    metadata:
      cwe: ["CWE-79"]
      category: security
      technology: [jquery]
```

## 17.2 CodeQL Queries

### Taint Analysis: Source to innerHTML Sink Without DOMPurify

```ql
/**
 * @name Missing DOMPurify sanitization on innerHTML sink
 * @description Tracks data flow from user-controlled sources to innerHTML/outerHTML
 *              sinks without passing through DOMPurify.sanitize().
 * @kind path-problem
 * @problem.severity error
 * @security-severity 9.0
 * @precision medium
 * @id js/xss-missing-dompurify
 * @tags security
 *       external/cwe/cwe-079
 */

import javascript
import DataFlow::PathGraph

class UserControlledSource extends DataFlow::Node {
  UserControlledSource() {
    this = DOM::locationSource() or
    this = DOM::documentSource() or
    this.asExpr() instanceof HTTP::RequestInputAccess or
    exists(DataFlow::CallNode call |
      call.getCalleeName() = ["getElementById", "querySelector", "querySelectorAll"] and
      this = call.getAReturnedNode()
    ) or
    exists(DOM::AttributeDefinition attr |
      attr.getName() = ["value", "textContent", "innerText"] and
      this = attr.getARead()
    )
  }
}

class InnerHtmlSink extends DataFlow::Node {
  InnerHtmlSink() {
    exists(DataFlow::PropWrite pw |
      pw.getPropertyName() = ["innerHTML", "outerHTML"] and
      this = pw.getRhs()
    ) or
    exists(DataFlow::MethodCallNode call |
      call.getMethodName() = "insertAdjacentHTML" and
      this = call.getArgument(1)
    )
  }
}

class DOMPurifySanitizeBarrier extends DataFlow::Node {
  DOMPurifySanitizeBarrier() {
    exists(DataFlow::CallNode call |
      call.getCalleeName() = "sanitize" and
      call.getReceiver().getALocalSource().getAPropertyRead("sanitize").exists() and
      this = call.getAReturnedNode()
    )
  }
}

class MissingDOMPurifyConfig extends TaintTracking::Configuration {
  MissingDOMPurifyConfig() { this = "MissingDOMPurifyConfig" }

  override predicate isSource(DataFlow::Node source) {
    source instanceof UserControlledSource
  }

  override predicate isSink(DataFlow::Node sink) {
    sink instanceof InnerHtmlSink
  }

  override predicate isSanitizer(DataFlow::Node node) {
    node instanceof DOMPurifySanitizeBarrier
  }
}

from MissingDOMPurifyConfig config, DataFlow::PathNode source, DataFlow::PathNode sink
where config.hasFlowPath(source, sink)
select sink.getNode(), source, sink,
  "User-controlled data flows to innerHTML/outerHTML without DOMPurify sanitization."
```

### Data Flow Through DOMPurify to Post-Transformation to Sink

```ql
/**
 * @name Post-sanitization modification before innerHTML sink
 * @description Detects data flow where DOMPurify output is modified
 *              (string replace, decode, concatenation) before reaching an HTML sink.
 * @kind path-problem
 * @problem.severity error
 * @security-severity 8.0
 * @precision medium
 * @id js/xss-post-sanitization-modification
 * @tags security
 *       external/cwe/cwe-079
 */

import javascript
import DataFlow::PathGraph

class DOMPurifyOutput extends DataFlow::Node {
  DOMPurifyOutput() {
    exists(DataFlow::CallNode call |
      call.getCalleeName() = "sanitize" and
      this = call
    )
  }
}

class PostSanitizationModification extends DataFlow::Node {
  PostSanitizationModification() {
    exists(DataFlow::MethodCallNode call |
      call.getMethodName() = ["replace", "replaceAll", "trim", "slice", "substring"] and
      this = call
    ) or
    exists(DataFlow::CallNode call |
      call.getCalleeName() = ["decodeURIComponent", "decodeURI", "unescape"] and
      this = call
    ) or
    exists(StringOps::Concatenation concat |
      this = concat
    )
  }
}

from DOMPurifyOutput dpOutput, PostSanitizationModification mod, DataFlow::Node sink
where
  DataFlow::localFlow(dpOutput, mod) and
  DataFlow::localFlow(mod, sink) and
  exists(DataFlow::PropWrite pw |
    pw.getPropertyName() = ["innerHTML", "outerHTML"] and
    sink = pw.getRhs()
  )
select sink, "DOMPurify output is modified by $@ before reaching innerHTML sink.",
  mod, mod.toString()
```

### Configuration Analysis: Dangerous Option Combinations

```ql
/**
 * @name Dangerous DOMPurify configuration
 * @description Detects DOMPurify.sanitize() calls with configuration options
 *              that weaken sanitization security.
 * @kind problem
 * @problem.severity warning
 * @security-severity 7.0
 * @precision high
 * @id js/dompurify-dangerous-config
 * @tags security
 */

import javascript

from DataFlow::CallNode call, DataFlow::ObjectLiteralNode config
where
  call.getCalleeName() = "sanitize" and
  config = call.getArgument(1).getALocalSource() and
  (
    // ALLOW_UNKNOWN_PROTOCOLS enables javascript: URIs
    config.hasPropertyWrite("ALLOW_UNKNOWN_PROTOCOLS", any(DataFlow::Node n | n.mayHaveBooleanValue(true))) or
    // WHOLE_DOCUMENT can enable doctype injection
    config.hasPropertyWrite("WHOLE_DOCUMENT", any(DataFlow::Node n | n.mayHaveBooleanValue(true))) or
    // FORCE_BODY: false can skip body wrapping
    config.hasPropertyWrite("FORCE_BODY", any(DataFlow::Node n | n.mayHaveBooleanValue(false)))
  )
select call, "DOMPurify.sanitize() called with dangerous configuration option in $@.",
  config, "config"
```

## 17.3 Code Review Checklist

### Mandatory Review Items

**1. HTML Sink Coverage**
- [ ] Identify every `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `document.writeln` in the codebase
- [ ] Verify each sink receives DOMPurify.sanitize() output or is provably safe (static string, no user input)
- [ ] Check for framework-specific sinks: `dangerouslySetInnerHTML` (React), `v-html` (Vue), `bypassSecurityTrustHtml` (Angular), `{@html}` (Svelte)
- [ ] Check for jQuery sinks: `.html()`, `.append()`, `.prepend()`, `.after()`, `.before()` with string arguments
- [ ] Search for `eval()`, `Function()`, `setTimeout(string)`, `setInterval(string)` with user input

**2. DOMPurify Version Verification**
- [ ] Current DOMPurify version is >= 3.4.13 (all known CVEs patched)
- [ ] Verify version is pinned in package.json/yarn.lock/pnpm-lock.yaml (no floating ranges)
- [ ] Check for multiple DOMPurify versions in the dependency tree (npm ls dompurify)
- [ ] Verify lockfile integrity (no modified checksums)

**3. Configuration Review**
- [ ] Enumerate all DOMPurify.sanitize() call sites and their configurations
- [ ] Check for `ALLOW_UNKNOWN_PROTOCOLS: true` (CRITICAL: enables javascript: URIs)
- [ ] Check for `SAFE_FOR_XML: false` (may weaken XML context protection)
- [ ] Check for permissive `CUSTOM_ELEMENT_HANDLING` (tagNameCheck matching all)
- [ ] Verify `USE_PROFILES: { html: true }` is used when SVG/MathML is not needed
- [ ] Check for `ADD_TAGS` or `ADD_ATTR` that widen the allowlist beyond requirements
- [ ] Verify `FORBID_TAGS` and `FORBID_ATTR` are set for defense-in-depth
- [ ] Check configuration sources for attacker-controllable input

**4. Hook Audit**
- [ ] List all `DOMPurify.addHook()` calls
- [ ] Verify no hook sets `data.forceKeepAttr = true` unconditionally
- [ ] Verify no hook modifies allowlist sets (ALLOWED_TAGS, ALLOWED_ATTR internal arrays)
- [ ] Verify `afterSanitizeAttributes` hooks do not re-add removed attributes
- [ ] Verify `afterSanitizeElements` hooks do not re-insert removed elements
- [ ] Check hook ordering for conflicts (multiple hooks on the same event)
- [ ] Verify hooks are properly cleaned up on component unmount (React useEffect cleanup, Vue beforeUnmount)

**5. Post-Sanitization Integrity**
- [ ] No string replace/replaceAll on sanitized output
- [ ] No decodeURIComponent/decodeURI/unescape on sanitized output
- [ ] No HTML entity decoding on sanitized output
- [ ] No string concatenation combining sanitized and unsanitized content
- [ ] No template literal substitution mixing sanitized and unsanitized variables
- [ ] Sanitized output is not cached (Map, WeakMap, localStorage, sessionStorage)

**6. Conditional Sanitization Paths**
- [ ] No trust flags bypassing sanitization (`if (isTrusted) return raw`)
- [ ] No role-based sanitization bypass (`if (isAdmin) skip DOMPurify`)
- [ ] No feature flag-gated sanitization (`if (newFeature) skip sanitization`)
- [ ] No type-check bypass (`if (typeof input !== 'string') return input`)
- [ ] All code paths through the sanitization wrapper lead to DOMPurify.sanitize()

**7. Server-Client Consistency**
- [ ] If server-side sanitization exists, client-side re-sanitization also occurs
- [ ] Server-side DOMPurify uses jsdom or similar; verify `<noscript>` handling
- [ ] Server-side and client-side configurations are identical or server is stricter
- [ ] No assumption that server-side sanitization is sufficient (it is not -- browser reparsing creates new attack surface)

**8. Error Handling**
- [ ] try/catch blocks around DOMPurify do not return raw input on error
- [ ] Errors are logged for monitoring
- [ ] Fallback is empty string or safe default, not raw input

**9. Wrapper Function Review**
- [ ] No spread operator allowing config override (`{...baseConfig, ...userConfig}`)
- [ ] No type-checking that skips sanitization for non-string input
- [ ] Config objects are frozen (`Object.freeze()`)
- [ ] Wrapper always calls DOMPurify.sanitize() regardless of code path
- [ ] Return type is consistent (always string, always DocumentFragment)

**10. Trusted Types Integration**
- [ ] If Trusted Types CSP is deployed, verify DOMPurify creates policies correctly
- [ ] Verify policy name matches CSP header
- [ ] Verify no other Trusted Types policies that bypass DOMPurify

## 17.4 Automated Pipeline Integration

### Pre-Commit Hook (Husky / lint-staged)

```json
{
  "lint-staged": {
    "*.{js,jsx,ts,tsx}": [
      "semgrep --config=.semgrep/dompurify-rules.yml --error"
    ]
  }
}
```

### CI/CD GitHub Actions Workflow

```yaml
name: DOMPurify Security Scan
on: [pull_request]

jobs:
  dompurify-sast:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check DOMPurify version
        run: |
          DOMPURIFY_VERSION=$(node -e "console.log(require('dompurify/package.json').version)")
          MINIMUM_VERSION="3.4.13"
          if [ "$(printf '%s\n' "$MINIMUM_VERSION" "$DOMPURIFY_VERSION" | sort -V | head -n1)" != "$MINIMUM_VERSION" ]; then
            echo "::error::DOMPurify version $DOMPURIFY_VERSION is below minimum $MINIMUM_VERSION"
            exit 1
          fi

      - name: Run Semgrep DOMPurify rules
        uses: returntocorp/semgrep-action@v1
        with:
          config: .semgrep/dompurify-rules.yml

      - name: Run CodeQL analysis
        uses: github/codeql-action/analyze@v3
        with:
          queries: .codeql/dompurify-queries.ql
```

### PR Review Automation (CODEOWNERS)

```
# Require security team review for any file touching DOMPurify
**/sanitize*.{js,ts,jsx,tsx}  @security-team
**/dompurify*.{js,ts,jsx,tsx} @security-team
**/purify*.{js,ts,jsx,tsx}    @security-team
```

---
