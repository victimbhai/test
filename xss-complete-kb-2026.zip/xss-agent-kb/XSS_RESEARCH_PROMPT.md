# Cross-Site Scripting (XSS) Vulnerability Deep Research Directive

## Mission
You are a security research agent tasked with building the most comprehensive XSS knowledge base ever assembled. This intelligence will power an automated XSS testing agent capable of detecting and exploiting all variants of cross-site scripting vulnerabilities — reflected, stored, DOM-based, mutation-based, and exotic — across every injection context, with advanced CSP bypass, WAF evasion, and real-world exploitation capabilities.

## Research Execution Mode
- Execute research systematically, phase by phase
- Save all findings to the `/knowledge-base` directory
- Use web search extensively for real-world data, CVEs, and bug bounty reports
- Cross-reference multiple authoritative sources
- Include source URLs for all claims
- Focus on actionable, testable techniques
- Include code examples (vulnerable code AND exploit code)
- Include tool commands with exact syntax
- Include ready-to-use payloads

---

# PHASE 1: XSS FUNDAMENTALS & TAXONOMY

## Task 1.1: Core Concepts
Research and document in `knowledge-base/01-xss-fundamentals.md`:

### What is Cross-Site Scripting
- Definition, root cause, and the browser trust model
- Same-Origin Policy (SOP) and how XSS violates it
- XSS vs CSRF vs HTML injection — clear distinctions
- How user input reaches the DOM unsanitized
- The XSS kill chain: injection → execution → exploitation

### XSS Taxonomy
- Reflected XSS (Type 1) — server-side reflection
- Stored XSS (Type 2) — persistent server-side storage
- DOM-based XSS (Type 0) — client-side only, never hits server
- Mutation XSS (mXSS) — browser mutation of safe HTML into dangerous HTML
- Self-XSS — social engineering component
- Blind XSS — stored XSS triggered in admin/internal panels
- Universal XSS (UXSS) — browser vulnerability, not application

### Injection Contexts Overview
- HTML context (between tags)
- HTML attribute context (inside attribute values)
- JavaScript context (inside script blocks)
- URL context (href, src, action attributes)
- CSS context (style attributes, stylesheets)
- SVG/MathML context (XML-based embedded content)
- Template context (client-side template engines)
- JSON context (inline JSON, API responses)
- Markdown/Rich text context
- PDF/Email/File upload context

## Task 1.2: Browser Parsing & Execution Model
Research and document in `knowledge-base/02-browser-parsing-execution.md`:

### HTML Parser Behavior
- Tag soup parsing and error recovery
- Character reference decoding (&#x41;, &#65;, &amp;)
- Parser states and transitions
- How browsers handle malformed HTML
- Encoding priority: HTML entity → URL → JavaScript

### JavaScript Execution Context
- Inline scripts vs external scripts
- Event handlers and their execution context
- javascript: protocol URLs
- Dangerous functions as sinks
- Module scripts and their security implications

### DOM Construction
- DOM tree building from parsed HTML
- Script execution timing (sync, defer, async)
- Mutation observers and DOM manipulation timing
- Shadow DOM and its security boundaries
- Template element special parsing rules

### Content-Type and MIME Sniffing
- X-Content-Type-Options and MIME type enforcement
- Content-Type vs actual content behavior
- Browser MIME sniffing algorithms
- How incorrect Content-Type leads to XSS

---

# PHASE 2: REFLECTED XSS — ALL CONTEXTS

## Task 2.1: HTML Context Injection
Research and document in `knowledge-base/03-reflected-xss-html-context.md`:

### Between Tags
- Basic tag injection: `<script>alert(1)</script>`
- Event handler injection: `<img src=x onerror=alert(1)>`
- SVG-based: `<svg onload=alert(1)>`
- Details/summary: `<details open ontoggle=alert(1)>`
- All HTML5 tags that support event handlers
- Tags that auto-execute: script, body, iframe, embed, object, applet
- Lesser-known auto-executing contexts

### Inside Existing Tags (Attribute Breakout)
- Double-quote breakout: `" onfocus=alert(1) autofocus "`
- Single-quote breakout: `' onfocus=alert(1) autofocus '`
- No-quote attribute breakout: `x onfocus=alert(1) autofocus`
- Backtick breakout (IE legacy)
- Adding new attributes without closing the tag

### URL Context
- javascript: in href, src, action, formaction
- Data URLs: `data:text/html,<script>alert(1)</script>`
- URL encoding tricks
- Protocol-relative URLs

### CSS Context
- Style attribute injection
- CSS injection for data exfiltration

## Task 2.2: JavaScript Context Injection
Research and document in `knowledge-base/04-reflected-xss-javascript-context.md`:

### Breaking Out of Strings
- String delimiter escape and breakout
- Template literal escape
- Backslash bypass
- Unicode escape bypass
- Line terminator injection (U+2028, U+2029)

### Breaking Out of Script Blocks
- `</script>` tag injection to close script
- Partial tag closure tricks

### JavaScript Expression Injection
- Arithmetic context injection
- Conditional context injection
- Object key injection
- Array context injection
- Template literal expression injection

### JSON Context
- Breaking out of JSON string values
- JSON.parse vs inline JSON
- JSONP callback injection
- Content-Type confusion attacks

## Task 2.3: Special Contexts & Edge Cases
Research and document in `knowledge-base/05-reflected-xss-special-contexts.md`:

### Inside HTML Comments, Meta Tags, Title/Textarea
### Inside SVG/MathML Foreign Content
### Inside Input/Hidden Fields
### Edge Cases and Browser Quirks

---

# PHASE 3: STORED XSS — PERSISTENCE & EXOTIC VECTORS

## Task 3.1: Stored XSS Attack Vectors
Research and document in `knowledge-base/06-stored-xss-vectors.md`:
- Common injection points (profiles, comments, messaging, file names)
- Second-order XSS
- Testing methodology for stored XSS

## Task 3.2: Exotic Storage Vectors
Research and document in `knowledge-base/07-stored-xss-exotic.md`:
- SVG file upload XSS
- Image metadata XSS
- Document upload XSS
- API/Webhook XSS

## Task 3.3: Blind XSS
Research and document in `knowledge-base/08-blind-xss.md`:
- Blind XSS concepts and high-impact targets
- Blind XSS payloads and platforms
- Injection points for blind XSS

---

# PHASE 4: DOM-BASED XSS

## Task 4.1: Sources & Sinks
Research and document in `knowledge-base/09-dom-xss-sources-sinks.md`:
- Complete DOM XSS sources catalog
- Complete DOM XSS sinks catalog
- Source-to-sink tracing methodology

## Task 4.2: Modern DOM XSS Patterns
Research and document in `knowledge-base/10-dom-xss-modern.md`:
- Hash-based routing XSS, postMessage XSS
- Client-side template injection
- URL fragment and parameter manipulation

## Task 4.3: Framework-Specific DOM XSS
Research and document in `knowledge-base/11-dom-xss-frameworks.md`:
- React, Angular, Vue.js, jQuery XSS vectors
- Next.js/Nuxt.js specific patterns

---

# PHASE 5: CSP BYPASS TECHNIQUES

## Task 5.1-5.3: CSP Analysis & Bypass
Research and document in `knowledge-base/12-csp-bypass-fundamentals.md`, `13-csp-bypass-techniques.md`, `14-csp-bypass-real-world.md`:
- CSP header analysis and common misconfigurations
- JSONP, CDN, script gadget, policy injection, nonce/hash bypasses
- Real-world CSP bypass case studies

---

# PHASE 6: FILTER, WAF & SANITIZER BYPASS

## Tasks 6.1-6.4
Research and document in `knowledge-base/15-filter-bypass-server.md`, `16-sanitizer-bypass-client.md`, `17-waf-bypass-xss.md`, `18-advanced-bypass-techniques.md`:
- Server-side filter bypass (encoding, tag manipulation, obfuscation)
- Client-side sanitizer bypass (DOMPurify, Angular, React, custom)
- WAF bypass for XSS (Cloudflare, AWS, Akamai, ModSecurity)
- Advanced techniques (mXSS, DOM clobbering, prototype pollution)

---

# PHASE 7: XSS EXPLOITATION & IMPACT

## Tasks 7.1-7.4
Research and document in `knowledge-base/19-exploitation-session-hijack.md`, `20-exploitation-account-takeover.md`, `21-exploitation-rce-advanced.md`, `22-exploitation-payloads.md`:
- Session hijacking and cookie theft
- Account takeover via XSS
- XSS to RCE, data exfiltration, network pivoting
- Complete exploitation payloads library

---

# PHASE 8: CONTEXT-SPECIFIC & EXOTIC XSS

## Tasks 8.1-8.4
Research and document in `knowledge-base/23-svg-mathml-xml-xss.md`, `24-json-api-header-xss.md`, `25-file-upload-xss.md`, `26-pdf-email-markdown-xss.md`:
- SVG, MathML, XML injection
- JSON, API, header XSS
- File upload XSS
- PDF, email, markdown XSS

---

# PHASE 9: MODERN & EMERGING XSS

## Tasks 9.1-9.3
Research and document in `knowledge-base/27-browser-api-exploitation.md`, `28-prototype-pollution-xss.md`, `29-postmessage-emerging.md`:
- Browser API exploitation (Service Workers, WebRTC, etc.)
- Prototype pollution to XSS chains
- postMessage attacks and emerging vectors

---

# PHASE 10: REAL-WORLD INTELLIGENCE

## Tasks 10.1-10.4
Research and document in `knowledge-base/30-bug-bounty-xss.md`, `31-xss-cve-analysis.md`, `32-xss-impact.md`, `33-xss-prevention.md`:
- Bug bounty case studies and methodology
- CVE analysis (2020-2025)
- Impact and business context
- Prevention intelligence (know what defenders do)

---

# PHASE 11: TOOLS & AUTOMATION

## Tasks 11.1-11.3
Research and document in `knowledge-base/34-xss-tools.md`, `35-xss-detection-methodology.md`, `36-burp-integration.md`:
- XSS testing tools (Dalfox, XSStrike, kxss, etc.)
- Detection and scanning methodology
- Burp Suite integration

---

# PHASE 12: PAYLOAD LIBRARIES & METHODOLOGY COMPILATION

## Tasks 12.1-12.2
Research and document in `knowledge-base/37-xss-polyglots.md`, `knowledge-base/38-methodology-compilation.md`:
- XSS polyglot collection
- Complete methodology + populate payload files

---

# PHASE 13: AGENT CREATION

## Tasks 13.1-13.4
Compile into `agent/methodology.md`, `agent/xss-agent-logic.md`, `agent/integration.md`, `agent/XSS_AGENT_PROMPT.md`:
- Complete testing methodology
- Agent decision logic
- Inter-agent integration
- Final production agent prompt

---

# OUTPUT FORMAT

For each knowledge-base file:
1. Start with a clear title and file number
2. Include a brief overview/abstract
3. Organize content with clear headers
4. Include source URLs for all claims
5. Include code examples (vulnerable AND exploit)
6. Include ready-to-use payloads and commands
7. End with a summary of key takeaways
8. Target 3-5 KB per file (some may be larger)

## Quality Standards
- Every technique must be actionable
- Every payload must be tested syntax
- Every tool command must have exact syntax
- Every bypass must include the specific filter/WAF it bypasses
- Every exploitation technique must include impact demonstration
- Cross-reference between files where relevant
