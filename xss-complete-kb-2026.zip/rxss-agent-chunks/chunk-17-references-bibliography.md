# Agent Chunk 17: References & Bibliography

**Agent Task:** Use these reference tables to trace any claim back to its source. Before reporting a finding, check its evidence quality here. Use the bibliography for further research on specific topics.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 30. Local-Source References

### 30.1 Core Reflected-XSS Files

| Ref ID | File Path | Role in Guide |
|---|---|---|
| KB-01 | `xss-agent-kb/01-xss-fundamentals.md` | Taxonomy and classification (Section 2) |
| KB-02 | `xss-agent-kb/02-browser-parsing-execution.md` | Browser parsing model (Section 8) |
| KB-03 | `xss-agent-kb/03-reflected-xss-html-context.md` | HTML context XSS (Section 10) |
| KB-04 | `xss-agent-kb/04-reflected-xss-javascript-context.md` | JavaScript context XSS (Section 12) |
| KB-05 | `xss-agent-kb/05-reflected-xss-special-contexts.md` | Special parser contexts (Section 15) |
| KB-15 | `xss-agent-kb/15-filter-bypass-server.md` | Server-side filter bypass (Section 9) |
| KB-16 | `xss-agent-kb/16-sanitizer-bypass-client.md` | Sanitizer bypass analysis (Section 20, 39) |
| KB-17 | `xss-agent-kb/17-waf-bypass-xss.md` | WAF analysis (Section 9) |
| KB-24 | `xss-agent-kb/24-json-api-header-xss.md` | JSON/header reflection (Section 14, 16) |
| KB-30 | `xss-agent-kb/30-bug-bounty-xss.md` | Bounty statistics and methodology |
| KB-31 | `xss-agent-kb/31-xss-cve-analysis.md` | CVE catalog (Section 40) |
| KB-32 | `xss-agent-kb/32-xss-impact.md` | Impact analysis (Section 25) |
| KB-33 | `xss-agent-kb/33-xss-prevention.md` | Prevention guidance (Section 20, 21) |
| KB-35 | `xss-agent-kb/35-xss-detection-methodology.md` | Detection methodology (Section 22) |
| KB-36 | `xss-agent-kb/36-burp-integration.md` | Burp Suite integration |
| KB-38 | `xss-agent-kb/38-methodology-compilation.md` | Methodology reference (Section 22) |
| KB-39 | `xss-agent-kb/39-agent-methodology.md` | Agent workflow (Section 22) |
| KB-40 | `xss-agent-kb/40-agent-decision-logic.md` | Decision trees (Section 24) |
| KB-44 | `xss-agent-kb/44-framework-xss.md` | Framework analysis (Section 19) — **WEAKEST evidence** |

### 30.2 Case Study Files

| Ref ID | File Path | Role in Guide |
|---|---|---|
| XSS-14 | `xss/14-reflected-xss-oauth-redirect.md` | OAuth XSS (Section 17) |
| XSS-16 | `xss/16-crlf-injection-to-xss.md` | CRLF-to-XSS chains (Section 16) |
| XSS-18 | `xss/18-mxss-mutation-xss.md` | Mutation XSS (Section 39) |
| XSS-21 | `xss/21-swagger-api-docs-xss.md` | API doc XSS (Section 18) |
| XSS-22 | `xss/22-waf-bypass-techniques.md` | WAF bypass (Section 9) |
| XSS-25 | `xss/25-waf-bypass-advanced.md` | Advanced WAF bypass (Section 9) |
| XSS-99 | `xss/99-xss-brain-logic.md` | Strategic thinking (Section 29) |

### 30.3 Unique offsec-agent-system Files

| Ref ID | File Path | Role in Guide |
|---|---|---|
| OFF-SKILL | `offsec-agent-system/skills/offsec-xss/SKILL.md` | Skill definition |
| OFF-XSS | `offsec-agent-system/skills/xss/SKILL.md` | Technique breakdowns |
| OFF-BYPASS | `offsec-agent-system/skills/xss/refs/xss-bypasses.md` | Bypass payloads (UNVERIFIED) |
| OFF-POLY | `offsec-agent-system/skills/xss/refs/xss-polyglots.md` | Polyglot vectors (UNVERIFIED) |

---

## 31. Public HackerOne TOPXSS Report Manifest

**Source**: `TOPXSS.md` (local archive copy)
**Total entries**: 2,376
**Format**: Title, link, metadata only — NO full report bodies
**Sort order**: By upvote count, descending

### Reflected XSS in Top 30 Entries

| Rank | Title Pattern | Program | Classification |
|---|---|---|---|
| 8 | XSS via OAuth ... | LY Corporation | **REFLECTED_SERVER** (likely — OAuth flow) |
| 14 | Reflected XSS ... redirect | Reddit | **REFLECTED_SERVER** (likely) |
| 15 | Reflected XSS ... | HackerOne | **REFLECTED_SERVER** (likely) |
| 16 | Reflected XSS ... | Uber | **REFLECTED_SERVER** (likely) |
| 26 | Reflected XSS ... | Bumble | **REFLECTED_SERVER** (likely) |

**Note**: Stored XSS dominates top entries by upvote count. These classifications are from TITLE ANALYSIS ONLY — titles are hypotheses, not evidence.

---

## 32. Hacktivity Reflected-XSS Analysis

### Publicly Disclosed Reports (from corpus and search)

| Report Source | Program | Vulnerability Type | Bounty | Evidence |
|---|---|---|---|---|
| XSS-14 (local) | LINE Corporation | OAuth redirect reflected XSS | $1,989 | PRIMARY-LOCAL |
| XSS-14 (local) | Shopify | OAuth redirect reflected XSS | $1,750 | PRIMARY-LOCAL |
| XSS-14 (local) | Reddit | Redirect parameter reflected XSS | $5,000 | PRIMARY-LOCAL |
| XSS-14 (local) | TikTok | OAuth/redirect reflected XSS | $5,000 | PRIMARY-LOCAL |
| XSS-16 (local) | Twitter | CRLF to reflected XSS | $1,680 | PRIMARY-LOCAL |
| XSS-16 (local) | TikTok (x2) | CRLF to reflected XSS | Various | PRIMARY-LOCAL |
| XSS-22 (local) | Starbucks | WAF bypass reflected XSS | Various | PRIMARY-LOCAL |
| XSS-22 (local) | data.gov | WAF bypass reflected XSS | Various | PRIMARY-LOCAL |

---

## 33. Bugcrowd and Independent Disclosure Analysis

### Independent Disclosures and CVEs

| CVE | Product | Type | CVSS | Verification |
|---|---|---|---|---|
| CVE-2025-64764 | Astro (server islands) | Reflected XSS | 7.1 (High) | PRIMARY-EXTERNAL |
| CVE-2025-26791 | DOMPurify | mXSS (template regex) | 4.5 (Medium) | PRIMARY-EXTERNAL |
| CVE-2024-47875 | DOMPurify | Nesting-based mXSS | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-46342 | Nuxt Nitro Server | Reflected XSS | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-41238 | DOMPurify | Prototype pollution | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-47423 | DOMPurify | Engine-deferred mutation | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-0540 | DOMPurify | RAWTEXT element bypass | Not verified | SECONDARY-EXTERNAL |
| CVE-2025-62800 | FastMCP | OAuth callback XSS | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-77272 | MCP Atlassian | OAuth callback XSS | Not verified | SECONDARY-EXTERNAL |
| CVE-2026-40302 | OpenZiti zrok | OAuth callback XSS | Not verified | SECONDARY-EXTERNAL |

---

## 34. Primary Research Bibliography

### Specifications and Standards

| Title | Relevance | Evidence Grade |
|---|---|---|
| WHATWG HTML Living Standard | HTML5 tokenizer, DOM construction, parser algorithms | PRIMARY-EXTERNAL |
| WHATWG URL Standard | URL parsing, percent-encoding | PRIMARY-EXTERNAL |
| ECMAScript Specification (TC39) | JavaScript parsing, template literals, string escaping | PRIMARY-EXTERNAL |
| W3C Content Security Policy Level 3 | CSP directives, nonce/hash, Trusted Types | PRIMARY-EXTERNAL |

### Security Guidance

| Title | Relevance | Evidence Grade |
|---|---|---|
| OWASP XSS Prevention Cheat Sheet | Output encoding rules, framework guidance | PRIMARY-EXTERNAL |
| OWASP DOM XSS Prevention Cheat Sheet | Safe sinks, dangerous APIs | PRIMARY-EXTERNAL |
| PortSwigger XSS Contexts | Context-specific XSS techniques | PRIMARY-EXTERNAL |

### Research Papers and Articles

| Title | Relevance | Evidence Grade |
|---|---|---|
| WAFFLED: Exploiting Parsing Discrepancies to Bypass WAFs | WAF bypass via structure mutation | PRIMARY-EXTERNAL |
| XSS in Hidden Input Fields (Gareth Heyes) | accesskey technique | PRIMARY-EXTERNAL |
| Exploring DOMPurify Bypasses and Fixes (Kevin Mizu) | DOMPurify mXSS mechanisms | PRIMARY-EXTERNAL |
| DOMPurify Attack Classes & Bypass History (cure53) | Comprehensive bypass timeline | PRIMARY-EXTERNAL |
| HTMX Web Security Basics | HTMX security model | PRIMARY-EXTERNAL |

---

*Next chunk: chunk-18-root-cause-browser-analysis.md*
