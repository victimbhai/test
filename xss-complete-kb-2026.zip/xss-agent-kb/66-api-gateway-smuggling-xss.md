# 66 - API Gateway Bypass and HTTP Request Smuggling to XSS

## Overview

API gateways and reverse proxies enable XSS through:
- HTTP request smuggling (CL-TE, TE-CL, H2.CL, TE.0, chunk-extension TE.TE) turning reflected XSS into stored-like XSS
- Nginx misconfiguration: add_header inheritance, $uri reflection, merge_slashes
- X-Forwarded-Host header injection reflected in application responses
- CRLF injection via HTTP/2 downgrade (CVE-2025-57804)
- FrontJacking through reverse proxy misconfiguration
- Kong request smuggling (CVE-2026-6338)

## HTTP Request Smuggling to XSS

Request smuggling (CL-TE, TE-CL, and HTTP/2 downgrade variants) is a well-documented technique for upgrading reflected XSS to affect arbitrary users. The smuggled request poisons the connection so the backend treats the next legitimate user's request as a continuation of the attacker's smuggled request.

### Smuggling-to-XSS Attack Flow

```
Attacker                 Front-end                Back-end
   |                        |                        |
   |-- Smuggled request --->|                        |
   |   (CL says X,          |-- Forwards partial --->|
   |    TE says Y)           |   request              |
   |                        |                        |
   |                        |   Back-end sees leftover|
   |                        |   bytes as next request  |
   |                        |                        |
   |                        |<-- Victim's request ----|
   |                        |   (appended to smuggled |
   |                        |    leftover with XSS    |
   |                        |    in User-Agent)       |
   |                        |                        |
   |                        |<-- XSS response --------|
   |<-- XSS to victim ------|                        |
```

### TE.0 Dechunking (2024)

Targets servers that accept chunked encoding in requests but do not properly handle a zero-length chunk, creating a new class of smuggling that bypasses previous mitigations.

### Chunk-Extension TE.TE (2025)

Credited to Jeppe Weikop. Exploits differences in how front-end and back-end servers handle extensions appended to chunk sizes (e.g., `0;extension`), creating desync even when both servers nominally support chunked encoding.

### H2.CL Desync

HTTP/2 downgrading is where smuggling via HTTP/2 comes from. Front-end proxies that translate HTTP/2 to HTTP/1.1 for backends create smuggling opportunities. HTTP/2's binary framing makes the smuggled content invisible to HTTP/2-aware WAFs.

### Detection

The hsmug tool (Go, open-source) detects HTTP/1.1, HTTP/2 downgrade, and HTTP/3 desync, and includes a reflected-XSS check.

## Nginx Reverse Proxy Misconfigurations

### add_header Inheritance

The `add_header` directive in a child block completely overrides (not appends to) parent block headers. If CSP or X-Content-Type-Options is set in the server block but a location block adds its own `add_header`, all parent security headers are silently dropped.

```nginx
# VULNERABLE: Security headers silently dropped in location block
server {
    add_header Content-Security-Policy "default-src 'self'";
    add_header X-Content-Type-Options "nosniff";

    location /api/ {
        add_header X-Custom-Header "value";
        # CSP and X-Content-Type-Options are now GONE in this location!
        proxy_pass http://backend;
    }
}

# SAFE: Repeat security headers in every location block
server {
    location /api/ {
        add_header Content-Security-Policy "default-src 'self'";
        add_header X-Content-Type-Options "nosniff";
        add_header X-Custom-Header "value";
        proxy_pass http://backend;
    }
}
```

### $uri Variable Reflection XSS

`$uri` and `$document_uri` contain the decoded/normalized URI, while `$request_uri` contains the original. Using `$uri` in a return or rewrite directive reflects decoded user input.

```nginx
# VULNERABLE: $uri decodes %3Cscript%3E to <script>
location / {
    return 302 https://$host$uri;
    # Request: /%3Cscript%3Ealert(1)%3C/script%3E
    # Location header: https://example.com/<script>alert(1)</script>
}

# SAFE: Use $request_uri (preserves encoding)
location / {
    return 302 https://$host$request_uri;
}
```

### Off-by-Slash Misconfiguration

When a location block lacks a trailing slash but proxy_pass includes one, unexpected path mappings occur, potentially routing requests to XSS-vulnerable backend endpoints.

### merge_slashes Bypass

When `merge_slashes` is set to `off`, Nginx does not normalize multiple slashes, allowing requests to bypass location-based access controls and reach XSS-vulnerable paths.

## X-Forwarded-Host Header Injection

### Attack Pattern

```
Attacker                   Proxy/LB              Backend Application
   |                          |                          |
   |-- Request with           |                          |
   |   X-Forwarded-Host:      |                          |
   |   evil"><script>...      |-- Forwards with header ->|
   |                          |                          |
   |                          |                   Generates response
   |                          |                   using header value
   |                          |                   in <base href="...">,
   |                          |                   redirect URL, or
   |                          |                   asset URL
   |                          |                          |
   |<-- Response with XSS ----|<-- Response with XSS ----|
```

Bug bounty disclosures in 2024-2025 confirm this remains actively exploited. A December 2024 Bugcrowd disclosure against NASA describes X-Forwarded-Host manipulation leading to open redirection and potential reflected XSS.

### Underscore-Hyphen Normalization (CVE-2025-48865, CVE-2025-64484)

Proxies may treat `X_Forwarded_Host` and `X-Forwarded-Host` differently, allowing an attacker to inject a header that the proxy does not strip but the backend trusts.

### Hop-by-Hop Header Abuse

An attacker marks security-relevant headers as hop-by-hop using the `Connection` header, causing the proxy to strip them. The backend then falls back to a default or attacker-supplied value.

## CRLF Injection via HTTP/2 Downgrade (CVE-2025-57804)

**CVE-2025-57804 (python-hyper h2):** HTTP/2 request splitting vulnerability allows attackers to perform request smuggling by injecting CRLF characters into headers. This occurs when servers downgrade HTTP/2 requests to HTTP/1.1 without properly validating header names/values. Fixed in version 4.3.0.

```
Attacker               HTTP/2 Front-end        HTTP/1.1 Backend
   |                        |                        |
   |-- HTTP/2 request       |                        |
   |   with \r\n in         |                        |
   |   header value         |                        |
   |   (valid in HTTP/2     |                        |
   |   binary framing)      |                        |
   |                        |-- Downgrades to ------>|
   |                        |   HTTP/1.1             |
   |                        |   Header value now     |
   |                        |   contains literal     |
   |                        |   CRLF, splitting into |
   |                        |   multiple headers     |
   |                        |                        |
   |                        |                Injected header/body
   |                        |                contains XSS payload
```

**CVE-2024-45302 (RestSharp):** CRLF injection in versions 107 through 111. Client libraries used for inter-service communication can also be CRLF injection vectors.

### FrontJacking

FrontJacking involves CRLF injection, HTTP request header injection, and XSS to exploit a poorly configured reverse proxy in a shared hosting environment.

### Response Splitting to XSS

By injecting a double CRLF sequence (%0D%0A%0D%0A), an attacker can terminate the headers of the original response and start an entirely new response that they control, injecting arbitrary HTML/JavaScript.

## Kong API Gateway

No XSS-specific CVEs were found for Kong in 2024-2026. Related findings:

**CVE-2026-6338:** Request smuggling and desynchronization caused by a parsing flaw in Kong's HTTP request processing pipeline.

Kong's Admin API, when exposed without authentication, permits arbitrary plugin configuration. An attacker could install or reconfigure the response-transformer plugin to inject arbitrary content into responses.

## AWS API Gateway

No specific CVEs found. Primary XSS risks:
- Lambda proxy integration passes function output directly to clients without encoding
- VTL mapping templates in integration responses can embed unsanitized input
- Custom authorizer error messages may reflect request data

## Testing Methodology

1. **Test for request smuggling** using CL-TE, TE-CL, and H2.CL variants
2. **Check Nginx configuration** for add_header inheritance issues
3. **Test $uri reflection** in Nginx return/rewrite directives
4. **Inject X-Forwarded-Host** and check for reflection in responses
5. **Test CRLF injection** in HTTP/2 headers (test bare \r separately)
6. **Check Kong Admin API** exposure and plugin configurations
7. **Test AWS Lambda** proxy integration for unsanitized output
8. **Check for hop-by-hop header abuse** via Connection header

## Bug Bounty Tips

1. Request smuggling upgrades reflected XSS to affect arbitrary users
2. Nginx add_header inheritance silently drops CSP -- check every location block
3. $uri in Nginx return directives is a direct XSS vector
4. X-Forwarded-Host reflection is actively exploited in 2024-2025 bounty programs
5. HTTP/2 downgrade CRLF injection (CVE-2025-57804) creates new attack surfaces
6. Kong exposed Admin API enables arbitrary response injection via plugins
7. End-to-end HTTP/2 eliminates most smuggling vectors
8. WAFs must inspect after protocol normalization, not before
