# Agent Chunk 04: Browser Parsing & Decoding Pipeline

**Agent Task:** Understand how browsers parse HTML and apply multi-layer decoding. Use the tokenizer state table to determine what a reflected value will become in the DOM. Use the transformation pipeline to find where encoding gaps allow bypasses.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 8. Browser Parsing and Context Taxonomy

### 8.1 HTML5 Tokenizer States Relevant to Reflected XSS

The HTML5 parsing algorithm (WHATWG HTML Living Standard, §13.2) defines a state machine that processes input characters into tokens. The tokenizer's current state determines how reflected content is interpreted.

**Source**: KB-02 (`02-browser-parsing-execution.md`), cross-verified with WHATWG HTML Living Standard.

| Tokenizer State | Triggered By | Parsing Behavior | XSS Relevance |
|---|---|---|---|
| **Data state** | Normal HTML content | Processes `<` as tag open, `&` as character reference | Standard HTML injection point |
| **RCDATA state** | `<title>`, `<textarea>` | Recognizes end tag, character references decoded, but `<` does NOT start new tags | Cannot inject new tags, but closing the RCDATA element returns to data state |
| **RAWTEXT state** | `<style>`, `<xmp>`, `<iframe>`, `<noembed>`, `<noframes>` | Only recognizes the matching end tag; no character references, no tags | Must close the RAWTEXT element to escape |
| **Script data state** | `<script>` | Special rules for `</script>` recognition | `</script>` terminates regardless of JS string context |
| **PLAINTEXT state** | `<plaintext>` | No tags recognized, no way to exit | Cannot be exploited (no exit) |
| **Attribute value (double-quoted)** | `attr="..."` | `"` ends value, `&` starts character reference | Must break out of quotes to inject |
| **Attribute value (single-quoted)** | `attr='...'` | `'` ends value, `&` starts character reference | Must break out of quotes to inject |
| **Attribute value (unquoted)** | `attr=...` | Whitespace, `>`, and several other characters end value | Easier to escape; many characters terminate |

### 8.2 The Triple-Layer Decoding Model

Browsers apply up to three independent decoding layers, each with distinct rules:

```
Layer 1: HTML Entity Decoding
+-- Named entities: &lt; -> <, &gt; -> >, &amp; -> &, &quot; -> "
+-- Numeric decimal: &#60; -> <
+-- Numeric hexadecimal: &#x3C; -> <
+-- Context: Decoded in HTML text and attribute values
+-- NOT decoded in: <script> content, <style> content, RAWTEXT elements
+-- Semicolons: Some parsers accept entities without trailing semicolon

Layer 2: URL Decoding
+-- Percent encoding: %3C -> <, %22 -> "
+-- Context: Decoded in href, src, action, and other URL-bearing attributes
+-- Double encoding: %253C -> %3C -> < (if server also URL-decodes)
+-- Applied AFTER HTML entity decoding in attributes

Layer 3: JavaScript Decoding
+-- Unicode escapes: < -> <, \u{3C} -> <
+-- Hex escapes: \x3C -> <
+-- Octal escapes: \074 -> < (non-strict mode)
+-- Context: Decoded within JavaScript execution contexts
+-- Applied AFTER HTML entity decoding in event-handler attributes
```

**Critical security implication**: In an event-handler attribute like `onclick="..."`, the browser first HTML-entity-decodes the attribute value, then passes the result to the JavaScript engine. This means `&#x27;` becomes `'` before JavaScript interpretation, allowing string breakout through HTML entities.

### 8.3 DOM Tree Construction and Adoption Agency

**Adoption Agency Algorithm** (WHATWG §13.2.6.4.7): Handles improperly nested formatting elements. When the parser encounters mismatched tags like `<b><i></b></i>`, the adoption agency algorithm rearranges nodes. This can cause elements to be moved to different positions in the tree than the raw markup suggests.

**Foster Parenting** (WHATWG §13.2.6.1): When certain elements appear inside `<table>` where they are not expected, the parser moves them before the table in the DOM. A reflected value inside a table context may end up at a different document position than the source markup indicates.

**Foreign Content Parsing** (WHATWG §13.2.6.5): When the parser encounters SVG or MathML elements, it switches to foreign content parsing rules. Elements like `<foreignObject>`, `<desc>`, and `<title>` within SVG are HTML integration points that switch back to HTML parsing. This namespace transition is the foundation of namespace confusion attacks.

### 8.4 Browser Engine Differences

| Feature | Blink (Chrome/Edge) | Gecko (Firefox) | WebKit (Safari) |
|---|---|---|---|
| XSS Auditor | Removed (Chrome 78) | Never implemented | Removed (Safari 13) |
| `<svg><desc>` as HTML integration point | Yes | Yes | Yes |
| `accesskey` on hidden inputs | Fires `onclick` | Fires `onclick` | Not confirmed |
| `popover` attribute support | Yes (Chrome 114+) | Yes (Firefox 125+) | Yes (Safari 17+) |
| Trusted Types enforcement | Yes (Chrome 83+) | Not yet | Not yet |
| `<selectedcontent>` behavior | Chrome 130+ (DOMPurify CVE-2026-47423) | N/A | N/A |

---

## 9. Transformation and Decoding Pipeline

### 9.1 Ordered Transformation Stages

Between the HTTP request and browser rendering, a reflected value may pass through up to 14 distinct transformation stages. The order matters critically because encoding performed for the wrong stage or at the wrong point in the pipeline may be ineffective.

```
Request Input
   |
   +-- 1. URL decoding (web server / reverse proxy)
   +-- 2. Form body decoding (application/x-www-form-urlencoded or multipart)
   +-- 3. JSON/XML parsing (for API endpoints)
   +-- 4. Character-set conversion (if charset differs from UTF-8)
   +-- 5. Unicode normalization (NFC/NFD/NFKC/NFKD)
   +-- 6. Framework parameter binding (query string, path, body -> named params)
   +-- 7. Proxy rewriting (reverse proxy URL rewriting, header injection)
   +-- 8. Application validation (allowlist, blocklist, regex, length)
   +-- 9. Application processing (business logic, database queries)
   +-- 10. Template engine rendering (Jinja2, ERB, JSX, Blade, etc.)
   +-- 11. Output encoding/sanitization (HTML encode, JS encode, sanitize)
   +-- 12. Response serialization (JSON, HTML, XML construction)
   +-- 13. Compression (gzip/br -- transparent, not security-relevant)
   v
HTTP Response
   |
   +-- 14. Browser HTML parsing (tokenization, tree construction, script execution)
   +-- 15. DOM mutation after parsing (sanitizer reparsing, innerHTML assignment)
   +-- 16. Client-side JavaScript processing (if hybrid reflected/DOM)
```

### 9.2 Key Differential Questions

For every reflected value, determine:

1. **How many decoding stages exist?** A value that passes through URL decoding, framework parameter binding, and template rendering has three transformation opportunities.
2. **In which order do they occur?** URL decoding before validation allows double-encoded bypasses.
3. **Which representation is validated?** If the validator inspects URL-encoded form but the template engine receives the decoded form, validation was ineffective.
4. **Which representation is rendered?** The final output context determines the required encoding.
5. **Is encoding performed for the correct final context?** HTML entity encoding in a JavaScript string context does not prevent XSS.
6. **Is input normalized after validation?** Unicode normalization (NFKC) can map characters like U+FE64 (SMALL LESS-THAN SIGN) to `<` after validation.
7. **Is sanitized content later concatenated with untrusted data?** DOMPurify's output is safe HTML, but concatenating it with unsanitized content before innerHTML reintroduces risk.
8. **Does a proxy or framework decode differently from the validator?** WAFFLED research showed WAFs and frameworks can parse the same multipart body differently.
9. **Is server-side escaping undone by client-side processing?** A server-rendered `&lt;script&gt;` is safe in HTML, but client-side JavaScript reading via `textContent` and assigning to `innerHTML` reverses the escaping.

### 9.3 HTTP Parameter Pollution

HTTP Parameter Pollution (HPP) exploits server-side parsing differences when the same parameter appears multiple times:

| Technology | Behavior with `?a=1&a=2` | Exploitation Relevance |
|---|---|---|
| PHP | Takes LAST value (`a=2`) | WAF may inspect first, app uses last |
| ASP.NET | Joins all values (`a=1,2`) | Concatenation may bypass length checks |
| Python (Flask) | Takes FIRST value (`a=1`) | App processes different value than WAF |
| Java (Servlet) | Takes FIRST value (`a=1`) | Similar to Flask |
| Node.js (Express) | Returns array (`a=["1","2"]`) | Array handling may bypass string-based filters |
| Ruby (Rack) | Takes LAST value (`a=2`) | Similar to PHP |

**Source**: KB-15, Acunetix HPP whitepaper, OWASP HPP guidance.

---

*Next chunk: chunk-05-html-attribute-context-testing.md*
