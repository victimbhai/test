# Agent Chunk 08: OAuth, Redirect & API Documentation Testing

**Agent Task:** Test OAuth and redirect flows for reflected XSS in callback pages, error displays, and redirect parameter handling. Test API documentation renderers (Swagger UI, ReDoc, GraphiQL) for DOM XSS via URL/config query parameters.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 17. OAuth and Redirect-Flow Reflection

### 17.1 OAuth Callback Page Reflection

OAuth flows involve multiple redirect steps where parameters are reflected in URLs and sometimes in page content. The most common reflected XSS surfaces in OAuth are:

| Parameter | Description | XSS Surface |
|---|---|---|
| `redirect_uri` | Where to redirect after authorization | If reflected in error page when validation fails |
| `state` | CSRF protection parameter | If reflected in callback page HTML |
| `error` | Error code from authorization server | If reflected in error display page |
| `error_description` | Human-readable error message | If reflected without encoding in error page |
| `code` | Authorization code | Rarely reflected in HTML |
| `login_hint` | Suggested username | If reflected in login form |

### 17.2 HackerOne Reports: OAuth Reflected XSS

From XSS-14 (`14-reflected-xss-oauth-redirect.md`) — the most detailed reflected XSS case study in the corpus:

| Program | Report | Bounty | Vulnerable Parameter | Context |
|---|---|---|---|---|
| LINE Corporation | HackerOne report | $1,989 | OAuth redirect parameter | Reflected in callback page |
| Shopify | HackerOne report | $1,750 | OAuth redirect parameter | Reflected in error page |
| Reddit | HackerOne report | $5,000 | Redirect parameter | Reflected in redirect confirmation page |
| TikTok | HackerOne report | $5,000 | OAuth/redirect parameter | Reflected in callback handling |

**Note**: These bounty amounts and report details are from the local corpus (XSS-14). Full report bodies were not independently read from HackerOne during this research session; the details are sourced from the local case study file. Evidence quality: PRIMARY-LOCAL.

### 17.3 Common Vulnerable Redirect Parameter Names

The corpus documents 10 commonly vulnerable redirect parameter names across OAuth implementations:

`redirect_uri`, `redirect_url`, `return_url`, `returnTo`, `next`, `continue`, `callback`, `redirect`, `destination`, `target`

### 17.4 Recent OAuth Reflected XSS CVEs

- **CVE-2025-62800**: FastMCP reflected XSS in OAuth callback page — the client's callback page did not sanitize parameters reflected in the OAuth response
- **CVE-2026-77272**: MCP Atlassian reflected XSS in OAuth setup callback handler
- **CVE-2026-40302**: OpenZiti zrok reflected XSS in GitHub OAuth callback via unsanitized `refreshInterval` error rendering

**Source**: XSS-14, Vulert advisory for CVE-2025-62800, Corgea advisory for CVE-2026-77272, GitLab advisory database for CVE-2026-40302.

---

## 18. API-Documentation Reflected XSS

### 18.1 Swagger UI DOM XSS

Swagger UI renders interactive API documentation from OpenAPI specifications. Versions prior to 4.1.3 contained a DOM XSS vulnerability via the `url` and `configUrl` query parameters:

```
/swagger-ui/index.html?url=[ATTACKER_CONTROLLED_SPEC_URL]
```

The `url` parameter specifies which OpenAPI specification file to load and render. If an attacker-controlled URL is provided, the specification can contain HTML/JavaScript content that Swagger UI renders unsafely.

**Affected versions**: Swagger UI < 4.1.3
**Remediation**: Update to Swagger UI ≥ 4.1.3, restrict `url`/`configUrl` to trusted domains, or disable query parameter configuration

**HackerOne reports** (from XSS-21):
- Reports against Adobe, IBM, and U.S. Department of Defense targets
- Common pattern: Swagger UI deployed at predictable paths (`/api-docs`, `/swagger`, `/swagger-ui/`)

**Source**: XSS-21, GHSA-qrmm-w75w-3wpx, Ed-Fi advisory on Swagger XSS.

### 18.2 Other API Documentation Renderers

| Renderer | Known XSS Surface | Mitigation |
|---|---|---|
| Swagger UI (< 4.1.3) | `url`, `configUrl` query parameters | Update version, restrict URL sources |
| ReDoc | Configuration injection via query parameters | Validate configuration sources |
| GraphQL Playground / GraphiQL | Query reflection in UI | Update to latest version, restrict access |
| Postman documentation | User-generated content in published docs | Sanitization in renderer |

### 18.3 Discovery Checklist for API Documentation XSS

When testing a target application for API documentation XSS:

1. **Enumerate API doc endpoints** — check common paths:
   - `/swagger-ui/`, `/swagger-ui/index.html`
   - `/api-docs`, `/api-docs/`
   - `/swagger/`, `/swagger.json`, `/swagger.yaml`
   - `/redoc`, `/graphql`, `/graphiql`, `/graphql/playground`
   - `/docs`, `/api/docs`

2. **Check Swagger UI version** — look for version string in the page source or loaded JavaScript files

3. **Test `url` parameter** — try `?url=[UNIQUE_REFLECTION_MARKER]` and observe whether the marker appears in the page or in network requests

4. **Test `configUrl` parameter** — similar to `url`, but loads configuration rather than spec

5. **Check for query-parameter-based configuration** — some renderers accept additional query parameters that control rendering behavior

---

*Next chunk: chunk-09-framework-testing-part1.md*
