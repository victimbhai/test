# AGENT TASK: Find Missing and Conditional Sanitization Gaps
# PURPOSE: Identify code paths where DOMPurify is missing or conditionally applied
# PRIORITY: Run SECOND - easiest wins, no bypass needed
# INPUTS: Source code access or black-box testing capability
# OUTPUT: List of unsanitized sinks, conditional bypass paths, coverage gap map
# CHAPTERS: 3 (Missing Invocation), 4 (Conditional Sanitization)
---

# Chapter 3: Missing DOMPurify Invocation

## 3.1 Direct innerHTML Bypass Patterns (B1)

The most common XSS vulnerability class in applications using DOMPurify is code paths that assign to innerHTML without routing through the sanitizer. This typically occurs in:

### 3.1.1 Legacy Code

```javascript
// Legacy module written before DOMPurify was adopted
function displayNotification(message) {
  document.getElementById('notification').innerHTML = message;
}
// Called with user-controlled data from URL hash:
displayNotification(location.hash.slice(1));
```

### 3.1.2 Quick Fixes and Hotfixes

```javascript
// Hotfix that bypasses the sanitization pipeline
function renderEmergencyBanner(bannerHtml) {
  // "Temporary" bypass for urgent deployment
  document.querySelector('.banner').innerHTML = bannerHtml;
}
```

### 3.1.3 Third-Party Library Integrations

```javascript
// Third-party charting library handles its own HTML
chart.setTooltipContent(userData.tooltipHtml);
// Internally calls: tooltipDiv.innerHTML = content;
```

### 3.1.4 Event Handlers and Callbacks

```javascript
// WebSocket callback constructs HTML
socket.on('message', (data) => {
  chatDiv.innerHTML += `<div class="msg">${data.html}</div>`;
});
```

## 3.2 Raw HTML in Sibling Components (B2)

### 3.2.1 React

```jsx
// File: components/SafeComment.jsx
function SafeComment({ html }) {
  return <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(html) }} />;
}

// File: components/AdminPanel.jsx (same app, different team)
function AdminPanel({ announcements }) {
  return announcements.map(a =>
    <div dangerouslySetInnerHTML={{ __html: a.html }} /> // No sanitization
  );
}
```

### 3.2.2 Vue

```vue
<!-- Safe component -->
<template>
  <div v-html="sanitizedContent"></div>
</template>
<script>
export default {
  computed: {
    sanitizedContent() { return DOMPurify.sanitize(this.rawHtml); }
  }
}
</script>

<!-- Unsafe sibling in same app -->
<template>
  <div v-html="rawContent"></div> <!-- No sanitization -->
</template>
```

### 3.2.3 Angular

```typescript
// Safe component uses sanitization pipe
@Component({
  template: `<div [innerHTML]="content | sanitize"></div>`
})
export class SafeComponent {}

// Unsafe component bypasses Angular's sanitizer
@Component({
  template: `<div [innerHTML]="trustedHtml"></div>`
})
export class UnsafeComponent {
  constructor(private sanitizer: DomSanitizer) {}
  get trustedHtml() {
    return this.sanitizer.bypassSecurityTrustHtml(this.rawHtml);
  }
}
```

## 3.3 Different Wrapper Policies (B3)

```javascript
// utils/sanitizers.js
export const sanitizeStrict = (html) => DOMPurify.sanitize(html, {
  ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p', 'br'],
  ALLOWED_ATTR: []
});

export const sanitizeRich = (html) => DOMPurify.sanitize(html, {
  ADD_TAGS: ['iframe', 'embed', 'object'],
  ADD_ATTR: ['target', 'allowfullscreen', 'frameborder', 'srcdoc'],
  ALLOW_UNKNOWN_PROTOCOLS: true
});

// Developer chooses the wrong wrapper:
import { sanitizeRich } from './sanitizers';
commentDiv.innerHTML = sanitizeRich(userComment); // Should be sanitizeStrict
```

## 3.4 Detection Methodology: Source-to-Sink Analysis

### 3.4.1 Step 1: Enumerate All HTML Sinks

Search the codebase for every location where strings become DOM:

**Direct DOM API sinks:**
- `innerHTML`, `outerHTML`
- `insertAdjacentHTML()`
- `document.write()`, `document.writeln()`

**Framework sinks:**
- React: `dangerouslySetInnerHTML`
- Vue: `v-html`
- Angular: `bypassSecurityTrustHtml`, `[innerHTML]`
- Svelte: `{@html ...}`

**jQuery sinks:**
- `.html()`, `.append()`, `.prepend()`, `.after()`, `.before()`, `.replaceWith()`
- `$.parseHTML()`

**Other sinks:**
- `DOMParser.parseFromString()`
- `createContextualFragment()`
- `Range.createContextualFragment()`
- `srcdoc` attribute on `<iframe>`

### 3.4.2 Step 2: Trace Each Sink's Data Source Backward

For each sink, trace the variable back through assignments, function returns, and data flow:

1. What variable is assigned to the sink?
2. Where does that variable get its value?
3. Does it pass through `DOMPurify.sanitize()` on **every** code path?
4. Are there conditional branches that bypass sanitization?

### 3.4.3 Step 3: Identify Unprotected Paths

Look for:
- Direct assignments from API responses, database queries, or user input
- Conditional sanitization (Model C patterns)
- Error handling fallbacks that bypass sanitization
- Template strings combining sanitized and unsanitized content

## 3.5 Code Search Patterns

### 3.5.1 grep/ripgrep Rules

```bash
# Find innerHTML assignments not preceded by DOMPurify.sanitize
rg '\.innerHTML\s*=' --type js --type ts -l

# Find insertAdjacentHTML calls
rg 'insertAdjacentHTML' --type js --type ts -l

# Find document.write calls
rg 'document\.write(ln)?\(' --type js --type ts -l

# Find jQuery .html() calls
rg '\.html\(' --type js --type ts -l

# Find React dangerouslySetInnerHTML without sanitize
rg 'dangerouslySetInnerHTML' --type jsx --type tsx -l

# Find Vue v-html directives
rg 'v-html' --type vue -l

# Find Angular bypass
rg 'bypassSecurityTrustHtml' --type ts -l

# Find Svelte @html
rg '\{@html' --type svelte -l
```

### 3.5.2 Semgrep Rules

```yaml
# Detect innerHTML without DOMPurify
rules:
  - id: innerHTML-without-dompurify
    pattern: |
      $X.innerHTML = $Y;
    pattern-not: |
      $X.innerHTML = DOMPurify.sanitize($Y);
    pattern-not: |
      $X.innerHTML = sanitize($Y);
    message: "innerHTML assignment without DOMPurify sanitization"
    severity: ERROR
    languages: [javascript, typescript]

  - id: react-dangerously-without-sanitize
    pattern: |
      dangerouslySetInnerHTML={{ __html: $X }}
    pattern-not: |
      dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize($X) }}
    message: "dangerouslySetInnerHTML without DOMPurify"
    severity: ERROR
    languages: [javascript, typescript, jsx, tsx]

  - id: vue-v-html-without-sanitize
    pattern: |
      v-html="$X"
    pattern-not: |
      v-html="sanitized$X"
    message: "v-html without sanitization"
    severity: WARNING
    languages: [html]

  - id: angular-bypass-security
    pattern: |
      this.$SANITIZER.bypassSecurityTrustHtml($X)
    message: "Angular security bypass - ensure input is sanitized"
    severity: ERROR
    languages: [typescript]
```

## 3.6 Framework-Specific Detection

### 3.6.1 React: dangerouslySetInnerHTML Without Sanitize

```bash
# Find all uses and check if sanitized
rg -n 'dangerouslySetInnerHTML' --type tsx --type jsx | \
  grep -v 'DOMPurify\|sanitize\|purify'
```

### 3.6.2 Vue: v-html Without Sanitize

```bash
# Find v-html in Vue templates
rg -n 'v-html=' --type vue | \
  grep -v 'sanitize\|purify\|clean'
```

### 3.6.3 Angular: bypassSecurityTrustHtml

```bash
# Every use of bypassSecurityTrustHtml should be audited
rg -n 'bypassSecurityTrustHtml' --type ts
```

### 3.6.4 Svelte: {@html}

```bash
# Find @html directives
rg -n '\{@html' --type svelte
```

## 3.7 jQuery .html() Detection

```bash
# Find jQuery .html() with arguments (setting HTML)
rg '\.html\([^)]+\)' --type js --type ts | \
  grep -v 'DOMPurify\|sanitize\|\.html()\s*$'
```

jQuery's `.html()` method is particularly dangerous because:
- It accepts HTML strings and parses them into DOM
- CVE-2020-11022 showed jQuery-specific parsing differences
- Self-closing tags in attribute values can create XSS through jQuery < 3.5.0

## 3.8 Remediation

### 3.8.1 Wrapper Function Pattern

```javascript
// lib/sanitize.js -- single point of enforcement
import DOMPurify from 'dompurify';

const DEFAULT_CONFIG = Object.freeze({
  USE_PROFILES: { html: true },
  FORBID_TAGS: ['style', 'form'],
  FORBID_ATTR: ['style'],
  RETURN_DOM_FRAGMENT: true,
});

export function sanitizeHTML(dirty) {
  return DOMPurify.sanitize(String(dirty), DEFAULT_CONFIG);
}

export function sanitizeToString(dirty) {
  return DOMPurify.sanitize(String(dirty), {
    ...DEFAULT_CONFIG,
    RETURN_DOM_FRAGMENT: false,
  });
}
```

### 3.8.2 ESLint Rules

```javascript
// .eslintrc.js
module.exports = {
  rules: {
    'no-restricted-properties': ['error',
      { object: 'document', property: 'write', message: 'Use sanitized DOM APIs' },
      { property: 'innerHTML', message: 'Use sanitizeHTML() wrapper' },
      { property: 'outerHTML', message: 'Use sanitizeHTML() wrapper' },
    ],
    'no-restricted-globals': ['error',
      { name: 'document.write', message: 'Use sanitized DOM APIs' },
    ],
  }
};
```

### 3.8.3 Framework-Level Enforcement

**React:** Create a `SafeHTML` component that wraps all `dangerouslySetInnerHTML` usage:

```jsx
function SafeHTML({ html, config }) {
  return (
    <div
      dangerouslySetInnerHTML={{
        __html: DOMPurify.sanitize(html, config || DEFAULT_CONFIG)
      }}
    />
  );
}
```

**Vue:** Create a global directive:

```javascript
Vue.directive('safe-html', {
  bind(el, binding) {
    el.innerHTML = DOMPurify.sanitize(binding.value);
  },
  update(el, binding) {
    el.innerHTML = DOMPurify.sanitize(binding.value);
  }
});
```

**Angular:** Create a sanitization pipe:

```typescript
@Pipe({ name: 'sanitize' })
export class SanitizePipe implements PipeTransform {
  transform(value: string): SafeHtml {
    return DOMPurify.sanitize(value);
  }
}
```

---

# Chapter 4: Conditional Sanitization and Coverage Gaps

## 4.1 Conditional Sanitization Patterns (C1-C7)

### 4.1.1 C1: Trust Flags

**Pattern:** Boolean flags that control whether sanitization is applied.

```javascript
function renderContent(html, options = {}) {
  if (options.isTrusted || options.isSafe || options.allowHtml) {
    return html;
  }
  return DOMPurify.sanitize(html);
}
```

**Why this is dangerous:**
- The flag may be set based on the content source, which can change over time
- The flag may be inherited from a parent component's props without validation
- The flag may default to `true` in development but `false` in production (or vice versa)
- If the flag is derived from user-controlled input (query parameter, cookie), attackers bypass sanitization directly

**Exploitation:**
```javascript
// If the flag comes from a cookie:
document.cookie = 'trusted=true';
// Or from a URL parameter:
// https://example.com/page?trusted=true
// Or from localStorage:
localStorage.setItem('renderMode', 'trusted');
```

**Detection:**
```yaml
# Semgrep rule for conditional sanitization
rules:
  - id: conditional-sanitization
    patterns:
      - pattern: |
          if ($CONDITION) { return $INPUT; }
          ...
          return DOMPurify.sanitize($INPUT);
    message: "Conditional sanitization - verify $CONDITION cannot be attacker-controlled"
    severity: WARNING
```

### 4.1.2 C2: Role-Based Sanitization Bypass

**Pattern:** Admin or privileged-role checks that skip sanitization.

```javascript
function processComment(comment, user) {
  if (user.isAdmin || user.role === 'editor') {
    return comment.html;
  }
  return DOMPurify.sanitize(comment.html);
}
```

**Case study -- Drupal CVE-2026-13231:** The Drupal Admin Feedback Module had insufficient input sanitization tied to administrative contexts. Admin-authored content was displayed to all users without re-sanitization, turning a compromised admin account into a stored XSS vector affecting every site visitor.

**Why role-based bypass is dangerous:**
1. **Compromised admin accounts:** If an admin account is compromised (phishing, credential stuffing), the attacker gets stored XSS affecting all users
2. **Privilege escalation:** Role checks may be bypassable via IDOR, JWT manipulation, or authorization bugs
3. **Display context:** Admin-authored content displayed to non-admin users is never re-sanitized
4. **Client-side role checks:** Trivially spoofed by modifying JavaScript or intercepting API responses

**Remediation:**
```javascript
// Always sanitize, use different policies for different roles
function processComment(comment, user) {
  const config = user.isAdmin
    ? ADMIN_SANITIZE_CONFIG  // More permissive, but still sanitizes
    : USER_SANITIZE_CONFIG;  // Restrictive
  return DOMPurify.sanitize(comment.html, config);
}
```

### 4.1.3 C3: Feature Flag-Dependent Sanitization

**Pattern:** Feature flags that toggle sanitization behavior.

```javascript
function sanitize(html) {
  if (featureFlags.get('use_new_sanitizer')) {
    return newSanitizer.clean(html); // May have bugs
  }
  if (featureFlags.get('skip_sanitization_for_performance')) {
    return html; // Performance A/B test removes security
  }
  return DOMPurify.sanitize(html);
}
```

**Why this is dangerous:**
- Feature flags create combinatorial explosion of code paths
- A flag that disables sanitization for a subset of users (A/B testing) exposes those users to XSS
- Flag management tools (LaunchDarkly, Split, etc.) may have their own vulnerabilities
- Gradual rollouts mean some users are unprotected during the transition

**Remediation:** Never feature-flag sanitization itself. Feature-flag the sanitizer **configuration** if needed, but every path must sanitize.

### 4.1.4 C4: Content-Type-Based Decisions

**Pattern:** Sanitization depends on content type or MIME type.

```javascript
function processContent(content, contentType) {
  switch (contentType) {
    case 'text/plain':
      return escapeHtml(content);
    case 'text/html':
      return DOMPurify.sanitize(content);
    case 'text/markdown':
      return markdownToHtml(content); // No sanitization!
    case 'application/json':
      return JSON.stringify(content); // May contain HTML in values
    default:
      return content; // Unknown type, no sanitization
  }
}
```

**Exploitation:** If the attacker controls the `contentType` (via Content-Type header manipulation, multipart form fields, API parameters), they route HTML through a non-sanitizing path.

**Remediation:**
```javascript
function processContent(content, contentType) {
  let html;
  switch (contentType) {
    case 'text/plain':
      html = escapeHtml(content);
      break;
    case 'text/markdown':
      html = markdownToHtml(content);
      break;
    default:
      html = content;
  }
  return DOMPurify.sanitize(html); // Always sanitize the final HTML
}
```

### 4.1.5 C5: Cache/Memoization Returning Unsanitized Content

**Pattern:** Caching layers that store content before sanitization or return stale versions.

```javascript
const contentCache = new Map();

function getContent(id) {
  if (contentCache.has(id)) {
    return contentCache.get(id); // May be unsanitized
  }
  const raw = database.get(id);
  const sanitized = DOMPurify.sanitize(raw);
  contentCache.set(id, raw);   // BUG: Caches raw, not sanitized!
  return sanitized;            // First call safe, subsequent calls vulnerable
}
```

**Case study -- GitLab Issue #357930:** Sanitized HTML was cached. When the sanitizer policy was updated to fix a vulnerability, cached content was not re-sanitized, leaving old XSS payloads intact and serving them to users.

**React memoization variant:**
```javascript
// VULNERABLE: Memoized without sanitization
const memoizedHtml = useMemo(() => content, [content]);
// Should be:
const memoizedHtml = useMemo(() => DOMPurify.sanitize(content), [content]);
```

**Remediation:**
- Always cache the sanitized output, never the raw input
- Include the sanitizer version and config hash in cache keys
- Implement cache invalidation when sanitizer policies change
- Set TTLs on cached sanitized content

### 4.1.6 C6: Error Handling Returning Raw Input

**Pattern:** Exception handling that falls back to unsanitized content.

```javascript
function sanitize(html) {
  try {
    return DOMPurify.sanitize(html);
  } catch (error) {
    console.error('Sanitization failed:', error);
    return html; // CRITICAL: Returns raw input
  }
}
```

**Promise chain variant:**
```javascript
sanitizeAsync(html)
  .then(clean => render(clean))
  .catch(() => render(html)); // Fallback renders raw
```

**Why DOMPurify might throw:**
- Prototype pollution causing `TypeError` in cached getters
- Memory limits on extremely large inputs
- DOM manipulation errors in edge cases
- `IN_PLACE` mode with clobbered root elements

**Remediation:**
```javascript
function sanitize(html) {
  try {
    return DOMPurify.sanitize(html);
  } catch (error) {
    console.error('Sanitization failed:', error);
    return ''; // Safe fallback: empty string
  }
}
```

### 4.1.7 C7: Attacker-Controlled Flags

**Pattern:** Sanitization decisions based on data the attacker can influence.

```javascript
// URL parameter
app.post('/render', (req, res) => {
  const { content, format } = req.body;
  if (format === 'raw') {
    res.send(content); // Attacker sends format=raw
  } else {
    res.send(DOMPurify.sanitize(content));
  }
});
```

**Attack vectors for controlling flags:**
- **Query parameters:** `?format=raw`, `?trusted=true`
- **HTTP headers:** Custom headers like `X-Trust-Content: true`
- **Cookies:** `renderMode=trusted`
- **localStorage/sessionStorage:** `localStorage.setItem('sanitize', 'false')`
- **Database fields:** Modified via IDOR, SQL injection, or compromised admin
- **postMessage:** Cross-origin message with a `trusted` field

**Remediation:** Never derive sanitization decisions from user-controlled input. Sanitization must be unconditional.

## 4.2 Coverage Gap Patterns (B4-B13)

### 4.2.1 B4: Sanitize-on-Render-Not-Update

```javascript
class CommentWidget extends React.Component {
  componentDidMount() {
    // Sanitized on initial render
    this.setState({ html: DOMPurify.sanitize(this.props.content) });
  }

  componentDidUpdate(prevProps) {
    if (prevProps.content !== this.props.content) {
      // NOT sanitized on update
      this.container.innerHTML = this.props.content;
    }
  }

  render() {
    return <div ref={el => this.container = el}
                dangerouslySetInnerHTML={{ __html: this.state.html }} />;
  }
}
```

**Why this happens:** Performance optimization. Developers sanitize on mount but skip it on updates, assuming content was already sanitized. This fails when:
- Props change to contain user-controlled data
- The data source changes between initial load and updates
- WebSocket/SSE delivers unsanitized updates

### 4.2.2 B5: Preview-Sanitized-But-Published-Not

```javascript
// CMS workflow:
// 1. Author writes content
// 2. Preview sanitizes for display
// 3. Publish stores raw content
// 4. View renders raw content to all visitors

// Preview (safe):
app.get('/preview', (req, res) => {
  const preview = DOMPurify.sanitize(req.body.html);
  res.render('preview', { content: preview });
});

// Publish (stores raw):
app.post('/publish', (req, res) => {
  db.articles.insert({ html: req.body.html }); // Raw
  res.redirect('/article/' + id);
});

// View (serves raw to all users):
app.get('/article/:id', (req, res) => {
  const article = db.articles.findById(req.params.id);
  res.render('article', { content: article.html }); // Unsanitized
});
```

### 4.2.3 B6: Sanitize-During-Editing-Skip-Viewing

```javascript
// Editor component: sanitizes on every change
editor.on('change', (content) => {
  const clean = DOMPurify.sanitize(content);
  editor.setContent(clean);
  saveToDatabase(clean);
});

// Viewer component: trusts database
function ArticleViewer({ article }) {
  return <div dangerouslySetInnerHTML={{ __html: article.html }} />;
}
```

**Bypass paths:**
- Direct API call to save endpoint (bypasses editor)
- Database modification (admin panel, migration script)
- Content import from external source
- API accepts HTML in fields not connected to the editor

### 4.2.4 B7: Mobile vs Desktop Differences

| Surface | Sanitization | Risk |
|---------|-------------|------|
| Desktop web | DOMPurify in React SPA | Protected |
| Mobile web | Same SPA, different route | May skip sanitization in mobile-specific components |
| iOS app (WebView) | Native code renders HTML | May not invoke DOMPurify |
| Android app (WebView) | Native code renders HTML | May not invoke DOMPurify |
| AMP pages | Stripped sanitizer for performance | Unprotected |
| Email digest | Server-side rendering | Different sanitization policy |

### 4.2.5 B9: Cached HTML Under Old Policy

```javascript
// Redis cache with no policy versioning
const cacheKey = `rendered:${articleId}`;
let html = await redis.get(cacheKey);
if (!html) {
  html = DOMPurify.sanitize(article.rawHtml, CURRENT_POLICY);
  await redis.set(cacheKey, html, 'EX', 86400); // 24-hour TTL
}
element.innerHTML = html;
```

**Problem:** If DOMPurify is updated or the policy changes, cached content from the old policy is served for up to 24 hours. A payload that the old policy allowed but the new policy blocks remains live.

**Remediation:** Include a policy version in the cache key:

```javascript
const policyVersion = crypto.createHash('md5')
  .update(JSON.stringify(CURRENT_POLICY) + DOMPURIFY_VERSION)
  .digest('hex').slice(0, 8);
const cacheKey = `rendered:${policyVersion}:${articleId}`;
```

### 4.2.6 B10: API Responses as Trusted

```javascript
// VULNERABLE: API response treated as pre-sanitized
fetch('/api/comments')
  .then(res => res.json())
  .then(data => {
    commentsDiv.innerHTML = data.html;
  });
```

**Case study -- Firefly III CVE-2024-22075:** A client-side path traversal routed a page's request to another API endpoint. The error response reflected attacker input in its JSON `message` field, which was rendered as raw HTML via `v-html`. The application trusted its own API responses, but the API endpoint reflected user input.

**Remediation:** Sanitize API responses on the client, even from your own API:

```javascript
fetch('/api/comments')
  .then(res => res.json())
  .then(data => {
    commentsDiv.innerHTML = DOMPurify.sanitize(data.html);
  });
```

### 4.2.7 B11: Imported/Migrated Content

Sources of unsanitized content entering the system:

| Source | Risk | Example |
|--------|------|---------|
| CSV/Excel import | HTML in text fields | `<img src=x onerror=alert(1)>` in "description" column |
| Database migration | Legacy system had no sanitization | Migrating from a system that stored raw HTML |
| RSS/Atom feeds | Syndicated content with scripts | Feed from compromised source |
| Content APIs | Third-party reviews, comments | Google reviews, Yelp descriptions |
| File uploads | HTML files served directly | User uploads `malicious.html` |
| Email ingest | Email body parsed as HTML | Email-to-ticket systems |

### 4.2.8 B12: Error/Fallback Components

```javascript
// React error boundary with unsanitized error rendering
class ErrorBoundary extends React.Component {
  componentDidCatch(error, errorInfo) {
    this.setState({
      errorHtml: `<div class="error">
        <h2>Something went wrong</h2>
        <pre>${error.message}</pre>
        <details>${errorInfo.componentStack}</details>
      </div>`
    });
  }

  render() {
    if (this.state.errorHtml) {
      return <div dangerouslySetInnerHTML={{ __html: this.state.errorHtml }} />;
    }
    return this.props.children;
  }
}
```

**Exploitation:** If `error.message` contains attacker-controlled content (from a malformed API response, crafted URL, or manipulated data), this is a direct XSS vector in the error handling path.

### 4.2.9 B13: SSR vs Client Rendering Differences

```javascript
// Server-side: sanitizes with jsdom (scripting disabled)
const serverHtml = DOMPurify.sanitize(content);
// <noscript> content is parsed as HTML on server

// Client-side: browser with scripting enabled
// <noscript> content is treated as raw text
// Same HTML string, different DOM tree
```

The `<noscript>` element is the most visible parsing difference between jsdom (server-side) and browsers (client-side). This affects sanitization coverage because:

1. jsdom parses `<noscript>` content as HTML (can see and sanitize elements inside)
2. Browsers with scripting enabled treat `<noscript>` content as raw text (elements inside are inert)
3. A payload that is sanitized on the server (where it is visible) may behave differently when the browser parses the sanitized string

---
