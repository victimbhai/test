# Agent Chunk 11: Sanitization, CSP & Browser Defenses

**Agent Task:** Understand output encoding requirements for each context (OWASP 6 contexts), safe rendering APIs, DOMPurify's role and limitations, CSP defense-in-depth configuration, Trusted Types (Chromium-only), and why a CSP-blocked test is not proof of XSS.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 20. Sanitization and Output Encoding

### 20.1 Context-Specific Output Encoding

The OWASP XSS Prevention Cheat Sheet (PRIMARY-EXTERNAL, verified) defines encoding requirements by output context:

| Output Context | Required Encoding | Unsafe If Missing |
|---|---|---|
| HTML body (text content) | HTML entity encoding: `<` → `&lt;`, `>` → `&gt;`, `&` → `&amp;`, `"` → `&quot;`, `'` → `&#x27;` | Tag injection |
| HTML attribute (quoted) | HTML attribute encoding (same as above + attribute-specific) | Attribute breakout |
| JavaScript string | JavaScript string encoding: `'` → `\'`, `"` → `\"`, `\` → `\\`, newlines → `\n`, `</script>` → `<\/script>` or `\x3C/script>` | String breakout, script termination |
| URL parameter | URL encoding (percent-encoding): `<` → `%3C`, `"` → `%22` | URL injection |
| CSS value | CSS encoding: alphanumeric unchanged, others → `\HH` or `\HHHHHH` | CSS injection (limited modern risk) |
| JSON value | JSON encoding: `"` → `\"`, `\` → `\\`, `/` → `\/`, control chars → `\uXXXX`, `<` → `<` | JSON structure breakout, script termination |

**Critical rule**: Encoding must match the FINAL interpretation context. HTML-encoding a value that ends up inside a JavaScript string context is insufficient — the JavaScript engine does not process HTML entities within `<script>` blocks.

**Anti-pattern**: Using a single encoding function for all contexts. Each context requires its own encoder.

### 20.2 Safe Rendering Primitives

Instead of encoding, prefer safe APIs that inherently prevent XSS:

| Operation | Safe API | Unsafe API |
|---|---|---|
| Insert text | `element.textContent = value` | `element.innerHTML = value` |
| Insert text | `document.createTextNode(value)` | `document.write(value)` |
| Set attribute | `element.setAttribute('data-x', value)` (safe attributes only) | `element.setAttribute('onclick', value)` |
| Create element | `document.createElement('div')` | Writing raw HTML strings |
| Handle events | `element.addEventListener('click', handler)` | `element.onclick = userInput` |

**Source**: OWASP XSS Prevention Cheat Sheet, OWASP DOM XSS Prevention Cheat Sheet.

### 20.3 HTML Sanitization with DOMPurify

DOMPurify is the most widely used client-side HTML sanitizer. It uses the browser's own HTML parser to parse input, walks the resulting DOM tree, removes unsafe elements and attributes, and serializes the result.

**When to use sanitization vs. encoding**:
- **Encoding**: When the application needs to display user input as text (the vast majority of cases)
- **Sanitization**: When the application intentionally allows user-provided rich HTML (WYSIWYG editors, Markdown rendering, email display)

**DOMPurify configuration considerations**:
- Default configuration removes all potentially dangerous elements and attributes
- `SAFE_FOR_TEMPLATES: true` — additional protections for template expressions (subject to CVE-2025-26791)
- `SAFE_FOR_XML: true` — protections against RAWTEXT element breakout
- Custom `ALLOWED_TAGS` and `ALLOWED_ATTR` — can weaken security if misconfigured
- `ADD_URI_SAFE_ATTR` — adds attributes to the URL-safe list
- `RETURN_DOM` / `RETURN_DOM_FRAGMENT` — returns DOM nodes instead of strings (avoids serialization/reparsing mXSS)

**Key principle**: DOMPurify is relevant only when intentionally rendering untrusted HTML. The absence of DOMPurify is NOT a vulnerability — most reflected values should use context-specific encoding or safe text rendering, not HTML sanitization.

**Source**: OWASP XSS Prevention Cheat Sheet, DOMPurify documentation, DOMPurify wiki.

---

## 21. CSP, Trusted Types and Browser Defenses

### 21.1 Content Security Policy as Defense in Depth

CSP is a defense-in-depth mechanism that restricts the sources from which a page can load resources. It does NOT replace proper output encoding or sanitization.

**CSP directives relevant to reflected XSS**:

| Directive | Effect on Reflected XSS | Configuration |
|---|---|---|
| `script-src` | Controls which scripts can execute | `'nonce-{random}'` or `'strict-dynamic'` |
| `script-src 'unsafe-inline'` | **DEFEATS** inline script restrictions | Avoid — allows reflected XSS to execute |
| `script-src 'unsafe-eval'` | Allows `eval()`, `setTimeout(string)`, `Function(string)` | Avoid — expands attack surface |
| `default-src` | Fallback for all resource types | Set restrictive default |
| `object-src 'none'` | Blocks plugins (Flash, Java) | Always include |
| `base-uri 'self'` | Prevents `<base>` tag hijacking | Always include |
| `require-trusted-types-for 'script'` | Enforces Trusted Types | Chromium-only (see Section 21.2) |

**CSP bypass patterns** (conceptual, not operational):
- `script-src 'self'` with a JSONP endpoint on the same origin
- `script-src` with a CDN that hosts user-uploadable content
- `script-src 'strict-dynamic'` with a trusted script that creates new script elements from user input
- Missing `base-uri` allows `<base>` tag to redirect relative script loads
- `report-only` mode does not block execution

**Key insight from OWASP**: "CSP should be used as defense in depth, customized per application. It is not a primary defense."

### 21.2 Trusted Types

Trusted Types is a browser API (W3C specification) that prevents DOM-based XSS by requiring all values assigned to dangerous DOM sinks to be created through trusted policy functions.

**Browser support** (as of research date):
- Chrome/Edge: Supported since Chrome 83 (2020)
- Firefox: Not yet supported (under consideration)
- Safari: Not yet supported

**Deployment**:
```
Content-Security-Policy: require-trusted-types-for 'script'
```

When enforced, the browser rejects plain strings assigned to dangerous sinks like `innerHTML`, `outerHTML`, `document.write()`, `eval()`, `setTimeout(string)`, and `script.src`. Only values created by registered Trusted Type policies are accepted.

**Limitation**: Trusted Types protect against DOM XSS sinks but do not directly prevent server-side reflected XSS. They are most effective when combined with CSP and proper output encoding.

### 21.3 X-Content-Type-Options

The `X-Content-Type-Options: nosniff` header prevents browsers from MIME-sniffing a response's Content-Type. Without it, a response served as `application/json` might be sniffed as `text/html` by older browsers, enabling XSS.

### 21.4 Obsolete X-XSS-Protection

The `X-XSS-Protection` header controlled browser-built-in XSS filters:
- **Chrome**: XSS Auditor removed in Chrome 78 (July 2019)
- **Edge**: XSS filter removed when Edge moved to Chromium
- **Firefox**: Never implemented an XSS filter
- **Safari**: Removed in Safari 13 (2019)

**Current recommendation**: Do NOT use `X-XSS-Protection`. Setting it on modern browsers has no effect, and on older browsers it could be exploited for information leakage.

### 21.5 Why a Blocked Test Is Not Proof of XSS

If a CSP blocks inline script execution during testing, this means:
1. The CSP is providing defense in depth (good)
2. The underlying injection flaw may still exist (the value is reflected without proper encoding)
3. The injection flaw should still be remediated because:
   - CSP can be weakened by future configuration changes
   - CSP bypass techniques exist
   - Not all browsers enforce all CSP directives
   - The CSP may be in `report-only` mode

Conversely, an injection flaw blocked by CSP should not be classified as the same severity as one that achieves script execution.

---

*Next chunk: chunk-12-lab-methodology.md*
