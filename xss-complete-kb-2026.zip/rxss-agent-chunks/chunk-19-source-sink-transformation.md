# Agent Chunk 19: Source-to-Sink Methodology & Reflection-Context Matrix

**Agent Task:** Use the source-to-sink trace methodology to map every data flow from HTTP request to browser rendering. For each framework, follow the specific call-graph pattern to identify the dangerous escape hatches. Use the reflection-context matrix as a lookup table to determine the required encoding and common failure mode for each input-source/context combination.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 37. Source-to-Sink and Framework Call-Graph Methodology

### 37.1 General Source-to-Sink Trace

For each reflected XSS investigation, trace the full data flow:

```
HTTP REQUEST
│
├── SOURCE: Where user input enters
│   ├── request.query.param (query parameter)
│   ├── request.params.param (path parameter)
│   ├── request.body.field (POST body)
│   ├── request.headers['x-header'] (HTTP header)
│   └── request.cookies.name (cookie)
│
├── BINDING: How framework captures the value
│   ├── Express: req.query.q, req.params.id, req.body.name
│   ├── Django: request.GET['q'], request.POST['name']
│   ├── Spring: @RequestParam, @PathVariable
│   ├── Rails: params[:q]
│   └── Next.js: searchParams.q, params.id
│
├── PROCESSING: What happens to the value
│   ├── Validation (allowlist? blocklist? regex?)
│   ├── Normalization (trim? lowercase? Unicode?)
│   ├── Database query (select? insert? → stored XSS)
│   ├── Business logic (concatenation? formatting?)
│   └── Error handling (does error path use same encoding?)
│
├── RENDERING: How the value enters the response
│   ├── Template interpolation (auto-escaped? raw?)
│   ├── String concatenation (manual HTML construction)
│   ├── JSON serialization (json.dumps? JSON.stringify?)
│   ├── Error template (same escaping as main templates?)
│   └── Redirect header (any CRLF filtering?)
│
└── SINK: Where the value appears in the browser
    ├── HTML text content (data state)
    ├── HTML attribute value (quoted? unquoted?)
    ├── JavaScript string (in <script> block)
    ├── URL (href, src, action)
    ├── Event handler (onclick, onerror)
    ├── Inline JSON (inside <script> tag)
    └── CSS value (inside <style> tag)
```

### 37.2 Framework-Specific Source-to-Sink Patterns

#### Python/Django
```
Source: request.GET['q']
Binding: view function parameter
Processing: business logic
Rendering: {{ q }} in Django template → AUTO-ESCAPED by default
    DANGER: {{ q|safe }} or {% autoescape off %} → RAW
Sink: HTML text content
```

#### Python/Flask+Jinja2
```
Source: request.args.get('q')
Binding: view function
Processing: business logic
Rendering: {{ q }} in Jinja2 template → AUTO-ESCAPED by default
    DANGER: {{ q|safe }} or Markup(q) → RAW
Sink: HTML text content
```

#### Node.js/Express+EJS
```
Source: req.query.q
Binding: route handler
Processing: business logic
Rendering: <%= q %> → HTML-ESCAPED
    DANGER: <%- q %> → RAW (unescaped)
Sink: HTML text content
```

#### PHP/Laravel+Blade
```
Source: request()->input('q')
Binding: controller method
Processing: business logic
Rendering: {{ $q }} → HTML-ESCAPED via htmlspecialchars()
    DANGER: {!! $q !!} → RAW (unescaped)
Sink: HTML text content
```

#### Ruby/Rails+ERB
```
Source: params[:q]
Binding: controller action
Processing: business logic
Rendering: <%= q %> → HTML-ESCAPED (Rails 3+)
    DANGER: raw(q) or q.html_safe → RAW (unescaped)
Sink: HTML text content
```

#### Java/Spring+Thymeleaf
```
Source: @RequestParam String q
Binding: controller method parameter
Processing: business logic
Rendering: th:text="${q}" → HTML-ESCAPED
    DANGER: th:utext="${q}" → RAW (unescaped)
Sink: HTML text content
```

#### Go html/template
```
Source: r.URL.Query().Get("q")
Binding: handler function
Processing: business logic
Rendering: {{.Q}} → CONTEXT-AWARE auto-escaping
    DANGER: template.HTML(q) → declared safe
Sink: Depends on template position (Go auto-selects encoder by context)
```

---

## 38. Reflection-Context and Transformation Knowledge Matrix

| Input Source | Typical Reflection Context | Key Transformations | Required Encoding | Common Failure Mode |
|---|---|---|---|---|
| Query parameter → search results | HTML data (text content) | URL decode → template interpolation | HTML entity encoding | Missing encoding in search results heading |
| Query parameter → page title | RCDATA (`<title>`) | URL decode → template interpolation | HTML entity encoding + `</title>` prevention | `</title>` breakout |
| Query parameter → input value | HTML attribute (quoted) | URL decode → template interpolation | HTML attribute encoding | Missing quote encoding allows breakout |
| Query parameter → inline JS | JavaScript string | URL decode → JS string interpolation | JavaScript encoding + `</script>` prevention | HTML encoding used instead of JS encoding |
| Query parameter → redirect URL | URL attribute (href) | URL decode → URL construction | URL validation + HTML attribute encoding | No protocol validation allows javascript: |
| Query parameter → inline JSON | JSON value in `<script>` | URL decode → JSON serialization | JSON encoding + `</script>` prevention | Missing `</script>` prevention |
| Form field → error message | HTML data | Form decode → error template | HTML entity encoding | Error template lacks auto-escaping |
| Path segment → breadcrumb | HTML data | URL decode → routing → template | HTML entity encoding | Framework passes raw path to template |
| OAuth parameter → error page | HTML data or URL attribute | URL decode → OAuth validation → error template | HTML entity encoding | OAuth error params reflected raw |
| Header → error page | HTML data | Header parsing → error template | HTML entity encoding | Error template reflects headers unsafely |
| Cookie → welcome message | HTML data | Cookie parsing → template | HTML entity encoding | Cookie value reflected without encoding |
| JSON body → API error | Depends on rendering | JSON parse → error handler → response | Context-dependent | JSON error reflected in HTML error page |
| API doc config → Swagger UI | DOM (innerHTML) | URL decode → client-side fetch → DOM | URL validation + sanitization | No URL validation in Swagger UI < 4.1.3 |
| Hydration data → inline JSON | JSON in `<script>` | Framework serialization | JSON + `</script>` prevention | Framework serialization bug |

---

*Next chunk: chunk-20-dompurify-cve-confidence-resume.md*
