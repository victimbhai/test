# 69 - API Error Handling XSS

## Overview

API error handling introduces XSS through:
- Stack trace and debug page reflection of request parameters
- Validation error messages echoing user input without encoding
- 404/500 error pages reflecting the requested path or query parameters
- Rate limit response pages including request details
- JSON parse error messages reflecting raw input
- API version string reflection in error messages

## Stack Trace Reflection XSS

Framework debug pages (Django DEBUG=True, Rails development mode, Express error handler with stack traces, Laravel APP_DEBUG=true) that display request paths, parameters, or bodies are XSS vectors when accidentally left enabled in production.

```python
# VULNERABLE: Django DEBUG=True in production
# The debug error page renders request.GET, request.POST, and
# request.path without HTML encoding
# Attack: any URL that triggers a 500 error with XSS in the path

# VULNERABLE: Express error handler with stack traces
app.use((err, req, res, next) => {
  res.status(500).send(`
    <h1>Error</h1>
    <p>Path: ${req.originalUrl}</p>
    <pre>${err.stack}</pre>
  `);
  // Reflected XSS via URL path
});

# SAFE: Generic error page without request reflection
app.use((err, req, res, next) => {
  console.error(err.stack);  // Log server-side only
  res.status(500).json({ error: 'Internal server error' });
});
```

## Validation Error Message XSS

### LibreChat JSON Parse Error (GHSA-q6c5-gvj5-c264)

Invalid JSON payloads in API requests were reflected entirely in the HTTP response, leading to XSS risk when the user includes HTML/JavaScript code in the request body. The advisory states "user supplied input in error messages on a production application should not need to be reflected at all."

```http
# Attack: Send invalid JSON that gets reflected in error
POST /api/chat HTTP/1.1
Content-Type: application/json

<script>alert(document.cookie)</script>

# Response (if Content-Type is text/html):
# HTTP/1.1 400 Bad Request
# Content-Type: text/html
#
# Parse error: unexpected token '<script>alert(document.cookie)</script>'
```

### GraphQL Error Message Reflection

GraphQL error responses can contain reflected user input in the `message` field. If the frontend renders error messages via innerHTML, XSS results.

```javascript
// VULNERABLE: Rendering GraphQL errors without encoding
fetch('/graphql', { body: maliciousQuery })
  .then(r => r.json())
  .then(data => {
    if (data.errors) {
      errorDiv.innerHTML = data.errors[0].message;
      // If message contains: "Invalid input '<script>alert(1)</script>'"
      // XSS fires
    }
  });

// SAFE: Use textContent or structured error display
errorDiv.textContent = data.errors[0].message;
```

### Serializer Validation Error Rendering

DRF serializer validation errors returned as JSON are safe by default. When a custom exception handler renders these errors in HTML, unsanitized field names or error messages produce XSS.

```python
# VULNERABLE: Custom exception handler rendering errors as HTML
def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)
    if response is not None:
        html = "<ul>"
        for field, errors in response.data.items():
            html += f"<li>{field}: {', '.join(str(e) for e in errors)}</li>"
        html += "</ul>"
        response.content_type = 'text/html'
        response.data = html
    return response
```

## 404/500 Error Page Injection

### Pi-hole Admin Interface (CVE-2025-53533)

The 404 page reflects the URL path into a `class` attribute, enabling script injection. Affects versions <= 6.2.1. CVSS 6.1.

```
# Attack: Inject via URL path reflected in class attribute
GET /admin/<img+src=x+onerror=alert(1)> HTTP/1.1

# The 404 page renders:
# <div class="<img src=x onerror=alert(1)>">Page not found</div>
# XSS fires via attribute breakout
```

### StoneFly Storage Concentrator (CVE-2026-50040)

The 404 handler echoes request path or query content without HTML entity encoding or contextual output escaping in the response body.

### Better Auth Error Page (CVE-2025-71404)

The `/api/auth/error` page reflects the `error` parameter as HTML. Fixed in version 1.1.16. CVSS v4 score 5.1. Notable because it is an API authentication library error page.

```
# Attack: Error parameter reflection
GET /api/auth/error?error=<script>alert(1)</script> HTTP/1.1
```

### WordPress Smart Custom 404 (CVE-2024-9204)

Reads `$_SERVER['REQUEST_URI']` and reflects the value into response HTML without sanitization.

### API-Specific 404 Patterns

API contexts are particularly affected because:
1. Custom error handlers include the API version string or endpoint path
2. API gateways generate error pages reflecting the original request URI
3. Authentication libraries provide error endpoints that render parameters

```
# Pattern: API version string reflection
GET /api/v3<script>alert(1)</script>/users HTTP/1.1

# 404 Response: "API version v3<script>alert(1)</script> not found"
```

## Rate Limit Response XSS

No confirmed XSS through rate-limiting responses was found. The attack is theoretically possible if a rate-limit error page reflects request details.

```
# Theoretical attack: Custom 429 page reflecting request data
# "Too many requests from <attacker-controlled-user-agent> for /api/users"

# Most plausible scenario: Custom 429 error page that includes
# the request path, IP address, or user-agent without encoding
GET /api/users HTTP/1.1
User-Agent: <script>alert(1)</script>

# Response:
# HTTP/1.1 429 Too Many Requests
# Content-Type: text/html
# <p>Too many requests from <script>alert(1)</script></p>
```

## JSON API Error Response Rendering

JSON APIs are not immune to XSS. If a browser renders a JSON response as HTML (missing or wrong Content-Type), script tags in JSON values can execute.

```python
# VULNERABLE: Missing Content-Type header on error response
@app.errorhandler(400)
def bad_request(e):
    return json.dumps({"error": str(e), "path": request.path})
    # If Content-Type defaults to text/html and path contains XSS

# SAFE: Explicit Content-Type on ALL responses including errors
@app.errorhandler(400)
def bad_request(e):
    response = make_response(json.dumps({"error": "Bad request"}))
    response.headers['Content-Type'] = 'application/json'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    return response, 400
```

## Prevention Principles

1. **Never echo user input in error messages** -- use structured error formats with fixed templates
2. **Set Content-Type: application/json and X-Content-Type-Options: nosniff** on ALL responses including errors
3. **Use generic error pages** that do not include request data
4. **Disable debug mode** in production (APP_DEBUG=false, DEBUG=False)
5. **Test ALL response codes** (200, 400, 404, 429, 500) for reflected input

## Testing Methodology

1. **Trigger every error code** (400, 401, 403, 404, 405, 429, 500, 502, 503)
2. **Test path reflection** in 404 pages with XSS payloads in the URL
3. **Send malformed JSON** with XSS and check error response rendering
4. **Test validation errors** with XSS in field names and values
5. **Check Content-Type** on all error responses
6. **Test rate limit pages** for reflected request details
7. **Check framework debug pages** for production exposure
8. **Test API version string** reflection in error messages

## Bug Bounty Tips

1. Error pages are often overlooked -- test 404/500 pages before anything else
2. Pi-hole CVE-2025-53533 reflects in a class attribute -- test attribute contexts too
3. API auth library error pages (Better Auth CVE-2025-71404) are a specific target
4. JSON parse errors that echo the input are a common reflected XSS source
5. Debug mode in production elevates XSS to CVSS 8.0 (Laravel precedent)
6. GraphQL error messages frequently contain reflected user input
7. Rate limit responses are an unexplored XSS surface -- no CVEs exist yet
8. Always check Content-Type on error responses, not just successful responses
