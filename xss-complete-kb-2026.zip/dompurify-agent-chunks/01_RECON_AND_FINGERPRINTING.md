# AGENT TASK: Reconnaissance and DOMPurify Fingerprinting
# PURPOSE: Identify DOMPurify version, understand architecture, map failure models
# PRIORITY: Run FIRST before any attack testing
# INPUTS: Target URL, access to target application
# OUTPUT: DOMPurify version, configuration detected, failure model classification
# CHAPTERS: 1 (Architecture Deep-dive), 2 (XSS Failure Models), Table of Contents
---

# Advanced DOMPurify XSS Security Research
## Comprehensive Analysis of DOMPurify Bypass Techniques, Integration Vulnerabilities, and Audit Methodology

**Version:** 2.1 — Deep Forensic + Attack Methodology Edition  
**Date:** 2026-10-09  
**DOMPurify Version Analyzed:** 3.4.16  
**Classification:** Security Research — Authorized Testing Only  
**Addendum:** 22-section forensic supplement with complete attack methodology, working payloads, exploitation chains, CSS exfiltration, parser fuzzing, real-world incident forensics, and GHSA inventory

---

## Table of Contents

### Part I — Foundations
1. [DOMPurify Security Architecture (Deep-dive)](#chapter-1-dompurify-security-architecture-deep-dive)
2. [DOMPurify XSS Failure Models](#chapter-2-dompurify-xss-failure-models)

### Part II — Missing and Conditional Sanitization
3. [Missing DOMPurify Invocation](#chapter-3-missing-dompurify-invocation)
4. [Conditional Sanitization and Coverage Gaps](#chapter-4-conditional-sanitization-and-coverage-gaps)

### Part III — Configuration and Integration
5. [DOMPurify Configuration Security](#chapter-5-dompurify-configuration-security)
6. DOMPurify Hook Security and Wrapper Pitfalls
7. Post-Sanitization Transformation Attacks

### Part IV — Advanced Attack Techniques
8. Mutation XSS (mXSS) Deep-Dive
9. DOM Clobbering and Namespace Confusion
10. Server-Side DOMPurify (jsdom, linkedom, happy-dom)

### Part V — Framework Integration
11. React Integration Vulnerabilities
12. Vue / Nuxt Integration Vulnerabilities
13. Angular Integration Vulnerabilities
14. Svelte, Solid, and Other Frameworks
15. jQuery and Legacy Library Integration

### Part VI — Audit Methodology
16. Source-to-Sink Analysis Methodology
17. Automated Detection: Semgrep, ESLint, and CodeQL Rules
18. Manual Audit Checklist and Workflow
19. Regression Testing and CI/CD Integration
20. Remediation Patterns and Secure Defaults

### Appendices
- Appendix A: Complete CVE Reference Table (30 Vulnerabilities)
- Appendix B: DOMPurify Configuration Decision Matrix
- Appendix C: Semgrep Rule Library
- Appendix D: Detection Pattern Quick-Reference
- Appendix E: Safe Wrapper Implementation Templates

### Part VII — Advanced Forensic Analysis (v2.0 Addendum)
- F1: 2025 HTML Serialization Spec Change — The Game-Changing Fix
- F2: Chrome Sanitizer API Bypasses — Native Sanitizer Not Bulletproof
- F3: Engine-Deferred Mutation — A New Bypass Class
- F4: Advanced DOM Clobbering Forensics (Hulk, Multi-Level, Gmail AMP4Email)
- F5: CSS Exfiltration Through DOMPurify — The Undefended Channel
- F6: MutaGen Parser Differential Fuzzer — State of the Art
- F7: Real-World Incident Forensics — 6 Case Studies
- F8: setConfig() — The Most Dangerous Undocumented API
- F9: Complete GitHub Security Advisory Inventory (23+ Advisories)
- F10: Performance-Based Attack Surface
- F11: Academic Research Gap Analysis
- F12: W3C Sanitizer API — Migration Strategy and Gaps
- F13: Declarative Partial Updates Deep Dive
- F14: DOMPurify 21 Official Attack Classes
- F15: Complete mXSS Payload Taxonomy
- F16: Enhanced Reference Database

### Part VIII — Deep Attack Methodology (v2.1 Supplement)
- F17: Complete DOMPurify Bypass Methodology — Attacker's Playbook
- F18: mXSS Exploit Development — From Theory to Working Payload
- F19: DOM Clobbering — From Property Override to Account Takeover
- F20: XSS Escalation Framework — From DOMPurify Bypass to Full Impact
- F21: CSS Exfiltration Deep Methodology — Exploiting DOMPurify's Blind Spot
- F22: Server-Side DOMPurify Exploitation — Parser Differentials to RCE

---

# Chapter 1: DOMPurify Security Architecture (Deep-dive)

## 1.1 Architecture Overview

DOMPurify 3.4.16 is structured as a factory function `createDOMPurify(window)` that returns a `DOMPurify` instance bound to a specific `window` (or Window-like) object. The default export is `createDOMPurify()` called with the global `window`. This design allows server-side use with jsdom or similar by passing a custom window object.

**Source files analyzed:** `src/purify.ts` (3319 lines), `src/config.ts`, `src/tags.ts`, `src/attrs.ts`, `src/regexp.ts`, `src/types.ts`, `src/utils.ts` (4956 lines total).

### 1.1.1 Core Sanitization Pipeline

The pipeline is sequential with no branching between stages:

```
Input
  |
  v
Normalization (empty check, type coercion, config parse)
  |
  v
Parsing (_initDocument: HTMLTemplateElement -> DOMParser.parseFromString)
  |
  v
DOM Tree (detached document, isolated from page)
  |
  v
Iterator Walk (NodeIterator with cached ownerDocument getter)
  |
  v
Per-node:
  _sanitizeElements (15-step element processing)
  _sanitizeAttributes (15-step attribute processing)
  Shadow DOM recursion (iterative stack, not recursion)
  |
  v
Output Serialization (string / DOM / DocumentFragment / TrustedHTML)
```

Each stage is designed to be independent: a failure at any point triggers fail-closed behavior (stripping content or throwing), never fail-open.

## 1.2 Prototype-Method Caching (Anti-Clobbering Foundation)

Before any sanitization logic runs, DOMPurify caches prototype-chain getters for all DOM methods it will use. This is the foundational defense against DOM clobbering attacks, where `<input name="nodeName">` inside a `<form>` can shadow the real `nodeName` property:

```typescript
// src/utils.ts - lookupGetter walks the prototype chain
const cloneNode = lookupGetter(ElementPrototype, 'cloneNode');
const remove = lookupGetter(ElementPrototype, 'remove');
const removeAttributeNode = lookupGetter(ElementPrototype, 'removeAttributeNode');
const getNextSibling = lookupGetter(ElementPrototype, 'nextSibling');
const getChildNodes = lookupGetter(ElementPrototype, 'childNodes');
const getParentNode = lookupGetter(ElementPrototype, 'parentNode');
const getShadowRoot = lookupGetter(ElementPrototype, 'shadowRoot');
const getAttributes = lookupGetter(ElementPrototype, 'attributes');
const getNodeType = lookupGetter(Node.prototype, 'nodeType');
const getNodeName = lookupGetter(Node.prototype, 'nodeName');
const getOwnerDocument = lookupGetter(Node.prototype, 'ownerDocument');
```

The `lookupGetter` utility (in `utils.ts`) walks the prototype chain to find the real getter/method, then wraps it via `unapply()` so it can be called with any receiver safely. The `unapply()` function also resets `RegExp.lastIndex` to 0 before every call, preventing sticky-regex state leakage.

**Security assumption #1:** The prototype chain of `Element.prototype` and `Node.prototype` has not been tampered with before DOMPurify loads. If an attacker can redefine these prototypes before DOMPurify initializes, the cached getters are compromised.

## 1.3 Input Normalization

Entry point: `DOMPurify.sanitize(dirty, cfg)`

### 1.3.1 Empty Input Handling

```typescript
IS_EMPTY_INPUT = !dirty;
if (IS_EMPTY_INPUT) {
  dirty = '<!-->';
}
```

Empty/falsy input is replaced with a minimal comment marker `<!-->`. This ensures the parser always has something to work with, and the return type is consistent. The comment is stripped during output serialization.

### 1.3.2 Type Coercion (stringifyValue)

```typescript
if (typeof dirty !== 'string' && !_isNode(dirty)) {
  dirty = stringifyValue(dirty);
}
```

Non-string, non-DOM inputs are coerced via `stringifyValue()`, which uses prototype-safe conversion (cached `Number.prototype.toString`, `Boolean.prototype.toString`, etc.) rather than relying on `.toString()` directly. This prevents prototype-pollution-based injection through `toString` overrides.

The `_isNode()` function uses the cached `Node.prototype.nodeType` getter for realm-independent detection. This fixed GHSA-4w3q-35jp-p934, where `instanceof Node` failed for cross-realm nodes (e.g., nodes from an iframe's document).

### 1.3.3 Config Parsing (_parseConfig)

`_parseConfig(cfg)` applies three hardening steps:

1. **Prototype-free deep copy:** `clone(cfg)` creates an `Object.create(null)` deep copy, preventing prototype pollution attacks through the config object.
2. **Array hole filling:** `cleanArray()` fills array holes (sparse arrays) to harden against Client-Side Prototype Pollution (CSPP). Without this, `Array.prototype[0]` pollution could inject values into configuration arrays.
3. **Type validation:** Config values are checked against expected types before use.

```typescript
// clone() creates a prototype-free deep copy
function clone(obj) {
  const newObj = Object.create(null);
  for (const [key, value] of Object.entries(obj)) {
    if (Array.isArray(value)) {
      newObj[key] = cleanArray(value);
    } else if (value && typeof value === 'object') {
      newObj[key] = clone(value);
    } else {
      newObj[key] = value;
    }
  }
  return newObj;
}
```

## 1.4 HTML Parsing (_initDocument)

### 1.4.1 Detached Document Isolation

DOMPurify creates a detached document for parsing to isolate the sanitization process from the page document:

```typescript
if (typeof HTMLTemplateElement === 'function') {
  const template = document.createElement('template');
  if (template.content && template.content.ownerDocument) {
    document = template.content.ownerDocument;
  }
}
```

The template content owner document is used because it has an empty web-components registry (per spec), preventing inherited custom element definitions from the page document from interfering with parsing.

### 1.4.2 Primary Parsing Path: DOMParser

```typescript
const doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
```

The primary parser is `DOMParser.parseFromString()` using the browser's native HTML5 parser. This creates a new document with scripting disabled (a critical detail for `<noscript>` handling -- see mXSS discussion in Chapter 8).

**Fallback path:** `implementation.createDocument(NAMESPACE, 'template', null)` with `innerHTML` assignment, used when DOMParser is unavailable.

**XHTML mode:** When `PARSER_MEDIA_TYPE` is `application/xhtml+xml`, the input is wrapped in a proper XHTML skeleton:

```html
<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>INPUT</body></html>
```

### 1.4.3 FORCE_BODY Mode

When `FORCE_BODY` is true, a sacrificial `<remove></remove>` tag is prepended to the input:

```typescript
dirty = '<remove></remove>' + dirty;
```

This prevents browsers from moving elements like `<style>` or `<link>` into `<head>` during parsing, keeping all content in `<body>` for consistent traversal. Without this, a `<style>` element at the start of input would migrate to `<head>` and potentially be missed during the body-scoped walk.

### 1.4.4 Leading Whitespace Preservation

When `FORCE_BODY` is false, leading whitespace is captured via `/^[\r\n\t ]+/` and manually re-inserted as a text node after parsing, since the HTML parser may strip it. This prevents information loss but has no security impact.

**Security assumption #2:** The browser's DOMParser produces a well-formed DOM tree that accurately reflects the HTML5 parsing algorithm. mXSS protections exist because this assumption can fail when the DOM is re-serialized.

## 1.5 DOM Traversal

### 1.5.1 NodeIterator (Not TreeWalker)

```typescript
const _createNodeIterator = function (root: Node): NodeIterator {
  const doc = getOwnerDocument ? getOwnerDocument(root) : root.ownerDocument;
  return createNodeIterator.call(
    doc || root,
    root,
    NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT |
      NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION |
      NodeFilter.SHOW_CDATA_SECTION,
    null
  );
};
```

DOMPurify uses `createNodeIterator` (not `TreeWalker`) to walk the tree in document order. The filter shows elements, comments, text nodes, processing instructions, and CDATA sections.

**Critical anti-clobbering detail:** The `ownerDocument` property is read through the cached `Node.prototype` getter, not the direct property. This prevents `HTMLFormElement` `[LegacyOverrideBuiltIns]` clobbering where `<input name="ownerDocument">` would shadow the real document.

### 1.5.2 Main Walk Loop

```typescript
const nodeIterator = _createNodeIterator(walkRoot);
while ((currentNode = nodeIterator.nextNode())) {
  _sanitizeElements(currentNode, walkRoot);
  _sanitizeAttributes(currentNode, walkRoot);
  if (_isDocumentFragment(currentNode.content)) {
    _sanitizeShadowDOM(currentNode.content);
  }
}
```

The walk is wrapped in a try/catch for the `IN_PLACE` path. If the walk throws (e.g., a custom element reaction detaches a node mid-walk), the catch block calls `_neutralizeRoot(dirty)` to strip the live tree bare before re-throwing, ensuring **fail-closed** behavior.

### 1.5.3 Shadow DOM Handling (Iterative Stack)

`_sanitizeAttachedShadowRoots(root)` runs before the main walk for both `IN_PLACE` and DOM-node input paths. It uses an **iterative explicit stack** (not recursion) to prevent stack overflow on deeply nested attacker-controlled trees:

```typescript
// Simplified: iterative stack prevents DoS via deep nesting
const stack = [root];
while (stack.length > 0) {
  const current = stack.pop();
  // Process shadow roots at this level
  // Push child shadow roots onto stack
}
```

`_sanitizeShadowDOM(fragment)` processes shadow roots, template content, and nested shadow roots within template content. Each shadow root gets its own NodeIterator walk with the full `_sanitizeElements` + `_sanitizeAttributes` treatment.

## 1.6 Element Sanitization (_sanitizeElements)

### 1.6.1 15-Step Processing Order (Load-Bearing)

The ordering of these steps is security-critical. Reordering any step can create bypass paths:

| Step | Action | Purpose |
|------|--------|---------|
| 1 | **Hook: `beforeSanitizeElements`** | Fire pre-element hook; may detach node |
| 2 | **Hook-detach check** | `_handleHookDetachedNode()` returns true if a hook removed the node from its parent |
| 3 | **Clobbering check** | `_isClobbered(currentNode)` detects DOM clobbering on `<form>` elements |
| 4 | **Tag name read** | `transformCaseFunc(_readNodeName(currentNode))` via cached Node.prototype getter |
| 5 | **Allowlist fork** | `_forkSharedAllowlist()` clones ALLOWED_TAGS if hooks are registered, preventing mutation leaks |
| 6 | **Hook: `uponSanitizeElement`** | Exposes `{tagName, allowedTags}`; hook can modify `allowedTags` |
| 7 | **Hook-detach check** (again) | Second check in case `uponSanitizeElement` detached the node |
| 8 | **Unsafe-node check** | `_isUnsafeNode()` for mXSS vectors, processing instructions, risky comments |
| 9 | **Tag allowlist/forbidlist check** | FORBID_TAGS wins, then ADD_TAGS function check, then ALLOWED_TAGS lookup |
| 10 | **Disallowed-node handling** | `_sanitizeDisallowedNode()` with KEEP_CONTENT hoisting or removal |
| 11 | **Namespace validation** | `_checkValidNamespace()` for elements that pass the tag check |
| 12 | **Fallback-tag mXSS** | Regex check on `noscript`/`noembed`/`noframes` innerHTML for closing tags |
| 13 | **Template expression strip** | If SAFE_FOR_TEMPLATES, strip `{{...}}`, `${...}`, `<%...%>` from text nodes |
| 14 | **Hook: `afterSanitizeElements`** | Post-element hook |
| 15 | **Hook-detach check** (final) | Final check in case the post-element hook detached the node |

## 1.7 Unsafe Node Detection (_isUnsafeNode)

This function detects structural threats regardless of allowlists. It implements four rules:

### Rule 1 -- mXSS via Namespace Confusion (SAFE_FOR_XML gated)

Checks if an element has child nodes where `firstElementChild` is not a real Node and both `textContent` and `innerHTML` contain markup-like patterns (`<[/\w!]`). This catches trees built via DOM API or XML/XHTML parsing that contain element children within literal-text elements -- structures the HTML parser cannot produce but that serialize and reparse dangerously.

### Rule 2 -- Literal-Text Element Content Poisoning (SAFE_FOR_XML gated)

For elements in `LITERAL_TEXT_ELEMENTS` (`style`, `script`, `xmp`, `iframe`, `noembed`, `noframes`, `plaintext`, `noscript`), checks for either:
- **(a)** Element children (impossible in these elements via normal HTML parsing), or
- **(b)** `textContent` containing the element's own closing tag via `LITERAL_TEXT_CLOSE[tagName]`

Uses per-element end-tag matchers with HTML tag-name terminators in lookahead (e.g., `/^<\/style[\t\n\f\r \/]/i` for `<style>`).

### Rule 3 -- Processing Instructions

Always removed. Any node with `nodeType === 7` (processing instruction) is unsafe. Processing instructions in XML can contain content that HTML parsers interpret as markup.

### Rule 4 -- Risky Comments (SAFE_FOR_XML gated)

Comments whose `.data` matches `COMMENT_MARKUP_PROBE` (`/<[/\w]/`). A comment containing `<script>` could be dangerous if the comment is improperly serialized or parsed by a downstream consumer.

**Security assumption #3:** `SAFE_FOR_XML` defaults to `true`. Setting it to `false` disables rules 1, 2, and 4, creating mXSS exposure if the output is used in SVG/MathML/XML contexts.

## 1.8 Clobbering Detection (_isClobbered)

Only applies to `<form>` elements (the sole HTML interface with `[LegacyOverrideBuiltIns]`). This 13-property check validates that DOM APIs have not been clobbered by named `<input>` children:

```typescript
function _isClobbered(elm) {
  return (
    typeof elm.nodeName !== 'string' ||          // 1
    typeof elm.textContent !== 'string' ||        // 2
    typeof elm.removeChild !== 'function' ||      // 3
    elm.attributes !== getAttributes(elm) ||      // 4 (cached getter identity)
    typeof elm.removeAttribute !== 'function' ||  // 5
    typeof elm.removeAttributeNode !== 'function' || // 6
    typeof elm.getAttributeNode !== 'function' || // 7
    typeof elm.setAttribute !== 'function' ||     // 8
    typeof elm.namespaceURI !== 'string' ||       // 9
    typeof elm.insertBefore !== 'function' ||     // 10
    typeof elm.hasChildNodes !== 'function' ||    // 11
    elm.nodeType !== getNodeType(elm) ||           // 12 (cached vs direct)
    elm.childNodes !== getChildNodes(elm)          // 13 (cached vs direct)
  );
}
```

A clobbered form is force-removed. On the `IN_PLACE` path, a clobbered root triggers `_neutralizeRoot()` + throw.

## 1.9 Attribute Sanitization (_sanitizeAttributes)

### 1.9.1 15-Step Attribute Processing Chain

| Step | Action | Purpose |
|------|--------|---------|
| 1 | **Hook: `beforeSanitizeAttributes`** | Pre-attribute hook |
| 2 | **Hook-detach check** | Check if hook detached the element |
| 3 | **Clobbering re-check** | `_isClobbered()` again (attribute changes could introduce clobbering) |
| 4 | **Allowlist fork** | Clone ALLOWED_ATTR if hooks registered |
| 5 | **Per-attribute backward loop** | `while (l--)` over `attributes` |
| 6a | Read `{name, namespaceURI, value}` from the Attr node | |
| 6b | `transformCaseFunc` the name | |
| 6c | Trim value (except `value` attribute) | |
| 7 | **Hook: `uponSanitizeAttribute`** | Exposes `{attrName, attrValue, keepAttr, allowedAttributes, forceKeepAttr}` |
| 8 | **SANITIZE_NAMED_PROPS** | Prefix `id`/`name` with `user-content-` |
| 9 | **SAFE_FOR_XML comment-in-attr check** | Regex for `-->`, `]>`, or closing literal-text tags |
| 10 | **Animated href block** | Remove `attributename` attr if value matches `href` |
| 11 | **forceKeepAttr bypass** | If hook set `forceKeepAttr`, skip all remaining checks |
| 12 | **keepAttr check** | If hook set `keepAttr: false`, remove |
| 13 | **jQuery self-closing tag** | If `!ALLOW_SELF_CLOSE_IN_ATTR`, check for `/>` in value |
| 14 | **SAFE_FOR_TEMPLATES strip** | Remove `{{...}}`, `${...}`, `<%...%>` |
| 15 | **`_isValidAttribute` check** | The core policy evaluation (12-step decision chain) |

### 1.9.2 Attribute Removal via Exact Attr Node

```typescript
function _removeAttribute(attr, node) {
  removeAttributeNode.call(node, attr); // Not removeAttribute(name)!
}
```

Uses the exact `Attr` node for removal via cached `Element.prototype.removeAttributeNode()`, not name-based `removeAttribute()`. This is critical because `removeAttribute()` ASCII-lowercases its key in HTML documents, silently missing case-preserved attributes from XML/XHTML imports (e.g., `ONERROR` surviving as an attribute name).

Special handling for the `is` attribute: when removing, on DOM-returning paths the element is force-removed entirely (since `is` cannot be truly removed from a live element); on string paths, the value is set to an empty string.

## 1.10 Tag Validation

### 1.10.1 ALLOWED_TAGS (Default Set)

Built from four namespaces plus text nodes:

| Namespace | Count | Notes |
|-----------|-------|-------|
| `TAGS.html` | 122 HTML elements | No `script`, `iframe`, `object`, `embed`, `applet` |
| `TAGS.svg` | 47 SVG elements | No `animate`, `foreignobject`, `use`, `script`, `set` |
| `TAGS.svgFilters` | 25 SVG filter elements | Case-preserved: `feBlend`, `feGaussianBlur`, etc. |
| `TAGS.mathMl` | 30 MathML elements | No `maction`, `semantics`, `annotation-xml` |
| `TAGS.text` | 1 (`#text`) | Text nodes always pass |

All stored lowercased in a prototype-free object (`Object.setPrototypeOf(set, null)`).

### 1.10.2 FORBID_TAGS

Default: empty set. When configured, **FORBID_TAGS always wins** over ALLOWED_TAGS and ADD_TAGS. This precedence is a security invariant.

### 1.10.3 USE_PROFILES

Overrides ALLOWED_TAGS entirely with a union of selected profiles:
- `html: true` -- TAGS.html + ATTRS.html
- `svg: true` -- TAGS.svg + ATTRS.svg + ATTRS.xml
- `svgFilters: true` -- TAGS.svgFilters + ATTRS.svg + ATTRS.xml
- `mathMl: true` -- TAGS.mathMl + ATTRS.mathMl + ATTRS.xml

USE_PROFILES and ALLOWED_TAGS should not be combined; USE_PROFILES resets the tag set.

### 1.10.4 ADD_TAGS

Can be an array (merged into ALLOWED_TAGS) or a function `(tagName: string) => boolean` stored in `EXTRA_ELEMENT_HANDLING.tagCheck`. Function form is checked during the element walk. Before DOMPurify 3.4.0, function-form ADD_TAGS bypassed FORBID_TAGS (CVE-2026-41240 / CVE-2026-65903).

## 1.11 Attribute Validation (_isValidAttribute)

### 1.11.1 12-Step Decision Chain

Each check is short-circuit (returns immediately on match):

| Step | Check | Result if matched |
|------|-------|-------------------|
| 1 | **FORBID_ATTR** | Always reject |
| 2 | **Patch linkage** (`_isPatchLinkageAttribute`) | Block `patchsrc`; block `for` except on `<label>`/`<output>` when SAFE_FOR_XML |
| 3 | **SANITIZE_DOM clobber check** | Reject `id`/`name` values colliding with `document` or `formElement` properties |
| 4 | **ALLOWED_ATTR lookup** | Accept if in allowlist |
| 5 | **ADD_ATTR function** | Accept if predicate returns true |
| 6 | **data-\* attributes** | Accept if `ALLOW_DATA_ATTR` and matches `/^data-[\-\w.·-￿]+$/` |
| 7 | **aria-\* attributes** | Accept if `ALLOW_ARIA_ATTR` and matches `/^aria-[\-\w]+$/` |
| 8 | **Custom element attributes** | Accept if `_isBasicCustomElement(tag)` + `tagNameCheck` + `attributeNameCheck` |
| 9 | **URI-safe attributes** | Accept if in `URI_SAFE_ATTRIBUTES` set (class, id, style, etc.) |
| 10 | **URI validation** | Accept if `IS_ALLOWED_URI` passes after `ATTR_WHITESPACE` stripping |
| 11 | **Data URI allowlist** | Accept `data:` URIs only on `DATA_URI_TAGS` (`audio`, `video`, `img`, `source`, `image`, `track`), NOT on `<script>` |
| 12 | **Unknown protocols** | If `ALLOW_UNKNOWN_PROTOCOLS`, accept unless `IS_SCRIPT_OR_DATA` matches |

If no check accepts the attribute, it is rejected (an empty value falls through as accepted at this point).

## 1.12 URI Policy

### 1.12.1 IS_ALLOWED_URI (Default Regex)

```
/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
```

Allows: `http(s)`, `ftp(s)`, `mailto`, `tel`, `callto`, `sms`, `cid`, `xmpp`, `matrix`, relative URLs, `#anchors`, `//protocol-relative`.

Blocks: `javascript:`, `data:` (except via DATA_URI_TAGS), `vbscript:`, any `\w+script:`.

### 1.12.2 IS_SCRIPT_OR_DATA

```
/^(?:\w+script|data):/i
```

Used as fallback when `ALLOW_UNKNOWN_PROTOCOLS` is true. Blocks all `*script:` and `data:` regardless.

### 1.12.3 ATTR_WHITESPACE Stripping

```
/[\u0000-   ᠎ -     　]/g
```

Stripped from attribute values before URI validation. Catches whitespace obfuscation like `java\tscript:` or `java\x00script:`. The range covers all Unicode whitespace including zero-width and non-breaking spaces.

### 1.12.4 ALLOWED_URI_REGEXP Override

Users can replace the default URI regex entirely. This is documented as a high-risk option.

**Security assumption #4:** The default IS_ALLOWED_URI regex correctly identifies all dangerous URI schemes across all browsers and protocol handlers.

## 1.13 Namespace Handling

### 1.13.1 Three-Namespace Model

DOMPurify tracks three namespaces with strict transition rules:

- `HTML_NAMESPACE` = `http://www.w3.org/1999/xhtml`
- `SVG_NAMESPACE` = `http://www.w3.org/2000/svg`
- `MATHML_NAMESPACE` = `http://www.w3.org/1998/Math/MathML`

### 1.13.2 Transition Rules

**`_checkSvgNamespace(tagName, parent, parentTagName)`:**
- HTML to SVG: only via `<svg>` tag
- MathML to SVG: only via `<svg>` if parent is `<annotation-xml>` or a MathML text integration point (`mi`, `mo`, `mn`, `ms`, `mtext`)
- SVG to SVG: must be in `ALL_SVG_TAGS`

**`_checkMathMlNamespace(tagName, parent, parentTagName)`:**
- HTML to MathML: only via `<math>` tag
- SVG to MathML: only via `<math>` if parent is an HTML integration point (`annotation-xml` by default)
- MathML to MathML: must be in `ALL_MATHML_TAGS`

**`_checkHtmlNamespace(tagName, parent, parentTagName)`:**
- SVG to HTML: only through HTML integration points (default: `annotation-xml`)
- MathML to HTML: only through MathML text integration points (default: `mi`, `mo`, `mn`, `ms`, `mtext`)
- Rejects elements that belong exclusively to MathML or SVG namespaces

### 1.13.3 COMMON_SVG_AND_HTML_ELEMENTS

`title`, `style`, `font`, `a`, `script` exist in both SVG and HTML namespaces and are not rejected as SVG-only when found in HTML namespace.

### 1.13.4 Configurable Integration Points

`MATHML_TEXT_INTEGRATION_POINTS` and `HTML_INTEGRATION_POINTS` are configurable.

**Security assumption #5:** Expanding these opens mXSS attack surface through namespace confusion. Restricting them may cause legitimate content to be stripped.

## 1.14 Custom Element Handling

### 1.14.1 _isBasicCustomElement Regex

```typescript
const _isBasicCustomElement = function (tagName: string): boolean {
  return (
    !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] &&
    regExpTest(CUSTOM_ELEMENT, tagName) // /^[a-z][.\w]*(-[.\w]+)+$/i
  );
};
```

Must contain at least one hyphen (not at the start), and must not be in the reserved list (`annotation-xml`, `color-profile`, `font-face-*`, `missing-glyph`).

### 1.14.2 CUSTOM_ELEMENT_HANDLING Configuration

```typescript
{
  tagNameCheck: RegExp | ((tagName: string) => boolean) | null,     // default: null
  attributeNameCheck: RegExp | ((attr: string) => boolean) | null,  // default: null
  allowCustomizedBuiltInElements: boolean  // default: false
}
```

- `tagNameCheck: null` (default) means no custom elements pass
- Custom elements that pass `tagNameCheck` **skip namespace validation and fallback-tag mXSS checks**
- `attributeNameCheck` controls which non-standard attributes are allowed on passing custom elements
- `allowCustomizedBuiltInElements` enables `is="..."` attribute support

**Security assumption #6:** A permissive `tagNameCheck` (e.g., `/.*/`) combined with a permissive `attributeNameCheck` could allow event handler attributes on custom elements, bypassing the core attribute allowlist.

## 1.15 Hook System

### 1.15.1 Nine Hook Points (Execution Order)

| Hook | Receives | Fires when |
|------|----------|------------|
| `beforeSanitizeElements` | `(node, null, config)` | Before any element check |
| `uponSanitizeElement` | `(node, {tagName, allowedTags}, config)` | After tag name read; `allowedTags` is mutable |
| `afterSanitizeElements` | `(node, null, config)` | After element decision |
| `beforeSanitizeAttributes` | `(element, null, config)` | Before attribute loop |
| `uponSanitizeAttribute` | `(element, {attrName, attrValue, keepAttr, allowedAttributes, forceKeepAttr}, config)` | Per attribute; hook can set `keepAttr`, `forceKeepAttr`, `attrValue` |
| `afterSanitizeAttributes` | `(element, null, config)` | After all attributes processed |
| `beforeSanitizeShadowDOM` | `(fragment, null, config)` | Before shadow DOM walk |
| `uponSanitizeShadowNode` | `(node, null, config)` | Per shadow DOM node |
| `afterSanitizeShadowDOM` | `(fragment, null, config)` | After shadow DOM walk |

### 1.15.2 Allowlist Isolation via _forkSharedAllowlist

When any `uponSanitizeElement` or `uponSanitizeAttribute` hook is registered, ALLOWED_TAGS/ALLOWED_ATTR are cloned before each `sanitize()` call. This prevents a hook from permanently widening the allowlist across calls by modifying the exposed reference. (Prior to fix for CVE-2026-65902, this cloning was incomplete.)

### 1.15.3 Hook Detach Handling

After every hook site, `_handleHookDetachedNode()` checks if the hook detached the current node. If so, on the `IN_PLACE` path, `_neutralizeSubtree()` strips non-allowed attributes from the detached subtree to prevent queued resource events (e.g., `<img onload>`) from firing in page scope.

### 1.15.4 forceKeepAttr Foot-Gun

The `uponSanitizeAttribute` hook can set `forceKeepAttr: true` to bypass ALL remaining attribute validation including URI checks. This is a documented foot-gun. A hook using `forceKeepAttr` to keep a `content` attribute on SVG elements could allow `javascript:` URIs through.

## 1.16 Output Serialization

### 1.16.1 String Output (Default)

Default mode: `body.innerHTML` serialization. This is the path most vulnerable to mXSS because the consumer must re-parse the string via `innerHTML` assignment.

### 1.16.2 RETURN_DOM

Returns an `HTMLBodyElement`. The consumer can directly append the body's children without re-parsing, avoiding the mXSS serialize-reparse roundtrip.

### 1.16.3 RETURN_DOM_FRAGMENT

Returns a `DocumentFragment` for direct insertion without a wrapper element. This uses `importNode` (not `adoptNode`) for shadow root content, ensuring the imported nodes belong to the target document's realm.

**Security advantage:** Both DOM return modes avoid the serialize-then-reparse step that enables mXSS. `RETURN_DOM_FRAGMENT` is the DOMPurify wiki's recommended output mode.

### 1.16.4 Fast Path

When the input string contains no `<` character, DOMPurify returns it directly without parsing. This is a performance optimization that is safe because no markup can exist without `<`.

## 1.17 Trusted Types Integration

### 1.17.1 Lazy Policy Creation

DOMPurify creates a Trusted Types policy lazily on first use. The policy is named `dompurify` by default (configurable via `TRUSTED_TYPES_POLICY`).

### 1.17.2 Re-entrancy Guard

A re-entrancy guard prevents nested `sanitize()` calls from creating multiple policies. This is important because Trusted Types policy creation is a global side effect.

### 1.17.3 Policy Lifecycle Vulnerability

GHSA-vxr8-fq34-vvx9 (CVE-2026-65899): The Trusted Types policy survived `clearConfig()`. When a custom `TRUSTED_TYPES_POLICY` was set on one call, `clearConfig()` reset CONFIG but did NOT reset the internal `trustedTypesPolicy`. A later call with `RETURN_TRUSTED_TYPE: true` used the stale policy. Fixed in DOMPurify 3.4.9.

### 1.17.4 Attribute-Level Trusted Types

`_applyTrustedTypesToAttribute` wraps URI-bearing attribute values in TrustedURL/TrustedScriptURL as appropriate, supporting attribute-level Trusted Types enforcement.

## 1.18 Eight Security-Critical Assumptions

| # | Assumption | If violated... |
|---|-----------|----------------|
| 1 | `Element.prototype` / `Node.prototype` intact at load time | Cached getters compromised; all sanitization bypassed |
| 2 | Browser DOMParser implements HTML5 spec correctly | mXSS via parser differential |
| 3 | `SAFE_FOR_XML` defaults to `true` | mXSS via namespace confusion, literal-text poisoning |
| 4 | Default IS_ALLOWED_URI regex covers all dangerous schemes | Protocol-scheme bypass |
| 5 | Namespace integration points are not expanded | mXSS via namespace confusion |
| 6 | Custom element handling is restrictive by default | Event handler injection on custom elements |
| 7 | Output is used in the same parsing context as sanitization | Re-contextualization mXSS |
| 8 | No post-sanitization transformation occurs | All Model A failures |

---

# Chapter 2: DOMPurify XSS Failure Models

This chapter defines five classes of failure that lead to XSS despite DOMPurify being present in the application. Each model represents a distinct root cause, and understanding these models is essential for systematic security auditing.

## 2.1 Model A -- Post-Sanitization Transformations

**Root cause:** The application modifies DOMPurify's output before or during insertion into the DOM. DOMPurify guarantees safety only at the moment its output is produced.

### A1. Sanitize Then Concatenate

```javascript
// VULNERABLE: Wrapper HTML is attacker-influenced
const wrapper = `<div class="${userClass}">`;
element.innerHTML = wrapper + DOMPurify.sanitize(userInput) + '</div>';
// If userClass = '" onclick="stealCookies()', XSS via the wrapper
```

A subtler variant -- boundary-crossing concatenation:

```javascript
// Sanitized output can form new elements across boundaries
const part1 = DOMPurify.sanitize(chunk1); // outputs: '<div class="safe'
const part2 = DOMPurify.sanitize(chunk2); // outputs: '" onmouseover=alert(1)>'
element.innerHTML = part1 + part2; // Combined: creates an event handler
```

### A2. Sanitize Then Decode

```javascript
// VULNERABLE: Entity decoding after sanitization
let clean = DOMPurify.sanitize(input);
clean = clean.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
element.innerHTML = clean;
// Encoded "<img onerror=alert(1)>" is now live HTML
```

**Real-world:** Curiosus.Utils (Issue #61) called `HtmlDecode` after sanitizing. SE-Dashboard (PR #312) applied URL decoding after XSS sanitization.

```javascript
// VULNERABLE: URL decoding after sanitization
let clean = DOMPurify.sanitize(input);
clean = decodeURIComponent(clean);
element.innerHTML = clean;
```

### A3. Sanitize Then Template Substitution

```javascript
// VULNERABLE: Template interpolation re-introduces attacker content
const sanitized = DOMPurify.sanitize(userBio);
const html = `<div class="${userClass}" data-id="${userId}">${sanitized}</div>`;
element.innerHTML = html;
// userClass and userId are not sanitized
```

**CVE-2025-26791:** Incorrect `${ }` regex in SAFE_FOR_TEMPLATES allowed template expression bypass in DOMPurify < 3.2.4.

### A4. Sanitize Then Markdown Conversion

```javascript
// VULNERABLE: Markdown-to-HTML after sanitization re-introduces raw HTML
let clean = DOMPurify.sanitize(userInput);
let html = markdownToHtml(clean); // CommonMark allows raw HTML blocks
element.innerHTML = html;
```

Sanitization must be the **last** step after Markdown conversion, never before.

### A5. Sanitize Then DOM Mutation

```javascript
// VULNERABLE: DOM mutation after sanitization
const fragment = DOMPurify.sanitize(input, { RETURN_DOM_FRAGMENT: true });
const img = fragment.querySelector('img');
if (img) {
  img.setAttribute('onerror', 'handleError(this)');
}
container.appendChild(fragment);
```

**CVE-2026-47423 (GHSA-87xg-pxx2-7hvx):** The `<selectedcontent>` element caused the browser to re-clone `<option>` content after DOMPurify's walk, so unsanitized content appeared in a subtree that was already processed.

### A6. Sanitize Then setAttribute()

```javascript
// VULNERABLE: Adding attributes after sanitization
const div = DOMPurify.sanitize(input, { RETURN_DOM: true });
div.setAttribute('onmouseover', 'track(event)');
document.body.appendChild(div);
```

### A7. Sanitize Then Rewrite URLs

```javascript
// VULNERABLE: URL rewriting removes DOMPurify's URI validation
const clean = DOMPurify.sanitize(input, { RETURN_DOM_FRAGMENT: true });
clean.querySelectorAll('a').forEach(link => {
  link.href = addTracking(link.href); // Tracking function may not validate
});
```

### A8. Sanitize Then Serialize Then Reparse (mXSS Fundamental)

```javascript
// VULNERABLE: The fundamental mXSS vector
const div = document.createElement('div');
div.innerHTML = DOMPurify.sanitize(input); // First parse
const serialized = div.innerHTML;           // Serialize
document.body.innerHTML = serialized;       // Second parse (different DOM!)
```

This is the core attack class against all client-side sanitizers. See Chapter 8 for full mXSS analysis.

### A9. Sanitize Then HTML Reconstruction

```javascript
// VULNERABLE: Building new HTML structure around sanitized fragments
const cells = userData.map(cell => DOMPurify.sanitize(cell));
const row = '<tr>' + cells.map(c => '<td>' + c + '</td>').join('') + '</tr>';
element.innerHTML = '<table>' + row + '</table>';
// If a sanitized cell contains "</td><td onclick=..." the table is corrupted
```

### A10. Sanitize Then Plugin Modification

**CVE-2023-48219 (TinyMCE):** Post-processing character removal after sanitization re-formed dangerous markup.

**CVE-2020-11022 (jQuery):** jQuery's HTML parsing treated DOMPurify's self-closing filter output differently.

### A11. Sanitize Then Framework Hydration

```javascript
// Server: sanitizes with jsdom
const serverHtml = DOMPurify.sanitize(content);
// Client: hydrates, may re-render with unsanitized data
function Article({ html }) {
  const [liveHtml, setLiveHtml] = useState(html);
  useEffect(() => {
    socket.on('update', (newHtml) => setLiveHtml(newHtml)); // Unsanitized!
  }, []);
  return <div dangerouslySetInnerHTML={{ __html: liveHtml }} />;
}
```

### A12. Sanitize Then Rich-Text Postprocessing

- **Auto-linking:** Converting URL text to `<a>` tags introduces `javascript:` URIs
- **Emoji replacement:** New `<img>` or `<span>` elements not inspected by sanitizer
- **Media embedding:** Converting URLs to `<iframe>` bypasses sanitizer
- **Paste transformation:** External content undergoes conversion reintroducing dangerous elements

### A13. Sanitizing Only Part of an HTML String

```javascript
// VULNERABLE: userName is not sanitized
const html = `<div class="comment">
  <div class="header">${userName}</div>
  <div class="body">${DOMPurify.sanitize(userComment)}</div>
</div>`;
```

### A14. Sanitizing the Wrong Variable

```javascript
// VULNERABLE: Logic error uses unsanitized variable
function renderComment(rawComment, processedComment) {
  const sanitized = DOMPurify.sanitize(rawComment);
  element.innerHTML = processedComment; // Bug: wrong variable
}
```

### A15. Returning the Original Unsanitized Input

```javascript
// VULNERABLE: Empty-result fallback returns the most dangerous input
function sanitizeContent(html, options) {
  const clean = DOMPurify.sanitize(html);
  if (!clean || clean.length === 0) {
    return html; // If DOMPurify stripped everything, the input was maximally dangerous
  }
  return clean;
}
```

### A16. Modifying DOM Nodes Returned by RETURN_DOM

```javascript
// VULNERABLE: Adding event handlers to sanitized DOM nodes
const dom = DOMPurify.sanitize(input, { RETURN_DOM: true });
dom.querySelectorAll('[data-action]').forEach(el => {
  el.setAttribute('onclick', el.dataset.action);
});
document.body.appendChild(dom);
```

## 2.2 Model B -- Coverage Gaps

**Root cause:** DOMPurify is present in the application but does not cover all paths from user input to HTML sinks.

### B1. Direct innerHTML Bypass

```javascript
// Component A: Uses sanitization
element.innerHTML = sanitize(userContent);

// Component B: No sanitizer (legacy code, quick fix, third-party)
otherElement.innerHTML = apiResponse.html;
```

### B2. Raw HTML in Sibling Components

**React:**
```jsx
<SafeComponent content={DOMPurify.sanitize(data.html)} />
<UnsafeComponent content={data.rawHtml} />  {/* No sanitization */}
```

**Vue:**
```vue
<safe-component v-html="sanitized"></safe-component>
<unsafe-component v-html="raw"></unsafe-component>
```

**Angular:**
```typescript
// Component A uses sanitization pipe
@Pipe({ name: 'sanitize' })
export class SanitizePipe { transform(value: string) { return DOMPurify.sanitize(value); } }

// Component B bypasses Angular's built-in sanitizer
constructor(private sanitizer: DomSanitizer) {}
getHtml() { return this.sanitizer.bypassSecurityTrustHtml(this.rawHtml); }
```

### B3. Different Wrapper Policies

```javascript
// Strict policy
export const sanitizeStrict = (html) => DOMPurify.sanitize(html, {
  ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'p'],
  ALLOWED_ATTR: []
});

// Permissive policy -- allows iframes and unknown protocols
export const sanitizeRich = (html) => DOMPurify.sanitize(html, {
  ADD_TAGS: ['iframe', 'embed', 'object'],
  ALLOW_UNKNOWN_PROTOCOLS: true  // DANGEROUS
});
```

### B4. Sanitize-on-Render-Not-Update

```javascript
// Initial render: sanitized
componentDidMount() {
  this.setState({ html: DOMPurify.sanitize(this.props.content) });
}

// Dynamic update: not sanitized
componentDidUpdate(prevProps) {
  if (prevProps.content !== this.props.content) {
    this.container.innerHTML = this.props.content; // Direct assignment!
  }
}
```

### B5. Preview-Sanitized-But-Published-Not

```javascript
// Preview endpoint: sanitized
app.get('/preview', (req, res) => {
  res.render('preview', { content: DOMPurify.sanitize(req.body.html) });
});

// Publish endpoint: stored raw
app.post('/publish', (req, res) => {
  db.save({ html: req.body.html }); // No sanitization on persist
});

// View endpoint: trusts database
app.get('/article/:id', (req, res) => {
  res.render('article', { content: db.find(id).html }); // Unsanitized
});
```

### B6. Sanitize-During-Editing-Skip-Viewing

```javascript
// Editor sanitizes on input
editor.on('change', (content) => {
  editor.setContent(DOMPurify.sanitize(content));
});

// Viewer trusts stored content
function ArticleViewer({ article }) {
  return <div dangerouslySetInnerHTML={{ __html: article.html }} />;
}
// Bypass: direct API call or DB modification bypasses the editor
```

### B7. Mobile vs Desktop Differences

- Mobile web views may use a different rendering library
- Native mobile apps may use WebView with different HTML processing
- AMP pages may strip the sanitizer for performance
- Progressive enhancement adds unsanitized features on desktop only

### B8. Rich-Text Components with Independent Rendering

CKEditor, TinyMCE, Quill, Slate.js, ProseMirror, and Draft.js each maintain internal content pipelines that may not invoke the application's DOMPurify wrapper.

### B9. Cached HTML Under Old Policy

```javascript
// Cache key does not include sanitizer version or config hash
const cacheKey = `article:${id}`;
let html = cache.get(cacheKey);
if (!html) {
  html = DOMPurify.sanitize(rawHtml);
  cache.set(cacheKey, html);
}
element.innerHTML = html; // May be from old policy
```

**GitLab Issue #357930:** Stored XSS via cache invalidation failure. Sanitized HTML was cached, but when the sanitizer policy was updated, cached content was not re-sanitized.

### B10. API Responses as Trusted

```javascript
// VULNERABLE: API response treated as pre-sanitized
fetch('/api/comments')
  .then(res => res.json())
  .then(data => {
    commentsDiv.innerHTML = data.html; // No sanitization
  });
```

**CVE-2024-22075 (Firefly III):** Client-side path traversal routed to another API endpoint; the error response reflected attacker input in JSON `message`, rendered as raw HTML via `v-html`.

### B11. Imported/Migrated Content

- CSV/Excel imports with HTML in fields
- Database migrations from systems with different policies
- RSS/Atom feeds rendered without sanitization
- Third-party content APIs (comments, reviews)

### B12. Error/Fallback Components

```javascript
// Error boundary displays raw error message
class ErrorBoundary extends React.Component {
  componentDidCatch(error) {
    this.setState({ errorHtml: `<div class="error">${error.message}</div>` });
  }
  render() {
    if (this.state.errorHtml) {
      return <div dangerouslySetInnerHTML={{ __html: this.state.errorHtml }} />;
    }
    return this.props.children;
  }
}
```

### B13. SSR vs Client Rendering Differences

```javascript
// Server: sanitizes with jsdom parser
const serverHtml = DOMPurify.sanitize(content); // jsdom

// Client: re-renders without sanitization from client state
// Or: jsdom and browser parsers disagree on <noscript> handling
```

## 2.3 Model C -- Conditional Sanitization Failures

**Root cause:** Sanitization is present but is conditionally skipped based on trust flags, user roles, feature flags, or content types.

### C1. Trust Flags

```javascript
function renderContent(html, options = {}) {
  if (options.isTrusted || options.isSafe || options.allowHtml) {
    return html; // No sanitization
  }
  return DOMPurify.sanitize(html);
}
```

### C2. Role-Based Bypass

```javascript
function processComment(comment, user) {
  if (user.isAdmin || user.role === 'editor') {
    return comment.html; // Admins post raw HTML
  }
  return DOMPurify.sanitize(comment.html);
}
```

**CVE-2026-13231 (Drupal Admin Feedback Module):** Insufficient input sanitization tied to administrative contexts. Admin-authored content displayed to non-admin users without re-sanitization.

### C3. Feature Flag Bypass

```javascript
function sanitize(html) {
  if (featureFlags.get('skip_sanitization_for_performance')) {
    return html; // Performance A/B test disables security
  }
  return DOMPurify.sanitize(html);
}
```

### C4. Content-Type-Based Decisions

```javascript
function processContent(content, contentType) {
  switch (contentType) {
    case 'text/html':
      return DOMPurify.sanitize(content);
    case 'text/markdown':
      return markdownToHtml(content); // No sanitization!
    default:
      return content; // Unknown type, no sanitization
  }
}
```

### C5. Cache/Memoization Returning Unsanitized Content

```javascript
function getContent(id) {
  if (contentCache.has(id)) {
    return contentCache.get(id); // May be unsanitized
  }
  const raw = database.get(id);
  const sanitized = DOMPurify.sanitize(raw);
  contentCache.set(id, raw); // BUG: Caches raw instead of sanitized!
  return sanitized;
}
```

### C6. Error Handling Returning Raw Input

```javascript
function sanitize(html) {
  try {
    return DOMPurify.sanitize(html);
  } catch (error) {
    console.error('Sanitization failed:', error);
    return html; // CRITICAL: Returns raw input on error
  }
}
```

### C7. Attacker-Controlled Flags

```javascript
// VULNERABLE: Attacker controls the 'format' parameter
app.post('/render', (req, res) => {
  const { content, format } = req.body;
  if (format === 'raw') {
    res.send(content); // Attacker sets format=raw
  } else {
    res.send(DOMPurify.sanitize(content));
  }
});
```

Attack vectors for controlling flags: query parameters, cookies, HTTP headers, localStorage values, database fields modified via IDOR.

## 2.4 Model D -- Server-Side DOMPurify Risks

**Root cause:** DOMPurify on the server uses a different DOM implementation than the browser, creating parser differentials.

### D1. jsdom Differences

```javascript
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');
const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);
```

Key differences from browser DOM:
- `<noscript>` content may be parsed as HTML in jsdom (scripting disabled) but as raw text in browsers (scripting enabled)
- Form-based DOM clobbering does not reproduce identically in jsdom
- SVG/MathML namespace switching may have subtle differences
- Performance: jsdom is significantly slower, potentially triggering error-handling fallbacks

### D2. linkedom and happy-dom

```javascript
const { parseHTML } = require('linkedom');
const { document } = parseHTML('');
const DOMPurify = createDOMPurify({ document });
```

Even less spec-compliant than jsdom in edge cases. **CVE-2024-51757:** happy-dom had a full RCE vulnerability.

### D3. Server/Browser Parsing Differences

| Feature | Browser | jsdom/linkedom |
|---------|---------|----------------|
| `<noscript>` parsing | Raw text (scripting on) | HTML (scripting off) |
| DOM clobbering on forms | Full LegacyOverrideBuiltIns | Partial or missing |
| Error recovery edge cases | Battle-tested | May differ |
| Character encoding detection | Browser-specific | Library-specific |
| Quirks mode behavior | Browser-specific | May not replicate |

### D4. Shared DOM Instances

```javascript
// VULNERABLE: Hooks accumulate across requests
app.post('/sanitize', (req, res) => {
  DOMPurify.addHook('afterSanitizeAttributes', customHook);
  const clean = DOMPurify.sanitize(req.body.html);
  res.json({ html: clean });
  // Hook persists for all subsequent requests
});
```

### D5. Different Policies Across Server and Client

```javascript
// Server: permissive (trusts itself)
const serverClean = DOMPurify.sanitize(html, {
  ADD_TAGS: ['iframe', 'video'],
});

// Client: strict
const clientClean = DOMPurify.sanitize(serverHtml, {
  ALLOWED_TAGS: ['p', 'b', 'i', 'a'],
});
```

### D6. HTML Serialization Differences

Server-side DOM implementations may serialize:
- Self-closing tags differently (`<div/>` vs `<div></div>`)
- Attribute quoting differently (single vs double)
- Entity encoding differently
- Namespace prefixes differently
- Whitespace differently

These differences mean HTML sanitized and serialized on the server may parse into a different DOM tree in the browser, potentially re-enabling mXSS.

### D7. SSR-to-Hydration Pipeline

1. Server sanitizes with jsdom
2. Server renders via React/Vue SSR
3. HTML sent to client
4. Client hydrates -- may modify DOM
5. Client re-renders with unsanitized data from WebSocket/API

### D8. Old Persisted Content

```
2023: Sanitized with DOMPurify 2.x, <style> allowed, no SAFE_FOR_XML rawtext checks
2024: DOMPurify 3.x, SAFE_FOR_XML enabled, stricter rawtext handling
2025: Policy updated to strip <style> entirely
2026: Database content from 2023 still served without re-sanitization
```

Content must be re-sanitized when policies change. Multiple CVEs (CVE-2024-45801, CVE-2025-15599, CVE-2026-0540, CVE-2026-41238, CVE-2026-41239) have required policy updates.

## 2.5 Model E -- DOMPurify Implementation Defects

**Root cause:** Bugs in DOMPurify itself, in the DOM implementations it relies on, or in the integration patterns it documents.

### Class 1: Implementation Defects (~21 CVEs)

Bugs in DOMPurify's own sanitization logic:

| CVE | Description | CVSS |
|-----|-------------|------|
| CVE-2024-47875 | Nesting-based mXSS | 10.0 |
| CVE-2024-48910 | Prototype pollution sanitizer tampering | 9.1 |
| CVE-2024-45801 | Depth check bypass via nesting | 7.0 |
| CVE-2026-41240 | ADD_TAGS function bypasses FORBID_TAGS | 8.2 |
| CVE-2026-75838 | IN_PLACE hook detached subtree XSS | 7.5 |
| CVE-2025-26791 | SAFE_FOR_TEMPLATES regex error | 4.5 |
| CVE-2025-15599 | SAFE_FOR_XML textarea rawtext bypass | 5.1 |
| CVE-2026-0540 | SAFE_FOR_XML missing rawtext elements | 6.1 |
| CVE-2026-41238 | Prototype pollution via CUSTOM_ELEMENT_HANDLING | 7.1 |
| CVE-2026-41239 | SAFE_FOR_TEMPLATES bypass in RETURN_DOM | 6.8 |
| CVE-2026-65902 | Hook mutation pollutes default allowlists | 6.1 |
| CVE-2026-65903 | ADD_TAGS function short-circuits FORBID_TAGS | 6.1 |
| CVE-2026-65911 | ADD_TAGS/ADD_ATTR state leakage across calls | 4.7 |
| CVE-2026-65912 | ADD_ATTR predicate skips URI validation | 6.1 |
| CVE-2026-65898 | setConfig() permanently pollutes ALLOWED_ATTR | 7.2 |
| CVE-2026-65899 | Trusted Types policy survives clearConfig() | 6.1 |
| CVE-2026-65900 | SAFE_FOR_TEMPLATES bypass in template.content | 6.1 |
| CVE-2026-65901 | IN_PLACE trusts attacker-controlled nodeName | 6.1 |
| CVE-2026-65913 | USE_PROFILES prototype pollution allows handlers | 6.1 |
| CVE-2026-66010 | Custom elements bypass afterSanitizeElements hook | 6.1 |
| GHSA-mjjq-c88q-qhr6 | mXSS bypass (pre-2.0.7) | Critical |

### Class 2: DOM/Browser Behaviors (3 CVEs)

Issues from differences in DOM parser implementations:

| CVE | Description | CVSS |
|-----|-------------|------|
| CVE-2020-26870 | MathML namespace confusion mXSS | 6.1 |
| CVE-2019-16728 | SVG/Math closing tag confusion mXSS | 6.1 |
| CVE-2026-47423 | `selectedcontent` re-clone bypass | 8.2 |

### Class 3: Integration Patterns (6 CVEs)

Vulnerabilities triggered by how applications use DOMPurify:

| CVE | Description | CVSS |
|-----|-------------|------|
| CVE-2026-49978 | IN_PLACE shadow root inside template.content | 8.1 |
| CVE-2026-49459 | IN_PLACE clobbered root retains attributes | 6.1 |
| CVE-2026-49458 | Cross-realm IN_PLACE bypass | 6.1 |
| CVE-2026-65914 | mXSS via re-contextualization | 6.9 |
| CVE-2026-65904 | IN_PLACE fails on cross-window elements | 4.7 |
| CVE-2019-25155 | Open redirect in demo file | 6.1 |

---
