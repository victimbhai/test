#!/usr/bin/env python3
"""
DOM XSS Scanner - DOM-Based Cross-Site Scripting Source-Sink Analyzer
======================================================================

A comprehensive static analysis tool that crawls JavaScript files from target
URLs and identifies dangerous source-to-sink data flows that lead to DOM-based
XSS vulnerabilities.

Features:
- Crawls and extracts JavaScript from target pages and linked .js files
- 50+ regex patterns for source-sink detection
- Maps data flow from sources (location.hash, URLSearchParams, etc.) to sinks
- Detects framework-specific patterns (React, Angular, Vue, jQuery)
- Configurable crawl depth for JS file discovery
- Direct JS file analysis mode
- Severity classification and remediation advice
- JSON and text output formats
- Proxy support for testing through intercepting proxies

Usage:
    python3 dom-xss-scanner.py -u "https://target.com"
    python3 dom-xss-scanner.py -u "https://target.com" --crawl --depth 2
    python3 dom-xss-scanner.py --js-files app.js,vendor.js -u "https://target.com"
    python3 dom-xss-scanner.py -u "https://target.com" --crawl --output json -o report.json

Author: Security Research Team
License: For authorized security testing only

NOTE: This security testing tool references dangerous JavaScript patterns
(innerHTML, eval, setTimeout with strings, etc.) as detection signatures
for identifying DOM-based XSS vulnerabilities during authorized assessments.
"""

import argparse
import json
import re
import sys
import time
import urllib.parse
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Set, Tuple, Any
from datetime import datetime
import warnings

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print("[-] Required dependencies: pip install requests beautifulsoup4")
    sys.exit(1)

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# ============================================================================
# CONFIGURATION
# ============================================================================

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
DEFAULT_TIMEOUT = 15
DEFAULT_CRAWL_DEPTH = 1
MAX_JS_FILE_SIZE = 10 * 1024 * 1024  # 10 MB limit per file

# ============================================================================
# TERMINAL COLORS
# ============================================================================

class Colors:
    """ANSI color codes for terminal output."""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        for attr in ['RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'BOLD', 'END']:
            setattr(Colors, attr, '')


class Logger:
    """Logging utility with colored output."""
    verbose = False

    @staticmethod
    def info(msg: str):
        print(f"{Colors.BLUE}[*]{Colors.END} {msg}")

    @staticmethod
    def success(msg: str):
        print(f"{Colors.GREEN}[+]{Colors.END} {msg}")

    @staticmethod
    def warning(msg: str):
        print(f"{Colors.YELLOW}[!]{Colors.END} {msg}")

    @staticmethod
    def error(msg: str):
        print(f"{Colors.RED}[-]{Colors.END} {msg}")

    @staticmethod
    def vuln(msg: str):
        print(f"{Colors.RED}{Colors.BOLD}[VULN]{Colors.END} {msg}")

    @staticmethod
    def debug(msg: str):
        if Logger.verbose:
            print(f"{Colors.CYAN}[D]{Colors.END} {msg}")


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class SourcePattern:
    """A DOM XSS source pattern definition."""
    name: str
    category: str          # url, storage, message, dom, network
    regex: str
    description: str
    risk: str              # high, medium, low

@dataclass
class SinkPattern:
    """A DOM XSS sink pattern definition."""
    name: str
    category: str          # html_injection, js_execution, url_redirect, resource_load
    regex: str
    description: str
    severity: str          # critical, high, medium, low

@dataclass
class FrameworkPattern:
    """A framework-specific dangerous pattern."""
    name: str
    framework: str
    regex: str
    description: str
    severity: str

@dataclass
class DOMXSSFinding:
    """A detected DOM XSS source-sink pattern or dangerous usage."""
    file_url: str
    finding_type: str      # source-sink, source, sink, framework
    source_name: str
    source_category: str
    sink_name: str
    sink_category: str
    severity: str
    confidence: str        # high, medium, low
    line_number: int
    code_snippet: str
    description: str
    remediation: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# ============================================================================
# SOURCE PATTERNS (User-controllable input)
# ============================================================================

SOURCE_PATTERNS = [
    # URL-based sources
    SourcePattern("location.hash", "url", r"(?:document\.location|location|window\.location)\.hash", "URL fragment identifier - user controlled after #", "high"),
    SourcePattern("location.search", "url", r"(?:document\.location|location|window\.location)\.search", "URL query string - user controlled after ?", "high"),
    SourcePattern("location.href", "url", r"(?:document\.location|location|window\.location)\.href", "Full URL - partially user controlled", "high"),
    SourcePattern("location.pathname", "url", r"(?:document\.location|location|window\.location)\.pathname", "URL path component", "medium"),
    SourcePattern("location.host", "url", r"(?:document\.location|location|window\.location)\.host(?:name)?", "URL hostname - less commonly exploitable", "low"),
    SourcePattern("document.URL", "url", r"document\.URL", "Full document URL string", "high"),
    SourcePattern("document.documentURI", "url", r"document\.documentURI", "Document URI - similar to document.URL", "high"),
    SourcePattern("document.baseURI", "url", r"document\.baseURI", "Base URI of the document", "medium"),
    SourcePattern("document.referrer", "url", r"document\.referrer", "Referring page URL - attacker can control via link", "high"),
    SourcePattern("window.name", "dom", r"window\.name", "Window name - persists across navigations, attacker controlled", "high"),
    SourcePattern("document.cookie", "dom", r"document\.cookie", "Document cookies - may contain attacker-injected values", "medium"),
    SourcePattern("document.title", "dom", r"document\.title", "Document title element content", "low"),

    # URLSearchParams
    SourcePattern("URLSearchParams", "url", r"new\s+URLSearchParams\s*\(", "URLSearchParams constructor - parses query strings", "high"),
    SourcePattern("URLSearchParams.get", "url", r"\.get\s*\(\s*['\"]", "URLSearchParams.get() - extracts single parameter", "high"),
    SourcePattern("URLSearchParams.getAll", "url", r"\.getAll\s*\(\s*['\"]", "URLSearchParams.getAll() - extracts parameter array", "high"),

    # Web Messaging
    SourcePattern("postMessage handler", "message", r"(?:addEventListener|attachEvent)\s*\(\s*['\"]message['\"]", "postMessage event listener - receives cross-origin messages", "high"),
    SourcePattern("event.data", "message", r"(?:event|e|evt|msg)\.data", "Message event data property - attacker controlled via postMessage", "high"),
    SourcePattern("event.origin", "message", r"(?:event|e|evt|msg)\.origin", "Message event origin - should be validated", "medium"),

    # Storage sources
    SourcePattern("localStorage.getItem", "storage", r"localStorage\.getItem\s*\(", "localStorage read - may contain attacker-planted data", "medium"),
    SourcePattern("localStorage[]", "storage", r"localStorage\[", "localStorage bracket access", "medium"),
    SourcePattern("sessionStorage.getItem", "storage", r"sessionStorage\.getItem\s*\(", "sessionStorage read - may contain attacker-planted data", "medium"),
    SourcePattern("sessionStorage[]", "storage", r"sessionStorage\[", "sessionStorage bracket access", "medium"),
    SourcePattern("IndexedDB", "storage", r"(?:indexedDB|IDBDatabase)\.open", "IndexedDB access - stored data may be tainted", "low"),

    # Network sources
    SourcePattern("fetch response", "network", r"\.then\s*\(\s*(?:function\s*\()?\s*(?:response|res|r)\s*(?:\)|=>)", "Fetch API response handler - data from network", "medium"),
    SourcePattern("XMLHttpRequest.response", "network", r"\.response(?:Text|XML)?", "XHR response data", "medium"),
    SourcePattern("WebSocket.onmessage", "network", r"\.onmessage\s*=|addEventListener\s*\(\s*['\"]message['\"]", "WebSocket message handler", "medium"),

    # DOM reading sources
    SourcePattern("innerHTML read", "dom", r"\.innerHTML(?!\s*=)", "Reading innerHTML of an element", "low"),
    SourcePattern("outerHTML read", "dom", r"\.outerHTML(?!\s*=)", "Reading outerHTML of an element", "low"),
    SourcePattern("textContent read", "dom", r"\.textContent(?!\s*=)", "Reading text content (safer but check sink)", "low"),
    SourcePattern("input.value", "dom", r"\.value(?!\s*=)", "Reading form input value - user controlled", "medium"),
]

# ============================================================================
# SINK PATTERNS (Dangerous output/execution)
# ============================================================================

SINK_PATTERNS = [
    # HTML injection sinks
    SinkPattern("innerHTML", "html_injection", r"\.innerHTML\s*(?:\+?=|\+=)", "Direct HTML injection into DOM element", "critical"),
    SinkPattern("outerHTML", "html_injection", r"\.outerHTML\s*(?:\+?=|\+=)", "Replaces entire element with attacker HTML", "critical"),
    SinkPattern("insertAdjacentHTML", "html_injection", r"\.insertAdjacentHTML\s*\(", "Inserts HTML at specified position", "critical"),
    SinkPattern("document.write", "html_injection", r"document\.write\s*\(", "Writes directly to document - classic DOM XSS sink", "critical"),
    SinkPattern("document.writeln", "html_injection", r"document\.writeln\s*\(", "Writes line to document - classic DOM XSS sink", "critical"),
    SinkPattern("document.body.innerHTML", "html_injection", r"document\.body\.innerHTML\s*(?:\+?=|\+=)", "Direct body HTML replacement", "critical"),
    SinkPattern("DOMParser.parseFromString", "html_injection", r"\.parseFromString\s*\(", "Parses string as HTML/XML document", "medium"),
    SinkPattern("Range.createContextualFragment", "html_injection", r"\.createContextualFragment\s*\(", "Creates HTML fragment from string", "high"),

    # JavaScript execution sinks
    # NOTE: These patterns detect dangerous JS code execution sinks for security analysis.
    # The scanner itself never invokes these functions.
    SinkPattern("eval()", "js_execution", r"(?<![.\w])eval\s*\(", "Direct JavaScript code execution via eval()", "critical"),
    SinkPattern("Function constructor", "js_execution", r"(?:new\s+Function|Function)\s*\(", "Dynamic function creation from string", "critical"),
    SinkPattern("setTimeout (string)", "js_execution", r"setTimeout\s*\(\s*(?:['\"`]|[a-zA-Z_$][\w.]*\s*(?:\+|\,))", "setTimeout with string argument executes as code", "high"),
    SinkPattern("setInterval (string)", "js_execution", r"setInterval\s*\(\s*(?:['\"`]|[a-zA-Z_$][\w.]*\s*(?:\+|\,))", "setInterval with string argument executes as code", "high"),
    SinkPattern("execScript", "js_execution", r"execScript\s*\(", "IE-specific JavaScript execution", "critical"),
    SinkPattern("msSetImmediate", "js_execution", r"msSetImmediate\s*\(", "IE setImmediate with string code", "high"),
    SinkPattern("script.src assignment", "js_execution", r"\.src\s*=(?!\s*['\"]https?://)", "Script source assignment - may load attacker JS", "high"),
    SinkPattern("script.textContent", "js_execution", r"script.*\.textContent\s*=", "Setting script element text executes as code", "critical"),
    SinkPattern("script.text", "js_execution", r"script.*\.text\s*=", "Setting script element text executes as code", "critical"),
    SinkPattern("import()", "js_execution", r"import\s*\(", "Dynamic import - loads and executes module", "high"),

    # URL/navigation sinks
    SinkPattern("location assignment", "url_redirect", r"(?:document\.location|location|window\.location)\s*=", "Direct location assignment - open redirect / javascript: execution", "high"),
    SinkPattern("location.href assignment", "url_redirect", r"(?:document\.location|location|window\.location)\.href\s*=", "Location href assignment - open redirect / javascript:", "high"),
    SinkPattern("location.assign", "url_redirect", r"(?:document\.location|location|window\.location)\.assign\s*\(", "Location assign method - open redirect / javascript:", "high"),
    SinkPattern("location.replace", "url_redirect", r"(?:document\.location|location|window\.location)\.replace\s*\(", "Location replace method - open redirect / javascript:", "high"),
    SinkPattern("window.open", "url_redirect", r"window\.open\s*\(", "Opens new window/tab with attacker-controlled URL", "high"),
    SinkPattern("anchor.href assignment", "url_redirect", r"\.href\s*=(?!.*(?:location|document))", "Setting anchor href - javascript: protocol possible", "medium"),
    SinkPattern("form.action assignment", "url_redirect", r"\.action\s*=", "Setting form action URL", "medium"),

    # Resource loading sinks
    SinkPattern("iframe.src", "resource_load", r"iframe.*\.src\s*=", "Setting iframe source - loads attacker content", "high"),
    SinkPattern("embed.src", "resource_load", r"embed.*\.src\s*=", "Setting embed source", "high"),
    SinkPattern("object.data", "resource_load", r"object.*\.data\s*=", "Setting object data URL", "high"),
    SinkPattern("img.src", "resource_load", r"(?:img|image).*\.src\s*=", "Setting image source (limited impact but info leak)", "low"),
    SinkPattern("source.src", "resource_load", r"source.*\.src\s*=", "Setting media source element", "medium"),
    SinkPattern("link.href", "resource_load", r"link.*\.href\s*=", "Setting stylesheet/resource link href", "medium"),

    # DOM manipulation sinks
    SinkPattern("element.setAttribute", "html_injection", r"\.setAttribute\s*\(\s*['\"](?:on\w+|href|src|action|data|style|background)['\"]", "Setting dangerous attributes with user input", "high"),
    SinkPattern("element.style.cssText", "html_injection", r"\.style\.cssText\s*=", "Direct CSS text injection - expression() possible in IE", "medium"),
    SinkPattern("element.className", "html_injection", r"\.className\s*(?:\+?=|\+=)", "Class name manipulation (low risk unless CSS injection)", "low"),

    # jQuery sinks
    SinkPattern("jQuery.html()", "html_injection", r"\$\s*\([^)]*\)\s*\.html\s*\(", "jQuery .html() sets innerHTML - DOM XSS sink", "critical"),
    SinkPattern("jQuery.append()", "html_injection", r"\$\s*\([^)]*\)\s*\.append\s*\(", "jQuery .append() parses HTML strings", "high"),
    SinkPattern("jQuery.prepend()", "html_injection", r"\$\s*\([^)]*\)\s*\.prepend\s*\(", "jQuery .prepend() parses HTML strings", "high"),
    SinkPattern("jQuery.after()", "html_injection", r"\$\s*\([^)]*\)\s*\.after\s*\(", "jQuery .after() parses HTML strings", "high"),
    SinkPattern("jQuery.before()", "html_injection", r"\$\s*\([^)]*\)\s*\.before\s*\(", "jQuery .before() parses HTML strings", "high"),
    SinkPattern("jQuery.replaceWith()", "html_injection", r"\$\s*\([^)]*\)\s*\.replaceWith\s*\(", "jQuery .replaceWith() parses HTML strings", "high"),
    SinkPattern("jQuery.wrap()", "html_injection", r"\$\s*\([^)]*\)\s*\.wrap(?:All|Inner)?\s*\(", "jQuery .wrap() parses HTML strings", "medium"),
    SinkPattern("jQuery.constructor $() HTML", "html_injection", r"\$\s*\(\s*['\"]?\s*<", "jQuery $() with HTML string creates DOM elements", "high"),
    SinkPattern("jQuery.constructor $(var)", "html_injection", r"\$\s*\(\s*(?!this|document|window|['\"][\s#.\[:])[a-zA-Z_$]", "jQuery $() with variable - may parse as HTML if starts with <", "medium"),
    SinkPattern("jQuery.globalEval", "js_execution", r"jQuery\.globalEval\s*\(|\.globalEval\s*\(", "jQuery global eval execution", "critical"),
    SinkPattern("jQuery.parseHTML", "html_injection", r"jQuery\.parseHTML\s*\(|\$\.parseHTML\s*\(", "jQuery.parseHTML - parses HTML string", "high"),

    # Underscore/Lodash template
    SinkPattern("_.template", "js_execution", r"_\.template\s*\(", "Underscore/Lodash template - can execute JS", "high"),
]

# ============================================================================
# FRAMEWORK-SPECIFIC PATTERNS
# ============================================================================

FRAMEWORK_PATTERNS = [
    # React
    FrameworkPattern("React dangerouslySetInnerHTML", "React", r"dangerouslySetInnerHTML\s*(?:=\s*\{|:\s*\{)", "React explicit dangerous HTML insertion - bypasses React XSS protection", "critical"),
    FrameworkPattern("React ref innerHTML", "React", r"ref\.current\.innerHTML\s*=", "React ref used to set innerHTML directly - bypasses virtual DOM", "critical"),
    FrameworkPattern("React createRef innerHTML", "React", r"createRef\(\).*\.innerHTML", "React createRef followed by innerHTML assignment", "high"),

    # Angular
    FrameworkPattern("Angular bypassSecurityTrustHtml", "Angular", r"bypassSecurityTrustHtml\s*\(", "Angular DomSanitizer bypass - trusts arbitrary HTML", "critical"),
    FrameworkPattern("Angular bypassSecurityTrustScript", "Angular", r"bypassSecurityTrustScript\s*\(", "Angular DomSanitizer bypass - trusts arbitrary scripts", "critical"),
    FrameworkPattern("Angular bypassSecurityTrustStyle", "Angular", r"bypassSecurityTrustStyle\s*\(", "Angular DomSanitizer bypass - trusts arbitrary styles", "high"),
    FrameworkPattern("Angular bypassSecurityTrustUrl", "Angular", r"bypassSecurityTrustUrl\s*\(", "Angular DomSanitizer bypass - trusts arbitrary URLs", "high"),
    FrameworkPattern("Angular bypassSecurityTrustResourceUrl", "Angular", r"bypassSecurityTrustResourceUrl\s*\(", "Angular DomSanitizer bypass - trusts resource URLs", "high"),
    FrameworkPattern("Angular [innerHTML] binding", "Angular", r"\[innerHTML\]\s*=", "Angular innerHTML binding - potentially dangerous with user input", "high"),
    FrameworkPattern("Angular ng-bind-html", "Angular", r"ng-bind-html\s*=", "AngularJS ng-bind-html directive", "high"),

    # Vue.js
    FrameworkPattern("Vue v-html directive", "Vue", r"v-html\s*=", "Vue v-html directive - renders raw HTML, XSS risk", "critical"),
    FrameworkPattern("Vue compile()", "Vue", r"Vue\.compile\s*\(|\.compile\s*\(", "Vue template compilation from string", "high"),
    FrameworkPattern("Vue template string", "Vue", r"template\s*:\s*[`'\"].*\$\{", "Vue template with string interpolation", "medium"),
    FrameworkPattern("Vue render innerHTML", "Vue", r"createElement\s*\(.*innerHTML|h\s*\(.*innerHTML", "Vue render function with innerHTML", "high"),

    # Svelte
    FrameworkPattern("Svelte @html", "Svelte", r"@html\s+", "Svelte @html tag - renders raw HTML", "critical"),

    # Handlebars/Mustache (triple-stache = unescaped)
    FrameworkPattern("Handlebars triple-stache", "Handlebars", r"\{\{\{.*\}\}\}", "Handlebars triple-mustache - unescaped HTML output", "high"),
    FrameworkPattern("Handlebars SafeString", "Handlebars", r"Handlebars\.SafeString\s*\(|SafeString\s*\(", "Handlebars SafeString - marks content as safe/unescaped", "high"),

    # EJS
    FrameworkPattern("EJS unescaped output", "EJS", r"<%[-=]\s*", "EJS unescaped output tag", "medium"),

    # Polymer
    FrameworkPattern("Polymer innerHTML binding", "Polymer", r"innerHTML\$\s*=|inner-h-t-m-l\s*=", "Polymer innerHTML binding", "high"),

    # Generic template injection
    FrameworkPattern("Template literal HTML", "Generic", r"`\s*<[^>]*\$\{.*\}[^`]*`", "Template literal containing HTML with interpolation", "medium"),
]


# ============================================================================
# REMEDIATION ADVICE
# ============================================================================

REMEDIATION = {
    "html_injection": (
        "Use textContent or innerText instead of innerHTML. "
        "If HTML insertion is required, sanitize input using DOMPurify or a trusted HTML sanitizer. "
        "Apply Content-Security-Policy headers to mitigate impact."
    ),
    "js_execution": (
        "Never pass user-controlled data to eval(), Function(), setTimeout(string), or setInterval(string). "
        "Use setTimeout/setInterval with function references instead of strings. "
        "Apply strict CSP with no unsafe-eval."
    ),
    "url_redirect": (
        "Validate URLs against an allowlist of trusted schemes (http:, https:) before assignment. "
        "Explicitly block javascript:, data:, and vbscript: protocols. "
        "Use URL parsing to validate origin before redirect."
    ),
    "resource_load": (
        "Validate resource URLs against trusted origins. "
        "Use a Content-Security-Policy with restrictive frame-src, img-src, and object-src directives. "
        "Sanitize URLs before setting src/data attributes."
    ),
    "framework": (
        "Avoid framework security bypasses (dangerouslySetInnerHTML, bypassSecurityTrust*, v-html). "
        "Use framework-native safe rendering methods. "
        "If raw HTML is required, sanitize with DOMPurify before passing to the framework."
    ),
}


# ============================================================================
# JAVASCRIPT CRAWLER
# ============================================================================

class JSCrawler:
    """Crawls target URLs and extracts JavaScript content."""

    def __init__(self, timeout: int = DEFAULT_TIMEOUT, proxy: Optional[str] = None,
                 headers: Optional[Dict] = None, cookies: Optional[Dict] = None):
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': DEFAULT_USER_AGENT})
        self.session.verify = False
        self.timeout = timeout

        if headers:
            self.session.headers.update(headers)
        if cookies:
            self.session.cookies.update(cookies)
        if proxy:
            self.session.proxies = {'http': proxy, 'https': proxy}

    def fetch_page(self, url: str) -> Optional[str]:
        """Fetch an HTML page."""
        try:
            resp = self.session.get(url, timeout=self.timeout)
            resp.raise_for_status()
            return resp.text
        except requests.RequestException as e:
            Logger.error(f"Failed to fetch {url}: {e}")
            return None

    def fetch_js(self, url: str) -> Optional[str]:
        """Fetch a JavaScript file."""
        try:
            resp = self.session.get(url, timeout=self.timeout)
            if resp.status_code != 200:
                Logger.debug(f"HTTP {resp.status_code} for {url}")
                return None
            if len(resp.content) > MAX_JS_FILE_SIZE:
                Logger.warning(f"Skipping {url} - exceeds {MAX_JS_FILE_SIZE // (1024*1024)}MB limit")
                return None
            return resp.text
        except requests.RequestException as e:
            Logger.debug(f"Failed to fetch JS {url}: {e}")
            return None

    def extract_js_urls(self, html: str, base_url: str) -> Set[str]:
        """Extract JavaScript file URLs from HTML."""
        js_urls = set()
        soup = BeautifulSoup(html, 'html.parser')

        # External script tags
        for script in soup.find_all('script', src=True):
            src = script['src'].strip()
            if src:
                absolute = urllib.parse.urljoin(base_url, src)
                js_urls.add(absolute)

        # Also check for dynamically loaded scripts in inline code
        for script in soup.find_all('script', src=False):
            if script.string:
                # Look for patterns like: src = "something.js"
                for match in re.finditer(r'''(?:src|href)\s*[=:]\s*['"]([^'"]*\.js(?:\?[^'"]*)?)['"]\s''', script.string):
                    absolute = urllib.parse.urljoin(base_url, match.group(1))
                    js_urls.add(absolute)

        return js_urls

    def extract_inline_js(self, html: str) -> List[Tuple[str, str]]:
        """Extract inline JavaScript blocks from HTML. Returns list of (label, code)."""
        blocks = []
        soup = BeautifulSoup(html, 'html.parser')

        for i, script in enumerate(soup.find_all('script', src=False)):
            if script.string and script.string.strip():
                blocks.append((f"inline-block-{i}", script.string))

        # Also check event handler attributes
        event_attrs = [
            'onclick', 'onload', 'onerror', 'onmouseover', 'onmouseout',
            'onfocus', 'onblur', 'onsubmit', 'onchange', 'oninput',
            'onkeydown', 'onkeyup', 'onkeypress',
        ]
        for tag in soup.find_all(True):
            for attr in event_attrs:
                if tag.get(attr):
                    blocks.append((f"event-{attr}-{tag.name}", tag[attr]))

        return blocks

    def extract_linked_pages(self, html: str, base_url: str) -> Set[str]:
        """Extract same-origin page links for deeper crawling."""
        links = set()
        soup = BeautifulSoup(html, 'html.parser')
        base_parsed = urllib.parse.urlparse(base_url)

        for a in soup.find_all('a', href=True):
            href = a['href'].strip()
            if href.startswith(('#', 'mailto:', 'tel:', 'javascript:')):
                continue
            absolute = urllib.parse.urljoin(base_url, href)
            parsed = urllib.parse.urlparse(absolute)
            # Same origin only
            if parsed.netloc == base_parsed.netloc and parsed.scheme in ('http', 'https'):
                links.add(absolute)

        return links

    def crawl(self, start_url: str, depth: int = DEFAULT_CRAWL_DEPTH) -> Dict[str, str]:
        """
        Crawl starting from a URL, collecting all JavaScript content.
        Returns dict of {url_or_label: js_content}.
        """
        js_contents = {}
        visited_pages = set()
        visited_js = set()
        pages_to_visit = [(start_url, 0)]

        while pages_to_visit:
            page_url, current_depth = pages_to_visit.pop(0)

            if page_url in visited_pages:
                continue
            visited_pages.add(page_url)

            Logger.info(f"Crawling page (depth {current_depth}): {page_url}")
            html = self.fetch_page(page_url)
            if not html:
                continue

            # Extract inline JavaScript
            inline_blocks = self.extract_inline_js(html)
            for label, code in inline_blocks:
                key = f"{page_url}#{label}"
                js_contents[key] = code
                Logger.debug(f"Found inline JS: {label} ({len(code)} chars)")

            # Extract and fetch external JS files
            js_urls = self.extract_js_urls(html, page_url)
            for js_url in js_urls:
                if js_url in visited_js:
                    continue
                visited_js.add(js_url)

                Logger.info(f"Fetching JS: {js_url}")
                js_code = self.fetch_js(js_url)
                if js_code:
                    js_contents[js_url] = js_code
                    Logger.debug(f"Fetched {js_url} ({len(js_code)} chars)")

            # Crawl deeper if depth allows
            if current_depth < depth:
                linked_pages = self.extract_linked_pages(html, page_url)
                for link in linked_pages:
                    if link not in visited_pages:
                        pages_to_visit.append((link, current_depth + 1))

        Logger.success(
            f"Crawl complete: {len(visited_pages)} page(s), "
            f"{len(js_contents)} JS source(s) collected"
        )
        return js_contents


# ============================================================================
# DOM XSS ANALYZER
# ============================================================================

class DOMXSSAnalyzer:
    """Analyzes JavaScript code for DOM XSS source-sink patterns."""

    def __init__(self):
        # Pre-compile all regex patterns for performance
        self.compiled_sources = [
            (sp, re.compile(sp.regex, re.IGNORECASE))
            for sp in SOURCE_PATTERNS
        ]
        self.compiled_sinks = [
            (sp, re.compile(sp.regex, re.IGNORECASE))
            for sp in SINK_PATTERNS
        ]
        self.compiled_frameworks = [
            (fp, re.compile(fp.regex, re.IGNORECASE))
            for fp in FRAMEWORK_PATTERNS
        ]

    def _get_line_number(self, code: str, position: int) -> int:
        """Get the 1-based line number for a character position."""
        return code[:position].count('\n') + 1

    def _get_code_snippet(self, code: str, position: int, context_chars: int = 120) -> str:
        """Extract a code snippet around a match position."""
        start = max(0, position - context_chars)
        end = min(len(code), position + context_chars)
        snippet = code[start:end].strip()
        snippet = re.sub(r'\s+', ' ', snippet)
        if start > 0:
            snippet = "..." + snippet
        if end < len(code):
            snippet = snippet + "..."
        return snippet

    def find_sources(self, code: str, file_url: str) -> List[Dict]:
        """Find all source patterns in the code."""
        found = []
        for sp, compiled in self.compiled_sources:
            for match in compiled.finditer(code):
                found.append({
                    'pattern': sp,
                    'match': match.group(),
                    'position': match.start(),
                    'line': self._get_line_number(code, match.start()),
                    'snippet': self._get_code_snippet(code, match.start()),
                })
        return found

    def find_sinks(self, code: str, file_url: str) -> List[Dict]:
        """Find all sink patterns in the code."""
        found = []
        for sp, compiled in self.compiled_sinks:
            for match in compiled.finditer(code):
                found.append({
                    'pattern': sp,
                    'match': match.group(),
                    'position': match.start(),
                    'line': self._get_line_number(code, match.start()),
                    'snippet': self._get_code_snippet(code, match.start()),
                })
        return found

    def find_framework_patterns(self, code: str, file_url: str) -> List[Dict]:
        """Find framework-specific dangerous patterns."""
        found = []
        for fp, compiled in self.compiled_frameworks:
            for match in compiled.finditer(code):
                found.append({
                    'pattern': fp,
                    'match': match.group(),
                    'position': match.start(),
                    'line': self._get_line_number(code, match.start()),
                    'snippet': self._get_code_snippet(code, match.start()),
                })
        return found

    def _proximity_check(self, source_pos: int, sink_pos: int, code: str,
                         max_line_distance: int = 30) -> bool:
        """
        Check if a source and sink are in proximity (heuristic for data flow).
        Returns True if they are within a reasonable line distance.
        """
        source_line = self._get_line_number(code, source_pos)
        sink_line = self._get_line_number(code, sink_pos)
        return abs(source_line - sink_line) <= max_line_distance

    def _variable_flow_check(self, code: str, source_match: Dict, sink_match: Dict) -> bool:
        """
        Heuristic: check if a variable assigned from a source flows to a sink.
        Looks for pattern like: var x = source; ... sink(x) or sink = x.
        """
        # Extract the region between source and sink (or reverse)
        start = min(source_match['position'], sink_match['position'])
        end = max(source_match['position'], sink_match['position']) + 200
        region = code[start:min(end, len(code))]

        # Look for variable assignments from the source
        source_text = source_match['match']
        var_pattern = re.compile(
            r'(?:var|let|const)?\s*(\w+)\s*=\s*.*?' + re.escape(source_text),
            re.DOTALL
        )
        var_match = var_pattern.search(region)
        if var_match:
            var_name = var_match.group(1)
            sink_text = sink_match['snippet']
            if var_name in sink_text:
                return True

        return False

    def analyze(self, code: str, file_url: str) -> List[DOMXSSFinding]:
        """
        Perform full DOM XSS analysis on JavaScript code.
        Returns list of findings with source-sink mappings.
        """
        findings = []

        sources = self.find_sources(code, file_url)
        sinks = self.find_sinks(code, file_url)
        fw_patterns = self.find_framework_patterns(code, file_url)

        Logger.debug(
            f"  {file_url}: {len(sources)} source(s), "
            f"{len(sinks)} sink(s), {len(fw_patterns)} framework pattern(s)"
        )

        # Source-Sink correlation (proximity + variable flow heuristics)
        matched_sinks = set()
        for source in sources:
            for sink in sinks:
                sp = source['pattern']
                sk = sink['pattern']

                in_proximity = self._proximity_check(
                    source['position'], sink['position'], code
                )
                has_flow = self._variable_flow_check(code, source, sink)

                if in_proximity or has_flow:
                    confidence = "high" if has_flow else "medium"
                    severity = sk.severity

                    # Combine snippets for evidence
                    combined_snippet = (
                        f"SOURCE [{sp.name}] L{source['line']}: {source['snippet']}\n"
                        f"SINK [{sk.name}] L{sink['line']}: {sink['snippet']}"
                    )

                    findings.append(DOMXSSFinding(
                        file_url=file_url,
                        finding_type="source-sink",
                        source_name=sp.name,
                        source_category=sp.category,
                        sink_name=sk.name,
                        sink_category=sk.category,
                        severity=severity,
                        confidence=confidence,
                        line_number=sink['line'],
                        code_snippet=combined_snippet,
                        description=(
                            f"User-controlled data from {sp.name} ({sp.description}) "
                            f"flows to dangerous sink {sk.name} ({sk.description})"
                        ),
                        remediation=REMEDIATION.get(sk.category, "Review and sanitize user input."),
                    ))
                    matched_sinks.add(id(sink))

        # Report unmatched sinks with high severity as standalone findings
        for sink in sinks:
            if id(sink) not in matched_sinks:
                sk = sink['pattern']
                if sk.severity in ('critical', 'high'):
                    findings.append(DOMXSSFinding(
                        file_url=file_url,
                        finding_type="sink",
                        source_name="unknown",
                        source_category="unknown",
                        sink_name=sk.name,
                        sink_category=sk.category,
                        severity=sk.severity,
                        confidence="low",
                        line_number=sink['line'],
                        code_snippet=sink['snippet'],
                        description=(
                            f"Dangerous sink {sk.name} detected ({sk.description}). "
                            f"Manual review needed to determine if user input reaches this sink."
                        ),
                        remediation=REMEDIATION.get(sk.category, "Review and sanitize user input."),
                    ))

        # Report high-risk sources without matched sinks
        for source in sources:
            sp = source['pattern']
            if sp.risk == 'high':
                # Check if this source was already matched
                already_matched = any(
                    f.source_name == sp.name and f.finding_type == "source-sink"
                    for f in findings
                )
                if not already_matched:
                    findings.append(DOMXSSFinding(
                        file_url=file_url,
                        finding_type="source",
                        source_name=sp.name,
                        source_category=sp.category,
                        sink_name="unknown",
                        sink_category="unknown",
                        severity="low",
                        confidence="low",
                        line_number=source['line'],
                        code_snippet=source['snippet'],
                        description=(
                            f"User-controllable source {sp.name} detected ({sp.description}). "
                            f"Trace data flow manually to determine if it reaches a sink."
                        ),
                        remediation="Trace data flow from this source to ensure it does not reach any sinks without sanitization.",
                    ))

        # Framework-specific findings
        for fw in fw_patterns:
            fp = fw['pattern']
            findings.append(DOMXSSFinding(
                file_url=file_url,
                finding_type="framework",
                source_name="user-input",
                source_category="framework",
                sink_name=fp.name,
                sink_category="framework",
                severity=fp.severity,
                confidence="medium",
                line_number=fw['line'],
                code_snippet=fw['snippet'],
                description=(
                    f"Framework-specific dangerous pattern: {fp.name} ({fp.framework}). "
                    f"{fp.description}"
                ),
                remediation=REMEDIATION.get("framework", "Review framework security documentation."),
            ))

        return findings


# ============================================================================
# REPORT GENERATOR
# ============================================================================

class ReportGenerator:
    """Generates structured reports from DOM XSS findings."""

    @staticmethod
    def generate_summary(findings: List[DOMXSSFinding]) -> Dict[str, Any]:
        """Generate a summary report."""
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        type_counts = {'source-sink': 0, 'source': 0, 'sink': 0, 'framework': 0}
        files_affected = set()

        for f in findings:
            severity_counts[f.severity] = severity_counts.get(f.severity, 0) + 1
            type_counts[f.finding_type] = type_counts.get(f.finding_type, 0) + 1
            files_affected.add(f.file_url)

        return {
            'scan_time': datetime.now().isoformat(),
            'total_findings': len(findings),
            'files_analyzed': len(files_affected),
            'severity_summary': severity_counts,
            'finding_type_summary': type_counts,
            'files_affected': sorted(files_affected),
            'findings': [asdict(f) for f in findings],
        }

    @staticmethod
    def print_text_report(findings: List[DOMXSSFinding]):
        """Print a human-readable text report."""
        if not findings:
            print(f"\n  {Colors.GREEN}No DOM XSS patterns detected.{Colors.END}")
            return

        # Group by severity
        by_severity = {'critical': [], 'high': [], 'medium': [], 'low': []}
        for f in findings:
            by_severity.get(f.severity, []).append(f)

        severity_color = {
            'critical': Colors.RED,
            'high': Colors.RED,
            'medium': Colors.YELLOW,
            'low': Colors.CYAN,
        }

        finding_num = 0
        for severity in ['critical', 'high', 'medium', 'low']:
            for f in by_severity[severity]:
                finding_num += 1
                color = severity_color.get(severity, Colors.WHITE)

                print(f"\n  {Colors.BOLD}--- Finding #{finding_num} ---{Colors.END}")
                print(f"  Severity:   {color}{f.severity.upper()}{Colors.END}")
                print(f"  Confidence: {f.confidence}")
                print(f"  Type:       {f.finding_type}")
                print(f"  File:       {f.file_url}")
                print(f"  Line:       {f.line_number}")
                if f.source_name != "unknown":
                    print(f"  Source:     {f.source_name} ({f.source_category})")
                if f.sink_name != "unknown":
                    print(f"  Sink:       {f.sink_name} ({f.sink_category})")
                print(f"  Description: {f.description}")
                print(f"  Code:       {f.code_snippet[:200]}")
                print(f"  Remediation: {f.remediation[:150]}")


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='DOM XSS Scanner - DOM-Based Cross-Site Scripting Source-Sink Analyzer',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s -u "https://target.com"
  %(prog)s -u "https://target.com" --crawl --depth 2
  %(prog)s -u "https://target.com" --crawl --depth 3 --output json -o report.json
  %(prog)s --js-files "https://target.com/js/app.js,https://target.com/js/vendor.js" -u "https://target.com"
  %(prog)s -u "https://target.com" --proxy http://127.0.0.1:8080 --cookies "session=abc123"

Finding Types:
  source-sink   User-controlled source reaches a dangerous sink (highest risk)
  sink          Dangerous sink detected without confirmed source (needs manual review)
  source        User-controllable source without confirmed sink (informational)
  framework     Framework-specific dangerous pattern detected
        """
    )

    parser.add_argument('-u', '--url', required=True,
                        help='Target URL to scan (used as base for crawling and JS resolution)')
    parser.add_argument('--crawl', action='store_true',
                        help='Crawl the target page and linked pages for JavaScript')
    parser.add_argument('--depth', type=int, default=DEFAULT_CRAWL_DEPTH,
                        help=f'Crawl depth for discovering linked pages (default: {DEFAULT_CRAWL_DEPTH})')
    parser.add_argument('--js-files', default='',
                        help='Comma-separated list of JS file URLs to analyze directly')
    parser.add_argument('--output', default='text', choices=['json', 'text'],
                        help='Output format (default: text)')
    parser.add_argument('-o', '--output-file',
                        help='Output file path (for JSON or text report)')
    parser.add_argument('--headers', default='',
                        help='Custom headers as JSON string, e.g. \'{"Authorization": "Bearer xxx"}\'')
    parser.add_argument('--cookies', default='',
                        help='Cookies as "name=value; name2=value2"')
    parser.add_argument('--proxy', default='',
                        help='Proxy URL (e.g., http://127.0.0.1:8080)')
    parser.add_argument('--timeout', type=int, default=DEFAULT_TIMEOUT,
                        help=f'Request timeout in seconds (default: {DEFAULT_TIMEOUT})')
    parser.add_argument('--min-severity', default='low',
                        choices=['critical', 'high', 'medium', 'low'],
                        help='Minimum severity to report (default: low)')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Verbose debug output')
    parser.add_argument('--no-color', action='store_true',
                        help='Disable colored output')

    args = parser.parse_args()

    if args.no_color:
        Colors.disable()

    Logger.verbose = args.verbose

    # Parse optional inputs
    headers = None
    if args.headers:
        try:
            headers = json.loads(args.headers)
        except json.JSONDecodeError:
            Logger.error("Invalid JSON for --headers")
            sys.exit(1)

    cookies = {}
    if args.cookies:
        for part in args.cookies.split(';'):
            if '=' in part:
                k, v = part.strip().split('=', 1)
                cookies[k.strip()] = v.strip()

    # Banner
    print(f"""
{Colors.CYAN}{Colors.BOLD}
 ____   ___  __  __   __  ______ ____
|  _ \\ / _ \\|  \\/  |  \\ \\/ / ___/ ___|
| | | | | | | |\\/| |   \\  /\\___ \\___ \\
| |_| | |_| | |  | |   /  \\ ___) |__) |
|____/ \\___/|_|  |_|  /_/\\_\\____/____/

    DOM-Based XSS Source-Sink Analyzer
{Colors.END}""")

    # Initialize crawler and analyzer
    crawler = JSCrawler(
        timeout=args.timeout,
        proxy=args.proxy if args.proxy else None,
        headers=headers,
        cookies=cookies if cookies else None,
    )
    analyzer = DOMXSSAnalyzer()

    # Collect JavaScript content
    js_contents = {}

    # Direct JS file analysis
    if args.js_files:
        for js_url in args.js_files.split(','):
            js_url = js_url.strip()
            if not js_url:
                continue
            # If it is a relative path, resolve against the base URL
            if not js_url.startswith(('http://', 'https://')):
                js_url = urllib.parse.urljoin(args.url, js_url)
            Logger.info(f"Fetching specified JS: {js_url}")
            code = crawler.fetch_js(js_url)
            if code:
                js_contents[js_url] = code

    # Crawl mode
    if args.crawl or not args.js_files:
        crawled = crawler.crawl(args.url, depth=args.depth if args.crawl else 0)
        js_contents.update(crawled)

    if not js_contents:
        Logger.error("No JavaScript content found to analyze.")
        sys.exit(1)

    Logger.info(f"Analyzing {len(js_contents)} JavaScript source(s)...")

    # Analyze all collected JavaScript
    all_findings = []
    for file_url, code in js_contents.items():
        Logger.debug(f"Analyzing: {file_url} ({len(code)} chars)")
        findings = analyzer.analyze(code, file_url)
        all_findings.extend(findings)

    # Filter by minimum severity
    severity_order = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
    min_level = severity_order.get(args.min_severity, 1)
    filtered = [f for f in all_findings if severity_order.get(f.severity, 0) >= min_level]

    # Sort by severity (critical first)
    filtered.sort(key=lambda f: severity_order.get(f.severity, 0), reverse=True)

    # Print summary header
    print(f"\n{Colors.BOLD}{'=' * 70}")
    print(f"  DOM XSS SCAN RESULTS")
    print(f"{'=' * 70}{Colors.END}")

    report = ReportGenerator.generate_summary(filtered)
    summary = report['severity_summary']

    print(f"  Total Findings: {report['total_findings']}")
    print(f"  Files Analyzed: {len(js_contents)}")
    if summary['critical']:
        print(f"  {Colors.RED}Critical: {summary['critical']}{Colors.END}")
    if summary['high']:
        print(f"  {Colors.RED}High:     {summary['high']}{Colors.END}")
    if summary['medium']:
        print(f"  {Colors.YELLOW}Medium:   {summary['medium']}{Colors.END}")
    if summary['low']:
        print(f"  {Colors.CYAN}Low:      {summary['low']}{Colors.END}")

    # Output findings
    if args.output == 'text':
        ReportGenerator.print_text_report(filtered)
    elif args.output == 'json':
        if not args.output_file:
            print(json.dumps(report, indent=2))

    print(f"\n{'=' * 70}\n")

    # Save to file
    if args.output_file:
        with open(args.output_file, 'w') as fp:
            if args.output == 'json':
                json.dump(report, fp, indent=2)
            else:
                # Text format to file
                lines = []
                lines.append("DOM XSS Scan Report")
                lines.append("=" * 70)
                lines.append(f"Scan Time: {report['scan_time']}")
                lines.append(f"Total Findings: {report['total_findings']}")
                lines.append(f"Severity: {json.dumps(summary)}")
                lines.append("")
                for i, f in enumerate(filtered, 1):
                    lines.append(f"--- Finding #{i} ---")
                    lines.append(f"Severity: {f.severity.upper()}")
                    lines.append(f"Confidence: {f.confidence}")
                    lines.append(f"Type: {f.finding_type}")
                    lines.append(f"File: {f.file_url}")
                    lines.append(f"Line: {f.line_number}")
                    lines.append(f"Source: {f.source_name} ({f.source_category})")
                    lines.append(f"Sink: {f.sink_name} ({f.sink_category})")
                    lines.append(f"Description: {f.description}")
                    lines.append(f"Code: {f.code_snippet}")
                    lines.append(f"Remediation: {f.remediation}")
                    lines.append("")
                fp.write('\n'.join(lines))
        Logger.success(f"Report saved to: {args.output_file}")

    sys.exit(1 if any(f.severity in ('critical', 'high') for f in filtered) else 0)


if __name__ == '__main__':
    main()
