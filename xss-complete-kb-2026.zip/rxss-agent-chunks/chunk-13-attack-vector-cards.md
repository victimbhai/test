# Agent Chunk 13: Attack-Vector Research Cards

**Agent Task:** Use these 8 structured research cards as templates for testing. Each card covers a specific reflected XSS vector with endpoint patterns, required control, missing protections, harmless lab assertions, negative controls, and false positive indicators. Match the target against these patterns to identify the applicable vector.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 23. Attack-Vector Research Cards

### Card RXSS-01: Search Page Reflection

| Field | Value |
|---|---|
| **Vector ID** | RXSS-01 |
| **Endpoint Pattern** | `/search?q=[VALUE]`, `/find?query=[VALUE]`, `/results?term=[VALUE]` |
| **Input Source** | Query parameter (GET) |
| **HTTP Method** | GET |
| **Reflection Location** | Search results heading, "You searched for..." text, page title |
| **Server Transformations** | URL decode → parameter binding → template interpolation |
| **Final Browser Context** | HTML data (text content between tags) |
| **Required Control** | Characters `<`, `>` must survive encoding |
| **Missing Protection** | HTML entity encoding absent or incomplete on search term output |
| **Prerequisites** | None — no authentication typically required |
| **Victim Interaction** | Click a crafted link |
| **Harmless Lab Assertion** | `[HARMLESS_EXECUTION_MARKER]` appears in console in local browser |
| **Negative Control** | Same input with proper HTML encoding → renders as text |
| **False Positives** | Value appears in `<input value="...">` (attribute context, not data context); value in `<meta>` tag (generally non-executable); value only in JSON API response |
| **Impact Ceiling** | Session token access (if `HttpOnly` not set), page defacement, redirect |
| **Remediation** | Apply HTML entity encoding to search term in all output locations; use `textContent` or framework auto-escaping |
| **Regression Test** | Submit `[UNIQUE_REFLECTION_MARKER]<test>` → verify `&lt;test&gt;` in response |
| **Local Sources** | KB-03, KB-35, KB-38 |
| **Confidence** | HIGH — well-documented, common pattern |

### Card RXSS-02: Error/Validation Page Reflection

| Field | Value |
|---|---|
| **Vector ID** | RXSS-02 |
| **Endpoint Pattern** | `/login` (POST error), `/register` (validation error), `/api/resource?id=invalid` |
| **Input Source** | Form field (POST) or query parameter (GET) |
| **HTTP Method** | GET or POST |
| **Reflection Location** | Error message text, validation feedback, "invalid value: ..." |
| **Server Transformations** | URL/form decode → validation → error template rendering |
| **Final Browser Context** | HTML data or HTML attribute (within error message markup) |
| **Required Control** | Characters `<`, `>` for HTML data; `"` or `'` for attributes |
| **Missing Protection** | Error template uses different escaping than main templates; raw value in error message |
| **Prerequisites** | Must trigger an error condition (invalid input, failed login) |
| **Victim Interaction** | Click crafted link (GET) or submit form from attacker page (POST) |
| **Harmless Lab Assertion** | Error page contains `[HARMLESS_EXECUTION_MARKER]` execution evidence |
| **Negative Control** | Error message with proper encoding → invalid input shown as text |
| **False Positives** | Error message in JSON API response (`Content-Type: application/json`); error message in non-HTML format; framework auto-escaping active |
| **Impact Ceiling** | Same as RXSS-01, but may affect authenticated pages (login error) |
| **Remediation** | Apply same encoding to error templates as main templates; audit all error paths |
| **Local Sources** | KB-03, KB-35, XSS-99 |
| **Confidence** | HIGH — common pattern, error templates frequently overlooked |

### Card RXSS-03: OAuth Callback/Redirect Page

| Field | Value |
|---|---|
| **Vector ID** | RXSS-03 |
| **Endpoint Pattern** | `/oauth/callback?redirect_uri=[VALUE]`, `/auth/callback?error=[VALUE]&error_description=[VALUE]` |
| **Input Source** | Query parameters: `redirect_uri`, `state`, `error`, `error_description`, `code` |
| **HTTP Method** | GET |
| **Reflection Location** | Error display page, consent page, redirect confirmation page |
| **Server Transformations** | URL decode → OAuth parameter validation → error template rendering |
| **Final Browser Context** | HTML data (error message) or URL attribute (redirect link) |
| **Required Control** | Characters `<`, `>` for HTML injection; full URL control for `javascript:` |
| **Missing Protection** | OAuth error parameters reflected without encoding; redirect_uri reflected in HTML |
| **Prerequisites** | Application uses OAuth; callback endpoint accessible |
| **Victim Interaction** | Click crafted authorization URL |
| **Harmless Lab Assertion** | OAuth error page renders `[HARMLESS_EXECUTION_MARKER]` |
| **Negative Control** | Error parameters properly encoded → displayed as text |
| **False Positives** | Redirect happens without rendering a page; parameters only in server logs; OAuth state is opaque token not reflected in HTML |
| **Impact Ceiling** | Token theft via same-origin cookie access; account takeover if combined with CSRF |
| **Remediation** | Validate `redirect_uri` against registered whitelist; encode all OAuth error parameters |
| **Local Sources** | XSS-14, KB-03 |
| **Confidence** | HIGH — documented in 6 HackerOne reports with bounties ($1,750–$5,000) |

### Card RXSS-04: API Documentation (Swagger UI)

| Field | Value |
|---|---|
| **Vector ID** | RXSS-04 |
| **Endpoint Pattern** | `/swagger-ui/index.html?url=[VALUE]`, `/api-docs?configUrl=[VALUE]` |
| **Input Source** | Query parameters: `url`, `configUrl` |
| **HTTP Method** | GET |
| **Reflection Location** | Swagger UI renders specification from user-supplied URL |
| **Final Browser Context** | DOM XSS via innerHTML in Swagger UI rendering |
| **Framework/Template** | Swagger UI < 4.1.3 |
| **Required Control** | Control of the `url` or `configUrl` parameter |
| **Missing Protection** | No URL validation or origin restriction on specification source |
| **Prerequisites** | Swagger UI deployed at accessible path |
| **Victim Interaction** | Click crafted Swagger UI link |
| **Harmless Lab Assertion** | Swagger UI renders attacker-controlled content from local specification file |
| **Negative Control** | Updated Swagger UI (≥ 4.1.3) rejects external URLs |
| **False Positives** | Swagger UI behind authentication; Swagger UI with restricted `url` configuration |
| **Remediation** | Update Swagger UI ≥ 4.1.3; restrict `url`/`configUrl` to trusted origins |
| **Local Sources** | XSS-21 |
| **Confidence** | HIGH — documented CVEs and multiple HackerOne reports (Adobe, IBM, DoD) |

### Card RXSS-05: Inline JSON Configuration

| Field | Value |
|---|---|
| **Vector ID** | RXSS-05 |
| **Endpoint Pattern** | Any page with inline `<script>var config = {...[VALUE]...}</script>` |
| **Input Source** | Query parameter, path segment, or form value reflected into inline JSON |
| **HTTP Method** | GET or POST |
| **Reflection Location** | Inline `<script>` tag containing JSON configuration |
| **Final Browser Context** | JavaScript string within inline script block |
| **Required Control** | `</script>` to terminate script block, OR `"` to break JSON string |
| **Missing Protection** | Missing `</script>` prevention in JSON values; using HTML encoding instead of JS encoding inside `<script>` |
| **Harmless Lab Assertion** | Console marker fires from injected content after script termination |
| **Negative Control** | JSON value properly encoded with `<` for `<` → script block intact |
| **False Positives** | JSON in `type="application/json"` script tag (not executed); JSON served as `application/json` response |
| **Remediation** | JSON-encode values AND prevent `</script>` (encode `<` as `<`); use `type="application/json"` and parse with `JSON.parse()` |
| **Local Sources** | KB-04, KB-24 |
| **Confidence** | HIGH — well-documented, common in SSR applications |

### Card RXSS-06: CRLF Injection to Reflected XSS

| Field | Value |
|---|---|
| **Vector ID** | RXSS-06 |
| **Endpoint Pattern** | `/redirect?url=[VALUE]`, any endpoint reflecting input into response headers |
| **Input Source** | Query parameter or header value containing `%0D%0A` |
| **HTTP Method** | GET |
| **Reflection Location** | Response headers, then response body after double CRLF |
| **Final Browser Context** | HTML data (attacker-controlled response body) |
| **Required Control** | CRLF characters (`%0D%0A`) must survive to response header |
| **Missing Protection** | No CRLF filtering in header value construction |
| **Prerequisites** | Server/framework does not reject CRLF in header values |
| **Harmless Lab Assertion** | Response contains attacker-controlled HTML body |
| **Negative Control** | Modern framework rejects CRLF → returns error or strips characters |
| **False Positives** | Framework strips CRLF; response is not rendered as HTML; redirect happens before body is rendered |
| **Remediation** | Validate and strip CRLF from all values reflected in headers; use framework header APIs that reject CRLF |
| **Local Sources** | XSS-16 |
| **Confidence** | MEDIUM — rare in modern frameworks but HIGH impact when present |

### Card RXSS-07: Header Reflection in Error Pages

| Field | Value |
|---|---|
| **Vector ID** | RXSS-07 |
| **Endpoint Pattern** | Error pages that display `Host`, `Referer`, `User-Agent`, or custom headers |
| **Input Source** | HTTP request headers |
| **HTTP Method** | Any |
| **Reflection Location** | Error page HTML body, debug output, admin panels |
| **Final Browser Context** | HTML data within error page template |
| **Required Control** | Attacker must control the header value reaching the victim's request |
| **Missing Protection** | Header values reflected without HTML encoding in error templates |
| **Prerequisites** | CRLF injection to inject headers, or victim sends request through attacker-controlled proxy, or Referer from attacker page |
| **Harmless Lab Assertion** | Error page renders injected header value as HTML |
| **Negative Control** | Header values properly encoded in error template |
| **False Positives** | Headers only in server logs (not rendered); error page serves `Content-Type: application/json` |
| **Remediation** | Encode all header values in error templates; minimize header reflection |
| **Local Sources** | KB-24, KB-03 |
| **Confidence** | MEDIUM — delivery often impractical, but error templates frequently overlooked |

### Card RXSS-08: Hydration State Reflection

| Field | Value |
|---|---|
| **Vector ID** | RXSS-08 |
| **Endpoint Pattern** | Next.js, Nuxt, SvelteKit, or other SSR framework pages |
| **Input Source** | Query parameter, path segment, or form value reflected into hydration data |
| **HTTP Method** | GET |
| **Reflection Location** | `__NEXT_DATA__`, `__NUXT__`, or framework-specific inline JSON |
| **Final Browser Context** | JSON within `<script>` tag (may or may not be executable depending on `type` attribute) |
| **Required Control** | Characters that can break JSON structure or terminate `<script>` |
| **Missing Protection** | Insufficient JSON encoding of user input in serialized state; `</script>` not prevented |
| **Harmless Lab Assertion** | Script block terminated or JSON structure broken, resulting in execution |
| **Negative Control** | Properly serialized with `<` encoding → JSON intact |
| **False Positives** | `type="application/json"` (Next.js) — not directly executed; value only in JSON but never reaches DOM sink |
| **Remediation** | Use framework's built-in serialization; avoid custom serialization |
| **Local Sources** | KB-44, KB-04 |
| **Confidence** | MEDIUM — framework-dependent; Next.js generally safe; Nuxt 2 higher risk |

---

*Next chunk: chunk-14-false-positive-evidence-severity.md*
