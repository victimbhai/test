# 62 - Framework-Specific API XSS Vectors

## Overview

Modern API frameworks introduce XSS through:
- Django REST Framework's Browsable API (CVE-2024-21520)
- Laravel debug-mode error pages reflecting request/route parameters (CVE-2024-13918, CVE-2024-13919)
- NestJS Fastify adapter middleware bypass via URL encoding (CVE-2025-69211)
- Express.js res.send() defaulting to text/html for string arguments
- FastAPI/Starlette debug traceback pages
- Spring Boot Whitelabel error pages and Thymeleaf th:utext

## Django REST Framework (CVE-2024-21520)

**CVE-2024-21520:** XSS in the `break_long_headers` template filter used by the Browsable API. Affected versions below 3.15.2. CVSS 6.1 (Medium). Fixed in DRF 3.15.2.

**CVE-2018-25045:** Versions before 3.9.1 had XSS because the default DRF Browsable API view templates disabled autoescaping.

```python
# VULNERABLE: Custom exception handler rendering errors as HTML
from rest_framework.views import exception_handler

def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)
    if response is not None:
        html = "<ul>"
        for field, errors in response.data.items():
            # If field names contain user input (dynamic fields), XSS is possible
            html += f"<li>{field}: {', '.join(str(e) for e in errors)}</li>"
        html += "</ul>"
        response.content_type = 'text/html'
        response.data = html  # Unescaped field names and error messages
    return response

# SAFE: Keep JSON responses, disable Browsable API in production
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': ['rest_framework.renderers.JSONRenderer'],
}
```

The Browsable API is the primary XSS surface in DRF. Disabling it in production eliminates most risk.

## Laravel Debug Mode XSS (CVE-2024-13918, CVE-2024-13919)

### Request Parameter Reflection (CVE-2024-13918)

**CVE-2024-13918:** Reflected XSS via request parameters in the debug-mode error page. Affected versions 11.9.0 through 11.35.1. CVSS 8.0 (High). The values in URL parameters and the request body are embedded in the error page without proper encoding, using Blade `{!! !!}` tags. Fixed in Laravel 11.36.0.

### Route Parameter Reflection (CVE-2024-13919)

**CVE-2024-13919:** Reflected XSS via route parameters in the debug-mode error page. Same affected versions and fix.

```php
// Proof of Concept:
// 1. Set APP_DEBUG=true in .env
// 2. Create a route that throws an error:
Route::get('/poc-url', function () {
    return 0/0;  // DivisionByZeroError
});
// 3. Visit: http://localhost:8000/poc-url?payload=<script>alert(1)</script>
// Result: Division by zero error page renders the unencoded payload

// Root cause: Blade {!! !!} syntax explicitly disables HTML escaping
// Any use of {!! !!} with user-controlled data is an XSS vector
```

Debug mode in production is a precondition for these CVEs. The `{!! !!}` Blade syntax is the root cause.

## NestJS Fastify Middleware Bypass (CVE-2025-69211)

**CVE-2025-69211:** Middleware registered on string-path routes in `@nestjs/platform-fastify` can be skipped by percent-encoding the path. CWE-367 (TOCTOU). CVSS 6.9 (Medium). Affected versions before 11.1.11.

```typescript
// VULNERABLE: Sanitization middleware bypassed via URL encoding
@Module({})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(SanitizationMiddleware)  // Strips <script> tags from input
      .forRoutes('api/comments');     // Only matches exact string
  }
}
// Attacker sends POST /%61pi/comments with XSS payload in body
// Middleware is skipped because /%61pi != api
// Controller receives unsanitized input

// The Express adapter is NOT affected because Express normalizes
// URL encoding before middleware matching

// SAFE: Use route objects or upgrade to 11.1.11+
consumer
  .apply(SanitizationMiddleware)
  .forRoutes({ path: 'api/comments', method: RequestMethod.ALL });
```

The Fastify adapter's URL handling is a TOCTOU issue: middleware sees the raw (encoded) path but the router sees the decoded path. Any middleware-based security control is bypassable on affected versions.

## Express.js res.send() XSS

Express sends a string passed to `res.send()` as `text/html` unless a different response type has been set. This makes any reflected user input an XSS vector.

**CVE-2024-43796:** Passing untrusted user input to `response.redirect()` may execute untrusted code even after sanitizing it. Fixed in Express 4.20.0.

```javascript
// VULNERABLE: res.send() with string defaults to text/html
app.get('/search', (req, res) => {
  const query = req.query.q;
  res.send(`No results found for: ${query}`);
  // Payload: /search?q=<script>alert(document.cookie)</script>
});

// VULNERABLE: error handler reflecting input
app.use((err, req, res, next) => {
  res.status(500).send(`Error processing ${req.originalUrl}: ${err.message}`);
  // Reflected XSS via URL path
});

// SAFE: explicit content type
app.get('/search', (req, res) => {
  res.type('text/plain').send(`No results found for: ${req.query.q}`);
});
```

### Prototype Pollution Gadget

Prototype pollution can force Express to serve an HTML content type when `res.send(obj)` is called with a body parser configured for `application/json`. The pollution sets `content-type` on `Object.prototype`.

### express-validator Escape Bypass

An older issue (express-validator #651) shows that changing a parameter to an array bypasses the `escape()` function.

## FastAPI/Starlette XSS Vectors

No XSS-specific CVEs were found for FastAPI or Starlette in 2024-2026. The most significant vulnerability is an authentication bypass:

**CVE-2026-48710 ("BadHost"):** Authentication bypass in Starlette versions 0.8.3 through 1.0.0. A single malformed Host header character bypasses path-based middleware, potentially disabling XSS protections set in middleware. Patched in Starlette 1.0.1.

Starlette's debug error pages render tracebacks with request details. While no CVE exists, the pattern mirrors the Laravel debug-mode XSS and should be treated as a risk when debug mode is enabled in production.

```python
# POTENTIAL RISK: Starlette debug mode in production
# Debug traceback pages may render request parameters without encoding
# Similar pattern to Laravel CVE-2024-13918

# SAFE: Disable debug in production
app = Starlette(debug=False)
```

## Spring Boot Error Page XSS

The most critical Spring Boot Whitelabel error page vulnerability is an older SpEL injection (RCE) in versions before 1.2.8/1.3.1. Modern Spring Boot (3.x) HTML-encodes error attributes by default.

```java
// VULNERABLE: Custom error page with unescaped output (Thymeleaf)
// error.html: <p th:utext="${message}">Error</p>
// If 'message' contains user input from query params, XSS results

// SAFE: Use th:text (auto-escaped)
// error.html: <p th:text="${message}">Error</p>

// VULNERABLE: Actuator custom UI rendering
@GetMapping("/admin/env")
public String showEnv(Model model) {
    Map<String, Object> env = actuatorEndpoint.environment(null)
        .getPropertySources();
    model.addAttribute("env", env);
    // If env values contain HTML and template uses th:utext
    return "env-view";
}
```

Actuator endpoints are JSON-only by default but become XSS vectors when wrapped in custom HTML UIs without encoding.

## NestJS WebSocket Gateway Security Gap

NestJS Guards applied to WebSocket gateways allow any user to establish a connection before the guard runs. Authentication must happen during the handshake via Socket.IO middleware, not NestJS Guards.

Starting with NestJS v12.1, `app.useSecurityHeaders()` sets CSP and other security headers. Prior versions require manual helmet integration.

## Testing Methodology

1. **Identify the API framework** from error pages, headers, and response formats
2. **Check debug mode** -- is APP_DEBUG=true, DEBUG=True, or similar enabled in production?
3. **Test error page reflection** -- do 404/500 pages reflect the request path or parameters?
4. **Check Browsable API** in Django REST Framework -- is it enabled in production?
5. **Test Express res.send()** with HTML payloads -- is Content-Type explicitly set?
6. **Check NestJS adapter** -- Fastify or Express? Test URL encoding bypass on Fastify
7. **Test middleware ordering** -- can security headers be bypassed by route-specific handlers?
8. **Check Thymeleaf templates** for th:utext usage with user-controlled data

## Bug Bounty Tips

1. Laravel debug mode in production + XSS = CVSS 8.0 (High)
2. DRF Browsable API in production is always worth checking -- two CVEs demonstrate the risk
3. NestJS Fastify adapter URL encoding bypass is version-specific -- check for < 11.1.11
4. Express res.send() with string arguments is a frequent reflected XSS source
5. The Starlette BadHost bypass (CVE-2026-48710) can disable CSP middleware
6. Spring Boot Thymeleaf th:utext is the modern equivalent of PHP's echo without htmlspecialchars
7. Test both the Express and Fastify adapter codepaths in NestJS -- they handle security differently
