# 30 - Bug Bounty XSS Case Studies

## Overview

Cross-site scripting remains the single most discovered vulnerability type in bug bounty programs, accounting for over 66% of categorized vulnerabilities on platforms like Bugcrowd. Despite a 10% decline in XSS reports on HackerOne since 2023, XSS continues to be the top reported vulnerability class across the industry, with payouts ranging from $100 to $62,500+ depending on impact and program.

---

## 1. High-Value HackerOne XSS Reports (2020-2025)

### Top Disclosed Reports by Impact and Upvotes

| Report | Target | Type | Bounty | Upvotes |
|--------|--------|------|--------|---------|
| Stored XSS via deleted S3-bucket (old page_widget) | HackerOne | Stored | $0 (self) | 120 |
| XSS on any Shopify shop via HTML5 structured clone in postMessage | Shopify | DOM | $3,000 | 119 |
| Persistent XSS via unvalidated Open Graph embed | LinkedIn | Stored | $0 | 119 |
| Stored XSS in Snapmatic + R*Editor comments | Rockstar Games | Stored | $0 | 118 |
| Stored XSS on any page in most Uber domains | Uber | Stored | $6,000 | 107 |
| Stored XSS at 8x8.com | 8x8 | Stored | $1,337 | 105 |
| Stored XSS via Mermaid Prototype Pollution | GitLab | Stored | $3,000 | 56 |
| Stored XSS in ICQ account name field | Mail.ru | Stored | $1,000 | 57 |
| CVE-2024-41937 Apache Airflow Stored XSS | Apache | Stored | $497 | 70 |
| Reflected XSS on Chaturbate | Chaturbate | Reflected | $800 | 69 |

Source: https://github.com/reddelexc/hackerone-reports/blob/master/tops_by_bug_type/TOPXSS.md

### Notable Payload Techniques from Top Reports

**Shopify postMessage XSS:**
Abused the HTML5 structured clone algorithm in a postMessage listener. The attacker crafted a message from an attacker-controlled window to inject HTML into the Shopify storefront DOM, bypassing origin checks.

```javascript
// Simplified attack concept - postMessage origin bypass
// The vulnerable listener accepted messages without verifying the origin,
// allowing attacker-controlled HTML to be rendered in the storefront DOM
window.postMessage({html: '<img src=x onerror=alert(document.domain)>'}, '*');
```

**GitLab Mermaid Prototype Pollution to Stored XSS:**
Exploited prototype pollution in the Mermaid charting library to achieve stored XSS within GitLab issues and comments. The attacker polluted `Object.prototype` to inject attributes that bypassed sanitization in the Mermaid rendering pipeline.

**Uber Multi-Domain Stored XSS:**
Leveraged a shared component across Uber's domains where user-controlled data was rendered without proper sanitization, allowing a single stored payload to execute across multiple Uber properties.

---

## 2. Google VRP XSS Reports

Google's Vulnerability Reward Program paid $12 million in 2022 and $10 million in 2023 across all vulnerability types. Chrome VRP alone awarded $2.1 million for 359 unique Chrome vulnerabilities in 2023.

### Notable Google XSS Findings

| Finding | Date | Bounty | Details |
|---------|------|--------|---------|
| XSS via postMessage in Google Cloud Theia Notebooks | Jan 2024 | $3,133.70 | postMessage handler with insufficient origin validation |
| Google Cloud Shell XSS | Dec 2023 | $5,000 | XSS in Cloud Shell terminal interface |
| XS-Search on Google Photos | Sep 2024 | $4,837 | Cross-origin information leak via timing side-channel |
| Stored XSS on Google Books | 2023 | Undisclosed | Injection via book metadata rendering |

Source: https://github.com/xdavidhu/awesome-google-vrp-writeups

### Google VRP XSS Methodology Insights

- Google Cloud products (Cloud Shell, Theia, Cloud Console) are high-value targets due to access to infrastructure credentials
- postMessage-based attacks are particularly effective against Google's web applications
- XS-Search/XS-Leak variants qualify as XSS-adjacent findings in Google's program
- Google pays a premium for XSS that can access Google Workspace data or cloud credentials

---

## 3. Facebook/Meta Bug Bounty XSS

Meta's bug bounty program offers rewards from $500 to $80,000+ depending on severity and impact. XSS findings that lead to account takeover command the highest payouts.

### Notable Meta XSS Findings

| Finding | Researcher | Bounty | Year |
|---------|-----------|--------|------|
| Self-XSS in Payments Flow leading to Account Takeover | Youssef Sammouda | $62,500 | 2024 |
| Account Takeover via XSS + auth token theft (Gmail signup) | Youssef Sammouda | $44,625 | 2022 |
| XSS on forums.oculusvr.com | Samm0uda | $30,000 | 2022 |
| XSS in "Login with Facebook" button (postMessage) | Undisclosed | $20,000 | 2020 |
| Stored XSS at Meta Careers | Almuntadhar | Undisclosed | 2025 |

Source: https://portswigger.net/daily-swig/xss-vulnerability-in-login-with-facebook-button-earns-20-000-bug-bounty

### Key Takeaways from Meta Reports

- **Self-XSS escalation**: Meta pays for self-XSS when chained with CSRF or social engineering to demonstrate real account takeover risk
- **OAuth/Login flows**: The "Login with Facebook" XSS exploited a flawed postMessage API implementation in the social login widget
- **Account takeover chains**: The $44,625 report chained XSS with authentication token theft from a sandbox domain to achieve full account takeover for users who signed up via Gmail

---

## 4. Apple Security Bounty XSS

Apple's Security Bounty focuses heavily on WebKit vulnerabilities that affect Safari across all Apple platforms (iOS, macOS, iPadOS, watchOS, tvOS, visionOS).

### Notable WebKit/Safari XSS-Related Findings

- **CVE-2024-44308**: JavaScriptCore XSS vulnerability in Safari/WebKit actively exploited in the wild. Apple confirmed targeted attacks using this flaw.
- **CVE-2025-43529 and CVE-2025-14174**: Two WebKit zero-days exploited in targeted iPhone spyware attacks, confirmed by Apple as exploited in real-world attacks.
- **CVE-2023-43000**: Use-after-free in WebKit affecting macOS, iOS, iPadOS, and Safari.

Apple's bounty for Safari web content XSS-type vulnerabilities ranges from $5,000 to $50,000+, with UXSS (Universal XSS) vulnerabilities commanding higher payouts due to cross-origin impact.

Source: https://www.jit.io/resources/app-security/what-is-cve-2024-44308-xss-and-how-to-protect-from-it

---

## 5. Microsoft MSRC XSS

Microsoft's Bug Bounty Program awarded $13.8 million in total in 2023, collaborating with 345+ researchers from 45+ countries.

### Notable Microsoft XSS Findings

| Finding | Date | Details |
|---------|------|---------|
| Azure Bastion XSS | April 2023 | Reported by Orca Security, mitigated May 2023 |
| Azure Container Registry XSS | May 2023 | Reported by Orca Security, mitigated May 2023 |
| Microsoft Teams Preview XSS | Jan 2023 | Part of Teams Bug Bounty research invitation |

Source: https://msrc.microsoft.com/blog/2023/06/microsoft-mitigates-set-of-cross-site-scripting-xss-vulnerabilities-in-azure-bastion-and-azure-container-registry/

### Microsoft XSS Bounty Ranges

- M365 services (Outlook, Teams, SharePoint Online): $500 - $26,000 for XSS
- Azure services: $500 - $60,000 depending on impact to cloud infrastructure
- Dynamics 365: $500 - $20,000

---

## 6. Bugcrowd XSS Findings

XSS accounts for over 66% of all vulnerabilities disclosed through Bugcrowd. Reflected XSS is most frequently submitted, but stored XSS typically receives higher payouts.

### Notable Bugcrowd Disclosures

- **Stored XSS in Jira Service Desk "Reports"** (Sep 2023): Non-authenticated users could execute stored XSS via the Widget Chat question field. Rated P3 priority.
- **Stored XSS in Blog Title Field** on globe.gov (Mar 2024): Rated P2 priority.
- **Reflected XSS in Opera Login Page**: Reflected JavaScript injection in the login endpoint.

Source: https://bugcrowd.com/disclosures

---

## 7. Methodology from Top Hunters

### Recon-to-XSS Workflow

**Phase 1: Asset Discovery and Enumeration**
```bash
# Subdomain enumeration
subfinder -d target.com -all -o subdomains.txt
amass enum -d target.com -o amass_subs.txt

# Historical URL discovery from passive sources
cat subdomains.txt | gau --threads 10 --o gau_urls.txt
cat subdomains.txt | waybackurls > wayback_urls.txt

# Combine and deduplicate
cat gau_urls.txt wayback_urls.txt | sort -u > all_urls.txt
```

**Phase 2: Parameter Discovery**
```bash
# Extract parameters from historical URLs
cat all_urls.txt | grep "=" | uro | tee params.txt

# Parameter bruteforcing with Arjun
arjun -u https://target.com/endpoint -m GET POST

# JavaScript file analysis for hidden parameters
cat all_urls.txt | grep "\.js$" | httpx -mc 200 | tee js_files.txt
# Use LinkFinder to extract endpoints from JS files
cat js_files.txt | xargs -I{} python3 LinkFinder.py -i {} -o cli
```

**Phase 3: Hidden Endpoint Discovery**
```bash
# Force browsing / directory fuzzing
ffuf -u https://target.com/FUZZ -w /path/to/wordlist.txt -mc 200,301,302,403

# API endpoint enumeration
ffuf -u https://target.com/api/FUZZ -w api-wordlist.txt -mc 200

# JavaScript analysis for undocumented endpoints
python3 LinkFinder.py -i https://target.com/main.js -o cli
```

**Phase 4: XSS Testing**
```bash
# Reflected XSS scanning with parameters
cat params.txt | kxss | tee potential_xss.txt

# Automated XSS detection
dalfox file params.txt --skip-bav --output dalfox_results.txt

# Manual verification of findings
# Test each reflected parameter with context-specific payloads
```

### Framework-Specific Hunting

**React Applications:**
- Search for `dangerouslySetInnerHTML` usage in JavaScript bundles -- this is the primary vector for React XSS
- Look for `href={userInput}` with `javascript:` protocol injection
- Check for server-side rendering (SSR) injection points
- Inspect React Server Components for deserialization issues (CVE-2025-55182)

**Angular Applications:**
- Test for template injection: `{{constructor.constructor('alert(1)')()}}`
- Look for `bypassSecurityTrustHtml()` calls in source code
- Check `[innerHTML]` bindings with user-controlled data
- Test Angular expression sandboxes for bypasses

**Vue Applications:**
- Look for `v-html` directive with user-controlled data
- Test server-side rendering injection points
- Check for template compilation with user input
- CVE-2024-6783: Vue 2 template compiler XSS vulnerability

---

## 8. Payoff Analysis

### Bounty Ranges by Program Tier

| Program Tier | Reflected XSS | Stored XSS | XSS to ATO |
|-------------|---------------|------------|------------|
| Top-tier (Google, Meta, Apple) | $1,000-$10,000 | $3,000-$30,000 | $20,000-$80,000 |
| Enterprise (Shopify, Uber, GitLab) | $500-$3,000 | $1,000-$10,000 | $5,000-$25,000 |
| Mid-tier programs | $100-$1,000 | $500-$3,000 | $2,000-$10,000 |
| Small programs | $50-$500 | $200-$1,500 | $500-$5,000 |

### Factors That Increase XSS Payouts

1. **Account takeover demonstrated**: XSS that steals session tokens or OAuth codes for full account takeover
2. **Wormable potential**: Self-propagating XSS (stored XSS that can replicate itself)
3. **Authentication bypass**: XSS that bypasses 2FA or CSRF protections
4. **Sensitive data access**: XSS that exfiltrates PII, financial data, or API keys
5. **Multi-domain impact**: Single payload affecting multiple subdomains or services
6. **Zero-click execution**: Stored XSS requiring no user interaction beyond visiting a page
7. **Admin panel impact**: XSS that executes in administrative interfaces

### Report Writing for Maximum Impact

**Structure for high-impact XSS reports:**
1. **Title**: Clear, specific (e.g., "Stored XSS in Comment Field Leading to Account Takeover on app.target.com")
2. **Severity justification**: CVSS score with vector string
3. **Steps to reproduce**: Exact, numbered steps with screenshots
4. **Proof of concept**: Working payload with video/GIF demonstration
5. **Impact statement**: What an attacker could actually do (session hijacking, data theft, worm propagation)
6. **Affected users**: Estimate of impacted user base
7. **Remediation guidance**: Specific fix recommendations

**Impact demonstration best practices:**
- Always demonstrate cookie theft or session hijacking rather than just `alert(1)`
- Show the full attack chain: XSS -> token theft -> account takeover
- If stored, calculate the number of users who would view the payload
- For admin panel XSS, demonstrate privilege escalation potential
- Record a video walkthrough of the exploitation

Source: https://corneacristian.medium.com/top-25-xss-bug-bounty-reports-b3c90e2288c8
Source: https://www.hackerone.com/resources/bug-bounty-program/8th-hacker-powered-security-report
Source: https://www.eweek.com/security/hackerone-reports-bug-bounties-rise-as-xss-remains-the-top-flaw/
Source: https://security.googleblog.com/2025/03/vulnerability-reward-program-2024-in.html
Source: https://github.com/jaiswalakshansh/Facebook-BugBounty-Writeups
