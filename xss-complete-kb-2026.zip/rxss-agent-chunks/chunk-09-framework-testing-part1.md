# Agent Chunk 09: Framework-Specific Testing Part 1 (React, Vue, Angular, Svelte, Astro)

**Agent Task:** Identify framework-specific reflected XSS risks in React/Next.js, Vue/Nuxt, Angular, Svelte/SvelteKit, and Astro. For each framework, know the default auto-escaping mechanism and the dangerous escape hatches that bypass it. Check for SSR hydration injection and framework-specific CVEs.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 19. Framework-Specific Research (Part 1)

### 19.1 React and Next.js

**Default safety**: React's JSX compiles expressions to `React.createElement()` calls that use `textContent` for string values. This provides automatic HTML escaping for all interpolated values.

**Dangerous escape hatches**:
- `dangerouslySetInnerHTML={{__html: value}}` — bypasses React's escaping entirely
- `href` with `javascript:` protocol — React 19 blocks this in JSX, but earlier versions allow it
- `ref` manipulation — using refs to directly manipulate DOM elements bypasses React's virtual DOM protections
- Server-side rendering with string concatenation instead of JSX

**Next.js SSR-specific risks**:
- `__NEXT_DATA__` hydration data: JSON-serialized with Unicode escaping for `<`, `>`, `&`. Generally safe, but client-side code that reads and inserts these values via `innerHTML` creates hybrid XSS.
- `getServerSideProps` / Server Components: Values returned from server functions are serialized into the page. If these values contain user input and are used in a `dangerouslySetInnerHTML` context, reflected XSS occurs.
- CSP2XSS: A vulnerability pattern in Next.js App Router where CSP nonce handling could be exploited (AiSafe research).

**CVE reference**: The corpus (KB-31) mentions React CVE-2025-55182 (CVSS 10.0), but this CVE could not be independently verified through NVD during this research session. Evidence quality: UNVERIFIED-LOCAL — treat with caution.

**Source**: KB-44 (unverified), Sonarsource framework sanitization blog, VibeAppScanner React XSS analysis, OWASP XSS Prevention Cheat Sheet, AiSafe CSP2XSS research.

### 19.2 Vue and Nuxt

**Default safety**: Vue's template double-curly-brace syntax `{{ value }}` automatically HTML-encodes output. This is the primary defense against XSS in Vue applications.

**Dangerous escape hatches**:
- `v-html` directive — renders raw HTML without escaping
- `:href` / `:src` with user-controlled URLs — allows `javascript:` protocol injection
- Server-side rendering with manual string interpolation
- `v-bind` with user-controlled attribute names — can inject event handlers

**Nuxt-specific risks**:
- Nuxt 2: `window.__NUXT__` is executable JavaScript (higher risk than Next.js's `application/json` approach)
- Nuxt 3: Uses safer serialization, but custom server middleware may still reflect unsafely
- CVE-2026-46342: Nuxt Nitro Server XSS vulnerability
- SNYK-JS-NUXT-7640972: XSS vulnerability in Nuxt package

**Source**: KB-44 (unverified), Snyk vulnerability database, WP-Firewall CVE report.

### 19.3 Angular

**Default safety**: Angular treats all values as untrusted by default. Template interpolation `{{ value }}` is HTML-encoded. Angular's DomSanitizer automatically sanitizes values bound to potentially dangerous properties.

**Dangerous escape hatches**:
- `bypassSecurityTrustHtml()` — marks a string as safe HTML
- `bypassSecurityTrustScript()` — marks a string as safe script
- `bypassSecurityTrustUrl()` — marks a string as safe URL
- `bypassSecurityTrustResourceUrl()` — marks a string as safe resource URL
- `bypassSecurityTrustStyle()` — marks a string as safe style
- Direct DOM manipulation via `ElementRef.nativeElement`
- Using `innerHTML` binding with unsanitized values

**Angular's DomSanitizer** uses an allowlist approach. It permits safe HTML elements and attributes while stripping potentially dangerous ones. However, it has known limitations:
- Does not sanitize CSS expressions (not relevant for modern browsers)
- May not catch all namespace confusion attacks
- Is bypassed entirely by `bypassSecurityTrust*` functions

**Source**: KB-44 (unverified), KB-16, Angular security documentation, Sonarsource framework research.

### 19.4 Svelte and SvelteKit

**Default safety**: Svelte's template syntax `{value}` automatically HTML-encodes output, similar to React and Vue.

**Dangerous escape hatches**:
- `{@html value}` — renders raw HTML without escaping
- `{@const}` with dynamic values in certain contexts
- SvelteKit's `load` function returning user input that reaches `{@html}`

**SvelteKit SSR risks**:
- Server-side rendering serializes data into the page
- If `load` function output contains user input and is used with `{@html}`, reflected XSS occurs
- SvelteKit's error pages may reflect request parameters

**Source**: KB-44 (unverified), Svelte security documentation.

### 19.5 Astro

**Default safety**: Astro auto-escapes expressions in `.astro` templates. Content is server-rendered by default with minimal client-side JavaScript.

**Dangerous escape hatches**:
- `set:html` directive — renders raw HTML without escaping
- `<Fragment set:html={value} />` — same as `set:html`
- Server islands feature — CVE-2025-64764 (GHSA-wrwg-2hg8-v723)

**CVE-2025-64764** (verified via GitHub Security Advisory):
- **Affected**: Astro ≤ 5.15.6
- **Fixed**: Astro 5.15.8
- **CVSS**: 7.1 (High)
- **Mechanism**: Server islands at `/_server-islands/[name]` accept parameters `e` (export), `p` (props), and `s` (slot content). When `e=file`, the server returns the island file path, which enters a code path using `markHTMLString` (skipping escaping). The `s` (slot) value is injected as child content without escaping.
- **Impact**: An attacker can inject HTML/script into any Astro application using server islands, even with empty island components.
- **Evidence quality**: PRIMARY-EXTERNAL (verified from GitHub advisory GHSA-wrwg-2hg8-v723).

**Source**: GitHub advisory GHSA-wrwg-2hg8-v723, VibeAppScanner Astro XSS analysis, BitNinja Astro security analysis.

---

*Next chunk: chunk-10-framework-testing-part2.md*
