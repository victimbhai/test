# Agent Chunk 03: Request-to-Browser Pipeline & Input Sources

**Agent Task:** Map the full data flow from attacker input to browser execution. Use the pipeline model to trace every reflected value through all transformation stages. Use the input-source inventory as a checklist when scanning a target.

---

## 6. Reflected-XSS Request-to-Browser Model

### 6.1 The Complete Pipeline

```
ATTACKER-CONTROLLED INPUT
  Query param - Path segment - Form body - JSON property - Header
  Cookie - Error-inducing value - OAuth parameter - API config
          |
          v
STAGE 1: HTTP TRANSPORT & DECODING
  URL decoding - Form decoding - Multipart parsing - Charset
  JSON/XML parsing - Content-type interpretation
          |
          v
STAGE 2: SERVER-SIDE PROCESSING
  Framework parameter binding - Validation/canonicalization
  Unicode normalization - Business logic - Database interaction
  Middleware processing - Route-specific handling
          |
          v
STAGE 3: RESPONSE CONSTRUCTION
  Template engine - Response serialization - Output encoding
  Sanitization (if any) - Content-type header - CSP headers
  Inline JSON/hydration data - Error template rendering
          |
          v
STAGE 4: HTTP RESPONSE TRANSMISSION
  Response headers - Content-Type - X-Content-Type-Options
  CSP - Response body with reflected value
          |
          v
STAGE 5: BROWSER PARSING
  MIME type determination - Character encoding detection
  HTML5 tokenization - DOM tree construction - Script execution
  CSS parsing - URL resolution - JavaScript evaluation
  Insertion mode - Namespace (HTML/SVG/MathML) - Foster parenting
          |
          v
STAGE 6: EXECUTION DETERMINATION
  Is the reflected value in an executable context?
  +-- Text node with HTML-entity encoding -> SAFE (not XSS)
  +-- Script element content -> EXECUTABLE
  +-- Event-handler attribute -> EXECUTABLE
  +-- javascript: URL -> EXECUTABLE
  +-- Unquoted attribute allowing new attribute injection -> DEPENDS
  +-- CSP blocks inline script -> BLOCKED (still a flaw)
```

### 6.2 Critical Insight: Context Determines Everything

The same reflected string has radically different security implications depending on where it lands:

| Response Location | Example | Risk Level | Required Encoding |
|---|---|---|---|
| HTML text content | `<p>[MARKER]</p>` | LOW if encoded | HTML entity encoding |
| Unquoted HTML attribute | `<div class=[MARKER]>` | HIGH | HTML attribute encoding + quoting |
| Quoted HTML attribute | `<div class="[MARKER]">` | MEDIUM | HTML attribute encoding |
| Event-handler attribute | `<div onclick="[MARKER]">` | CRITICAL | JavaScript encoding |
| JavaScript string | `var x = '[MARKER]';` | CRITICAL | JavaScript string encoding |
| JavaScript template literal | `` var x = `${[MARKER]}`; `` | CRITICAL | JavaScript encoding |
| URL href/src | `<a href="[MARKER]">` | HIGH | URL validation + encoding |
| CSS value | `<div style="color:[MARKER]">` | MEDIUM | CSS encoding + validation |
| HTML comment | `<!-- [MARKER] -->` | LOW (usually) | Generally safe, but `-->` can terminate |
| RCDATA (`<textarea>`, `<title>`) | `<title>[MARKER]</title>` | MEDIUM | HTML entity encoding; `</title>` terminates |
| SVG/MathML namespace | `<svg><desc>[MARKER]</desc></svg>` | HIGH | Namespace-aware encoding |
| Inline JSON | `<script>var data = {"q":"[MARKER]"};</script>` | CRITICAL | JSON encoding + `</script>` prevention |

---

## 7. Input-Source Inventory

### 7.1 URL-Based Inputs

| Source | Example | Expected Safe Behavior |
|---|---|---|
| Query parameters | `?q=[VALUE]&page=1` | URL-decode -> validate -> HTML-entity-encode in output |
| Path segments | `/product/[VALUE]/details` | Route parameter binding -> validate -> encode |
| Matrix parameters | `/resource;sort=[VALUE]` | Framework-dependent parsing -> validate -> encode |
| Fragment (hash) | `#section=[VALUE]` | Not sent to server - DOM XSS surface only |

### 7.2 Request Body Inputs

| Source | Example | Expected Safe Behavior |
|---|---|---|
| Form fields (POST) | `username=[VALUE]&password=...` | Form-decode -> validate -> encode in error response |
| JSON properties | `{"search":"[VALUE]"}` | JSON-parse -> process -> JSON-serialize response |
| XML values | `<query>[VALUE]</query>` | XML-parse -> process -> XML-encode response |
| Multipart fields | `Content-Disposition: form-data; name="file"; filename="[VALUE]"` | Parse -> validate filename -> encode if displayed |
| GraphQL variables | `{"variables":{"q":"[VALUE]"}}` | Parse -> validate -> encode in error messages |

### 7.3 Header-Based Inputs

| Source | Example | Expected Safe Behavior |
|---|---|---|
| Host / X-Forwarded-Host | `Host: [VALUE]` | Validate against allowlist |
| Referer | `Referer: https://[VALUE]/page` | Should not reflect into HTML |
| User-Agent | `User-Agent: [VALUE]` | Should not reflect into HTML |
| Accept-Language | `Accept-Language: [VALUE]` | Validate against supported locales |
| Custom headers | `X-Custom: [VALUE]` | Should not reflect into HTML |

### 7.4 Cookie-Based Inputs

| Source | Example | Expected Safe Behavior |
|---|---|---|
| Session/preference cookies | `Cookie: lang=[VALUE]` | Validate -> encode if reflected |
| Tracking cookies | `Cookie: utm_source=[VALUE]` | Should not reflect into HTML |

### 7.5 Application-Specific Inputs

| Source | Example | Expected Safe Behavior |
|---|---|---|
| OAuth redirect_uri | `?redirect_uri=[VALUE]` | Validate against registered URIs |
| OAuth state | `?state=[VALUE]` | Opaque token, should not reflect as HTML |
| Error-producing input | `?id=invalid_[VALUE]` | Error template should encode the invalid input |
| API doc config | `?url=[VALUE]` | Validate URL, do not render as HTML |
| Pagination/sort values | `?sort=[VALUE]&order=asc` | Validate against allowlist |
| WebSocket handshake | Various headers | Should not reflect into HTTP error responses |

---

*Next chunk: chunk-04-browser-parsing-decoding.md*
