# 65 - Webhook and Callback XSS Vectors

## Overview

Webhook and callback systems introduce XSS through:
- Webhook payload stored XSS when admin dashboards render user-controlled fields without encoding
- Missing webhook signature verification enabling payload forgery
- Callback URL injection with javascript:/data: schemes in OAuth and payment flows
- Notification template XSS in admin preview interfaces
- Push notification payload rendering in webviews

## Webhook Payload Stored XSS

### Simple Membership Stripe Webhook XSS (CVE-2026-11855)

**CVE-2026-11855:** Before version 4.7.5, the Simple Membership WordPress plugin does not verify the authenticity of Stripe webhook requests when no signing secret is configured, nor escape a value taken from them before outputting it in an administrator notice. CVSS 8.8.

```
Attack Flow:
1. Attacker sends a forged Stripe webhook to the plugin endpoint
2. The plugin stores the payload without verifying the Stripe-Signature header
3. A user-controlled field (customer name, description) contains XSS
4. An administrator views the admin notices page
5. The stored XSS payload executes in the admin's browser
6. The attacker gains admin session access
```

### Webhook Stored XSS Pattern

All three conditions must be present:
1. Webhook payloads containing user-controlled fields (names, descriptions, metadata) are stored
2. An admin dashboard renders those stored values without HTML encoding
3. Webhook signature verification is absent or optional

```python
# VULNERABLE: Webhook handler storing unsanitized data
@app.route('/webhooks/stripe', methods=['POST'])
def stripe_webhook():
    payload = request.get_json()
    # No signature verification!
    # No input sanitization!
    db.store_event(
        customer_name=payload['data']['object']['name'],
        description=payload['data']['object']['description']
    )
    return '', 200

# Admin template rendering stored webhook data:
# <p>Customer: {{ event.customer_name }}</p>
# If customer_name = "<script>alert(document.cookie)</script>"
# and template engine does not auto-escape, XSS fires

# SAFE: Verify signature and sanitize on output
@app.route('/webhooks/stripe', methods=['POST'])
def stripe_webhook():
    sig = request.headers.get('Stripe-Signature')
    try:
        event = stripe.Webhook.construct_event(
            request.data, sig, endpoint_secret
        )
    except ValueError:
        return 'Invalid payload', 400
    except stripe.error.SignatureVerificationError:
        return 'Invalid signature', 400
    # Store the verified event data
    # Always HTML-encode when rendering in admin UI
```

### Webhook Provider Signing

Stripe signs all webhook payloads with HMAC-SHA256 using a webhook signing secret and includes a timestamp to prevent replay attacks. Slack uses a similar approach. Both providers document signature verification as the primary defense against payload forgery.

### Cross-Provider Webhook XSS

The pattern extends beyond Stripe: any SaaS webhook (Twilio, SendGrid, Shopify, etc.) that includes user-controlled fields (customer names, message bodies, product descriptions) can be an XSS vector if the receiving application renders them without sanitization.

Stripe, GitHub, and Slack's own dashboard interfaces properly sanitize webhook data for display. The vulnerability surface is in third-party applications that receive and display webhook data.

## Callback URL Injection

### better-auth javascript: URI XSS

The better-auth library (pre-1.6.13) oidc-provider and mcp plugins failed to validate the scheme of `redirect_uri` values registered by clients. An attacker could register a client with a `javascript:` redirect_uri. When the consent page assigned the returned value to `window.location.href`, attacker script executed in the authorization server's origin.

Fixed by rejecting `javascript:`, `data:`, and `vbscript:` schemes at registration.

```javascript
// VULNERABLE: No URI scheme validation on callback registration
app.post('/oauth/register', (req, res) => {
  const client = {
    redirect_uri: req.body.redirect_uri  // Accepts any scheme
  };
  db.saveClient(client);
});

// Later, during authorization:
app.get('/oauth/authorize', (req, res) => {
  // ...authorization logic...
  // Redirect to registered callback
  window.location.href = client.redirect_uri;
  // If redirect_uri = "javascript:alert(document.cookie)"
  // XSS fires in the authorization server's origin
});

// SAFE: Validate URI scheme
function validateRedirectUri(uri) {
  try {
    const parsed = new URL(uri);
    if (!['https:'].includes(parsed.protocol)) {
      throw new Error('Invalid scheme');
    }
    return uri;
  } catch {
    throw new Error('Invalid redirect_uri');
  }
}
```

### Spotipy OAuth Callback XSS (CVE-2025-66040)

An unsanitized error parameter in the library's local OAuth callback server allowed attackers to execute JavaScript in the user's browser during OAuth authentication.

### Feathers.js Redirect Token Leakage (CVE-2026-27191)

Concatenating a user-supplied `redirect` parameter onto a base origin allowed attackers to alter the URL authority during callback handling, leading to token leakage via open redirect. Affects versions up to 5.0.39.

### GitHub Callback URL Bug

A callback URL inserted into an anchor `href` on a redirect page could carry a `javascript:` URL. Impact was limited because a user had to manually click the link. GitHub responded by blocking dangerous schemes.

### Callback URL Injection Beyond OAuth

Any system that accepts a user-provided URL for post-action redirects (payment completion, email verification, SSO) is potentially vulnerable if it does not validate the scheme and domain.

## Notification Template XSS

Notification template XSS affects admin preview/management interfaces, not the delivered notification itself. Most email clients strip `<script>` tags and event handlers.

### Liferay Calendar Notification (CVE-2024-25151)

Calendar notification email templates did not escape user-supplied data, allowing injection through calendar event titles or user names. Impact depends on the recipient's mail client.

### Stormshield Alert Template (CVE-2024-31946)

Malicious JavaScript in an alert email template ran in the template's preview on the management console. CVSS 3.9 (Low). Exploitation required write access to the email alerts page. Affects SNS 3.7.0-4.7.4. Fixed in 3.7.42, 3.11.30, 4.3.25, 4.7.5.

### Formie/Craft CMS Notification (CVE-2025-32426)

Injected code in an email notification's HTML rendered in the admin preview, but not when the email was delivered normally. Exploitation needed access to the form's notification settings.

### WordPress Push Notification Plugins

**CVE-2025-58873 (Pushe Web Push):** Stored XSS in a web push notification plugin affecting versions up to 0.5.0. Requires high-privileged authenticated attacker.

**CVE-2025-31311 (All Push Notification for WP):** Reflected XSS in an admin page where request parameters were echoed without validation.

### Push vs Email Notification XSS

Push notification template XSS is more impactful than email template XSS because push notification content may be rendered in contexts (browser notification UI, in-app webviews) that execute JavaScript. SMS notification template XSS is largely theoretical since SMS is plaintext.

## Testing Methodology

1. **Identify webhook endpoints** and test for missing signature verification
2. **Send forged webhook payloads** with XSS in user-controlled fields
3. **Check admin dashboards** that display webhook data for output encoding
4. **Test callback/redirect URLs** with javascript: and data: schemes
5. **Check notification template previews** for XSS execution
6. **Test push notification content** rendering in webviews
7. **Check email template admin editors** for preview-time XSS
8. **Verify URI scheme validation** at both registration and redirect time

## Bug Bounty Tips

1. Webhook stored XSS has a high CVSS (8.8 for CVE-2026-11855) because it targets admin sessions
2. Missing webhook signature verification is a precondition -- always check for it
3. The javascript: URI in callback URLs is the most common injection pattern
4. Notification template XSS typically affects admin previews, not delivered emails
5. Push notification XSS is more impactful than email notification XSS
6. SaaS provider dashboards (Stripe, GitHub, Slack) properly sanitize -- focus on third-party receivers
7. Payment completion callbacks and email verification links are underexplored callback injection targets
8. Multi-hop callback chains (registered URL -> open redirector -> attacker) bypass exact-match validation
