# Agent Chunk 07: Special Parser Contexts, Headers & Error Pages

**Agent Task:** Test reflected XSS in special HTML parser contexts (comments, RCDATA, RAWTEXT, SVG/MathML), noscript/template/srcdoc elements, HTTP header reflection, error pages, CRLF injection chains, and reverse proxy error pages.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 15. Special Parser Contexts

### 15.1 HTML Comments

```html
<!-- Your search: [REFLECTED] -->
```

HTML comments are generally non-executable. However:
- The sequence `-->` terminates the comment, returning to Data state
- The sequence `--!>` also terminates comments in some parser implementations
- Within the comment, `<` does not start tags, so tag injection is blocked
- **Legacy concern**: Internet Explorer supported conditional comments — this is OBSOLETE and not relevant to modern browsers

**Verdict**: LOW risk in modern browsers unless the attacker can inject `-->` to escape the comment.

**Source**: KB-05, WHATWG HTML Living Standard §13.2.5.43–48.

### 15.2 RCDATA Elements (`<title>`, `<textarea>`)

```html
<title>[REFLECTED]</title>
```

In RCDATA state:
- `<` does NOT start new tags (rendered as text)
- Character references ARE decoded (`&lt;` → `<` but as text, not markup)
- The ONLY way to escape is the matching end tag (`</title>` or `</textarea>`)

**Attack model**: If the reflected value contains `</title>`, it terminates the RCDATA element, and subsequent content is parsed in Data state:
```
Input: [MARKER]</title><[CONTEXT_SPECIFIC_TEST_VALUE]>
```

**Source**: KB-05, WHATWG HTML Living Standard §13.2.5.2.

### 15.3 RAWTEXT Elements (`<style>`, `<xmp>`, `<iframe>`, `<noembed>`, `<noframes>`)

In RAWTEXT state:
- `<` does NOT start new tags
- Character references are NOT decoded (unlike RCDATA)
- Only the matching end tag escapes

**Key difference from RCDATA**: In `<style>`, entities like `&lt;` are NOT decoded — they appear as literal text `&lt;`. This means HTML encoding is ineffective as a defense inside `<style>`, but also means entity-based injection is impossible.

### 15.4 SVG and MathML Namespace Confusion

When the parser encounters `<svg>` or `<math>`, it switches to foreign content parsing. Within foreign content:
- Element and attribute names are case-sensitive (unlike HTML)
- Different elements are recognized as self-closing
- HTML integration points (`<foreignObject>`, `<desc>`, `<title>` in SVG; `<mi>`, `<mo>`, `<mn>`, `<ms>`, `<mtext>` in MathML) switch back to HTML parsing

**Namespace confusion for XSS**: The `<style>` element behaves differently in HTML versus SVG namespaces. In HTML, `<style>` enters RAWTEXT state (no tags parsed). In SVG namespace, `<style>` content may be parsed differently, potentially allowing tag injection within what appears to be a style block.

This namespace differential is the basis for mutation XSS (mXSS) attacks against sanitizers like DOMPurify. The sanitizer parses the content as HTML, while the browser may reparse it in a different namespace context.

**Source**: KB-05, KB-16 (sanitizer bypass), DOMPurify bypass history (mizu.re research), Michał Bentkowski's namespace confusion bypass of DOMPurify 2.0.17.

### 15.5 `<noscript>` Context

The `<noscript>` element's content parsing depends on whether JavaScript is enabled:
- **JS enabled**: Content is treated as RAWTEXT (not parsed as HTML)
- **JS disabled**: Content is parsed as normal HTML

If a reflected value appears inside `<noscript>` and JavaScript is enabled, it cannot be directly exploited. However, some sanitizers parse `<noscript>` content differently from browsers, creating potential mXSS vectors.

### 15.6 `<template>` Element

The HTML `<template>` element creates an inert document fragment. Its content is parsed but NOT rendered or executed. Scripts inside `<template>` do not run, and event handlers do not fire.

**XSS relevance**: A reflected value inside `<template>` is generally safe UNLESS:
- Client-side JavaScript clones and inserts the template content into the live DOM
- The template is used as part of a web component that processes its content unsafely

### 15.7 `iframe srcdoc`

The `srcdoc` attribute on `<iframe>` contains HTML that is parsed as a new document:
```html
<iframe srcdoc="[REFLECTED]"></iframe>
```

Content in `srcdoc` is HTML-entity-decoded (because it's an attribute value), then parsed as a complete HTML document. If the reflected value is not properly HTML-attribute-encoded, it can contain executable HTML.

**Note**: The `srcdoc` document inherits the parent's origin, so XSS within `srcdoc` has full access to the parent page's data.

---

## 16. Header, Error-Page and Gateway Reflection

### 16.1 HTTP Header Reflection

Server-side code that reflects HTTP headers into HTML responses creates reflected XSS surfaces:

| Header | Common Reflection Point | Risk Level |
|---|---|---|
| `Host` / `X-Forwarded-Host` | Page titles, canonical URLs, error pages | HIGH — often controls full URL construction |
| `Referer` | "Back" links, analytics, error pages | MEDIUM — URL-encoded by browser |
| `User-Agent` | Debug pages, error details, admin dashboards | MEDIUM — requires victim to use attacker-controlled UA |
| `Accept-Language` | Localization errors, language selector | LOW — limited character set |
| `X-Forwarded-For` | Rate-limit pages, access logs displayed in admin | LOW — requires specific application behavior |

**Delivery challenge**: Unlike query-parameter reflection, header-based reflection requires the victim to send a request with an attacker-controlled header value. This typically requires:
- A form submission from an attacker-controlled page (for `Referer`)
- A CRLF injection vulnerability (see Section 16.3)
- A proxy or middleware that copies a query parameter into a header
- Social engineering to install a browser extension or proxy

### 16.2 Error Page Reflection

Error pages are a common source of reflected XSS because they often:
- Use different template engines or layouts than the main application
- Lack the auto-escaping configuration applied to normal pages
- Reflect the request path, query parameters, or invalid input in error messages
- Are generated by middleware, reverse proxies, or frameworks rather than the application itself

**Common patterns**:
- `404 Not Found: /page/[REFLECTED]` — path segment reflected in error message
- `Invalid parameter: [REFLECTED]` — query parameter reflected in validation error
- `Cannot parse JSON: "[REFLECTED]"` — malformed input reflected in parser error
- Framework debug pages reflecting full request details in development mode

### 16.3 CRLF Injection to Reflected XSS

CRLF injection (CWE-113) allows an attacker to inject HTTP response headers by including carriage return (`\r`, `%0D`) and line feed (`\n`, `%0A`) characters in input that is reflected into response headers. If double CRLF (`\r\n\r\n`) is injected, the attacker controls the response body, enabling reflected XSS.

**Chain model**:
```
Request: /redirect?url=https://example.com%0D%0A%0D%0A[HTML_WITH_SCRIPT]
Response:
HTTP/1.1 302 Found
Location: https://example.com

[HTML_WITH_SCRIPT]
```

**HackerOne reports** (from XSS-16 case study):
- Twitter: CRLF to reflected XSS, $1,680 bounty
- TikTok: Two CRLF-to-XSS reports

**Modern mitigations**: Most modern web frameworks and servers reject or encode CRLF characters in header values. Node.js (since v14+) throws on CRLF in `setHeader()`. Apache and Nginx reject CRLF in header values.

**Source**: XSS-16, CWE-113 documentation.

### 16.4 Reverse Proxy and Gateway Error Pages

Reverse proxies (Nginx, Apache, HAProxy, cloud load balancers) and API gateways generate their own error pages when the backend is unreachable or returns an error. These error pages may:
- Reflect the requested URL or Host header without encoding
- Use minimal templates without proper escaping
- Be outside the application's CSP or security header configuration
- Serve with `Content-Type: text/html` regardless of the original request

---

*Next chunk: chunk-08-oauth-apidocs-testing.md*
