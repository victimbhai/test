# 32 - XSS Impact & Business Context

## Overview

Cross-site scripting is frequently underestimated as a "low-impact" vulnerability, yet real-world data demonstrates that XSS enables account takeover, financial fraud, data breaches, worm propagation, and serves as the initial access vector in sophisticated attack chains. This document catalogs real-world impact data, regulatory consequences, and attack chain methodologies to demonstrate the true business risk of XSS vulnerabilities.

---

## 1. Real-World Breach Examples Involving XSS

### British Airways / Magecart Attack (2018-2019)

**What happened:** Magecart attackers compromised a British Airways network account (originally issued to Swissport, a cargo-handling firm) and gained access to an administration console that allowed editing JavaScript on BA's website. Attackers modified baggage claim form scripts to exfiltrate payment data to a rogue domain (baways.com), which had been registered with a legitimate SSL certificate.

**Impact:**
- 380,000 customer payment card details stolen over 15 days
- Customer names, billing addresses, email addresses, and full card details exfiltrated
- The UK Information Commissioner's Office (ICO) initially proposed a fine of 183 million GBP under GDPR, later reduced to 20 million GBP

**Technical approach:** JavaScript injection into the BA website's payment processing page, functioning as a stored XSS / supply chain attack that skimmed credit card data in real-time.

Source: https://cside.com/blog/the-british-airways-attack-of-2018-full-breakdown
Source: https://evalian.co.uk/ba-breach-exemplifies-ongoing-magecart-supply-chain-attack-threat/

### Fortnite XSS Vulnerability (2019)

**What happened:** A retired, unsecured page on Epic Games' infrastructure contained an XSS vulnerability. Researchers discovered that attackers could exploit this to steal authentication tokens and access user accounts.

**Impact:**
- 200+ million user accounts potentially exposed
- Full account takeover possible via stolen OAuth tokens
- Access to purchase history, payment methods, and in-game currency
- Epic Games patched the vulnerability after responsible disclosure

Source: https://brightsec.com/blog/xss-attack/

### eBay XSS Attacks (2015-2017)

**What happened:** Persistent XSS vulnerabilities in eBay's listing pages allowed sellers to inject malicious JavaScript into product descriptions that executed when buyers viewed listings.

**Impact:**
- Phishing attacks redirecting buyers to credential-harvesting pages
- Session hijacking enabling account takeover
- Unauthorized purchases using stolen sessions
- Reputation damage to eBay's marketplace trust

### ERPNext/Frappe Stored XSS (2025)

**What happened:** A stored XSS vulnerability was disclosed in ERPNext/Frappe's Blog module where authenticated users could inject malicious HTML/JavaScript into the content field.

**Impact:**
- Payloads executed in browsers of all users viewing the blog post
- Session hijacking and data theft risk for enterprise users
- Particularly dangerous in ERP systems due to access to financial data, employee records, and business operations

---

## 2. Financial Impact Data

### Cost of Data Breaches (IBM/Ponemon Data)

| Year | Average Breach Cost | Financial Sector Average |
|------|-------------------|------------------------|
| 2023 | $4.45 million | $5.90 million |
| 2024 | $4.88 million | $6.08 million |
| 2025 | Projected $5.2M+ | Projected $6.5M+ |

**XSS as a breach vector contributes to these costs through:**
- Initial access enabling further exploitation
- Customer data exfiltration (payment cards, PII)
- Incident response and forensics
- Legal fees and regulatory fines
- Customer notification and credit monitoring
- Business interruption and downtime
- Brand and reputation damage

### Direct Financial Losses from XSS-Enabled Attacks

- **Magecart campaigns** (2018-2024): Estimated $1+ billion in stolen payment card data across thousands of compromised e-commerce sites
- **British Airways**: 20 million GBP GDPR fine + undisclosed settlement costs + reputational damage
- **Cryptocurrency exchanges**: Multiple exchanges have suffered XSS-enabled credential theft leading to direct fund theft

---

## 3. Regulatory Implications

### GDPR (General Data Protection Regulation)

**Fines:**
- Tier 1 (technical/organizational failures): Up to 2% of global annual revenue or 10 million EUR, whichever is higher
- Tier 2 (data processing violations): Up to 4% of global annual revenue or 20 million EUR, whichever is higher

**XSS relevance to GDPR:**
- XSS enabling data exfiltration triggers mandatory 72-hour breach notification to supervisory authorities
- Failure to implement adequate technical measures (including XSS prevention) violates Article 32 (security of processing)
- Data subjects must be notified if the breach is likely to result in high risk to their rights and freedoms
- British Airways' 20 million GBP GDPR fine was directly related to the Magecart JavaScript injection attack

Source: https://accutivesecurity.com/data-breach-statistics-2024-penalties-and-fines-for-major-regulations/

### PCI-DSS (Payment Card Industry Data Security Standard)

**Fines:**
- $5,000 to $100,000 per month until compliance is achieved
- $50 to $90 penalty per compromised customer record (up to $500,000 maximum)
- Potential loss of the ability to process card payments entirely

**XSS relevance to PCI-DSS:**
- PCI DSS Requirement 6.2 mandates protection against common coding vulnerabilities including XSS
- PCI DSS 4.0 specifically requires web application firewalls or equivalent protection
- XSS enabling payment card theft (Magecart-style attacks) is a direct PCI-DSS violation
- Quarterly ASV scans must check for XSS vulnerabilities

Source: https://pcidssguide.com/what-are-the-pci-compliance-fines-and-penalties/
Source: https://securiti.ai/pci-dss-violation-fines-and-penalties/

### Other Regulatory Frameworks

- **HIPAA**: XSS enabling access to protected health information (PHI) can result in fines up to $1.5 million per violation category
- **CCPA**: XSS leading to data exposure of California residents triggers statutory damages of $100-$750 per consumer per incident
- **SOX (Sarbanes-Oxley)**: XSS compromising financial reporting systems can trigger compliance violations for publicly traded companies

---

## 4. Brand/Reputation Damage Case Studies

### Key Findings on Reputational Impact

- **60% of small businesses** close within 6 months of a significant data breach (National Cyber Security Alliance)
- **Customer churn** increases 3-5% following a publicized breach
- **Stock price impact**: Companies experience an average 3-5% stock decline following breach disclosure, with recovery taking 6-12 months
- **Trust erosion**: 81% of consumers say they would stop engaging with a brand online after a data breach

### Case Studies

**British Airways:**
- Share price dropped following breach disclosure
- Customer trust significantly impacted, with many switching airlines
- Required significant investment in security infrastructure and communication

**Fortnite/Epic Games:**
- Rapid patch after disclosure prevented large-scale exploitation
- Responsible disclosure and fast response limited reputational damage
- Demonstrates the value of bug bounty programs in managing reputation risk

**Magecart Campaigns (Multiple E-Commerce Sites):**
- Ticketmaster, Newegg, and hundreds of smaller retailers were compromised
- Lasting damage to customer willingness to enter payment details
- Many smaller merchants lost the ability to process cards

---

## 5. XSS Worm Case Studies

### The Samy Worm (MySpace, 2005)

**Technical Details:**
- Created by Samy Kamkar, released October 4, 2005
- Exploited a stored XSS vulnerability in MySpace user profiles
- MySpace stripped the word "javascript" but Kamkar discovered he could split it across two lines inside a CSS tag to bypass the filter
- Used XMLHttpRequest (AJAX) to silently send friend requests and modify visiting users' profiles
- The payload copied itself into each visitor's profile, making it self-propagating

**Propagation:**
- Infected 1 million profiles in 20 hours
- At peak, spreading at 1,000 new infections every few seconds
- Exponential propagation pattern: each infected profile infected every visitor
- MySpace was forced to take the entire site offline to stop the worm

**Impact:**
- Fastest-spreading worm in history at the time
- Demonstrated that XSS could be weaponized for mass exploitation
- Kamkar was sentenced to 3 years probation, 90 days community service, and ordered to pay restitution
- Catalyzed the web security industry's focus on XSS prevention

Source: https://en.wikipedia.org/wiki/Samy_(computer_worm)
Source: https://www.vice.com/en/article/the-myspace-worm-that-changed-the-internet-forever/

### TweetDeck XSS Worm (2014)

**Technical Details:**
- Exploited a reflected XSS vulnerability in TweetDeck, Twitter's popular client
- A user inadvertently discovered the vulnerability and tweeted a link containing a script
- When TweetDeck users viewed the tweet, the script executed and automatically retweeted itself
- The self-retweeting mechanism created exponential propagation

**Impact:**
- Rapidly spread across TweetDeck's user base
- Twitter temporarily shut down TweetDeck access to contain the worm
- No malicious intent in the original discovery, but demonstrated the potential for Twitter-based XSS worms
- Led to significant improvements in Twitter's content rendering pipeline

### Other Notable XSS Worms

**StalkDaily Worm (Twitter, 2009):**
- Used XSS to automatically tweet a link to StalkDaily.com from infected accounts
- Forced Twitter to disable the vulnerable feature

**Yamanner Worm (Yahoo Mail, 2006):**
- Exploited XSS in Yahoo Mail to harvest email addresses
- Self-propagated by sending copies to all contacts in the victim's address book

**Orkut XSS Worm (2010):**
- Targeted Google's Orkut social network
- Automatically added infected users to communities and propagated to their connections

---

## 6. XSS in Attack Chains

### XSS as Initial Access Vector

XSS frequently serves as the entry point for more sophisticated attack chains. Attackers rarely rely on a single flaw; they combine multiple weaknesses to escalate an attack.

**Common XSS-Initiated Attack Chains:**

```
XSS -> Session Hijacking -> Account Takeover -> Data Exfiltration
XSS -> Admin Panel Access -> Server-Side Exploitation -> Full Compromise
XSS -> Credential Phishing -> Lateral Movement -> Persistence
XSS -> OAuth Token Theft -> API Access -> Data Breach
```

### XSS + CSRF Chaining

A stored XSS payload can inject CSRF forms directly into the DOM, chaining execution within the same domain. This bypasses CSRF protections because the malicious request originates from the legitimate domain.

**Example attack flow:**
1. Attacker discovers stored XSS in a user profile field
2. XSS payload generates a hidden form that performs an admin action (e.g., creating a new admin account)
3. When an admin views the attacker's profile, the CSRF payload executes with the admin's session
4. Attacker gains admin access to the application

```javascript
// XSS payload that chains with CSRF to create admin account
fetch('/api/admin/users', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  credentials: 'include',
  body: JSON.stringify({
    username: 'attacker',
    role: 'admin',
    password: 'compromised123'
  })
});
```

Source: https://portswigger.net/web-security/cross-site-scripting/exploiting/lab-perform-csrf
Source: https://www.microsoft.com/en-us/msrc/blog/2025/11/weaponizing-cross-site-scripting-when-one-bug-isnt-enough

### XSS + SSRF Chaining

XSS can be used to make server-side requests from the browser that the attacker cannot make directly:

1. XSS payload forces the victim's browser to make requests to internal services
2. Responses are exfiltrated back to the attacker
3. This effectively turns the victim's browser into a proxy for SSRF

### XSS in APT Campaigns

Advanced Persistent Threat groups have used XSS as part of multi-stage campaigns:

- **Watering hole attacks**: Compromising legitimate websites frequented by targets, injecting XSS payloads to deliver exploits
- **Spearphishing with XSS**: Sending links to vulnerable webmail interfaces with XSS payloads that steal email content
- **WebKit zero-days** (CVE-2025-43529, CVE-2025-14174): Apple confirmed these were exploited in targeted iPhone spyware attacks, demonstrating state-level interest in browser XSS exploitation

In sophisticated intrusions, XSS may operate as part of multi-vector campaigns. For example, creating a new SAML identity provider via XSS+CSRF in a cloud dashboard grants external persistence under the radar of most detection controls.

---

## 7. Supply Chain XSS

### Third-Party Script Risks

Modern websites average 30-50 third-party scripts (analytics, ads, chat widgets, A/B testing, tag managers), each representing a potential XSS vector.

### Polyfill.io Supply Chain Attack (2024)

**What happened:** In February 2024, a Chinese company (Funnull) acquired the polyfill.io domain and GitHub account, then modified the Polyfill.js library to inject malicious code into all websites loading scripts from cdn.polyfill.io.

**Impact:**
- 490,000+ websites compromised
- Affected major brands including Hulu, Mercedes-Benz, and Warner Bros.
- The attack functioned as stored XSS: malicious JavaScript executed automatically on any page loading the compromised library
- No user interaction required beyond visiting a compromised page

**Lessons:**
- Third-party script integrity must be verified (Subresource Integrity / SRI)
- Self-hosting critical libraries eliminates CDN compromise risk
- CSP should restrict script sources to prevent unauthorized script loading

Source: https://www.sonatype.com/blog/polyfill.io-supply-chain-attack-hits-100000-websites-all-you-need-to-know
Source: https://securityboulevard.com/2024/07/polyfill-io-supply-chain-attack-malicious-javascript-injection-puts-over-100k-websites-at-risk/

### Magecart Supply Chain Model

Magecart groups specialize in JavaScript supply chain attacks targeting e-commerce platforms:

**Attack vectors:**
- Compromising third-party payment processing scripts
- Injecting skimmer JavaScript via compromised tag managers
- Exploiting vulnerable CMS plugins to inject persistent scripts
- Compromising CDN accounts to modify hosted libraries

**Financial impact:** Magecart campaigns have been responsible for an estimated $1+ billion in stolen payment card data since 2015.

Source: https://www.imperva.com/learn/application-security/magecart/

### Dependency Injection Attacks

**NPM/Yarn ecosystem risks:**
- Typosquatting: Malicious packages with names similar to popular libraries
- Dependency confusion: Exploiting package resolution to load malicious internal packages
- Compromised maintainer accounts: Legitimate packages modified to include malicious code
- Build-time injection: Malicious post-install scripts that modify application code

---

## 8. CVSS Scoring for XSS Vulnerabilities

### Reflected XSS

**Typical CVSS v3.1 Vector:**
`CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N`

**Score range:** 6.1 (Medium) - requires user interaction

**Factors that increase score:**
- No authentication required (PR:N): 6.1 baseline
- Privilege escalation possible: Can increase to 8.8
- Impact to other components (Scope Changed): Increases from 5.4 to 6.1
- No user interaction needed (rare for reflected): Increases to 7.2+

### Stored XSS

**Typical CVSS v3.1 Vector (Low Privilege):**
`CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/A:N`

**Score range:** 5.4 (Medium) to 9.1 (Critical)

**Factors that increase score:**
- No authentication required for injection: 7.2+
- No user interaction needed for execution: 7.2+
- High confidentiality impact (e.g., admin token theft): 8.0+
- Wormable / self-propagating: Should be scored as High/Critical

### DOM-Based XSS

**Scoring considerations:**
- Client-side only exploitation: Similar to reflected XSS scoring
- May have Scope Changed if affecting other origins
- CVSS v3.0+ allows scoring client-side impacts

### Scoring Reference Table

| XSS Scenario | CVSS Score | Severity |
|--------------|------------|----------|
| Reflected, requires auth + interaction | 5.4 | Medium |
| Reflected, no auth, requires interaction | 6.1 | Medium |
| Stored, requires auth, no interaction | 6.5 | Medium |
| Reflected, no auth, no interaction | 7.2 | High |
| Stored, no auth, leads to session hijack | 8.0 | High |
| Stored, no auth, admin context, no interaction | 8.8-9.1 | High-Critical |
| UXSS / Browser-level XSS | 8.8-9.8 | High-Critical |

Source: https://www.first.org/cvss/v3-0/user-guide
Source: https://www.jenkins.io/blog/2020/07/15/xss-severity/
Source: https://copyprogramming.com/howto/cvss-score-for-self-xss-stored-xss
