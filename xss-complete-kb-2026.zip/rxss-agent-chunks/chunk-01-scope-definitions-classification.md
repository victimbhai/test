# Agent Chunk 01: Scope, Definitions & Classification

**Agent Task:** Before any testing begins, the agent MUST understand what reflected XSS is, what is in scope, and what is out of scope. This chunk defines the classification criteria that every other chunk depends on.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Do not execute repository tools, scripts or Nuclei templates
- Do not reproduce credential-stealing, session-stealing, phishing, keylogging or persistence code
- Do not compile a weaponized payload or WAF-bypass library
- Use abstract placeholders: `[UNIQUE_REFLECTION_MARKER]`, `[HARMLESS_EXECUTION_MARKER]`, `[CONTEXT_SPECIFIC_TEST_VALUE]`, `[NEGATIVE_CONTROL]`, `[ENCODED_VARIANT]`, `[CONTROLLED_PARAMETER]`
- Browser-execution examples must be limited to an isolated local laboratory and a harmless visible or console marker

---

## 1. Executive Summary

This guide is a comprehensive, technically precise research reference focused exclusively on **reflected cross-site scripting (XSS)**. It synthesizes three permitted local source repositories, extensive public internet research, browser specifications, framework documentation, CVE databases, and bug-bounty disclosure platforms.

### Key Findings

**Reflected XSS remains prevalent.** Despite two decades of research and the deprecation of browser-native XSS auditors (Chrome removed XSS Auditor in Chrome 78, July 2019), reflected XSS continues to appear in modern applications. The CVSS 3.1 baseline for reflected XSS is 6.1 (Medium), though impact escalates significantly when chained with cache poisoning, OAuth flows, or when CSP is absent or misconfigured.

**The request-to-browser pipeline is the correct analytical model.** A reflected value is not automatically reflected XSS. Confirmation requires tracing: attacker-controlled HTTP request value -> server-side decoding/normalization -> application processing -> template/response construction -> output encoding/sanitization -> immediate HTTP response -> browser parsing context -> possible script execution.

**Browser context determines exploitability, not reflection alone.** The same reflected value may be harmless in a text node (HTML-entity-encoded), dangerous in an unquoted HTML attribute, and critical inside a JavaScript string literal.

**Modern frameworks reduce but do not eliminate reflected XSS.** React's JSX auto-escaping, Vue's template interpolation, and Angular's DomSanitizer provide strong defaults, but every major framework provides escape hatches (`dangerouslySetInnerHTML`, `v-html`, `bypassSecurityTrustHtml`, `{@html}`, `set:html`) that reintroduce risk.

**Sanitizer bypasses continue to emerge.** DOMPurify has experienced multiple bypass CVEs through 2024-2026 (CVE-2024-47875, CVE-2025-26791, CVE-2026-41238, CVE-2026-47423). Each bypass was version-specific and promptly patched, but sanitizers require continuous updates.

**WAFs are unreliable as primary XSS defenses.** The WAFFLED research paper (2025) demonstrated 1,207 unique bypasses across Cloudflare, Azure, Google Cloud Armor, and ModSecurity. Only AWS WAF resisted all tested mutations under default configuration.

---

## 2. Strict Scope and Definitions

### 2.1 Reflected XSS Defined

Reflected XSS occurs when ALL of the following conditions are met:

1. **Request-controlled input**: An attacker can place arbitrary content into an HTTP request (query parameter, path component, form field, header, cookie, or other request element)
2. **Immediate server response reflection**: The server includes the attacker-controlled value in the immediate HTTP response without adequate transformation
3. **Insufficient context-specific protection**: The reflected value is not correctly encoded, escaped, or sanitized for its specific output context
4. **Browser interpretation in an executable context**: The browser's HTML parser, JavaScript engine, or URL handler interprets the reflected value in a way that permits script execution
5. **Realistic delivery path**: A victim can be induced to follow a crafted link, submit a form, or otherwise trigger the vulnerable request

### 2.2 Classification Decision Tree

```
Is the value controlled by the HTTP request?
+-- NO -> Not XSS (static content, server-generated)
+-- YES -> Does the value appear in the IMMEDIATE server response?
    +-- NO -> Is it stored for later retrieval?
    |   +-- YES -> STORED XSS (out of scope)
    |   +-- NO -> Is it processed only client-side?
    |       +-- YES -> PURE DOM XSS (out of scope)
    |       +-- NO -> Not XSS
    +-- YES -> Is the reflection in an executable browser context?
        +-- NO -> Is it safely encoded for its context?
        |   +-- YES -> SAFE REFLECTION (not XSS)
        |   +-- NO -> HTML INJECTION without execution (not XSS, but may warrant fixing)
        +-- YES -> Does server reflection reach a client-side sink?
            +-- NO, server context only -> REFLECTED XSS (REFLECTED_SERVER) - IN SCOPE
            +-- YES, server reflects then client processes ->
                Is execution from the server reflection or the client sink?
                +-- Server reflection alone causes execution -> REFLECTED XSS - IN SCOPE
                +-- Both required -> REFLECTED HYBRID (REFLECTED_HYBRID) - IN SCOPE
                +-- Client-side processing alone -> PURE DOM XSS (out of scope)
```

### 2.3 In-Scope Reflection Surfaces

| Reflection Source | Description | Typical Endpoint Features |
|---|---|---|
| Query parameters | `?search=[VALUE]` reflected in response body | Search pages, filter interfaces, error pages |
| Path components | `/category/[VALUE]/list` reflected in breadcrumbs/titles | Dynamic routing, RESTful APIs |
| Form and request-body values | POST parameters reflected in validation messages | Login errors, form submissions, registration |
| JSON/XML properties | Request JSON values reflected in error responses | API endpoints, GraphQL errors |
| HTTP headers | `Referer`, `User-Agent`, `Host`, `X-Forwarded-For` in responses | Error pages, debug output, analytics |
| Cookies | Cookie values reflected in personalization/error pages | Welcome messages, preference displays |
| Error messages | Input causing errors reflected in error template | 404 pages, validation errors, exception handlers |
| OAuth/redirect parameters | `redirect_uri`, `state`, `callback` reflected in consent/callback pages | OAuth flows, SSO callbacks |
| API documentation | Configuration parameters in Swagger UI/OpenAPI renderers | `url`, `configUrl` in API doc interfaces |
| Hydration data | Values reflected in `__NEXT_DATA__`, `__NUXT__`, inline JSON | SSR frameworks, isomorphic apps |
| Server-rendered JavaScript | Values interpolated into inline `<script>` blocks | Configuration objects, analytics init |

### 2.4 Out-of-Scope Categories (Comparison Only)

| Category | Distinguishing Feature | Why Excluded |
|---|---|---|
| Stored XSS | Value persisted server-side, served to other users later | No immediate reflection |
| Blind XSS | Payload stored, fires in administrative/internal context | Delayed execution, different victim model |
| Pure DOM XSS | No server reflection; client-side source to sink | No server-side component |
| Self-XSS | Only the attacker themselves can trigger execution | No realistic victim delivery path |
| Universal XSS (UXSS) | Browser or extension vulnerability | Not application-level |
| Browser-extension XSS | Extension code creates the vulnerability | Not server-application behavior |
| CRLF injection | Response header injection | Only in scope when it chains to reflected XSS in the response body |
| Open redirect | URL redirection without script execution | Only in scope when redirect parameter also reflects into HTML |
| SSTI | Server-side template code execution | Server-side execution, not browser XSS |
| Prototype pollution | Object property manipulation | Only in scope when it degrades a sanitizer protecting against reflected XSS |

---

*Next chunk: chunk-02-source-inventory-evidence-quality.md*
