# AGENT TASK: Source-to-Sink Analysis and Regression Testing
# PURPOSE: Trace data flows from input through DOMPurify to DOM sinks
# PRIORITY: Run for comprehensive code audit
# INPUTS: Application source code or ability to instrument DOM sinks
# OUTPUT: Complete source-to-sink map, dangerous flows, regression tests
# CHAPTERS: 13 (Source-to-Sink Analysis), 14 (Regression Testing)
---

# Chapter 13: DOMPurify-Focused Source-to-Sink Analysis

## 13.1 Full Flow Diagram

The complete data flow from attacker input to browser execution:

```
Attacker Input
     |
     v
[1. Source] --- URL params, form fields, WebSocket, postMessage,
                API responses, localStorage, cookies, file uploads,
                RSS/Atom feeds, database content, third-party APIs
     |
     v
[2. Transport] --- HTTP request/response, WebSocket frame,
                    postMessage event, storage event, file read
     |
     v
[3. Application Receives] --- Event handler, callback, promise resolution,
                               store mutation, template binding
     |
     v
[4. Pre-Sanitization Transforms] --- Decoding, template interpolation,
                                      Markdown conversion, string concatenation,
                                      JSON parsing, Base64 decoding
     |
     v
[5. DOMPurify.sanitize()] --- Configuration, hooks, output mode
     |                         (or MISSING -- direct sink assignment)
     v
[6. Post-Sanitization Transforms] --- Concatenation, decoding, template
                                       substitution, Markdown conversion,
                                       framework binding, re-contextualization
     |
     v
[7. HTML Sink] --- innerHTML, outerHTML, insertAdjacentHTML, document.write,
                    jQuery .html(), React dangerouslySetInnerHTML,
                    Vue v-html, Angular bypassSecurityTrustHtml,
                    Svelte {@html}, iframe.srcdoc
     |
     v
[8. Browser] --- HTML parsing, DOM construction, script execution,
                  event handler registration, resource loading
```

A source-to-sink analysis verifies that every path from step 1 to step 7 passes through step 5 with a secure configuration, and that steps 4 and 6 do not introduce or reintroduce dangerous content.

## 13.2 Source Enumeration

Every location where attacker-influenced data enters the application is a potential XSS source. The following sources are relevant to DOMPurify-based sanitization:

### 13.2.1 Direct User Input Sources

- **URL parameters**: `location.search`, `location.hash`, `URLSearchParams`, route parameters in SPA frameworks
- **Form fields**: `<input>`, `<textarea>`, `<select>` values; `FormData` objects; `contenteditable` element content
- **File uploads**: File name, content (HTML files, SVG files, Markdown files, DOCX/XLSX content), EXIF metadata

### 13.2.2 Indirect / API Sources

- **API responses**: REST/GraphQL response bodies, especially fields containing user-generated HTML content
- **WebSocket messages**: Real-time updates, chat messages, collaborative editing payloads
- **postMessage**: Cross-origin or cross-frame messages (`window.addEventListener('message', ...)`)
- **Third-party content APIs**: Social media embeds, CMS content, advertising content, RSS/Atom feed entries

### 13.2.3 Storage Sources

- **localStorage / sessionStorage**: Cached user content, draft messages, preferences containing HTML
- **Cookies**: Reflected cookie values (rare but possible in legacy applications)
- **IndexedDB**: Cached rich-text content, offline document storage
- **Database content**: Server-rendered content from database fields that store HTML

### 13.2.4 Derived Sources

- **Clipboard**: `paste` event data, `navigator.clipboard.readText()`
- **Drag and drop**: `drop` event `dataTransfer` content
- **URL fragments as state**: SPA frameworks that encode state in `location.hash`

## 13.3 Transport and Transformation Tracking

Data rarely flows directly from source to DOMPurify. It passes through transformation layers that can introduce, modify, or strip dangerous content:

### 13.3.1 Common Pre-Sanitization Transforms

- **JSON parsing**: `JSON.parse()` decodes escaped characters, potentially producing `<script>` from `<script>`
- **Base64 decoding**: `atob()` or `Buffer.from(b64, 'base64')` can produce arbitrary HTML from opaque-looking input
- **URL decoding**: `decodeURIComponent()` converts `%3Cscript%3E` to `<script>`
- **HTML entity decoding**: Server-side entity decoding before DOMPurify runs
- **Markdown to HTML conversion**: Markdown renderers produce HTML from Markdown syntax
- **Template interpolation**: Server-side template engines (EJS, Handlebars, Pug) may embed user data in HTML before DOMPurify processes it
- **String concatenation**: Building HTML strings from multiple sources before sanitization

### 13.3.2 Tracking Methodology

For each data flow path, document:

1. The source (where attacker data enters)
2. Each transformation applied (function name, library, purpose)
3. The order of transformations
4. Whether DOMPurify is called before or after each transformation
5. The DOMPurify configuration used
6. The sink where the final output is assigned

## 13.4 Sink Enumeration

### 13.4.1 Direct HTML Sinks

These sinks parse strings as HTML and insert the result into the DOM:

| Sink | Risk Level | Notes |
|------|-----------|-------|
| `element.innerHTML = ...` | Critical | Most common XSS sink |
| `element.outerHTML = ...` | Critical | Replaces element and its content |
| `element.insertAdjacentHTML(pos, html)` | Critical | Inserts parsed HTML at position |
| `document.write(html)` | Critical | Writes to document stream |
| `document.writeln(html)` | Critical | Same as write with newline |
| `DOMParser.parseFromString(html, 'text/html')` | High | Parses but does not insert (safe alone, dangerous if result is inserted) |
| `Range.createContextualFragment(html)` | Critical | Creates a DocumentFragment from HTML |

### 13.4.2 Framework-Specific Sinks

| Sink | Framework | Notes |
|------|-----------|-------|
| `dangerouslySetInnerHTML={{__html: ...}}` | React | Explicitly bypasses React's escaping |
| `v-html="..."` | Vue | Directive that sets innerHTML |
| `bypassSecurityTrustHtml(...)` | Angular | Marks content as trusted HTML |
| `{@html ...}` | Svelte | Inserts raw HTML |
| `[innerHTML]="..."` | Angular | Property binding to innerHTML |
| `.html(...)` / `.append(...)` | jQuery | Sets or appends HTML content |
| `$sce.trustAsHtml(...)` | AngularJS | Legacy trust marking |

### 13.4.3 JavaScript Execution Sinks

These sinks execute strings as JavaScript. DOMPurify does not directly protect against them because they do not accept HTML:

| Sink | Notes |
|------|-------|
| `eval(code)` | Direct code execution |
| `new Function(code)` | Creates function from string |
| `setTimeout(code, ms)` | Executes string as code (when first arg is string) |
| `setInterval(code, ms)` | Same as setTimeout |
| `script.textContent = code` | Sets script content |

### 13.4.4 URL Sinks

| Sink | Notes |
|------|-------|
| `window.location = url` | Navigation; `javascript:` URLs execute |
| `window.location.href = url` | Same |
| `window.open(url)` | Opens new window; `javascript:` executes |
| `element.href = url` | On `<a>`, navigates on click |
| `element.src = url` | On `<script>`, loads and executes |
| `iframe.srcdoc = html` | Parses as HTML in iframe context |

## 13.5 Step-by-Step Source-to-Sink Methodology

### Step 1: Identify All HTML Sinks in the Codebase

Search for every occurrence of HTML sinks using static analysis:

```
# Direct DOM sinks
grep -rn 'innerHTML\s*=' src/
grep -rn 'outerHTML\s*=' src/
grep -rn 'insertAdjacentHTML' src/
grep -rn 'document\.write' src/

# Framework sinks
grep -rn 'dangerouslySetInnerHTML' src/
grep -rn 'v-html' src/
grep -rn 'bypassSecurityTrustHtml' src/
grep -rn '{@html' src/
grep -rn '\.html(' src/

# jQuery sinks (high false positive rate)
grep -rn '\.append(' src/
grep -rn '\.prepend(' src/
grep -rn '\.after(' src/
grep -rn '\.before(' src/
```

For each sink found, record:
- File path and line number
- The expression assigned to the sink (what data flows in)
- The enclosing function or component
- Whether the sink is in client-side or server-side code

### Step 2: Trace Data Flow Backwards from Each Sink

Starting from each sink, trace the data backward through the codebase to identify its source. Follow:
- Variable assignments
- Function parameters and return values
- Promise chains and async/await flows
- Store mutations (Redux, Vuex, MobX)
- Event handlers and callbacks
- Component props and state

### Step 3: Verify DOMPurify Is Invoked on the Path

For each flow from source to sink, verify that `DOMPurify.sanitize()` is called on every code path. Check:
- Is DOMPurify called at all?
- Is it called on every branch (if/else, switch, try/catch)?
- Is it called before or after other transformations?
- Is it called on the correct variable (not a copy or derivative)?

### Step 4: Verify the DOMPurify Configuration Is Secure

For each DOMPurify invocation, examine the configuration object:

- **ALLOWED_TAGS**: Is the allowlist minimal? Are `<svg>`, `<math>`, `<style>`, `<form>`, `<template>` allowed only if needed?
- **FORBID_TAGS**: Are explicitly dangerous tags listed?
- **ADD_TAGS**: Is it a function? If so, is the predicate restrictive?
- **ALLOWED_ATTR / ADD_ATTR**: Are event handler attributes blocked? Is `style` attribute allowed unnecessarily?
- **ALLOW_DATA_ATTR**: Is it set to `false` when data attributes are not needed?
- **ALLOW_UNKNOWN_PROTOCOLS**: Is it `false` (the default)? If `true`, verify no `javascript:` URIs can survive.
- **WHOLE_DOCUMENT**: Is it `false` (the default)? `true` allows `<html>`, `<head>`, `<body>`.
- **FORCE_BODY**: Is it set appropriately for the input context?
- **RETURN_TRUSTED_TYPE**: Is it used where Trusted Types enforcement is active?
- **SAFE_FOR_TEMPLATES**: Is it enabled when sanitized output is used in a template framework?
- **IN_PLACE**: Is it `false` (the default)? If `true`, verify all IN_PLACE mode CVE mitigations are applied.
- **USE_PROFILES**: If used, verify which profile is active.
- **CUSTOM_ELEMENT_HANDLING**: Verify `tagNameCheck` and `attributeNameCheck` are restrictive.

### Step 5: Verify No Post-Sanitization Transformations Occur

Between the DOMPurify call and the sink assignment, verify that no transformations modify the sanitized output:

- No string concatenation with unsanitized content
- No HTML entity decoding (`&lt;` to `<`)
- No URL decoding (`%3C` to `<`)
- No template substitution (template literals, Handlebars, EJS)
- No Markdown conversion
- No regex replacements that modify HTML structure
- No JSON serialization/deserialization
- No Base64 encoding/decoding

### Step 6: Verify Context Matching

The context in which DOMPurify sanitizes must match the context in which the output is rendered:

- If sanitized output is assigned to `innerHTML` of a `<div>`, DOMPurify should sanitize as HTML body content (the default)
- If output is placed inside `<svg>`, DOMPurify should be aware of SVG namespace
- If output is placed inside `<textarea>`, DOMPurify should use `SAFE_FOR_XML` to prevent rawtext context breakout
- If output is used in a template framework, `SAFE_FOR_TEMPLATES` should be enabled
- If output is placed inside `<script>` (not recommended), DOMPurify cannot protect it

### Step 7: Check for Conditional Sanitization Bypass Paths

Look for patterns where sanitization is conditionally skipped:

```javascript
// VULNERABLE: Conditional sanitization
if (user.isTrusted) {
  element.innerHTML = content; // No sanitization for "trusted" users
} else {
  element.innerHTML = DOMPurify.sanitize(content);
}
```

All user-generated content must be sanitized regardless of user role or trust level. Admin-generated content should be sanitized with a potentially more permissive configuration, but never skipped entirely.

### Step 8: Verify Coverage Across All Rendering Paths

Check that sanitization covers all rendering contexts:

- Desktop web application
- Mobile web application (responsive views)
- Server-side rendering (SSR) path
- Email rendering path (if content is sent via email)
- Error/fallback rendering (error boundaries, loading states)
- Print stylesheet rendering
- Accessibility mode rendering (screen readers)
- Export/download paths (PDF, DOCX generation from sanitized content)

## 13.6 Configuration Analysis: Security Impact by Option

| Config Option | Default | Security Impact if Misconfigured |
|--------------|---------|--------------------------------|
| ALLOWED_TAGS | Full HTML allowlist | Too broad: enables CSS exfil, namespace confusion, form overlays |
| FORBID_TAGS | [] (empty) | Missing defense-in-depth for explicitly dangerous elements |
| ADD_TAGS | [] (empty) | Function form bypasses FORBID_TAGS (CVE-2026-41240) |
| ALLOWED_ATTR | Full attr allowlist | Too broad: enables style injection, DOM clobbering, form actions |
| FORBID_ATTR | [] (empty) | Missing defense-in-depth for event handlers, style |
| ADD_ATTR | [] (empty) | Function form skips URI validation (CVE-2026-65912) |
| ALLOW_DATA_ATTR | true | Framework gadgets via data-* (rails-ujs, TinyMCE) |
| ALLOW_ARIA_ATTR | true | Generally safe; minor info disclosure risk |
| ALLOW_UNKNOWN_PROTOCOLS | false | If true: javascript:, data:, vbscript: URIs survive |
| WHOLE_DOCUMENT | false | If true: html/head/body allowed, wider attack surface |
| SAFE_FOR_TEMPLATES | false | If false when needed: template injection in Vue/Angular |
| SAFE_FOR_XML | false | If false when needed: rawtext context breakout |
| IN_PLACE | false | If true: 7 known CVE classes apply |
| RETURN_DOM | false | If true with SAFE_FOR_TEMPLATES: expression bypass (CVE-2026-41239) |
| RETURN_TRUSTED_TYPE | false | If false in TT environment: violations on sink assignment |
| USE_PROFILES | not set | If set with proto pollution: Array.prototype exploitation |
| SANITIZE_DOM | true | If false: DOM clobbering attacks succeed |
| SANITIZE_NAMED_PROPS | false | If false: custom property clobbering via id/name |
| KEEP_CONTENT | true | If true: text content of removed elements is kept (information leakage) |
| FORCE_BODY | false | Context-dependent; affects parsing context selection |

## 13.7 Hook Audit

For each registered DOMPurify hook, verify:

1. **uponSanitizeElement / uponSanitizeAttribute**: Do hooks modify `data.allowedTags` or `data.allowedAttributes`? If so, are the modifications additive only (never adding `script`, event handlers, or dangerous URI attributes)? Are the modifications scoped (not affecting the global instance)?

2. **afterSanitizeElements**: Does the hook re-insert removed elements or add new elements to the DOM? Does it modify `node.innerHTML` or other properties?

3. **afterSanitizeAttributes**: Does the hook add back removed attributes? Does it use `forceKeepAttr` to retain dangerous attributes?

4. **beforeSanitizeElements / beforeSanitizeAttributes**: Do hooks modify the node before DOMPurify processes it? Do they change `nodeName`, attributes, or content?

5. **Hook isolation**: Are hooks per-instance or shared across instances? Do hooks capture references to internal state (allowlists) that persist beyond the hook's intended scope?

## 13.8 Output Type Tracing

After DOMPurify returns, trace the output through the application:

- **String output (default)**: Follow the string variable. Is it assigned directly to `innerHTML`, or does it pass through additional functions?
- **DOM output (RETURN_DOM / RETURN_DOM_FRAGMENT)**: Follow the DOM node/fragment. Is it inserted via `appendChild`, or is it serialized back to a string (defeating the purpose)?
- **TrustedHTML output (RETURN_TRUSTED_TYPE)**: Follow the TrustedHTML object. Is it converted to a string via concatenation or `.toString()`?

## 13.9 Comprehensive 20-Point Audit Checklist

| # | Check | Pass/Fail | Notes |
|---|-------|-----------|-------|
| 1 | All HTML sinks identified and documented | | |
| 2 | Every sink has a traced data flow to its source | | |
| 3 | Every data flow passes through DOMPurify | | |
| 4 | No conditional sanitization bypasses exist | | |
| 5 | DOMPurify version >= 3.4.13 (or latest stable) | | |
| 6 | ALLOWED_TAGS is minimized to needed elements | | |
| 7 | FORBID_TAGS includes defense-in-depth blocklist | | |
| 8 | No function-form ADD_TAGS/ADD_ATTR without FORBID checks | | |
| 9 | ALLOW_DATA_ATTR is false unless data-* are required | | |
| 10 | ALLOW_UNKNOWN_PROTOCOLS is false | | |
| 11 | No post-sanitization string concatenation with unsanitized content | | |
| 12 | No post-sanitization decoding (HTML entities, URL encoding) | | |
| 13 | No post-sanitization template substitution | | |
| 14 | No post-sanitization Markdown conversion | | |
| 15 | Sanitization context matches rendering context | | |
| 16 | SAFE_FOR_TEMPLATES is enabled when template frameworks process output | | |
| 17 | IN_PLACE mode is not used (or all IN_PLACE CVE mitigations applied) | | |
| 18 | Hooks do not widen allowlists or re-insert dangerous content | | |
| 19 | Trusted Types enforcement is configured with restrictive policy names | | |
| 20 | CSP script-src uses nonce or strict-dynamic as defense-in-depth | | |

## 13.10 Tooling

### 13.10.1 Browser DevTools

- **DOM breakpoints**: Set breakpoints on subtree modifications for `innerHTML` sinks to observe what data is assigned
- **Event listener breakpoints**: Break on XHR/Fetch, postMessage, and storage events to trace data sources
- **Console monitoring**: `monitorEvents(element, 'DOMSubtreeModified')` to observe DOM mutations

### 13.10.2 Burp Suite

- **Passive scanning**: Identifies reflected XSS candidates in HTTP responses
- **Active scanning**: Fuzzes input fields with XSS payloads and observes responses
- **Intruder**: Tests DOMPurify bypass payloads against sanitized endpoints
- **Match/replace rules**: Inject payloads into specific request parameters

### 13.10.3 Semgrep

Custom rules for detecting unsanitized sink assignments:

```yaml
rules:
  - id: innerHTML-without-dompurify
    patterns:
      - pattern: $EL.innerHTML = $VAL;
      - pattern-not: $EL.innerHTML = DOMPurify.sanitize(...);
    message: "innerHTML assignment without DOMPurify sanitization"
    severity: ERROR

  - id: post-sanitization-concatenation
    pattern: |
      $CLEAN = DOMPurify.sanitize($DIRTY);
      ...
      $EL.innerHTML = $PREFIX + $CLEAN + $SUFFIX;
    message: "Post-sanitization string concatenation"
    severity: WARNING
```

### 13.10.4 CodeQL

CodeQL provides taint tracking that can follow data from sources to sinks across function boundaries:

```ql
import javascript

class DOMPurifySanitizeCall extends DataFlow::CallNode {
  DOMPurifySanitizeCall() {
    this.getCalleeName() = "sanitize" and
    this.getReceiver().getAVariable().getName() = "DOMPurify"
  }
}

from DataFlow::Node source, DataFlow::Node sink
where
  source instanceof RemoteFlowSource and
  sink instanceof InnerHtmlSink and
  not exists(DOMPurifySanitizeCall call |
    DataFlow::localFlow(source, call.getArgument(0)) and
    DataFlow::localFlow(call, sink)
  )
select sink, "Unsanitized data flows to innerHTML without DOMPurify"
```

---

# Chapter 14: Safe Browser-Based Regression Testing

## 14.1 Why Browser Testing Matters

The DOMPurify project wiki explicitly warns: **jsdom is NOT sufficient for mXSS testing**. This is because:

1. **jsdom is not a browser**: jsdom implements the DOM specification but does not implement a full HTML parser with the same edge-case behaviors as Blink (Chrome), Gecko (Firefox), or WebKit (Safari). The HTML5 parsing algorithm has hundreds of edge cases in error recovery, foreign content handling, and namespace transitions. jsdom handles many but not all of these identically to real browsers.

2. **Parser differentials are browser-specific**: The entire class of mXSS attacks exploits differences between how parsers interpret the same HTML string. An mXSS payload that works in Chrome may not work in Firefox, and vice versa. Testing only in jsdom misses browser-specific parsing behaviors.

3. **The scripting flag differs**: `DOMParser` (used by DOMPurify internally) runs with the scripting flag disabled. In jsdom, the scripting flag's behavior depends on the configuration. `<noscript>` content is parsed differently depending on this flag, and this difference has been the basis for DOMPurify bypass research.

4. **Namespace handling differs**: jsdom's handling of SVG/MathML namespace transitions, foreign content integration points, and element re-contextualization may not match browser behavior exactly. These are the primary vectors for mXSS.

5. **The DOMPurify team tests in real browsers**: The DOMPurify CI/CD pipeline uses Playwright to run tests across Chrome, Firefox, and Safari. Any security research that does not match this approach risks false positives (finding bypasses that do not reproduce in real browsers) or false negatives (missing bypasses that only reproduce in specific browsers).

## 14.2 Playwright Browser Matrix

Following the DOMPurify team's approach, regression tests should run across three browser engines:

- **Chromium** (Chrome, Edge): Blink engine. Most common target. Unique behaviors include `selectedcontent` re-cloning (Chromium 148+), specific nesting depth limits, and CDATA handling in foreign content.
- **Firefox**: Gecko engine. Different parsing behaviors for MathML integration points, different error recovery strategies.
- **WebKit** (Safari): WebKit engine. Shares some behaviors with Chromium (both evolved from KHTML) but has unique edge cases in namespace handling and template content.

```javascript
// playwright.config.js
module.exports = {
  projects: [
    { name: 'chromium', use: { browserName: 'chromium' } },
    { name: 'firefox', use: { browserName: 'firefox' } },
    { name: 'webkit', use: { browserName: 'webkit' } },
  ],
};
```

## 14.3 Safe Regression Test Design Principles

### 14.3.1 Never Trigger Real XSS

Tests must never execute actual JavaScript payloads. A test that calls `alert()`, writes cookies, or navigates the page has failed in its safety design. Instead:

- **DOM inspection**: After sanitizing and assigning to `innerHTML`, inspect the resulting DOM tree for dangerous elements and attributes. Check for the presence of `onerror`, `onclick`, `onload`, `onmouseover` attributes, `<script>` elements, and `javascript:` URIs.
- **Attribute checking**: Use `element.querySelector('[onerror]')`, `element.querySelector('script')`, and similar selectors to detect surviving dangerous content.
- **Content comparison**: Compare the sanitized output string against expected safe output.

### 14.3.2 Test Sanitized Output AND Re-Parsed Output

The critical test is not whether DOMPurify's output string looks safe, but whether the browser's re-parse of that string produces a safe DOM tree:

```javascript
// Step 1: Sanitize
const sanitized = DOMPurify.sanitize(payload);

// Step 2: Assign to innerHTML (triggers browser re-parse)
testDiv.innerHTML = sanitized;

// Step 3: Inspect the re-parsed DOM tree (NOT the string)
const scripts = testDiv.querySelectorAll('script');
const eventHandlers = testDiv.querySelectorAll(
  '[onerror], [onclick], [onload], [onmouseover], [onfocus], [onblur]'
);
const jsUrls = testDiv.querySelectorAll('[href^="javascript:"], [src^="javascript:"]');

expect(scripts.length).toBe(0);
expect(eventHandlers.length).toBe(0);
expect(jsUrls.length).toBe(0);
```

This two-step approach -- sanitize then re-parse then inspect -- catches mXSS that only manifests after the browser's second parse.

### 14.3.3 Test with DOMPurify's Actual Output Path

Ensure the test uses the same output path as the application:

- If the application uses string output (default), test with string output
- If the application uses `RETURN_DOM` or `RETURN_DOM_FRAGMENT`, test with that mode
- If the application uses `RETURN_TRUSTED_TYPE`, verify TrustedHTML type before and after assignment

## 14.4 Test Categories

### 14.4.1 Namespace Confusion Tests

Test SVG and MathML namespace transitions that have historically produced mXSS:

```javascript
test('MathML namespace confusion does not produce executable markup', async ({ page }) => {
  const payloads = [
    '<form><math><mtext></form><form><mglyph><style></math><img src onerror=x>',
    '<math><mtext><table><mglyph><style><!--</style><img src onerror=x>',
    '<svg><foreignObject><div><style></div><img src onerror=x>',
    '<math><mi><table><mglyph><style><img src onerror=x>',
    '<svg><desc><table><svg><style><img src onerror=x>',
  ];

  for (const payload of payloads) {
    await page.evaluate((p) => {
      const sanitized = DOMPurify.sanitize(p);
      document.getElementById('test').innerHTML = sanitized;
      const dangerous = document.getElementById('test').querySelectorAll(
        'script, [onerror], [onclick], [onload]'
      );
      return dangerous.length;
    }, payload);

    const dangerousCount = await page.evaluate(() =>
      document.getElementById('test').querySelectorAll(
        'script, [onerror], [onclick], [onload]'
      ).length
    );
    expect(dangerousCount).toBe(0);
  }
});
```

Test integration points: `<svg foreignObject>`, `<math annotation-xml>`, `<math mtext>` combined with `<mglyph>` and `<malignmark>`.

Test `<style>` in different namespaces: In HTML namespace (content is raw text), in SVG namespace (content is parsed as markup), in MathML namespace (content is parsed as markup).

### 14.4.2 Nesting Depth Tests

Test deep nesting approaching the 512-level browser limit:

```javascript
test('deep nesting does not produce executable markup', async ({ page }) => {
  // Create nesting at various depths
  for (const depth of [255, 511, 512, 513, 600]) {
    const open = '<div>'.repeat(depth);
    const payload = open + '<img src=x onerror=alert(1)>' + '</div>'.repeat(depth);

    const dangerousCount = await page.evaluate((p) => {
      const sanitized = DOMPurify.sanitize(p);
      const el = document.createElement('div');
      el.innerHTML = sanitized;
      return el.querySelectorAll('[onerror]').length;
    }, payload);

    expect(dangerousCount).toBe(0);
  }
});
```

Test depth flattening: When the browser flattens elements beyond 512 levels, verify that flattened elements do not escape their intended context.

### 14.4.3 DOM Clobbering Tests

Test form elements that attempt to clobber DOM properties:

```javascript
test('DOM clobbering does not bypass sanitization', async ({ page }) => {
  const payloads = [
    '<form id="x"><input name="attributes"><input name="hasAttribute">',
    '<form name="getElementById"><input name="x" value="clobbered">',
    '<img name="currentScript"><form id="body">',
    '<form id="x"><input name="nodeName"><input name="nodeType">',
    '<form id="x"><input name="parentNode"><input name="childNodes">',
  ];

  for (const payload of payloads) {
    const result = await page.evaluate((p) => {
      const sanitized = DOMPurify.sanitize(p);
      const el = document.createElement('div');
      el.innerHTML = sanitized;
      // Verify prototype-chain methods still work on sanitized output
      const form = el.querySelector('form');
      if (form) {
        try {
          const attrs = Element.prototype.getAttribute.call(form, 'id');
          return { safe: true, id: attrs };
        } catch {
          return { safe: false, error: 'prototype method failed' };
        }
      }
      return { safe: true, noForm: true };
    }, payload);

    // DOMPurify should either remove clobbering elements or
    // produce output where prototype methods still function
  }
});
```

### 14.4.4 Parser Differential Tests

Test payloads that exploit differences between `DOMParser` (scripting disabled) and the live document (scripting enabled):

```javascript
test('noscript scripting flag differential does not produce XSS', async ({ page }) => {
  const payloads = [
    '<noscript><img src=x onerror=alert(1)></noscript>',
    '<noscript><div><img src=x onerror=alert(1)></div></noscript>',
    '<noscript><style></noscript><img src=x onerror=alert(1)>',
  ];

  for (const payload of payloads) {
    const dangerousCount = await page.evaluate((p) => {
      const sanitized = DOMPurify.sanitize(p);
      const el = document.createElement('div');
      el.innerHTML = sanitized;
      return el.querySelectorAll('[onerror], script').length;
    }, payload);

    expect(dangerousCount).toBe(0);
  }
});
```

Test `<noembed>` entity decoding, CDATA handling in SVG/MathML, and `<xmp>` content parsing.

### 14.4.5 Configuration Tests

For each security-relevant configuration option, test with dangerous payloads:

```javascript
const dangerousPayloads = [
  '<script>alert(1)</script>',
  '<img src=x onerror=alert(1)>',
  '<svg onload=alert(1)>',
  '<a href="javascript:alert(1)">click</a>',
  '<div style="background:url(javascript:alert(1))">',
  '<math><mtext><style><img src=x onerror=alert(1)></style></mtext></math>',
  '<form action="https://evil.com"><input type="submit">',
  '<base href="https://evil.com">',
  '<meta http-equiv="refresh" content="0;url=https://evil.com">',
];

const configs = [
  {},  // default
  { USE_PROFILES: { html: true } },
  { ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'a', 'p'] },
  { FORBID_TAGS: ['style', 'svg', 'math'] },
  { FORBID_ATTR: ['style', 'class'] },
  { ALLOW_DATA_ATTR: false },
  { SAFE_FOR_TEMPLATES: true },
  { RETURN_DOM: true },
  { RETURN_DOM_FRAGMENT: true },
];
```

### 14.4.6 Hook Interaction Tests

Test that hooks do not weaken sanitization:

```javascript
test('forceKeepAttr hook cannot retain event handlers', async ({ page }) => {
  const result = await page.evaluate(() => {
    DOMPurify.addHook('uponSanitizeAttribute', (node, data) => {
      if (data.attrName === 'onerror') {
        data.forceKeepAttr = true; // Attempt to force-keep onerror
      }
    });

    const sanitized = DOMPurify.sanitize('<img src=x onerror=alert(1)>');
    DOMPurify.removeAllHooks();

    const el = document.createElement('div');
    el.innerHTML = sanitized;
    return el.querySelector('[onerror]') !== null;
  });

  // forceKeepAttr should NOT override event handler removal
  // (DOMPurify blocks this since v2.x)
  expect(result).toBe(false);
});
```

### 14.4.7 Post-Sanitization Mutation Tests

Verify that sanitized output does not mutate on innerHTML round-trip:

```javascript
test('sanitized output is stable across innerHTML round-trips', async ({ page }) => {
  const payloads = [
    '<div><b>bold</b><i>italic</i></div>',
    '<table><tr><td>cell</td></tr></table>',
    '<ul><li>item 1</li><li>item 2</li></ul>',
    '<p>paragraph</p>',
    '<a href="https://example.com">link</a>',
  ];

  for (const payload of payloads) {
    const result = await page.evaluate((p) => {
      const sanitized = DOMPurify.sanitize(p);
      const el1 = document.createElement('div');
      el1.innerHTML = sanitized;
      const roundTrip1 = el1.innerHTML;

      const el2 = document.createElement('div');
      el2.innerHTML = roundTrip1;
      const roundTrip2 = el2.innerHTML;

      return {
        sanitized,
        roundTrip1,
        roundTrip2,
        stable: roundTrip1 === roundTrip2
      };
    }, payload);

    expect(result.stable).toBe(true);
  }
});
```

### 14.4.8 selectedcontent Tests (Browser-Version-Specific)

Test only on Chromium 148+ and WebKit 625+:

```javascript
test('selectedcontent does not bypass sanitization', async ({ page, browserName }) => {
  // selectedcontent is only relevant in Chromium 148+ and WebKit 625+
  const payload = '<select><option selected><selectedcontent><img src=x onerror=alert(1)></selectedcontent></option></select>';

  const dangerousCount = await page.evaluate((p) => {
    const sanitized = DOMPurify.sanitize(p);
    const el = document.createElement('div');
    el.innerHTML = sanitized;
    return el.querySelectorAll('[onerror], script').length;
  }, payload);

  expect(dangerousCount).toBe(0);
});
```

### 14.4.9 IN_PLACE Mode Tests

Test IN_PLACE mode with shadow roots, cross-realm nodes, and clobbered forms:

```javascript
test('IN_PLACE mode sanitizes shadow root content in template', async ({ page }) => {
  const result = await page.evaluate(() => {
    // Create a template with shadow root content
    const template = document.createElement('template');
    const div = document.createElement('div');
    template.content.appendChild(div);

    // Attach shadow root with dangerous content
    const shadow = div.attachShadow({ mode: 'open' });
    const img = document.createElement('img');
    img.setAttribute('onerror', 'alert(1)');
    shadow.appendChild(img);

    // Sanitize in place
    DOMPurify.sanitize(template, { IN_PLACE: true });

    // Check if the event handler survived
    const shadowRoot = div.shadowRoot;
    if (shadowRoot) {
      return shadowRoot.querySelector('[onerror]') !== null;
    }
    return false;
  });

  expect(result).toBe(false);
});
```

### 14.4.10 Template Expression Tests

Test `SAFE_FOR_TEMPLATES` with DOM output:

```javascript
test('SAFE_FOR_TEMPLATES strips expressions in DOM output', async ({ page }) => {
  const payloads = [
    '{{constructor.constructor("alert(1)")()}}',
    '${alert(1)}',
    '<%= alert(1) %>',
    '[% alert(1) %]',
    '<template>{{constructor.constructor("alert(1)")()}}</template>',
  ];

  for (const payload of payloads) {
    const containsExpression = await page.evaluate((p) => {
      const result = DOMPurify.sanitize(p, {
        SAFE_FOR_TEMPLATES: true,
        RETURN_DOM_FRAGMENT: true
      });

      const div = document.createElement('div');
      div.appendChild(result);
      const text = div.textContent;

      return text.includes('{{') || text.includes('${') ||
             text.includes('<%') || text.includes('[%');
    }, payload);

    expect(containsExpression).toBe(false);
  }
});
```

## 14.5 Safe Regression Test Concepts by CVE

The following are conceptual test approaches for each cataloged CVE. Each test verifies that the vulnerability is patched without executing actual XSS:

1. **CVE-2024-47875** (nesting mXSS): Deep nesting with namespace transitions; verify no event handlers after re-parse.
2. **CVE-2024-48910** (prototype pollution): Pollute `Object.prototype`, sanitize with dangerous payloads, verify handlers stripped, clean up prototype.
3. **CVE-2024-45801** (depth bypass): Extreme nesting depths with and without `__depth` pollution; verify no executable content.
4. **CVE-2020-26870** (MathML namespace): `<form><math><mtext>` nesting with `<mglyph><style>` breakout; verify no img onerror.
5. **CVE-2019-16728** (SVG closing tags): `<svg></p>` and `<math></br>` with payloads; verify in Chrome/Safari.
6. **CVE-2026-47423** (selectedcontent): `<select><option selected>` with `<selectedcontent>`; verify in Chromium 148+.
7. **CVE-2026-49978** (IN_PLACE shadow root): Template with shadow DOM; verify onerror stripped in IN_PLACE mode.
8. **CVE-2026-75838** (IN_PLACE hook detach): Register removal hook; verify descendant handlers neutralized.
9. **CVE-2026-41240** (FORBID_TAGS bypass): Function-form ADD_TAGS with FORBID_TAGS; verify forbidden tags removed.
10. **CVE-2026-65898** (setConfig pollution): setConfig with added attribute; verify reset removes it.

Each test follows the same pattern: construct the vulnerable scenario, run DOMPurify, inspect the DOM tree for surviving dangerous content, assert no dangerous elements or attributes exist.

## 14.6 Test Infrastructure

### 14.6.1 Playwright Test Setup

```javascript
// test/xss-regression.spec.js
const { test, expect } = require('@playwright/test');

test.beforeEach(async ({ page }) => {
  // Load a minimal page with DOMPurify
  await page.setContent(`
    <!DOCTYPE html>
    <html>
    <head>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.4.16/purify.min.js"></script>
    </head>
    <body>
      <div id="test"></div>
    </body>
    </html>
  `);

  // Wait for DOMPurify to load
  await page.waitForFunction(() => typeof DOMPurify !== 'undefined');
});
```

### 14.6.2 CI Integration

Run tests across all three browser engines on every PR and on a nightly schedule with the latest DOMPurify release:

```yaml
# .github/workflows/xss-regression.yml
name: XSS Regression Tests
on:
  pull_request:
  schedule:
    - cron: '0 6 * * *'  # Daily at 6am UTC
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        browser: [chromium, firefox, webkit]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm ci
      - run: npx playwright install --with-deps ${{ matrix.browser }}
      - run: npx playwright test --project=${{ matrix.browser }}
```

### 14.6.3 Version Matrix Testing

Test across multiple DOMPurify versions to verify backward compatibility and regression:

```javascript
const versions = ['3.4.16', '3.4.13', '3.4.0', '3.3.2', '3.2.4'];
for (const version of versions) {
  test.describe(`DOMPurify ${version}`, () => {
    test.beforeEach(async ({ page }) => {
      await page.setContent(`
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dompurify/${version}/purify.min.js"></script>
        <div id="test"></div>
      `);
    });
    // ... regression tests
  });
}
```

## 14.7 Reporting

### 14.7.1 Documenting Findings

For each finding, document:

1. **Payload**: The exact HTML input that triggers the issue
2. **DOMPurify version**: Version tested
3. **DOMPurify configuration**: Exact config object used
4. **Browser(s)**: Which browser(s) reproduce the issue
5. **Sanitized output**: The string returned by DOMPurify
6. **Re-parsed DOM**: The DOM tree produced by `innerHTML` assignment
7. **Dangerous elements/attributes**: What survived sanitization
8. **Exploitability**: Whether the surviving content is actually executable
9. **Impact**: What an attacker could achieve

### 14.7.2 False Positive Analysis

Before reporting a finding, verify it is not a false positive (see Chapter 15). Key checks:

- Does the payload actually execute in the target browser, or does the event handler exist but never fire?
- Is the finding specific to the application's DOMPurify version and configuration?
- Does the finding reproduce after the browser's re-parse, or only in the sanitized string?
- Is the finding blocked by CSP, Trusted Types, or other defense-in-depth layers?

---
