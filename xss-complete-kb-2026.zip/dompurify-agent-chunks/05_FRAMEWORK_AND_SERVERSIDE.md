# AGENT TASK: Framework Integration and Server-Side Exploitation
# PURPOSE: Test React/Vue/Angular/jQuery bypasses, server-side parser differentials
# PRIORITY: Run FIFTH - framework issues are extremely common
# INPUTS: Target framework, server-side rendering detection
# OUTPUT: Framework-specific bypasses, server-side differential findings
# CHAPTERS: 9 (Framework Integration), 10 (Server-Side DOMPurify)
---

# Chapter 9: DOMPurify Framework Integration Defects

### 9.1 React / Next.js

#### 9.1.1 dangerouslySetInnerHTML

React's `dangerouslySetInnerHTML` is the only built-in mechanism for rendering raw HTML in React components. It is therefore the primary HTML injection sink in React applications:

```jsx
// Standard DOMPurify integration with React
function SafeHTML({ html }) {
  return <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(html) }} />;
}

// VULNERABLE: Missing sanitization
function UnsafeHTML({ html }) {
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
}
```

#### 9.1.2 Props Injection via Object Spread

When React components use object spread to pass props, an attacker who controls the spread source can inject `dangerouslySetInnerHTML`:

```jsx
// VULNERABLE: Object spread with attacker-controlled props
function Widget(props) {
  return <div className="widget" {...props} />;
}

// Attack: if props comes from user input
const attackerProps = {
  dangerouslySetInnerHTML: {
    __html: '<img src=x onerror=alert(1)>'
  }
};
<Widget {...attackerProps} />
// The spread injects dangerouslySetInnerHTML, bypassing any sanitization
```

This pattern is particularly dangerous because:
- The `Widget` component appears to be safe (no explicit `dangerouslySetInnerHTML`)
- Code review may not catch the injection through the spread
- TypeScript types may not restrict the props adequately

#### 9.1.3 SSR/Hydration Mismatch

When React server-side renders with DOMPurify and the client hydrates:

```jsx
// Server (Node.js with isomorphic-dompurify):
function ServerComponent({ userHtml }) {
  const clean = DOMPurify.sanitize(userHtml);
  return <div dangerouslySetInnerHTML={{ __html: clean }} />;
}

// The server uses jsdom's parser (via isomorphic-dompurify)
// The client browser re-parses during hydration
// If jsdom and the browser parse differently, the hydrated DOM
// may differ from what DOMPurify validated
```

#### 9.1.4 getServerSideProps XSS

In Next.js, data returned from `getServerSideProps` is serialized to JSON and embedded in the page. If user-controlled data is not properly escaped:

```jsx
// VULNERABLE: getServerSideProps returning unsanitized data
export async function getServerSideProps(context) {
  const userInput = context.query.q;
  return { props: { query: userInput } };
  // userInput is embedded in the page's __NEXT_DATA__ JSON
  // If it contains </script>, it breaks out of the script context
}

// While this is not directly a DOMPurify issue, developers may
// assume that applying DOMPurify on the client component is sufficient,
// not realizing the XSS occurs during SSR serialization
```

### 9.2 Vue / Nuxt

#### 9.2.1 v-html Directive

Vue's `v-html` directive renders raw HTML and is the primary injection sink:

```vue
<!-- Standard DOMPurify integration -->
<template>
  <div v-html="sanitizedContent"></div>
</template>

<script>
import DOMPurify from 'dompurify';
export default {
  props: ['content'],
  computed: {
    sanitizedContent() {
      return DOMPurify.sanitize(this.content);
    }
  }
};
</script>
```

```vue
<!-- VULNERABLE: Direct v-html without sanitization -->
<template>
  <div v-html="content"></div>
</template>
```

#### 9.2.2 CVE-2024-22075 -- Firefly III

Firefly III (a financial management application) had a vulnerability where client-side path traversal allowed an attacker to inject arbitrary content into a `v-html` directive:

- User-controlled data was included in a URL path
- The application fetched content based on the path
- The response was rendered via `v-html` without sanitization
- Even if the backend sanitized, the client-side path traversal bypassed server-side controls

#### 9.2.3 Vue 2 Template Compilation

Vue 2's template compilation compiles templates to render functions. When `SAFE_FOR_TEMPLATES` is used but the template engine processes the sanitized output:

```javascript
// Vue 2 template compilation with SAFE_FOR_TEMPLATES
const sanitized = DOMPurify.sanitize(input, { SAFE_FOR_TEMPLATES: true });
// SAFE_FOR_TEMPLATES strips {{ and }}
// But Vue 2 also supports v-bind shorthand (:) and v-on shorthand (@)
// These are not stripped by SAFE_FOR_TEMPLATES
// <div :innerHTML="attackerControlled"> could still execute
```

#### 9.2.4 SSR v-html Handling

In Nuxt/Vue SSR, `v-html` content is rendered server-side and hydrated on the client. The same parser differential risks apply as with React SSR.

### 9.3 Angular

#### 9.3.1 bypassSecurityTrustHtml

Angular has a built-in sanitizer (`DomSanitizer`) that sanitizes HTML by default. When developers use DOMPurify instead, they typically bypass Angular's sanitizer:

```typescript
// COMMON PATTERN: DOMPurify replacing Angular's sanitizer
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import DOMPurify from 'dompurify';

@Pipe({ name: 'safeHtml' })
export class SafeHtmlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string): SafeHtml {
    const sanitized = DOMPurify.sanitize(value);
    // bypassSecurityTrustHtml tells Angular to trust this HTML
    // This DISABLES Angular's built-in sanitizer for this content
    return this.sanitizer.bypassSecurityTrustHtml(sanitized);
  }
}
```

The risk is that `bypassSecurityTrustHtml` completely disables Angular's defense-in-depth sanitizer. If DOMPurify has a bypass, there is no fallback.

#### 9.3.2 ElementRef.nativeElement.innerHTML

Direct DOM manipulation in Angular bypasses both Angular's sanitizer and any DOMPurify integration:

```typescript
// VULNERABLE: Direct DOM access
import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-content',
  template: '<div #content></div>'
})
export class ContentComponent {
  @ViewChild('content') contentEl: ElementRef;

  setContent(html: string) {
    // Bypasses Angular's sanitizer entirely
    this.contentEl.nativeElement.innerHTML = html;
    // If html is not sanitized with DOMPurify, this is XSS
  }
}
```

### 9.4 Svelte / SvelteKit

#### 9.4.1 {@html} Directive

Svelte's `{@html}` directive renders raw HTML with no built-in sanitization:

```svelte
<!-- VULNERABLE: No sanitization -->
<div>{@html userContent}</div>

<!-- FIXED: With DOMPurify -->
<script>
  import DOMPurify from 'dompurify';
  export let userContent;
  $: safeContent = DOMPurify.sanitize(userContent);
</script>
<div>{@html safeContent}</div>
```

Unlike React and Angular, Svelte provides no built-in sanitization for raw HTML rendering. The `{@html}` directive is completely unsanitized, making DOMPurify integration essential.

#### 9.4.2 Server-Side Rendering Differences

SvelteKit's SSR uses a different rendering path than client-side rendering. If DOMPurify is used only on the client:

```svelte
<script>
  import { browser } from '$app/environment';
  import DOMPurify from 'dompurify';

  export let html;

  // VULNERABLE: Only sanitizes on client
  $: safe = browser ? DOMPurify.sanitize(html) : html;
</script>
<div>{@html safe}</div>
<!-- Server-side renders unsanitized HTML -->
```

### 9.5 jQuery

#### 9.5.1 .html() Method

jQuery's `.html()` method sets innerHTML on matched elements. It also performs internal processing that can alter the HTML before insertion:

**CVE-2020-11022**: jQuery rewrites self-closing tags in `.html()` calls. The tag `<div/>text` is rewritten to `<div>text</div>`, changing containment. Combined with DOMPurify output, this rewriting can change the parser's interpretation.

```javascript
// jQuery .html() with DOMPurify
$('#target').html(DOMPurify.sanitize(userInput));

// jQuery internally rewrites self-closing tags:
// <option><style></option></select><img src=x onerror=alert(1)>
// jQuery's regex-based tag processing may alter the structure
```

**ALLOW_SELF_CLOSE_IN_ATTR interaction**: DOMPurify's `ALLOW_SELF_CLOSE_IN_ATTR` option, combined with jQuery's tag rewriting, can create unexpected parsing results.

#### 9.5.2 .append() with User Input

```javascript
// VULNERABLE: .append() with user-controlled input
$('#container').append(userInput);
// jQuery creates elements from strings, executing scripts in some versions
```

### 9.6 Markdown Renderers

The critical rule for DOMPurify with Markdown renderers: **sanitize AFTER conversion, not before**.

```javascript
// WRONG: Sanitize Markdown source, then convert
const cleanMd = DOMPurify.sanitize(markdownInput);
const html = marked.parse(cleanMd);
// Problem: DOMPurify strips HTML tags from Markdown source
// But the Markdown renderer creates new HTML tags from Markdown syntax
// These new tags are never sanitized

// CORRECT: Convert Markdown to HTML, then sanitize
const html = marked.parse(markdownInput);
const cleanHtml = DOMPurify.sanitize(html);
```

#### 9.6.1 Integration Patterns by Renderer

**marked.js**:
```javascript
import { marked } from 'marked';
import DOMPurify from 'dompurify';

// CORRECT: sanitize the rendered HTML
const html = DOMPurify.sanitize(marked.parse(userMarkdown));
```

**markdown-it**:
```javascript
import MarkdownIt from 'markdown-it';
import DOMPurify from 'dompurify';

const md = new MarkdownIt({
  html: true, // Enable HTML in Markdown (common requirement)
});

// CORRECT: sanitize after rendering
const html = DOMPurify.sanitize(md.render(userMarkdown));
// Note: if html:true, raw HTML blocks in Markdown pass through
// DOMPurify must catch these
```

**remark/rehype**:
```javascript
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remarkRehype from 'remark-rehype';
import rehypeSanitize from 'rehype-sanitize';
import rehypeStringify from 'rehype-stringify';

// rehype-sanitize provides AST-level sanitization
// This avoids the serialize/reparse cycle entirely
const result = await unified()
  .use(remarkParse)
  .use(remarkRehype, { allowDangerousHtml: true })
  .use(rehypeSanitize) // Sanitizes the AST, not an HTML string
  .use(rehypeStringify)
  .process(userMarkdown);
```

**showdown**:
```javascript
import showdown from 'showdown';
import DOMPurify from 'dompurify';

const converter = new showdown.Converter();
const html = DOMPurify.sanitize(converter.makeHtml(userMarkdown));
```

### 9.7 Rich-Text Editors

#### 9.7.1 TipTap / ProseMirror

TipTap (built on ProseMirror) uses a schema-based approach to content validation. The schema defines allowed elements and attributes at the document model level:

```javascript
// TipTap schema-based approach
import { Editor } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';

const editor = new Editor({
  extensions: [StarterKit],
  content: userContent, // Schema validates structure
});

// Risk: paste handler bypasses
// When users paste HTML, TipTap processes it through parse rules
// Custom parse rules may not sanitize all attributes
// Paste handler is a separate code path from normal content insertion
```

Paste handler risks:
- Custom `clipboardTextParser` may not sanitize
- `transformPastedHTML` can introduce unsanitized content
- ProseMirror marks can carry attributes through the schema

#### 9.7.2 Quill

Quill uses the Delta format internally but provides `dangerouslyPasteHTML` for inserting raw HTML:

```javascript
import Quill from 'quill';

const quill = new Quill('#editor');

// DANGEROUS: Bypasses Quill's Delta-based safety
quill.clipboard.dangerouslyPasteHTML('<img src=x onerror=alert(1)>');
// The name says "dangerously" -- it means it

// Safe approach:
quill.clipboard.dangerouslyPasteHTML(DOMPurify.sanitize(html));
```

#### 9.7.3 CKEditor

CKEditor's General HTML Support (GHS) feature allows preserving arbitrary HTML attributes that the editor does not normally recognize:

```javascript
// CKEditor GHS preserves attributes DOMPurify might remove
ClassicEditor.create(element, {
  htmlSupport: {
    allow: [
      {
        name: /.*/,
        attributes: true, // Allow ALL attributes on ALL elements
        styles: true,
        classes: true,
      },
    ],
  },
});
// GHS will preserve event handler attributes that DOMPurify removed
// if the content is processed by GHS after sanitization
```

**Issue #4847**: CKEditor's paste processing could re-introduce attributes that DOMPurify had removed, because the paste processing pipeline ran independently of DOMPurify's output.

#### 9.7.4 TinyMCE

**CVE-2026-47759 (data-mce-* attribute bypass)**: TinyMCE uses `data-mce-*` attributes internally for tracking editor state. These attributes could contain dangerous values that TinyMCE later expanded:

```javascript
// TinyMCE data-mce-* bypass
// DOMPurify allows data-* attributes by default
// TinyMCE interprets data-mce-href as the "real" href value
// <a data-mce-href="javascript:alert(1)" href="safe">click</a>
// DOMPurify: allows data-mce-href (it's a data attribute)
// TinyMCE: uses data-mce-href as the actual link target
```

**CVE-2023-48219 (BOM removal)**: TinyMCE's content processing removed BOM characters (U+FEFF) from content. If DOMPurify's output relied on BOM characters as parsing barriers (within element names or attribute values), their removal reconstructed dangerous content.

**xss_sanitization config**: TinyMCE has its own `xss_sanitization` configuration option that controls whether TinyMCE applies its own sanitization. When set to `false`, TinyMCE relies entirely on external sanitization (DOMPurify), but some code paths may not honor this setting.

#### 9.7.5 Slate

Slate uses a custom data model (not DOM-based) and requires custom serializers/deserializers:

```javascript
// Slate serialization risk
import { serialize } from './custom-serializer';
import { deserialize } from './custom-deserializer';

// Custom deserializer converts HTML to Slate nodes
// If the deserializer does not sanitize, XSS is possible
const nodes = deserialize(htmlInput);

// Custom serializer converts Slate nodes back to HTML
// If the serializer does not sanitize, XSS is possible
const html = serialize(editor.children);
element.innerHTML = html; // Unsanitized!
```

### 9.8 Framework-Specific SAST Rules

Semgrep patterns for detecting DOMPurify integration issues in each framework:

```yaml
# React: dangerouslySetInnerHTML without DOMPurify
rules:
  - id: react-dangerously-set-inner-html-no-sanitize
    patterns:
      - pattern: |
          <$EL dangerouslySetInnerHTML={{__html: $VAL}} />
      - pattern-not: |
          <$EL dangerouslySetInnerHTML={{__html: DOMPurify.sanitize(...)}} />
    message: "dangerouslySetInnerHTML without DOMPurify sanitization"
    severity: ERROR
    languages: [typescript, javascript]

  # React: props spread injection
  - id: react-props-spread-injection
    pattern: |
      <$EL {...$PROPS} />
    message: "Object spread on JSX element may inject dangerouslySetInnerHTML"
    severity: WARNING
    languages: [typescript, javascript]

# Vue: v-html without sanitization
  - id: vue-v-html-no-sanitize
    pattern: |
      <$EL v-html="$VAR" />
    message: "v-html may render unsanitized content"
    severity: WARNING
    languages: [html]

# Angular: bypassSecurityTrustHtml
  - id: angular-bypass-security-trust-html
    pattern: |
      this.sanitizer.bypassSecurityTrustHtml($VAL)
    message: "bypassSecurityTrustHtml disables Angular's sanitizer"
    severity: WARNING
    languages: [typescript]

# Svelte: {@html} without DOMPurify
  - id: svelte-html-tag-no-sanitize
    pattern: |
      {@html $VAR}
    message: "{@html} renders unsanitized HTML"
    severity: WARNING
    languages: [html]

# jQuery: .html() with user input
  - id: jquery-html-no-sanitize
    patterns:
      - pattern: |
          $($SEL).html($VAL)
      - pattern-not: |
          $($SEL).html(DOMPurify.sanitize(...))
    message: "jQuery .html() without DOMPurify sanitization"
    severity: ERROR
    languages: [javascript]

# Markdown: sanitize before conversion (wrong order)
  - id: markdown-sanitize-before-convert
    pattern: |
      $MD.parse(DOMPurify.sanitize($INPUT))
    message: "Sanitization before Markdown conversion is ineffective"
    severity: ERROR
    languages: [javascript, typescript]
```

### 9.9 Integration Testing Strategies

1. **Sink coverage testing**: Enumerate all HTML injection sinks in the application (innerHTML, v-html, dangerouslySetInnerHTML, {@html}, .html(), etc.) and verify that every path to each sink passes through DOMPurify.

2. **Framework-specific payload testing**: Use payloads tailored to each framework's sink behavior. Test self-closing tag handling for jQuery, template expression injection for Vue/Angular, and props spread injection for React.

3. **SSR/hydration differential testing**: Render content server-side, capture the HTML, and compare the browser-parsed DOM against the expected structure. Flag any differences as potential mXSS vectors.

4. **Editor paste testing**: Test paste handlers for each rich-text editor by pasting HTML payloads via the clipboard API and verifying that the editor's output is sanitized.

5. **Configuration drift testing**: Verify that DOMPurify configuration is consistent across all usage sites. Configuration differences between components can create gaps.

6. **Upgrade regression testing**: When upgrading DOMPurify, the framework, or the rich-text editor, re-run all sanitization tests to catch regressions caused by behavior changes in any component.

---

# Chapter 10: Server-Side DOMPurify and DOM Implementation Risks

### 10.1 jsdom (isomorphic-dompurify)

`isomorphic-dompurify` is the most common package for server-side DOMPurify usage. It wraps DOMPurify with jsdom to provide a DOM implementation in Node.js.

#### 10.1.1 parse5 HTML Parser

jsdom uses the `parse5` library as its HTML parser. parse5 is a specification-compliant HTML5 parser, but it differs from browser parsers in several important ways:

**Scripting flag**: jsdom creates documents with the scripting flag disabled by default (matching DOMParser behavior). This means `<noscript>` content is parsed as HTML elements, not raw text. When the sanitized output is rendered in a browser (scripting enabled), noscript content is treated as raw text, creating a parser differential.

```javascript
// Server-side (jsdom, scripting disabled):
// <noscript><img src=x onerror=alert(1)></noscript>
// parse5 parses: noscript contains child element <img> with onerror
// DOMPurify sees and removes the onerror handler

// Client-side (browser, scripting enabled):
// <noscript>...</noscript> content is raw text
// The img and onerror are treated as text, not elements
// In this specific case, the differential is "safe" (browser ignores the content)
// But the reverse is dangerous: content that is text in jsdom but HTML in browser
```

**No nesting depth limits**: parse5 does not implement browser-specific nesting depth limits. Content that triggers Chrome's 512-depth flattening is parsed without flattening in parse5, meaning the server-side sanitizer sees a different tree structure than the browser.

```javascript
// Server-side (jsdom/parse5): 600-deep nesting is preserved
// DOMPurify sees <style> deeply nested within 600 <div>s
// Content appears safely contained

// Client-side (Chrome): nesting flattened at depth 512
// <style> becomes a sibling, changing containment
// Content that was "inside" the nesting is now exposed at a different level
```

**Entity decoding differences**: parse5 and browser parsers may handle edge cases in character reference decoding differently, particularly for numeric character references, incomplete character references, and character references in attribute values.

**DOM clobbering differences**: jsdom's DOM implementation may handle named access on the Window and Document objects differently from browser DOMs, affecting DOM clobbering attack vectors.

**Namespace handling**: parse5's handling of SVG and MathML namespaces, while specification-compliant, may differ from browser implementations in edge cases involving error recovery within foreign content.

**No CSS engine**: jsdom does not have a CSS engine (or has a limited one). DOMPurify configurations that depend on CSS parsing behavior (such as sanitizing CSS in style elements) may produce different results.

#### 10.1.2 DOMPurify Wiki Warning

The DOMPurify wiki explicitly warns about server-side usage:

> "Using DOMPurify on the server is not the same as using it in the browser. The server-side DOM implementation may parse HTML differently, leading to parser differential vulnerabilities. Server-side sanitization should be treated as defense-in-depth, not as the primary security boundary."

### 10.2 linkedom

`linkedom` provides a lightweight DOM implementation for Node.js with its own HTML parser:

- **Own parser**: linkedom uses a custom HTML parser that is simpler and faster than parse5 but may not handle all HTML5 edge cases correctly
- **Incomplete namespace support**: SVG and MathML namespace handling may be incomplete, causing namespace-dependent attacks to produce different results
- **Less tested with DOMPurify**: linkedom has seen less security scrutiny in combination with DOMPurify compared to jsdom

```javascript
import { parseHTML } from 'linkedom';
import createDOMPurify from 'dompurify';

const { window } = parseHTML('<!DOCTYPE html><html><body></body></html>');
const DOMPurify = createDOMPurify(window);

// DOMPurify uses linkedom's DOM implementation
// Parser differences from browsers create differential risk
const clean = DOMPurify.sanitize(userInput);
```

### 10.3 happy-dom

`happy-dom` is another DOM implementation for Node.js, used primarily with testing frameworks:

**CVE-2024-51757**: happy-dom had a vulnerability where its HTML parser handled certain constructs differently from the specification, allowing content to bypass sanitization when DOMPurify was used with happy-dom's DOM.

**Foreign content/error recovery differences**: happy-dom's parser may handle error recovery within SVG and MathML foreign content differently from both browser parsers and parse5, creating unique parser differentials.

```javascript
import { Window } from 'happy-dom';
import createDOMPurify from 'dompurify';

const window = new Window();
const DOMPurify = createDOMPurify(window);

// happy-dom's parser may differ from browsers
// Particularly in error recovery and foreign content handling
```

### 10.4 General Server-Side Risks

#### 10.4.1 Parser Differential Risk

Any server-side DOM implementation introduces parser differential risk. The fundamental problem is:

1. Server sanitizes HTML using DOM implementation A's parser
2. Client renders HTML using DOM implementation B's parser (browser)
3. If A and B parse the same HTML string differently, the sanitizer's view of the content may not match what the browser renders

No server-side DOM implementation perfectly matches all browser parsers in all edge cases. The HTML5 specification is ambiguous or under-specified in certain error recovery scenarios, and browser implementations have accumulated behavioral differences over decades.

#### 10.4.2 Cannot Use RETURN_DOM_FRAGMENT

In server-side contexts, the sanitized content must be transmitted to the client as an HTML string. This means `RETURN_DOM_FRAGMENT: true` cannot be used, because:

1. The fragment cannot be serialized for HTTP transmission without going through `innerHTML` (serialize/reparse cycle)
2. The server must produce an HTML string that the client will parse
3. This reintroduces the exact serialize/reparse vulnerability that `RETURN_DOM_FRAGMENT` is designed to avoid

#### 10.4.3 Browser Version Variations

Even with browser-side sanitization, different browser versions may parse the sanitized output differently. Server-side sanitization is particularly vulnerable because:

- The server cannot know which browser version the client uses
- Parser behavior changes between browser versions
- Content sanitized on the server may be rendered months or years later on browsers that did not exist when the content was sanitized

### 10.5 Server/Browser Parsing Differences

#### 10.5.1 Scripting Context (noscript)

The scripting flag is the most impactful difference between server-side and browser-side parsing:

```
Server (jsdom/parse5, scripting disabled):
  <noscript><p>Fallback content</p></noscript>
  -> noscript contains element <p> with text "Fallback content"

Browser (scripting enabled):
  <noscript><p>Fallback content</p></noscript>
  -> noscript contains text "<p>Fallback content</p>"
  -> Text is displayed only when scripting is disabled
```

#### 10.5.2 Error Recovery

HTML5 specifies error recovery procedures, but implementations may differ in:
- Handling of deeply nested elements (depth limits)
- Recovery from malformed attributes
- Treatment of unexpected closing tags in foreign content
- Behavior with incomplete character references
- Processing of invalid element names

#### 10.5.3 Encoding

Character encoding detection and handling may differ:
- Server-side parsers typically receive content as UTF-8 strings
- Browsers may detect encoding from HTTP headers, BOM, or meta tags
- Encoding mismatches can cause different byte sequences to produce different character sequences

#### 10.5.4 Quirks Mode

Document mode (quirks, limited-quirks, no-quirks) affects some parsing behavior. Server-side DOMs may not implement quirks mode differences, leading to parsing differentials for content that triggers different document modes.

### 10.6 Shared DOM Instances

In server-side applications, DOMPurify instances may be shared across requests, creating state leakage:

```javascript
// VULNERABLE: Express middleware sharing DOMPurify instance
import express from 'express';
import createDOMPurify from 'dompurify';
import { JSDOM } from 'jsdom';

const app = express();
const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

app.post('/comment', (req, res) => {
  // Registering hooks per-request pollutes shared instance
  if (req.body.allowImages) {
    DOMPurify.addHook('uponSanitizeElement', (node, data) => {
      if (data.tagName === 'img') {
        data.allowedTags['img'] = true; // Pollutes shared state!
      }
    });
  }

  const clean = DOMPurify.sanitize(req.body.content);
  res.json({ content: clean });

  // Even with removeAllHooks, the allowedTags pollution persists
  DOMPurify.removeAllHooks();
});

// After a request with allowImages=true,
// ALL subsequent requests allow <img> tags
// This persists until the process is restarted
```

The fix is to create per-request DOMPurify instances:

```javascript
// FIXED: Per-request DOMPurify instance
app.post('/comment', (req, res) => {
  const window = new JSDOM('').window;
  const DOMPurify = createDOMPurify(window);
  // Instance-specific hooks and configuration
  // Garbage collected after request completes
  const clean = DOMPurify.sanitize(req.body.content);
  res.json({ content: clean });
});
// Note: creating a JSDOM instance per request has performance implications
// Consider pooling or caching strategies with proper isolation
```

### 10.7 Different Policies Server vs. Client

When server and client use different DOMPurify configurations, content that passes server-side sanitization may be dangerous in the client context:

```javascript
// Server configuration (permissive for email rendering)
const serverConfig = {
  ALLOWED_TAGS: ['div', 'span', 'p', 'a', 'img', 'table', 'tr', 'td', 'th',
                 'style', 'link', 'font', 'b', 'i', 'u'],
  ALLOWED_ATTR: ['href', 'src', 'style', 'class', 'color', 'bgcolor'],
};

// Client configuration (restrictive for web display)
const clientConfig = {
  ALLOWED_TAGS: ['div', 'span', 'p', 'a', 'b', 'i'],
  ALLOWED_ATTR: ['href', 'class'],
};

// Content sanitized with serverConfig passes <style> and <img>
// If the client does not re-sanitize, these elements are rendered
// <style> can contain CSS-based exfiltration
// <img> can trigger requests to attacker-controlled servers
```

### 10.8 HTML Serialization Differences

Server-side DOMs serialize HTML differently from browser DOMs:

```javascript
// jsdom serialization vs browser serialization
const dom = new JSDOM('<div><br></div>');
console.log(dom.window.document.body.innerHTML);
// jsdom may serialize as: <div><br></div>
// Browser may serialize as: <div><br></div> (same in this case)

// But for edge cases:
const dom2 = new JSDOM('<div attr=value>');
console.log(dom2.window.document.body.innerHTML);
// Attribute quoting, entity encoding, namespace prefixes, and
// void element serialization may differ between implementations

// SVG serialization differences are particularly notable:
// jsdom may use XMLSerializer for SVG content
// Browsers may use HTML serialization rules for inline SVG
```

### 10.9 SSR-to-Hydration Pipeline Risks

The complete SSR-to-hydration pipeline with DOMPurify:

```
1. User input arrives at server
2. Server sanitizes with DOMPurify + jsdom (parse5 parser, scripting disabled)
3. Server serializes sanitized DOM to HTML string
4. HTML string sent to client in HTTP response
5. Client browser parses HTML string (browser parser, scripting enabled)
6. Framework hydrates: attaches event listeners, binds data
7. If parsed DOM differs from server's expectation, hydration mismatch
```

The specific risk points:

```javascript
// Server (Next.js with isomorphic-dompurify)
export async function getServerSideProps(context) {
  const userContent = await fetchUserContent(context.params.id);
  const clean = DOMPurify.sanitize(userContent);
  // jsdom/parse5 parser used for sanitization
  return { props: { content: clean } };
}

// Client component
function Page({ content }) {
  // Browser re-parses 'content' via dangerouslySetInnerHTML
  // Browser parser may interpret 'content' differently than jsdom
  return <div dangerouslySetInnerHTML={{ __html: content }} />;
}
```

**noscript content reinterpretation**: Content within `<noscript>` that was parsed as HTML elements by jsdom (scripting disabled) is re-parsed as raw text by the browser (scripting enabled). If the sanitizer removed dangerous elements within noscript but the browser sees different content in noscript's raw text, the sanitization may be ineffective.

### 10.10 Old Persisted Content Under New Policies

Content stored in databases after sanitization with one version of DOMPurify may be rendered under different rules:

```
Scenario 1: DOMPurify 2.x -> 3.x
- Content sanitized with DOMPurify 2.x may contain elements/attributes
  that 3.x considers dangerous (tighter defaults)
- But the content was already sanitized and stored -- it is not re-sanitized
- The stored content may contain <svg> elements that 2.x allowed but 3.x
  would have handled differently

Scenario 2: DOMPurify 3.x -> 2.x rollback
- Content sanitized with 3.x may rely on 3.x's tighter parsing
- If the application rolls back to 2.x, the rendering pipeline changes
- Content that was safe under 3.x's behavior may be unsafe under 2.x

Scenario 3: Configuration changes
- Content sanitized under one ALLOWED_TAGS set is stored
- The ALLOWED_TAGS configuration changes (more restrictive)
- Stored content still contains tags that the new config would block
- If content is served without re-sanitization, the old tags are rendered
```

Mitigation approaches:
1. Always re-sanitize when rendering, not just when storing
2. Store both raw and sanitized versions; re-sanitize the raw version on render
3. When updating DOMPurify or changing configuration, run a migration to re-sanitize stored content

### 10.11 Recommendation: Client-Side Sanitization Preferred

The recommended architecture for DOMPurify deployment:

1. **Primary defense: Client-side sanitization**
   - DOMPurify runs in the browser where the content will be rendered
   - Eliminates parser differential risk (same parser for sanitization and rendering)
   - Enables `RETURN_DOM_FRAGMENT` to avoid serialize/reparse cycles
   - Browser's parser behavior is the ground truth

2. **Defense-in-depth: Server-side sanitization**
   - Server-side DOMPurify (with jsdom) provides an additional layer
   - Catches obvious attacks before they reach the client
   - Provides protection for non-JavaScript clients
   - But should NOT be the sole defense due to parser differential risk

3. **Client-side re-sanitization after server-side sanitization**
   - Content sanitized on the server should be re-sanitized on the client before rendering
   - The client sanitization is the authoritative security boundary
   - The server sanitization reduces the attack surface

```javascript
// Recommended: dual sanitization
// Server-side (defense-in-depth)
const serverClean = DOMPurify.sanitize(userInput); // jsdom
storeInDatabase(serverClean);

// Client-side (primary defense)
const content = await fetchFromDatabase();
const clientClean = DOMPurify.sanitize(content); // Browser
element.innerHTML = clientClean;
// Or better:
const fragment = DOMPurify.sanitize(content, { RETURN_DOM_FRAGMENT: true });
element.replaceChildren(fragment);
```

### 10.12 Playwright Browser Matrix Testing

The DOMPurify team uses Playwright for cross-browser testing of sanitization behavior. This approach tests DOMPurify's output against multiple real browser engines:

```javascript
// Playwright browser matrix testing approach
import { test, expect } from '@playwright/test';

const browsers = ['chromium', 'firefox', 'webkit'];
const testCases = [
  {
    name: 'SVG namespace breakout',
    input: '<svg><style><img src=x onerror=alert(1)></style></svg>',
    expected: { safe: true, noScript: true },
  },
  {
    name: 'noscript scripting flag',
    input: '<noscript><img src=x onerror=alert(1)></noscript>',
    expected: { safe: true, noScript: true },
  },
  {
    name: 'depth limit flattening',
    input: generateDeepNesting(600) + '<style>/*...*/</style>' + closeDeepNesting(600),
    expected: { safe: true, noScript: true },
  },
];

for (const browserName of browsers) {
  test.describe(`${browserName}`, () => {
    for (const tc of testCases) {
      test(tc.name, async ({ page }) => {
        // Sanitize on server
        const sanitized = serverSanitize(tc.input);

        // Render in real browser via Playwright
        await page.setContent(`<div id="target">${sanitized}</div>`);

        // Check for script execution
        const alertFired = await page.evaluate(() => {
          return window.__alertFired || false;
        });
        expect(alertFired).toBe(false);

        // Check DOM structure matches expectations
        const hasScript = await page.evaluate(() => {
          return document.querySelector('#target script') !== null;
        });
        expect(hasScript).toBe(false);
      });
    }
  });
}
```

This testing approach:
1. Tests sanitized output against real browser parsers (Chromium, Firefox, WebKit)
2. Detects parser differential issues that unit tests miss
3. Catches browser-specific mXSS vectors
4. Can be run against multiple browser versions
5. Verifies that no JavaScript executes in any tested browser

The matrix should include:
- Current stable versions of Chrome, Firefox, Safari
- Beta/canary versions to catch upcoming parser changes
- Mobile browser variants (particularly for WebView differences)
- The server-side DOM implementation used in production (jsdom, linkedom, happy-dom)

Comparing the server-side parser's output against each browser's parsed DOM reveals parser differentials that could enable mXSS.

---
