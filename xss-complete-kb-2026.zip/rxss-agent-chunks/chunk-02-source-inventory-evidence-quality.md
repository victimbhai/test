# Agent Chunk 02: Source Inventory & Evidence Quality

**Agent Task:** Understand the research sources, their reliability grades, and known gaps. Before trusting any finding, the agent should check its evidence quality. This chunk tells you which sources are trustworthy and which need verification.

---

## 3. Source Inventory

### 3.1 Archive Statistics

| Metric | Prompt Estimate | Verified Count | Discrepancy |
|---|---|---|---|
| Total entries | ~2,194 | **2,195** | +1 (root directory entry) |
| Total files | Not specified | **1,824** | N/A |
| Total directories | Not specified | **371** | N/A |
| XSS-filename matches | ~426 | **198** | -228 (prompt used broader matching criteria or counted duplicates) |

### 3.2 Top-Level Structure

```
data-extract/
+-- claude-bugbounty-vscode/     # Primary XSS knowledge base
|   +-- knowledge/
|   |   +-- xss-agent-kb/        # 101 files - core XSS research
|   |   +-- xss/                 # 28 files - HackerOne case studies
|   |   +-- vulnerability-agent/
|   +-- prompts/agents/
|
+-- offsec-agent-system/         # Offensive security agent framework
|   +-- skills/
|   |   +-- offsec-xss/SKILL.md  # Unique: skill dispatcher
|   |   +-- xss/
|   |   |   +-- SKILL.md         # 25 technique breakdowns
|   |   |   +-- refs/            # Unique: xss-bypasses.md, xss-polyglots.md
|   |   +-- xss-agent-kb/       # 101 files - IDENTICAL to claude-bugbounty-vscode
|   |   +-- vulnerability-agent/ # IDENTICAL to claude-bugbounty-vscode
|
+-- hackerone-reports/
    +-- tops_by_bug_type/
        +-- TOPXSS.md            # 2,376 entries - titles/links/metadata only
```

### 3.3 Source Manifest: Key Files

| Source ID | Path | Reflected-XSS Relevance | Evidence Quality | Unique Contribution |
|---|---|---|---|---|
| KB-01 | xss-agent-kb/01-xss-fundamentals.md | MEDIUM | SECONDARY-LOCAL | CWE-79 classification, OWASP mapping |
| KB-02 | xss-agent-kb/02-browser-parsing-execution.md | HIGH | PRIMARY-LOCAL (cites WHATWG spec) | HTML5 tokenizer states, triple-layer decoding |
| KB-03 | xss-agent-kb/03-reflected-xss-html-context.md | **CORE** | PRIMARY-LOCAL | Between-tags injection, 90+ event handlers |
| KB-04 | xss-agent-kb/04-reflected-xss-javascript-context.md | **CORE** | PRIMARY-LOCAL | JS string breakout, template literals, JSONP |
| KB-05 | xss-agent-kb/05-reflected-xss-special-contexts.md | **CORE** | PRIMARY-LOCAL | HTML comments, RCDATA/RAWTEXT, SVG/MathML |
| KB-15 | xss-agent-kb/15-filter-bypass-server.md | HIGH | SECONDARY-LOCAL | Turkish locale, encoding bypasses |
| KB-16 | xss-agent-kb/16-sanitizer-bypass-client.md | HIGH | PRIMARY-LOCAL (cites CVEs) | DOMPurify CVE timeline, mXSS mechanism |
| KB-17 | xss-agent-kb/17-waf-bypass-xss.md | HIGH | SECONDARY-LOCAL | Per-vendor WAF bypass categories |
| KB-24 | xss-agent-kb/24-json-api-header-xss.md | HIGH | PRIMARY-LOCAL | JSON/JSONP injection, GraphQL errors |
| KB-33 | xss-agent-kb/33-xss-prevention.md | HIGH | PRIMARY-LOCAL (cites OWASP) | Encoding contexts, CSP failures |
| KB-35 | xss-agent-kb/35-xss-detection-methodology.md | **CORE** | PRIMARY-LOCAL | 5-phase pipeline, context detection |
| KB-44 | xss-agent-kb/44-framework-xss.md | MEDIUM | **UNVERIFIED** (zero citations) | React/Next/Vue/Nuxt/Angular/Svelte/Astro |
| XSS-14 | xss/14-reflected-xss-oauth-redirect.md | **CORE** | PRIMARY-LOCAL | 6 reports, 10 vulnerable redirect params |
| XSS-16 | xss/16-crlf-injection-to-xss.md | HIGH | PRIMARY-LOCAL | Twitter, TikTok CRLF-to-XSS chains |
| XSS-21 | xss/21-swagger-api-docs-xss.md | HIGH | PRIMARY-LOCAL | Swagger UI < 4.1.3 |
| XSS-22 | xss/22-waf-bypass-techniques.md | HIGH | PRIMARY-LOCAL | Starbucks, data.gov WAF bypasses |
| TOPXSS | TOPXSS.md | Discovery index | SECONDARY-EXTERNAL | Title/link/metadata only - NO full report bodies |

### 3.4 Cross-Repository Duplication

Byte-for-byte comparison reveals extensive duplication between the two primary repositories:

| File Set | claude-bugbounty-vscode | offsec-agent-system | Status |
|---|---|---|---|
| xss-agent-kb/ (101 files) | knowledge/xss-agent-kb/ | skills/xss-agent-kb/ | **100% BYTE-IDENTICAL** |
| xss/ case studies (28 files) | knowledge/xss/ | skills/xss/refs/ | **100% BYTE-IDENTICAL** |
| vulnerability-agent/xss.md | knowledge/vulnerability-agent/ | skills/vulnerability-agent/ | **100% BYTE-IDENTICAL** |

**Files Unique to offsec-agent-system** (only 3):
1. `skills/offsec-xss/SKILL.md` (55 lines) - Skill dispatcher
2. `skills/xss/refs/xss-bypasses.md` (~21.5 KB) - 250+ bypass payloads (UNVERIFIED)
3. `skills/xss/refs/xss-polyglots.md` (~2.9 KB) - Multi-context polyglot vectors (UNVERIFIED)

---

## 5. Evidence-Quality Assessment

### 5.1 Evidence Grading System

| Grade | Definition | Requirements |
|---|---|---|
| **PRIMARY-LOCAL** | Original report, specification, or source code stored locally | Contains direct citations, version numbers, URLs |
| **PRIMARY-EXTERNAL** | Independently opened specification, first-party disclosure, maintainer source/patch | Fetched and verified during research from the primary publisher |
| **SECONDARY-EXTERNAL** | External commentary, indexed titles, curated summaries | Important claims verified against primary sources where possible |
| **SECONDARY-LOCAL** | Locally written summary citing primary evidence | Depends on accuracy of cited sources |
| **UNVERIFIED-LOCAL** | Payload, claim, or methodology without provenance | Requires independent verification before reliance |
| **INFERENCE** | Researcher conclusion based on multiple local sources | Clearly labeled, subject to falsification |
| **OBSOLETE/LEGACY** | Behavior limited to old browsers, frameworks, or retired protections | Clearly labeled with version/date boundaries |

### 5.2 Critical Evidence Gaps

1. **KB-44 has no citations**: The framework XSS file covers React, Next.js, Vue, Nuxt, Angular, Svelte, and Astro but provides zero source citations. All claims were cross-verified against framework documentation.

2. **Tools lack browser execution verification**: xss-detector.py operates on HTTP responses only, with no headless browser or DOM evaluation. Its detection of "reflection" does not constitute evidence of XSS.

3. **Nuclei templates have severity inflation**: reflected-xss-probe.yaml rates findings as "high" and reflected-xss-html-injection.yaml rates as "critical" - both without browser execution proof.

4. **TOPXSS.md contains titles only**: The 2,376 entries provide discovery leads but no technical evidence. A title stating "Reflected XSS" is a hypothesis until a complete report body confirms the full chain.

---

*Next chunk: chunk-03-request-pipeline-input-sources.md*
