# Agent Chunk 18: Root-Cause Taxonomy & Browser Parser Analysis

**Agent Task:** When you identify a reflected XSS, classify it by root cause (RC-1 through RC-8) to select the correct remediation. Use the browser parser comparison to determine whether a finding is browser-specific or universal. Check parser differentials before reporting cross-browser impact.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 35. Cross-Report Root-Cause Taxonomy

### 35.1 Root-Cause Categories

```
ROOT CAUSE TAXONOMY FOR REFLECTED XSS
│
├── RC-1: MISSING OUTPUT ENCODING
│   ├── RC-1a: No encoding applied to reflected value
│   ├── RC-1b: Encoding applied for wrong context (HTML encode in JS context)
│   ├── RC-1c: Partial encoding (< and > encoded, but not " or ')
│   ├── RC-1d: Encoding applied inconsistently (main template yes, error template no)
│   └── Reports: RXSS-01, RXSS-02, RXSS-07
│
├── RC-2: ENCODING/VALIDATION ORDERING
│   ├── RC-2a: Validation before decoding (double-encoding bypass)
│   ├── RC-2b: Encoding reversed by later processing (client-side innerHTML)
│   ├── RC-2c: Normalization after validation (Unicode NFKC mapping)
│   └── Reports: RXSS-05 (partial), WAF bypass reports
│
├── RC-3: TEMPLATE ENGINE ESCAPE HATCH
│   ├── RC-3a: Intentional raw HTML output (dangerouslySetInnerHTML, v-html, {@html}, set:html)
│   ├── RC-3b: Auto-escaping disabled for specific template
│   ├── RC-3c: Safe-string markers applied to unsanitized input
│   └── Reports: Framework-specific (Section 19)
│
├── RC-4: SANITIZER DEFICIENCY
│   ├── RC-4a: Sanitizer not applied (missing call on execution path)
│   ├── RC-4b: Sanitizer bypassed (mXSS, namespace confusion)
│   ├── RC-4c: Post-sanitization mutation (innerHTML reparsing)
│   ├── RC-4d: Sanitizer configuration weakened (prototype pollution)
│   └── Reports: DOMPurify CVEs, XSS-18
│
├── RC-5: PARSER DIFFERENTIAL
│   ├── RC-5a: WAF/server parser differential (WAFFLED)
│   ├── RC-5b: Browser/sanitizer parser differential (mXSS)
│   ├── RC-5c: Server/client parser differential (charset, encoding)
│   └── Reports: WAF bypass reports, DOMPurify bypasses
│
├── RC-6: PROTOCOL-LEVEL VULNERABILITY
│   ├── RC-6a: CRLF injection enabling response body control
│   ├── RC-6b: HTTP Parameter Pollution causing validation bypass
│   ├── RC-6c: Content-Type confusion (JSON served as text/html)
│   └── Reports: RXSS-06, XSS-16
│
├── RC-7: FRAMEWORK/LIBRARY VULNERABILITY
│   ├── RC-7a: Framework serialization bug (Astro server islands CVE-2025-64764)
│   ├── RC-7b: Library rendering vulnerability (Swagger UI url parameter)
│   ├── RC-7c: SSR hydration encoding failure (Nuxt CVE-2026-46342)
│   └── Reports: RXSS-04, RXSS-08
│
└── RC-8: CONFIGURATION/DEPLOYMENT
    ├── RC-8a: Debug/development mode in production
    ├── RC-8b: Reverse proxy error page reflection
    ├── RC-8c: Missing CSP or Trusted Types deployment
    └── Reports: RXSS-07 (partial)
```

### 35.2 Root-Cause to Remediation Mapping

| Root Cause | Primary Fix | Defense in Depth |
|---|---|---|
| RC-1 (Missing encoding) | Apply context-specific output encoding | CSP, Trusted Types |
| RC-2 (Ordering) | Fix transformation order: validate → process → encode at output | Input validation allowlists |
| RC-3 (Escape hatch) | Sanitize before raw rendering; audit all raw output uses | CSP, code review rules |
| RC-4 (Sanitizer) | Update sanitizer; use RETURN_DOM_FRAGMENT; avoid post-sanitization transformation | CSP, Trusted Types |
| RC-5 (Parser differential) | Normalize requests at WAF; use framework-native encoding | Multiple validation layers |
| RC-6 (Protocol-level) | Reject CRLF in headers; validate Content-Type; use framework header APIs | `nosniff`, CSP |
| RC-7 (Framework bug) | Update framework; report upstream; apply workaround | CSP, input validation |
| RC-8 (Configuration) | Disable debug mode; configure proxy error pages; deploy CSP | Security headers, monitoring |

---

## 36. Modern Browser Parser and Differential Analysis

### 36.1 Parser Engine Comparison

| Parsing Aspect | Blink (Chrome/Edge) | Gecko (Firefox) | WebKit (Safari) |
|---|---|---|---|
| HTML5 tokenizer compliance | Full (WHATWG spec) | Full (WHATWG spec) | Full (WHATWG spec) |
| DOM tree construction | WHATWG-compliant | WHATWG-compliant | WHATWG-compliant |
| Foreign content (SVG/MathML) | WHATWG-compliant | WHATWG-compliant | WHATWG-compliant |
| `<template>` inertness | Inert (no script execution) | Inert | Inert |
| Node depth limit (flattening) | ~512 (may vary by version) | ~512 | ~512 |
| Character encoding detection | Per WHATWG Encoding Standard | Per WHATWG Encoding Standard | Per WHATWG Encoding Standard |
| MIME sniffing with nosniff | Respects nosniff | Respects nosniff | Respects nosniff |
| JavaScript template literals | ES2015+ (full support) | ES2015+ (full support) | ES2015+ (full support) |
| Trusted Types | Supported (Chrome 83+) | **Not supported** | **Not supported** |
| `popover` attribute | Chrome 114+ | Firefox 125+ | Safari 17+ |

### 36.2 Known Parser Differentials Relevant to XSS

1. **`<selectedcontent>` (Chrome 130+)**: Chrome's implementation of `<selectedcontent>` re-clones option content after parsing, which can cause post-sanitization mutation. DOMPurify addressed this in CVE-2026-47423 (fixed in 3.4.5).

2. **Node flattening depth**: When DOM tree depth exceeds ~512 levels, browsers flatten nodes. The exact threshold varies by engine and version. This difference was exploited in DOMPurify bypass CVE-2024-45801.

3. **`<noscript>` parsing**: When JavaScript is enabled, `<noscript>` content is RAWTEXT (not parsed as HTML). When disabled, it's parsed normally. This creates a differential between environments.

4. **SVG `<style>` parsing**: In SVG namespace, `<style>` may be parsed differently than in HTML namespace, potentially allowing markup injection within what appears to be a style block.

**Source**: DOMPurify wiki (bypass history), WHATWG HTML Living Standard, mizu.re DOMPurify research.

---

*Next chunk: chunk-19-source-sink-transformation.md*
