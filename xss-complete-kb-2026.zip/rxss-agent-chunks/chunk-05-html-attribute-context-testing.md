# Agent Chunk 05: HTML & Attribute Context Testing

**Agent Task:** Test for reflected XSS in HTML text content and attribute contexts. Use the between-tags injection model for HTML data state. Use attribute breakout techniques for quoted, unquoted, and event-handler attributes. Check hidden input accesskey vectors.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Use abstract placeholders only
- Browser-execution examples limited to isolated local laboratory

---

## 10. HTML-Context Reflected XSS

### 10.1 Between-Tags Injection

When a reflected value appears between HTML tags (e.g., `<p>[REFLECTED]</p>`), the attacker's goal is to inject a new tag that triggers script execution.

**Required conditions**:
- The reflected value is not HTML-entity-encoded (or encoding is incomplete)
- The `<` character survives server processing
- The browser is in Data state (not inside a script, style, or RCDATA element)

**Abstract test model**:
```
Request: ?search=[UNIQUE_REFLECTION_MARKER]
Response: <div class="results">Your search for [UNIQUE_REFLECTION_MARKER] returned 0 results</div>

If < and > survive:
  Request: ?search=[CONTEXT_SPECIFIC_TEST_VALUE]
  where [CONTEXT_SPECIFIC_TEST_VALUE] causes a visible DOM change (e.g., a new element)

  Lab assertion: Observe DOM change in browser DevTools
  Negative control: Same request with HTML-entity-encoded input -> no DOM change
```

**Common implementation errors**:
- Encoding `<` and `>` but not `"` or `'` (partial encoding)
- Encoding on output in most templates but missing one template/partial
- Using blocklist filtering (`<script>` blocked but `<img>` or `<svg>` not)
- Case-sensitive filtering (`<SCRIPT>` or `<ScRiPt>` bypasses)
- Recursive filtering defeated by nesting: `<scr<script>ipt>` after removing inner `<script>`, becomes `<script>`

**Event handler surface**: The corpus (KB-03) documents 90+ HTML event handlers. Events that fire without user interaction are most significant for reflected XSS:

| Event Category | Examples | User Interaction Required |
|---|---|---|
| Load/error events | `onload`, `onerror`, `onloadstart` | NO -- fires automatically |
| Focus events | `onfocus` (with `autofocus`) | NO -- autofocus triggers automatically |
| Animation events | `onanimationend`, `ontransitionend` | NO -- fires when animation completes |
| Media events | `oncanplay`, `ondurationchange` | NO -- fires on media state change |
| Pointer events | `onpointerover`, `onpointerenter` | YES -- requires mouse movement |
| Click events | `onclick` | YES -- requires click |
| Keyboard events | `onkeydown`, `onkeyup` | YES -- requires keyboard input |

### 10.2 Server-Rendered Fragments

Modern applications using HTMX, Turbo/Hotwire, or similar hypermedia-driven approaches return HTML fragments inserted into the existing page via `innerHTML` or similar DOM operations. If these fragments contain reflected values without proper encoding, the fragment insertion creates an XSS execution point.

**HTMX-specific considerations**:
- HTMX inserts server responses directly into the page using swap operations
- The `hx-on` attribute "can evaluate arbitrary scripts" (htmx.org)
- HTMX 2 restricts cross-origin requests by default
- Auto-escaping in the server-side template engine is the primary defense
- `htmx.config.allowEval` can be disabled to restrict script evaluation

---

## 11. Attribute-Context Reflected XSS

### 11.1 Double-Quoted Attributes

When a reflected value appears inside a double-quoted HTML attribute:
```html
<input type="text" value="[REFLECTED]" />
```

**Attack principle**: Close the attribute with `"`, then either close the tag with `>` and inject a new tag, or inject a new attribute that creates a scriptable context.

**Abstract test model**:
```
Request: ?name=[UNIQUE_REFLECTION_MARKER]
Response: <input value="[UNIQUE_REFLECTION_MARKER]" />

Test: ?name=[CONTEXT_SPECIFIC_TEST_VALUE]" [ADDITIONAL_ATTRIBUTE]="
Lab assertion: Verify new attribute appears in DOM
Negative control: Same with " HTML-entity-encoded -> attribute value contains literal &quot;
```

**Required encoding**: HTML attribute encoding -- at minimum, encode `"`, `'`, `&`, `<`, `>`.

### 11.2 Single-Quoted Attributes

Identical to double-quoted, but the breakout character is `'` instead of `"`.

### 11.3 Unquoted Attributes

When a value appears in an unquoted attribute:
```html
<div class=[REFLECTED]>
```

**This is the most permissive context.** Any of the following characters terminate the attribute value: space, tab, newline, form feed, `>`, `"`, `'`, backtick, `=`. After termination, the attacker can inject new attributes.

### 11.4 Event-Handler Attributes

When a reflected value appears inside an event-handler attribute:
```html
<div onclick="handleClick('[REFLECTED]')">
```

**Critical**: The browser first HTML-entity-decodes the attribute value, then passes it to the JavaScript engine. This means:
- HTML entities like `&#x27;` are decoded to `'` before JavaScript evaluation
- The attacker needs to break out of the JavaScript string context
- Both JavaScript string encoding AND HTML attribute encoding are required

### 11.5 URL-Bearing Attributes

Attributes like `href`, `src`, `action`, `formaction`, `srcdoc`, and `data` accept URLs. If a reflected value controls the entire URL or a significant portion:

```html
<a href="[REFLECTED]">Click here</a>
```

**javascript: protocol**: If the value can start with `javascript:`, the browser will execute the URL as JavaScript when the link is activated. Modern browsers (Chrome, Firefox, Safari) still support `javascript:` URLs in `href` attributes. React 19 blocks `javascript:` in JSX `src` and `href` props, but this is framework-level protection, not browser-level.

**Defense**: Validate that URLs start with `https://` or `http://` (or another allowed scheme). Blocklisting `javascript:` is fragile due to encoding bypasses.

### 11.6 Hidden Input Fields and accesskey

Research by Gareth Heyes (PortSwigger) demonstrated that hidden input fields can be exploited using the `accesskey` attribute:

```html
<input type="hidden" accesskey="X" onclick="[HARMLESS_EXECUTION_MARKER]" />
```

- **Firefox**: ALT+SHIFT+X triggers the `onclick` handler
- **Chrome**: Also supports `accesskey`-triggered events on hidden inputs
- **Safari**: Not confirmed in the original research

This technique requires user interaction (pressing the key combination) but can make previously unexploitable reflections exploitable. It also works on `<link>` and `<meta>` elements.

**Limitation**: If the reflected input appears more than once on the page, the access key combination may fail.

**Source**: PortSwigger Research "XSS in hidden input fields" by Gareth Heyes, KB-05, XSS-25.

---

*Next chunk: chunk-06-javascript-url-json-context.md*
