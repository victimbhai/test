# Agent Chunk 12: Safe Isolated-Lab Methodology

**Agent Task:** Follow this exact 11-step methodology when testing for reflected XSS in an isolated local lab. Every test MUST use the workflow below. Never skip the negative control. Never escalate beyond a harmless execution marker.

**Safety Constraints:**
- Do not test public applications
- Do not send requests to third-party targets
- Do not execute repository tools, scripts or Nuclei templates
- Do not reproduce credential-stealing, session-stealing, phishing, keylogging or persistence code
- Do not compile a weaponized payload or WAF-bypass library
- Use abstract placeholders: `[UNIQUE_REFLECTION_MARKER]`, `[HARMLESS_EXECUTION_MARKER]`, `[CONTEXT_SPECIFIC_TEST_VALUE]`, `[NEGATIVE_CONTROL]`, `[ENCODED_VARIANT]`, `[CONTROLLED_PARAMETER]`
- Any browser-execution example must be limited to an isolated local laboratory and a harmless visible or console marker

---

## 22. Safe Isolated-Lab Methodology

### 22.1 Workflow Overview

```
1. MARKER INJECTION
   ├── Choose a unique inert alphanumeric marker: [UNIQUE_REFLECTION_MARKER]
   │   (e.g., a random string like "XSS_PROBE_a7b3c9d2")
   ├── Insert ONE marker into ONE controlled input
   └── Do NOT use any characters with HTML/JS/URL significance

2. RESPONSE CAPTURE
   ├── Capture the raw HTTP response (headers and body)
   ├── Record response Content-Type header
   ├── Record CSP and other security headers
   └── Record response status code

3. REFLECTION LOCATION
   ├── Search the response body for the marker
   ├── Count ALL reflection points (a value may reflect multiple times)
   ├── For EACH reflection, identify:
   │   ├── The exact byte offset in the response
   │   ├── The surrounding HTML/JS/CSS context
   │   ├── The quote state (inside single quotes, double quotes, unquoted)
   │   └── The parser state (HTML data, attribute, script, RCDATA, etc.)
   └── Analyze each reflection independently

4. CONTEXT IDENTIFICATION
   ├── Determine the HTML5 tokenizer state at the reflection point
   ├── Determine the DOM tree position
   ├── Identify the nearest element and attribute context
   ├── Check for namespace (HTML, SVG, MathML)
   └── Check for RCDATA/RAWTEXT/script contexts

5. ENCODING ANALYSIS
   ├── Record which characters are encoded/escaped
   ├── Record which characters survive unmodified
   ├── Record any transformations applied (case folding, normalization)
   └── Build a character survival matrix for the reflection point

6. EXECUTABILITY DETERMINATION
   ├── Given the context and surviving characters:
   │   ├── Can a new tag be injected? (requires < and >)
   │   ├── Can an attribute be broken out of? (requires quote char or space for unquoted)
   │   ├── Can a JavaScript string be terminated? (requires quote char or backslash bypass)
   │   ├── Can a script block be terminated? (requires </script>)
   │   └── Can a javascript: URL be injected? (requires protocol control)
   └── If no executable context exists → SAFE REFLECTION (stop)

7. HARMLESS EXECUTION MARKER (local lab only)
   ├── Use [HARMLESS_EXECUTION_MARKER] — a console.log or visible DOM change
   ├── Test ONLY in an isolated local browser against a local server
   ├── Never test against production or third-party applications
   └── Record browser name, version, and any extensions

8. EVIDENCE COLLECTION
   ├── Browser console output
   ├── DOM state (via DevTools)
   ├── Screenshot of visible marker
   ├── Raw HTTP request and response
   └── Exact browser version and configuration

9. NEGATIVE CONTROL
   ├── Apply the correct encoding for the identified context
   ├── Re-submit the same request
   ├── Verify the marker appears as inert text, not executable content
   └── Confirm no DOM change or console output occurs

10. REMEDIATION VERIFICATION
    ├── Apply the fix (output encoding, safe rendering, CSP)
    ├── Repeat the exact same test
    ├── Confirm the value is safely rendered
    └── Verify the negative control still passes

11. STOP
    ├── Do NOT escalate to data access, session theft, or account takeover
    ├── Do NOT test against other users or accounts
    └── Document findings with evidence classifications
```

### 22.2 Pre-Test Checklist

Before choosing any test value, identify:

| Item | Must Determine Before Testing |
|---|---|
| Input source | Query param, path, header, cookie, body, etc. |
| HTTP method | GET, POST, PUT, etc. |
| Reflection location | Where in the response body the value appears |
| HTML/JS/URL context | Tokenizer state, DOM position, namespace |
| Quote state | Single-quoted, double-quoted, unquoted, none |
| Parser state | Data, RCDATA, RAWTEXT, script, attribute |
| Encoding behavior | Which characters are encoded/escaped/transformed |
| Browser | Name, version, engine |
| CSP | Policy content, enforcement vs. report-only |
| Sandbox | iframe sandbox attributes, if applicable |
| Framework | Server-side framework and template engine |
| Expected proof | What constitutes successful execution |
| Negative control | What the safe version should look like |

---

*Next chunk: chunk-13-attack-vector-cards.md*
