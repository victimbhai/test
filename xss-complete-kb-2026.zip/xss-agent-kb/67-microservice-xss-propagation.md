# 67 - Microservice XSS Propagation

## Overview

Microservice architectures propagate XSS through:
- Shared databases where Service A stores unsanitized data that Service B renders
- Event-driven systems (Kafka, RabbitMQ, Redis) where message payloads contain XSS
- Service mesh tracing header reflection (X-Request-ID, traceparent, B3 headers)
- Apache Camel Kafka header injection (CVE-2026-49098)
- Admin UIs for message brokers rendering payload content without encoding

## Inter-Service XSS via Shared Databases

The inter-service stored XSS pattern occurs when Service A stores unsanitized data and Service B renders it. No specific CVEs exist, but it is a recognized architectural risk.

### Attack Flow

```
Attacker      Service A (Write)     Shared Database     Service B (Read/Render)     Victim
   |                |                    |                      |                      |
   |-- Submit       |                    |                      |                      |
   |   malicious    |                    |                      |                      |
   |   input ------>|                    |                      |                      |
   |                |-- Store            |                      |                      |
   |                |   unsanitized ---->|                      |                      |
   |                |   (Service A is    |                      |                      |
   |                |    API-only,       |                      |                      |
   |                |    never renders)  |                      |                      |
   |                |                    |<-- Read data --------|                      |
   |                |                    |                      |-- Render in HTML ---->|
   |                |                    |                      |   without encoding    |
   |                |                    |                      |   (trusts database)   |
   |                |                    |                      |                 XSS! |
```

### Root Cause

The root cause is misalignment of security responsibilities:
- Service A does not sanitize because it is an API that never renders HTML
- Service B does not sanitize because it trusts data from the "internal" database
- Neither service owns output encoding

### Mitigation Principles

- Never trust HTML coming from other microservices
- Treat data from shared databases as untrusted input
- Every service that returns HTML or JSON should use shared encoding and sanitizing libraries
- Output encoding must happen at the point of rendering, not at the point of storage

```python
# VULNERABLE: Service B trusts data from shared database
@app.route('/admin/users')
def admin_users():
    users = db.get_all_users()  # Data stored by Service A's API
    return render_template('users.html', users=users)
    # Template: <td>{{ user.bio | safe }}</td>  -- | safe disables encoding!

# SAFE: Encode at rendering layer
# Template: <td>{{ user.bio }}</td>  -- auto-escaped by default
```

## Event-Driven Architecture XSS

### Apache Camel Kafka Header Injection (CVE-2026-49098)

**CVE-2026-49098:** The camel-kafka component allows attackers who send HTTP requests to set Kafka headers that override the destination topic, letting forged messages reach topics the app never meant to write to. Affected versions: 4.0.0 through 4.20.9. A public exploit exists.

While this is a header injection vulnerability, the injected messages can contain XSS payloads that execute when consumed and rendered by downstream services.

### Kafka Admin UI XSS

Kafka admin UIs (kafka-ui, AKHQ, Kafdrop, Conduktor) render message keys, values, and headers in web interfaces. If a Kafka topic contains messages with HTML/JS in the value, any admin tool that renders the raw value without encoding will execute the XSS.

**CVE-2026-5562 (kafka-ui):** A crafted request to a smart-filter endpoint leads to remote code execution in versions up to 0.7.2.

### Event-Driven XSS Attack Flow

```
Attacker           Event Producer        Message Broker       Consumer           Admin UI
   |                    |                    |                    |                  |
   |-- Inject XSS -->   |                    |                    |                  |
   |   via API or       |-- Publish -------->|                    |                  |
   |   header injection |   message with     |                    |                  |
   |                    |   XSS in body      |-- Deliver -------->|                  |
   |                    |   or headers       |                    |-- Render -------->|
   |                    |                    |                    |   message in      |
   |                    |                    |                    |   web UI = XSS!   |
```

### Redis Pub/Sub XSS

Redis's protocol is length-prefixed and binary safe, so classic command injection is not expected. The XSS risk comes from web dashboards (Redis Commander, RedisInsight) that display pub/sub messages or key values without encoding.

**CVE-2024-25122 (sidekiq-unique-jobs):** XSS from unescaped GET parameters in the admin UI, not from Redis data itself.

### RabbitMQ Management UI

RabbitMQ management UI renders message payloads. If a queue contains a message with XSS in the body and an operator inspects it through the management interface, the XSS executes in the operator's browser with the management UI's session.

## Service Mesh XSS Propagation

### Tracing Header Reflection

No confirmed XSS vulnerabilities through service mesh tracing header reflection were found. However, the theoretical attack is viable.

```
External Client          Istio Ingress Gateway    Envoy Sidecar (A)    Service A App
   |                          |                        |                    |
   |-- Request with           |                        |                    |
   |   X-Request-ID:          |                        |                    |
   |   <script>alert(1)       |-- Propagates header -->|-- Passes to app ->|
   |   </script>              |                        |                    |
   |                          |                        |                    |-- Reflects
   |                          |                        |                    |   X-Request-ID
   |                          |                        |                    |   in error/debug
   |<-- XSS in response ------|<-----------------------|<-------------------|
```

### Envoy Default Behavior

Envoy's behavior of overwriting X-Request-ID with its own UUID value mitigates this attack in the default configuration. However, if `use_remote_address: false` is set or if custom EnvoyFilters pass through the original header, the mitigation is lost.

### Application-Level Tracing Risk

The greater risk is in application-level tracing: services that log or display tracing headers (traceparent, B3 trace IDs) in admin dashboards, debug pages, or error responses without HTML encoding. The mesh's header propagation becomes an XSS delivery mechanism across the entire service graph.

## GraphQL Federation XSS

GraphQL federation and API composition patterns create the same inter-service XSS risk without a shared database: Service A's resolver returns unsanitized data that Service B's frontend consumes and renders.

```javascript
// Service A: User service resolver returns unsanitized bio
const resolvers = {
  User: {
    bio: (user) => user.bio  // Raw HTML from user input
  }
};

// Service B: Frontend renders federated data
function UserProfile({ userId }) {
  const { data } = useQuery(GET_USER);
  // VULNERABLE: rendering federated data via innerHTML
  return <div dangerouslySetInnerHTML={{ __html: data.user.bio }} />;
}
```

## Event Sourcing XSS Amplification

Event sourcing architectures where raw events are stored immutably and rendered by multiple consumers amplify the XSS risk. Each consumer must independently handle encoding, and a single consumer that fails to encode will be vulnerable.

## Testing Methodology

1. **Map data flows** between services to identify write-to-render paths
2. **Check shared database consumers** for output encoding on data written by other services
3. **Inspect admin UIs** for Kafka, Redis, and RabbitMQ message rendering
4. **Test tracing headers** (X-Request-ID, traceparent) for reflection in error pages
5. **Check Envoy configuration** for use_remote_address and custom EnvoyFilters
6. **Test GraphQL federated resolvers** for unsanitized data propagation
7. **Submit XSS payloads via API** and check rendering across all consuming services
8. **Test Apache Camel Kafka** routes for header injection

## Bug Bounty Tips

1. Inter-service XSS through shared databases is an underreported vulnerability class
2. Kafka/RabbitMQ/Redis admin UIs are high-value targets for stored XSS
3. Apache Camel Kafka CVE-2026-49098 enables topic injection with public exploit
4. Tracing header reflection XSS in service meshes is an unstudied attack surface
5. Event sourcing amplifies XSS impact -- one stored payload renders across multiple consumers
6. GraphQL federation creates inter-service XSS without shared databases
7. The root cause is always misaligned security responsibility between writing and rendering services
8. ORMs protect against SQLi but not XSS -- database data must be encoded at the rendering layer
