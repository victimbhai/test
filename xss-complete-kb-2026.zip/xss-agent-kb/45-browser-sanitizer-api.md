# 45 - Browser Sanitizer API (setHTML/getHTML)

## Overview

The browser-native Sanitizer API provides built-in HTML sanitization through `Element.setHTML()` and `Element.getHTML()` methods, eliminating the need for third-party libraries like DOMPurify. Its primary advantage is the elimination of the parse-serialize-reparse cycle that enables mXSS -- the sanitized DOM tree is inserted directly without serialization. However, implementation bugs have already been found, and the API's design has required significant reworking during standardization.

**Sources**: [Searchlight Cyber Research](https://www.slcyber.io/research/two-bypasses-for-chromes-sanitizer-api), [NVD - CVE-2026-7939](https://nvd.nist.gov/vuln/detail/CVE-2026-7939), [Frederik Braun - Why setHTML()](https://frederikbraun.de/why-sethtml.html), [Chrome Developer Blog](https://developer.chrome.com/blog/escape-attributes)

---

## 1. API Overview and Browser Support

### Browser Rollout Status

| Browser | Version | Date | Status |
|---------|---------|------|--------|
| Chrome | 146+ | Early 2026 | Stable |
| Firefox | 148+ | Late 2025 (nightly) | Stable |
| Safari | 26+ | September 2025 | Stable |
| Baseline | All major browsers | 2026 | Available |

### Core API Usage

```javascript
// Basic usage - setHTML sanitizes and inserts directly
const sanitizer = new Sanitizer({
  allowElements: ['b', 'i', 'p', 'span', 'a'],
  blockElements: ['script'],
  dropElements: ['style']
});
element.setHTML(untrustedInput, { sanitizer: sanitizer });

// Default sanitizer (blocks scripts, event handlers, etc.)
element.setHTML(untrustedInput);

// getHTML - returns sanitized HTML string
const cleanHTML = element.getHTML({ sanitizer: sanitizer });
```

### Design Philosophy: Why setHTML() Instead of sanitize()

Mozilla (bug 1669945) documented a sanitizer bypass when sanitized markup is assigned to srcdoc. Mozilla chose to change the API design rather than patch the bypass -- they removed the context-free `sanitize()` function that accepts an HTML string.

**Rationale:** A string-in/string-out sanitizer cannot know the insertion context, so it cannot guarantee safety. This is why the API became `setHTML()` (an element method) rather than `Sanitizer.sanitize(string)`.

```javascript
// REMOVED from spec: context-free string sanitization
// Sanitizer.sanitize(htmlString)  <-- This was removed
// Because: the same string may be safe in <div> but unsafe in <iframe srcdoc="">

// CURRENT API: element-method, context-aware
element.setHTML(htmlString);  // Knows the insertion context
```

**Source**: [Mozilla Bugzilla 1669945](https://bugzilla.mozilla.org/show_bug.cgi?id=1669945), [Frederik Braun: Why the Sanitizer API is just setHTML()](https://frederikbraun.de/why-sethtml.html)

---

## 2. Advantage Over DOMPurify: Eliminating mXSS by Design

The browser Sanitizer API eliminates mXSS by design: it parses and sanitizes in the same engine that will render the content, removing the parse-serialize-reparse gap. There is no serialization step -- the sanitized DOM tree is inserted directly.

```
DOMPurify workflow (vulnerable to mXSS):
  Input -> Parse -> Sanitize -> Serialize (innerHTML string) -> Reparse -> Render
                                           ^ gap here creates mXSS

Sanitizer API workflow (mXSS-resistant):
  Input -> Parse -> Sanitize -> Insert directly into DOM -> Render
                                ^ no serialization step
```

This architectural difference means:
- No parser differential between sanitizer and renderer (same engine)
- No serialization step that could lose namespace information
- No reparse that could produce a different DOM tree
- No attribute value angle bracket mXSS (the class Chrome 138 spec change addresses)

**Source**: [ibit.blog](https://www.ibit.blog/articles/html-sanitizer-api), [keith.is](https://keith.is/post/html-sanitizer-api/)

---

## 3. Known Vulnerabilities and Bypasses

### CVE-2026-7939 (May 2026) - Chrome Sanitizer API UXSS

**Severity:** Medium (Google), CVSS 3.1 score 5.4 (CISA-ADP)

Inappropriate implementation in SanitizerAPI in Google Chrome before 148.0.7778.96 allowed a remote attacker to inject scripts or HTML (UXSS) via crafted HTML page. This demonstrates that even browser-native implementations are not immune to implementation bugs.

- **Affected versions:** Chrome < 148.0.7778.96
- **Fixed in:** Chrome 148.0.7778.96
- **Upstream bug:** issues.chromium.org/issues/492963096

**Source**: [NVD](https://nvd.nist.gov/vuln/detail/CVE-2026-7939), [Red Hat Bugzilla](https://bugzilla.redhat.com/show_bug.cgi?id=2467415)

### Two Chrome Sanitizer API Bypasses (Chrome 146)

Security researchers at Searchlight Cyber (Adam Kues) reported two bypasses in Chrome's Sanitizer API implementation at launch (Chrome 146):

1. One bypass discovered by Adam Kues
2. One bypass discovered by another party

The empty configuration (`new Sanitizer({})`) is the most permissive configuration but should still block scripts. These bypasses showed that even this safety guarantee could be violated.

```javascript
// The empty config is maximally permissive but should still block dangerous content
const sanitizer = new Sanitizer({});  // Most permissive
element.setHTML(payload, { sanitizer });
// Bypasses allowed script execution despite the safety guarantee
```

**Source**: [Searchlight Cyber](https://www.slcyber.io/research/two-bypasses-for-chromes-sanitizer-api)

### Mozilla srcdoc Design Decision

Mozilla bug 1669945 documented a bypass where sanitized markup assigned to `srcdoc` attribute could escape the sanitization context. Rather than patching individual bypasses, Mozilla fundamentally redesigned the API:

- Removed `sanitize()` string-in/string-out method entirely
- Made `setHTML()` an element method (knows insertion context)
- This prevents context-dependent bypasses where the same HTML is safe in one context but dangerous in another (e.g., `<div>` vs `<iframe srcdoc="">`)

---

## 4. Configuration and Security Considerations

### Default Configuration

The default Sanitizer configuration provides reasonable security:

```javascript
// Default sanitizer - blocks scripts, event handlers, dangerous elements
const sanitizer = new Sanitizer();
element.setHTML(untrustedInput, { sanitizer });

// The default configuration:
// - Removes <script>, <style>, <link>, <object>, <embed>, <applet>
// - Removes event handler attributes (onclick, onerror, etc.)
// - Keeps common formatting and structural elements
```

### Empty Configuration Pitfall

```javascript
// CAUTION: empty config ({}) is the MOST PERMISSIVE configuration
// It is NOT the same as the default
const sanitizer = new Sanitizer({});  // Allows almost everything
// vs
const sanitizer = new Sanitizer();    // Uses safe defaults
```

### Known Limitations

```javascript
// The Sanitizer API does NOT protect against DOM clobbering by default
// Elements with id/name attributes can still clobber global variables
element.setHTML('<img id="cookie">', { sanitizer });  // Passes through

// Custom elements are allowed by default
element.setHTML('<custom-xss onclick=alert(1)>click</custom-xss>');

// The API does not validate URL schemes in attributes
// Applications must separately validate href, src, action URLs
```

---

## 5. Adoption Limitations

The API's restrictive design (no string output, element-method-only) may limit adoption in scenarios where developers need sanitized HTML as a string:

- **Server-side rendering (SSR):** Cannot use setHTML() on the server; need string output
- **Email templates:** Email systems work with HTML strings, not DOM elements
- **Storage:** Applications that store sanitized HTML in databases need string output
- **Rich-text editors:** Some editors need sanitized HTML as a string for internal processing

In these scenarios, DOMPurify or other string-based sanitizers remain necessary, and the mXSS risks they carry remain relevant.

---

## 6. Comparison with DOMPurify

| Feature | Browser Sanitizer API | DOMPurify |
|---------|----------------------|-----------|
| mXSS resistance | By design (no reparse) | Actively patched |
| Browser support | Chrome 146+, Firefox 148+, Safari 26+ | All browsers |
| String output | No (element method only) | Yes |
| Server-side use | No | Yes (via jsdom) |
| Custom hooks | No | Yes (extensive hook system) |
| Custom elements | Configurable | Via CUSTOM_ELEMENT_HANDLING |
| Configuration | allowElements/blockElements/dropElements | ADD_TAGS/FORBID_TAGS/etc. |
| CVEs (2024-2026) | 1 (CVE-2026-7939) | 8+ |
| DOM clobbering protection | No | Yes (SANITIZE_DOM) |

---

## 7. Related: .NET HtmlSanitizer

**CVE-2026-25543** - A template-tag bypass in the .NET HtmlSanitizer library. Separate from the browser API but relevant to the sanitizer bypass landscape.

**Source**: [GitLab Advisory](https://advisories.gitlab.com/pkg/nuget/htmlsanitizer/CVE-2026-25543/)

---

## Testing Methodology

1. **Check API availability**: Test for `Element.prototype.setHTML` to confirm the API is present
2. **Test default vs empty config**: Verify the application uses `new Sanitizer()` not `new Sanitizer({})`
3. **Test custom element handling**: Custom elements may bypass allow-list expectations
4. **Test DOM clobbering**: The API does not protect against id/name clobbering
5. **Test srcdoc contexts**: Verify sanitized content is not used in `<iframe srcdoc="">`
6. **Test URL scheme validation**: Check if javascript:, data:, vbscript: URIs pass through href/src attributes
7. **Check browser version**: CVE-2026-7939 affects Chrome < 148.0.7778.96
8. **Test fallback behavior**: Applications often fall back to DOMPurify when the API is unavailable; test both paths

---

## References

- [Searchlight Cyber - Two Bypasses for Chrome's Sanitizer API](https://www.slcyber.io/research/two-bypasses-for-chromes-sanitizer-api)
- [NVD - CVE-2026-7939](https://nvd.nist.gov/vuln/detail/CVE-2026-7939)
- [Red Hat Bugzilla - CVE-2026-7939](https://bugzilla.redhat.com/show_bug.cgi?id=2467415)
- [Mozilla Bugzilla 1669945 - srcdoc Bypass](https://bugzilla.mozilla.org/show_bug.cgi?id=1669945)
- [Frederik Braun - Why the Sanitizer API is just setHTML()](https://frederikbraun.de/why-sethtml.html)
- [ibit.blog - HTML Sanitizer API](https://www.ibit.blog/articles/html-sanitizer-api)
- [keith.is - HTML Sanitizer API](https://keith.is/post/html-sanitizer-api/)
- [Chrome Developer Blog - Escape Attributes](https://developer.chrome.com/blog/escape-attributes)
- [OWASP - DOM Clobbering Prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_Clobbering_Prevention_Cheat_Sheet.html)
- [GitLab Advisory - CVE-2026-25543 (.NET HtmlSanitizer)](https://advisories.gitlab.com/pkg/nuget/htmlsanitizer/CVE-2026-25543/)
