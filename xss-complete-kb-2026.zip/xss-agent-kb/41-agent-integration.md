# 41 - XSS Agent Integration

## Overview

This document defines the inter-agent communication protocols, data sharing formats, and integration workflows between the XSS agent and all other agents in the security assessment platform. Proper integration ensures that findings, session context, and intelligence flow between agents to enable complex attack chains and comprehensive coverage that no single agent could achieve alone.

**Cross-references**: Agent methodology in `39-agent-methodology.md`, decision logic in `40-agent-decision-logic.md`, platform architecture in `../../CLAUDE.md`.

---

## 1. Integration with Auth Agent (BBAG3NT-03)

The auth-agent is the **foundational dependency**. It must execute before the XSS agent can test authenticated surfaces. The auth-agent provides session context, token handling knowledge, and authorization model understanding.

### 1.1 Data Received from Auth Agent

| Data Element | Format | Purpose |
|-------------|--------|---------|
| Session cookies | `Set-Cookie` header format: `name=value; path=/; domain=.target.com` | Inject into XSS agent HTTP requests for authenticated testing |
| Bearer tokens | `Authorization: Bearer <JWT_or_opaque_token>` | API endpoint testing with authentication |
| CSRF tokens | Token value + location (meta tag, cookie, hidden field) | Include in exploitation payloads that perform authenticated actions |
| Auth model type | Enum: `session-cookie`, `jwt`, `oauth2`, `api-key`, `saml`, `custom` | Determines cookie theft vs token theft exploitation strategy |
| Session lifespan | Integer (seconds) or `sliding`/`absolute` | Determines urgency of exploitation (short sessions require fast exfiltration) |
| Cookie flags | `HttpOnly`, `Secure`, `SameSite` per cookie | Determines whether direct cookie theft via `document.cookie` is possible |
| Role matrix | JSON: `{"roles": ["user", "moderator", "admin"], "current_role": "user"}` | Guides which surfaces to test and which roles to attempt escalation to |
| Authenticated URLs | List of URLs requiring authentication | Scope for authenticated XSS testing |

### 1.2 Session Context Request Protocol

When the XSS agent needs authenticated access, it sends a request to the auth-agent:

```json
{
  "request_type": "session_context",
  "agent_id": "xss-agent",
  "target": "https://target.com",
  "requirements": {
    "roles_needed": ["user", "admin"],
    "session_count": 2,
    "include_csrf_tokens": true,
    "include_cookie_flags": true
  }
}
```

**Auth-agent response**:

```json
{
  "response_type": "session_context",
  "target": "https://target.com",
  "sessions": [
    {
      "role": "user",
      "session_id": "session_user_001",
      "cookies": [
        {"name": "session_id", "value": "abc123...", "httponly": true, "secure": true, "samesite": "Lax"},
        {"name": "csrf_token", "value": "def456...", "httponly": false, "secure": true}
      ],
      "headers": {"Authorization": "Bearer eyJ..."},
      "csrf_token": {"value": "def456...", "location": "cookie", "header_name": "X-CSRF-Token"}
    },
    {
      "role": "admin",
      "session_id": "session_admin_001",
      "cookies": [...],
      "headers": {...},
      "csrf_token": {...}
    }
  ],
  "auth_model": "jwt",
  "token_lifespan_seconds": 3600,
  "refresh_mechanism": "refresh_token in httponly cookie"
}
```

### 1.3 XSS Testing Across Authentication Contexts

The XSS agent tests each input surface in multiple auth contexts:

1. **Unauthenticated**: Test all public-facing inputs without any session context.
2. **Authenticated (low-privilege user)**: Test with user-level session. This is the primary testing context since it reflects the most common attacker scenario.
3. **Authenticated (admin/moderator)**: Test admin-only inputs that may have weaker sanitization (internal tools often less hardened).
4. **Cross-role**: Inject XSS as low-privilege user, check if it renders/executes in admin context (stored XSS targeting admins).

### 1.4 Token Handling for Exploitation Payloads

When crafting exploitation payloads, the XSS agent adapts based on auth-agent intelligence:

| Auth Model | Cookie Flags | Exploitation Strategy |
|-----------|-------------|----------------------|
| Session cookie | No HttpOnly | Direct `document.cookie` theft |
| Session cookie | HttpOnly set | Perform authenticated actions via XSS (password change, data export) |
| JWT in localStorage | N/A | `localStorage.getItem('token')` exfiltration |
| JWT in sessionStorage | N/A | `sessionStorage.getItem('token')` exfiltration |
| JWT in HttpOnly cookie | HttpOnly set | CSRF-like attacks via XSS; extract from response if included in API calls |
| OAuth2 | Varies | Steal access_token from URL fragment or localStorage |
| API key | In header/query | Extract from JavaScript variables or request interception |

---

## 2. Integration with Recon Agent (BBAG3NT-01/02)

The recon agent performs target discovery before the XSS agent begins testing. It provides the input surface map that the XSS agent uses for testing.

### 2.1 Data Received from Recon Agent

| Data Element | Format | XSS Agent Usage |
|-------------|--------|-----------------|
| Discovered URLs | Newline-separated URL list | Input point enumeration (Phase 2 of methodology) |
| URL parameters | JSON: `{"url": "...", "params": ["q", "page", "sort"]}` | Direct reflection testing targets |
| Technology stack | JSON: `{"framework": "React", "server": "nginx", "cms": "WordPress"}` | Framework-specific payload selection |
| Subdomain list | Newline-separated: `sub1.target.com`, `sub2.target.com` | Same-origin policy analysis for XSS impact |
| CDN/WAF info | JSON: `{"cdn": "Cloudflare", "waf": "Cloudflare WAF", "real_ip": "1.2.3.4"}` | WAF bypass planning, origin IP for direct access |
| JavaScript files | List of JS file URLs | DOM XSS source-to-sink analysis |
| API endpoints | OpenAPI/Swagger spec or endpoint list | API parameter XSS testing |
| Sitemap | URL tree structure | Comprehensive coverage planning |

### 2.2 Recon Data Consumption Protocol

```json
{
  "request_type": "target_profile",
  "agent_id": "xss-agent",
  "target": "https://target.com",
  "data_needed": [
    "discovered_urls",
    "url_parameters",
    "technology_stack",
    "subdomain_list",
    "waf_info",
    "javascript_files",
    "api_endpoints"
  ]
}
```

### 2.3 Same-Origin Policy Analysis

The recon agent's subdomain data enables the XSS agent to assess cross-origin impact:

- **Same-origin XSS**: XSS on `app.target.com` can access cookies scoped to `.target.com`
- **Subdomain takeover + XSS**: If a subdomain is vulnerable to takeover, attacker can set cookies for the parent domain
- **Cross-subdomain XSS chaining**: XSS on `sub1.target.com` may enable attacks on `sub2.target.com` if cookies are shared

---

## 3. Integration with IDOR Agent (BBAG3NT-04)

XSS and IDOR vulnerabilities frequently coexist and can be chained for amplified impact.

### 3.1 XSS + IDOR Attack Chains

| Chain Pattern | Description | Impact |
|--------------|-------------|--------|
| **IDOR-delivered Stored XSS** | IDOR allows modifying another user's profile/content. Inject XSS payload into victim's profile. | Stored XSS without social engineering |
| **XSS-enabled IDOR** | XSS payload enumerates user IDs and accesses IDOR-vulnerable endpoints on behalf of the victim. | Mass data exfiltration via victim's authenticated session |
| **IDOR for XSS delivery** | IDOR in messaging allows sending XSS payloads to arbitrary users. | Targeted stored XSS delivery |
| **XSS + IDOR escalation** | XSS steals admin session, then uses IDOR in admin panel for full database access. | Critical: full application compromise |

### 3.2 Data Exchange with IDOR Agent

**XSS agent sends to IDOR agent**:
- Endpoints where user-specific content is rendered (potential IDOR targets)
- Active session tokens for cross-user testing
- DOM-discovered API endpoints with user ID parameters

**IDOR agent sends to XSS agent**:
- Endpoints where IDOR allows writing to other users' content (stored XSS delivery vector)
- User ID formats and enumeration results (for targeted XSS exploitation payloads)
- API endpoints that return user-controlled content without authorization checks

### 3.3 Handoff Protocol

```json
{
  "finding_type": "idor_xss_chain",
  "source_agent": "idor-agent",
  "target_agent": "xss-agent",
  "data": {
    "idor_endpoint": "PUT /api/users/{id}/profile",
    "injectable_field": "bio",
    "victim_id_format": "sequential_integer",
    "sample_ids": [1001, 1002, 1003],
    "auth_required": true,
    "recommendation": "Test stored XSS injection via IDOR write to victim profile bio field"
  }
}
```

---

## 4. Integration with WAF Bypass Agent (BBAG3NT-10)

When the XSS agent detects a WAF blocking payloads, it can delegate payload mutation to the specialized WAF bypass agent.

### 4.1 Payload Mutation Request

**XSS agent sends**:

```json
{
  "request_type": "payload_mutation",
  "agent_id": "xss-agent",
  "context": {
    "waf_vendor": "Cloudflare",
    "waf_version": "unknown",
    "blocked_payloads": [
      "<script>alert(1)</script>",
      "<img src=x onerror=alert(1)>",
      "<svg onload=alert(1)>"
    ],
    "injection_context": "html_body",
    "characters_allowed": "<>\"'()=/ ",
    "tags_allowed": ["unknown"],
    "events_allowed": ["unknown"]
  }
}
```

**WAF bypass agent responds**:

```json
{
  "response_type": "mutated_payloads",
  "waf_vendor": "Cloudflare",
  "payloads": [
    {
      "payload": "<details/open/ontoggle=confirm(1)>",
      "technique": "uncommon_tag_event",
      "confidence": "high"
    },
    {
      "payload": "<svg><animate onbegin=alert(1) attributeName=x dur=1s>",
      "technique": "svg_animation_event",
      "confidence": "medium"
    },
    {
      "payload": "<math><mi//onmouseover=alert(1)>hover</mi></math>",
      "technique": "mathml_namespace_confusion",
      "confidence": "medium"
    }
  ],
  "enumeration_results": {
    "allowed_tags": ["details", "math", "svg", "animate", "mi"],
    "allowed_events": ["ontoggle", "onbegin", "onmouseover"],
    "blocked_tags": ["script", "img", "iframe", "object", "embed"],
    "blocked_events": ["onerror", "onload"]
  }
}
```

### 4.2 Iterative Bypass Feedback Loop

If mutated payloads are also blocked, the XSS agent provides feedback:

```json
{
  "request_type": "bypass_feedback",
  "agent_id": "xss-agent",
  "feedback": {
    "payload_tested": "<details/open/ontoggle=confirm(1)>",
    "result": "blocked",
    "block_type": "waf_403",
    "response_code": 403,
    "notes": "ontoggle appears to be in the WAF ruleset now"
  },
  "request": "Generate payloads avoiding ontoggle event handler"
}
```

This iterative loop continues until either:
- A bypassing payload is found (success)
- All known bypass techniques are exhausted (document and move on)

---

## 5. Integration with SQLi/CMDi Agents

### 5.1 Cross-Vulnerability Intelligence Sharing

When the XSS agent finds input parameters that accept and reflect user input, those same parameters may be vulnerable to other injection types.

**XSS agent shares with injection agents**:

```json
{
  "finding_type": "input_surface_discovery",
  "source_agent": "xss-agent",
  "data": {
    "injectable_parameters": [
      {
        "url": "https://target.com/search",
        "method": "GET",
        "parameter": "q",
        "reflection_type": "html_body",
        "server_processing": true,
        "notes": "Input reflected in HTML and appears to be processed server-side (server errors on special chars)"
      }
    ]
  }
}
```

**Injection agents share with XSS agent**:

- Parameters confirmed to have server-side processing (potential for error-based XSS)
- Error pages that reflect input (error message XSS)
- Database-stored values that render in web UI (second-order XSS via SQL injection)

### 5.2 Chained Exploitation

| Chain | How It Works | Impact |
|-------|-------------|--------|
| SQLi -> Stored XSS | SQL injection writes XSS payload to database field that renders in web UI | Persistent XSS via database poisoning |
| XSS -> Internal SQLi | XSS in external app used to send requests to internal database admin panel | Network pivot to internal data |
| CMDi + XSS | Command injection reads files; XSS exfiltrates the data to attacker | Data theft combining server and client attacks |

---

## 6. Data Sharing Protocol Standards

### 6.1 Target Profile Format

All agents share a common target profile that is built incrementally:

```json
{
  "target_profile": {
    "domain": "target.com",
    "subdomains": ["app.target.com", "api.target.com", "admin.target.com"],
    "technology_stack": {
      "frontend": "React 18",
      "backend": "Node.js / Express",
      "database": "PostgreSQL",
      "cdn": "Cloudflare",
      "waf": "Cloudflare WAF"
    },
    "authentication": {
      "model": "jwt",
      "storage": "localStorage",
      "cookie_flags": {"session_id": {"httponly": true, "secure": true, "samesite": "Lax"}},
      "csrf_protection": "double-submit cookie"
    },
    "csp_policy": "default-src 'self'; script-src 'self' 'nonce-abc123'; style-src 'self' 'unsafe-inline'",
    "input_surfaces": {
      "url_parameters": ["/search?q=", "/profile?id=", "/api/users/{id}"],
      "post_endpoints": ["/api/comments", "/api/profile/update", "/contact"],
      "file_upload": ["/api/upload/avatar", "/api/documents"],
      "websocket": ["wss://app.target.com/ws"]
    }
  }
}
```

### 6.2 Session Context Format

Standardized session format shared between all agents:

```json
{
  "session": {
    "id": "session_001",
    "role": "user",
    "target": "https://target.com",
    "created_at": "2026-02-24T10:00:00Z",
    "expires_at": "2026-02-24T11:00:00Z",
    "cookies": [
      {"name": "session_id", "value": "abc...", "domain": ".target.com", "path": "/", "httponly": true, "secure": true}
    ],
    "headers": {
      "Authorization": "Bearer eyJ...",
      "X-CSRF-Token": "def456..."
    },
    "valid": true
  }
}
```

### 6.3 Finding Handoff Format

When one agent discovers something relevant to another agent, use this standardized format:

```json
{
  "finding_handoff": {
    "id": "handoff_xss_001",
    "timestamp": "2026-02-24T10:30:00Z",
    "source_agent": "xss-agent",
    "target_agent": "idor-agent",
    "priority": "high",
    "finding": {
      "type": "stored_xss_candidate",
      "url": "https://target.com/api/users/{id}/profile",
      "method": "PUT",
      "parameter": "bio",
      "details": "Bio field renders user input as HTML in profile page. No sanitization detected. Stored XSS confirmed. IDOR on this endpoint would enable attacking arbitrary users.",
      "evidence": {
        "payload": "<img src=x onerror=alert(document.domain)>",
        "response_screenshot": "evidence/xss_profile_bio.png"
      }
    },
    "recommended_action": "Test if PUT /api/users/{id}/profile is vulnerable to IDOR (modify other users' bio fields)"
  }
}
```

---

## 7. Agent Orchestrator Communication

### 7.1 XSS Agent Registration

When the orchestrator initializes the XSS agent:

```json
{
  "agent_registration": {
    "agent_id": "xss-agent",
    "agent_type": "vulnerability_scanner",
    "vulnerability_class": "CWE-79",
    "capabilities": ["reflected_xss", "stored_xss", "dom_xss", "blind_xss", "csp_bypass", "waf_bypass"],
    "dependencies": ["auth-agent"],
    "optional_integrations": ["recon-agent", "idor-agent", "waf-bypass-agent"],
    "input_requirements": ["target_url", "session_context"],
    "output_format": "vulnerability_report"
  }
}
```

### 7.2 Status Reporting

The XSS agent reports progress to the orchestrator at each methodology phase:

```json
{
  "status_report": {
    "agent_id": "xss-agent",
    "phase": "5_testing_execution",
    "progress_percent": 65,
    "findings_so_far": 3,
    "critical": 1,
    "high": 1,
    "medium": 1,
    "current_activity": "WAF bypass iteration on /search endpoint",
    "blockers": ["WAF blocking all payloads on /api/* endpoints -- requesting WAF bypass agent assistance"],
    "estimated_completion": "2026-02-24T12:00:00Z"
  }
}
```

### 7.3 Inter-Agent Request Routing

All inter-agent requests are routed through the orchestrator:

```
XSS Agent --> Orchestrator --> WAF Bypass Agent
                           --> Auth Agent
                           --> IDOR Agent
                           --> Recon Agent
```

The orchestrator handles:
- Request queuing and prioritization
- Session context distribution
- Finding deduplication (prevent multiple agents from reporting the same issue)
- Attack chain assembly from findings across agents
- Final report compilation

---

## 8. Integration Testing Checklist

```
[ ] Auth Agent Integration
    [ ] Session context request/response works
    [ ] Multiple role sessions received
    [ ] Cookie flags correctly parsed
    [ ] Token lifespan accounted for in testing timeline
    [ ] Exploitation payloads adapted to auth model

[ ] Recon Agent Integration
    [ ] Target profile consumed correctly
    [ ] URL parameters fed into reflection testing
    [ ] Technology stack drives payload selection
    [ ] WAF info drives bypass strategy
    [ ] JavaScript files analyzed for DOM XSS

[ ] IDOR Agent Integration
    [ ] XSS findings shared with IDOR agent for chain testing
    [ ] IDOR findings consumed for stored XSS delivery vectors
    [ ] Cross-user content manipulation chains tested

[ ] WAF Bypass Agent Integration
    [ ] Payload mutation request/response works
    [ ] Iterative feedback loop functions
    [ ] Enumeration results consumed for payload building

[ ] Orchestrator Integration
    [ ] Agent registration successful
    [ ] Status reporting at each phase
    [ ] Finding handoffs routed correctly
    [ ] Final report contribution submitted
```

---

## Key Takeaways

1. **Auth-agent is a hard dependency**: No authenticated XSS testing can proceed without session context from the auth-agent.
2. **Recon data accelerates testing**: Using recon agent's URL/parameter discovery skips Phase 2 manual enumeration.
3. **XSS + IDOR chains are critical**: Always share stored XSS findings with the IDOR agent for cross-user exploitation.
4. **WAF bypass delegation is efficient**: The dedicated WAF bypass agent maintains a larger, more current bypass database than the XSS agent alone.
5. **Standardized formats enable automation**: JSON-based request/response protocols allow programmatic inter-agent communication.
6. **The orchestrator prevents duplication**: All finding handoffs route through the orchestrator to avoid duplicate reporting and enable attack chain assembly.
