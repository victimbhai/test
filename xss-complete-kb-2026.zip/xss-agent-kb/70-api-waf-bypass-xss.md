# 70 - API WAF Bypass Techniques for XSS

## Overview

WAF bypass in API contexts exploits:
- WAFFLED methodology: 1,207 bypasses across 5 major WAFs via parser discrepancies
- Chunked transfer encoding splitting payloads across chunks
- Content-Type switching between form-urlencoded, JSON, and multipart
- Body-size limit exploitation padding payloads past inspection windows
- ModSecurity CRS 2026 CVEs in UTF-8, multipart, and comment transformations
- HTTP/2 HPACK encoding differences and downgrade smuggling

## WAFFLED Methodology (2025)

The WAFFLED methodology (Northeastern/Dartmouth, March 2025) identified and confirmed 1,207 bypasses across 5 well-known WAFs: AWS WAF, Azure WAF, Google Cloud Armor, Cloudflare, and ModSecurity. The attack keeps the malicious payload intact and mutates only the HTTP structure.

### Bypass Categories

- **557 JSON bypasses:** WAFs that do not fully parse JSON bodies before signature matching
- **351 multipart bypasses:** Boundary string variations, per-part header mutations, Content-Disposition field variations
- **299 XML bypasses:** Namespace features exploited for bypass

### Key Finding

More than 90% of tested applications processed URL-encoded and multipart forms equivalently, meaning content-type switching attacks have a very wide attack surface.

### HTTP-Normalizer

The researchers released HTTP-Normalizer, a proxy tool that validates HTTP requests against RFC standards, as a mitigation. All affected vendors acknowledged the vulnerabilities.

### Content-Type Switching

Changing the media type (e.g., from `application/x-www-form-urlencoded` to `application/json`) so the WAF applies a different parser or skips body inspection entirely, while the backend framework still parses the data correctly.

```http
# Original request (blocked by WAF):
POST /api/search HTTP/1.1
Content-Type: application/x-www-form-urlencoded

q=<script>alert(1)</script>

# Bypass: Switch to JSON (WAF may not inspect JSON bodies)
POST /api/search HTTP/1.1
Content-Type: application/json

{"q": "<script>alert(1)</script>"}

# Bypass: Switch to multipart (WAF may parse boundaries differently)
POST /api/search HTTP/1.1
Content-Type: multipart/form-data; boundary=----BYPASS

------BYPASS
Content-Disposition: form-data; name="q"

<script>alert(1)</script>
------BYPASS--
```

## Chunked Transfer Encoding Bypass

### CrowdSec AppSec Bypass (CVE-2026-44982)

**CVE-2026-44982:** Switching one header from Content-Length to Transfer-Encoding: chunked changed the response from 403 Forbidden to 200 OK. Affects CrowdSec AppSec versions 1.5.0 through 1.7.7, fixed in v1.7.8.

### F5 ASP.NET Core Smuggling (CVE-2025-55315)

**CVE-2025-55315:** Attackers abused chunk extensions in chunked transfer encoding to craft ambiguous request boundaries. Microsoft assigned it CVSS 9.9, the highest for ASP.NET Core to that date.

### Chunk-Splitting Technique

```http
# Attack: Split <script> across chunks
POST /api/search HTTP/1.1
Transfer-Encoding: chunked

3
<sc
4
ript
1
>
9
alert(1)
A
</script>
0

# WAF inspecting each chunk individually sees:
# Chunk 1: "<sc" (harmless)
# Chunk 2: "ript" (harmless)
# Backend reassembles: <script>alert(1)</script>
```

### Chunked + Multipart Double Reassembly

Combining chunked encoding with multipart boundaries creates a double reassembly requirement that further increases bypass probability.

## Body-Size Limit Exploitation

### Vendor-Specific Limits

- **Cloudflare:** Ignores requests over 131,072 bytes (128 KiB) on some configurations
- **Cloudflare Free:** Requests with 8,216+ bytes prepended bypass the WAF
- **AWS WAF:** Inspects only the first 8 KB of the request body for ALB and AppSync

```http
# Attack: Pad request body to push XSS past inspection window
POST /api/submit HTTP/1.1
Content-Type: application/json

{
  "padding": "AAAA....(8KB of padding)....AAAA",
  "comment": "<script>alert(document.cookie)</script>"
}
# AWS WAF inspects only first 8KB -- the XSS payload is beyond the limit
```

## ModSecurity CRS 2026 CVEs

### UTF-8 Transformation Bug (CVE-2026-52761)

ModSecurity 3.0.0-3.0.15 on i386 (32-bit): `t:utf8toUnicode` transformation produces incorrect output, allowing full-width UTF-8 XSS payloads to slip past rules. Fixed in 3.0.16. CVSS 5.3-5.8.

### Multipart Line Break Stripping (CVE-2026-52747)

ModSecurity before 3.0.16: multipart parser strips line breaks from form-field values before rules see them, so rules inspecting ARGS/ARGS_POST miss payloads depending on line breaks.

### removeComments Transformation Bypass (CVE-2026-104259)

ModSecurity v3 up to 3.0.16 and v2 up to 2.9.14: removeComments transformation bypass. Patched in 3.0.17 and 2.9.15.

### CRS Rule 922110 Multipart Bypass (CVE-2026-21876)

**CVE-2026-21876:** Critical (CVSS 9.3) flaw in CRS rule 922110, which blocks UTF-7 and UTF-16 charsets in multipart requests. The rule only validates the last part of a multipart request, so earlier parts can carry malicious charsets.

### URL Decoding Order Bug

ModSecurity versions 3.0.0 to 3.0.11 decoded URL-encoded characters before separating the URL path from the query string, enabling path-based injection bypasses.

## Vendor-Specific Bypass Findings

### Cloudflare

WAFFLED reported Cloudflare bypassed for multipart, JSON, and XML content types via parser discrepancies. Body-size limits vary by account tier.

### AWS WAF

Multiple AWS WAF rule sets (Managed Rules, Cyber Security Cloud rule set, F5 rule set) were completely bypassed by every parameter pollution payload tested (Bruno Mendes, August 2025). However, WAFFLED reported AWS WAF was the only tested WAF it did NOT bypass with multipart and JSON techniques.

### Azure WAF

Azure WAF with Microsoft's Default Rule Set 2.1 blocked all manually crafted parameter pollution payloads (3 of 17 WAFs that blocked). However, an automated hackbot found a bypass using an escaped-quote parsing discrepancy. WAFFLED reported Azure WAF bypassed for multipart and JSON.

## HTTP/2 WAF Bypass

### HPACK Encoding Differences

HTTP/2 binary framing makes XSS payloads in headers invisible to text-based WAF rules. A WAF inspecting HTTP/2 frames must decode HPACK-compressed headers before applying signature detection.

### Downgrade Smuggling

HTTP/2 downgrading creates XSS bypass when the WAF sees the HTTP/2 binary representation while the backend processes the downgraded HTTP/1.1 text. WAFs must inspect after protocol normalization.

### Stream Multiplexing

Multiple interleaved streams mean the WAF must maintain state per stream. A payload split across multiple HEADERS and CONTINUATION frames on the same stream may evade single-frame inspection.

## JSON Body XSS Bypass

JSON body XSS is the most promising API-specific WAF bypass because:
1. WAFs historically focused on URL parameters
2. JSON parsing is more complex than URL decoding
3. JSON Unicode escapes add an extra decoding layer
4. Many WAFs do not reassemble JSON values across nested structures

```json
// Attack: JSON body with Unicode-escaped XSS
{
  "comment": "<script>alert(1)</script>"
}
// WAF sees: <script> -- may not flag Unicode escapes
// JSON.parse() produces: <script>alert(1)</script>
```

## Detection and Prevention

### RASP (Runtime Application Self-Protection)

RASP operates inside the application at code-execution level, producing fewer false positives. Java and .NET have the most mature RASP agent options. Go and Rust ecosystems lack RASP tooling. OpenRASP (Baidu) is the only free option.

### Defense Hierarchy

1. Output encoding at the rendering layer (primary)
2. Input validation and normalization (secondary)
3. CSP headers (tertiary)
4. WAF rules (defense-in-depth only)

## Testing Methodology

1. **Test content-type switching** between form-urlencoded, JSON, and multipart
2. **Test chunked transfer encoding** with payload splitting
3. **Test body-size padding** to push payloads past inspection limits
4. **Test JSON Unicode escapes** (< for <, etc.)
5. **Test multipart boundary variations** with non-standard but RFC-valid boundaries
6. **Test parameter pollution** across duplicate parameter names
7. **Check ModSecurity version** for 2026 CVE exposure
8. **Test HTTP/2 header injection** via HPACK encoding differences

## Bug Bounty Tips

1. WAFFLED confirmed 1,207 bypasses -- systematically test all HTTP structure mutations
2. Body-size limits (AWS 8KB, Cloudflare 128KB) are trivially exploitable
3. ModSecurity CRS has a cluster of 2026 CVEs -- check transformation pipeline
4. Content-Type switching bypasses 90%+ of applications that accept multiple formats
5. JSON body XSS is the most promising API-specific bypass vector
6. WAFs should be defense-in-depth only -- output encoding is the authoritative defense
7. Test all three content types (JSON, multipart, XML) for each payload
8. Combine encoding + parameter pollution + Content-Type switching for layered evasion
